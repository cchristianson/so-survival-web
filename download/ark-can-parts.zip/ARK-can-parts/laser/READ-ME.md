# Etching ARK on a steel ammo can

Files for a laser that burns through paint (diode or fiber): the logo on one long side of a
**50 cal ammo can**, and two bare-metal strips along the lid seam on both long sides, so conductive
foil tape over the closed lid touches bare steel (see the *Ammo-Can Library Computer* and *EMP* guides).
The measurements come from a CAD model of a 50 cal can. Cans vary a little, so measure yours first.

![The can after etching, with the tape on, and where everything goes](can-plan.png)

All files are at real size, in millimetres: SVG for LightBurn, xTool and most others, or DXF.
Everything is a **fill** (engrave) job: the laser burns the paint off inside each shape.

| File (in the area's folder, e.g. `illinois-valley/`) | |
|---|---|
| `ark-can-side-1-logo-and-strips` | The logo side: logo and both strips (270.8 × 157.4 mm) |
| `ark-can-side-2-strips` | The other long side: just the strips (270.8 × 32.3 mm) |
| `ark-can-logo-only` | The logo by itself (about 128 × 100 mm) |

Colours are layers (LightBurn's colours): **black** = logo, **red** = strip on the lid's edge, **blue** =
strip on the body just below it.

## Setting up

1. **Measure your can.** Lid's bottom edge to the bottom of the can: about 160 mm (6¼ in). Flat part of
   the long side: about 271 mm. If yours is off by more than a few mm, resize before burning.
2. Lay the can on its side, **lid closed and latched**, so the lid strip lines up with the body.
3. Frame the job. The thin unburned gap between the red and blue strips sits right on the lid's bottom
   edge. The strips stop about 3 mm short of the rounded corners.
4. The lid's edge sticks out about 3 mm closer to the laser than the body. If the red strip comes out
   weak, run it as its own pass with the focus raised 3 mm.
5. Test on the bottom of the can first, to find a speed and power that takes the paint off cleanly
   without heating the steel blue. Run your fume extraction: burning paint makes nasty smoke.

## After burning

- The bare logo will rust. Give it a light coat of clear spray paint with the strips masked off; the
  strips must stay bare metal for the tape to make contact.
- The two ends (hinge and latch) can't be reached with the can on its side. Where the tape crosses
  them, sand a strip of paint off by hand on the lid's edge and on the body.
- Wipe the strips with rubbing alcohol before taping. Use foil tape with **conductive glue** (the
  strips are sized for 2-inch tape), and tape all the way round the closed lid. Keep it taped in
  storage so the strips don't rust.
- The tape is for storage: with the lid taped shut, Wi-Fi can't get out, so peel it off when you run
  the library.

`python3 tools/maintenance/make_logo.py` makes these files for the active area (the area's name is on
the logo); the can's measurements are at the `CAN = ...` line in that script.
