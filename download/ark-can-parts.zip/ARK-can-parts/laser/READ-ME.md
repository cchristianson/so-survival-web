# Etching ARK on a steel ammo can

Files for a laser that burns through paint (diode or fiber): the **ARK Vault** logo on both long sides of a
**50 cal ammo can**, and bare-metal strips all the way round the lid seam, so conductive foil tape over
the closed lid touches bare steel (see the *ARK Vault* and *EMP* guides).
The measurements come from a CAD model of a 50 cal can. Cans vary a little, so measure yours first.

![The can's long side after etching, with the tape on, and where everything goes](can-plan.png)

![The two ends and the lid's top after etching, and the ends taped](can-plan-ends.png)

All files are at real size, in millimetres: SVG for LightBurn, xTool and most others, or DXF.
Everything is a **fill** (engrave) job: the laser burns the paint off inside each shape.

| File (in the area's folder, e.g. `illinois-valley/`) | |
|---|---|
| `ark-can-long-side-logo-and-strips` | A long side: logo and both strips (270.8 × 157.4 mm). Burn it on **both** long sides |
| `ark-can-end-strip` | An end: one band (127.3 × 20 mm). Burn it on **both** ends: below the hinge and below the latch |
| `ark-can-lid-top-strips` | The lid's top: a band across each end (14 and 10 mm wide, 275.5 mm apart overall) |
| `ark-can-logo-only` | The logo by itself (about 145 × 100 mm) |

Colours are layers (LightBurn's colours): **black** = logo, **red** = a strip on the lid, **blue** = a
strip on the body.

## Setting up

1. **Measure your can.** Lid's bottom edge to the bottom of the can: about 160 mm (6¼ in). Flat part of
   the long side: about 271 mm. If yours is off by more than a few mm, resize before burning.
2. Lay the can on its side, **lid closed and latched**, so the lid strip lines up with the body.
3. Frame the job. The thin unburned gap between the red and blue strips sits right on the lid's bottom
   edge. The strips stop about 3 mm short of the rounded corners.
4. The lid's edge sticks out about 3 mm closer to the laser than the body. If the red strip comes out
   weak, run it as its own pass with the focus raised 3 mm.
5. **The ends** (the hinge and the latch sit right on the seam, so the tape goes over them): stand the can
   on one end to burn the other. The band goes **2 mm below the hinge plate** at the hinge end and
   **2 mm below the latch lever's bottom tab** at the latch end, centred across the end. Not enough
   room under your laser? Sand or scrape the same band by hand.
6. **The lid's top:** with the can standing upright and the handle folded flat, one band goes just inside
   the hinge leaf (the riveted plate along the hinge edge), the other between the two dimples at the
   latch end and the rounded edge.
7. Test on the bottom of the can first, to find a speed and power that takes the paint off cleanly
   without heating the steel blue. Run your fume extraction: burning paint makes nasty smoke.

## After burning

- The bare logo will rust. Give it a light coat of clear spray paint with the strips masked off; the
  strips must stay bare metal for the tape to make contact.
- Wipe the strips with rubbing alcohol before taping. Use foil tape with **conductive glue** (the
  strips are sized for 2-inch tape). Tape each long side with one strip over the seam; then tape each
  end with three pieces side by side, from the band on the lid's top, over the hinge (or the latch),
  down past the band below. Overlap the pieces a little, and overlap the long sides' tape at the
  corners. Keep it taped in storage so the strips don't rust.
- The tape is for storage: with the lid taped shut, Wi-Fi can't get out, so peel it off when you run
  the library.

`python3 tools/maintenance/make_logo.py` makes these files for the active area (the area's name is on
the logo); the can's measurements are at the `CAN = ...` line in that script.
