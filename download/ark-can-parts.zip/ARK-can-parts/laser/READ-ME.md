# Etching ARK on a steel ammo can

Files for a laser that burns through paint (diode or fiber): the **ARK Vault** logo on both long sides of a
**50 cal ammo can**, and bare-metal strips all the way round the lid seam, so conductive foil tape over
the closed lid touches bare steel (see the *ARK Vault* and *EMP* guides).
The measurements come from a CAD model of a 50 cal can. Cans vary a little, so measure yours first.

![The can's long side after etching, with the tape on, and where everything goes](can-plan.png)

![The two ends after etching, and one band of tape going right round the can](can-plan-ends.png)

All files are at real size, in millimetres: SVG for LightBurn, xTool and most others, or DXF.
Everything is a **fill** (engrave) job: the laser burns the paint off inside each shape.

| File (in the area's folder, e.g. `illinois-valley/`) | |
|---|---|
| `ark-can-long-side-logo-and-strips` | A long side: logo and both strips (270.8 × 157.4 mm). Burn it on **both** long sides |
| `ark-can-end-strip` | An end: one band (127.3 × 20 mm). Burn it on **both** ends, level with the blue strip on the long sides |
| `ark-can-logo-only` | The logo by itself (about 145 × 100 mm) |

Colours are layers (LightBurn's colours): **black** = logo, **red** = a strip on the lid, **blue** = a
strip on the body.

## Setting up

1. **Measure your can.** Lid's bottom edge to the bottom of the can: about 160 mm (6¼ in). Flat part of
   the long side: about 271 mm. If yours is off by more than a few mm, resize before burning.
2. Lay the can on its side, **lid closed and latched**, so the lid strip lines up with the body.
3. Frame the job. The thin unburned gap between the red and blue strips sits right on the lid's bottom
   edge. The strips stop about 3 mm short of the rounded corners.
4. The lid's edge sticks out about 3 mm closer to the laser than the body. If the red strip comes out
   weak, run it as its own pass with the focus raised 3 mm.
5. **The ends:** the blue (body) strip carries on round each end **at the same height**. Burn the long
   sides first, then stand the can on one end to burn the other, and line the band up with the blue strip
   showing at the corners, centred across the end. (The lid has no edge to burn at its ends, only the hinge
   and the latch, so the red strip stops at the long sides.)
   - **Hinge end:** the band lies on the hinge plate, just under the hinge's knuckles.
   - **Latch end:** open the latch and flip it up over the lid first, so the laser reaches the steel
     behind it. It will skip the hook that sticks out; sand the paint off the hook's face by hand if you
     want the tape to bite there too.

   Not enough room under your laser? Sand or scrape the same band by hand.
6. Test on the bottom of the can first, to find a speed and power that takes the paint off cleanly
   without heating the steel blue. Run your fume extraction: burning paint makes nasty smoke.

## After burning

- The bare logo will rust. Give it a light coat of clear spray paint with the strips masked off; the
  strips must stay bare metal for the tape to make contact.
- Wipe the strips with rubbing alcohol before taping. Use foil tape with **conductive glue** (the
  strips are sized for 2-inch tape). **One band goes right round the can**, about 1 m (40 in) of tape:
  with the lid shut and latched, start in the middle of a long side, covering the red and the blue
  strip, and carry on round: over the hinge, along the other side, over the closed latch, and back,
  overlapping the start by 5 cm (2 in). Press it down hard on the bare steel, and work it down around
  the hinge and the latch as far as it will go. Keep it taped in storage so the strips don't rust.
- The tape is for storage: with the lid taped shut, Wi-Fi can't get out, so peel it off when you run
  the library.

`python3 tools/maintenance/make_logo.py` makes these files for the active area (the area's name is on
the logo); the can's measurements are at the `CAN = ...` line in that script.
