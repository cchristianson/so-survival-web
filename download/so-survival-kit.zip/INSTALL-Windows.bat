@echo off
title SO Survival Library - Installer (keep this window open)
cd /d "%~dp0"
if not exist "%~dp0Get-OfflineLibrary.ps1" (
  echo The installer files are missing next to this file.
  echo Right-click the downloaded zip, choose "Extract All...", then double-click
  echo INSTALL-Windows inside the folder it makes.
  pause
  exit /b 1
)
rem Files that came from the internet are marked "from the web". Clear that mark on this kit's own
rem files so Windows lets the installer program start without extra warnings.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0.' -Recurse -File | Unblock-File" >nul 2>&1
set "LA=%~dp0local\library-assistant\library-assistant.exe"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" if exist "%~dp0local\library-assistant\library-assistant-arm64.exe" set "LA=%~dp0local\library-assistant\library-assistant-arm64.exe"
echo.
echo   The installer is opening in your web browser.
echo   Keep THIS window open until the download has finished.
echo.
"%LA%" -setup
if errorlevel 1 (
  echo.
  echo The point-and-click installer could not start - using the text installer instead.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Get-OfflineLibrary.ps1"
)
pause
