@echo off
title SO Survival Library - Installer (keep this window open)
cd /d "%~dp0"
rem The kit keeps the installer's parts in a "files" folder next to this file (in the repo they sit beside it).
set "K=%~dp0"
if exist "%~dp0files\Get-OfflineLibrary.ps1" set "K=%~dp0files\"
if not exist "%K%Get-OfflineLibrary.ps1" (
  echo.
  echo   This file needs the rest of the kit next to it.
  echo   Right-click the downloaded zip, choose "Extract All...", click Extract,
  echo   then double-click INSTALL-Windows inside the folder that opens.
  echo.
  pause
  exit /b 1
)
rem Files that came from the internet are marked "from the web". Clear that mark on this kit's own
rem files so Windows lets the installer program start without extra warnings.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0.' -Recurse -File | Unblock-File" >nul 2>&1
set "LA=%K%local\library-assistant\library-assistant.exe"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" if exist "%K%local\library-assistant\library-assistant-arm64.exe" set "LA=%K%local\library-assistant\library-assistant-arm64.exe"
echo.
echo   Starting the installer - it opens in your web browser in a moment...
"%LA%" -setup
if errorlevel 1 (
  echo.
  echo   The browser page could not start, so the installer will ask its questions here instead.
  echo.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%K%Get-OfflineLibrary.ps1"
)
pause
