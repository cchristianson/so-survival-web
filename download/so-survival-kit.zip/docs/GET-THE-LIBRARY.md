# 💾 Get the Whole Library on a USB Drive

This website holds the guides and tools. The **full library** also has every book, all of
Wikipedia with pictures, maps you can use with no signal, and an AI that runs with no internet. It
is too big for a website, so you put it on a **USB drive, external hard drive or SD card** while
you still have internet. After that it works with the power and phones out.

You don't need to type any commands. You download a small kit (about 85 MB), double-click one file,
and a page opens in your web browser where you pick the drive and press **Start**.

> ### ⚠️ Before you start
> - **Do it now, while the internet works.** The full download is large and takes hours. A
>   library you meant to download does nothing for you in an outage.
> - **Use a drive with nothing important on it**, or plenty of free space. The installer only adds
>   files; it never erases a drive.
> - **Leave the computer plugged in and awake** until the bar reaches 100%. If it stops (the
>   internet drops, the laptop sleeps), just run it again and press **Continue**. It picks up
>   where it left off.

---

## 📥 Step 1: Download the kit

**[⬇️ Download the installer kit (so-survival-kit.zip)](https://cchristianson.github.io/so-survival-web/download/so-survival-kit.zip)**

It is one zip file, about 85 MB. It works on **Windows, Mac and Linux** computers. (Phones and
tablets can't make the drive, but they can *use* one afterwards. See
[Start on any device](guide:START-ON-ANY-DEVICE).)

---

## 🧰 Step 2: Unzip it and double-click the installer

### Windows

1. Open your **Downloads** folder. **Right-click `so-survival-kit.zip` → Extract All… → Extract.**
   (Don't run it from inside the zip. It needs to be unzipped first.)
2. In the folder that opens, **double-click `INSTALL-Windows`**.
3. If Windows shows a blue box saying it *protected your PC*, click **More info → Run anyway**.
   If it asks *Do you want to run this file?*, click **Run**.
4. A black window opens (leave it open) and then the installer page opens in your web browser.

### Mac

1. Open **Downloads** and **double-click `so-survival-kit.zip`**. It unzips into a folder.
2. In that folder, **double-click `INSTALL-Mac`**.
3. The first time, your Mac will probably say it **can't verify** the file or **can't open** it
   because it's from the internet. Click **Done** (or **OK**), then:
   - open the **Apple menu → System Settings → Privacy & Security**,
   - scroll down to the message about `INSTALL-Mac` and click **Open Anyway**, then confirm.
   - (On older Macs you can instead **right-click `INSTALL-Mac` → Open → Open**.)
4. A Terminal window opens (leave it open) and then the installer page opens in your web browser.

### Linux (and Raspberry Pi)

1. Unzip the kit (right-click → *Extract Here*).
2. Open a terminal in that folder and type `bash INSTALL-Linux.sh`, then press Enter.
   (Some file managers can also run it: right-click → *Run as a Program*.)
3. The installer page opens in your web browser.

---

## ✅ Step 3: Pick the drive and press Start

The installer page has three simple steps:

1. **Pick the drive.** Plug in the USB drive first. Each drive shows its name and how much free
   space it has. Click the one you want. (If it isn't listed, click **I plugged in a drive - look again**.)
2. **Choose what to put on it.** The installer checks how big each part is today and ticks a set
   that **fits your drive**. You can tick or untick anything; the bar at the bottom shows the total
   and turns red if it's too big. Not sure? Keep what it picked.
3. **Press Start** and watch the progress bar. It shows how much is done and roughly how long is
   left. When it says **The library is on your drive**, click **Open the library** to try it.

Then **eject the drive** properly before you unplug it (Windows: the USB icon by the clock; Mac:
drag the drive to the Trash or click ⏏ in Finder).

---

## 📏 How big a drive?

The installer fills whatever drive you give it, so any size works. Roughly:

| Drive size | What fits |
|---|---|
| **16 GB** | All the guides and local books, the Library Assistant with a small AI, the medical encyclopedias, and maps of Oregon |
| **32 GB** | Add a short Wikipedia (the opening of every article) and maps of Oregon and California |
| **64 GB** | Add the repair encyclopedias, the bigger AI models and maps of the whole USA |
| **128 GB** | Add all of Wikipedia's text (no pictures) |
| **256 GB or more** | Everything, including all of Wikipedia with pictures |

Large USB 3 flash drives and small external SSDs are both fine. An SSD is faster and tougher.

**If you tick the map viewer for computers,** the installer keeps some of the drive **empty on
purpose** (about 30 GB for maps of the whole USA). The viewer unpacks the maps into that space the
first time you open it, so until then the drive shows more free space than you might expect. Phones
use the maps as they are and don't need it.

---

## 🔌 Make the drive work on every kind of device

For a drive you'll plug into different computers and tablets, two things matter:

1. **Keep "Works on every kind of device" ticked.** It adds the programs for Windows, Mac, Linux,
   Raspberry Pi and Android tablets. The installer ticks it for you on any USB or external drive.
2. **The drive's format should be exFAT.** The installer shows each drive's format and warns you if
   it isn't:

| Format | Works on | |
|---|---|---|
| **exFAT** | Windows, Mac, Linux, Raspberry Pi, most Android tablets | ✅ Best choice |
| **FAT32** | Everything | ⚠️ Can't hold a file over 4 GB, so no Wikipedia and no large AI |
| **NTFS** | Windows and Linux. Macs can only read it | ⚠️ Most Android tablets can't open it |
| **APFS / Mac OS Extended** | Macs only | ❌ Windows and Android can't open it |

**To switch a drive to exFAT** (this **erases everything** on it, so copy off anything you want to
keep first):

- **Windows:** File Explorer → **This PC** → right-click the drive → **Format…** → File system
  **exFAT** → **Start**.
- **Mac:** **Disk Utility** → View → Show All Devices → click the drive itself (the top line) →
  **Erase** → Format **ExFAT**, Scheme **Master Boot Record** → Erase.

Most new USB drives over 32 GB already come as exFAT.

---

## 🔁 Using it, copying it, updating it

- **To use it:** plug the drive in and open **`START-HERE.html`**, or double-click
  **`START-Windows`** / **`START-Mac`** for the search box and the offline AI. Details for every
  kind of device are in [Start on any device](guide:START-ON-ANY-DEVICE).
- **To make a copy for a neighbor:** copy the whole `OfflineLibrary` folder to their drive. The
  copy works exactly like the original. No internet needed.
- **To update it later:** run the installer again and pick the same drive. It keeps what you
  already have and only downloads what's new or missing.

---

## ❓ If something goes wrong

| What happens | What to do |
|---|---|
| Windows says the file **can't be found**, or nothing happens | You ran it from inside the zip. Right-click the zip → **Extract All**, then use the unzipped folder |
| The browser page doesn't open | Look at the black (or Terminal) window: it shows the address to open, like `http://127.0.0.1:8097/...`. Copy it into your browser. If that fails too, the same choices appear as questions in that window instead |
| Mac says it **can't be opened** | System Settings → Privacy & Security → **Open Anyway** (see the Mac steps above) |
| My drive isn't in the list | Plug it in, wait a few seconds and click **look again**. Or open *Use a different folder instead* and type the drive's location (like `E:\`) |
| It stopped partway | Run the installer again, pick the same drive and press **Continue** |
| It says it's **too big** | Untick something (Wikipedia with pictures and US maps are the largest), or click **Fill it automatically again** |
| A drive says it **can't hold a file that large** | The drive is formatted FAT32 (4 GB file limit). Switch it to **exFAT** (see *Make the drive work on every kind of device* above) |
| Lots of space is still **free after it finished** | You ticked the map viewer: that space is kept for it to unpack the maps the first time you open it (on the drive: `OsmAnd` → `MapViewer-Desktop` → `VIEW-MAPS-ON-PC`). The installer says how much when it finishes |
| The drive won't open on a Mac or Android tablet | Check its format (above). exFAT works everywhere |

Something else? The text window behind the installer shows each step. A photo of it helps anyone
helping you.
