# 🐇🐔 Rabbits & Chickens for Meat and Eggs

How to keep meat rabbits and a self-renewing chicken flock with no feed store, vet or hatchery:
breeds, hutches and coops, local predators, feeding on hay, greens, grain and scraps, breeding and
kindling, hatching chicks under hens, eggs, summer heat, common diseases, slaughter and butchering,
manure, and keeping the breeding lines going for years. The books are in `Small-Livestock\`
(`Rabbits`, `Chickens`, `Slaughter-Processing`) and `Animals\` (`Poultry`, `Rabbits-Other`,
`Veterinary`, `Planning-Predators-Toxic-Plants`).

> ### ⚠️ Rules that prevent the worst losses
> - **Lock birds in every night** behind **hardware cloth, not chicken wire**, buried at least
>   12 inches. A weasel kills several birds at once and fits through a ¼-inch gap
>   ([Kentucky ID-245, pp. 3, 6](lib:predator-management-for-small-scale-poultry#page=6)).
> - **Heat kills rabbits.** Plan litters for spring and fall, not July–August, and have shade, airflow
>   and water ready before 100 °F days ([USDA FB 1730, p. 31](lib:rabbit-production-usda-farmers-bulletin-1730#page=31)).
> - **Never feed heated, moldy or sprayed greens**, or plants from where dogs and cats go. **Scotch broom
>   and foxglove** — everywhere here — are toxic ([WSNWCB, p. 55](lib:wsnwcb-protect-your-horses-and-livestock-from-toxic-plants#page=55)).
> - **Keep breeds that can renew themselves.** Hybrid layers and Cornish-cross broilers rarely go broody
>   and won't rebuild a flock ([FAO, p. 10](lib:small-scale-poultry-production-technical-guide#page=10)).
> - **Rabbit meat alone is not a diet** — it is very lean. Eat it with fat and starch.
> - **The old bulletins' medicines are poisons** (sodium fluoride, carbon tetrachloride, nicotine, DDT,
>   lindane). See the last section.

---

## 🐇 Choosing breeds and starting stock

**Rabbits:**
- **[New Zealand](wiki:New_Zealand_rabbit) or [Californian](wiki:Californian_rabbit)** — by far the leading
  meat breeds, for steady color and growth ([🖼️ meat breeds](lib:selecting-and-raising-rabbits#page=6)). Most meat rabbits are butchered by 10 weeks
  ([OSU EC 1651, p. 1](lib:raising-rabbits-for-meat-getting-started#page=1)).
- Start with **2–3 does per buck** (6 does and 2 bucks is typical). **Buy from several different
  breeders** to avoid inbreeding. Pick thick-boned rabbits, as deep as they are wide
  ([EC 1651, p. 2](lib:raising-rabbits-for-meat-getting-started#page=2); [🖼️ body shape to look for](lib:raising-rabbits-for-meat-getting-started#page=1)).

**Chickens** ([USDA FB 1508, p. 6](lib:poultry-keeping-in-back-yards#page=6);
[FB 1363, p. 8](lib:natural-and-artificial-incubation#page=8)):

| Breed | Good for | Notes |
|---|---|---|
| [Plymouth Rock](wiki:Plymouth_Rock_chicken), [Rhode Island Red](wiki:Rhode_Island_Red), [Wyandotte](wiki:Wyandotte_chicken), [Orpington](wiki:Orpington_chicken), [Australorp](wiki:Australorp) | **Eggs and meat** | Most make good mothers — the best choice for a self-renewing flock ([🖼️ Buff Orpington](lib:poultry-keeping-in-back-yards#page=8)) |
| [Leghorn](wiki:Leghorn_chicken), [Ancona](wiki:Ancona_chicken), [Minorca](wiki:Minorca_chicken) | Eggs | Fly over fences; "fickle mothers" ([🖼️ Leghorn flock](lib:poultry-keeping-in-back-yards#page=5)) |
| [Brahma](wiki:Brahma_chicken), [Jersey Giant](wiki:Jersey_Giant), [Cochin](wiki:Cochin_chicken) | Meat | Sit well but are clumsy on eggs |
| Commercial hybrids, [Cornish-cross](wiki:Broiler) | Short-term only | "Very low mothering ability and broodiness" ([FAO, p. 10](lib:small-scale-poultry-production-technical-guide#page=10)) |

📚 **Go deeper:** [OSU EC 1651](lib:raising-rabbits-for-meat-getting-started#page=1) — meat breeds and picking breeding stock; [USDA FB 1508, p. 6](lib:poultry-keeping-in-back-yards#page=6) — back-yard chicken breeds; [Practical Poultry Raising](lib:practical-poultry-raising-peace-corps) — low-input flocks.

## 🏠 Hutches and coops

**Rabbit hutches** ([USDA AIB 358, pp. 8–10](lib:selecting-and-raising-rabbits#page=8);
[OSU EC 1654, p. 2](lib:raising-rabbits-for-meat-managing-animals-health#page=2);
[🖼️ two-compartment hutch](lib:selecting-and-raising-rabbits#page=10); [🖼️ building plans](lib:rabbit-production-usda-farmers-bulletin-1730#page=38)):
- About **2 ft high, no more than 2½ ft deep**; **3 ft long** for small breeds, **4 ft** for medium,
  **6 ft** for large. At least **¾ sq ft per pound** of rabbit.
- Scrap lumber and hardware cloth work. Give each **[hutch](wiki:Hutch_(animal_cage))** shade, a rain-proof
  roof and no drafts.
- **Water bottles or nipples, not crocks** (crocks get fouled). **No cedar shavings.**
- A **resting board** on part of a wire floor prevents sore hocks
  ([R-41, p. 26](lib:backyard-and-commercial-rabbit-production#page=26)).

**Colony or ground pens** *(rule of thumb)*: they save wire and work, but rabbits dig out (bury mesh or
a 2-ft wire apron; cover the top), catch coccidiosis and tapeworm from soil, and you lose track of matings. Does in heat ride each other and conceive less
([R-41, p. 41](lib:backyard-and-commercial-rabbit-production#page=41)); extra bucks fight — castrate or
remove them ([p. 67](lib:backyard-and-commercial-rabbit-production#page=67)). **Keep breeding does in their
own hutches**; put only growing fryers on grass in movable pens.

**[Chicken coops](wiki:Poultry_farming)** ([OSU EC 1644, pp. 1–2](lib:osu-backyard-chicken-coop-design-ec-1644#page=1); [🖼️ coop photo](lib:osu-backyard-chicken-coop-design-ec-1644#page=1)):
- **3 sq ft per bird** in the coop with a run, **8–10 sq ft** without one.
- Raise the coop **1 ft off the ground**. Roosts **2 ft high**, **5–10 inches of pole per bird**
  ([🖼️ roost layouts](lib:osu-backyard-chicken-coop-design-ec-1644#page=2)).
- Run of **1×2-inch mesh**, **top covered**, fence buried **6–12 inches** (Kentucky says 12+).
- A movable pen (a **[chicken tractor](wiki:Chicken_tractor)**) puts birds on fresh grass and breaks the
  parasite cycle.

📚 **Go deeper:** [USDA AIB 358, p. 10](lib:selecting-and-raising-rabbits#page=10) — scrap-lumber hutch plans; [OSU EC 1654, p. 1](lib:raising-rabbits-for-meat-managing-animals-health#page=1) — cages, drafts and bedding; [OSU EC 1644](lib:osu-backyard-chicken-coop-design-ec-1644#page=1) — coop design for Oregon.

## 🦝 Predators of the Illinois Valley

**Who did it?** ([Kentucky ID-245, pp. 2–3](lib:predator-management-for-small-scale-poultry#page=2)) — all of these live here:

| Predator | What you find |
|---|---|
| **[Bobcat](wiki:Bobcat)** | Whole bird eaten or gone; leftovers **covered with leaves and grass** (nothing else does this) |
| **[Raccoon](wiki:Raccoon)** | Head, crop and breast eaten; **heads pulled through the wire**; eggs carried 50+ yards |
| **Fox** | Bird gone; a few drops of blood and feathers |
| **[Opossum](wiki:Virginia_opossum)** | Feeding started **at the vent** |
| **Weasel or [mink](wiki:American_mink)** | **Several birds killed**, bloody, little eaten. A [least weasel](wiki:Least_weasel) fits a **¼-inch** hole |
| **[Hawk](wiki:Hawk) or [owl](wiki:Owl)** | Daytime (hawk) or night (owl) losses from open runs |

**Keeping them out** ([ID-245, pp. 5–6](lib:predator-management-for-small-scale-poultry#page=5); [🖼️ photos](lib:predator-management-for-small-scale-poultry#page=5)):
1. **Hardware cloth**, buried at least **12 inches**. [Chicken wire](wiki:Chicken_wire) keeps chickens in, not raccoons out.
2. **Lock birds in every night.** Feed them inside at dusk and they learn to go in on their own.
3. **Cover the run** against hawks and owls, and remove perches within 100 yards. **Hawks and owls are
   federally protected — don't shoot them.**
4. **A [guardian dog](wiki:Livestock_guardian_dog)** (such as a [Great Pyrenees](wiki:Pyrenean_Mountain_Dog)) that **stays with the flock** works day and night
   ([raising one](lib:livestock-guarding-dogs-usda-aib588#page=13)).
5. **Rabbits too:** hawks swoop into open pens; dogs and raccoons bend wire and open simple latches
   ([OSU EC 1654, p. 1](lib:raising-rabbits-for-meat-managing-animals-health#page=1)) — use clips a paw can't work *(rule of thumb)*.

**Big predators:** for **[cougars](wiki:Cougar)**, fence and shelter stock and shut them in sheds at night; Oregon law
lets a landowner kill a cougar that is damaging livestock ([ODFW, p. 2](lib:oregon-is-cougar-country-odfw#page=2)).
For **[black bears](wiki:American_black_bear)**, a properly installed **[electric fence](wiki:Electric_fence)** is the most reliable protection for a coop
([ODFW, p. 2](lib:raising-chickens-in-bear-country-odfw#page=2); [🖼️ building a bear fence, step by step (beehive version)](lib:building-bear-fences#page=3)).

📚 **Go deeper:** [Kentucky ID-245, p. 2](lib:predator-management-for-small-scale-poultry#page=2) — predator signs and fixes in detail; [ODFW *Raising Chickens in Bear Country*](lib:raising-chickens-in-bear-country-odfw#page=2) — electric fence setup; [USDA *Livestock Guarding Dogs*, p. 13](lib:livestock-guarding-dogs-usda-aib588#page=13) — raising a guardian pup.

## 🌾 Feeding on little bought feed

**Rabbits without pellets** ([USDA AIB 358, p. 12](lib:selecting-and-raising-rabbits#page=12)):
- **Leafy legume hay** (alfalfa, clover, vetch) + **whole grain** (oats, wheat, barley, rye, sorghum,
  buckwheat, soft corn) + **salt**.
- **Roots all year**, especially winter: carrots, turnips, beets, [mangels](wiki:Mangelwurzel), sweet potatoes,
  [Jerusalem artichokes](wiki:Jerusalem_artichoke) ([FB 1730, p. 11](lib:rabbit-production-usda-farmers-bulletin-1730#page=11)).
- Expect **3–9 oz of feed per rabbit a day**, and slower growth than on pellets — home mixes are hard to
  balance ([OSU EC 1655, p. 1](lib:raising-rabbits-for-meat-providing-basic-care#page=1)).

**Feeding greens safely** ([FB 1730, p. 12](lib:rabbit-production-usda-farmers-bulletin-1730#page=12);
[R-41, pp. 37–38](lib:backyard-and-commercial-rabbit-production#page=37)):
1. Fresh, **once a day, only what they eat in 4–5 minutes**, in a **manger, never on the floor**.
2. Dew-wet greens are fine. **Greens that sat in a pile and heated are dangerous.**
3. **Never** forage from where dogs or cats defecate (tapeworm, coccidiosis), or that was sprayed.
4. **Change the diet slowly.** A big feed of lush greens can kill rabbits used to pellets.

**Chickens on scraps, greens and range:**
- Mix each day's **table scraps** into a grain mash. Give **greens all the time** (clippings, cabbage,
  lettuce). **No onion tops, geranium leaves or strong-flavored scraps** — they taint eggs
  ([FB 1508, pp. 26–27](lib:poultry-keeping-in-back-yards#page=26)). Scraps are a supplement: too many
  lower laying ([PNW 477, p. 4](lib:pnw-how-to-feed-your-laying-hens-pnw-477#page=4)).
- **Winter greens: sprouted oats.** Soak oats 24 hours in a pail with small holes in the bottom, keep
  moist and rinse daily until they sprout ([FB 1508, p. 27](lib:poultry-keeping-in-back-yards#page=27)).
- **Foragers** eat insects, worms, snails, seeds, grass and leaves; village hens' crops held 72% household
  waste ([FAO, pp. 17–18](lib:small-scale-poultry-production-technical-guide#page=17)).
  You can grow fly maggots on wet seed husks or dung ([p. 24](lib:small-scale-poultry-production-technical-guide#page=24)) —
  [black soldier fly](wiki:Hermetia_illucens) larvae are a common choice *(rule of thumb)*.
- **With a dairy goat or cow:** layers can live on **skim milk or buttermilk to drink**, all the grain they
  want, and oyster shell — about **4–5 gallons of milk a day per 100 hens**
  ([FB 1841, pp. 23–24](lib:the-feeding-of-chickens#page=23)).
- **Calcium always:** oyster shell, limestone or **crushed baked eggshell**. The flock's own shells aren't
  enough, and short hens start **eating their eggs** ([Practical Poultry Raising, p. 117](lib:practical-poultry-raising-peace-corps#page=117)).
  **Grit or gravel** for confined birds ([FB 1508, p. 28](lib:poultry-keeping-in-back-yards#page=28)).

**Our dry season:** scavenged feed dries up ([FAO, p. 36](lib:small-scale-poultry-production-technical-guide#page=36)) —
here, roughly **July–October** when the grass browns. Store hay, grain, squash and roots for **summer** as
well as winter *(rule of thumb)*.

**Toxic plants:** rhododendron, nightshades, **[foxglove](wiki:Digitalis_purpurea), [Scotch broom](wiki:Cytisus_scoparius)**, [poison oak](wiki:Toxicodendron_diversilobum), tansy, [black locust](wiki:Robinia_pseudoacacia),
false hellebore, snowberry, clematis ([WSNWCB, p. 55](lib:wsnwcb-protect-your-horses-and-livestock-from-toxic-plants#page=55)).
**Penned birds are at more risk** — they eat what they're given ([p. 54](lib:wsnwcb-protect-your-horses-and-livestock-from-toxic-plants#page=54)).
Also never feed moldy feed, avocado, raw dried beans, green or sprouted potatoes, or rhubarb leaves
*(rule of thumb)*.

**Water:** a doe and her 8-week litter of seven drink about **a gallon a day** in summer
([FB 1730, p. 12](lib:rabbit-production-usda-farmers-bulletin-1730#page=12)). Fresh water for chickens
every day ([FB 1508, p. 28](lib:poultry-keeping-in-back-yards#page=28); [🖼️ homemade waterers](lib:raising-healthy-poultry-cvm#page=18)). A hen drinks about a pint a day,
double in heat, and a day without water can stop laying for weeks *(rule of thumb)*.

📚 **Go deeper:** [USDA AIB 358, p. 12](lib:selecting-and-raising-rabbits#page=12) — rabbit feeds without pellets; [FAO, p. 17](lib:small-scale-poultry-production-technical-guide#page=17) — scavenging flocks and home-grown feed; [USDA FB 1841, p. 23](lib:the-feeding-of-chickens#page=23) — home-grown grain and milk rations.

## 🐣 Breeding rabbits and kindling

| Step | When | Source |
|---|---|---|
| First breeding | Small breeds **4–6 months**, medium **7–9**, large **9–11** | [EC 1655, p. 1](lib:raising-rabbits-for-meat-providing-basic-care#page=1) |
| Mating | **Always take the doe to the buck's hutch** | same |
| Gestation | 28–35 days, **31 on average** | [EC 1655, p. 2](lib:raising-rabbits-for-meat-providing-basic-care#page=2) |
| Nest box in | **Day 27** after mating | [AIB 358, p. 16](lib:selecting-and-raising-rabbits#page=16); [🖼️ nest-box plans](lib:rabbit-production-usda-farmers-bulletin-1730#page=42) |
| Weaning | Leave young with the doe **until 8 weeks** | [AIB 358, p. 18](lib:selecting-and-raising-rabbits#page=18) |
| Litters a year | **Four** possible if none fail | [FB 1730, p. 19](lib:rabbit-production-usda-farmers-bulletin-1730#page=19) |

**Kindling:**
1. Write the mating date on the hutch. Put in the **nest box with clean straw on day 27**. Without one,
   kits born on the wire can die ([EC 1655, p. 2](lib:raising-rabbits-for-meat-providing-basic-care#page=2)).
2. A day or two before kindling **the doe pulls fur** to line the nest — normal ([AIB 358, p. 16](lib:selecting-and-raising-rabbits#page=16);
   [🖼️ litter in a fur-lined nest](lib:selecting-and-raising-rabbits#page=17)).
3. Next day, while the doe is busy eating, check the nest quietly and remove any dead kits *(rule of thumb)*.
4. **Time it for our climate:** breed so litters come in **spring and fall**, not July–August.

**If this goes wrong** *(rule of thumb)*: doe won't take the buck → try again in a few days or another
buck. Kits cold on the wire → warm them in your hands and return them to the nest. Born outside the
box → move kits and fur into it.

📚 **Go deeper:** [OSU EC 1655, p. 2](lib:raising-rabbits-for-meat-providing-basic-care#page=2) — palpating, nest boxes, newborn kits; [USDA FB 1730, p. 18](lib:rabbit-production-usda-farmers-bulletin-1730#page=18) — gestation and kindling.

## 🐤 Hatching and raising chicks

**With a broody hen** — the dependable way without power ([USDA FB 1363](lib:natural-and-artificial-incubation#page=9)):
1. **[Broody](wiki:Broodiness)** hens cluck and ruffle up when approached. After she has stayed on the nest
   2–3 days, **move her at night** to a quiet nest with dummy eggs ([p. 9](lib:natural-and-artificial-incubation#page=9)).
2. Set **10–13 eggs in cold weather, 13–15 in warm** ([p. 3](lib:natural-and-artificial-incubation#page=3)).
   Use **fresh** eggs — quality drops after 5 days, and 3-week-old eggs rarely hatch ([p. 5](lib:natural-and-artificial-incubation#page=5)).
3. **[Candle](wiki:Candling)** on **day 7 and day 14** (hold each egg to a bright light in the dark) and
   remove clear ones ([p. 18](lib:natural-and-artificial-incubation#page=18); [🖼️ the air cell on days 7, 14 and 18](lib:incubation-and-brooding-of-chickens#page=13);
   [🖼️ candling](lib:incubation-and-brooding-of-chickens#page=14)).
4. Chicks start **pipping the evening of day 19** and are out by **day 21**
   ([FB 1538, p. 11](lib:incubation-and-brooding-of-chickens#page=11)). **Don't help them out** — those
   that can't hatch alone rarely thrive ([p. 15](lib:incubation-and-brooding-of-chickens#page=15)).

**Incubators** (only if you have steady power) ([FB 1538, pp. 11, 16](lib:incubation-and-brooding-of-chickens#page=16)):
fan type **99.5–100 °F, about 57% humidity**, eggs turned 5–6 times a day; still-air about **102 °F** at
egg height. Turn at least twice a day from day 2 to day 18 ([FB 1363, p. 3](lib:natural-and-artificial-incubation#page=3)).
Homemade: a [foam cooler](lib:make-your-own-incubator#page=2) ([🖼️ photos](lib:make-your-own-incubator#page=1)) with a 40-watt bulb and thermostat at 99–100 °F,
or a [double cardboard box](lib:incubator-from-cardboard-boxes#page=1) with the bulb in a chimney touching
nothing (**fire risk**) — plan on hatching **no more than half** the eggs.

**Brooding:**
- **With the hen:** shut hen and chicks in a brood coop ([🖼️ drawing](lib:incubation-and-brooding-of-chickens#page=18)) at night (rats, cats). **Move the coop weekly to
  fresh short grass** ([FB 1538, p. 18](lib:incubation-and-brooding-of-chickens#page=18)). Raise chicks on
  ground old birds **haven't used for a year** ([p. 17](lib:incubation-and-brooding-of-chickens#page=17)).
- **Without a hen:** start at **about 95 °F**. Chicks crowding to the heat are cold; panting with open
  mouths are too hot ([p. 22](lib:incubation-and-brooding-of-chickens#page=22); [🖼️ what each looks like](lib:raising-healthy-poultry-cvm#page=29)). Wire across corners
  stops piling and smothering.

📚 **Go deeper:** [USDA FB 1363](lib:natural-and-artificial-incubation#page=3) — setting hens and choosing eggs; [USDA FB 1538, p. 11](lib:incubation-and-brooding-of-chickens#page=11) — incubation and brooding; [Wikipedia: egg incubation](wiki:Egg_incubation) — pictures of embryo development.

## 🥚 Eggs: how many, which hens, storing

**On little bought feed, expect far fewer eggs** ([FAO, p. 9](lib:small-scale-poultry-production-technical-guide#page=9)):

| How the hens live | Eggs per hen per year |
|---|---|
| Scavenging only | **20–30** |
| Scavenging + shelter and disease control | 40–60 |
| Some feed | about 100 |
| Fully fed | 160–220 |

So **two eggs a day (730 a year) takes 7–8 part-fed hens, or 25+ scavengers** *(our arithmetic)*.

**Which hens to keep** ([USDA FB 1727](lib:selecting-hens-for-egg-production#page=5)): hens lay most in year one
and about 20% less in year two. **Eat early molters and non-layers in June–July; keep hens still laying
in August–September** for a second year and for breeding ([p. 5](lib:selecting-hens-for-egg-production#page=5)).
A non-layer has a **shrunken, dull, dry [comb](wiki:Comb_(anatomy))** ([p. 8](lib:selecting-hens-for-egg-production#page=8)),
pubic bones close together, only **two fingers** from the keel ([p. 9](lib:selecting-hens-for-egg-production#page=9);
[🖼️ layer vs. non-layer](lib:raising-healthy-poultry-cvm#page=36)),
and yellow returning to beak and shanks ([p. 10](lib:selecting-hens-for-egg-production#page=10)).

**Storing eggs:**
- Collect **at least once a day**. Wash only dirty eggs, in water **20 °F warmer than the egg**
  ([OSU EM 9350, p. 5](lib:oregon-guidelines-for-selling-eggs-osu-em9350#page=5)).
- Clean, **unwashed** eggs keep 2–3 weeks at cool room temperature, longer in a cold cellar *(rule of thumb)*.
- **Spring surplus:** **[water glass](wiki:Sodium_silicate) or limewater** crocks keep eggs **6–9 months**
  ([USDA 1935, p. 3](lib:home-methods-of-preserving-eggs-water-glass-and-lime-usda-1935#page=3);
  [FB 1508, p. 32](lib:poultry-keeping-in-back-yards#page=32)).

📚 **Go deeper:** [USDA FB 1727](lib:selecting-hens-for-egg-production#page=8) — telling layers from loafers, with pictures; [USDA *Home Methods of Preserving Eggs*](lib:home-methods-of-preserving-eggs-water-glass-and-lime-usda-1935#page=3) — water glass and lime; [Root Cellar guide](guide:ROOT-CELLAR-GUIDE) — storing eggs cool.

## 🌡️ Heat, smoke and fire season

**Rabbits** ([USDA FB 1730, p. 31](lib:rabbit-production-usda-farmers-bulletin-1730#page=31)):
- Newborn litters and does late in pregnancy suffer most.
- **Signs:** fast breathing, wet mouth, slight bleeding from the nostrils.
- **Do:** shade and airflow ([🖼️ a cooling basket for young rabbits](lib:rabbit-production-usda-farmers-bulletin-1730#page=32)). **Wetting hutch tops and floors cools the hutch 6–10 °F.** Lay a sick rabbit
  on a feed sack soaked in cold water.

**Chickens** ([FAO, p. 27](lib:small-scale-poultry-production-technical-guide#page=27)): they have no sweat
glands and cool by panting. **Severe stress above 104 °F (40 °C); 115 °F (46 °C) kills most.** They eat
less, drink more and lay smaller eggs. Give **shade**, airflow and cool water; **white paint reflects up to
70%** of the sun's heat on a roof. Heat-stressed birds peck each other.

**Wildfire smoke** ([PNW 783, p. 10](lib:wildfires-smoke-and-livestock-pnw783#page=10)): watch for coughing,
open-mouth breathing, watery eyes, weakness. **Keep water clean and fresh, cool them, mist down dust, and
put off stressful jobs** (weaning, moving). Evacuation plan: [Illinois Valley page](guide:ILLINOIS-VALLEY-START-HERE).

📚 **Go deeper:** [USDA FB 1730, p. 31](lib:rabbit-production-usda-farmers-bulletin-1730#page=31) — rabbits in hot weather; [FAO, p. 27](lib:small-scale-poultry-production-technical-guide#page=27) — heat and housing; [PNW 783, p. 8](lib:wildfires-smoke-and-livestock-pnw783#page=8) — evacuating or sheltering stock.

## 🩺 Common diseases with no vet

**Rabbits:**
- **Quarantine new rabbits a month**, downwind, and do their chores last
  ([OSU EC 1654, p. 1](lib:raising-rabbits-for-meat-managing-animals-health#page=1)).
- **Watch for:** runny nose and **matted front paws** ([snuffles](wiki:Pasteurella_multocida);
  [🖼️ photo](lib:raising-rabbits-for-meat-managing-animals-health#page=1)), crusty ears (ear mites), diarrhea, sores.
- The common killers — **coccidiosis, pneumonia and enteritis** — come mostly from **poor sanitation**
  ([R-41, p. 52](lib:backyard-and-commercial-rabbit-production#page=52)). Keep floors dry, clear droppings,
  keep droppings out of feed and water ([p. 57](lib:backyard-and-commercial-rabbit-production#page=57)).
- **Bloat or diarrhea with no fever:** more hay and roughage; beware fermented or spoiled feed (p. 57).
- **Snuffles: cull** ([p. 56](lib:backyard-and-commercial-rabbit-production#page=56)) — it spreads.
- **At butchering:** white spots on an enlarged liver = liver coccidiosis (p. 56). Throw that liver away.

**Chickens:**
- **[Coccidiosis](wiki:Coccidiosis):** bloody droppings, droopy young birds; at death the two blind guts
  (ceca) are swollen with blood ([FB 1652, pp. 52–53](lib:diseases-and-parasites-of-poultry#page=53); [🖼️ life cycle](lib:raising-healthy-poultry-cvm#page=60)).
  If you stocked **amprolium**, it treats it; chicks kept off their droppings (wire or slat floors, fresh
  ground) get less ([Where There Is No Animal Doctor, p. 317](lib:where-there-is-no-animal-doctor-cvm-2024#page=317)).
- **[Marek's disease](wiki:Marek's_disease)** (paralysis; [🖼️ swollen nerves](lib:diseases-and-parasites-of-poultry#page=28)) strikes at **12–25 weeks** ([UF PS044, p. 7](lib:common-poultry-diseases-uf-ps044#page=7)).
  No cure — cull, and hatch from survivors' lines *(rule of thumb)*.
- **Lice and [mites](wiki:Dermanyssus_gallinae):** ruffled feathers, scabs, fewer eggs ([Practical Poultry Raising, p. 132](lib:practical-poultry-raising-peace-corps#page=132);
  [🖼️ louse](lib:diseases-and-parasites-of-poultry#page=82), [🖼️ mite](lib:diseases-and-parasites-of-poultry#page=86)).
  Give a **[dust bath](wiki:Dust_bathing) of fine dry soil and wood ash**, keep nests clean with fresh straw *(rule of thumb)*.
- **Burn or deeply bury** birds that die of disease ([FB 1652, p. 13](lib:diseases-and-parasites-of-poultry#page=13)).
- **Gloves and eye protection** with lye or lime disinfectants ([FB 1538, p. 17](lib:incubation-and-brooding-of-chickens#page=17)).

📚 **Go deeper:** [*Where There Is No Animal Doctor*, p. 312](lib:where-there-is-no-animal-doctor-cvm-2024#page=312) — poultry diseases with no vet; [*Raising Healthy Rabbits*](lib:raising-healthy-rabbits-cvm) and [*Raising Healthy Poultry*](lib:raising-healthy-poultry-cvm) — illustrated care; [USDA FB 1652](lib:diseases-and-parasites-of-poultry#page=13) — disease signs (ignore its drugs).

## 🔪 Humane slaughter and butchering

**Killing** — practice on a carcass first; the AVMA says neck dislocation is humane **only when done by
trained people** on small animals ([AVMA, p. 44](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=44)):
- **Rabbit:** hold the hind legs, thumb just behind the ears, fingers under the chin; stretch and raise the
  head sharply ([🖼️ how to hold it](lib:rabbit-production-usda-farmers-bulletin-1730#page=53)). Or a **heavy blow at the base of the skull** ([FB 1730, p. 52](lib:rabbit-production-usda-farmers-bulletin-1730#page=52)).
- **Chicken:** hang it head-down in a **killing cone** and cut the side of the neck
  ([Kansas State EP71, p. 1](lib:processing-farm-raised-poultry#page=1)).

**Chickens** ([EP71, p. 1](lib:processing-farm-raised-poultry#page=1); [UMN EB 385](lib:home-processing-of-poultry#page=3)):
1. **No feed for 8–10 hours** before.
2. **Scald at 140 °F for 30–40 seconds**, dunking up and down; a little detergent helps. **Pluck at once.**
3. Gut ([🖼️ step by step](lib:home-processing-of-poultry#page=5)), then **chill in ice water to 40 °F** ([UMN, p. 6](lib:home-processing-of-poultry#page=6)); keep
   unfrozen under 4 days ([EP71, p. 2](lib:processing-farm-raised-poultry#page=2)).
- **Don't eat** a bird with lumps or spots on the liver, fluid in the body, or orange fat on a thin carcass.
- Pinfeathery birds: wait a week or two ([UMN, p. 1](lib:home-processing-of-poultry#page=1)). Allow **1–2
  gallons of water per bird** ([OSU EM 9273, p. 2](lib:open-air-poultry-slaughter-best-practices-osu-em9273#page=2)).

**Rabbits** ([FB 1730, pp. 52–55](lib:rabbit-production-usda-farmers-bulletin-1730#page=52)):
1. No feed the day before ([R-41, p. 77](lib:backyard-and-commercial-rabbit-production#page=77)).
2. Hang by a hook through the **hock tendon of one hind leg**; **cut off the head at once** to bleed.
3. Remove tail, free hind foot and front feet, then **peel the skin off like a sock**
   ([🖼️ steps](lib:rabbit-production-usda-farmers-bulletin-1730#page=54)).
4. Gut. **Heart, kidneys and liver are good food.** Stretch the pelt on a wire frame to dry ([🖼️ pelt on a stretcher](lib:rabbit-production-usda-farmers-bulletin-1730#page=55)); tan with
   **salt-alum** ([FB 1334, p. 27](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=27)).
- **Yield:** a 4–4½ lb fryer at 8 weeks dresses to **50–59%** of live weight, **78–80%** of that edible
  ([p. 47](lib:rabbit-production-usda-farmers-bulletin-1730#page=47)).

**Keeping the meat:** pressure-can it (soak dressed rabbit 1 hour in salted water first)
([USDA canning guide 5, p. 5](lib:usda-complete-guide-to-home-canning-2015-guide-5#page=5)), or dry thin
strips ([CVM, p. 90](lib:slaughter-and-preservation-of-meat-cvm#page=90)) — 16 oz raw makes about 4 oz
jerky ([PNW 632, p. 7](lib:pnw632-making-jerky-at-home-safely#page=7)).

📚 **Go deeper:** [UMN *Home Processing of Poultry*](lib:home-processing-of-poultry#page=2) — illustrated plucking and gutting; [USDA FB 1730, p. 52](lib:rabbit-production-usda-farmers-bulletin-1730#page=52) — slaughter and skinning with drawings; [UF *Humane Euthanasia*](lib:humane-euthanasia-of-sick-and-injured-livestock-uf-vm114) — putting down a sick animal.

## 🌱 Manure for the garden

- **Rabbit manure** has about **2% nitrogen** — more than most farm manures — and **won't burn plants**:
  dig it straight in ([USDA *Rabbit Manure*, pp. 4–5](lib:value-and-use-of-rabbit-manure#page=4)).
  A doe and her litters make about **6 cubic feet a year** (9 with bedding); a buck about 3. **Raise
  earthworms in the pile under the hutches** ([vermicomposting](wiki:Vermicompost)) — they cut odor and flies ([p. 6](lib:value-and-use-of-rabbit-manure#page=6)).
- **Chicken manure: compost it at least 120 days** ([🖼️ compost bins](lib:composting-and-using-backyard-poultry-waste#page=2)) before use, and never put it raw on seedlings or
  growing plants. Spread raw litter **in fall, after harvest**, so winter rains leach out the salts
  ([Idaho CIS 1194, pp. 2, 6](lib:composting-and-using-backyard-poultry-waste#page=2)) — our wet winters suit this.

📚 **Go deeper:** [USDA *Value and Use of Rabbit Manure*, p. 6](lib:value-and-use-of-rabbit-manure#page=6) — composting and worm beds; [Idaho CIS 1194](lib:composting-and-using-backyard-poultry-waste#page=2) — the 120-day rule and spreading rates.

## 🧬 Keeping the lines going for years

**How many feed a family** *(our arithmetic from the sources)*:
- A doe at full production raises about **28 fryers a year** — roughly **60 lb of carcass, 48 lb of
  meat** ([FB 1730, pp. 19, 47](lib:rabbit-production-usda-farmers-bulletin-1730#page=47)). Each pound of
  fryer takes 3½–4½ lb of feed. **Rabbit twice a week for four people ≈ 100 fryers ≈ 4 does + 1 buck;
  keep 6 does and 2 bucks** to cover losses and smaller litters on home feed.
- FAO's village flock: **15 hens laying 30 eggs each** = 450 eggs, some set under broodies
  ([FAO, p. 36](lib:small-scale-poultry-production-technical-guide#page=36)). About half of each hatch is
  cockerels — **eat them at 12–20 weeks** before they compete for feed *(rule of thumb)*.

**Avoid inbreeding:**
- Inbreeding isn't harmful in itself, but it **quickly brings out hidden defects**; beginners usually
  inbreed just to avoid getting a new buck ([FB 1730, p. 20](lib:rabbit-production-usda-farmers-bulletin-1730#page=20)).
  Keep **at least two unrelated bucks** and **trade bucks with neighbors** every few generations *(rule of thumb)*.
- **Roosters:** one per **12–15 Leghorn-type hens**, **10–12 Rock or Wyandotte**, **10 or fewer** of the
  heaviest; with 20–30 hens keep two and alternate them ([FB 1508, p. 10](lib:poultry-keeping-in-back-yards#page=10)).
  FAO replaces the cock with a **new cockerel every year** ([p. 36](lib:small-scale-poultry-production-technical-guide#page=36)).
  Trade for an unrelated rooster every 2–3 years, or keep 2–3 hen families and rotate roosters *(rule of thumb)*.
- **Keep records** of matings and litter sizes ([🖼️ a hutch card](lib:selecting-and-raising-rabbits#page=20)); breed from the best mothers.

**Don't live on rabbit.** It is high in protein but **low in fat** ([EC 1651, p. 1](lib:raising-rabbits-for-meat-getting-started#page=1)).
People who live mainly on lean meat get **"[rabbit starvation](wiki:Protein_toxicity)"** within 1–2 weeks —
nausea, diarrhea, weakness and a craving for fat that more lean meat won't fix. Keep protein under about a
third of calories and pair rabbit with fat (egg yolks, chicken fat, lard, nuts) and starch *(rule of thumb)*.

📚 **Go deeper:** [USDA FB 1730, p. 20](lib:rabbit-production-usda-farmers-bulletin-1730#page=20) — inbreeding and selection; [FAO, p. 36](lib:small-scale-poultry-production-technical-guide#page=36) — a self-renewing village flock; [Food Security guide](guide:FOOD-SECURITY-GUIDE) — fitting meat and eggs into a ration.

## ⚠️ Old advice in the library to ignore

- **Sodium fluoride dusted on setting hens for lice** — [FB 1363, p. 9](lib:natural-and-artificial-incubation#page=9).
  It is poisonous. **Instead:** a dust bath of dry soil and wood ash, clean straw in the nest.
- **Poisons as wormers and mite killers** in [FB 1652](lib:diseases-and-parasites-of-poultry#page=7):
  carbon tetrachloride ([p. 63](lib:diseases-and-parasites-of-poultry#page=63), [p. 77](lib:diseases-and-parasites-of-poultry#page=77)),
  nicotine sulfate ([p. 78](lib:diseases-and-parasites-of-poultry#page=78)), DDT ([p. 49](lib:diseases-and-parasites-of-poultry#page=49)),
  phenothiazine ([p. 79](lib:diseases-and-parasites-of-poultry#page=79)), kerosene emulsion and carbolineum
  ([p. 7](lib:diseases-and-parasites-of-poultry#page=7)). **Instead:** use the bulletin for signs and
  prevention only; rotate ground, keep litter dry, cull. Also **nicotine sulfate painted on roosts** in
  [Practical Poultry Raising, p. 132](lib:practical-poultry-raising-peace-corps#page=132) — don't.
- **Lindane for rabbit ear mites** — [Peace Corps *Livestock Manual* Vol 4, p. 341](lib:peace-corps-livestock-training-manual-vol-4-1982#page=341).
  Banned and nerve-toxic.
- **"Salt-acid" tanning with concentrated sulfuric acid** — [FB 1730, p. 60](lib:rabbit-production-usda-farmers-bulletin-1730#page=60).
  **Instead:** salt-alum ([p. 61](lib:rabbit-production-usda-farmers-bulletin-1730#page=61); [FB 1334, p. 27](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=27)).
- **Formalin** for tanning and preserving paws in [R-41, pp. 81, 83](lib:backyard-and-commercial-rabbit-production#page=81) —
  toxic; use salt-alum. **Ipil-ipil (leucaena) as feed** ([p. 37](lib:backyard-and-commercial-rabbit-production#page=37)) —
  toxic in quantity (not grown here anyway). Many drugs R-41 names won't be available.
- **Cresol disinfectant** — [FB 1508, p. 31](lib:poultry-keeping-in-back-yards#page=31). Toxic.
  **Instead:** scrub, sun and dry; lime with gloves and goggles.
- **"Don't mix your own rabbit feed"** ([OSU EC 1655, p. 1](lib:raising-rabbits-for-meat-providing-basic-care#page=1))
  is right while pellets exist. After that, home-grown feed is the only choice — expect slower growth and
  smaller litters, not failure.

📚 **Go deeper:** [*Where There Is No Animal Doctor*](lib:where-there-is-no-animal-doctor-cvm-2024#page=312) — modern no-vet care; [USDA FB 1334, p. 27](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=27) — safe salt-alum tanning.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Breeds**
- Meat rabbits — [🖼️ AIB 358, p. 6](lib:selecting-and-raising-rabbits#page=6); [🖼️ OSU EC 1651, p. 1](lib:raising-rabbits-for-meat-getting-started#page=1); [New Zealand rabbit](wiki:New_Zealand_rabbit); [Californian rabbit](wiki:Californian_rabbit)
- Dual-purpose hens — [🖼️ FB 1508, p. 8](lib:poultry-keeping-in-back-yards#page=8); [Plymouth Rock](wiki:Plymouth_Rock_chicken); [Rhode Island Red](wiki:Rhode_Island_Red); [Wyandotte](wiki:Wyandotte_chicken); [Orpington](wiki:Orpington_chicken); [Australorp](wiki:Australorp)
- Egg breeds and meat breeds — [🖼️ FB 1508, p. 5](lib:poultry-keeping-in-back-yards#page=5); [Leghorn](wiki:Leghorn_chicken); [Brahma](wiki:Brahma_chicken); [Cochin](wiki:Cochin_chicken)

**Hutches, coops and predators**
- Rabbit hutches — [🖼️ AIB 358, p. 10](lib:selecting-and-raising-rabbits#page=10); [🖼️ FB 1730, pp. 38–39](lib:rabbit-production-usda-farmers-bulletin-1730#page=38); [🖼️ Peace Corps R-41, p. 23](lib:backyard-and-commercial-rabbit-production#page=23); [Hutch](wiki:Hutch_(animal_cage))
- Wire cage with nest box — [🖼️ OSU EC 1654, p. 2](lib:raising-rabbits-for-meat-managing-animals-health#page=2)
- Coop and roosts — [🖼️ OSU EC 1644, p. 1](lib:osu-backyard-chicken-coop-design-ec-1644#page=1); [🖼️ p. 2](lib:osu-backyard-chicken-coop-design-ec-1644#page=2); [🖼️ simple houses, Raising Healthy Poultry p. 16](lib:raising-healthy-poultry-cvm#page=16); [Chicken tractor](wiki:Chicken_tractor)
- Nests for hens — [🖼️ Raising Healthy Poultry, p. 35](lib:raising-healthy-poultry-cvm#page=35)
- Predators and predator-proofing — [🖼️ Kentucky ID-245, p. 5](lib:predator-management-for-small-scale-poultry#page=5); [🖼️ p. 6](lib:predator-management-for-small-scale-poultry#page=6); [Raccoon](wiki:Raccoon); [Bobcat](wiki:Bobcat); [Least weasel](wiki:Least_weasel)
- Electric fence against bears — [🖼️ UF bear fence, p. 3](lib:building-bear-fences#page=3); [🖼️ p. 5](lib:building-bear-fences#page=5)

**Feeding and water**
- Homemade waterers and feeders — [🖼️ Raising Healthy Poultry, p. 18](lib:raising-healthy-poultry-cvm#page=18); [🖼️ p. 20](lib:raising-healthy-poultry-cvm#page=20)
- Hopper made from a 5-gallon can — [🖼️ FB 1730, p. 46](lib:rabbit-production-usda-farmers-bulletin-1730#page=46)
- Toxic plants — [Foxglove](wiki:Digitalis_purpurea); [Scotch broom](wiki:Cytisus_scoparius); [Poison oak](wiki:Toxicodendron_diversilobum)
- Soldier-fly larvae — [Black soldier fly](wiki:Hermetia_illucens)

**Breeding, hatching and eggs**
- Palpating a doe and newborn kits — [🖼️ OSU EC 1655, p. 2](lib:raising-rabbits-for-meat-providing-basic-care#page=2)
- Nest box plans — [🖼️ FB 1730, p. 42](lib:rabbit-production-usda-farmers-bulletin-1730#page=42); [🖼️ R-41, p. 33](lib:backyard-and-commercial-rabbit-production#page=33)
- Candling and the air cell — [🖼️ FB 1538, p. 13](lib:incubation-and-brooding-of-chickens#page=13); [🖼️ p. 14](lib:incubation-and-brooding-of-chickens#page=14); [🖼️ homemade candler, Raising Healthy Poultry p. 26](lib:raising-healthy-poultry-cvm#page=26); [Candling](wiki:Candling)
- Brood coop and brooder chicks — [🖼️ FB 1538, p. 18](lib:incubation-and-brooding-of-chickens#page=18); [🖼️ Raising Healthy Poultry, p. 29](lib:raising-healthy-poultry-cvm#page=29); [Broodiness](wiki:Broodiness)
- Layer or loafer — [🖼️ FB 1727, p. 8](lib:selecting-hens-for-egg-production#page=8); [🖼️ p. 9](lib:selecting-hens-for-egg-production#page=9); [🖼️ Raising Healthy Poultry, p. 36](lib:raising-healthy-poultry-cvm#page=36)

**Disease signs**
- Snuffles — [🖼️ OSU EC 1654, p. 1](lib:raising-rabbits-for-meat-managing-animals-health#page=1); [🖼️ healthy vs. sick rabbit, R-41 p. 53](lib:backyard-and-commercial-rabbit-production#page=53)
- Coccidiosis in chicks — [🖼️ FB 1652, p. 53](lib:diseases-and-parasites-of-poultry#page=53); [🖼️ Raising Healthy Poultry, p. 60](lib:raising-healthy-poultry-cvm#page=60); [Coccidiosis](wiki:Coccidiosis)
- Marek's paralysis — [🖼️ FB 1652, p. 28](lib:diseases-and-parasites-of-poultry#page=28); [Marek's disease](wiki:Marek's_disease)
- Lice and mites — [🖼️ FB 1652, p. 82](lib:diseases-and-parasites-of-poultry#page=82); [🖼️ p. 86](lib:diseases-and-parasites-of-poultry#page=86); [Dermanyssus gallinae](wiki:Dermanyssus_gallinae)
- Chicken anatomy (for checking a carcass) — [🖼️ Raising Healthy Poultry, p. 64](lib:raising-healthy-poultry-cvm#page=64)

**Slaughter and pelts**
- Holding a rabbit for slaughter — [🖼️ FB 1730, p. 53](lib:rabbit-production-usda-farmers-bulletin-1730#page=53)
- Skinning and gutting a rabbit — [🖼️ FB 1730, p. 54](lib:rabbit-production-usda-farmers-bulletin-1730#page=54); [🖼️ R-41, p. 78](lib:backyard-and-commercial-rabbit-production#page=78)
- Pelt on a stretcher — [🖼️ FB 1730, p. 55](lib:rabbit-production-usda-farmers-bulletin-1730#page=55)
- Plucking tools and gutting a chicken — [🖼️ UMN EB 385, p. 2](lib:home-processing-of-poultry#page=2); [🖼️ p. 5](lib:home-processing-of-poultry#page=5)
- Composting poultry litter — [🖼️ Idaho CIS 1194, p. 2](lib:composting-and-using-backyard-poultry-waste#page=2); [Vermicompost](wiki:Vermicompost)

## 🔗 Related guides

- [Food Security guide](guide:FOOD-SECURITY-GUIDE) — rations, fat needs and storing the feed grain
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — larger stock, hay, toxic plants, wildfire plans
- [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — rendering lard, jerky, grain for people and birds
- [Seed Bank guide](guide:SEED-BANK-GUIDE) — growing feed grain, roots and greens
- [Root Cellar guide](guide:ROOT-CELLAR-GUIDE) — storing roots and eggs, curing meat
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — animal vital signs, euthanasia, wildfire evacuation
