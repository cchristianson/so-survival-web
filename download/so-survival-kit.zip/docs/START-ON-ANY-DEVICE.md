# 📱💻 Start the Library on Any Device

This library works on almost anything: a Windows laptop, a Mac, a Linux computer or Raspberry Pi,
an Android tablet or phone, even an old computer. Nothing needs the internet, and nothing you
search for ever leaves your device.

There are **two ways** to use it:

1. **Just open the files.** Open **`START-HERE.html`** in any web browser. Every guide and book on
   the drive opens like a web page or PDF. Works on every device, no setup at all.
2. **The Library Assistant (recommended).** One search box for *everything* on the drive (every
   book, guide and encyclopedia) plus an **offline AI** that writes a short answer from what it
   finds, with numbered links to the exact pages. It runs on the device itself.

> ### ⚠️ Please remember
> - The AI can be wrong. **Always check the sources it links to**, especially for medicine,
>   electricity, chemicals or food safety.
> - Keep the window (or the Termux app) open while you use the assistant. Closing it stops it.
> - Nothing is sent anywhere. You can turn off Wi-Fi and it works the same.

---

## 🚀 Pick your device

| Your device | What to do | What you get |
|---|---|---|
| **Windows** laptop, desktop or Surface tablet | Double-click **`START-Windows.bat`** | Everything |
| **Mac** | Double-click **`START-Mac.command`** | Everything |
| **Linux** PC, **Raspberry Pi 4/5** (64-bit), or a **Chromebook** with Linux turned on | Run **`START-Linux.sh`** | Everything |
| **Android** tablet or phone | Set up once with the free **Termux** app (below), then type `library` | Everything (AI size depends on the device) |
| **iPhone / iPad** | Open a library **shared over Wi-Fi** from another device, or load the iPhone itself (below) | Everything when shared; reading and search on its own |
| **Any other phone, tablet or laptop with a web browser** | Open a library **shared over Wi-Fi** from another device | Everything, with the AI running on the sharing device |
| **Very old computer** (Windows 7, 32-bit) | Open **`START-HERE.html`** in a browser, or use a shared library | Guides and books |

All the start files are at the **top of the drive**, next to `START-HERE.html`.

---

## 🪟 Windows

1. Plug in the drive and open it.
2. Double-click **`START-Windows.bat`**.
3. If a blue **"Windows protected your PC"** box appears, click **More info**, then **Run anyway**.
4. A black window opens and then your web browser. Ask your question in the box.
5. When you're done, close the black window.

## 🍎 Mac

1. Plug in the drive and open it in Finder.
2. **The first time:** right-click (or Control-click) **`START-Mac.command`**, choose **Open**,
   then click **Open** again. After that, a normal double-click works.
3. A Terminal window opens and then your web browser. Keep Terminal open while you use it.

## 🐧 Linux, Raspberry Pi, Chromebook

1. Open the drive in the file manager.
2. Right-click **`START-Linux.sh`** → **Run as a Program** (or **Run in Terminal**).
   If it only opens as text, open a terminal in the drive's folder and type `bash START-Linux.sh`.
3. Your web browser opens. If it doesn't, type the address shown in the window
   (it looks like `http://127.0.0.1:8095/`) into the browser.

- **Raspberry Pi:** needs the 64-bit system and works best on a Pi 5 with 8 GB of memory.
- **Chromebook:** first turn on Linux (open Settings and search for **Linux**), then right-click
  the drive in the Files app and choose **Share with Linux**.

## 🤖 Android tablet or phone

This takes about 10 minutes **once**. After that it's one word.

**Before you start:** copy the library folder onto the tablet's **SD card** (or onto the tablet
itself if it has room). A computer with a card reader, or a USB cable, is the easiest way.

1. **Install Termux.** On the drive, open `Phone-Apps\Android-Termux\` and copy **`Termux-….apk`**
   to the tablet. Tap it to install. If Android asks, allow installing apps from this source.
2. **Copy one small file.** Copy **`START-Android.sh`** (top of the drive) into the tablet's
   **Download** folder.
3. **Open Termux** (a black screen with a text cursor) and type, then press Enter:

   `termux-setup-storage`

   Tap **Allow** when Android asks.
4. Type this exactly, then press Enter:

   `bash /sdcard/Download/START-Android.sh`

   It finds the library, installs the AI and the Wikipedia search from the drive (no internet
   needed), and opens the library in your browser.
5. **Every time after that:** open Termux, type `library`, press Enter.

- Keep Termux open while you use the library. To stop it, close Termux.
- **Tip:** in the browser, choose **⋮ → Add to Home screen** so the library has its own icon.
- Phones and tablets with **4 GB of memory or more** get a written-answer AI (the Quick one on most
  tablets). Smaller ones still get the full search with the AI turned off, which is fast and works well.

## 🍏 iPhone and iPad

Apple doesn't let iPhones run programs like the Library Assistant, so an iPhone uses the library
in one of two ways — and old iPhones work fine for both (iPhone 6s or newer).

**1. Use a library shared from another device (everything, including the AI).** Any laptop, Android
tablet or Raspberry Pi running the library can share it over Wi-Fi — see
[Share one library with every phone nearby](#share-one-library-with-every-phone-nearby) below. The
iPhone just opens a web address in Safari. Search, the AI, every book and Wikipedia all work,
because the work happens on the sharing device.

**2. Load the iPhone itself, for when it's on its own.** Do this **now, while you have internet** —
the App Store won't work later.

1. **Update** the iPhone as far as it will go (Settings → General → Software Update).
2. **Install these free apps** from the App Store:
   - **Kiwix** — offline Wikipedia, the medical encyclopedia and the survival archives.
   - **OsmAnd** — offline maps.
   - *Optional:* **PocketPal AI** — an offline AI chat that can load the library's small AI
     (`AI-Offline/models/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf`). It chats, but doesn't search the
     books. Works best on newer iPhones; skip it if it won't install.
3. **Save the library website for offline use:** open it in Safari, tap **⚙️ Offline → Save library
   & guides** (and the walking routes), then **Share → Add to Home Screen**. That gives the search,
   every guide and the walking routes with no internet. Open it from the home screen now and then
   so the iPhone keeps it.
4. **Copy files onto the iPhone** — from a Mac (Finder → your iPhone → Files tab) or a Windows PC
   (Apple Devices app → File Sharing), or plug the library drive straight into the iPhone with a
   USB adapter and copy in the **Files** app:
   - `.zim` files you have room for → **Kiwix** (the medical and survival ones are small)
   - maps from `OsmAnd\` → **OsmAnd** (tap a `.zip` in Files to unzip it first)
   - the PDF books you want (e.g. the whole `Southern-Oregon` folder, about 7 GB) → **Files**
5. **Or keep a small USB stick with the iPhone.** With a USB adapter (newer iPhones take USB-C
   directly) the **Files** app opens every book on the stick, no copying needed.

---

## 📡 Share one library with every phone nearby

One device runs the library and **every phone, tablet and laptop in range uses it in its web
browser** — iPhones, old Android phones, Chromebooks, anything with a browser. No internet is
involved, and the AI runs on the sharing device, so even a very old phone gets written answers.
This is the easiest way to serve a whole household, or a whole street, from one laptop or tablet.

**On the device with the library** (laptop, Android tablet or Raspberry Pi):

1. Start the library as usual.
2. Open **⚙️ Settings → 📡 Share with phones nearby → Turn on sharing.**
3. If Windows or the Mac asks whether to allow network access, choose **Allow**.
4. Settings shows an address like **`http://192.168.43.1:8096`**. Write it down or tape it to the wall.

**On each phone or tablet:**

1. Connect to the **same Wi-Fi** as the sharing device.
2. Open the web browser and type the address exactly.
3. Tap **Share → Add to Home Screen** (iPhone) or **⋮ → Add to Home screen** (Android) so it gets an
   icon. Next time, just tap the icon while you're on that Wi-Fi.

**No Wi-Fi network?** You don't need the internet, just a local Wi-Fi network:

- **An Android phone's hotspot** works with mobile data turned off. Turn it on, connect the sharing
  device and the other phones to it.
- **A small travel Wi-Fi router** (powered from USB) is the most reliable: plug it in and everyone
  joins its network. Good to keep in the emergency kit.
- **A Raspberry Pi or Linux laptop** can make its own Wi-Fi network.
- iPhone hotspots usually need a working phone plan, so don't count on them.

**Good to know:**

- Anyone on that Wi-Fi can read the library, but **only the sharing device can change settings**
  or turn sharing off. Use a password on the hotspot or router.
- Search is instant for everyone. If several people ask the AI at once, it answers them one at a
  time.
- A laptop sharing all evening uses about as much power as a bright light bulb; keep it plugged in
  or on solar.
- To stop, tap **Stop sharing** in Settings, or close the library.

---

## 🗄️ Put old devices to work — set them up now

The best emergency computer is the one already in a drawer. While you still have internet:

| Old device | Can it run the library itself? | Set it up as |
|---|---|---|
| Windows laptop (Windows 10/11, 4 GB+) | Yes | A home library, or the household's **sharing hub** |
| Mac (about 2017 or newer) | Yes | Same |
| Chromebook | Yes, with Linux turned on | Same |
| Android tablet or phone (Android 7+), Amazon Fire tablet | Yes, with Termux (Fire tablets: usually) | A pocket library, or a hub that runs from a power bank |
| Raspberry Pi 4/5 (64-bit) | Yes | A low-power, always-on **sharing hub** |
| iPhone or iPad (6s or newer) | No | A **client** of a shared library, plus Kiwix, OsmAnd and the saved website |
| Any other phone or tablet with a web browser | No | A **client** of a shared library |

For every device: charge it, update it, install what it needs, copy the library onto it, and
**try it once** with Wi-Fi turned off. Store spares in a metal can (see the
[EMP guide](guide:EMP-GUIDE)) at about half charge, and top them up every few months.

---

## 🧠 Which AI will I get?

The assistant looks at your device's memory, picks an AI size, **times a test answer**, and steps
down if it's too slow. It remembers the choice for that device. You can change it any time in
the **⚙️ Settings** tab.

| Setting | Good for | How it answers |
|---|---|---|
| **Automatic** (recommended) | Any device | Picks the best one below for you |
| **Off — search only** | Anything, even very old or small devices | Instantly lists the matching pages; you read them yourself |
| **Quick** | Phones, tablets, older laptops (4 GB+ memory) | Short, simple answers in about 30–60 seconds |
| **Standard** | Most laptops and good tablets (8 GB+) | Good answers in about a minute |
| **Smart** | Computers with 16 GB+ | Better answers, about 3 times slower |
| **Graphics card** | Gaming-type computers (6 GB+ graphics card) | Fast, good answers |

The times are rough. **Search is always instant**: only the written answer takes time, and the
pages it found are shown right away while the AI works.

---

## 🔧 If something goes wrong

| What you see | What to do |
|---|---|
| Windows: "Windows protected your PC" | Click **More info** → **Run anyway** |
| Mac: "can't be opened because it is from an unidentified developer" | Right-click the file → **Open** → **Open** |
| Linux: the file opens as text | Open a terminal in the drive folder and type `bash START-Linux.sh` |
| The browser didn't open | Type the address shown in the window, e.g. `http://127.0.0.1:8095/` |
| "The AI stopped on this device" | Go to **⚙️ Settings** and pick a smaller AI, or **Off** |
| Answers take minutes | **⚙️ Settings → Quick**, or **Off** and read the sources yourself |
| Android: "Couldn't find the library" | Copy the *whole* library folder to the SD card or tablet, then run it again |
| Android: Termux closes or the page stops | Keep Termux open; don't swipe it away while you use the library |
| Wikipedia isn't searched | That device is missing the Wikipedia search program; the books and guides are still searched |

---

## 🤝 Sharing it with your community

The more households that have this, the calmer things stay when the power and phones are out.

- **Copy it.** Copy the whole library folder onto another USB stick, drive or SD card. The copy
  works exactly like the original on every kind of device. No installing needed. Use a drive
  formatted **exFAT** so Windows, Macs, Linux and Android tablets can all open it (see
  [Get the whole library](guide:GET-THE-LIBRARY) for how to check and change it).
- **The Community kit (about 11 GB)** has all the guides, the Illinois Valley books, and the
  Library Assistant with a small AI for every kind of device. It fits on a **16 GB** or larger USB
  stick or SD card. Make one with `community-kit.bat` (Windows) or
  `./get-offline-library.sh --community` (Mac/Linux) while you still have internet.
- **Or let the installer fit the drive.** Download the installer kit from the website (*Offline*
  tab → *Get the whole library*), unzip it and double-click **INSTALL-Windows** (Mac: right-click
  **INSTALL-Mac** → Open). A page opens in your browser: pick the stick or drive, keep the ticks it
  suggests (they fit the free space) and press **Start**.
- **The full library (about 170 GB)** adds all of Wikipedia with pictures, maps of the US and the
  big AI models. It needs a **256 GB** or larger drive.
- **Hold a "library night."** Bring a laptop and a few blank USB sticks, copy the kit for
  neighbors, help them try it once on their own device, and print this page for each household.
- **Keep one copy safe** in a metal can as protection against an EMP or solar storm (see the
  [EMP guide](guide:EMP-GUIDE)), with a charger and a small solar panel.
- **Please don't sell it, and don't post the books online.** Everything here is free to share
  with family and neighbors, but some publishers ask that their free books not be re-posted.

---

## 🔗 Related guides

- [Start Here (Illinois Valley)](guide:ILLINOIS-VALLEY-START-HERE) — the one-page local quick reference
- [Use the Library on a Phone](guide:USE-ON-PHONE) — Kiwix and OsmAnd on phones and iPads
- [How to Run the Offline AI](guide:HOW-TO-RUN-OFFLINE-AI) — more about the AI models
- [EMP Guide](guide:EMP-GUIDE) — protecting a spare device and drive in a Faraday cage
- [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) — organizing your neighbors
