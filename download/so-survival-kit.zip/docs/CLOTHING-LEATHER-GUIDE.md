# 🧵 Clothing, Textiles, Leather & Shoes

How to keep a household clothed and shod for years with no stores: dressing for our cold-wet winters,
heavy mending, sewing machines, wool from sheep to yarn, linen, natural dyes, weaving, knitting, tanning,
and boots and moccasins. Simple stitches, darning, tire sandals and boot-grease recipes are in the
[Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE); this guide goes further. The books are in
`Clothing-Leather\` (`Sewing-Mending`, `Knitting-Hats-Gloves`, `Spinning-Weaving-Dyeing`, `Tanning-Hides`,
`Shoes-Boots`, `Cold-Weather-Clothing`), `Homestead-Skills\Household-Make-Do`,
`Homestead-Skills\Food-Crafts-Tools` and `Trapping\Hides-Tanning`.

> ### ⚠️ Rules that prevent the worst outcomes
> - **Wet, not cold, is what kills here.** Wear wool under a waterproof shell, no cotton in the winter
>   rain, and **change to dry socks at least twice a day** ([TC 21-3, p. 12](lib:tc-21-3-soldiers-handbook#page=12)).
> - **Fleece and nylon melt onto skin.** Wear wool or cotton at the stove, at the forge and near any fire
>   *(rule of thumb)*.
> - **Never use the old poisons** in tanning, fur and dye recipes: arsenic, mercury chloride, chrome,
>   sulfuric or oxalic acid, gasoline, burning sulfur. Brains, bark, salt, alum, soap and smoke are enough.
> - **Wear gloves** with brains (deer and elk can carry chronic wasting disease) and lime *(rule of thumb)*,
>   and never put cut or cracked hands in alum liquor ([USDA FB1334, p. 22](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=22)).
> - **Dye pots, tanning barrels and mordants never go back to food use**, and stay away from children
>   *(rule of thumb)*.
> - **Wet leather burns easily.** Dry boots slowly; leather hotter than your hand can bear is almost sure
>   to burn ([USDA FB1183, p. 9](lib:usda-the-care-of-leather-fb1183-1920#page=9)).

---

## 🌧️ Dressing for our cold-wet winters

**Our winters are "cold-wet"** — near freezing, freeze-thaw, rain, wet snow, slush and mud — the hardest
weather to dress for. You need a **waterproof or water-repellent, windproof outer layer over insulation**,
and waterproof footwear. "Cold-dry" weather (below 14 °F) is colder but easier
([TC 21-3, p. 6](lib:tc-21-3-soldiers-handbook#page=6); [🖼️ cold-wet vs cold-dry](lib:tc-21-3-soldiers-handbook#page=11)). On the valley floor most winter nights are in the
20s–30s °F, with weeks of rain from November to March *(rule of thumb)*.

**The COLD rule** ([TC 21-3, p. 10](lib:tc-21-3-soldiers-handbook#page=10); [🖼️ drawing](lib:tc-21-3-soldiers-handbook#page=10); [FM 21-76, p. 176](lib:fm-21-76-army-survival-manual#page=176)):

| | Rule | Why |
|---|---|---|
| **C** | Keep clothes **clean** | Dirt and grease clog the air spaces |
| **O** | Avoid **overheating** | Better a little cool than sweaty; shed a layer before you work |
| **L** | Wear it **loose and in [layers](wiki:Layered_clothing)** | Trapped air insulates; a tight outer layer crushes it ([🖼️ drawing](lib:tc-21-3-soldiers-handbook#page=9)) |
| **D** | Keep it **dry** | Wet clothing carries heat away far faster than dry |

**[Wool](wiki:Wool), not cotton.** Cotton underwear, T-shirts, jeans and flannel lose what little warmth they have when
wet and pull heat from the body. Wool keeps you warm when wet
([hunter manual, p. 77](lib:todays-hunter-in-new-york-hunter-education-manual#page=77)). The Army's
fallback is all-wool clothing, except perhaps a windbreaker ([FM 21-76, p. 176](lib:fm-21-76-army-survival-manual#page=176)).
Cover the head and neck too — their blood vessels don't narrow in the cold the way the hands' do
*(rule of thumb)*.

**Feet** ([TC 21-3, pp. 12, 41–42](lib:tc-21-3-soldiers-handbook#page=42)): [trench foot](wiki:Trench_foot)
([🖼️ photo](lib:afh-10-644#page=75)) comes from days of cold, wet feet, not from freezing; in bad cases the skin dies and amputation follows.
1. **Change to dry socks at least twice a day.**
2. Dry and massage your feet.
3. Dry leather boots whenever you can.
4. Wear socks that aren't tight, and only one pair of cushion socks at a time.

**Drying clothes** ([TC 21-3, p. 14](lib:tc-21-3-soldiers-handbook#page=14); [FM 21-76, p. 177](lib:fm-21-76-army-survival-manual#page=177)):
- Hang items separately, high in the shelter, away from the stove and steaming pots. **Nylon melts** if
  dried too close.
- Pin damp socks inside your outer layer as you walk. **Never put damp clothes in a sleeping bag.**
- Dry leather slowly; boots can dry between the sleeping-bag shell and liner.

**Bedding:** wet down loses much of its warmth. No bag? Sew two layers of cloth and stuff them with dry
leaves, pine needles or moss ([FM 21-76, p. 177](lib:fm-21-76-army-survival-manual#page=177)). Wool
blankets beat heavy cotton quilts ([*Household Discoveries*, p. 53](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=53)).

📚 **Go deeper:** [TC 21-3 *Cold-Weather Soldier's Handbook*](lib:tc-21-3-soldiers-handbook#page=9) — layers, feet, drying clothes, cold injuries; [FM 21-76](lib:fm-21-76-army-survival-manual#page=176) — cold-weather clothing and improvised gear.

## 🪡 Mending and hand sewing

**Hand-sewing basics** ([TM 4-42.21, pp. 17–22](lib:general-fabric-repair#page=17)):
- Cut thread about 36 inches, never more than a yard (it tangles). Cut it; never bite or break it.
- **Basting** ([🖼️ drawing](lib:general-fabric-repair#page=19)) holds work in place for a while. **Backstitch** ([🖼️ drawing](lib:afh-10-644#page=253)) is the
  strong seam. **Catch (cross) stitch** ([🖼️ drawing](lib:general-fabric-repair#page=20)) holds hems invisibly. **Whipstitch**
  ([🖼️ drawing](lib:general-fabric-repair#page=22)) binds raw edges.
- **Darns** are for holes under 1 inch; **patches** for bigger ones ([pp. 39, 43](lib:general-fabric-repair#page=43);
  [🖼️ four darns](lib:general-fabric-repair#page=40); [🖼️ top patch](lib:general-fabric-repair#page=44)).
  Cut a top patch **2½ inches bigger than the hole all round**, with ½ inch turned under, its grain
  matching the garment's.

**Mend early** ([*ABCs of Mending*, pp. 5–6](lib:usda-abcs-of-mending-fb1925-1943#page=5)): overcast fraying
seams, tape-stay pocket corners, rework raveled buttonholes with buttonhole stitch ([🖼️ drawing](lib:general-fabric-repair#page=23)), and sew buttons on with a
thread "shank" so the cloth isn't strained.

**Canvas, packs, tarps and leather** ([TM 4-42.21, pp. 71–74](lib:general-fabric-repair#page=71)):
- Use a triangular **sailmaker's needle** ([🖼️ drawing](lib:general-fabric-repair#page=71)), pushed with a **sewing palm** (a leather strap
  with a metal pad — [🖼️ putting one on](lib:general-fabric-repair#page=73)).
- Pull the thread across a cake of **beeswax**, and rewax it as you go ([🖼️ drawing](lib:general-fabric-repair#page=72)).
- Cut 2-strand thread **6 times** the seam length, 4-strand **12 times**.

**The lockstitch with a saddler's sewing awl** — the same stitch a machine makes
([TM 4-42.21, p. 79](lib:general-fabric-repair#page=79); [🖼️ threading the awl](lib:general-fabric-repair#page=74); [🖼️ the finished stitch](lib:general-fabric-repair#page=80);
[Lockstitch](wiki:Lockstitch)):
1. Thread the awl, leaving ½ inch out of the needle. Pull out enough thread to reach the end of the seam.
2. Push the needle through; pull all that slack through to the underside; hold it and withdraw the needle.
3. Push the needle in a stitch-length away and pull it **halfway** back, forming a loop underneath.
4. Pass the slack thread through the loop. Pull the needle out, then pull handle and thread equally hard
   to lock the stitch in the middle of the cloth. Repeat.

**Waxed thread for leather** ([*The Saddler*, p. 15](lib:the-saddler-war-dept-tm-10-430-1942#page=15);
[Hasluck, p. 36](lib:harness-making-hasluck-1904#page=36)): twist 3–6 strands of flax ([linen](wiki:Linen)) thread. Taper
each end first by untwisting it on your thigh and pulling it apart. Saddler's wax works best near 75 °F;
cold wax is brittle. For shoes use **waxed flax, never cotton** — it is stronger, and the wax seals the
stitch holes ([FB1183, p. 9](lib:usda-the-care-of-leather-fb1183-1920#page=9)).

📚 **Go deeper:** [TM 4-42.21 *General Fabric Repair*](lib:general-fabric-repair#page=39) — every hand stitch, four darns, patches, canvas and webbing; [USDA *ABCs of Mending*](lib:usda-abcs-of-mending-fb1925-1943#page=7) — darns and patches for every fabric. Pictures: [Backstitch](wiki:Backstitch).

## ✂️ Fibers, first garments and sewing machines

**Tell the fiber before you trust a salvaged garment** ([Turner, p. 95](lib:turner-sewing-and-textiles#page=95)):

| Burn a few threads | Fiber |
|---|---|
| Burns fast, little ash, no smell | Cotton |
| Burns slowly, black ball of ash, smells like burning feathers | Wool |
| Melts and drips into a hard bead | Synthetic — keep it away from fire *(rule of thumb)* |

Boiling a sample in weak lye (in an enamel pot) destroys wool but leaves cotton — so never wash wool with
lye or chlorine bleach *(rule of thumb)*.

**A first garment with no pattern** ([Turner, pp. 122–123](lib:turner-sewing-and-textiles#page=123)): a
kimono nightgown takes cloth twice the shoulder-to-floor length, plus a hem. Fold it crosswise, lay the
drafted pattern on the fold, and cut the neck with the garment on the wearer. Its long straight seams
(French or felled) are good machine practice. To remake old clothes, rip, wash and press first, and check
the cloth is worth the work ([*Make-overs from Coats and Suits*, p. 4](lib:usda-make-overs-from-coats-and-suits-mp545-1944#page=4)).

**Lice** live in seams: hang infested clothes in the cold, then beat and brush them. This does not kill
the eggs ([FM 21-76, p. 177](lib:fm-21-76-army-survival-manual#page=177)).

**Rescuing a gummed-up treadle or electric machine** ([USDA FB1944, pp. 4–12](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=4);
[🖼️ two views of the machine](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=6); [Sewing machine](wiki:Sewing_machine)):
1. Pick out the oil holes. Run the machine while squirting kerosene or cleaning fluid into every hole and
   bearing, then oil each one freely. **Never oil the tension discs. Never use gasoline indoors.**
2. A stuck screw: soak it with cleaning fluid. "Left is loose, right is tight" ([p. 5](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=5)).
3. Replace a dirty wool wad in a long-bobbin oil well with raw wool ([p. 8](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=8)).
4. Then one drop per hole after each day's work, and now and then when idle ([p. 10](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=10)).
5. **Skipped stitches:** usually a needle of the wrong length or set wrong — the short groove faces the
   shuttle point. Sharpen a dull needle on a fine emery stone; scratch marks on the machine to record the
   needle length ([pp. 11–12](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=12)).

Many electric heads from about 1900–1960 fit a [treadle](wiki:Treadle) cabinet, run by a 3/16-inch leather
round belt if the hand wheel has a belt groove. Stock spare needles, bobbins and belts now *(rule of thumb)*.

📚 **Go deeper:** [Turner *Sewing and Textiles*](lib:turner-sewing-and-textiles#page=95) — seams, measuring and simple garments; [USDA FB1944](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=4) — cleaning and adjusting machines.

## 🐑 Wool: from sheep to yarn

**Shearing** ([*Raising Healthy Sheep*, pp. 81–82](lib:raising-healthy-sheep-cvm#page=81); [🖼️ handling the fleece](lib:raising-healthy-sheep-cvm#page=82);
[Sheep shearing](wiki:Sheep_shearing)): once a year when
spring warms. If cold, wet weather follows, house the sheep 10–14 days or leave some wool on. Shear white
sheep first, keep colored wool apart, and never throw hay over sheep's backs — it ruins the fleece. Here,
shear in late April–May as the rains ease *(rule of thumb)*.

**Washing without felting:**
- **Raw fleece:** soak a few ounces at a time in warm water with mild soap for about 30 minutes. **Don't
  stir it or it [felts](wiki:Felt).** Rinse in water of the same temperature ([CSU 4-H *Spinning*, p. 17](lib:4-h-heritage-arts-spinning#page=17)).
- **Finished woolens:** lukewarm suds (about 95 °F), rinses the same temperature. Never boil, rub, wring or
  twist; squeeze, pull to shape and dry away from the fire ([USDA, p. 9](lib:usda-home-dyeing-with-natural-dyes-1935#page=9);
  [*Household Discoveries*, p. 206](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=206)).
- **Local soap:** the bulb of [soaproot](wiki:Chlorogalum_pomeridianum) lathers "like ordinary soap" and has
  no alkali, which suits wool better than lye soap ([Chesnut, p. 332](lib:chesnut-1902#page=332)). It grows on
  dry, rocky slopes here *(rule of thumb)*.

**Carding and combing** ([CSU, p. 17](lib:4-h-heritage-arts-spinning#page=17); [Hooper, p. 43](lib:hooper-hand-loom#page=43)):
[carding](wiki:Carding) ([🖼️ hand cards](lib:hooper-hand-loom#page=40)) gives soft, fuzzy yarn; combing gives smooth yarn. Spread wool on one hand card,
draw the other across it a few times, and roll the fibers off into a soft roll. No cards? A metal dog comb,
or your fingers.

**Make a drop [spindle](wiki:Spindle_(textiles))** ([CSU, p. 16](lib:4-h-heritage-arts-spinning#page=16); [🖼️ spinning with distaff and spindle](lib:hooper-hand-loom#page=46)):
1. Sand a 12-inch, ½-inch dowel to a point at one end. Cut a ⅛-inch notch 1 inch from the blunt end as a hook.
2. Glue a 2–3-inch wooden disk (the whorl) 1½ inches from the point. Spin it like a top; if it wobbles,
   re-center the whorl.

**Spin and finish** ([CSU, pp. 18–19](lib:4-h-heritage-arts-spinning#page=18)):
1. Tie on an 18-inch leader of yarn. Twist the spindle and draw the fibers out as the twist runs up.
   Too much twist makes drafting hard; too little and the yarn falls apart.
2. Wind a skein around a chair back and tie it in 4 places. Soak it 20 minutes and hang it to dry with a
   weight. A balanced skein hangs straight.

**[Angora rabbits](wiki:Angora_rabbit)** give wool from a hutch: shear every 10–12 weeks, leave ½ inch of wool in winter, and keep
newly shorn rabbits warm ([USDA Handbook 309, p. 61](lib:usda-commercial-rabbit-raising-handbook-309#page=61)).

📚 **Go deeper:** [CSU 4-H *Spinning*](lib:4-h-heritage-arts-spinning#page=15) — spindle, washing, carding, skeins; [Hooper *Hand-loom Weaving*](lib:hooper-hand-loom#page=43) — carding, distaff and spindle.

## 🌾 Linen, nettle and native fibers

**Fiber [flax](wiki:Flax)** ([USDA FB669](lib:usda-fiber-flax#page=7); [🖼️ the plant](lib:usda-fiber-flax#page=7)):
1. **Climate:** moderately cool, damp weather while growing and a dry spell at harvest. Heat and drought
   make it ripen early and short (p. 7). Here, sow very early on moisture-holding soil, or irrigate
   *(rule of thumb)*.
2. **Sow thickly** — about 6 pecks an acre — so stalks grow tall and unbranched ([p. 11](lib:usda-fiber-flax#page=11)).
3. **Pull, don't cut,** when the stalks yellow and the lower leaves drop ([p. 12](lib:usda-fiber-flax#page=12)).
4. **[Ret](wiki:Retting)** to rot the gum that holds fiber to stalk: spread it on grass 2–8 weeks, turning
   once (dew retting), or weight bundles under soft water 6–15 days and watch closely — "a few hours'
   delay often causes loss" ([pp. 16–17](lib:usda-fiber-flax#page=16)).
5. Dry the straw, **break** it ([🖼️ a flax brake](lib:usda-fiber-flax#page=18)), then **scutch** (beat) out the woody bits ([Hooper, p. 37](lib:hooper-hand-loom#page=37)).

**Native fibers:**
- **[Douglas iris](wiki:Iris_douglasiana):** the leaf edges are "as fine and strong as silk" and made the
  strongest nets and snare rope ([🖼️ twisting fiber into cord](lib:afh-10-644#page=275)) — about six weeks' work for a 12-foot rope
  ([Chesnut, p. 343](lib:chesnut-1902#page=343)).
- **[Hemp dogbane](wiki:Apocynum_cannabinum):** good fiber, but poisonous to livestock
  ([AIB 415, p. 50](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=50)).
- **[Stinging nettle](wiki:Urtica_dioica):** gather with long rubber gloves and sleeves
  ([OSU EM 9373, p. 2](lib:osu-wild-edibles-stinging-nettle#page=2)). Cut tall creek-side stalks after they
  brown in late summer or fall, then ret, break and scutch like flax *(rule of thumb; no book here
  covers nettle fiber)*.

📚 **Go deeper:** [USDA FB669 *Fiber Flax*](lib:usda-fiber-flax#page=16) — growing, retting, breaking and scutching; [Chesnut (1902)](lib:chesnut-1902#page=343) — native fiber and soap plants of our region.

## 🎨 Natural dyes with safe mordants

**Mordant with [alum](wiki:Alum)** ([USDA, p. 10](lib:usda-home-dyeing-with-natural-dyes-1935#page=10)): for each pound of dry
wool, dissolve **4 oz alum and 1 oz cream of tartar** in 4–4½ gallons of soft water. Bring it slowly to the
boil, simmer 1 hour, and leave it overnight. The Navajo used raw alum, or water from burned green juniper
needles ([Navajo Native Dyes, p. 19](lib:navajo-native-dyes#page=19)). **Skip the "chrome" mordant** on the
same USDA page — it causes cancer (see the last section).

| Color | Plant | How |
|---|---|---|
| Dull greenish yellow | [Oregon grape](wiki:Berberis_aquifolium) roots, stems and leaves | With raw alum ([Navajo, p. 39](lib:navajo-native-dyes#page=39); [USDA, p. 24](lib:usda-home-dyeing-with-natural-dyes-1935#page=24)) |
| Soft brown | [Alder](wiki:Alnus_rubra) bark peeled in fall | No mordant needed ([Navajo, p. 23](lib:navajo-native-dyes#page=23); [Worst, p. 207](lib:worst-foot-power-loom-weaving-1918#page=207)) |
| Black | Tannin (oak or tanoak bark, sumac) plus "iron liquor" | Steep iron filings in vinegar for days; mop it onto tanned leather ([FB1334, pp. 19–20](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=20)) |

- **Use enamel pots** — tin or aluminum changes the color ([Navajo, p. 12](lib:navajo-native-dyes#page=12)).
- **Test fastness:** sun a sample half-covered with cardboard ([USDA, p. 6](lib:usda-home-dyeing-with-natural-dyes-1935#page=6)).
- **Dye pots are never used for food again** *(rule of thumb)*.

📚 **Go deeper:** [*Navajo Native Dyes*](lib:navajo-native-dyes#page=11) — plant dyes with only alum or juniper ash; [USDA *Home Dyeing with Natural Dyes*](lib:usda-home-dyeing-with-natural-dyes-1935#page=10) — mordanting and dye recipes. Pictures: [Mordant](wiki:Mordant); [Natural dye](wiki:Natural_dye).

## 🧶 Weaving and knitting

**The simplest loom** ([Hooper, pp. 60–61](lib:hooper-hand-loom#page=60)): the one part every [loom](wiki:Loom) needs is
the **cross** in the warp ([🖼️ securing the crosses](lib:worst-foot-power-loom-weaving-1918#page=18)) — alternate threads cross between two rods so they can't tangle. A board with the
warp wound around it and two rods holding the cross is a working loom. For 10-yard warps, build a warping
board ([🖼️ drawing](lib:worst-foot-power-loom-weaving-1918#page=16)) at least 6 ft × 1 ft with smooth hardwood pegs 1 inch thick, and **tie cords through both crosses
before taking the warp off**, or it "will be irretrievably spoiled" ([pp. 64–68](lib:hooper-hand-loom#page=64)).
The next step up is the foot-power loom ([Worst, p. 11](lib:worst-foot-power-loom-weaving-1918#page=11); [🖼️ parts named](lib:worst-foot-power-loom-weaving-1918#page=27)).
Picture: [Warp and weft](wiki:Warp_and_weft).

**[Knitting](wiki:Knitting) habits from the WWI sock drives** ([Nicoll, pp. 25–26](lib:nicoll-knitting#page=25)):
- Join yarn without a knot: ravel both ends 3 inches, remove half the strands of each, overlap them and rub
  between damp palms.
- Cast on ([🖼️ drawing](lib:dillmont-encyclopedia-of-needlework-1890#page=184)) and off loosely. Press with a damp cloth and a cool iron — wool scorches.
- Tie a few needlefuls of the same yarn to each article for darning later ([🖼️ repairing knitting](lib:dillmont-encyclopedia-of-needlework-1890#page=200)).

**Socks, hats and mittens** ([Nicoll](lib:nicoll-knitting#page=133)):
- **Socks:** measure your own rounds per inch and adjust the pattern (p. 133). [Graft](wiki:Grafting_(knitting)) the toe closed so no
  seam blisters the foot ([🖼️ heel, sole and toe](lib:dillmont-encyclopedia-of-needlework-1890#page=196)) ([p. 139](lib:nicoll-knitting#page=139)); knit extra into the heel
  ([p. 143](lib:nicoll-knitting#page=143)).
- **Helmet:** 100 stitches in knit 2, purl 2 ribbing, with a face opening ([p. 28](lib:nicoll-knitting#page=28));
  [balaclava](wiki:Balaclava_(clothing)) ([p. 31](lib:nicoll-knitting#page=31)); mittens ([p. 71](lib:nicoll-knitting#page=71)).
- **Fur caps:** rip apart an old cloth cap for the pattern and line it with wool. [Muskrat](wiki:Muskrat) is "as warm as any
  fur" ([Farnham, p. 246](lib:home-manufacture-of-furs-and-skins#page=246)).
- **Leather or fur mittens:** woodsmen make them unlined and wear a knit liner they can pull out and dry.
  Trace the hand, add ¼–½ inch for seams, test the pattern in old cloth, and leave a long cuff
  ([Farnham, pp. 248–249](lib:home-manufacture-of-furs-and-skins#page=248)).

📚 **Go deeper:** [Nicoll *Knitting and Sewing*](lib:nicoll-knitting#page=28) — seventy patterns for socks, caps and mittens; [Dillmont *Encyclopedia of Needlework*](lib:dillmont-encyclopedia-of-needlework-1890#page=190) — stocking proportions and every stitch.

## 🦌 Tanning hides

**Hold a hide until you can work it** ([USDA FB1334, p. 8](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=8)):
salt it with **1 lb of salt per lb of hide**; it keeps 3–5 months. Never let it freeze or heat. Work in
wooden barrels, never iron ([🖼️ tools](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=7)). Lime takes off the hair in 6–16 days ([🖼️ unhairing](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=11)); a gallon of vinegar removes the lime
([pp. 10–14](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=10)).

**[Bark tanning](wiki:Tanning_(leather)) — sole and harness leather** ([pp. 14–16](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=14)):
1. Per hide, steep **30–40 lb of oak or hemlock bark**, ground no coarser than corn, in 20 gallons of
   boiling water. Use rain water, and keep it away from iron.
2. Strengthen the liquor every 5 days; then bury the hide in wet bark for 6 weeks, and again for about
   2 months.
3. It is done when a cut edge shows **no white streak**. Sole leather needs 2 months more.
4. Finish with **[dubbin](wiki:Dubbin)** (equal parts tallow and neatsfoot or cod oil), slicking ([🖼️ drawing](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=15))
   and staking ([🖼️ drawing](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=21)).

**Local bark:** [tanoak](wiki:Notholithocarpus) bark "has high tannin content" and was once used widely to
cure leather ([USDA NRCS, p. 2](lib:tanoak-plant-guide-usda-nrcs#page=2)); [Oregon white](wiki:Quercus_garryana) and [black oak](wiki:Quercus_kelloggii) bark
also work. **[Sudden oak death](wiki:Phytophthora_ramorum)** kills tanoak and is under quarantine in Curry County, next door: don't haul
tanoak bark, wood or leaves out of infested areas *(rule of thumb)*.

**Brain-tanned [buckskin](wiki:Buckskin_(leather))** ([Farnham, pp. 73–74, 142–147](lib:home-manufacture-of-furs-and-skins#page=73); [Brain tanning](wiki:Buckskin_(leather))):
1. Soak the skin in water, or water with wood ashes, until the hair and the grain (outer skin) slip.
2. Flesh it on a beam ([🖼️ a fleshed hide](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=13)), then scrape off hair and grain.
3. Boil the brains about an hour in a gallon of water; cool until you can hold your hand in it. Work the
   skin in it and wring it out.
4. **Pull and stretch it without stopping until it is dry.** Repeat if it is still stiff.
5. **Smoke it** over a cool smudge of punky hardwood inside a little tepee of sticks. Unsmoked buckskin dries
   hard every time it gets wet.

Soap or lard can replace brains. **Wear gloves with brains** — the prions of [chronic wasting disease](wiki:Chronic_wasting_disease)
concentrate in brain and spinal cord; use soap or egg yolk if in doubt *(rule of thumb)*.

**Furs: salt-alum** ([FB1334, p. 27](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=27)):
1. Dissolve 1 lb alum in 1 gallon of water. Dissolve 4 oz washing soda and 8 oz salt in ½ gallon of water,
   and pour it in **very slowly**.
2. Thicken with flour to a paste; spread 2–3 coats on the flesh side, a day apart.
3. Rinse, oil, and work the skin over a stake as it dries. If it dries stiff, dampen it and work it again.

**[Rawhide](wiki:Rawhide)** ([AFH 10-644, p. 257](lib:afh-10-644#page=257)): flesh the hide, cover the hair side
with wet hardwood ashes, roll it up for several days, and scrape off the hair. Wash it, stretch it in a
frame and dry it slowly in the shade. Soak to soften.

📚 **Go deeper:** [USDA FB1334 *Home Tanning*](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=14) — bark, alum and fur tanning (skip its chrome and acid recipes); [Farnham *Furs and Skins*](lib:home-manufacture-of-furs-and-skins#page=142) — buckskin, robes, caps and mittens (skip its poisons).

## 👢 Boots, shoes and moccasins

**Boot care** ([USDA FB1183, pp. 9–12](lib:usda-the-care-of-leather-fb1183-1920#page=9)):
- **Wet boots:** wash off mud, grease work boots while damp, stuff with paper, dry slowly.
- **Harder grease in summer, more grease in winter** ([p. 12](lib:usda-the-care-of-leather-fb1183-1920#page=12));
  recipes are in the Make-Do guide.
- **Soles:** stand them 15 minutes in warm grease, no hotter than your hand can bear
  ([FB1334, p. 16](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=16)).

**A home repair kit** ([FB1183, p. 9](lib:usda-the-care-of-leather-fb1183-1920#page=9)): last holder, 3–4 iron
lasts, hammer, pincers, knives, rasp, awls, sole and heel nails, flax thread, bristles and wax.

**Half-soling sewn shoes** ([Leno, p. 131](lib:leno-the-art-of-boot#page=131); [Bower, p. 29](lib:practical-shoe-repairing-bower-1923#page=29)):
1. Wet the new leather.
2. Take off the old sole **without cutting the [welt](wiki:Goodyear_welt)**.
3. Carry the new sole well back into the waist (the narrow middle).
4. Cut a channel deep enough to bury the stitches, and sew with stout, well-waxed thread.

**Pegged soles:** one well-driven row of pegs usually holds; two rows make a stiff, tiring sole
([Leno, p. 109](lib:leno-the-art-of-boot#page=109)). **Fit:** measure the foot's length seated, then trace it
on paper standing — it lengthens under load, and the difference sets the allowance ([p. 45](lib:leno-the-art-of-boot#page=45); [🖼️ measuring diagram](lib:leno-the-art-of-boot#page=45)).
Leno also covers pumps ([turnshoes](wiki:Turnshoe)) and leggings.

**[Moccasins](wiki:Moccasin) in a wet climate** ([Farnham, pp. 260–266](lib:home-manufacture-of-furs-and-skins#page=261)):
frontier moccasins were one piece of buckskin stuffed with deer hair or dry leaves. In wet weather wearing
them was "a decent way of going barefooted," because the leather is spongy. Improve them:
- Add a rawhide sole, or sew on a thick "tap" that runs up the sides ([p. 266](lib:home-manufacture-of-furs-and-skins#page=266)).
- Shape them by wetting and wearing them until dry ([p. 264](lib:home-manufacture-of-furs-and-skins#page=264)).
- For uppers, 10–12 oz [cotton duck](wiki:Cotton_duck) rubbed with paraffin and ironed is waterproof and wears well.

A child's moccasins can be cut from an old leather handbag
([MP614, p. 9](lib:usda-make-overs-from-leather-fur-and-felt-mp614-1946#page=9)). Here, keep moccasins for
indoors and the dry season, and save real boots for winter mud *(rule of thumb)*.

📚 **Go deeper:** [Leno *Boot and Shoemaking*](lib:leno-the-art-of-boot#page=45) — lasts, uppers, welted and pegged boots, mending; [Bower *Practical Shoe Repairing*](lib:practical-shoe-repairing-bower-1923#page=29) — soles and heels; [USDA FB1183](lib:usda-the-care-of-leather-fb1183-1920#page=10) — care of shoes and harness.

## 🧯 If this goes wrong

| Problem | Likely cause and fix |
|---|---|
| Wool sweater shrank and felted | Washed hot, rubbed, or rinsed at another temperature — wash lukewarm, rinse the same ([USDA, p. 9](lib:usda-home-dyeing-with-natural-dyes-1935#page=9)). Felt can't be undone; cut it into mittens or slippers *(rule of thumb)* ([MP614, p. 8](lib:usda-make-overs-from-leather-fur-and-felt-mp614-1946#page=8)) |
| Machine skips stitches | Needle wrong length or set backward ([FB1944, p. 11](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=11)) |
| Buckskin went hard after rain | It wasn't smoked — re-soften and smoke it ([Farnham, p. 74](lib:home-manufacture-of-furs-and-skins#page=74)) |
| Alum-tanned fur dried stiff | Common — dampen it and work it over a stake again ([FB1334, p. 27](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=27)) |
| White streak in the middle of bark-tanned leather | Not finished — more time in stronger liquor ([FB1334, p. 15](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=15)) |

📚 **Go deeper:** [USDA FB1334](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=15) — tanning troubles; [Farnham, p. 74](lib:home-manufacture-of-furs-and-skins#page=74) — re-softening and smoking buckskin; [USDA FB1944, p. 11](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=11) — needle and stitch troubles.

## ⚠️ Old advice in the library to ignore

- **Arsenic** sprinkled on stored furs ([Farnham, p. 64](lib:home-manufacture-of-furs-and-skins#page=64)),
  as a hair remover ([p. 120](lib:home-manufacture-of-furs-and-skins#page=120)) and to "poison" fur robes
  ([p. 224](lib:home-manufacture-of-furs-and-skins#page=224)); **arsenical soap and corrosive sublimate (mercury
  chloride)** in [Lee's, p. 225](lib:lees-priceless-recipes-3000-formulas-1900#page=225). Deadly; old mounts and
  furs may still carry it ([ATSDR Arsenic](lib:atsdr-toxfaqs-arsenic#page=1)). **Instead:** salt, dry, cold storage.
- **Chrome tanning** — [FB1334, p. 17](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=17); the bulletin
  itself says the spent liquor "probably would be fatal to farm animals" ([p. 19](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=19)).
  Also the **chrome (dichromate) dye mordant** — [USDA dyes, p. 10](lib:usda-home-dyeing-with-natural-dyes-1935#page=10).
  Chromium(VI) causes cancer ([ATSDR Chromium](lib:atsdr-toxfaqs-chromium#page=1)). **Instead:** bark or alum.
- **Sulfuric acid "salt-acid" pickle** — [FB1334, pp. 27–28](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=28);
  [Farnham, p. 113](lib:home-manufacture-of-furs-and-skins#page=113). Burns and fumes. **Instead:** salt-alum.
- **Oxalic acid tan liquors** — [Farnham, p. 116](lib:home-manufacture-of-furs-and-skins#page=116);
  [*Household Discoveries*, p. 409](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=409).
  Poisonous. **Instead:** brains, bark or alum.
- **Gasoline baths for furs** — [FB1334, pp. 25–26](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=25);
  [Farnham, p. 150](lib:home-manufacture-of-furs-and-skins#page=150). Fire and fumes. **Instead:** lukewarm
  soapy water *(rule of thumb)*.
- **Burning sulfur to bleach sheepskins** — [Farnham, p. 151](lib:home-manufacture-of-furs-and-skins#page=151).
  Toxic fumes. **Instead:** keep the natural color.
- **Formaldehyde and borax-heavy "pickles"** in old taxidermy recipes *(rule of thumb)*. **Instead:** salt and alum.
- **"40 to 45 percent of body heat" lost from the head** — [FM 21-76, p. 176](lib:fm-21-76-army-survival-manual#page=176).
  The real figure is about 10%, in proportion to skin area *(rule of thumb)* — but still cover head and neck.
- **Wet clothing loses heat "several hundred times faster"** — [hunter manual, p. 77](lib:todays-hunter-in-new-york-hunter-education-manual#page=77).
  Overstated: water conducts heat about 25 times better than still air *(rule of thumb)*. Wet is still deadly.
- **Wool next to the skin and wool blankets are "unsanitary"** — [Turner, p. 233](lib:turner-sewing-and-textiles#page=233).
  Wrong: wool is the best cold-wet fabric. **Instead:** wash or air whatever touches the skin often.

📚 **Go deeper:** [ATSDR *Chromium*](lib:atsdr-toxfaqs-chromium#page=1) and [ATSDR *Arsenic*](lib:atsdr-toxfaqs-arsenic#page=1) — what these poisons do and where they hide.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Dressing for cold-wet weather**
- Layers and trapped air; the COLD rule — [🖼️ TC 21-3, p. 9](lib:tc-21-3-soldiers-handbook#page=9); [🖼️ p. 10](lib:tc-21-3-soldiers-handbook#page=10); [Layered clothing](wiki:Layered_clothing)
- Cold-wet versus cold-dry — [🖼️ TC 21-3, p. 11](lib:tc-21-3-soldiers-handbook#page=11)
- How much warmth each layer adds — [🖼️ AFH 10-644 CLO chart, p. 179](lib:afh-10-644#page=179); [Wool](wiki:Wool)
- Trench foot — [🖼️ AFH 10-644, p. 75](lib:afh-10-644#page=75); [Trench foot](wiki:Trench_foot)

**Hand sewing and heavy mending**
- Threading a needle and tying the knot — [🖼️ TM 4-42.21, p. 18](lib:general-fabric-repair#page=18)
- Basting, felling, cross stitch, whipstitch, buttonhole stitch — [🖼️ TM 4-42.21, pp. 19–23](lib:general-fabric-repair#page=19); [🖼️ backstitch, AFH 10-644 p. 253](lib:afh-10-644#page=253); [Backstitch](wiki:Backstitch)
- Four darns — [🖼️ TM 4-42.21, pp. 40–43](lib:general-fabric-repair#page=40); [Darning](wiki:Darning)
- Patches for clothes and canvas — [🖼️ top patch, p. 44](lib:general-fabric-repair#page=44); [🖼️ canvas patch, p. 91](lib:general-fabric-repair#page=91)
- Sailmaker's needle, waxed thread and sewing palm — [🖼️ TM 4-42.21, pp. 71–73](lib:general-fabric-repair#page=71)
- Lockstitch with a saddler's sewing awl — [🖼️ p. 74](lib:general-fabric-repair#page=74); [🖼️ p. 80](lib:general-fabric-repair#page=80); [Lockstitch](wiki:Lockstitch); [Awl](wiki:Awl)
- Treadle sewing machine — [🖼️ USDA FB1944, p. 6](lib:usda-sewing-machines-cleaning-and-adjusting-fb1944-1943#page=6); [Treadle](wiki:Treadle); [Sewing machine](wiki:Sewing_machine)

**Wool, linen and native fibers**
- Shearing and handling the fleece — [🖼️ *Raising Healthy Sheep*, p. 82](lib:raising-healthy-sheep-cvm#page=82); [Sheep shearing](wiki:Sheep_shearing)
- Hand cards — [🖼️ Hooper, p. 40](lib:hooper-hand-loom#page=40); [Carding](wiki:Carding)
- Distaff and drop spindle; spinning wheel — [🖼️ Hooper, p. 46](lib:hooper-hand-loom#page=46); [🖼️ Worst, p. 43](lib:worst-foot-power-loom-weaving-1918#page=43); [Spindle](wiki:Spindle_(textiles)); [Distaff](wiki:Distaff); [Spinning wheel](wiki:Spinning_wheel)
- Fiber flax: the plant, pulling, dew retting, the brake — [🖼️ FB669, p. 7](lib:usda-fiber-flax#page=7); [🖼️ p. 12](lib:usda-fiber-flax#page=12); [🖼️ p. 16](lib:usda-fiber-flax#page=16); [🖼️ p. 18](lib:usda-fiber-flax#page=18); [Retting](wiki:Retting)
- Twisting plant fiber into cord — [🖼️ AFH 10-644, p. 275](lib:afh-10-644#page=275); [🖼️ FM 3-05.70, p. 201](lib:fm-3-05-70-survival-2002#page=201)
- Douglas iris, hemp dogbane, nettle and soaproot — [Douglas iris](wiki:Iris_douglasiana); [Hemp dogbane](wiki:Apocynum_cannabinum); [Stinging nettle](wiki:Urtica_dioica); [Soaproot](wiki:Chlorogalum_pomeridianum)

**Dyes, weaving and knitting**
- Dye plants — [Oregon grape](wiki:Berberis_aquifolium); [Red alder](wiki:Alnus_rubra); [Natural dye](wiki:Natural_dye); [Alum](wiki:Alum)
- Warp and weft — [🖼️ Hooper, plate III, p. 41](lib:hooper-hand-loom#page=41); [Warp and weft](wiki:Warp_and_weft)
- Warping board and securing the crosses — [🖼️ Worst, p. 16](lib:worst-foot-power-loom-weaving-1918#page=16); [🖼️ p. 18](lib:worst-foot-power-loom-weaving-1918#page=18)
- Foot-power loom and the shed — [🖼️ Worst, p. 27](lib:worst-foot-power-loom-weaving-1918#page=27); [🖼️ p. 42](lib:worst-foot-power-loom-weaving-1918#page=42); [Loom](wiki:Loom)
- Knitting: holding the needles, casting on, mending — [🖼️ Dillmont, p. 181](lib:dillmont-encyclopedia-of-needlework-1890#page=181); [🖼️ p. 184](lib:dillmont-encyclopedia-of-needlework-1890#page=184); [🖼️ p. 200](lib:dillmont-encyclopedia-of-needlework-1890#page=200); [Knitting](wiki:Knitting)
- Stocking heel and toe; grafting — [🖼️ Dillmont, p. 196](lib:dillmont-encyclopedia-of-needlework-1890#page=196); [Kitchener stitch](wiki:Grafting_(knitting))

**Tanning**
- Tanning tools — [🖼️ USDA FB1334, p. 7](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=7)
- Unhairing, a fleshed hide, slicking out, staking — [🖼️ p. 11](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=11); [🖼️ p. 13](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=13); [🖼️ p. 15](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=15); [🖼️ p. 21](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=21)
- Tanoak and oak bark — [Tanoak](wiki:Notholithocarpus); [Oregon white oak](wiki:Quercus_garryana); [Sudden oak death](wiki:Phytophthora_ramorum)
- Buckskin and rawhide — [Buckskin](wiki:Buckskin_(leather)); [Brain tanning](wiki:Buckskin_(leather)); [Rawhide](wiki:Rawhide)

**Shoes, boots and moccasins**
- Measuring a foot for a last — [🖼️ Leno, p. 45](lib:leno-the-art-of-boot#page=45)
- Shoes made on good and bad lines — [🖼️ USDA FB1183, p. 6](lib:usda-the-care-of-leather-fb1183-1920#page=6)
- Welted shoes — [Goodyear welt](wiki:Goodyear_welt); [Shoemaking](wiki:Shoemaking)
- Moccasins and turnshoes — [Moccasin](wiki:Moccasin); [Turnshoe](wiki:Turnshoe)

## 🔗 Related guides

- [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — basic stitches, tire sandals, boot grease, laundry
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — skinning and caring for hides
- [Rabbits & Chickens](guide:RABBITS-CHICKENS-GUIDE) — rabbit pelts and angora wool
- [Milk Goats, Dairy & Bees](guide:GOATS-DAIRY-BEES-GUIDE) — goat hides, beeswax for thread and boots
- [Field Care guide](guide:FIELD-CARE-GUIDE) — hypothermia and trench foot
- [Shelter Building guide](guide:SHELTER-BUILDING-GUIDE) — staying dry and warm through the rains
