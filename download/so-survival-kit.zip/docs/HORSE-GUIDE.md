# 🐴 Horses, Mules and Draft Animals

How to keep, feed, handle, ride, shoe and pack horses, mules and donkeys, and how to put them to
work in harness — written for a time when there may be no feed store, vet or farrier. The
manuals are in `Horses-Draft-Animals\` (`Care-Feeding`, `Riding-Training`, `Hoof-Care-Shoeing`,
`Packing-Travel`, `Draft-Harness`). Horse health, vital signs, colic and first aid are in
`Animals\` and the **Animals and vet care** section of the Illinois Valley page.

> ### ⚠️ Rules that prevent the worst accidents
> - **A horse can kill you without meaning to.** Stay where it can see you, speak before you
>   touch it, keep a hand on it as you move around the hindquarters, and never stand directly
>   behind or in front of it.
> - **Never wrap a lead rope or reins around your hand or body**, and never tie a horse with a
>   knot you can't pull loose. Never tie with a chain lead.
>   ([4-H *Horse Project* PNW 587, p. 51](lib:the-4-h-horse-project#page=51); [*Basic Horse Safety*](lib:basic-horse-safety#page=3))
> - **Wear a helmet** and boots with a heel when riding.
> - The old books here (1867–1940s) teach good handling and shoeing but also **harsh "breaking"
>   methods and dangerous old medicines** (purges, firing, chloroform). Use them for skills, not
>   for doctoring.

---

## 🐎 Choosing an animal

- **For a first horse, pick an older, calm, well-trained one** over a young or green horse —
  the 4-H manual says **6 to 18 years** suits most purposes, and "a young horse and an
  inexperienced rider do not learn together" ([PNW 587, p. 24](lib:the-4-h-horse-project#page=24)).
  For hard work, not much under 5; with good care many stay useful past 20
  ([USDA FB 779, p. 8](lib:how-to-select-a-sound-horse#page=8)). Check it **sound** before you
  take it: walk and trot it on hard ground, look for limping, swellings, bad feet and bad habits.
  (USDA *How to Select a Sound Horse*; [🖼️ points of the horse](lib:how-to-select-a-sound-horse#page=5); [🖼️ where unsoundness shows](lib:how-to-select-a-sound-horse#page=6);
  [conformation](wiki:Equine_conformation))
- **Age by the [teeth](wiki:Horse_teeth):** after about 12 years the front teeth turn triangular and slant forward.
  ([USDA AIB 353, p. 18](lib:horsemanship-and-horse-care-usda-aib-353#page=18);
  [PNW 587, p. 48](lib:the-4-h-horse-project#page=48); [🖼️ mouths from 4 to 8 years](lib:how-to-select-a-sound-horse#page=8); [🖼️ 14- and 22-year-old mouths](lib:how-to-select-a-sound-horse#page=10))
- **Mules** are tough, sure-footed, eat less and handle heat and rough country better; they tend
  to stand and fight rather than bolt. A well-trained mule is very steady; a badly trained one is
  hard work. **Donkeys** need shelter always — their coats aren't waterproof, which matters in our
  wet winters. ([*Donkey Care Handbook*, p. 44](lib:donkey-care-handbook#page=44))
- **Who's who:** a [mule](wiki:Mule) is a mare bred to a jack (male donkey); a [hinny](wiki:Hinny)
  is a jenny bred to a stallion and is smaller and rarer. Mules are hardy but can still founder,
  and they fret if stabled long or kept alone. **[Donkeys](wiki:Donkey) live just over 30 years** and
  should be kept with a companion. ([*Donkey Care Handbook*, pp. 15–19](lib:donkey-care-handbook#page=17);
  [🖼️ points of the donkey](lib:donkey-care-handbook#page=15))

📚 **Go deeper:** [4-H *Horse Project* (PNW 587)](lib:the-4-h-horse-project#page=24) — choosing a horse, breeds, behavior; [USDA *How to Select a Sound Horse*](lib:how-to-select-a-sound-horse#page=8) — unsoundness, blemishes and vices to check; [*Donkey Care Handbook*](lib:donkey-care-handbook#page=11) — how donkeys and mules differ from horses; [USDA *Mule Production*](lib:mule-production#page=7) — breeding and raising mules.

## 🌾 Feeding and water

- **Total feed: 1.5–2.5% of body weight a day**, most of it hay or pasture. **Never less than
  8–10 lb of hay a day** for a 1,000-lb horse; an idle horse holds weight on about **18 lb of good
  hay**. ([Nebraska G1781, pp. 1–2](lib:basics-of-feeding-horses#page=2); [FM 25-5, p. 101](lib:animal-transport-war-dept-fm-25-5#page=101))
- **Weigh a horse with a string:** weight (lb) = heart girth (in) × heart girth (in) × body
  length (in) ÷ 330. Body length is point of shoulder to point of buttock.
  ([G1781, p. 1](lib:basics-of-feeding-horses#page=1); [🖼️ where to measure](lib:basics-of-feeding-horses#page=2))
- **Working horses:** about 1.1 lb grain + 1.25 lb hay per 100 lb of body weight a day, grain split
  into 3 feeds. Keep each grain meal **under about 5 lb** for a 1,000-lb horse. Feed by weight:
  a quart of oats ≈ 1 lb, a quart of corn ≈ 1.7 lb.
  ([USDA FB1419, p. 9](lib:care-and-management-of-farm-work#page=9); [G1781, p. 3](lib:basics-of-feeding-horses#page=3); [UGA B1356](lib:basic-nutritional-guidelines#page=1))
- **Water: 5–15 gallons a day**, double in heat or hard work (an idle horse drinks about 10–12 —
  [G1781, p. 4](lib:basics-of-feeding-horses#page=4)). Give an exhausted horse small drinks
  every 5–10 minutes until it recovers. In cold weather, take the chill off the water or salt the
  feed (1–2 oz) so it keeps drinking (prevents impaction colic).
  ([UGA B1356, p. 2](lib:basic-nutritional-guidelines#page=2); FM 25-5)
- **Salt:** about 3 oz a day; loose salt-mineral beats a block. **Western Oregon soils are low in
  selenium** — use a mineral that contains it. *(Rule of thumb)* (AIB 353;
  [UGA B1356, p. 3](lib:basic-nutritional-guidelines#page=3))
- **Army feeding rules that prevent colic:** water before feeding (or wait an hour after); never
  grain a hot horse (hay is fine); a little hay before grain; **change feeds gradually over 1–2
  weeks**; never feed moldy or dusty hay. ([FM 25-5, p. 103](lib:animal-transport-war-dept-fm-25-5#page=103))
- **Body condition:** keep them at **5–7 on the 1–9 scale** — feel ribs, back and tailhead with
  your hands; a winter coat hides thinness. ([G1781, p. 2](lib:basics-of-feeding-horses#page=2); [🖼️ where to feel](lib:basics-of-feeding-horses#page=3))

**Body condition at a glance** ([G1781, p. 3](lib:basics-of-feeding-horses#page=3)):

| Score | Ribs | Back |
|---|---|---|
| 1–3 (thin) | Easy to see | Backbone sticks up |
| 4 | Faint outline shows | Slight ridge |
| **5 (ideal)** | Can't see, easy to feel | Level |
| 6–7 | Felt with pressure | Slight crease |
| 8–9 (fat) | Hard or impossible to feel | Deep crease, bulging fat |

**More feeding rules from the modern bulletins:**

- **Turning out onto lush spring grass:** a few hours a day for 2–3 days, then half days for
  2–3 days, then full time — or fill them up on hay first
  ([G1781, p. 4](lib:basics-of-feeding-horses#page=4)).
- **Never feed cattle feed containing Rumensin** — it kills horses
  ([G1781, p. 4](lib:basics-of-feeding-horses#page=4)).
- **A horse that bolts its grain:** put a few fist-sized rocks in the feed box
  ([USFS *Horse Packing*, p. 3](lib:instructions-on-horse-packing#page=3)).
- **Plan the winter hay:** at 1.5–2% of body weight, a 1,000-lb horse eats **15–20 lb of hay a
  day — roughly 450–600 lb for every month off pasture** *(arithmetic from G1781's table)*. Add a
  margin for waste and a late spring.
- **Donkeys are different:** they do best on good **barley straw** (high fiber, low sugar), not rich
  horse hay ([*Donkey Care Handbook*, p. 16](lib:donkey-care-handbook#page=16); [🖼️ a homemade straw feeder](lib:donkey-care-handbook#page=47)).

**Pasture in our wet climate** ([OSU EC1558](lib:small-acreage-horse-farms#page=4)):

1. **Keep horses off pasture through the wet months.** Wet soil compacts, the grass dies, and you
   buy more hay next year. Hold them in a **sacrifice area** (a dry lot) instead (pp. 4–5;
   [🖼️ photo](lib:small-acreage-horse-farms#page=4)).
2. Graze only when the grass is **over 3 inches tall** and the soil is firm. Move them when it's
   grazed to **3–4 inches**; let it regrow to **6–8 inches** before grazing again (p. 7;
   [🖼️ why: leaves feed the roots](lib:small-acreage-horse-farms#page=8)).
3. Keep clover and alfalfa under **30%** of the mix to reduce colic risk (p. 10).

📚 **Go deeper:** [Nebraska G1781](lib:basics-of-feeding-horses#page=1) — feed by body weight, weight tape formula, condition scoring; [UGA B1356](lib:basic-nutritional-guidelines#page=1) — 25 feeding rules that prevent colic; [OSU EC1558 *Small-Acreage Horse Farms*](lib:small-acreage-horse-farms#page=4) — western Oregon pasture, mud and manure; [USDA FB 1030 *Feeding Horses*](lib:feeding-horses-usda-fb1030#page=1) — rations from home-grown hay and grain.

## 🦷 Teeth and worms

- **Teeth:** check at least yearly (twice for older horses). Sharp edges form on the outside of the
  upper molars and inside of the lowers — **[float (rasp) them](wiki:Equine_dentistry)**
  ([🖼️ how to hold the float](lib:animal-dentistry-and-diseases-of-the-mouth#page=197)) or the horse drops feed and loses
  weight. ([PNW 587, p. 46](lib:the-4-h-horse-project#page=46);
  Merillat [*Animal Dentistry*](lib:animal-dentistry-and-diseases-of-the-mouth))
- **Signs of tooth trouble:** dropping grain while chewing, holding the head sideways, eating
  slowly, whole grain in the manure, losing condition
  ([G1781, p. 4](lib:basics-of-feeding-horses#page=4)).
- **Worms:** don't deworm blindly every 8 weeks. Adults need 1–2 treatments a year (one in fall
  for [bots](wiki:Gasterophilus) and tapeworms); youngsters 3–4. **When dewormers run out:** pick up manure, don't
  overgraze, rotate pastures and graze with cattle or sheep.
  ([Penn State/SARE, pp. 1–2](lib:managing-equine-parasites#page=2))
- **Know your high shedders:** most horses carry few worms; a few shed most of the eggs. Penn
  State's line: deworm a horse whose fecal egg count is over about **300 eggs per gram**; over 500
  is a "high shedder" ([Penn State, pp. 1–2](lib:managing-equine-parasites#page=2)). Foals need a special schedule —
  ask the books, not guesswork.
- **Kill eggs without drugs:** a manure pile that heats to **130–150 °F** kills most parasites,
  flies and weed seeds ([OSU EC1558, p. 16](lib:small-acreage-horse-farms#page=16); [🖼️ covered piles](lib:small-acreage-horse-farms#page=16)); dragging or
  harrowing pastures in dry weather spreads droppings so eggs dry out
  ([p. 15](lib:small-acreage-horse-farms#page=15)).
- **Donkeys can carry lungworm** with no signs and pass it to horses — worm them together
  ([*Donkey Care Handbook*, p. 16](lib:donkey-care-handbook#page=16)).

📚 **Go deeper:** [Penn State *Managing Equine Parasites*](lib:managing-equine-parasites#page=1) — the egg-count method and when to treat; [4-H PNW 587](lib:the-4-h-horse-project#page=46) — teeth and aging; [Merillat *Animal Dentistry*](lib:animal-dentistry-and-diseases-of-the-mouth) — floating and dental work by hand (old book: skills only).

## 🦶 Hoof care and shoeing

- **Pick out the feet every day** ([🖼️ how](lib:donkey-care-handbook#page=91)). A healthy frog feels like firm rubber
  ([🖼️ parts of the hoof](lib:evaluation-of-equine-hoof-care#page=2)). **[Thrush](wiki:Thrush_(horse))** (black,
  stinking rot in the frog) comes from wet, dirty footing — trim away dead tissue, apply an
  antiseptic, and get the horse onto dry ground. **In our wet winters, give horses a dry gravel
  or wood-chip standing area.** ([TM 2-220, p. 97](lib:the-horseshoer#page=97); PNW 587;
  [OSU EC1558, p. 2](lib:small-acreage-horse-farms#page=2))
- **Hooves grow about ⅜ inch a month.** Trim barefoot horses every **6–12 weeks**, donkeys and
  mules every 6–10; the Army reset shoes every **3–6 weeks** ([🖼️ untrimmed vs. trimmed](lib:farm-horseshoeing#page=10)).
  ([NMSU B-707, p. 2](lib:evaluation-of-equine-hoof-care#page=2); [*Donkey Care Handbook*, p. 14](lib:donkey-care-handbook#page=14); TM 2-220)
- **Going barefoot** (when shoes and nails run out): leave the sole, balance the wall, **round
  off the outer edge** so it doesn't chip ([🖼️ using the rasp](lib:farm-horseshoeing#page=9)), and check weekly. Most horses do fine barefoot on soft
  ground; hard rocky work wears feet faster than they grow. ([TM 2-220, p. 98](lib:the-horseshoer#page=98))
- **Making and fitting shoes:** TM 2-220 *The Horseshoer* teaches forging shoes from bar stock,
  fitting and nailing ([🖼️ nailing and clinching](lib:farm-horseshoeing#page=11)), and even shoeing in the field with a ground fire and a rail for an anvil.
  Lungwitz's *Text-Book of Horseshoeing* is the standard reference ([🖼️ the foot from the side](lib:a-text-book-of-horseshoeing#page=67);
  [farrier](wiki:Farrier)). Pair with the
  **[Blacksmithing guide](guide:BLACKSMITHING-GUIDE)**.

**Taking shoes off for good** ([TM 2-220, p. 97](lib:the-horseshoer#page=97)):

1. Pull the shoes, then **trim to balance and round the edge** of the wall. Leave the dead sole.
2. Expect the hoof to **break away and the horse to go a bit tender for the first few weeks.**
   It isn't serious and passes as new horn grows.
3. On rough, rocky pasture, **leave the front shoes on for the first few days** while the horse
   settles, then pull them.
4. Even shod horses do better with **2–3 months a year barefoot.**

**Mud is the enemy here.** Wet ground softens hooves and soles, leading to cracks, stone bruises,
abscesses and thrush; mud also causes **"mud fever" ([scratches](wiki:Mud_fever))** — crusty scabs on the lower legs
([OSU EC1558, p. 2](lib:small-acreage-horse-farms#page=2)). For the dry lot, lay down **twice as much
footing as you have mud**: landscape fabric, 3 inches of ¾–1½-inch crushed rock, then 6 inches of
gravel or sand or up to 12 inches of wood chips ([p. 5](lib:small-acreage-horse-farms#page=5); [🖼️ photo](lib:small-acreage-horse-farms#page=5)).

**Field tips from the Army farrier:** store horseshoe nails **wrapped in an oiled cloth in a
watertight can**, and a worn rasp can be re-sharpened with a three-cornered file and re-hardened
([TM 2-220, p. 99](lib:the-horseshoer#page=99)) — see the Blacksmithing guide.

📚 **Go deeper:** [*The Horseshoer* TM 2-220](lib:the-horseshoer#page=95) — care of shod and unshod feet, field expedients; [Lungwitz *Text-Book of Horseshoeing*](lib:a-text-book-of-horseshoeing) — hoof anatomy, trimming, forging and diseased hooves; [NMSU B-707](lib:evaluation-of-equine-hoof-care#page=2) — how to judge a good trim; [USDA *Farm Horseshoeing*](lib:farm-horseshoeing) — shoeing with simple tools. Pictures: [Horse hoof](wiki:Horse_hoof), [Horseshoe](wiki:Horseshoe).

## 🤠 Handling, saddling and riding

- **Leading:** from the left side, right hand near the halter, slack folded (never wrapped) in your
  left hand. If the horse rears, let go with the hand nearest the halter so you stay on the
  ground. ([PNW 587, p. 51](lib:the-4-h-horse-project#page=51))
- **Tying:** use a **[quick-release knot](wiki:Halter_hitch)** ([🖼️ drawing](lib:the-4-h-horse-project#page=51); [🖼️ step by step](lib:donkey-care-handbook#page=84)), about 3 ft of rope, tied **at or above withers height**
  to something solid. Any rope around the neck gets a **[bowline](wiki:Bowline)** (it can't tighten), never a slip
  knot. Untie before taking the halter off. ([PNW 587, p. 51](lib:the-4-h-horse-project#page=51);
  [*Basic Horse Safety*, p. 3](lib:basic-horse-safety#page=3))
- **[Saddle](wiki:Saddle) fit:** with pad and rider on, the gullet must clear the withers. After a sweaty ride,
  **even sweat marks = good fit; dry spots = pressure.** A sliding saddle needs a breast collar,
  not a tighter cinch. **Dry spots with raised skin** lead to saddle sores and white hair — fix
  the fit now ([UF *Saddle Fit*, p. 3](lib:saddle-fit-for-the-horse#page=3)).
- **[Cinching](wiki:Girth_(tack)):** snug it gradually until a flat hand just slips under, walk the horse a few steps,
  then **recheck after a short ride** — many horses puff up their bellies. On the trail, stop after
  1–2 miles to retighten. (PNW 587; [*Animal Management*](lib:animal-management-british-war-office))
- **Mounting and riding:** mount from the left, reins short enough to stop the horse ([🖼️ holding the reins](lib:animal-transport-war-dept-fm-25-5#page=47)), sit deep with
  heels down. The 4-H manual (PNW 587) and FM 25-5 walk through riding step by step.
- **Starting young horses:** handle foals early and teach them to lead before weaning. Light
  harness or saddle work at 2–3 years; **no heavy work until they're nearly mature.** First tie
  with a neck rope through the halter ring, tied with a bowline.
  ([USDA FB1368](lib:breaking-and-training-colts))
- **Holding a horse for treatment:** have a helper hold up another foot while you work on a leg;
  a twitch on the upper lip works for short jobs — tighten it only enough to stay on and take it
  off as soon as you can ([PNW 587, p. 30](lib:the-4-h-horse-project#page=30)).
- **[Tack](wiki:Horse_tack) repair:** cutting leather, hand-stitching with waxed thread and riveting are in TM 10-430
  *The Saddler* and Hasluck's *Harness Making* ([🖼️ sewing awls](lib:harness-making-hasluck#page=26); [🖼️ stitching clamp](lib:harness-making-hasluck#page=28)).

📚 **Go deeper:** [4-H PNW 587](lib:the-4-h-horse-project#page=51) — handling, safety knots, tack, saddling and riding; [UF *Saddle Fit*](lib:saddle-fit-for-the-horse#page=1) — checking tree fit and sweat patterns; [*The Saddler* TM 10-430](lib:the-saddler) — hand-repairing saddles and tack; [USDA *Breaking and Training Colts*](lib:breaking-and-training-colts) — gentling and starting young horses.

## 🩺 Health checks and first aid

**Normal vital signs at rest** — *the sources differ a little*, so learn your own horse's normal by
taking it twice a day for a week ([PNW 587, p. 28](lib:the-4-h-horse-project#page=28); [🖼️ vital-signs chart](lib:first-aid-for-horse-owners#page=2)):

| | Temperature | Pulse (beats/min) | Breaths/min |
|---|---|---|---|
| [4-H PNW 587](lib:the-4-h-horse-project#page=28) | 99–101 °F (102+ = sick) | 32–48 (over 50 = distress) | 8–20 |
| [*Raising Healthy Horses*](lib:raising-healthy-horses#page=8) | 99–101.5 °F | 40–48 | 10–14 |
| [UGA B1356](lib:basic-nutritional-guidelines#page=1) | 99.5–101.5 °F | 32–36 | 8–12 |

Take the pulse under the jawbone for 15 seconds × 4. A pinched fold of neck skin should flatten in
1–2 seconds; gums should be pink and moist; a healthy horse passes several piles of manure a day
([PNW 587, p. 28](lib:the-4-h-horse-project#page=28)).

**Act fast** (no vet coming? treat these as emergencies) — temperature 102 °F or more, signs of
colic, a deep puncture, a wound near an eye, joint or tendon, severe lameness, choking, off feed
12–24 hours, worsening cough, persistent diarrhea, or a mare in trouble foaling
([PNW 587, p. 29](lib:the-4-h-horse-project#page=29)).

**Colic** (belly pain) — looking at or kicking at the belly, pawing, rolling, getting up and down,
sweating, little or no manure, pulse over 60 ([PNW 587, p. 31](lib:the-4-h-horse-project#page=31);
[UF VM275, pp. 3–4](lib:first-aid-for-horse-owners#page=4); [🖼️ a horse in colic](lib:first-aid-for-horse-owners#page=4)):

- **Take away all feed.** Let it stand or lie quietly; walk it only briefly if it's throwing itself
  around — don't walk it to exhaustion.
- **Don't** syringe in oil or water, and **never put a hose down its nose or throat** — the fluid
  goes into the lungs. Don't repeat painkillers without advice.
- **Water:** *sources disagree* — UF lets the horse drink; the 4-H manual says no food or water
  until the vet sees it.
- If it recovers on its own, **no feed for 12–24 hours, then small meals over 3–5 days**, and
  watch for manure (8–12 piles a day is normal) ([UF VM275, p. 4](lib:first-aid-for-horse-owners#page=4)).

**[Choke](wiki:Choke_(horse))** (feed stuck in the gullet) — saliva and feed running from the nose ([🖼️ photo](lib:first-aid-for-horse-owners#page=4)), retching, sometimes a lump
you can see or feel in the neck. It can still breathe. Remove **all** feed and water, keep it on bare
ground or muzzle it, gently massage a visible lump; many cases clear in a couple of hours. Watch
for fever over 101.5 °F or coughing in the days after — food in the lungs causes pneumonia
([UF VM275, pp. 4–5](lib:first-aid-for-horse-owners#page=5)).

**Wounds:** hose with cold water, pat dry, apply antiseptic. For heavy bleeding use a **pressure
bandage, not a tourniquet**; a horse can lose up to 4 gallons of blood without severe stress.
Watch for **[proud flesh](wiki:Granulation_tissue)** (red, lumpy tissue) in wounds over joints
([PNW 587, p. 30](lib:the-4-h-horse-project#page=30)).

**Eyes:** rinse gently with saline (1 teaspoon salt in a pint of boiled water —
[*Raising Healthy Horses*, p. 9](lib:raising-healthy-horses#page=9)) or weak-tea-colored dilute
betadine. **Never alcohol or chlorhexidine near the eye**, and no steroid ointments. Put on a fly
mask ([UF VM275, pp. 5–6](lib:first-aid-for-horse-owners#page=5); [🖼️ a painful eye](lib:first-aid-for-horse-owners#page=5)).

**Swollen face, noisy breathing** (snakebite, bee sting): horses can't breathe through the mouth.
Cut two pieces of soft hose as long as from the inner corner of the eye to the nostril, lubricate
them, slide one into each nostril and tape them in place
([UF VM275, p. 6](lib:first-aid-for-horse-owners#page=6); [🖼️ photo](lib:first-aid-for-horse-owners#page=6)).

**Donkeys hide illness.** **A dull donkey off its feed is an emergency** — it can fall into
*hyperlipaemia* (fat flooding the blood) and die. Coax it to eat with fresh grass or favorite food
and warm water. When a donkey loses its companion, **let it stay with the body until it loses
interest**, and watch it closely for three weeks
([*Donkey Care Handbook*, pp. 108–110](lib:donkey-care-handbook#page=109)).

**When a horse can't be saved,** the UF guide shows humane gunshot placement and how to confirm
death ([UF VM114](lib:humane-euthanasia-of-sick-and-injured-livestock)); see also the Illinois
Valley page.

📚 **Go deeper:** [UF *First Aid for Horse Owners* VM275](lib:first-aid-for-horse-owners#page=1) — colic, choke, eyes, breathing, wounds, do's and don'ts; [*Raising Healthy Horses*](lib:raising-healthy-horses#page=8) — normal values, medical kit and diseases; [*Where There Is No Animal Doctor*](lib:where-there-is-no-animal-doctor) — livestock medicine with no vet; [4-H PNW 587](lib:the-4-h-horse-project#page=28) — vital signs, first-aid kit, vaccinations. Pictures: [Horse colic](wiki:Horse_colic).

## 🎒 Travel and packing

| | |
|---|---|
| Walk / trot | about 4 mph / 8–9 mph |
| Steady day's travel | 20+ miles on easy ground, 10–15 in mountains |
| Rider | no more than about **20% of the horse's weight** (250 lb max) |
| Pack load | **200–250 lb** per 900–1,000-lb animal; 300 lb only short-distance |
| Load balance | side packs within **2–3 lb** of each other |

([FM 25-5](lib:animal-transport-war-dept-fm-25-5); [FM 25-7](lib:pack-transportation-war-dept-fm-25-7); [USFS *Instructions on Horse Packing*, pp. 2, 20](lib:instructions-on-horse-packing#page=20); [Montana outfitters manual](lib:packing-services-reference-manual))

- **On the road:** rest 5–10 minutes every hour; every 2–3 hours unsaddle, let the horse roll and
  graze. Walk them up steep hills. Only hardened horses can do 40–50 miles a day for days on end.
  **Condition animals 2–4 weeks** before hard travel. (*Animal Management*)
- **Packing:** sawbuck and Decker [pack saddles](wiki:Pack_saddle) ([🖼️ Decker](lib:instructions-on-horse-packing#page=22), [🖼️ sawbuck](lib:instructions-on-horse-packing#page=25)), hitches and loading are in the 1943 Forest Service
  manual (written for Oregon and Washington) and FM 25-7, which also shows **improvised pack
  saddles and a [travois](wiki:Travois)** ([🖼️ pack saddle improvised from horseshoes](lib:pack-transportation-war-dept-fm-25-7#page=164)).
- **Lighter loads** when breaking in a pack string, on long or fast trips, or on steep rough trail.
  **Check balance** by lifting one side so the load rocks: it should ride free, not settle to one
  side ([USFS, p. 20](lib:instructions-on-horse-packing#page=20)).
- **Sore backs and poor feeding** are the most common reasons pack stock break down
  ([USFS, p. 2](lib:instructions-on-horse-packing#page=2)).
- **In camp:** water before feeding, hay before grain, feed small amounts at least three times a
  day. Turn animals loose in a corral or pasture at night if you can — a horse tied out on a cold
  night can't move to keep warm ([USFS, p. 3](lib:instructions-on-horse-packing#page=3)).

📚 **Go deeper:** [USFS *Instructions on Horse Packing* (1943, Oregon–Washington)](lib:instructions-on-horse-packing#page=2) — pack stock, sawbuck and Decker gear, loads and hitches; [FM 25-7 *Pack Transportation*](lib:pack-transportation-war-dept-fm-25-7) — lashed loads, march rates, improvised saddles and travois; [Montana *Packing Services Reference Manual*](lib:packing-services-reference-manual) — modern conditioning and Decker packing. Pictures: [Diamond hitch](wiki:Diamond_hitch).

## 🚜 Harness and draft work

- **What an animal can pull all day:** about **one-tenth of its body weight** in steady draft
  (a big horse pulling 150 lb at 2½ mph ≈ 1 horsepower). Donkeys pull about a fifth of their
  weight for 3–4 hours. A cart donkey should pull no more than twice its weight, cart included, on
  the flat. ([Peace Corps *Animal Traction*, p. 20](lib:animal-traction-peace-corps#page=20); *Donkey Care Handbook*)
  *Sources differ:* Starkey quotes 15% of body weight as normal pulling power for horses
  ([Starkey, p. 118](lib:harnessing-and-implements#page=118)).
- **Collar fit:** a flat hand should just pass between the [collar](wiki:Horse_collar) and the windpipe
  ([🖼️ drawing](lib:care-and-management-of-farm-work#page=17)). A short collar
  chokes; a long one bruises the shoulders. Give each horse its own collar and wipe it after
  every use. **Sore shoulders are the #1 harness problem.** (USDA FB1419; FM 25-5; [🖼️ where collar sores form](lib:animal-transport-war-dept-fm-25-5#page=157))
- **Harness, hitching, driving pairs and teams, carts, plows and sledges:** FM 25-5, *Mounted
  Instruction for Field Artillery*, the Peace Corps *Animal Traction* manual and Starkey's
  *Harnessing and Implements* ([🖼️ harnessing options](lib:harnessing-and-implements#page=33)). Big-team hitches and [eveners](wiki:Whippletree): Sommerfeld's
  *How to Hitch Horses* ([🖼️ five-horse evener](lib:how-to-hitch-horses#page=9); [🖼️ eveners for four horses](lib:harnessing-and-implements#page=21)).

**Preventing sore shoulders, step by step** ([USDA FB1419, pp. 17–20](lib:care-and-management-of-farm-work#page=17)):

1. **Fit:** flat hand at the windpipe, **fingertips at the sides** of the neck just above the
   shoulder points. A narrow collar pinches; a wide one rubs.
2. **Skip sweat pads** — they cause more sore shoulders than a clean, smooth collar.
3. **Set the hames** snug so the pull comes about **one-third of the way up** from the point of the
   shoulder ([🖼️ point of draft](lib:animal-traction-peace-corps#page=91); [🖼️ hames](lib:harness-making-hasluck#page=127)).
4. **Spring toughening:** for the first 2–3 weeks of work, wash the shoulders after work with warm
   water and mild soap, then rinse with cold water with a little salt in it.
5. **At midday,** lift the collar forward, wipe off sweat and dirt, and let the shoulders cool.
6. **Allow for winter hair and extra flesh** when fitting a collar in spring — the fit changes as
   the horse works down.

**Harness care:** hang it in a dry room; wipe the collar face after every use; once a year take it
apart, soak 15 minutes in lukewarm water with mild soap, clean, oil and restitch. Keep a repair kit:
punch, rivets, awls, needles, waxed thread, a clamp, spare leather, snaps and buckles
([FB1419, p. 18](lib:care-and-management-of-farm-work#page=18)).

📚 **Go deeper:** [USDA FB1419 *Farm Work Horses*](lib:care-and-management-of-farm-work#page=17) — collar fitting, sore shoulders, harness care; [Peace Corps *Animal Traction*](lib:animal-traction-peace-corps#page=20) — choosing and training draft animals, yokes, plows and carts; [Starkey *Harnessing and Implements*](lib:harnessing-and-implements#page=118) — harness systems and draft-force data; [Hasluck *Harness Making*](lib:harness-making-hasluck) — making collars and harness by hand. Pictures: [Horse harness](wiki:Horse_harness).

## 🧯 If this goes wrong

| Problem | Likely cause and fix |
|---|---|
| **Losing weight** | Check teeth, worms and the amount of hay first ([G1781, p. 4](lib:basics-of-feeding-horses#page=4)). Score body condition weekly. |
| **Won't drink in cold weather** | Warm the water to air temperature twice a day or add 1–2 oz salt to feed ([UGA B1356, p. 2](lib:basic-nutritional-guidelines#page=2)). |
| **Chewing wood, eating bedding** | Not enough long hay — at least 8–10 lb a day for a 1,000-lb horse ([G1781, p. 2](lib:basics-of-feeding-horses#page=2)). |
| **Scabs on the lower legs** | Mud fever — get the horse onto dry footing and keep the legs clean and dry ([EC1558, p. 2](lib:small-acreage-horse-farms#page=2)). |
| **[Laminitis](wiki:Laminitis) (founder) signs after bedding change** ([🖼️ a foundered foot, cut open](lib:a-text-book-of-horseshoeing#page=184)) | [Black walnut](wiki:Juglans_nigra) shavings — even 20% in the bedding — cause founder; remove them at once ([WSU, p. 27](lib:wsu-selected-poisonous-plants#page=27)). |

📚 **Go deeper:** [UGA B1356](lib:basic-nutritional-guidelines#page=1) — feeding mistakes that cause colic and founder; [OSU EC1558](lib:small-acreage-horse-farms#page=2) — mud, manure and horse health; [*Animal Management* (1908)](lib:animal-management-british-war-office) — sore backs, saddle and harness galls (old book: skip its medicines).

## ☠️ Local dangers

- **Toxic plants:** tansy ragwort, poison and water hemlock, foxglove and bracken fern — hungry
  horses on overgrazed pasture eat them. (`Wild-Plants\` and `Animals\` sheets)
- **Wildfire:** evacuate horses **early and in daylight**; practice loading into a trailer ahead
  of time. See the Illinois Valley page.

| Plant | Watch for | Why it matters |
|---|---|---|
| **[Tansy ragwort](wiki:Jacobaea_vulgaris)** | Yellow daisy-like flowers in flat clusters, ragged leaves, bad smell | Horses are especially sensitive. **As toxic dried in hay as fresh — and tastier.** Liver damage shows up months later ([WSNWCB, p. 24](lib:wsnwcb-protect-your-horses#page=24); [🖼️ photos](lib:wsnwcb-protect-your-horses#page=25)) |
| **[Poison hemlock](wiki:Conium_maculatum)** | Hollow stems with **purple blotches**, fern-like leaves, rank smell when crushed | Less than a pound can kill a 1,000-lb animal in 2–3 hours; stays toxic in hay up to 3 years ([WSNWCB, p. 34](lib:wsnwcb-protect-your-horses#page=34); [🖼️ photos of both hemlocks](lib:wsnwcb-protect-your-horses#page=35)) |
| **[Water hemlock](wiki:Cicuta_douglasii)** | Wet ground; thick, **chambered** stem base | **A single mouthful can kill in 15 minutes**; roots most toxic ([WSNWCB, p. 34](lib:wsnwcb-protect-your-horses#page=34)) |
| **[Bracken fern](wiki:Pteridium_aquilinum)** | Big triangular fronds, in woods and open ground | 2–5 lb a day for weeks causes staggers; also toxic in hay ([WSNWCB, p. 36](lib:wsnwcb-protect-your-horses#page=36); [🖼️ photos](lib:wsnwcb-protect-your-horses#page=37)) |
| **[Yellow starthistle](wiki:Centaurea_solstitialis)** | Gray-woolly plant, yellow flowers with inch-long spines | "Chewing disease" — horses can't eat or drink; poor outlook ([WSNWCB, p. 26](lib:wsnwcb-protect-your-horses#page=26)) |
| **[Foxglove](wiki:Digitalis_purpurea)** | Tall spikes of spotted pink-purple bells | Heart poison, fresh or dried ([WSU, p. 28](lib:wsu-selected-poisonous-plants#page=28)) |
| **[Yew](wiki:Taxus)** | Flat glossy needles, red berries — garden shrubs | **Hedge trimmings thrown to stock kill fast** ([WSU, p. 2](lib:wsu-selected-poisonous-plants#page=2)) |

**If you suspect poisoning** ([WSNWCB, p. 4](lib:wsnwcb-protect-your-horses#page=4)): move the animal
to shade with clean water and clean hay and keep it calm; **collect a sample of the plant** (gloves,
sealed bag with a dry paper towel); find the source. **Pulled or sprayed plants become more
tempting as they wilt** — bag them and put them in the trash, never in compost or the pasture.
When buying hay, **break open several bales** and look for weeds; refuse gray or dusty bales —
the dust is often mold ([p. 56](lib:wsnwcb-protect-your-horses#page=56)).

**Wildfire plan for horses:**

- **Go-kit:** halters and lead ropes for every animal, feed and hay, water buckets, medical and
  vaccination records, ID, wire cutters, shovel and flashlights
  ([Oregon ODA](lib:wildfire-prep-for-pets-and-livestock#page=2)).
- **When you evacuate,** photograph each trailer load and record which animals go where
  ([PNW783, p. 8](lib:wildfires-smoke-and-livestock#page=8)).
- **If they must stay:** put them in a heavily grazed (low-fuel) pasture, leave sprinklers running,
  **open the gates** so they can move, leave 7–10 days of feed and water, and shut off power and
  propane ([PNW783, p. 8](lib:wildfires-smoke-and-livestock#page=8)).
- **After the fire,** check burns, smoke damage, feed and water before bringing them home
  ([ODA *Caring for Livestock After Wildfire*](lib:caring-for-livestock-after-wildfire)).

📚 **Go deeper:** [WSNWCB *Protect Your Horses and Livestock from Toxic Plants*](lib:wsnwcb-protect-your-horses#page=4) — color ID and symptoms; [WSU Tansy Ragwort](lib:tansy-ragwort-wsu) — identifying and controlling ragwort; [USDA *Plants Poisonous to Livestock*](lib:plants-poisonous-to-livestock-in-the-western-states) — western poisonous plants with photos; [PNW783 *Wildfires, Smoke and Livestock*](lib:wildfires-smoke-and-livestock#page=8) — evacuate or shelter in place.

---

*Old military feeding rules assume plenty of oats and hay; scale rations to what you can grow,
and watch body condition.*

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**The animal**
- Points of the horse — [🖼️ USDA FB 779, p. 5](lib:how-to-select-a-sound-horse#page=5); [🖼️ FM 25-5, p. 89](lib:animal-transport-war-dept-fm-25-5#page=89); [Equine anatomy](wiki:Equine_anatomy)
- Points of the donkey — [🖼️ *Donkey Care Handbook*, p. 15](lib:donkey-care-handbook#page=15); [Donkey](wiki:Donkey); [Mule](wiki:Mule); [Hinny](wiki:Hinny)
- Where unsoundness shows — [🖼️ FB 779, p. 6](lib:how-to-select-a-sound-horse#page=6); [Equine conformation](wiki:Equine_conformation)
- Age by the teeth — [🖼️ FB 779, p. 7](lib:how-to-select-a-sound-horse#page=7); [🖼️ p. 8](lib:how-to-select-a-sound-horse#page=8); [🖼️ p. 10](lib:how-to-select-a-sound-horse#page=10); [🖼️ AIB 353, p. 18](lib:horsemanship-and-horse-care-usda-aib-353#page=18); [Horse teeth](wiki:Horse_teeth)
- Weight tape and body condition — [🖼️ Nebraska G1781, p. 2](lib:basics-of-feeding-horses#page=2); [🖼️ p. 3](lib:basics-of-feeding-horses#page=3)
- Dry lot, mud footing and pasture regrowth — [🖼️ OSU EC1558, p. 4](lib:small-acreage-horse-farms#page=4); [🖼️ p. 5](lib:small-acreage-horse-farms#page=5); [🖼️ p. 8](lib:small-acreage-horse-farms#page=8)

**Feet and shoeing**
- Parts of the hoof — [🖼️ NMSU B-707, p. 2](lib:evaluation-of-equine-hoof-care#page=2); [🖼️ Lungwitz, p. 67](lib:a-text-book-of-horseshoeing#page=67); [🖼️ FM 25-5, p. 161](lib:animal-transport-war-dept-fm-25-5#page=161); [Horse hoof](wiki:Horse_hoof)
- Inside the foot — [🖼️ FB 1535, p. 5](lib:farm-horseshoeing#page=5); [🖼️ under a donkey's foot, p. 123](lib:donkey-care-handbook#page=123)
- Picking out the feet — [🖼️ *Donkey Care Handbook*, p. 91](lib:donkey-care-handbook#page=91); [🖼️ p. 94](lib:donkey-care-handbook#page=94); [Thrush](wiki:Thrush_(horse))
- Trimming, before and after — [🖼️ FB 1419, p. 20](lib:care-and-management-of-farm-work#page=20); [🖼️ FB 1535, p. 7](lib:farm-horseshoeing#page=7); [🖼️ p. 10](lib:farm-horseshoeing#page=10)
- Hoof cutter, rasp, nailing and clinching — [🖼️ FB 1535, p. 8](lib:farm-horseshoeing#page=8); [🖼️ p. 9](lib:farm-horseshoeing#page=9); [🖼️ p. 11](lib:farm-horseshoeing#page=11); [🖼️ a well-fitted shoe, NMSU p. 3](lib:evaluation-of-equine-hoof-care#page=3); [Horseshoe](wiki:Horseshoe)
- Founder — [🖼️ Lungwitz, p. 184](lib:a-text-book-of-horseshoeing#page=184); [Laminitis](wiki:Laminitis)

**Handling and first aid**
- Quick-release knot — [🖼️ 4-H PNW 587, p. 51](lib:the-4-h-horse-project#page=51); [🖼️ *Donkey Care Handbook*, p. 84](lib:donkey-care-handbook#page=84); [Halter hitch](wiki:Halter_hitch)
- Holding the reins; tack — [🖼️ FM 25-5, p. 47](lib:animal-transport-war-dept-fm-25-5#page=47); [Bridle](wiki:Bridle); [Western saddle](wiki:Western_saddle)
- Floating the teeth by hand — [🖼️ Merillat, p. 197](lib:animal-dentistry-and-diseases-of-the-mouth#page=197); [Equine dentistry](wiki:Equine_dentistry)
- Vital signs and the physical exam — [🖼️ UF VM275, p. 2](lib:first-aid-for-horse-owners#page=2); [🖼️ p. 3](lib:first-aid-for-horse-owners#page=3)
- Colic, choke, eye pain, breathing tubes — [🖼️ UF VM275, p. 4](lib:first-aid-for-horse-owners#page=4); [🖼️ p. 5](lib:first-aid-for-horse-owners#page=5); [🖼️ p. 6](lib:first-aid-for-horse-owners#page=6); [Horse colic](wiki:Horse_colic)
- Toxic plants — [🖼️ WSNWCB, p. 25 (tansy)](lib:wsnwcb-protect-your-horses#page=25); [🖼️ p. 35 (hemlocks)](lib:wsnwcb-protect-your-horses#page=35); [🖼️ p. 37 (bracken)](lib:wsnwcb-protect-your-horses#page=37); [Tansy ragwort](wiki:Jacobaea_vulgaris); [Poison hemlock](wiki:Conium_maculatum)

**Packing**
- Decker packsaddle and Decker tie — [🖼️ USFS 1943, p. 22](lib:instructions-on-horse-packing#page=22); [🖼️ p. 24](lib:instructions-on-horse-packing#page=24); [🖼️ p. 25](lib:instructions-on-horse-packing#page=25)
- Sawbuck saddle — [🖼️ USFS 1943, p. 25](lib:instructions-on-horse-packing#page=25); [🖼️ FM 25-7, p. 163](lib:pack-transportation-war-dept-fm-25-7#page=163); [Pack saddle](wiki:Pack_saddle)
- Diamond hitch — [🖼️ USFS 1943, p. 27](lib:instructions-on-horse-packing#page=27); [🖼️ FM 25-7, p. 162](lib:pack-transportation-war-dept-fm-25-7#page=162); [Diamond hitch](wiki:Diamond_hitch)
- Improvised pack saddle and pack-saddle designs — [🖼️ FM 25-7, p. 164](lib:pack-transportation-war-dept-fm-25-7#page=164); [🖼️ Starkey, p. 82](lib:harnessing-and-implements#page=82); [Travois](wiki:Travois)

**Harness and draft work**
- Collar fit and collar sores — [🖼️ FB 1419, p. 17](lib:care-and-management-of-farm-work#page=17); [🖼️ FM 25-5, p. 157](lib:animal-transport-war-dept-fm-25-5#page=157); [Horse collar](wiki:Horse_collar)
- Collar, hames and point of draft — [🖼️ Peace Corps *Animal Traction*, p. 91](lib:animal-traction-peace-corps#page=91); [🖼️ Hasluck, p. 127](lib:harness-making-hasluck#page=127); [🖼️ Starkey, p. 33](lib:harnessing-and-implements#page=33); [Horse harness](wiki:Horse_harness)
- Swingletrees and eveners — [🖼️ Starkey, p. 29](lib:harnessing-and-implements#page=29); [🖼️ p. 21](lib:harnessing-and-implements#page=21); [🖼️ Sommerfeld, p. 9](lib:how-to-hitch-horses#page=9); [Whippletree](wiki:Whippletree)
- Sledges and carts — [🖼️ Starkey, p. 83](lib:harnessing-and-implements#page=83); [Draft horse](wiki:Draft_horse)
- Harness-making tools — [🖼️ Hasluck, p. 26](lib:harness-making-hasluck#page=26); [🖼️ p. 28](lib:harness-making-hasluck#page=28); [Horse tack](wiki:Horse_tack)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local vets, wildfire, animal vital signs and euthanasia
- [Blacksmithing guide](guide:BLACKSMITHING-GUIDE) — forging shoes, nails and tools
- [Root Cellar guide](guide:ROOT-CELLAR-GUIDE) — dry, rodent-proof storage for grain and feed
- [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — growing and storing grain
- [Nuclear Fallout guide](guide:NUCLEAR-FALLOUT-GUIDE) — sheltering stock and protecting feed and water
- [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — leather, rope and repairs without stores
