# 🛡️ Home & Property Protection (Defensive Only)

How to keep your family, home, food, tools and animals from being easy targets when no deputy is
coming: looking like a poor choice to thieves, hearing trouble early, slowing people down, getting
everyone to safety, calling the neighbors, and staying within Oregon law. This guide is **strictly
defensive**. On purpose, it has nothing on fighting, patrolling or building traps. The books are in
`Southern-Oregon\Home-Security\` (`Home-Hardening`, `Safe-Room`, `Neighborhood-Watch`,
`Rural-Property`, `Law`), with the watch and de-escalation books in `Southern-Oregon\Community-Barter\`
and guardian-dog books in `Southern-Oregon\Animals\Planning-Predators-Toxic-Plants`.

> ### ⚠️ Rules that prevent the worst outcomes
> - **Never booby-trap anything: no spring guns, tripwires, spikes or rigged doors.** Traps can't
>   tell a thief from a child, a firefighter or a neighbor coming to help. In 2018 a man in
>   **Williams** (here in Josephine County) rigged a house with shotgun traps. One went off into an
>   FBI bomb technician's leg, and in 2023 he got **150 months in federal prison**
>   *(U.S. Attorney's Office, District of Oregon, 2023)*. See [the law](#oregon-law-on-force-in-defense-of-people-and-property).
> - **Don't shoot at property, or at anyone who is not an immediate deadly threat to a person.**
>   Oregon never allows deadly force to stop theft or damage to property (ORS 161.229).
> - **Know who is on your land before you do anything.** At night the "intruder" may be a neighbor, a
>   lost child, a confused elder or someone running from a fire.
> - **Keep firearms locked away from children and thieves.** It's Oregon law (ORS 166.395).
> - **A person's life is worth more than any property.** Let things go. Physical force is "never
>   recommended" except to stop an injury ([De-escalation, p. 4](lib:using-verbal-de-escalation#page=4)).
> - **Avoid confrontation and call the neighbors.** Watchers "should never confront suspicious
>   persons" ([Watch Manual, p. 20](lib:neighborhood-watch-manual#page=20)).

---

## 🧅 Layers: deter, detect, delay, respond

Think of protection as **layers**. Each one makes a thief more likely to give up or be seen, and
buys your family time. The Watch Manual compares it to sports: "the more defenses a team has... the
less likely the opponent will be to score" ([Watch Manual, p. 32](lib:neighborhood-watch-manual#page=32)).

| Layer | What it means | On a Valley lot *(examples)* |
|---|---|---|
| **Deter** | Make your place look like a poor choice | Someone home, a dog, no supplies on show, a locked gate |
| **Detect** | Know early that someone is coming | Dog, geese, gate bell, gravel, motion light, radio check-ins |
| **Delay** | Slow them down | Strong doors and strike plates, locked outbuildings, pinned windows |
| **Respond** | Protect people, not things | Safe room or escape, whistle alarm, neighbors on the radio |

**Why layers matter more out here:**
- **Secluded houses are attractive targets**: set back on large lots, they "reduce the chance that
  neighbors or passersby will see or hear a burglar"
  ([COPS *Burglary*, p. 22](lib:burglary-of-single-family-houses#page=22); [🖼️ photo](lib:burglary-of-single-family-houses#page=22)).
- **Devices work best together.** Burglars get in less often when a house has **two or more**
  (window locks, deadbolts, lights, alarms), and the devices "slow them down, making them more
  vulnerable to being seen" ([p. 25](lib:burglary-of-single-family-houses#page=25)).
- **Help is far away.** Each layer must buy time for the family to reach safety *(rule of thumb)*.

"Respond" in this guide never means going out to fight. It means **getting people safe and getting
help.**

📚 **Go deeper:** [COPS *Burglary of Single-Family Houses*, pp. 20–25](lib:burglary-of-single-family-houses#page=20) — what the research says about which houses get picked; [*Neighborhood Watch Manual*, ch. 9](lib:neighborhood-watch-manual#page=32) — basic home "target hardening".

## 🤫 Don't be a target

**Look lived-in.** "Most burglars do not target occupied houses, taking great care to avoid them";
some ring the doorbell first to check ([COPS *Burglary*, p. 20](lib:burglary-of-single-family-houses#page=20)).
So:
- **Someone home most of the time**, **no set times** when everyone leaves, and be seen around the
  property often ([WSDA *Farm Security*, p. 1](lib:general-farm-security#page=1)).
- **Never announce who is away** ([Watch Manual, p. 21](lib:neighborhood-watch-manual#page=21)).
- **No spare key under the mat** or in the car. Leave one with a trusted neighbor
  ([Seattle Police, *Outside the Home*, p. 2](lib:deterring-burglary-from-outside#page=2)).

**Don't advertise supplies.** Burglars read a house's contents from what they can see outside
([COPS *Burglary*, p. 25](lib:burglary-of-single-family-houses#page=25)). After a collapse the "signs
of wealth" change *(rule of thumb)*:

| Gives you away | Quieter way *(rule of thumb)* |
|---|---|
| Bright windows when every other house is dark | Curtains or blankets over lit rooms (cover windows people can see into: [Seattle Police](lib:home-security-window-security#page=1)) |
| A generator roaring every evening | Run it in daylight, only as needed, **outdoors and away from windows** (carbon monoxide). See the [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE) |
| Cooking smoke and smells at all hours | Cook at the same times as the neighbors |
| Empty food boxes and fuel cans by the road | Burn, compost or bury packaging well back from the road |
| Talking about your stores at trades | Keep amounts private. Share through the group, not at the roadside |

**Quiet sharing.** Hungry people steal, so fair sharing prevents theft
([Community guide](guide:COMMUNITY-BARTER-GUIDE#settling-disputes-and-dealing-with-theft)). Give through the
group or a welcome point (below), so no one house becomes "the place with food" *(rule of thumb)*.

**What to say to strangers** *(rule of thumb)*: friendly and short. "We're getting by like everyone.
The table at the crossroads has water and news." **Don't say** how many live here, who is away, what
you have, or that you're armed.

📚 **Go deeper:** [COPS *Burglary*, p. 20](lib:burglary-of-single-family-houses#page=20) — occupancy and how burglars check; [Seattle Police, *Deterring Burglary From Outside the Home*](lib:deterring-burglary-from-outside#page=1) — looking at your home "through the eyes of a burglar".

## 🚪 Doors, frames, locks and windows

**Doors get kicked, not picked.** "The most common way used to force entry through a door with a
wooden jamb is to kick it open." The weak point is "almost always the **strike plate**," which is
held only by short screws into thin trim ([Seattle Police, *Door Security*](lib:home-security-door-security#page=1);
[🖼️ how a strike plate sits in the jamb](lib:wood-frame-house-construction#page=147)).

**The cheapest big fix** ([Seattle, *Door Security*](lib:home-security-door-security#page=1)):
1. Take out the short screws in every exterior door's **strike plates and hinges**.
2. Put in **3- to 4-inch wood screws** that bite into the wall stud. "This one step alone will deter
   or prevent most through-the-door forced entries."
3. Better still, fit a **four-screw heavy-duty strike plate**, plus at least one long screw in each
   hinge.
4. Against pry bars, add a **latch guard** over the gap where the bolt meets the frame ([🖼️ photo](lib:home-security-door-security#page=1)).

**Doors and locks** ([Watch Manual, pp. 32–33](lib:neighborhood-watch-manual#page=32)):
- Exterior doors **metal or solid wood**. Hollow-core or poorly fitting doors "can mean trouble"
  ([🖼️ door types](lib:wood-frame-house-construction#page=84); [🖼️ door and frame cross-section](lib:wood-frame-house-construction#page=83)).
- A **[deadbolt](wiki:Deadbolt)** with a bolt that sticks out **at least 1 inch**, on every outside
  door *and the door from the garage into the house*.
- **Hinges on the inside**, or pins that can't be pulled. Exterior doors carry **3 hinges**
  ([USDA AH 73, p. 146](lib:wood-frame-house-construction#page=146); [🖼️ hinge drawing](lib:fm-5-426-carpentry#page=139)).
- **Change the locks** when a place changes hands.
- **Double-cylinder** deadbolts (key both sides) only where a thief could break glass and reach the
  thumb-turn, and **keep the key in the inside lock while anyone is home** so you can get out in a fire
  ([Seattle, *Door Security*](lib:home-security-door-security#page=1)).
- A **door viewer** ([peephole](wiki:Peephole)) lets you see and talk without opening *(general practice)*.

**Windows have latches, not locks** ([Seattle, *Window Security*](lib:home-security-window-security#page=1)):
- **Double-hung windows** ([🖼️ drawing](lib:wood-frame-house-construction#page=75); [sash window](wiki:Sash_window)): drill a
  hole down through the inner sash into the outer one and drop in a **sash pin**, a long nail or an Allen
  wrench ([🖼️ photos](lib:home-security-window-security#page=1)). A second hole 5 inches up lets you pin it
  open for air.
- **[Sliding glass doors](wiki:Sliding_glass_door) and sliding windows**: a snug **dowel** or a hinged
  "Charlie bar" in the inside track, plus **screws half-way into the top track** so the panel can't be
  lifted out ([🖼️ p. 2](lib:home-security-window-security#page=2)).
- **Security [window film](wiki:Window_film)** makes glass shatterproof ([p. 2](lib:home-security-window-security#page=2)).
- **Bars on bedroom windows must open from the inside.** Every sleeping room needs a way out in a fire
  ([p. 2](lib:home-security-window-security#page=2)). Nails in windows are a fire hazard
  ([Watch Manual, p. 33](lib:neighborhood-watch-manual#page=33)).

**Garages and outbuildings:**
- About a third of burglars force nothing. They walk in through **unlocked doors and windows,
  especially garage and basement ones** ([COPS *Burglary*, p. 26](lib:burglary-of-single-family-houses#page=26)).
  **Lock the door between the garage and the house** ([Watch Manual, p. 33](lib:neighborhood-watch-manual#page=33)),
  and keep the garage shut ([🖼️ why](lib:burglary-of-single-family-houses#page=27)).
- Lock sheds with a **hasp and [padlock](wiki:Padlock)**, and lock up **ladders and tools**
  ([Seattle, *Outside the Home*, p. 2](lib:deterring-burglary-from-outside#page=2)).

📚 **Go deeper:** [Seattle Police *Door Security*](lib:home-security-door-security#page=1) — strike plates, screws, deadbolts on one page; [Seattle Police *Window Security*](lib:home-security-window-security#page=1) — every window type; [USDA *Wood-Frame House Construction*, pp. 141–147](lib:wood-frame-house-construction#page=146) — how doors, frames and hardware go together.

## 🌳 Fences, gates, lighting and sightlines

**The three CPTED ideas** ([Crime prevention through environmental design](wiki:Crime_prevention_through_environmental_design);
[COPS *CPTED*, pp. 15, 17–19](lib:using-crime-prevention-through-environmental-design#page=17)):
1. **Control access.** "Fences, tree lines, hedges, or berms define the boundaries"; drives and paths
   guide people; "gates and doors limit points of entry."
2. **See and be seen.** Lighting, windows that look out on the approaches, and plants chosen and
   trimmed so views are kept open ([p. 18](lib:using-crime-prevention-through-environmental-design#page=18)).
3. **Show ownership.** Gardens and upkeep "show that someone cares and is paying attention"
   ([p. 19](lib:using-crime-prevention-through-environmental-design#page=19)).

**Sightlines and brush, with fire safety first.** Dense shrubs and privacy fences near doors and
windows give a burglar cover ([COPS *Burglary*, p. 21](lib:burglary-of-single-family-houses#page=21)).
Seattle Police use a **3/6 rule**: shrubs under 3 ft, tree limbs above 6 ft
([*Outside the Home*, p. 1](lib:deterring-burglary-from-outside#page=1); [🖼️ pictures](lib:deterring-burglary-from-outside#page=1)).
Here the stricter fire rules win:
- **Limbs on mature trees at least 10 ft up**, none over the roof ([OSU EM 9184, p. 8](lib:osu-em-9184#page=8)).
- **Nothing that burns within 5 ft of the house** ([Ready Set Go, p. 4](lib:ready-set-go-wildland#page=4);
  [🖼️ the zones](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=23)). Seattle suggests thorny
  [Oregon grape](wiki:Berberis_aquifolium) under windows; here, plant only **beyond 5 ft**, and pick
  fire-resistant shrubs ([OSU PNW 590](lib:osu-pnw-590-fire-resistant-plants-for-home-landscapes#page=9)).
- **Clear brush that hides the driveway approach**: **10 ft side clearance, 13.5 ft overhead**, so a
  fire engine fits ([OSU EM 9184, p. 8](lib:osu-em-9184#page=8); [wildfire section](guide:ILLINOIS-VALLEY-START-HERE#wildfire)).

**Fences and gates:**
- The boundary "is the property owner's primary line of defense." Make **gates strong, mounted
  securely, and locked with heavy chain and padlock**; use ditches, large rocks or locking posts to
  close side gaps ([WSDA *Farm Security*, p. 1](lib:general-farm-security#page=1)).
- A solid privacy fence hides a burglar. **See-through fencing** such as [chain-link](wiki:Chain-link_fencing)
  keeps the view open ([Seattle, *Outside the Home*, p. 2](lib:deterring-burglary-from-outside#page=2)).
- **Make sure helpers can get in.** Neighbors and the fire crew must be able to open or cut the gate
  fast *(rule of thumb)*. Skip razor wire or spikes where children or firefighters might climb.

**Lighting** ([security lighting](wiki:Security_lighting)): enough to see about **100 ft** at the
entry, with **motion lights** on side and back yards ([Seattle, p. 1](lib:deterring-burglary-from-outside#page=1)).
On a secluded lot a **[motion-activated](wiki:Motion_detector) light** works as an alert, while steady
light only helps if someone is there to see ([COPS *Burglary*, p. 22](lib:burglary-of-single-family-houses#page=22)).
With no grid, aim **[solar lights](wiki:Solar_lamp)** along the approaches ([Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE)).

**Signs and address:** "No Trespassing" signs define the boundary ([WSDA, p. 1](lib:general-farm-security#page=1)),
but signs "are only good if you can back them up" ([Seattle, p. 2](lib:deterring-burglary-from-outside#page=2)).
Keep a **reflective address sign** visible from both directions, day and night, so neighbors and
responders find you ([OSU EM 9184, p. 8](lib:osu-em-9184#page=8)).

📚 **Go deeper:** [COPS *Using CPTED in Problem Solving*](lib:using-crime-prevention-through-environmental-design#page=15) — the three CPTED ideas with checklists; [OSU EM 9184](lib:osu-em-9184#page=8) — seasonal checklists for brush, driveways and address signs; [WSDA *General Farm Security*](lib:general-farm-security#page=1) — boundaries, gates and outlying fields.

## 🔔 Early warning with no grid

**Dogs.** "A dog's presence is a close substitute for human occupancy, and most burglars avoid houses
with dogs." Small dogs bark and draw attention ([COPS *Burglary*, pp. 20–21](lib:burglary-of-single-family-houses#page=20)).
"A good watch dog in the house and yard area is one of the best security measures"
([WSDA, p. 1](lib:general-farm-security#page=1); [Guard dog](wiki:Guard_dog)).

**Livestock guardian dogs guard stock, not people.** Common breeds are the **Great Pyrenees,
Anatolian Shepherd, Maremma and Akbash** ([Texas A&M, p. 5](lib:livestock-guardian-dogs-overview#page=5);
[Livestock guardian dog](wiki:Livestock_guardian_dog); [Great Pyrenees](wiki:Pyrenean_Mountain_Dog);
[Anatolian Shepherd](wiki:Kangal_Shepherd_Dog); [Maremma](wiki:Maremmano-Abruzzese_Sheepdog); [🖼️ photo](lib:raising-healthy-sheep-cvm#page=133)).
**Socialize them** with people: unsocialized dogs may "harm employees" ([same page](lib:livestock-guardian-dogs-overview#page=5)).
Known problems include dogs **"overly aggressive to people"** and dogs that **roam onto neighbors'
land** ([USDA AIB 588, p. 28](lib:livestock-guarding-dogs-usda-aib588#page=28)). See the predator sections of the
[Rabbits & Chickens](guide:RABBITS-CHICKENS-GUIDE#predators-of-the-illinois-valley) and
[Goats, Dairy & Bees](guide:GOATS-DAIRY-BEES-GUIDE#fences-shelter-and-minerals) guides.

**Other alarm animals.** "Donkeys, [llamas](wiki:Llama) and cattle will sometimes protect sheep that graze
with them" ([*Raising Healthy Sheep*, p. 133](lib:raising-healthy-sheep-cvm#page=133);
[🖼️ guard llama](lib:raising-healthy-sheep-cvm#page=133)). **[Geese](wiki:Domestic_goose)** honk loudly at
strangers and are an old farm alarm *(general practice)*.

**Simple noise alarms** *(rule of thumb)*:
- A **bell on every gate and door** that rings when it opens.
- **Cans with pebbles tied to fence wire**, where people don't walk.
- **Gravel** on paths and under windows crunches underfoot.
- **Never string a line across a path, driveway or doorway.** It trips children, elders and
  firefighters in the dark, and it's one step from a trap.

**Lights and radios:**
- Battery or **solar motion lights** on the approaches (above).
- **Radio check-ins:** a set time each evening on FRS or GMRS. The local **Channel 3 Project** uses FRS
  channel 3 ([Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE); [Radio guide](guide:RADIO-GUIDE);
  [FRS](wiki:Family_Radio_Service)).
- **An alarm code everyone knows:** a string of short, sharp blasts on a whistle or
  [air horn](wiki:Air_horn) = "general alarm, act on the plan," and the horn is never used for
  anything else ([Signals guide](guide:SIGNALS-MORSE-GUIDE#whistles-bells-and-alarm-codes)).

📚 **Go deeper:** [USDA *Livestock Guarding Dogs* (AIB 588)](lib:livestock-guarding-dogs-usda-aib588#page=5) — choosing, raising and the problems to expect; [Texas A&M *LGD Overview*](lib:livestock-guardian-dogs-overview#page=5) — breeds and socializing; [COPS *Burglary*, p. 21](lib:burglary-of-single-family-houses#page=21) — dogs and alarms as substitutes for someone being home.

## 🏠 A safe room and a household plan

**A safe room is a place to wait behind a strong door while help comes.** It is not a place to
fight from.

**FEMA's full version.** [*Taking Shelter from the Storm* (FEMA P-320)](lib:taking-shelter-from-the-storm#page=41)
has plans for reinforced tornado rooms, which also make a strong hardened room:
- **Where:** a basement, a **bathroom, closet or laundry room**, or a separate room **within 150 ft**
  ([p. 41](lib:taking-shelter-from-the-storm#page=41); [🖼️ floor plans](lib:taking-shelter-from-the-storm#page=41)).
- **Size:** at least **3 sq ft per person** for a short stay, **7** for a long one, **10** for a
  wheelchair user ([p. 37](lib:taking-shelter-from-the-storm#page=37)).
- **Door:** ordinary steel house doors fail FEMA's tests; a real safe room needs a **tested, labeled
  door** ([p. 53](lib:taking-shelter-from-the-storm#page=53); [🖼️ label](lib:taking-shelter-from-the-storm#page=54)).
- **Cost:** about **$9,400–$25,500** new, plus the door, and more in an existing house ([p. 56](lib:taking-shelter-from-the-storm#page=56);
  [🖼️ construction drawings](lib:taking-shelter-from-the-storm#page=83)).

**The everyday version** *(rule of thumb, built from the door advice above)*:
- An **inside room** with a **solid-wood or metal door**, a **deadbolt**, and the **strike plate and
  hinges screwed into the studs with 3-inch screws**.
- **A second way out** (a window that opens from inside), a **[smoke alarm](wiki:Smoke_detector)** and a
  **[fire extinguisher](wiki:Fire_extinguisher)** ([🖼️ how to use one](lib:cert-basic-training#page=171)).
  **A locked room in a burning house is a death trap. If there is smoke, get out.**
- **Kept stocked** ([P-320, p. 69](lib:taking-shelter-from-the-storm#page=69)): **1 gallon of water per
  person per day**, food, first-aid kit and medicines, a flashlight for every 4 people, a battery radio,
  a portable toilet, a crowbar to open a jammed door, plus a **whistle or air horn and an FRS radio**.

**The household plan** *(rule of thumb; fill it in on the [Oregon *My Pocket Plan*](lib:oregon-oem-my-pocket-plan-2023))*:

| Decide now | Example |
|---|---|
| **Who goes where** | Kids and grandma to the back bedroom; one adult with the radio |
| **Who calls for help, and how** | Air horn, then FRS channel 3 to the neighbors |
| **Two ways out** | Front door; back bedroom window |
| **Outside meeting spot** | The neighbor's barn |
| **Code words** | "Safe room now," "all clear," and one that secretly means "I'm being forced, stay hidden" |

**Practice it**, once at night too, until the children know it *(rule of thumb)*.

📚 **Go deeper:** [FEMA P-320](lib:taking-shelter-from-the-storm#page=37) — sizing, locations and full building plans; [FEMA *Are You Ready?*, p. 62](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=62) — preparing a safe room.

## 🥫 Protecting food, water, fuel, tools and livestock

**Food and water:**
- Shared stores go in **locked, rodent-proof containers with a written in-and-out log**, and it takes
  **two people to open them** ([Community guide](guide:COMMUNITY-BARTER-GUIDE#settling-disputes-and-dealing-with-theft)).
- **Don't keep everything in one place.** Split stores between the house, the cellar and an
  outbuilding, so a thief or a fire takes only part *(rule of thumb)*.
- **A hidden cache** *(rule of thumb)*: sealed, rodent-proof containers of foods that keep
  ([Food Security guide](guide:FOOD-SECURITY-GUIDE#storing-it-for-years)). Tell one other adult where.
- **Lock the pump house** *(rule of thumb; [Wells guide](guide:WATER-WELLS-GUIDE))*.

**Fuel** ([WSDA, pp. 1–2](lib:general-farm-security#page=1)):
- **Lockable caps** on fuel outlets; fuel tanks, pumps and electric-fence units **secured and locked**.
- Place fuel tanks **where they can be seen from the house**. Keep stored fuel, chemicals and fertilizer
  "to a minimum" and locked up. Storage and safety: [Fuel guide](guide:FUEL-GUIDE).

**Tools, machinery and valuables:**
- **Mark everything in at least two places**, one easy to see and one hidden
  ([WSDA, p. 2](lib:general-farm-security#page=2)).
- **Operation ID** ([Watch Manual, p. 34](lib:neighborhood-watch-manual#page=34)): engrave your Oregon
  driver's license number starting with "OR" and ending with "DL". **Never your Social Security
  number.** Marked items are hard to sell, so burglars avoid them.
- **Keep a property list** with serial numbers and marks, plus **photos**, stored away from the things
  themselves ([p. 34](lib:neighborhood-watch-manual#page=34)).
- **Machinery:** take the keys out; remove the distributor cap, rotor or battery; chain it up; park it
  where a neighbor can see it ([WSDA, p. 1](lib:general-farm-security#page=1)).
- **Firearms are a top target.** Burglars steal "cash and goods they can easily carry and sell,"
  weapons included ([COPS *Burglary*, p. 25](lib:burglary-of-single-family-houses#page=25)). Lock them up
  ([the law](#oregon-law-on-force-in-defense-of-people-and-property)).

**Livestock:**
- **Mark every animal** with [ear tags](wiki:Ear_tag), ear notches or tattoos ([🖼️ marking goats' ears](lib:milk-goats-usda#page=33)),
  or [branding](wiki:Livestock_branding). Keep **records and photos** of each one, with births, deaths,
  buys and sales ([WSDA, p. 1](lib:general-farm-security#page=1)).
- **Check stock daily, at different times.** Keep loading ramps away from the road, and lock gates
  and ramps (same page).
- **At night, bring flocks into a predator-proof area near the home**
  ([*Raising Healthy Sheep*, pp. 132–133](lib:raising-healthy-sheep-cvm#page=132)). The same book notes
  that "theft from human predators is a problem in some places."

📚 **Go deeper:** [WSDA *General Farm Security*](lib:general-farm-security#page=1) — fuel, machinery, livestock and records on two pages; [*Neighborhood Watch Manual*, p. 34](lib:neighborhood-watch-manual#page=34) — Operation ID and property lists.

## 👥 Neighborhood watch after the collapse

How to set up a watch, block captains, the phone or runner tree, describing people and the night
shift table are all in the Community guide: **[Keeping watch](guide:COMMUNITY-BARTER-GUIDE#keeping-watch)**.
The key rules:
- **Watchers watch and report.** They "shall not carry weapons or pursue" and "should never confront
  suspicious persons" ([Watch Manual, p. 20](lib:neighborhood-watch-manual#page=20); [Neighborhood watch](wiki:Neighborhood_watch)).
- **What counts as suspicious** ([p. 24](lib:neighborhood-watch-manual#page=24)): someone peering into
  cars or windows, people at homes at unusual hours, tampering with gas, power or water, signs of forced
  entry, and "anything that feels uncomfortable or looks out of place."

**A roster that doesn't wear people out** *(rule of thumb, from the Community guide)*:
- **2-hour shifts in pairs**, the **same nights each week**, with a written handover. Protect
  watchers' daytime sleep ([*Ship's Medicine Chest*, p. 154](lib:ships-medicine-chest#page=154)).
- **Nobody stands watch two nights running.** Spread it across every capable adult; give elders,
  parents of babies and the sick lighter daytime jobs.
- **In fire season the watch is also the fire lookout.**

**Daily check-in:** post OK/HELP cards at the communication site
([MYN Rural, p. 2](lib:map-your-neighborhood-in-rural#page=2)), or follow the
[Signals guide's OK/HELP plan](guide:SIGNALS-MORSE-GUIDE#the-neighborhood-ok-help-plan).

**Checkpoints: a welcome point, not a roadblock** *(rule of thumb)*:
- **Never block a public road.** Obstructing "vehicular or pedestrian traffic on a public way" is
  disorderly conduct under Oregon law (ORS 166.025). Gates on your own driveway are fine.
- Put a **table at a crossroads turnout, on private land with permission**, with two calm, unarmed
  neighbors, a radio, water and a news board.
- **Everyone may pass.** Nobody is stopped or searched. The table offers news and help, and quietly
  notes **descriptions and vehicles** ([Watch Manual, p. 24](lib:neighborhood-watch-manual#page=24)).

**Helping people on the move** *(rule of thumb)*: meet them **at the welcome point, not your house**,
and give through the group. Use **look, listen, link**: check urgent needs, listen, connect them to help
([WHO *Psychological First Aid*, p. 25](lib:psychological-first-aid-guide-for-field-workers#page=25)).
Newcomers who stay join the group's work and barter rules ([Community guide](guide:COMMUNITY-BARTER-GUIDE)).

📚 **Go deeper:** [*Neighborhood Watch Manual*, pp. 20–24](lib:neighborhood-watch-manual#page=20) — patrol rules and what is suspicious; [MYN *Rural Settings*](lib:map-your-neighborhood-in-rural#page=1) — the rural check-in plan; [COPS *CPTED*, p. 19](lib:using-crime-prevention-through-environmental-design#page=19) — showing a neighborhood is cared for.

## 🚧 Someone at the gate, strangers, or a break-in

**Before you open anything:**
1. **Find out who it is**: through the viewer, a window, or by calling out.
2. **Talk through the closed door or gate. Don't open it.** Let them know someone is home; most
   burglars avoid occupied houses ([COPS *Burglary*, p. 20](lib:burglary-of-single-family-houses#page=20)).
3. **Point them to help that isn't your house**, such as the welcome point *(rule of thumb)*.

**If they're upset**, use the Community guide's
**[Calming an angry person](guide:COMMUNITY-BARTER-GUIDE#calming-an-angry-person)**: a slow, calm
voice, hands visible, never threats or ultimatums
([De-escalation, pp. 15–24](lib:using-verbal-de-escalation#page=15); [De-escalation](wiki:De-escalation)).

**If someone is trying to get in, or is already inside** *(rule of thumb)*:
1. **Sound the alarm**: air horn or whistle, a string of short blasts.
2. **Everyone goes to the safe room, or out the escape route** to the meeting spot. Take the kids
   and elders first.
3. **Call the neighbors** on the radio: who you are, where, what's happening.
4. **Stay put.** Don't go looking for the intruder. Let them take things. **Property can be
   replaced. People can't.**

**Remember what you saw** ([Watch Manual, p. 24](lib:neighborhood-watch-manual#page=24)): what
**can't be changed** (height, build, skin and eye color, scars, tattoos) and the vehicle's make, type
and plate. Write it down at once. "Never hesitate to say, 'I'm not sure.'"

**Afterwards** ([WSDA, p. 2](lib:general-farm-security#page=2)):
- Check everyone first, then give first aid ([Injuries guide](guide:FIELD-CARE-GUIDE)).
- **Don't disturb the point of entry.** Write down the facts and times, and list what's gone with
  serial numbers.
- **Report it** when you can: to the group now, to the sheriff when there is one.
- **A stolen firearm must be reported within 72 hours**, or within 24 hours of a way to report becoming
  available (ORS 166.397).
- Write down every threatening incident ([De-escalation, p. 23](lib:using-verbal-de-escalation#page=23)).
  Fix the weak point the intruder used.

📚 **Go deeper:** [*Using Verbal De-Escalation*](lib:using-verbal-de-escalation#page=15) — stance, voice and what never to say; [*Neighborhood Watch Manual*, p. 24](lib:neighborhood-watch-manual#page=24) — describing people and vehicles.

## ⚖️ Oregon law on force in defense of people and property

> **This is not legal advice.** It quotes the Oregon Revised Statutes (2025 edition, from
> oregonlegislature.gov) in plain words. Laws change, and courts decide each case on its facts.
> The key test in every section is what you "reasonably believe," and **other people judge that
> afterwards.**

| Situation | What the law says | In plain words |
|---|---|---|
| **Defending yourself or another person** (ORS 161.209) | You may use physical force against "what the person reasonably believes to be the use or imminent use of unlawful physical force," and only "a degree of force which the person reasonably believes to be necessary" | Only against a real, present attack, and only as much force as needed |
| **If you started it** (ORS 161.215) | No justification if you provoked it or were "the initial aggressor," unless you withdraw and make that clear | Starting a fight takes away your defense |
| **Deadly force** (ORS 161.219) | Only if you reasonably believe the other person is committing or attempting a felony that uses or threatens force against a person, or a **burglary in a dwelling**, or is using or about to use unlawful deadly force against a person | Reserved for a threat to people's lives and bodies |
| **Your land and buildings** (ORS 161.225) | Physical force to stop a criminal trespass when you reasonably believe it necessary. Deadly force only to defend a person (as above), or to prevent **arson** or "a felony by force and violence by the trespasser" | Trespassing alone never justifies deadly force |
| **Your things** (ORS 161.229) | "Physical force, other than deadly physical force," to stop theft or criminal mischief | **Never deadly force over property** |
| **Pointing a gun** (ORS 166.190) | Purposely pointing a loaded or empty firearm at someone "except in self-defense" is a crime | Don't wave guns at people at the gate |
| **Threatening** (ORS 163.190) | Menacing: trying "to place another person in fear of imminent serious physical injury" by word or conduct | Threats are a crime too |

"Deadly physical force" means force that "is readily capable of causing death or serious physical
injury" (ORS 161.015).

**Booby traps and spring guns.** No Oregon law allows them. A trap can't "reasonably believe" anything;
it hits whoever comes: a child, a firefighter, a neighbor coming to help. Setting one creates "a
substantial risk of serious physical injury to another person," which is **recklessly endangering**
(ORS 163.195), and if someone is hurt or killed the charges grow. Courts have long made trap-setters
pay even when the person hurt was a trespasser ([Katko v. Briney](wiki:Katko_v._Briney);
[Spring-gun](wiki:Spring-gun); [Booby trap](wiki:Booby_trap)). Then there's the Williams case in the
warning box at the top.

**Firearm storage: the Cindy Yuille and Steve Forsyth Act** ([SB 554 as passed](lib:oregon-senate-bill-554#page=1)):
- Whenever a firearm is **not carried by or under the control of** its owner or an authorized person,
  it must be secured with an **engaged trigger or cable lock**, in a **locked container**, or in a
  **locked gun room** (ORS 166.395; [trigger locks](wiki:Gun_safety), [gun safe](wiki:Gun_safe)).
- It is **not secured** if the key or combination is "readily available" to someone not authorized.
- The fine is higher if a **minor** gets an unsecured gun. If an unsecured gun is used to hurt someone
  within two years, the owner is treated as negligent in a lawsuit (with narrow exceptions).
- Report loss or theft within 72 hours (ORS 166.397). **Directly supervise** any minor you hand a
  firearm to, with some hunting and target-range exceptions (ORS 166.403).

**Training:** if you keep firearms, **get real training from a qualified instructor**. This guide
doesn't teach firearm use.

**Why it still matters when the courts are closed:** courts reopen, and in Oregon a prosecution for
murder or "any degree of manslaughter may be commenced at any time" (ORS 131.125). Neighbors remember,
too: a shooting over a chainsaw can start a feud that outlasts the emergency *(rule of thumb)*.

📚 **Go deeper:** [Oregon SB 554 (2021), enrolled](lib:oregon-senate-bill-554#page=1) — the full storage, theft-reporting and transfer law, with the legislature's reasons; ORS chapter 161 (sections 161.195–161.275) is quoted above from oregonlegislature.gov.

## 🔥 Fire as a threat to your home

A fire, whether set on purpose or blown in from the hills, can take everything at once. The defenses
are those in the [Illinois Valley wildfire section](guide:ILLINOIS-VALLEY-START-HERE#wildfire):
- **First 5 ft:** nothing that burns. **Firewood and lumber 30 ft away**
  ([OSFM, p. 13](lib:osfm-defensible-space-homeowner-guide-2025#page=13);
  [Defensible space](wiki:Defensible_space_(fire_control))).
- **Within 100 ft:** grass short, trees spaced, and no ladder fuels ([🖼️ drawing](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=21)).
- **Vents** covered with 1/8-inch metal mesh ([🖼️ how embers get in](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=40)).

**Water and tools ready** *(rule of thumb)*: full buckets or barrels, a charged hose if you have
pressure, shovels and rakes by the door, and a
[fire extinguisher](wiki:Fire_extinguisher) you know how to use (Pull, Aim, Squeeze, Sweep:
[🖼️ CERT, pp. 171–172](lib:cert-basic-training#page=171)).

**At night:** the watch looks for smoke and glow as well as people
([Community guide](guide:COMMUNITY-BARTER-GUIDE#keeping-watch)). **If the house is on fire, everyone
gets out.** Never stay in a safe room in a burning building.

📚 **Go deeper:** [OSFM *Defensible Space Homeowner Guide*](lib:osfm-defensible-space-homeowner-guide-2025#page=13) — the zones, step by step; [FEMA P-737](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=23) — hardening the house itself; [OSU EM 9184](lib:osu-em-9184#page=8) — year-round checklists.

## 😴 Stress, fatigue and judgment

The worst outcomes come from **tired, frightened people deciding fast in the dark** *(rule of thumb)*.
- **Sleep is protection.** Keep watch-standers on a **consistent schedule**
  ([*Ship's Medicine Chest*, p. 154](lib:ships-medicine-chest#page=154)).
- **Check rumors before acting.** Use the phone or runner tree to confirm facts
  ([Community guide](guide:COMMUNITY-BARTER-GUIDE#keeping-watch)).
- **Don't escalate.** Two calm people with one angry person is safer than one
  ([De-escalation, p. 21](lib:using-verbal-de-escalation#page=21)). Swap out anyone losing their temper *(rule of thumb)*.
- **Look after the helpers.** Watchers and helpers burn out; time away helps
  ([CERT, pp. 144–146](lib:cert-basic-training#page=144)).
- **After a scare, use psychological first aid**: look, listen, link
  ([Community guide](guide:COMMUNITY-BARTER-GUIDE#grief-stress-and-psychological-first-aid);
  [Psychological first aid](wiki:Psychological_first_aid)).
- **Despair and guns don't mix.** Oregon's legislature found that "a proven barrier to the impulse to
  commit suicide is securing firearms with a lock or storing firearms in locked containers"
  ([SB 554, p. 1](lib:oregon-senate-bill-554#page=1)). In hard months, let a trusted person hold the
  key for anyone who is struggling *(rule of thumb)*.

📚 **Go deeper:** [WHO *Psychological First Aid*](lib:psychological-first-aid-guide-for-field-workers#page=25) — a short field guide; [CERT, p. 144](lib:cert-basic-training#page=144) — stress in helpers.

## ⚠️ Old advice in the library to ignore

| Old book | What it says | Do this instead |
|---|---|---|
| [*Shifts and Expedients of Camp Life* (1871), p. 290](lib:shifts-and-expedients-of-camp-life#page=290) | Plans a homestead as a fort, with windows "convenient for firing from" against "savage assailants" | Racist colonial war thinking. Use the layers: deter, detect, delay, shelter, call for help |
| [FM 5-34 (1987), p. 78](lib:fm-5-34-engineer-field-data#page=78) | Military barbed-wire entanglements for base camps | Wire traps your own family and blocks fire engines; blocking a public road is a crime (ORS 166.025). Use a gate |
| [AFH 10-644, p. 587](lib:afh-10-644#page=587) | Describes tripwire-set devices and booby traps (written for aircrew evading an enemy) | **Never set any device.** It's illegal and it hurts the wrong people (see the law section) |
| [Seattle *Door Security*](lib:home-security-door-security#page=1) and [Watch Manual, p. 33](lib:neighborhood-watch-manual#page=33) | Double-cylinder deadbolts; nails or pins in windows | Fine only with a fire escape: key in the inside lock while home, pins you can pull, every bedroom with a way out |
| [Watch Manual](lib:neighborhood-watch-manual#page=20), [WSDA](lib:general-farm-security#page=2) and [FEMA P-320, p. 69](lib:taking-shelter-from-the-storm#page=69) | Dial 911; keep a cell phone in the safe room | With no 911: an air horn, FRS/GMRS radios and runners to the neighbors |

📚 **Go deeper:** [*Neighborhood Watch Manual*, p. 20](lib:neighborhood-watch-manual#page=20) — the "no weapons, never confront" rules to keep exactly as written.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Doors, locks and windows**
- Strike plate in the door jamb — [🖼️ USDA AH 73, p. 147](lib:wood-frame-house-construction#page=147)
- Latch guard on a door — [🖼️ Seattle *Door Security*, p. 1](lib:home-security-door-security#page=1); [Dead bolt](wiki:Deadbolt)
- Exterior door and frame, door types — [🖼️ USDA AH 73, p. 83](lib:wood-frame-house-construction#page=83); [🖼️ p. 84](lib:wood-frame-house-construction#page=84)
- Hanging doors on hinges — [🖼️ FM 5-426, p. 139](lib:fm-5-426-carpentry#page=139); [🖼️ USDA AH 73, p. 146](lib:wood-frame-house-construction#page=146)
- Double-hung windows and sash pins — [🖼️ USDA AH 73, p. 75](lib:wood-frame-house-construction#page=75); [🖼️ Seattle *Window Security*, p. 1](lib:home-security-window-security#page=1); [Sash window](wiki:Sash_window)
- Sliding doors: dowels, bars, anti-lift screws — [🖼️ Seattle *Window Security*, p. 2](lib:home-security-window-security#page=2); [Sliding glass door](wiki:Sliding_glass_door); [Window film](wiki:Window_film)
- Open garage doors, sheds — [🖼️ COPS *Burglary*, p. 27](lib:burglary-of-single-family-houses#page=27); [Padlock](wiki:Padlock)

**Yard, sightlines and fire**
- Shrubs, lighting, fences and signs — [🖼️ Seattle *Outside the Home*, p. 1](lib:deterring-burglary-from-outside#page=1); [🖼️ p. 2](lib:deterring-burglary-from-outside#page=2); [Security lighting](wiki:Security_lighting)
- Secluded and corner houses — [🖼️ COPS *Burglary*, p. 22](lib:burglary-of-single-family-houses#page=22); [🖼️ p. 23](lib:burglary-of-single-family-houses#page=23); [CPTED](wiki:Crime_prevention_through_environmental_design)
- Driveway clearance and address signs — [🖼️ OSU EM 9184, p. 8](lib:osu-em-9184#page=8)
- Defensible-space zones and ladder fuels — [🖼️ FEMA P-737, p. 23](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=23); [🖼️ p. 21](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=21); [Defensible space](wiki:Defensible_space_(fire_control))
- How embers get in through vents — [🖼️ FEMA P-737, p. 40](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=40)
- Solar motion lights — [Solar lamp](wiki:Solar_lamp); [Motion detector](wiki:Motion_detector)

**Animals and early warning**
- Guard dog, guard llama — [🖼️ *Raising Healthy Sheep*, p. 133](lib:raising-healthy-sheep-cvm#page=133); [Livestock guardian dog](wiki:Livestock_guardian_dog); [Llama](wiki:Llama); [Domestic goose](wiki:Domestic_goose)
- Guardian breeds — [Great Pyrenees](wiki:Pyrenean_Mountain_Dog); [Anatolian Shepherd](wiki:Kangal_Shepherd_Dog); [Maremma](wiki:Maremmano-Abruzzese_Sheepdog)
- Marking goats' ears — [🖼️ USDA FB 920, p. 33](lib:milk-goats-usda#page=33); [Ear tag](wiki:Ear_tag); [Livestock branding](wiki:Livestock_branding)

**Safe room and fire tools**
- Where a safe room can go — [🖼️ FEMA P-320, p. 41](lib:taking-shelter-from-the-storm#page=41); [🖼️ p. 43](lib:taking-shelter-from-the-storm#page=43); [Safe room](wiki:Safe_room)
- A safe room being built, and its plans — [🖼️ FEMA P-320, p. 36](lib:taking-shelter-from-the-storm#page=36); [🖼️ p. 83](lib:taking-shelter-from-the-storm#page=83)
- A tested safe room door label — [🖼️ FEMA P-320, p. 54](lib:taking-shelter-from-the-storm#page=54)
- Using a fire extinguisher — [🖼️ CERT, pp. 171–172](lib:cert-basic-training#page=171); [Fire extinguisher](wiki:Fire_extinguisher); [Smoke detector](wiki:Smoke_detector)

**Law and history**
- Locks and safes for firearms — [Gun safety](wiki:Gun_safety); [Gun safe](wiki:Gun_safe)
- Why traps are illegal — [Spring-gun](wiki:Spring-gun); [Katko v. Briney](wiki:Katko_v._Briney); [Booby trap](wiki:Booby_trap)

## 🔗 Related guides

- [Community, Barter & Keeping Watch](guide:COMMUNITY-BARTER-GUIDE) — watch structure, calming an angry person, settling theft fairly
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — wildfire, radio nets and local contacts
- [Signals & Morse](guide:SIGNALS-MORSE-GUIDE) and [Radio guide](guide:RADIO-GUIDE) — alarm codes, OK/HELP cards, calling for help
- [Rabbits & Chickens](guide:RABBITS-CHICKENS-GUIDE) and [Goats, Dairy & Bees](guide:GOATS-DAIRY-BEES-GUIDE) — predators, guardian animals, pens
- [Food Security](guide:FOOD-SECURITY-GUIDE) and [Fuel guide](guide:FUEL-GUIDE) — storing food and fuel so it lasts
- [Injuries & Illness When No Help Is Coming](guide:FIELD-CARE-GUIDE) — first aid after an incident
- [What to Expect](guide:WHAT-TO-EXPECT-GUIDE) — how disasters unfold and what tends to happen to order
