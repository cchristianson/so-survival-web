#!/bin/bash
# Double-click to put the SO Survival Library on a drive. (The first time, macOS may refuse to open it:
# System Settings > Privacy & Security > Open Anyway; on older Macs right-click this file > Open > Open.)
cd "$(dirname "$0")" || exit 1
DIR="$(pwd)"
K="$DIR"; [ -f "$DIR/files/get-offline-library.sh" ] && K="$DIR/files"   # the kit keeps its parts in "files"
if [ ! -f "$K/get-offline-library.sh" ]; then
  echo ""; echo "  This file needs the rest of the kit next to it. Unzip the downloaded kit first,"
  echo "  then double-click INSTALL-Mac inside the folder it makes."; echo ""; exit 1
fi
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null   # files from the internet are quarantined; this kit's files are safe to run
case "$(uname -m)" in arm64) B=library-assistant-mac-arm64;; *) B=library-assistant-mac-x64;; esac
LA="$K/local/library-assistant/$B"
chmod +x "$LA" 2>/dev/null
echo ""; echo "  Starting the installer - it opens in your web browser in a moment..."
"$LA" -setup || { echo ""; echo "  The browser page could not start, so the installer will ask its questions here instead."; echo ""; bash "$K/get-offline-library.sh"; }
