#!/bin/bash
# Double-click to put the SO Survival Library on a drive. (The first time, macOS may refuse to open it:
# System Settings > Privacy & Security > Open Anyway; on older Macs right-click this file > Open > Open.)
cd "$(dirname "$0")" || exit 1
DIR="$(pwd)"
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null   # files from the internet are quarantined; this kit's files are safe to run
case "$(uname -m)" in arm64) B=library-assistant-mac-arm64;; *) B=library-assistant-mac-x64;; esac
LA="$DIR/local/library-assistant/$B"
chmod +x "$LA" 2>/dev/null
echo ""
echo "  The installer is opening in your web browser."
echo "  Keep THIS window open until the download has finished."
echo ""
"$LA" -setup || { echo "The point-and-click installer could not start - using the text installer instead."; bash "$DIR/get-offline-library.sh"; }
