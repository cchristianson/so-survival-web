@echo off
rem The same as INSTALL-Windows.bat (kept so older instructions still work).
cd /d "%~dp0"
if not exist "%~dp0INSTALL-Windows.bat" (
  echo ERROR: unzip the whole folder first, then double-click INSTALL-Windows inside it.
  pause
  exit /b 1
)
call "%~dp0INSTALL-Windows.bat"
