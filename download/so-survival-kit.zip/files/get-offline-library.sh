#!/usr/bin/env bash
# get-offline-library.sh — Mac/Linux one-shot downloader for the Offline Emergency Library.
# Mirrors Get-OfflineLibrary.ps1. Resumable: re-run to continue after an interruption.
#
# Usage:
#   ./get-offline-library.sh                 # asks where to save
#   ./get-offline-library.sh -d /mnt/usb     # non-interactive
#   flags: --skip-wikipedia  --skip-maps  --skip-models  --skip-local  --local-only
#          --community   (the shareable kit: local pack + guides + Library Assistant with a small AI
#                         for every kind of device - Windows, Mac, Linux, Android - about 10 GB)
#          --skip-other-devices   (only this computer's programs, not the ones for other devices)
#          --wikipedia-size maxi|nopic|mini   (default maxi = full Wikipedia with pictures)
#          --drive-size 116   (fill 116 GB with the most useful parts - sizes are checked live)
#          --choose           (show the "what goes on this drive" list even with -d)
#          --plan-only        (just show what would fit; download nothing)

REPO_RAW="https://raw.githubusercontent.com/elhajahmadj/offline-emergency-library/main"
# The area this kit was built for: names, the drive folder and the project's own repository
# (local/region.env, written by tools/region.py from regions/<id>/region.json).
LOCAL_DIR="Local"; AREA_NAME="Local"; AREA_TITLE="Local"; LIBRARY_NAME="Offline Emergency Library"; LOCAL_GUIDE=""; REPO=""
MAP_WIDE="Us_oregon,Us_california|Oregon and California|2100"; MAP_NEAR="Us_oregon|Oregon only|360"   # smaller map choices
_KITDIR="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$_KITDIR/local/region.env" ]; then
  while IFS='=' read -r k v; do
    case "$k" in LOCAL_DIR|AREA_NAME|AREA_TITLE|LIBRARY_NAME|LOCAL_GUIDE|REPO|MAP_WIDE|MAP_NEAR) printf -v "$k" '%s' "$v";; esac
  done < <(tr -d '\r' < "$_KITDIR/local/region.env" | grep -E '^[A-Z_]+=')
fi
[ -n "$REPO" ] && REPO_RAW="https://raw.githubusercontent.com/$REPO/main"
DEST=""; SKIP_WIKI=0; SKIP_MAPS=0; SKIP_MODELS=0; SKIP_LOCAL=0; LOCAL_ONLY=0; WIKI_SIZE="maxi"
COMMUNITY=0; SKIP_OTHER=0; DRIVE_SIZE=0; CHOOSE=0; PLAN_ONLY=0; ASKED=0; PLAN_JSON=0; PARTS=""
REGION="US"; LISTREGIONS=0; FILTER=""
CONTINENTS="africa asia australia-oceania centralamerica europe northamerica southamerica"
while [ $# -gt 0 ]; do
  case "$1" in
    -d|--destination) DEST="$2"; shift 2;;
    --region)         REGION="$2"; shift 2;;
    --list-regions)   LISTREGIONS=1; if [ -n "$2" ] && [ "${2#-}" = "$2" ]; then FILTER="$2"; shift 2; else shift; fi;;
    --skip-wikipedia) SKIP_WIKI=1; shift;;
    --skip-maps)      SKIP_MAPS=1; shift;;
    --skip-models)    SKIP_MODELS=1; shift;;
    --skip-local)     SKIP_LOCAL=1; shift;;
    --local-only)     LOCAL_ONLY=1; shift;;
    --community)      COMMUNITY=1; LOCAL_ONLY=1; shift;;
    --skip-other-devices) SKIP_OTHER=1; shift;;
    --wikipedia-size) WIKI_SIZE="$2"; shift 2;;
    --drive-size)     DRIVE_SIZE="$2"; shift 2;;
    --choose)         CHOOSE=1; shift;;
    --plan-only)      PLAN_ONLY=1; shift;;
    --plan-json)      PLAN_JSON=1; shift;;   # (point-and-click installer) sizes + suggested plan as JSON
    --parts)          PARTS="$2"; shift 2;;  # (point-and-click installer) e.g. local,ai,devices,medical
    *) shift;;
  esac
done

case "$WIKI_SIZE" in maxi|nopic|mini) ;; *) echo "ERROR: --wikipedia-size must be maxi, nopic or mini"; exit 1;; esac
case "$DRIVE_SIZE" in ''|*[!0-9.]*) echo "ERROR: --drive-size must be a number of GB, e.g. --drive-size 116"; exit 1;; esac
command -v curl >/dev/null 2>&1 || { echo "ERROR: 'curl' is required."; exit 1; }
HAVE_UNZIP=1; command -v unzip >/dev/null 2>&1 || HAVE_UNZIP=0
HAVE_TAR=1;   command -v tar   >/dev/null 2>&1 || HAVE_TAR=0

# ---- --list-regions (discovery, no download) ----
if [ "$LISTREGIONS" = 1 ]; then
  idx="$(mktemp 2>/dev/null || echo /tmp/osmidx.xml)"
  curl -s "https://download.osmand.net/get_indexes" -o "$idx"
  names="$(grep -oE '<region [^>]*>' "$idx" | grep 'type="map"' | grep -oE 'name="[^"]+\.obf\.zip"' | sed -E 's/name="([^"]+)"/\1/' | grep -viE 'wiki|srtm|depth|road|hillshade|heightmap')"
  if [ -n "$FILTER" ]; then
    echo "Regions / sub-regions matching '$FILTER' (pass any of these to --region):"
    echo "$names" | grep -iE "$FILTER" | sed -E "s/_(africa|asia|australia-oceania|centralamerica|europe|northamerica|southamerica)_[0-9]+\.obf\.zip\$//" | sort -u | sed 's/^/  /'
  else
    echo "Available top-level regions (pass one to --region, e.g. --region France):"
    echo "$names" | cut -d_ -f1 | sort | uniq -c | awk '{printf "  %-26s %s file(s)\n",$2,$1}'
    echo ""
    echo "Continents: $CONTINENTS, or 'world' for everything."
    echo "To see a country's sub-regions:  --list-regions US"
  fi
  rm -f "$idx" 2>/dev/null; exit 0
fi

if [ -z "$DEST" ] && ! { { [ "$PLAN_ONLY" = 1 ] || [ "$PLAN_JSON" = 1 ]; } && [ "$DRIVE_SIZE" != 0 ]; }; then
  echo ""
  echo "  Offline Emergency Library installer"
  echo "  -----------------------------------"
  printf "Where would you like to save these files? (for example /Volumes/USB or /media/usb) "
  read -r DEST
  ASKED=1
fi

# ---- fit-to-drive planner ----
# Works out how big each part of the library is right now, picks the most useful set that fits
# the space you have (the drive's free space, or --drive-size), and lets you switch parts on and
# off before anything downloads. Shown when you run the installer without -d; use --choose to see
# it with -d, --drive-size 116 to fill 116 GB, and --plan-only to just see what would fit.
# (Plain bash 3.2 so it also runs on the bash that comes with macOS.)
UA="Mozilla/5.0"
GET_AI=1; GET_MEDICAL=1; GET_REPAIR=1; GET_READER=1; GET_VIEWER=1; GET_GPT4ALL=1
if [ "$LOCAL_ONLY" = 1 ]; then
  GET_AI=$COMMUNITY; GET_MEDICAL=0; GET_REPAIR=0; GET_READER=0; GET_VIEWER=0; GET_GPT4ALL=0
  SKIP_WIKI=1; SKIP_MAPS=1; SKIP_MODELS=1
fi
USE_PLANNER=0
if [ "$DRIVE_SIZE" != 0 ] || [ "$CHOOSE" = 1 ] || [ "$PLAN_ONLY" = 1 ] || [ "$PLAN_JSON" = 1 ] || { [ "$ASKED" = 1 ] && [ "$LOCAL_ONLY" = 0 ]; }; then USE_PLANNER=1; fi
if [ -n "$PARTS" ]; then   # chosen in the point-and-click installer: exactly these parts, no questions
  has_part(){ case ",$(printf '%s' "$PARTS" | tr 'A-Z ;' 'a-z,,')," in *",$1,"*) return 0;; esac; return 1; }
  SKIP_LOCAL=1; has_part local && SKIP_LOCAL=0
  SKIP_MODELS=1; has_part bigai && SKIP_MODELS=0
  SKIP_OTHER=1; has_part devices && SKIP_OTHER=0
  GET_AI=0; { has_part ai || has_part bigai; } && GET_AI=1
  GET_MEDICAL=0; has_part medical && GET_MEDICAL=1
  GET_REPAIR=0; has_part repair && GET_REPAIR=1
  GET_READER=0; has_part reader && GET_READER=1
  GET_GPT4ALL=0; has_part gpt4all && GET_GPT4ALL=1
  GET_VIEWER=0; has_part viewer && [ "$SKIP_MAPS" = 0 ] && GET_VIEWER=1
  LOCAL_ONLY=0; USE_PLANNER=0
fi
QUICK_MODEL_URL="https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf"
STD_MODEL_URL="https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf"
SMART_MODEL_URL="https://huggingface.co/bartowski/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf"
GPU_MODEL_URL="https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf"

remote_gb(){ # url fallback-GB -> size in GB of the file at url
  curl -sIL -A "Mozilla/5.0" --max-time 25 "$1" 2>/dev/null | tr -d '\r' |
    awk -v fb="$2" 'tolower($1)=="content-length:"{n=$2} END{ if (n+0 > 100000) printf "%.2f", n/1073741824; else printf "%s", fb }'
}
gsum(){ awk 'BEGIN{t=0; for(i=1;i<ARGC;i++) t+=ARGV[i]; printf "%.2f", t}' "$@"; }
plan_sizes(){
  echo ""; echo "  Checking how big each part of the library is right now (about half a minute)..."
  Z_CORE=0.4; Z_DEVICES=0.7; Z_READER=1.0; Z_GPT4ALL=0.4; Z_VIEWER=0.45
  Z_LOCAL="$(tr -d '\r' < "$SCRIPTDIR/local/library-files.txt" 2>/dev/null | awk -F'|' '!/^[[:space:]]*#/ && NF>=4 {s+=$4} END{printf "%.2f", s/1024}')"
  [ -z "$Z_LOCAL" ] && Z_LOCAL=0
  Z_AI="$(gsum 0.5 "$(remote_gb "$QUICK_MODEL_URL" 0.92)" "$(remote_gb "$STD_MODEL_URL" 1.88)")"
  Z_BIGAI="$(gsum "$(remote_gb "$SMART_MODEL_URL" 4.58)" "$(remote_gb "$GPU_MODEL_URL" 4.36)")"
  PW_="$(curl -sL -A "$UA" --max-time 40 https://download.kiwix.org/zim/wikipedia/)"
  PO_="$(curl -sL -A "$UA" --max-time 40 https://download.kiwix.org/zim/other/)"
  PF_="$(curl -sL -A "$UA" --max-time 40 https://download.kiwix.org/zim/ifixit/)"
  zgb(){ # page dir prefix fallback
    n="$(printf '%s' "$1" | grep -oE "$3[0-9-]+\.zim" | sort -u | tail -n1)"
    if [ -n "$n" ]; then remote_gb "$2$n" "$4"; else printf '%s' "$4"; fi
  }
  W="https://download.kiwix.org/zim/wikipedia/"; O="https://download.kiwix.org/zim/other/"; F="https://download.kiwix.org/zim/ifixit/"
  Z_MEDICAL="$(gsum "$(zgb "$PW_" "$W" wikipedia_en_medicine_maxi_ 1.7)" "$(zgb "$PO_" "$O" zimgit-medicine_en_ 0.07)")"
  Z_REPAIR="$(gsum "$(zgb "$PF_" "$F" ifixit_en_all_ 3.3)" "$(zgb "$PO_" "$O" appropedia_en_all_maxi_ 0.55)" "$(zgb "$PO_" "$O" zimgit-post-disaster_en_ 0.6)" \
               "$(zgb "$PO_" "$O" zimgit-water_en_ 0.02)" "$(zgb "$PO_" "$O" zimgit-food-preparation_en_ 0.09)" "$(zgb "$PO_" "$O" zimgit-knots_en_ 0.03)")"
  Z_WIKI_maxi="$(zgb "$PW_" "$W" wikipedia_en_all_maxi_ 119)"; Z_WIKI_nopic="$(zgb "$PW_" "$W" wikipedia_en_all_nopic_ 49)"
  Z_WIKI_mini="$(zgb "$PW_" "$W" wikipedia_en_all_mini_ 13)"; Z_WIKI_none=0
  # maps: sizes straight from the OsmAnd download index (zipped, and unpacked for the PC viewer)
  IDX_="$(mktemp 2>/dev/null || echo /tmp/oel-osm-idx.xml)"
  curl -s --max-time 60 "https://download.osmand.net/get_indexes" > "$IDX_"
  MAPLIST_="$(grep -oE '<region [^>]*>' "$IDX_" 2>/dev/null | grep 'type="map"' |
    sed -E 's/.* size="([0-9.]+)".* targetsize="([0-9.]+)".* name="([^"]+)".*/\3 \1 \2/' | grep -E '^[^ ]+ [0-9.]+ [0-9.]+$')"
  rm -f "$IDX_"
  AREA_N=0
  add_area(){ # region-tokens label fallback-MB
    local zip unz tok tl
    zip=0; unz=0
    for tok in $(printf '%s' "$1" | tr ',;' '  '); do
      tl="$(printf '%s' "$tok" | tr 'A-Z' 'a-z')"
      read -r zip unz <<EOT
$(printf '%s\n' "$MAPLIST_" | awk -v t="$tl" -v z="$zip" -v u="$unz" -v cont="$CONTINENTS" '
  BEGIN{ n=split(cont,c," "); isc=0; for(i=1;i<=n;i++) if(c[i]==t) isc=1 }
  { nm=tolower($1); if (t=="world" || (isc && index(nm,"_" t "_")) || (!isc && index(nm, t "_")==1)) { z+=$2; u+=$3 } }
  END{ printf "%.1f %.1f", z, u }')
EOT
    done
    if [ "$(awk -v z="$zip" 'BEGIN{print (z>0)}')" = 0 ]; then zip="$3"; unz="$(awk -v z="$3" 'BEGIN{printf "%.1f", z*1.8}')"; fi
    eval "AREA_R_$AREA_N=\"\$1\"; AREA_L_$AREA_N=\"\$2\""
    eval "AREA_Z_$AREA_N=$(awk -v z="$zip" 'BEGIN{printf "%.2f", z/1024}'); AREA_U_$AREA_N=$(awk -v u="$unz" 'BEGIN{printf "%.2f", u/1024}')"
    AREA_N=$((AREA_N+1))
  }
  [ "$REGION" != US ] && add_area "$REGION" "Maps: $REGION" 1000
  I_US=$AREA_N
  add_area "US" "Maps: the whole USA" 17000
  IFS='|' read -r _mr _ml _mz <<<"$MAP_WIDE"; add_area "$_mr" "Maps: $_ml" "${_mz:-2000}"
  IFS='|' read -r _mr _ml _mz <<<"$MAP_NEAR"; add_area "$_mr" "Maps: $_ml" "${_mz:-400}"
}
plan_total(){
  local mz=0 mu=0 wz
  if [ "$S_MAP" -ge 0 ]; then eval "mz=\$AREA_Z_$S_MAP; mu=\$AREA_U_$S_MAP"; fi
  eval "wz=\$Z_WIKI_$S_WIKI"
  awk -v core="$Z_CORE" -v l="$S_LOCAL" -v zl="$Z_LOCAL" -v ai="$S_AI" -v bai="$S_BIGAI" -v zai="$Z_AI" -v zbai="$Z_BIGAI" \
      -v dev="$S_DEVICES" -v zdev="$Z_DEVICES" -v med="$S_MEDICAL" -v zmed="$Z_MEDICAL" -v rd="$S_READER" -v zrd="$Z_READER" \
      -v rp="$S_REPAIR" -v zrp="$Z_REPAIR" -v map="$S_MAP" -v mz="$mz" -v mu="$mu" -v vw="$S_VIEWER" -v zvw="$Z_VIEWER" \
      -v wz="$wz" -v g4="$S_GPT4ALL" -v zg4="$Z_GPT4ALL" 'BEGIN{
    t=core; if(l) t+=zl; if(ai||bai) t+=zai; if(dev) t+=zdev; if(bai) t+=zbai; if(med) t+=zmed; if(rd) t+=zrd; if(rp) t+=zrp
    if(map>=0){ t+=mz; if(vw) t+=zvw+mu } t+=wz; if(g4) t+=zg4; printf "%.1f", t }'
}
plan_fits(){ awk -v t="$(plan_total)" -v b="$BUDGET" 'BEGIN{exit !(t<=b)}'; }
plan_state(){ echo "$S_LOCAL $S_AI $S_DEVICES $S_MEDICAL $S_READER $S_REPAIR $S_MAP $S_VIEWER $S_WIKI $S_BIGAI $S_GPT4ALL"; }
plan_restore(){ set -- $1; S_LOCAL=$1; S_AI=$2; S_DEVICES=$3; S_MEDICAL=$4; S_READER=$5; S_REPAIR=$6; S_MAP=$7; S_VIEWER=$8; S_WIKI=$9; S_BIGAI=${10}; S_GPT4ALL=${11}; }
plan_auto(){
  S_LOCAL=1; S_AI=1; S_DEVICES=1; S_MEDICAL=1; S_READER=1; S_REPAIR=1; S_MAP=0; S_VIEWER=1; S_WIKI=maxi; S_BIGAI=1; S_GPT4ALL=1
  # when it doesn't fit, give things up in this order (least needed first)
  for step in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
    plan_fits && break
    case $step in
      1) S_GPT4ALL=0;; 2) S_VIEWER=0;; 3) [ "$S_WIKI" = maxi ] && S_WIKI=nopic;; 4) S_BIGAI=0;;
      5) [ "$S_MAP" -le "$I_US" ] && S_MAP=$((I_US+1));; 6) [ "$S_WIKI" = nopic ] && S_WIKI=mini;; 7) S_REPAIR=0;;
      8) [ "$S_MAP" -ge 0 ] && S_MAP=$((I_US+2));; 9) S_WIKI=none;; 10) S_MAP=-1;; 11) S_DEVICES=0;;
      12) S_READER=0;; 13) S_MEDICAL=0;; 14) S_AI=0;; 15) S_LOCAL=0;;
    esac
  done
  # then add back, most useful first, anything that still fits in the space left over
  for try in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
    keep="$(plan_state)"
    case $try in
      1) S_LOCAL=1;; 2) S_AI=1;; 3) S_MEDICAL=1;; 4) S_READER=1;; 5) S_DEVICES=1;;
      6) [ "$S_MAP" -lt 0 ] && S_MAP=$((I_US+2));; 7) S_REPAIR=1;; 8) [ "$S_WIKI" = none ] && S_WIKI=mini;;
      9) [ "$S_WIKI" = mini ] && S_WIKI=nopic;; 10) [ "$S_MAP" = $((I_US+2)) ] && S_MAP=$((I_US+1));;
      11) [ "$S_MAP" = $((I_US+1)) ] && S_MAP=$I_US;; 12) S_BIGAI=1;; 13) [ "$S_WIKI" = nopic ] && S_WIKI=maxi;;
      14) S_VIEWER=1;; 15) S_GPT4ALL=1;;
    esac
    plan_fits || plan_restore "$keep"
  done
}
plan_row(){ # number on label GB
  local mark="[ ]"; [ "$2" = 1 ] && mark="[x]"
  printf "  %3s  %s  %-62s %6.1f GB\n" "$1" "$mark" "$3" "$4"
}
plan_show(){
  local ml mz mu wl wz on
  if [ "$S_MAP" -ge 0 ]; then eval "ml=\$AREA_L_$S_MAP; mz=\$AREA_Z_$S_MAP; mu=\$AREA_U_$S_MAP"; else ml="Maps"; mz=$AREA_Z_0; mu=$AREA_U_0; fi
  case "$S_WIKI" in maxi) wl="Wikipedia: everything, with pictures";; nopic) wl="Wikipedia: every article, text only";;
                    mini) wl="Wikipedia: article introductions only";; *) wl="Wikipedia";; esac
  if [ "$S_WIKI" = none ]; then wz=$Z_WIKI_nopic; else eval "wz=\$Z_WIKI_$S_WIKI"; fi
  echo ""; echo "  WHAT GOES ON THIS DRIVE"
  printf "  Space to use: %.0f GB  (keeping %.0f GB free so the drive doesn't fill to the brim)\n\n" "$SPACE" "$(awk -v s="$SPACE" -v b="$BUDGET" 'BEGIN{print s-b}')"
  plan_row 1 "$S_LOCAL" "$AREA_NAME books, maps and guides (local pack)" "$Z_LOCAL"
  on=0; { [ "$S_AI" = 1 ] || [ "$S_BIGAI" = 1 ]; } && on=1; plan_row 2 "$on" "Offline AI, small - runs on most computers" "$Z_AI"
  plan_row 3 "$S_DEVICES" "Works on every device (Windows, Android programs too)" "$Z_DEVICES"
  plan_row 4 "$S_MEDICAL" "Medical encyclopedia (WikiMed) and medicine archive" "$Z_MEDICAL"
  plan_row 5 "$S_READER" "Army manuals, Kiwix reader and phone apps" "$Z_READER"
  plan_row 6 "$S_REPAIR" "Repair and survival archives (iFixit, Appropedia)" "$Z_REPAIR"
  on=0; [ "$S_MAP" -ge 0 ] && on=1; plan_row 7 "$on" "$ml   (M = change)" "$mz"
  on=0; [ "$S_VIEWER" = 1 ] && [ "$S_MAP" -ge 0 ] && on=1; plan_row 8 "$on" "Map viewer for computers (+ EMPTY room to unpack maps)" "$(gsum "$Z_VIEWER" "$mu")"
  on=0; [ "$S_WIKI" != none ] && on=1; plan_row 9 "$on" "$wl   (W = change)" "$wz"
  plan_row 10 "$S_BIGAI" "Offline AI, large - smarter, needs 16 GB memory" "$Z_BIGAI"
  plan_row 11 "$S_GPT4ALL" "GPT4All document reader (optional)" "$Z_GPT4ALL"
  printf "         %-62s %6.1f GB\n" "Guides, tools and the Library Assistant (always)" "$Z_CORE"
  echo "  ----------------------------------------------------------------------------------"
  PLAN_T="$(plan_total)"
  if plan_fits; then printf "  Total %s GB of %s GB - fits, with %s GB to spare\n" "$PLAN_T" "$BUDGET" "$(awk -v t="$PLAN_T" -v b="$BUDGET" 'BEGIN{printf "%.1f", b-t}')"
  else printf "  Total %s GB of %s GB - TOO BIG by %s GB: switch something off\n" "$PLAN_T" "$BUDGET" "$(awk -v t="$PLAN_T" -v b="$BUDGET" 'BEGIN{printf "%.1f", t-b}')"; fi
  if [ "$S_VIEWER" = 1 ] && [ "$S_MAP" -ge 0 ]; then
    printf "  Note: %s GB of that is left EMPTY on purpose. The PC map viewer fills it the first time\n" "$mu"
    echo "  you open it, to unpack the maps - until then the drive shows that much free space."
  fi
}
if [ "$USE_PLANNER" = 1 ]; then
  SCRIPTDIR="$(cd "$(dirname "$0")" && pwd)"
  SPACE="$DRIVE_SIZE"
  if [ "$SPACE" = 0 ]; then
    p="$DEST"; while [ -n "$p" ] && [ ! -d "$p" ]; do p="$(dirname "$p")"; done
    freek="$(df -Pk "${p:-.}" 2>/dev/null | awk 'NR==2{print $4}')"
    havek=0; [ -d "$DEST/OfflineLibrary" ] && havek="$(du -sk "$DEST/OfflineLibrary" 2>/dev/null | awk '{print $1}')"
    SPACE="$(awk -v f="${freek:-0}" -v h="${havek:-0}" 'BEGIN{printf "%.1f", (f+h)/1048576}')"
  fi
  if [ "$(awk -v s="$SPACE" 'BEGIN{print (s>0)}')" = 0 ]; then echo "Could not tell how much space the drive has - use --drive-size, e.g. --drive-size 116"; exit 1; fi
  BUDGET="$(awk -v s="$SPACE" 'BEGIN{r=s*0.02; if(r<1) r=1; b=s-r; if(b<0) b=0; printf "%d", b}')"
  plan_sizes
  plan_auto
  if [ "$PLAN_JSON" = 1 ]; then
    areas=""; i=0
    while [ $i -lt $AREA_N ]; do
      eval "ar=\$AREA_R_$i; al=\$AREA_L_$i; az=\$AREA_Z_$i; au=\$AREA_U_$i"
      areas="$areas${areas:+,}{\"r\":\"$ar\",\"l\":\"$al\",\"zip\":$az,\"unz\":$au}"; i=$((i+1))
    done
    printf 'PLANJSON:{"space":%s,"budget":%s,"z":{"core":%s,"local":%s,"ai":%s,"bigai":%s,"devices":%s,"medical":%s,"reader":%s,"repair":%s,"viewer":%s,"gpt4all":%s,"wiki":{"maxi":%s,"nopic":%s,"mini":%s,"none":0},"areas":[%s]},"auto":{"local":%s,"ai":%s,"devices":%s,"medical":%s,"reader":%s,"repair":%s,"map":%s,"viewer":%s,"wiki":"%s","bigai":%s,"gpt4all":%s}}\n' \
      "$SPACE" "$BUDGET" "$Z_CORE" "$Z_LOCAL" "$Z_AI" "$Z_BIGAI" "$Z_DEVICES" "$Z_MEDICAL" "$Z_READER" "$Z_REPAIR" "$Z_VIEWER" "$Z_GPT4ALL" \
      "$Z_WIKI_maxi" "$Z_WIKI_nopic" "$Z_WIKI_mini" "$areas" \
      "$([ "$S_LOCAL" = 1 ] && echo true || echo false)" "$([ "$S_AI" = 1 ] && echo true || echo false)" "$([ "$S_DEVICES" = 1 ] && echo true || echo false)" \
      "$([ "$S_MEDICAL" = 1 ] && echo true || echo false)" "$([ "$S_READER" = 1 ] && echo true || echo false)" "$([ "$S_REPAIR" = 1 ] && echo true || echo false)" \
      "$S_MAP" "$([ "$S_VIEWER" = 1 ] && echo true || echo false)" "$S_WIKI" "$([ "$S_BIGAI" = 1 ] && echo true || echo false)" "$([ "$S_GPT4ALL" = 1 ] && echo true || echo false)"
    exit 0
  fi
  while true; do
    plan_show
    { [ "$PLAN_ONLY" = 1 ] || { [ "$ASKED" = 0 ] && [ "$CHOOSE" = 0 ]; }; } && break
    echo ""
    echo "  Type a number to switch that part on or off.   W = change Wikipedia   M = change the map area"
    echo "  A = fill the drive automatically again   Enter = start downloading   Q = quit"
    printf "  Your choice: "; read -r a || a=q
    case "$a" in
      "") plan_fits && break
          printf "  That is more than the space you have. Start anyway? (y/N) "; read -r yn; case "$yn" in y*|Y*) break;; esac;;
      q*|Q*) echo "Nothing was downloaded."; exit 0;;
      a*|A*) plan_auto;;
      w*|W*) case "$S_WIKI" in maxi) S_WIKI=nopic;; nopic) S_WIKI=mini;; mini) S_WIKI=none;; *) S_WIKI=maxi;; esac;;
      m*|M*) S_MAP=$((S_MAP+1)); [ "$S_MAP" -ge "$AREA_N" ] && S_MAP=-1;;
      1) S_LOCAL=$((1-S_LOCAL));;
      2) if [ "$S_AI" = 1 ] || [ "$S_BIGAI" = 1 ]; then S_AI=0; S_BIGAI=0; else S_AI=1; fi;;
      3) S_DEVICES=$((1-S_DEVICES));; 4) S_MEDICAL=$((1-S_MEDICAL));; 5) S_READER=$((1-S_READER));; 6) S_REPAIR=$((1-S_REPAIR));;
      7) if [ "$S_MAP" -ge 0 ]; then S_MAP=-1; else S_MAP=0; fi;;
      8) if [ "$S_VIEWER" = 1 ] && [ "$S_MAP" -ge 0 ]; then S_VIEWER=0; else S_VIEWER=1; [ "$S_MAP" -lt 0 ] && S_MAP=0; fi;;
      9) if [ "$S_WIKI" != none ]; then S_WIKI=none; else S_WIKI=nopic; fi;;
      10) S_BIGAI=$((1-S_BIGAI)); [ "$S_BIGAI" = 1 ] && S_AI=1;;
      11) S_GPT4ALL=$((1-S_GPT4ALL));;
      *) echo "  (no such choice)";;
    esac
  done
  [ "$PLAN_ONLY" = 1 ] && { echo ""; echo "  (--plan-only: nothing was downloaded.)"; exit 0; }
  SKIP_LOCAL=$((1-S_LOCAL)); SKIP_MODELS=$((1-S_BIGAI)); SKIP_OTHER=$((1-S_DEVICES)); LOCAL_ONLY=0
  if [ "$S_WIKI" = none ]; then SKIP_WIKI=1; else SKIP_WIKI=0; WIKI_SIZE=$S_WIKI; fi
  if [ "$S_MAP" -lt 0 ]; then SKIP_MAPS=1; else SKIP_MAPS=0; eval "REGION=\$AREA_R_$S_MAP"; fi
  GET_AI=0; { [ "$S_AI" = 1 ] || [ "$S_BIGAI" = 1 ]; } && GET_AI=1
  GET_MEDICAL=$S_MEDICAL; GET_REPAIR=$S_REPAIR; GET_READER=$S_READER; GET_GPT4ALL=$S_GPT4ALL
  GET_VIEWER=0; [ "$S_VIEWER" = 1 ] && [ "$S_MAP" -ge 0 ] && GET_VIEWER=1
  PLAN_SUMMARY="plan: $PLAN_T GB of $BUDGET GB - local=$S_LOCAL ai=$GET_AI devices=$S_DEVICES medical=$S_MEDICAL reader=$S_READER repair=$S_REPAIR maps=$([ "$S_MAP" -ge 0 ] && echo "$REGION" || echo none) viewer=$GET_VIEWER wikipedia=$S_WIKI bigai=$S_BIGAI gpt4all=$S_GPT4ALL"
fi

[ -z "$DEST" ] && { echo "No destination given. Exiting."; exit 1; }
ROOT="$DEST/OfflineLibrary"
mkdir -p "$ROOT" || { echo "Cannot create $ROOT"; exit 1; }
LOG="$ROOT/_download.log"
# Anything that couldn't be downloaded is also noted in _failed.txt (started fresh each run), so the
# end of the run - and the point-and-click page - can say exactly what's missing instead of "all done".
FAILS="$ROOT/_failed.txt"; : > "$FAILS" 2>/dev/null
log(){ printf '%s  %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" | tee -a "$LOG"
  case "$*" in *FAILED*|*ERROR*|*"NOT FOUND"*|*"not found ("*|*"could not find"*|*"not reachable"*|*"no maps matched"*|*"doc missing"*|*"converter missing"*)
    printf '%s\n' "$*" >> "$FAILS";; esac; }
# --retry-all-errors needs curl 7.71 or newer: the curl on macOS 11 and older (and on older Linux)
# stops with "option is unknown", which would make EVERY download fail - so use it only if it works
RETRY_ALL=""; curl --retry-all-errors --version >/dev/null 2>&1 && RETRY_ALL="--retry-all-errors"
fetch(){ local rc; curl -f -L -C - --retry 10 --retry-delay 5 $RETRY_ALL -s -o "$2" "$1"; rc=$?
  [ "$rc" = 0 ] || log "  FAILED: $(basename "$2") (download error $rc) - will retry on the next run"; return $rc; }
UA="Mozilla/5.0"

# ---- platform detection ----
OSN="$(uname -s)"; ARCHN="$(uname -m)"
case "$ARCHN" in arm64|aarch64) CPU=arm64; JARCH=aarch64;; *) CPU=x64; JARCH=x64;; esac
case "$OSN" in Darwin) PLAT=mac;; Linux) PLAT=linux;; *) PLAT=linux;; esac
log "Platform: $PLAT/$CPU   Destination: $ROOT"
[ -n "${PLAN_SUMMARY:-}" ] && log "$PLAN_SUMMARY"
# the drive's format decides which devices can open it: exFAT works on all of them
fs_of(){
  if command -v findmnt >/dev/null 2>&1; then findmnt -no FSTYPE -T "$1" 2>/dev/null | head -n1
  elif [ "$OSN" = Darwin ]; then   # (diskutil wants the disk itself, e.g. /dev/disk4s1, not a folder on it)
    diskutil info "$(df "$1" 2>/dev/null | awk 'NR==2{print $1}')" 2>/dev/null | awk -F': *' '/Type \(Bundle\)/{print $2; exit}'; fi
}
case "$ROOT" in /Volumes/*|/media/*|/run/media/*|/mnt/*)
  FSN="$(fs_of "$ROOT" | tr 'A-Z' 'a-z')"
  [ -n "$FSN" ] && log "Drive format: $FSN"
  case "$FSN" in
    vfat|msdos|fat|fat32)
      log "WARNING: this drive is formatted FAT32, which can't hold a file over 4 GB - Wikipedia and the large AI are skipped. For a drive that holds everything and works on every kind of device, format it as exFAT first (this erases it)."
      SKIP_WIKI=1; SKIP_MODELS=1;;
    exfat|fuseblk|"") ;;
    ntfs*) log "NOTE: this drive is formatted NTFS. Windows and Linux can use it, but Macs can only read it and most Android tablets can't open it. For a drive that works on every kind of device, format it as exFAT first (this erases it).";;
    *) log "NOTE: this drive is formatted $FSN, which not every kind of computer can open. For a drive that works on every kind of device, format it as exFAT first (this erases it).";;
  esac;;
esac
[ "$HAVE_UNZIP" = 0 ] && log "NOTE: 'unzip' not found — the desktop map viewer needs it (install it to enable maps-on-PC)."

# ---- folder tree ----
for d in AI-Offline AI-Offline/engine AI-Offline/models AI-Offline/DocReader-GPT4All \
         Manuals Manuals/ArmyFieldManuals Manuals/Repair-iFixit Manuals/DIY-Appropedia \
         Manuals/Survival-Water-Food Manuals/Radio-Communications \
         Medical Medical/WikiMed Medical/zimgit-medicine Medical/Manuals-PDF \
         Wikipedia OsmAnd Kiwix-Reader Phone-Apps "$LOCAL_DIR"; do
  mkdir -p "$ROOT/$d"
done

# ---- helpers ----
gh_asset(){ # repo regex  -> first matching asset url across recent releases
  curl -s -H "User-Agent: oel" "https://api.github.com/repos/$1/releases?per_page=20" \
   | grep -oE '"browser_download_url"[ ]*:[ ]*"[^"]+"' | sed -E 's/.*"(https[^"]+)"/\1/' \
   | grep -E "$2" | head -n1
}
gh_asset_latest(){ # repo regex -> asset url from the 'latest' release
  curl -s -H "User-Agent: oel" "https://api.github.com/repos/$1/releases/latest" \
   | grep -oE '"browser_download_url"[ ]*:[ ]*"[^"]+"' | sed -E 's/.*"(https[^"]+)"/\1/' \
   | grep -E "$2" | head -n1
}
latest_zim(){ curl -sL -A "$UA" "$1" | grep -oE "$2[^\"<]*\.zim" | sort -u | tail -n1; }

# ---- local pack helpers (this area: local/library-files.txt) ----
SCRIPTDIR="$(cd "$(dirname "$0")" && pwd)"
LOCAL_LIST="$SCRIPTDIR/local/library-files.txt"
local_items(){ [ -f "$LOCAL_LIST" ] && tr -d '\r' < "$LOCAL_LIST" | grep -v '^[[:space:]]*#' | grep -v '^[[:space:]]*$'; }
trim(){ printf '%s' "$1" | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//'; }

# ---- programs for every kind of device --------------------------------------------------------
# One drive serves Windows, Mac, Linux (incl. Raspberry Pi) and Android, so the AI engine and the
# archive-search program are kept in one folder per platform (AI-Offline/engine/<platform>,
# Kiwix-Reader/tools/<platform>). The Library Assistant picks the right one when it starts.
platdir(){ case "$PLAT/$CPU" in mac/arm64) echo mac-arm64;; mac/*) echo mac-x64;; */arm64) echo linux-arm64;; *) echo linux-x64;; esac; }
expand_any(){ # archive dir - and puts a copy of the real file where the archive has a link, since
              # exFAT/FAT drives (most USB drives) can't store links
  case "$1" in *.zip) [ "$HAVE_UNZIP" = 1 ] && unzip -qo "$1" -d "$2"; return 0;; esac
  tar -xf "$1" -C "$2" 2>/dev/null
  links="$(tar -tvf "$1" 2>/dev/null | grep '^l' | sed -n 's/.* \([^ ]*\) -> \([^ ]*\)$/\1|\2/p')"
  for pass in 1 2 3; do
    printf '%s\n' "$links" | while IFS='|' read -r l t; do
      [ -n "$l" ] || continue; [ -e "$2/$l" ] && continue
      src="$(dirname "$2/$l")/$t"; [ -f "$src" ] && cp "$src" "$2/$l"
    done
  done
  return 0
}
get_archive(){ # name url dir label
  mkdir -p "$3"
  if [ -f "$3/downloaded.txt" ] && [ "$(cat "$3/downloaded.txt")" = "$1" ]; then log "$4: already on the drive"; return 0; fi
  log "$4: $1"
  if fetch "$2" "$3/$1"; then expand_any "$3/$1" "$3"; rm -f "$3/$1"; printf '%s\n' "$1" > "$3/downloaded.txt"
  else log "$4: download failed - will retry on the next run"; fi
}
get_ai_engines(){
  [ "$HAVE_TAR" = 1 ] || { log "engine: skipped (no 'tar')"; return 0; }
  assets="$(curl -s -H "User-Agent: oel" "https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=10" \
    | grep -oE '"browser_download_url"[ ]*:[ ]*"[^"]+"' | sed -E 's/.*"(https[^"]+)"/\1/')"
  [ -n "$assets" ] || { log "engine: GitHub not reachable - try again later"; return 0; }
  for spec in "bin-macos-arm64\.(tar\.gz|zip)$|mac-arm64|engine for Macs with Apple chips" \
              "bin-macos-x64\.(tar\.gz|zip)$|mac-x64|engine for Intel Macs" \
              "bin-ubuntu-x64\.(tar\.gz|zip)$|linux-x64|engine for Linux PCs" \
              "bin-ubuntu-vulkan-x64\.(tar\.gz|zip)$|linux-vulkan-x64|engine for Linux PCs with a graphics card" \
              "bin-ubuntu-arm64\.(tar\.gz|zip)$|linux-arm64|engine for Linux ARM / Raspberry Pi" \
              "bin-win-cpu-x64\.zip$|x64|engine for Windows PCs" \
              "bin-win-cpu-arm64\.zip$|arm64|engine for Windows on ARM" \
              "bin-win-vulkan-x64\.zip$|vulkan-x64|engine for Windows with a graphics card"; do
    rx="${spec%%|*}"; rest="${spec#*|}"; sub="${rest%%|*}"; label="${rest#*|}"
    if [ "$SKIP_OTHER" = 1 ]; then case "$sub" in "$(platdir)") ;; linux-vulkan-x64) [ "$(platdir)" = linux-x64 ] || continue;; *) continue;; esac; fi
    u="$(printf '%s\n' "$assets" | grep -E "$rx" | head -n1)"
    if [ -n "$u" ]; then get_archive "$(basename "$u")" "$u" "$ROOT/AI-Offline/engine/$sub" "$label"; else log "$label: not in the recent releases"; fi
  done
}
get_archive_search(){ # kiwix-serve: lets the Library Assistant search Wikipedia and the other .zim archives
  [ "$HAVE_TAR" = 1 ] || return 0
  kdir="https://download.kiwix.org/release/kiwix-tools/"; html="$(curl -sL -A "$UA" "$kdir")"
  for spec in "linux-x86_64-musl|linux-x64" "linux-aarch64-musl|linux-arm64" "macos-arm64|mac-arm64" "macos-x86_64|mac-x64" "win-x86_64|."; do
    pat="${spec%%|*}"; sub="${spec#*|}"
    [ "$SKIP_OTHER" = 1 ] && [ "$sub" != "$(platdir)" ] && continue
    ext='tar\.gz'; [ "$sub" = . ] && ext='zip'
    n="$(printf '%s' "$html" | grep -oE "kiwix-tools_${pat}-[0-9][^\"<]*\.${ext}" | sort -u | tail -n1)"
    [ -n "$n" ] && get_archive "$n" "$kdir$n" "$ROOT/Kiwix-Reader/tools/$sub" "kiwix-serve ($sub)"
  done
}
get_android_kit(){ # Termux + the AI and Wikipedia helper packages, so a tablet can be set up with no internet
  [ "$SKIP_OTHER" = 1 ] && return 0
  TX="$ROOT/Phone-Apps/Android-Termux"; TP="$TX/packages"; mkdir -p "$TP"
  vc="$(curl -sL -A "$UA" https://f-droid.org/api/v1/packages/com.termux | grep -oE '"suggestedVersionCode":[0-9]+' | grep -oE '[0-9]+' | head -n1)"
  if [ -n "$vc" ] && [ ! -f "$TX/Termux-$vc.apk" ]; then log "phone app: Termux $vc"; fetch "https://f-droid.org/repo/com.termux_$vc.apk" "$TX/Termux-$vc.apk"; fi
  repo="https://packages.termux.dev/apt/termux-main"
  idx="$(curl -s -L "$repo/dists/stable/main/binary-aarch64/Packages.gz" | gunzip 2>/dev/null)"
  [ -n "$idx" ] || { log "android packages: index not reachable - try again later"; return 0; }
  want="$(grep -v '^#' "$SCRIPTDIR/local/launchers/android-termux-packages.txt" 2>/dev/null)"; [ -n "$want" ] || want="llama-cpp kiwix-tools"
  keep=" "
  for p in $want; do
    fn="$(printf '%s\n' "$idx" | awk -v p="$p" '/^Package: /{ok=($2==p)} ok && /^Filename: /{print $2; exit}')"
    [ -n "$fn" ] || continue
    keep="$keep$(basename "$fn") "
    [ -f "$TP/$(basename "$fn")" ] || fetch "$repo/$fn" "$TP/$(basename "$fn")"
  done
  for f in "$TP"/*.deb; do [ -e "$f" ] || continue; case "$keep" in *" $(basename "$f") "*) ;; *) rm -f "$f";; esac; done
  log "android: Termux + $(ls "$TP"/*.deb 2>/dev/null | wc -l | tr -d ' ') helper packages (AI + Wikipedia search)"
}
QUICK_MODEL_URL="https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf"
STD_MODEL_URL="https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf"
# Download to "<file>.part", check it really is a PDF/ZIP (not an error page), then rename.
# Finished files are skipped on re-runs; a failed/interrupted .part is resumed next time.
fetch_checked(){ # url out expectedMB -> prints ok | have | FAILED...
  [ -f "$2" ] && { echo have; return; }
  part="$2.part"; why=""
  # Try as a web browser first; a few government sites only answer plain curl, so try that second.
  for ua in "$UA" ""; do
    if [ -n "$ua" ]; then uaargs=(-A "$ua"); else uaargs=(); fi
    curl -f -L -C - --retry 3 --retry-delay 5 $RETRY_ALL -s "${uaargs[@]}" -o "$part" "$1"; rc=$?
    if [ "$rc" = 33 ]; then rm -f "$part"; curl -f -L --retry 3 --retry-delay 5 $RETRY_ALL -s "${uaargs[@]}" -o "$part" "$1"; rc=$?; fi
    if [ "$rc" != 0 ]; then why="curl error $rc"; continue; fi
    # a real file far smaller than the list says is usually an error page dressed up as a PDF
    small=$(awk -v e="${3:-0}" -v g="$(wc -c < "$part")" 'BEGIN{print (e>=0.5 && g/1048576 < e*0.25) ? 1 : 0}')
    case "$(head -c 4 "$part" 2>/dev/null)" in
      %PDF*|PK*) if [ "$small" = 0 ]; then mv -f "$part" "$2"; echo ok; return; fi;;
    esac
    rm -f "$part"; why="the site sent an error page instead of the file - it may have moved"
  done
  echo "FAILED ($why) - will retry on the next run"
}

# ================================================================ LOCAL PACK
if [ "$SKIP_LOCAL" = 0 ]; then
  log "=== [Local] $AREA_NAME pack (books, maps, local rules, guides) ==="
  if [ -z "$(local_items)" ]; then log "local pack: list not found or empty ($LOCAL_LIST)"; else
    ok=0; have=0; bad=0
    while IFS='|' read -r lf ln lu lsz ldesc; do
      lf="$(trim "$lf" | tr '\\' '/')"; ln="$(trim "$ln")"; lu="$(trim "$lu")"
      [ -z "$lu" ] && continue
      mkdir -p "$ROOT/$lf"
      r="$(fetch_checked "$lu" "$ROOT/$lf/$ln" "$(trim "$lsz")")"
      case "$r" in ok) ok=$((ok+1)); log "local: $ln";; have) have=$((have+1));; *) bad=$((bad+1)); log "local: $ln - $r";; esac
    done <<EOF
$(local_items)
EOF
    log "local pack: $ok downloaded, $have already on the drive, $bad failed"
  fi
else log "=== [Local] pack SKIPPED ==="; fi

if true; then   # ---- the big library: each part below checks its own switch (GET_... / SKIP_...)
# ================================================================ 1. AI engine
if [ "$GET_AI" = 1 ]; then
  log "=== [1/8] Offline AI engine (llama.cpp) for every kind of device ==="
  get_ai_engines
else log "=== [1/8] AI engine SKIPPED ==="; fi

# ================================================================ 2. AI models
log "=== [2/8] AI chat models (GGUF) ==="
if [ "$GET_AI" = 1 ]; then
  fetch "$QUICK_MODEL_URL" "$ROOT/AI-Offline/models/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf"; log "model: Qwen2.5-1.5B (quick) done"
  fetch "$STD_MODEL_URL" "$ROOT/AI-Offline/models/Llama-3.2-3B-Instruct-Q4_K_M.gguf"
  log "model: Llama-3.2-3B done"
else log "models: small models skipped"; fi
if [ "$SKIP_MODELS" = 0 ]; then
  fetch "https://huggingface.co/bartowski/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf" "$ROOT/AI-Offline/models/Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf"; log "model: Llama-3.1-8B done"
  fetch "https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf" "$ROOT/AI-Offline/models/Qwen2.5-7B-Instruct-Q4_K_M.gguf"; log "model: Qwen2.5-7B done"
else
  log "models: large models skipped"
fi

# ================================================================ 3. GPT4All
log "=== [3/8] GPT4All (offline document Q&A) ==="
if [ "$GET_GPT4ALL" = 0 ]; then
  log "gpt4all: SKIPPED"
elif [ "$PLAT" = mac ]; then
  u="$(gh_asset_latest nomic-ai/gpt4all 'installer-macos-v.*\.dmg$')"
  [ -n "$u" ] && { log "gpt4all: $(basename "$u")"; fetch "$u" "$ROOT/AI-Offline/DocReader-GPT4All/$(basename "$u")"; }
else
  u="$(gh_asset_latest nomic-ai/gpt4all 'installer-linux-v.*\.run$')"
  [ -n "$u" ] && { log "gpt4all: $(basename "$u")"; fetch "$u" "$ROOT/AI-Offline/DocReader-GPT4All/$(basename "$u")"; chmod +x "$ROOT/AI-Offline/DocReader-GPT4All/$(basename "$u")" 2>/dev/null; }
fi

# ================================================================ 4. Kiwix reader
log "=== [4/8] Kiwix reader ==="
if [ "$GET_READER" = 0 ]; then
  log "kiwix reader: SKIPPED"
elif [ "$PLAT" = linux ] && [ "$CPU" = x64 ]; then
  ai="$(curl -sL -A "$UA" https://download.kiwix.org/release/kiwix-desktop/ | grep -oE 'kiwix-desktop_x86_64_[0-9][^\"]*\.appimage' | sort -u | tail -n1)"
  if [ -n "$ai" ]; then log "kiwix: $ai"; fetch "https://download.kiwix.org/release/kiwix-desktop/$ai" "$ROOT/Kiwix-Reader/$ai"; chmod +x "$ROOT/Kiwix-Reader/$ai" 2>/dev/null; fi
else
  log "kiwix desktop: on macOS install 'Kiwix' from the Mac App Store or kiwix.org; on Linux-ARM use the Kiwix website. (ZIMs still work via the bundled Android app or any Kiwix build.)"
fi

if [ "$GET_MEDICAL" = 1 ] || [ "$GET_REPAIR" = 1 ] || [ "$SKIP_WIKI" = 0 ]; then get_archive_search; fi

# ================================================================ 5. ZIM archives
log "=== [5/8] Offline archives (Kiwix ZIM) ==="
# Kiwix publishes new editions of these archives every few months. Get the newest one; if an older
# edition is already here, update only when the drive has room for both, and delete the old one once
# the new one is complete. Unfinished older downloads are removed. A .zim is complete when its size is
# the checksum position written in its header (bytes 72-79) plus the 16-byte checksum.
zim_complete(){ local p sz; [ -f "$1" ] || return 1
  p="$(od -An -tu8 -j72 -N8 "$1" 2>/dev/null | tr -d ' \n')"; sz="$(wc -c < "$1" | tr -d ' ')"
  [ -n "$p" ] && [ -n "$sz" ] && [ "$sz" = "$((p + 16))" ]; }
remote_bytes(){ curl -sIL -A "$UA" --max-time 30 "$1" 2>/dev/null | tr -d '\r' | awk 'tolower($1)=="content-length:"{n=$2} END{printf "%.0f", n+0}'; }
free_bytes(){ df -Pk "$1" 2>/dev/null | awk 'NR==2{printf "%.0f", $4*1024}'; }
drop_zims(){ # folder regex keep: delete the files matching regex except "keep"
  ls "$1" 2>/dev/null | grep -E "$2" | while IFS= read -r f; do
    [ "$f" = "$3" ] && continue; rm -f "$1/$f" && log "  removed $f (making way for $3)"; done; }
get_zim(){ # server-folder prefix dest-folder label [note] [regex of other files the new one replaces]
  local avail newest have f old need free
  mkdir -p "$3"
  avail="$(curl -sL -A "$UA" "$1" | grep -oE "$2[0-9-]+\.zim" | sort -u)"
  newest="$(printf '%s\n' "$avail" | tail -n1)"
  [ -n "$newest" ] || { log "$4: could not find $2*.zim on $1"; return 0; }
  have="$(ls "$3" 2>/dev/null | grep -E "^$2[0-9-]+\.zim$" | sort)"
  if ! printf '%s\n' "$have" | grep -qx "$newest"; then
    old=""
    for f in $have; do
      if zim_complete "$3/$f"; then old="$f"; else rm -f "$3/$f"; log "$4: removed an unfinished older download ($f)"; fi
    done
    need="$(remote_bytes "$1$newest")"; free="$(free_bytes "$3")"
    if [ -n "$old" ]; then
      if [ "${need:-0}" -gt 0 ] && [ "${free:-0}" -gt $((need + 1073741824)) ]; then
        log "$4: updating $old to the newer $newest (the old one is deleted once the new one is complete)"
      elif [ "${need:-0}" -gt 0 ]; then
        log "$4: keeping $old - the newer $newest needs about $(( (need + 1073741823) / 1073741824 + 1 )) GB free beside it to update"
        return 0
      else
        log "$4: keeping $old (couldn't check the size of the newer $newest - try again later)"
        return 0
      fi
    elif [ -n "$6" ] && [ "${need:-0}" -gt 0 ] && [ "${free:-0}" -lt $((need + 1073741824)) ]; then
      # switching to another size of Wikipedia: make room by removing the size no longer wanted
      drop_zims "$3" "$6" "$newest"
    fi
  fi
  log "$4: $newest${5:+ $5}"
  fetch "$1$newest" "$3/$newest" && zim_complete "$3/$newest" && drop_zims "$3" "${6:-^$2[0-9-]+\.zim$}" "$newest"
  return 0
}
add_zim(){ get_zim "$1" "$2" "$3" "zim"; }
if [ "$GET_REPAIR" = 1 ]; then
add_zim "https://download.kiwix.org/zim/ifixit/"    "ifixit_en_all_"            "$ROOT/Manuals/Repair-iFixit"
add_zim "https://download.kiwix.org/zim/other/"     "appropedia_en_all_maxi_"   "$ROOT/Manuals/DIY-Appropedia"
add_zim "https://download.kiwix.org/zim/other/"     "zimgit-post-disaster_en_"  "$ROOT/Manuals/Survival-Water-Food"
add_zim "https://download.kiwix.org/zim/other/"     "zimgit-water_en_"          "$ROOT/Manuals/Survival-Water-Food"
add_zim "https://download.kiwix.org/zim/other/"     "zimgit-food-preparation_en_" "$ROOT/Manuals/Survival-Water-Food"
add_zim "https://download.kiwix.org/zim/other/"     "zimgit-knots_en_"          "$ROOT/Manuals/Survival-Water-Food"
else log "zim: repair and survival archives SKIPPED"; fi
if [ "$GET_MEDICAL" = 1 ]; then
add_zim "https://download.kiwix.org/zim/wikipedia/" "wikipedia_en_medicine_maxi_" "$ROOT/Medical/WikiMed"
add_zim "https://download.kiwix.org/zim/other/"     "zimgit-medicine_en_"       "$ROOT/Medical/zimgit-medicine"
else log "zim: medical archives SKIPPED"; fi

# ================================================================ 6. PDFs
log "=== [6/8] Public-domain manuals (PDF) ==="
ia_pdf(){ curl -sL -A "$UA" "https://archive.org/metadata/$1" | grep -oE '"name":"[^"]+\.pdf"' | sed -E 's/"name":"([^"]+)"/\1/' | grep -vE '_text\.pdf$' | head -n1; }
get_pdf(){ # id  localname  destdir
  f="$(ia_pdf "$1")"
  if [ -n "$f" ]; then
    enc="$(printf '%s' "$f" | sed 's/ /%20/g')"
    log "pdf: $2"; fetch "https://archive.org/download/$1/$enc" "$3/$2"
  else log "pdf: none for $1"; fi
}
AFM="$ROOT/Manuals/ArmyFieldManuals"; MPDF="$ROOT/Medical/Manuals-PDF"
if [ "$GET_READER" = 1 ]; then
get_pdf "fm-21-76-us-army-survival-manual"                    "FM 21-76 Army Survival Manual.pdf" "$AFM"
get_pdf "fm-3-05.70-survival-2002"                            "FM 3-05.70 Survival (2002).pdf" "$AFM"
get_pdf "105-page-survival-field-manual"                      "105-Page Survival Field Manual.pdf" "$AFM"
get_pdf "UsArmyFirstAidManualFm4-25.11"                       "FM 4-25.11 First Aid.pdf" "$AFM"
get_pdf "Survival-FirstAidForSoldiers-AFieldManual"          "Survival and First Aid for Soldiers.pdf" "$AFM"
get_pdf "use-and-care-of-hand-tools-and-measuring-tools-1983" "TM 9-243 Use and Care of Hand Tools.pdf" "$AFM"
get_pdf "fm-5-426-carpentry-1995"                            "FM 5-426 Carpentry.pdf" "$AFM"
get_pdf "tm-9-8000-principles-of-automotive-vehicles-1985"   "TM 9-8000 Principles of Automotive Vehicles.pdf" "$AFM"
get_pdf "u-s-army-guide-to-rigging"                          "FM 5-125 Army Guide to Rigging.pdf" "$AFM"
get_pdf "fm-90-3-desert-operations-1993"                     "FM 90-3 Desert Operations.pdf" "$AFM"
get_pdf "tm-10-412-armed-forces-recipe-service-2003"         "TM 10-412 Armed Forces Recipe Service.pdf" "$AFM"
get_pdf "where-there-is-no-dentist-13th-printing-2010"       "Where There Is No Dentist.pdf" "$MPDF"
else log "pdf: SKIPPED (Army manuals not chosen)"; fi
# (Where There Is No Doctor and Ship's Medicine Chest were archive.org lending copies that refuse
#  downloads; working copies now come from local/library-files.txt)

# ================================================================ 7. Wikipedia + Maps
if [ "$SKIP_WIKI" = 0 ]; then
  # Readable offline Wikipedia = Kiwix's ready-made .zim (opens in Kiwix on PC and phone).
  # The old raw pages-articles.xml.bz2 dump could not be opened by anything in this kit.
  log "=== [7/8] Wikipedia (Kiwix ZIM, '$WIKI_SIZE' edition - maxi ~120 GB with pictures) ==="
  # (a newer edition replaces the old one only when there's room for both; choosing another size
  #  replaces the old size once the new one is complete - or first, if there's no room for both)
  get_zim "https://download.kiwix.org/zim/wikipedia/" "wikipedia_en_all_${WIKI_SIZE}_" "$ROOT/Wikipedia" "wikipedia" \
    "(this is the longest download - often overnight)" '^wikipedia_en_all_(maxi|nopic|mini)_[0-9-]+\.zim$'
else log "=== [7/8] Wikipedia SKIPPED ==="; fi

if [ "$SKIP_MAPS" = 0 ]; then
  log "=== [8/8] Offline maps (OsmAnd) - region: $REGION ==="
  curl -s "https://download.osmand.net/get_indexes" -o "$ROOT/OsmAnd/_index.xml"
  # only <region type="map"> entries: the index also lists <deleted_map> files (e.g. Florida and New York
  # before they were split), which no longer download (404) and cost a minute of retries each
  allnames="$(grep -oE '<region [^>]*>' "$ROOT/OsmAnd/_index.xml" | grep 'type="map"' | grep -oE 'name="[^"]+\.obf\.zip"' | sed -E 's/name="([^"]+)"/\1/' | grep -viE 'wiki|srtm|depth|road|hillshade|heightmap')"
  : > "$ROOT/OsmAnd/_filelist.txt"
  # (printf ends the list with a newline: "read" skips a last line that has none, which dropped the
  #  last region - for the usual single region, US, that meant no maps at all)
  printf '%s\n' "$REGION" | tr ',;' '  ' | tr ' ' '\n' | while IFS= read -r tok; do
    [ -z "$tok" ] && continue
    tl="$(printf '%s' "$tok" | tr 'A-Z' 'a-z')"
    if [ "$tl" = world ]; then printf '%s\n' "$allnames" >> "$ROOT/OsmAnd/_filelist.txt"
    elif echo "$CONTINENTS" | grep -qw "$tl"; then printf '%s\n' "$allnames" | grep -iE "_${tl}_" >> "$ROOT/OsmAnd/_filelist.txt"
    else printf '%s\n' "$allnames" | grep -iE "^${tok}_" >> "$ROOT/OsmAnd/_filelist.txt"
    fi
  done
  sort -u "$ROOT/OsmAnd/_filelist.txt" -o "$ROOT/OsmAnd/_filelist.txt"
  n=$(grep -c . "$ROOT/OsmAnd/_filelist.txt" 2>/dev/null || echo 0)
  if [ "$n" = "0" ]; then
    log "osmand: no maps matched region '$REGION'. Run with --list-regions to see valid names. Skipping maps."
  else
  log "osmand: $n map files for '$REGION'"
  while IFS= read -r fn; do [ -n "$fn" ] && fetch "https://download.osmand.net/download.php?standard=yes&file=$fn" "$ROOT/OsmAnd/$fn"; done < "$ROOT/OsmAnd/_filelist.txt"
  fi

  # desktop map viewer (OsmAndMapCreator + portable Java) — use maps on a PC, no phone
  MVD="$ROOT/OsmAnd/MapViewer-Desktop"
  if [ "$GET_VIEWER" = 0 ]; then
    log "desktop map viewer: SKIPPED"
  elif [ "$HAVE_UNZIP" = 1 ]; then
    log "=== [8b] Desktop map viewer (OsmAndMapCreator + portable Java) ==="
    mkdir -p "$MVD/app"
    fetch "https://download.osmand.net/latest-night-build/OsmAndMapCreator-main.zip" "$MVD/OsmAndMapCreator.zip"
    unzip -o -q "$MVD/OsmAndMapCreator.zip" -d "$MVD/app"
    jreurl="https://api.adoptium.net/v3/binary/latest/21/ga/${PLAT}/${JARCH}/jre/hotspot/normal/eclipse"
    [ "$PLAT" = mac ] && jreurl="https://api.adoptium.net/v3/binary/latest/21/ga/mac/${JARCH}/jre/hotspot/normal/eclipse"
    fetch "$jreurl" "$MVD/jre.tar.gz"
    mkdir -p "$MVD/_jre"; tar -xf "$MVD/jre.tar.gz" -C "$MVD/_jre" 2>/dev/null
    rm -rf "$MVD/jre"; mv "$MVD/_jre"/*/ "$MVD/jre" 2>/dev/null; rm -rf "$MVD/_jre"
    cat > "$MVD/VIEW-MAPS-ON-PC.sh" <<'EOS'
#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
# find bundled java
JAVA="$(find "$DIR/jre" -name java -type f 2>/dev/null | head -n1)"
[ -n "$JAVA" ] && export PATH="$(dirname "$JAVA"):$PATH"
MAPS="$(cd "$DIR/.." && pwd)"; OBF="$MAPS/obf"; mkdir -p "$OBF"
echo "Preparing maps for desktop viewing (first run can take several minutes)..."
for z in "$MAPS"/*.obf.zip; do
  [ -e "$z" ] || continue
  base="$(basename "$z" .zip)"
  [ -e "$OBF/$base" ] || unzip -o -q "$z" -d "$OBF"
done
echo "Maps ready in: $OBF"
sh "$DIR/app/OsmAndMapCreator.sh" 2>/dev/null || bash "$DIR/app/OsmAndMapCreator.sh"
EOS
    chmod +x "$MVD/VIEW-MAPS-ON-PC.sh" 2>/dev/null
    find "$MVD/app" -name "*.sh" -exec chmod +x {} \; 2>/dev/null
    find "$MVD/jre" -name java -exec chmod +x {} \; 2>/dev/null
  else
    log "desktop map viewer: skipped (install 'unzip' then re-run to enable)"
  fi
else log "=== [8/8] Maps SKIPPED ==="; fi

# ================================================================ phone apps
log "=== Phone apps (port the library to a phone) ==="
PA="$ROOT/Phone-Apps"
if [ "$GET_READER" = 1 ]; then
  ku="$(gh_asset_latest kiwix/kiwix-android 'universal-standalone\.apk$')"
  [ -z "$ku" ] && ku="$(gh_asset_latest kiwix/kiwix-android '\.apk$')"
  [ -n "$ku" ] && { log "phone app: Kiwix $(basename "$ku")"; fetch "$ku" "$PA/$(basename "$ku")"; }
fi
if [ "$SKIP_MAPS" = 0 ]; then
  vc="$(curl -sL -A "$UA" https://f-droid.org/api/v1/packages/net.osmand.plus | grep -oE '"suggestedVersionCode":[0-9]+' | grep -oE '[0-9]+' | head -n1)"
  [ -n "$vc" ] && { log "phone app: OsmAnd~ $vc"; fetch "https://f-droid.org/repo/net.osmand.plus_$vc.apk" "$PA/OsmAnd-$vc.apk"; }
fi
# Termux and its packages let an Android tablet run the Library Assistant and Wikipedia search (and the AI)
if [ "$GET_AI" = 1 ] || { { [ -n "$PARTS" ] || [ "$USE_PLANNER" = 1 ]; } && [ "$SKIP_OTHER" = 0 ]; }; then get_android_kit; fi

# ================================================================ launchers (.sh)
if [ "$GET_AI" = 1 ]; then
log "=== Writing launchers ==="
AO="$ROOT/AI-Offline"
make_launcher(){ # file  model  extra-args
cat > "$AO/$1" <<EOS
#!/usr/bin/env bash
DIR="\$(cd "\$(dirname "\$0")" && pwd)"
case "\$(uname -s)/\$(uname -m)" in Darwin/arm64) P=mac-arm64;; Darwin/*) P=mac-x64;; */aarch64|*/arm64) P=linux-arm64;; *) P=linux-x64;; esac
CLI="\$(find "\$DIR/engine/\$P" "\$DIR/engine/metal" "\$DIR/engine/cpu" -name llama-cli -type f 2>/dev/null | head -n1)"
[ -z "\$CLI" ] && { echo "AI engine not found in \$DIR/engine"; exit 1; }
LIBDIR="\$(dirname "\$CLI")"
export LD_LIBRARY_PATH="\$LIBDIR:\${LD_LIBRARY_PATH:-}"
export DYLD_LIBRARY_PATH="\$LIBDIR:\${DYLD_LIBRARY_PATH:-}"
exec "\$CLI" -m "\$DIR/models/$2" -c 4096 $3 -cnv
EOS
chmod +x "$AO/$1" 2>/dev/null
}
make_launcher "chat-3B-light.sh" "Llama-3.2-3B-Instruct-Q4_K_M.gguf" ""
make_launcher "chat-8B-smart.sh" "Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf" ""
if [ "$PLAT" = linux ]; then
  # GPU launcher uses the Vulkan engine subdir
  cat > "$AO/chat-GPU-Qwen7B.sh" <<'EOS'
#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
CLI="$(find "$DIR/engine/linux-vulkan-x64" "$DIR/engine/gpu" -name llama-cli -type f 2>/dev/null | head -n1)"
[ -z "$CLI" ] && CLI="$(find "$DIR/engine/linux-x64" "$DIR/engine/cpu" -name llama-cli -type f 2>/dev/null | head -n1)"
LIBDIR="$(dirname "$CLI")"; export LD_LIBRARY_PATH="$LIBDIR:${LD_LIBRARY_PATH:-}"
exec "$CLI" -m "$DIR/models/Qwen2.5-7B-Instruct-Q4_K_M.gguf" -c 4096 -ngl 99 -cnv
EOS
  chmod +x "$AO/chat-GPU-Qwen7B.sh" 2>/dev/null
fi
cat > "$AO/web-ui.sh" <<'EOS'
#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
case "$(uname -s)/$(uname -m)" in Darwin/arm64) P=mac-arm64;; Darwin/*) P=mac-x64;; */aarch64|*/arm64) P=linux-arm64;; *) P=linux-x64;; esac
SRV="$(find "$DIR/engine/$P" "$DIR/engine/metal" "$DIR/engine/cpu" -name llama-server -type f 2>/dev/null | head -n1)"
[ -z "$SRV" ] && { echo "server not found"; exit 1; }
LIBDIR="$(dirname "$SRV")"; export LD_LIBRARY_PATH="$LIBDIR:${LD_LIBRARY_PATH:-}"; export DYLD_LIBRARY_PATH="$LIBDIR:${DYLD_LIBRARY_PATH:-}"
echo "Open http://127.0.0.1:8080 when it says 'server listening'"
exec "$SRV" -m "$DIR/models/Llama-3.2-3B-Instruct-Q4_K_M.gguf" -c 4096 --host 127.0.0.1 --port 8080
EOS
chmod +x "$AO/web-ui.sh" 2>/dev/null

fi   # ---- end of: if GET_AI = 1 (launchers)
fi   # ---- end of the big library (the community kit is now just a preset of these switches)

# ================================================================ documentation
log "=== Documentation (Markdown + HTML) ==="
place_doc(){ # base  destpath
  for ext in md html; do
    if [ -f "$SCRIPTDIR/docs/$1.$ext" ]; then cp "$SCRIPTDIR/docs/$1.$ext" "$2.$ext"
    else curl -sf -A "$UA" "$REPO_RAW/docs/$1.$ext" -o "$2.$ext" || log "  doc missing: $1.$ext"; fi
  done
}
# every page and where it goes on the drive: local/pages.txt (name|folder/name), written by tools/region.py
[ -f "$SCRIPTDIR/local/pages.txt" ] || curl -sf -A "$UA" "$REPO_RAW/local/pages.txt" -o "$SCRIPTDIR/local/pages.txt" || log "  page list missing"
while IFS='|' read -r pname pdest; do
  case "$pname" in ''|'#'*) continue;; esac
  mkdir -p "$(dirname "$ROOT/$pdest")"
  place_doc "$pname" "$ROOT/$pdest"
done < <(tr -d '\r' < "$SCRIPTDIR/local/pages.txt" 2>/dev/null)
# the pictures in the guides (drawings from the books and diagrams): the guides look for them here
if [ -d "$SCRIPTDIR/docs/img" ]; then
  mkdir -p "$ROOT/$LOCAL_DIR/guide-images" && cp -R "$SCRIPTDIR/docs/img/." "$ROOT/$LOCAL_DIR/guide-images/"
else log "  guide pictures: run the installer from the kit to include them"; fi
# Unit converter and calculators (one offline page at the top of the drive)
if [ -f "$SCRIPTDIR/local/unit-converter/UNIT-CONVERTER.html" ]; then cp "$SCRIPTDIR/local/unit-converter/UNIT-CONVERTER.html" "$ROOT/UNIT-CONVERTER.html"; log "unit converter: copied to UNIT-CONVERTER.html"
else curl -sf -A "$UA" "$REPO_RAW/local/unit-converter/UNIT-CONVERTER.html" -o "$ROOT/UNIT-CONVERTER.html" || log "  unit converter missing"; fi
[ -f "$ROOT/UNIT-CONVERTER.html" ] && sed -i.bak "s#{{drive_folder}}#$LOCAL_DIR#g" "$ROOT/UNIT-CONVERTER.html" && rm -f "$ROOT/UNIT-CONVERTER.html.bak"
# calculator (basic + scientific, offline), next to the unit converter at the top of the drive
if [ -f "$SCRIPTDIR/local/calculator/CALCULATOR.html" ]; then cp "$SCRIPTDIR/local/calculator/CALCULATOR.html" "$ROOT/CALCULATOR.html"; log "calculator: copied to CALCULATOR.html"
else curl -sf -A "$UA" "$REPO_RAW/local/calculator/CALCULATOR.html" -o "$ROOT/CALCULATOR.html" || log "  calculator missing"; fi
# offline Pill Identifier (NLM Pillbox data, shipped in local/pill-identifier)
if [ -d "$SCRIPTDIR/local/pill-identifier" ]; then
  mkdir -p "$ROOT/Medical/Pill-Identifier"
  cp -R "$SCRIPTDIR/local/pill-identifier/." "$ROOT/Medical/Pill-Identifier/"
  log "pill identifier: copied to Medical/Pill-Identifier"
fi
# walking routes from the home town (pre-built pages + GPX tracks, shipped in local/walking-routes)
if [ -d "$SCRIPTDIR/local/walking-routes" ]; then
  mkdir -p "$ROOT/$LOCAL_DIR/Walking-Routes"
  cp -R "$SCRIPTDIR/local/walking-routes/." "$ROOT/$LOCAL_DIR/Walking-Routes/"
  log "walking routes: copied to $LOCAL_DIR/Walking-Routes"
fi
# Library Assistant (one search for everything + the AI) and one start file per kind of device
if [ -d "$SCRIPTDIR/local/library-assistant" ]; then
  mkdir -p "$ROOT/AI-Offline/Library-Assistant"
  for f in "$SCRIPTDIR/local/library-assistant/"*; do [ "$(basename "$f")" = src ] || cp -R "$f" "$ROOT/AI-Offline/Library-Assistant/"; done
  chmod +x "$ROOT/AI-Offline/Library-Assistant/library-assistant-"* 2>/dev/null
  log "library assistant: copied to AI-Offline/Library-Assistant"
fi
if [ -d "$SCRIPTDIR/local/launchers" ]; then
  cp "$SCRIPTDIR/local/launchers/"START-* "$SCRIPTDIR/local/launchers/"SETUP-* "$ROOT/" && chmod +x "$ROOT/START-Mac.command" "$ROOT/START-Linux.sh" "$ROOT/START-Android.sh" "$ROOT/SETUP-Raspberry-Pi.sh" 2>/dev/null
  log "start files: START-Windows.bat, START-Mac.command, START-Linux.sh, START-Android.sh (+ SETUP-Raspberry-Pi.sh for a Pi with no screen)"
fi

# ================================================================ README index
log "=== Building README.html (full index of everything) ==="
IDX="$ROOT/README.html"
IDXCSS='<style>:root{--bg:#0f1420;--card:#171f2e;--ink:#e7ecf3;--muted:#9fb0c3;--accent:#4fd1c5;--accent2:#f6ad55;--line:#273246;--code:#0b0f17}@media(prefers-color-scheme:light){:root:not([data-theme=dark]){--bg:#f4f6fb;--card:#fff;--ink:#15202b;--muted:#56657a;--accent:#0d9488;--accent2:#b45309;--line:#e2e8f0;--code:#f1f5f9}}:root[data-theme=light]{--bg:#f4f6fb;--card:#fff;--ink:#15202b;--muted:#56657a;--accent:#0d9488;--accent2:#b45309;--line:#e2e8f0;--code:#f1f5f9}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.65 -apple-system,Segoe UI,Roboto,Arial,sans-serif}.wrap{max-width:1000px;margin:0 auto;padding:28px 20px 80px}h1{font-size:30px;background:linear-gradient(135deg,var(--accent),var(--accent2));-webkit-background-clip:text;background-clip:text;color:transparent}h2{font-size:21px;border-bottom:2px solid var(--line);padding-bottom:6px;margin-top:32px}a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}code{background:var(--code);padding:2px 6px;border-radius:6px;font-family:Consolas,monospace;font-size:13px}table{border-collapse:collapse;width:100%;margin:10px 0;font-size:14.5px}th,td{border:1px solid var(--line);padding:8px 11px;text-align:left;vertical-align:top}th{background:rgba(127,127,127,.12)}.muted{color:var(--muted);font-size:13px}.hero{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px;margin:14px 0}details.sec{background:var(--card);border:1px solid var(--line);border-radius:14px;margin:12px 0;padding:0 14px}details.sec>summary{cursor:pointer;font-weight:700;font-size:20px;padding:12px 0}details.sec .n{font-size:12px;font-weight:600;padding:0 8px;border-radius:999px;background:rgba(127,127,127,.16);color:var(--muted);margin-left:8px;vertical-align:middle}</style><script>document.addEventListener("DOMContentLoaded",function(){[].slice.call(document.querySelectorAll(".wrap > h2")).forEach(function(h,i){var d=document.createElement("details"),s=document.createElement("summary");d.className="sec";if(i===0)d.open=true;s.innerHTML=h.innerHTML;h.parentNode.insertBefore(d,h);d.appendChild(s);var n=h.nextSibling;h.parentNode.removeChild(h);while(n&&!(n.nodeType===1&&n.tagName==="H2")){var x=n.nextSibling;d.appendChild(n);n=x}var c=d.querySelectorAll("tr").length-d.querySelectorAll("table").length;if(c>0){var b=document.createElement("span");b.className="n";b.textContent=c;s.appendChild(b)}})});</script><style>:root{color-scheme:dark}@media(prefers-color-scheme:light){:root:not([data-theme=dark]){color-scheme:light}}:root[data-theme=light]{color-scheme:light}.themebtn{font:inherit;font-size:14px;line-height:1.3;background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:999px;padding:3px 11px;cursor:pointer;white-space:nowrap;text-decoration:none}.themefloat{position:absolute;top:10px;right:12px;z-index:9}@media print{.themebtn{display:none}}</style><script>/* so-theme: light or dark screen */(function(){var K="so-theme",d=document.documentElement,L={auto:"\uD83C\uDF13 Auto",dark:"\uD83C\uDF19 Dark",light:"\u2600\uFE0F Light"},N={auto:"dark",dark:"light",light:"auto"},cur="auto";try{cur=localStorage.getItem(K)||"auto"}catch(e){}function a(){if(cur==="dark"||cur==="light")d.setAttribute("data-theme",cur);else d.removeAttribute("data-theme");var b=document.querySelectorAll(".themebtn");for(var i=0;i<b.length;i++){b[i].textContent=L[cur]||L.auto;b[i].title="Screen: "+cur+" - tap to change (Auto follows this device)"}}a();window.soTheme=function(){cur=N[cur]||"dark";try{localStorage.setItem(K,cur)}catch(e){}a()};function btn(){var b=document.createElement("button");b.type="button";b.className="themebtn";return b}document.addEventListener("DOMContentLoaded",function(){if(!document.querySelector(".themebtn")){var n=document.querySelector(".topnav"),b=btn();if(n){n.appendChild(document.createTextNode(" \u00B7 "));n.appendChild(b)}else{b.className+=" themefloat";document.body.appendChild(b)}}var all=document.querySelectorAll(".themebtn");for(var i=0;i<all.length;i++)all[i].onclick=window.soTheme;a()})})();</script>'
relp(){ printf '%s' "${1#"$ROOT"/}"; }
nicen(){ b="$(basename "$1")"; b="${b%.*}"; printf '%s' "$b" | tr '_-' '  '; }
hsz(){ du -h "$1" 2>/dev/null | cut -f1; }
esc(){ printf '%s' "$1" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'; }
# ---- local pack index: <area folder>/LOCAL-FILES.html (what each local file is, with links)
# Grouped on the same "shelves" as the Library Assistant's Books tab; every group folds open/closed.
SHELF_NAMES=('&#x1F9ED; Start here' '&#x1FA79; Health &amp; medicine' '&#x1F4A7; Water' '&#x1F35E; Food' '&#x1F332; Living off the land' '&#x1F410; Animals' '&#x1F3E0; Shelter &amp; building' '&#x1F4A1; Heat, light &amp; power' '&#x1F6E0;&#xFE0F; Making &amp; repair' '&#x1F97E; Getting around' '&#x1F4E1; Radio, community &amp; protection' '&#x1F6A8; Disasters' '&#x1F4D6; Stories &amp; fun' '&#x1F4BE; Using this library' '&#x1F4C1; Other')
shelf_of(){ # folder (without the area folder) -> shelf number (same groups as the Library Assistant)
  case "${1%%/*}" in
    Manuals) case "$1" in Manuals/Radio*) echo 10;; *) echo 13;; esac;;
    Local-Contacts) echo 0;;
    Medical|Sanitation-Hygiene|Children-Learning) echo 1;;
    Water|Water-Purification|Water-Wells-Pumps) echo 2;;
    Food-Security|Food-From-Scratch|Food-Storage|Gardening-Food) echo 3;;
    Wild-Plants|Mushrooms|Hunting|Trapping|Fishing|Native-Skills) echo 4;;
    Animals|Small-Livestock|Horses-Draft-Animals) echo 5;;
    Shelter-Building|Natural-Building) echo 6;;
    Firewood|Off-Grid-Power|Fuel|Engines-Motors) echo 7;;
    Homestead-Skills|Blacksmithing-Tools|Clothing-Leather|Electronics-Repair|Math-Measuring) echo 8;;
    Travel-On-Foot|Bicycles-Carts|Navigation-Weather|Maps|Walking-Routes) echo 9;;
    Comms-Signals|Radio-Weather|Community-Barter|Home-Security) echo 10;;
    Wildfire|Disaster-Scenarios|Earthquake-Tsunami|Nuclear-Radiation|EMP-Solar-Storms) echo 11;;
    Stories) echo 12;;
    *) echo 14;;
  esac; }
NAVCSS='<style>.topnav{font-size:14.5px;margin:-28px -20px 8px;padding:10px 20px 8px;color:var(--muted);position:sticky;top:0;z-index:4;background:var(--bg);border-bottom:1px solid var(--line)}.topnav a{text-decoration:none;white-space:nowrap}</style><style>.backbtn{font-weight:700;text-decoration:none;white-space:nowrap}@media print{.backbtn{display:none}}@media(max-width:600px){.topnav{white-space:nowrap;overflow-x:auto;scrollbar-width:none;font-size:14px}.topnav::-webkit-scrollbar{display:none}.topnav .lbl{display:none}.topnav .themebtn{font-size:13px;padding:2px 9px}}</style><script>/* so-back: a Back button on every page after the first */(function(){function add(){var n=document.querySelector(".topnav");if(!n||n.querySelector(".backbtn"))return;var f=n.querySelector("a"),a=document.createElement("a");a.className="backbtn";a.href=f?f.href:"#";a.textContent="\u2190 Back";a.title="Back to the page you came from";a.onclick=function(e){if(history.length>1&&document.referrer){e.preventDefault();history.back()}};n.insertBefore(document.createTextNode(" \u00B7 "),n.firstChild);n.insertBefore(a,n.firstChild)}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",add);else add();document.addEventListener("click",function(e){var a=e.target&&e.target.closest?e.target.closest("a[href^=\"#\"]"):null;if(!a||e.defaultPrevented)return;var id=decodeURIComponent(a.getAttribute("href").slice(1)),t=id?document.getElementById(id):null;if(!t)return;e.preventDefault();t.scrollIntoView();try{history.replaceState(history.state,"","#"+id)}catch(x){}})})();</script>'
LFCSS='<style>details{background:var(--card);border:1px solid var(--line);border-radius:14px;margin:10px 0}details details{border:none;border-top:1px solid var(--line);border-radius:0;margin:0}summary{cursor:pointer;padding:12px 16px;font-weight:700;font-size:18px}details details summary{font-size:15.5px;color:var(--accent2);padding:10px 16px}.in{padding:0 12px 10px}.n{font-size:12px;font-weight:600;padding:0 8px;border-radius:999px;background:rgba(127,127,127,.16);color:var(--muted);margin-left:6px;vertical-align:middle}input[type=search]{width:100%;font:inherit;padding:10px 12px;border-radius:12px;border:1px solid var(--line);background:var(--card);color:var(--ink)}button{font:inherit;font-size:14px;background:none;border:none;color:var(--accent);text-decoration:underline;cursor:pointer;padding:4px 0}table{display:block;overflow-x:auto}</style>'
LFJS='<script>function filt(v){v=v.toLowerCase().trim();document.querySelectorAll("tr.f").forEach(function(r){r.style.display=(!v||r.textContent.toLowerCase().indexOf(v)>=0)?"":"none"});document.querySelectorAll("details").forEach(function(d){var n=0;d.querySelectorAll("tr.f").forEach(function(r){if(r.style.display!=="none")n++});d.style.display=n?"":"none";d.open=!!v&&n>0})}function openAll(o){document.querySelectorAll("details").forEach(function(d){d.open=o})}</script>'
if [ -n "$(local_items)" ]; then
  {
    printf '%s' "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>$(esc "$AREA_NAME") - Local Files</title>$IDXCSS$NAVCSS$LFCSS$LFJS</head><body><div class=\"wrap\"><p class='topnav'><a href='../START-HERE.html#guides-by-subject'>&#x1F4D8; Guides</a> &middot; <a href='../EMERGENCY-FINDER.html'>&#x1F198;<span class='lbl'> Emergency</span></a> &middot; <a href='../SUBJECT-INDEX.html'>&#x1F4C7;<span class='lbl'> Index A&ndash;Z</span></a> &middot; <a href='../README.html'>&#x1F4DA; Every file</a></p>"
    printf '%s' "<h1>$(esc "$AREA_TITLE") &mdash; Local Files</h1>"
    printf '%s' "<div class='hero'>Every file in the local pack, what it is, and a link to open it &mdash; grouped by subject. Tap a heading to open it. For the one-page quick reference (radio, weather, contacts, seasons) open <a href='$LOCAL_GUIDE.html'><b>$LOCAL_GUIDE.html</b></a>.<br><span class='muted'>Generated $(date '+%Y-%m-%d %H:%M'). Anything marked <i>not downloaded yet</i> failed or was skipped &mdash; run the installer again to retry.</span></div>"
    printf '%s' "<p><input type='search' placeholder='Filter by title or topic...' oninput='filt(this.value)'></p><p><button onclick='openAll(true)'>Open all</button> &middot; <button onclick='openAll(false)'>Close all</button></p>"
    # number each line with its shelf, sort by shelf, then folder (first time it appears in the list), then list order
    seq=0
    sorted="$(local_items | while IFS='|' read -r lf rest; do
        seq=$((seq+1)); lf="$(trim "$lf" | tr '\\' '/')"
        printf '%s|%06d|%s|%s\n' "$(shelf_of "${lf#"$LOCAL_DIR"/}")" "$seq" "$lf" "$rest"
      done | awk -F'|' -v OFS='|' '!($3 in first){first[$3]=$2} {f=$2; $2=first[$3] "|" f; print}' \
           | sort -t'|' -k1,1n -k2,2n -k3,3n | cut -d'|' -f1,3-)"
    count(){ printf '%s\n' "$sorted" | awk -F'|' -v k="$1" -v g="$2" '$1==k && (g=="" || $3==g)' | wc -l | tr -d ' '; }
    pshelf=""; pgrp=""
    while IFS='|' read -r sh _ lf ln lu lsz ldesc; do
      ln="$(trim "$ln")"; ldesc="$(trim "$ldesc")"
      [ -z "$ln" ] && continue
      if [ "$lf" != "$pgrp" ] || [ "$sh" != "$pshelf" ]; then
        [ -n "$pgrp" ] && printf '%s' "</table></div></details>"
        if [ "$sh" != "$pshelf" ]; then
          [ -n "$pshelf" ] && printf '%s' "</div></details>"
          printf '%s' "<details><summary>${SHELF_NAMES[$sh]} <span class='n'>$(count "$sh" "")</span></summary><div class='in'>"
          pshelf="$sh"
        fi
        grp="${lf#"$LOCAL_DIR"/}"
        printf '%s' "<details><summary>$(esc "$(printf '%s' "$grp" | sed -e 's#/# / #g' -e 's/-/ /g')") <span class='n'>$(count "$sh" "$lf")</span></summary><div class='in'><table><tr><th>File</th><th>What it is</th><th>Size</th></tr>"
        pgrp="$lf"
      fi
      case "$lf" in "$LOCAL_DIR"/*) href="${lf#"$LOCAL_DIR"/}/$ln";; *) href="../$lf/$ln";; esac
      href="$(printf '%s' "$href" | sed -e 's/ /%20/g' -e 's/#/%23/g')"
      if [ -f "$ROOT/$lf/$ln" ]; then
        printf '%s' "<tr class='f'><td><a href=\"$href\">$(esc "$ln")</a></td><td>$(esc "$ldesc")</td><td>$(hsz "$ROOT/$lf/$ln")</td></tr>"
      else
        printf '%s' "<tr class='f'><td>$(esc "$ln") <span class='muted'>(not downloaded yet)</span></td><td>$(esc "$ldesc")</td><td></td></tr>"
      fi
    done <<EOF
$sorted
EOF
    [ -n "$pgrp" ] && printf '%s' "</table></div></details></div></details>"
    printf '%s' "</div></body></html>"
  } > "$ROOT/$LOCAL_DIR/LOCAL-FILES.html"
  log "$LOCAL_DIR/LOCAL-FILES.html written."
fi
{
  printf '%s' "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Offline Emergency Library - Full Index</title>$IDXCSS$NAVCSS</head><body><div class=\"wrap\"><p class='topnav'><a href='START-HERE.html#guides-by-subject'>&#x1F4D8; Guides</a> &middot; <a href='EMERGENCY-FINDER.html'>&#x1F198;<span class='lbl'> Emergency</span></a> &middot; <a href='SUBJECT-INDEX.html'>&#x1F4C7;<span class='lbl'> Index A&ndash;Z</span></a> &middot; <a href='$LOCAL_DIR/LOCAL-FILES.html'>&#x1F3D4;&#xFE0F; Local books</a></p>"
  printf '%s' "<h1>&#128703; Offline Emergency Library &mdash; Full Index</h1>"
  printf '%s' "<div class='hero'>Every guide, document, manual, archive, app and data file on this drive, with links.<br><span class='muted'>Generated $(date '+%Y-%m-%d %H:%M')</span></div>"
  [ -f "$ROOT/START-HERE.html" ] && printf '%s' "<p>&#128073; New here? Start with <a href='START-HERE.html'><b>START-HERE.html</b></a>.</p>"
  # guides
  printf '%s' "<h2>&#128214; Guides &amp; Documentation</h2><table><tr><th>Guide</th><th>Folder</th><th>Open</th></tr>"
  find "$ROOT" -type f -name '*.html' ! -name 'README.html' ! -path '*/Walking-Routes/directions/*' | sort | while read -r f; do
    rel="$(relp "$f")"; dir="$(dirname "$rel")"; [ "$dir" = "." ] && dir='(root)'
    mdrel="${rel%.html}.md"; ml=""; [ -f "$ROOT/$mdrel" ] && ml=" &middot; <a href='$mdrel'>md</a>"
    printf '%s' "<tr><td>$(nicen "$f")</td><td class='muted'>$dir</td><td><a href='$rel'>HTML</a>$ml</td></tr>"
  done
  printf '%s' "</table>"
  # pdfs
  if find "$ROOT" -type f -name '*.pdf' | grep -q .; then
    printf '%s' "<h2>&#128218; Manuals &amp; Books (PDF)</h2><table><tr><th>Document</th><th>Folder</th><th>Size</th><th>Open</th></tr>"
    find "$ROOT" -type f -name '*.pdf' | sort | while read -r f; do rel="$(relp "$f")"; printf '%s' "<tr><td>$(nicen "$f")</td><td class='muted'>$(dirname "$rel")</td><td>$(hsz "$f")</td><td><a href='$rel'>PDF</a></td></tr>"; done
    printf '%s' "</table>"
  fi
  # e-books (the stories shelf)
  if find "$ROOT" -type f -name '*.epub' | grep -q .; then
    printf '%s' "<h2>&#128214; Stories &amp; Classics (e-books)</h2><p class='muted'>Read them in the library: open it and choose Books &rarr; Stories &amp; fun (they open as web pages). Or open a file in an e-book app.</p><table><tr><th>Book</th><th>Folder</th><th>Size</th><th>Open</th></tr>"
    find "$ROOT" -type f -name '*.epub' | sort | while read -r f; do rel="$(relp "$f")"; printf '%s' "<tr><td>$(nicen "$f")</td><td class='muted'>$(dirname "$rel")</td><td>$(hsz "$f")</td><td><a href='$rel'>e-book</a></td></tr>"; done
    printf '%s' "</table>"
  fi
  # zims
  if find "$ROOT" -type f -name '*.zim' | grep -q .; then
    printf '%s' "<h2>&#127760; Offline Archives (ZIM &mdash; open with Kiwix)</h2><table><tr><th>Archive</th><th>Folder</th><th>Size</th><th>File</th></tr>"
    find "$ROOT" -type f -name '*.zim' | sort | while read -r f; do rel="$(relp "$f")"; printf '%s' "<tr><td>$(nicen "$f")</td><td class='muted'>$(dirname "$rel")</td><td>$(hsz "$f")</td><td><a href='$rel'>open</a></td></tr>"; done
    printf '%s' "</table>"
  fi
  # programs
  printf '%s' "<h2>&#9881; Programs &amp; Launchers</h2><table><tr><th>Item</th><th>Folder</th></tr>"
  { find "$ROOT" -type f \( -name '*.bat' -o -name '*.sh' -o -name '*.command' -o -name '*.appimage' -o -name '*.run' -o -name '*.dmg' \); find "$ROOT" -type f -name '*.exe' | grep -iE 'installer|kiwix-desktop'; } | sort -u | while read -r f; do rel="$(relp "$f")"; dir="$(dirname "$rel")"; [ "$dir" = "." ] && dir='(root)'; printf '%s' "<tr><td><a href='$rel'>$(basename "$f")</a></td><td class='muted'>$dir</td></tr>"; done
  printf '%s' "</table>"
  # apks
  if find "$ROOT" -type f -name '*.apk' | grep -q .; then
    printf '%s' "<h2>&#128241; Phone Apps (Android APK)</h2><table><tr><th>App</th><th>Folder</th><th>Size</th></tr>"
    find "$ROOT" -type f -name '*.apk' | sort | while read -r f; do rel="$(relp "$f")"; printf '%s' "<tr><td><a href='$rel'>$(basename "$f")</a></td><td class='muted'>$(dirname "$rel")</td><td>$(hsz "$f")</td></tr>"; done
    printf '%s' "</table>"
  fi
  # data
  if find "$ROOT" -type f \( -name '*.bz2' -o -name '*.obf.zip' \) | grep -q .; then
    printf '%s' "<h2>&#128451; Data</h2><table><tr><th>Item</th><th>Folder</th><th>Size</th></tr>"
    find "$ROOT" -type f -name '*.bz2' | sort | while read -r f; do rel="$(relp "$f")"; printf '%s' "<tr><td>$(basename "$f") <span class='muted'>(Wikipedia)</span></td><td class='muted'>$(dirname "$rel")</td><td>$(hsz "$f")</td></tr>"; done
    mc=$(find "$ROOT" -type f -name '*.obf.zip' | wc -l | tr -d ' ')
    [ "$mc" -gt 0 ] && printf '%s' "<tr><td>Offline maps - $mc files</td><td class='muted'>OsmAnd</td><td>$(du -ch "$ROOT"/OsmAnd/*.obf.zip 2>/dev/null | tail -1 | cut -f1)</td></tr>"
    printf '%s' "</table>"
  fi
  printf '%s' "</div></body></html>"
} > "$IDX"
log "README.html index written."

# the PC map viewer unpacks the maps the first time it is opened: say why that much of the drive is still empty
if [ -f "$ROOT/OsmAnd/MapViewer-Desktop/VIEW-MAPS-ON-PC.sh" ] && ! ls "$ROOT"/OsmAnd/obf/*.obf >/dev/null 2>&1; then
  zk="$(du -ck "$ROOT"/OsmAnd/*.obf.zip 2>/dev/null | tail -n1 | awk '{print $1}')"
  [ "${zk:-0}" -gt 0 ] && log "NOTE: about $(awk -v k="$zk" 'BEGIN{g=k*1.8/1048576; printf (g<10 ? "%.1f" : "%.0f"), g}') GB of the drive is left EMPTY on purpose. The PC map viewer (OsmAnd/MapViewer-Desktop/VIEW-MAPS-ON-PC) unpacks the maps into it the first time you open it. Phones don't need it."
fi
NFAIL="$(sort -u "$FAILS" 2>/dev/null | grep -c .)"
if [ "${NFAIL:-0}" -gt 0 ]; then
  log "=== DONE, but $NFAIL item(s) could not be downloaded this time (listed in _failed.txt) - run the installer again later to try them again ==="
else log "=== DONE. Open README.html (full index) or START-HERE.html ==="; fi
echo ""
echo "  Finished. Your offline library is in: $ROOT"
[ "${NFAIL:-0}" -gt 0 ] && echo "  $NFAIL item(s) could not be downloaded this time - they are listed in _failed.txt." \
  && echo "  Everything else is ready. Run the installer again later; it only fetches what's missing."
echo "  Open README.html for a full index, or START-HERE.html to begin."
[ -n "$LOCAL_GUIDE" ] && echo "  Local info: $LOCAL_DIR/$LOCAL_GUIDE.html"
