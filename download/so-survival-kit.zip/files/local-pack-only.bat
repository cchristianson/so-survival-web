@echo off
title SO Survival Library - Illinois Valley local pack only
cd /d "%~dp0"
echo ================================================================
echo   ILLINOIS VALLEY LOCAL PACK ONLY
echo.
echo   Downloads just the local pack (topo maps, hunting and fishing
echo   regulations, gardening, wildfire, earthquake, radio/weather
echo   guides) plus the how-to guides. A few GB - minutes, not hours.
echo.
echo   Use it to:
echo    - try things out before the big download, or
echo    - refresh the local pack later (e.g. new regulations).
echo.
echo   When asked where to save, give the SAME place you use for the
echo   full library (e.g. E:\) so everything stays in one folder.
echo ================================================================
echo.
if not exist "%~dp0Get-OfflineLibrary.ps1" (
  echo ERROR: Get-OfflineLibrary.ps1 was not found next to this file.
  echo Unzip the whole folder first, then run this file from inside it.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Get-OfflineLibrary.ps1" -LocalOnly
echo.
echo Done. Open Southern-Oregon\ILLINOIS-VALLEY-START-HERE.html in the folder you chose.
pause
