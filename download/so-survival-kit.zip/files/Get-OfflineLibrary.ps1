<#
  Get-OfflineLibrary.ps1
  One-shot downloader for the Offline Emergency Library.
  Downloads: offline AI (3 models + CPU/GPU engines), GPT4All doc-Q&A, full Wikipedia
  (readable Kiwix ZIM, with pictures by default), offline US maps (OsmAnd), survival/repair/
  medical archives (Kiwix ZIM), public-domain Army field manuals + medical PDFs, the Kiwix
  reader, launchers, all documentation (Markdown + HTML), and the LOCAL PACK for the
  Illinois Valley / southern Oregon (list in local\illinois-valley-files.txt).

  Usage:
    .\Get-OfflineLibrary.ps1                      # will ask where to save
    .\Get-OfflineLibrary.ps1 -Destination E:\     # non-interactive
    .\Get-OfflineLibrary.ps1 -Destination E:\ -LocalOnly   # just the local pack (+ docs)
    .\Get-OfflineLibrary.ps1 -Destination E:\ -Community   # local pack + guides + Library Assistant
                                                          # with a small AI for every device (~10 GB)
    .\Get-OfflineLibrary.ps1 -Destination E:\ -DriveSize 116   # fill 116 GB with the most useful parts
    .\Get-OfflineLibrary.ps1 -Destination E:\ -Choose          # pick the parts yourself, sizes shown
    .\Get-OfflineLibrary.ps1 -DriveSize 64 -PlanOnly            # just show what would fit in 64 GB
  Everything is RESUMABLE: re-run to continue after an interruption.
#>
[CmdletBinding()]
param(
  [string]$Destination,
  [string]$Region = 'US',   # which country/region maps to download (default US). Examples:
                            #   -Region France   -Region "Germany,Austria"   -Region Europe
                            #   -Region US_texas   -Region world   (see -ListRegions)
  [switch]$ListRegions,     # print available map regions (optionally filtered by -Filter) and exit
  [string]$Filter,          # substring filter used with -ListRegions
  [ValidateSet('maxi','nopic','mini')]
  [string]$WikipediaSize = 'maxi', # maxi = full with pictures (~120 GB), nopic = full text (~50 GB),
                                   # mini = article intros only (~13 GB)
  [switch]$SkipWikipedia,   # Wikipedia is the biggest piece; allow skipping
  [switch]$SkipMaps,        # OsmAnd maps (~17 GB for US); allow skipping
  [switch]$SkipModels,      # the large AI chat models (~11 GB)
  [switch]$SkipLocal,       # skip the Illinois Valley / southern Oregon local pack
  [switch]$LocalOnly,       # ONLY the local pack + docs (quick test, or yearly refresh)
  [switch]$Community,       # the shareable kit: local pack + guides + the Library Assistant with a
                            # small AI for every kind of device (Windows, Mac, Linux, Android) ~10 GB
  [switch]$SkipOtherDevices, # only the Windows programs (skip the Mac/Linux/Android ones, ~300 MB)
  [double]$DriveSize = 0,   # GB to fill (e.g. 116 for a 128 GB stick); default: the drive's free space
  [switch]$Choose,          # show the "what goes on this drive" list even with -Destination
  [switch]$PlanOnly,        # show what would fit, download nothing
  [switch]$PlanJson,        # (for the point-and-click installer) print the sizes and suggested plan as JSON
  [string]$Parts            # (for the point-and-click installer) the parts to get, e.g. "local,ai,devices,medical"
)
if($Community){ $LocalOnly = $true }   # the community kit is the local pack plus the AI pieces below

$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'
# Windows PowerShell 5.1 often offers websites only the old TLS 1.0, which GitHub and F-Droid refuse
# ("Could not create SSL/TLS secure channel" - no AI engine, no phone apps). Allow TLS 1.2 as well.
try { $tls = [int][Net.ServicePointManager]::SecurityProtocol
      if($tls -ne 0 -and ($tls -band 3072) -eq 0){ [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]($tls -bor 3072) } } catch {}
$RepoRaw = 'https://raw.githubusercontent.com/elhajahmadj/offline-emergency-library/main'
$Continents = @('africa','asia','australia-oceania','centralamerica','europe','northamerica','southamerica')
$ScriptDir = if($PSScriptRoot){$PSScriptRoot}else{(Get-Location).Path}
$LocalList = Join-Path $ScriptDir 'local\illinois-valley-files.txt'

# ---------------------------------------------------------------- -ListRegions (discovery, no download)
if($ListRegions){
  $tmp = Join-Path $env:TEMP 'osmand_idx.xml'
  curl.exe -s 'https://download.osmand.net/get_indexes' -o $tmp
  try { [xml]$ix = Get-Content $tmp } catch { Write-Host "Could not fetch the OsmAnd region index."; return }
  $maps = $ix.osmand_regions.region | Where-Object { $_.type -eq 'map' }
  if($Filter){
    Write-Host "Regions / sub-regions matching '$Filter' (pass any of these to -Region):"
    $rx = '_(' + ($Continents -join '|') + ')_\d+\.obf\.zip$'
    $maps | Where-Object { $_.name -match [regex]::Escape($Filter) } | ForEach-Object { $_.name -replace $rx,'' } | Sort-Object -Unique | ForEach-Object { Write-Host "  $_" }
  } else {
    Write-Host "Available top-level regions (pass one to -Region, e.g. -Region France):"
    $maps | ForEach-Object { ($_.name -split '_')[0] } | Group-Object | Sort-Object Name | ForEach-Object { Write-Host ("  {0,-26} {1} file(s)" -f $_.Name, $_.Count) }
    Write-Host ""
    Write-Host "Continents: $($Continents -join ', '), or 'world' for everything."
    Write-Host "To see a country's sub-regions:  -ListRegions -Filter US"
  }
  return
}

# ---------------------------------------------------------------- destination
$AskedDestination = $false
if (-not $Destination -and -not (($PlanOnly -or $PlanJson) -and $DriveSize -gt 0)) {
  Write-Host ''
  Write-Host '  Offline Emergency Library installer' -ForegroundColor Cyan
  Write-Host '  -----------------------------------'
  $Destination = Read-Host 'Where would you like to save these files? (for example E:\)'
  $AskedDestination = $true
}

# ---------------------------------------------------------------- fit-to-drive planner
# Works out how big each part of the library is right now, picks the most useful set that fits
# the space you have (all the free space on the drive, or -DriveSize), and lets you switch parts
# on and off before anything downloads. Shown automatically when you run the installer by
# double-click; use -Choose to see it with -Destination, -DriveSize 116 to fill 116 GB, and
# -PlanOnly to just see what would fit.
$Models = @(
 @{n='Qwen2.5-1.5B-Instruct-Q4_K_M.gguf';      u='https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf'; big=$false; gb=0.92}
 @{n='Llama-3.2-3B-Instruct-Q4_K_M.gguf';      u='https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf'; big=$false; gb=1.88}
 @{n='Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf'; u='https://huggingface.co/bartowski/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf'; big=$true; gb=4.58}
 @{n='Qwen2.5-7B-Instruct-Q4_K_M.gguf';        u='https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF/resolve/main/Qwen2.5-7B-Instruct-Q4_K_M.gguf'; big=$true; gb=4.36}
)
# what to fetch in the big library (the planner, -LocalOnly and -Community change these)
$Get = @{ ai=$true; medical=$true; repair=$true; reader=$true; viewer=$true; gpt4all=$true }
if($LocalOnly){
  $Get = @{ ai=[bool]$Community; medical=$false; repair=$false; reader=$false; viewer=$false; gpt4all=$false }
  $SkipWikipedia = $true; $SkipMaps = $true; $SkipModels = $true
}
$UsePlanner = ($DriveSize -gt 0) -or $Choose -or $PlanOnly -or $PlanJson -or ($AskedDestination -and -not $LocalOnly)
if($Parts){   # chosen in the point-and-click installer: exactly these parts, no questions
  $pp = @($Parts.ToLower() -split '[,; ]' | Where-Object { $_ })
  $SkipLocal = -not ($pp -contains 'local'); $SkipModels = -not ($pp -contains 'bigai'); $SkipOtherDevices = -not ($pp -contains 'devices')
  $LocalOnly = $false; $UsePlanner = $false
  $Get = @{ ai=(($pp -contains 'ai') -or ($pp -contains 'bigai')); medical=($pp -contains 'medical'); repair=($pp -contains 'repair')
            reader=($pp -contains 'reader'); viewer=(($pp -contains 'viewer') -and -not $SkipMaps); gpt4all=($pp -contains 'gpt4all') }
}

function Get-RemoteGB($url,$fallback){
  try{
    $h = @(curl.exe -sIL -A 'Mozilla/5.0' --max-time 25 $url 2>$null)
    $cl = $h | Where-Object { $_ -match '^content-length:\s*\d+' } | ForEach-Object { [double](($_ -replace '^content-length:\s*','').Trim()) } | Select-Object -Last 1
    if($cl -gt 100000){ return [math]::Round($cl/1GB,2) }
  }catch{}
  return $fallback
}
function Get-PlanSizes{
  Write-Host ''
  Write-Host '  Checking how big each part of the library is right now (about half a minute)...'
  $Z = @{ core=0.4; devices=0.7; reader=1.0; gpt4all=0.4; viewer=0.45 }
  $mb = 0.0
  if(Test-Path -LiteralPath $LocalList){
    foreach($line in (Get-Content -LiteralPath $LocalList)){
      if($line.Trim().StartsWith('#')){ continue }
      $f = $line -split '\|'; $v = 0.0
      if($f.Count -ge 4 -and [double]::TryParse($f[3].Trim(),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$v)){ $mb += $v }
    }
  }
  $Z.local = [math]::Round($mb/1024,2)
  $Z.ai = 0.5; $Z.bigai = 0.0
  foreach($m in $Models){ $g = Get-RemoteGB $m.u $m.gb; if($m.big){ $Z.bigai += $g } else { $Z.ai += $g } }
  $dirs = @{ w='https://download.kiwix.org/zim/wikipedia/'; o='https://download.kiwix.org/zim/other/'; f='https://download.kiwix.org/zim/ifixit/' }
  $pages = @{}; foreach($k in $dirs.Keys){ $pages[$k] = (curl.exe -sL -A 'Mozilla/5.0' --max-time 40 $dirs[$k]) -join "`n" }
  $zimGB = { param($k,$pre,$fb)
    $m = @([regex]::Matches($pages[$k],[regex]::Escape($pre)+'[0-9-]+\.zim') | ForEach-Object { $_.Value } | Sort-Object -Unique)
    if($m.Count){ Get-RemoteGB ($dirs[$k] + $m[-1]) $fb } else { $fb } }
  $Z.medical = (& $zimGB 'w' 'wikipedia_en_medicine_maxi_' 1.7) + (& $zimGB 'o' 'zimgit-medicine_en_' 0.07)
  $Z.repair  = (& $zimGB 'f' 'ifixit_en_all_' 3.3) + (& $zimGB 'o' 'appropedia_en_all_maxi_' 0.55) + (& $zimGB 'o' 'zimgit-post-disaster_en_' 0.6) +
               (& $zimGB 'o' 'zimgit-water_en_' 0.02) + (& $zimGB 'o' 'zimgit-food-preparation_en_' 0.09) + (& $zimGB 'o' 'zimgit-knots_en_' 0.03)
  $Z.wiki = @{ maxi=(& $zimGB 'w' 'wikipedia_en_all_maxi_' 119); nopic=(& $zimGB 'w' 'wikipedia_en_all_nopic_' 49); mini=(& $zimGB 'w' 'wikipedia_en_all_mini_' 13); none=0 }
  # maps: sizes straight from the OsmAnd download index (zipped, and unpacked for the PC viewer)
  $Z.areas = @()
  $opts = @()
  if($Region -and $Region -ne 'US'){ $opts += ,@($Region, "Maps: $Region") }
  $opts += ,@('US','Maps: the whole USA'); $opts += ,@('Us_oregon,Us_california','Maps: Oregon and California'); $opts += ,@('Us_oregon','Maps: Oregon only')
  $all = @()
  try{ [xml]$ix = (curl.exe -s --max-time 60 'https://download.osmand.net/get_indexes') -join "`n"; $all = @($ix.osmand_regions.region | Where-Object { $_.type -eq 'map' }) }catch{}
  foreach($o in $opts){
    $sel = @()
    foreach($t in (($o[0] -split '[,; ]') | Where-Object { $_ })){
      if($t -ieq 'world'){ $sel = $all; break }
      elseif($Continents -contains $t.ToLower()){ $sel += $all | Where-Object { $_.name -match ('_' + [regex]::Escape($t.ToLower()) + '_') } }
      else { $sel += $all | Where-Object { $_.name -match ('^' + [regex]::Escape($t) + '_') } }
    }
    $sel = @($sel | Sort-Object name -Unique)
    $zip = ($sel | ForEach-Object { [double]$_.size } | Measure-Object -Sum).Sum
    $unz = ($sel | ForEach-Object { [double]$_.targetsize } | Measure-Object -Sum).Sum
    if(-not $sel.Count){ $zip = if($o[0] -eq 'US'){17000}elseif($o[0] -like '*california*'){2100}else{360}; $unz = $zip*1.8 }
    $Z.areas += ,@{ r=$o[0]; l=$o[1]; zip=[math]::Round($zip/1024,2); unz=[math]::Round($unz/1024,2) }
  }
  return $Z
}
function Get-PlanTotal($S,$Z){
  $t = $Z.core
  if($S.local){ $t += $Z.local }
  if($S.ai -or $S.bigai){ $t += $Z.ai }
  if($S.devices){ $t += $Z.devices }
  if($S.bigai){ $t += $Z.bigai }
  if($S.medical){ $t += $Z.medical }
  if($S.reader){ $t += $Z.reader }
  if($S.repair){ $t += $Z.repair }
  if($S.map -ge 0){ $t += $Z.areas[$S.map].zip; if($S.viewer){ $t += $Z.viewer + $Z.areas[$S.map].unz } }
  $t += $Z.wiki[$S.wiki]
  if($S.gpt4all){ $t += $Z.gpt4all }
  return [math]::Round($t,1)
}
function Get-AutoPlan($Z,$budget){
  $iUS = 0; while($Z.areas[$iUS].r -ne 'US'){ $iUS++ }
  $S = @{ local=$true; ai=$true; devices=$true; medical=$true; reader=$true; repair=$true; map=0; viewer=$true; wiki='maxi'; bigai=$true; gpt4all=$true }
  # when it doesn't fit, give things up in this order (least needed first)
  $steps = @(
    { $S.gpt4all = $false }, { $S.viewer = $false }, { if($S.wiki -eq 'maxi'){ $S.wiki = 'nopic' } },
    { $S.bigai = $false }, { if($S.map -le $iUS){ $S.map = $iUS + 1 } }, { if($S.wiki -eq 'nopic'){ $S.wiki = 'mini' } },
    { $S.repair = $false }, { if($S.map -ge 0){ $S.map = $iUS + 2 } }, { $S.wiki = 'none' }, { $S.map = -1 },
    { $S.devices = $false }, { $S.reader = $false }, { $S.medical = $false }, { $S.ai = $false }, { $S.local = $false } )
  foreach($st in $steps){ if((Get-PlanTotal $S $Z) -le $budget){ break }; & $st }
  # then add back, most useful first, anything that still fits in the space left over
  $tries = @(
    { $S.local = $true }, { $S.ai = $true }, { $S.medical = $true }, { $S.reader = $true }, { $S.devices = $true },
    { if($S.map -lt 0){ $S.map = $iUS + 2 } }, { $S.repair = $true }, { if($S.wiki -eq 'none'){ $S.wiki = 'mini' } },
    { if($S.wiki -eq 'mini'){ $S.wiki = 'nopic' } }, { if($S.map -eq $iUS + 2){ $S.map = $iUS + 1 } }, { if($S.map -eq $iUS + 1){ $S.map = $iUS } },
    { $S.bigai = $true }, { if($S.wiki -eq 'nopic'){ $S.wiki = 'maxi' } }, { $S.viewer = $true }, { $S.gpt4all = $true } )
  foreach($tr in $tries){
    $keep = $S.Clone(); & $tr
    if((Get-PlanTotal $S $Z) -gt $budget){ foreach($k in $keep.Keys){ $S[$k] = $keep[$k] } }
  }
  return $S
}
function Show-Plan($S,$Z,$space,$budget){
  $wl = @{ maxi='Wikipedia: everything, with pictures'; nopic='Wikipedia: every article, text only'; mini='Wikipedia: article introductions only'; none='Wikipedia' }
  $mapLabel = if($S.map -ge 0){ $Z.areas[$S.map].l } else { 'Maps' }
  $mapGB = if($S.map -ge 0){ $Z.areas[$S.map].zip } else { $Z.areas[0].zip }
  $vwGB = $Z.viewer + $(if($S.map -ge 0){ $Z.areas[$S.map].unz } else { $Z.areas[0].unz })
  $wGB = if($S.wiki -ne 'none'){ $Z.wiki[$S.wiki] } else { $Z.wiki.nopic }
  $rows = @(
    @(1,  $S.local,   'Illinois Valley books, maps and guides (local pack)', $Z.local),
    @(2,  ($S.ai -or $S.bigai), 'Offline AI, small - runs on most computers',  $Z.ai),
    @(3,  $S.devices, 'Works on every device (Mac, Linux, Android programs)',  $Z.devices),
    @(4,  $S.medical, 'Medical encyclopedia (WikiMed) and medicine archive', $Z.medical),
    @(5,  $S.reader,  'Army manuals, Kiwix reader and phone apps',           $Z.reader),
    @(6,  $S.repair,  'Repair and survival archives (iFixit, Appropedia)',   $Z.repair),
    @(7,  ($S.map -ge 0), "$mapLabel   (M = change)",                        $mapGB),
    @(8,  ($S.viewer -and $S.map -ge 0), 'Map viewer for PCs (+ EMPTY room to unpack maps)', $vwGB),
    @(9,  ($S.wiki -ne 'none'), "$($wl[$S.wiki])   (W = change)",            $wGB),
    @(10, $S.bigai,   'Offline AI, large - smarter, needs 16 GB memory',     $Z.bigai),
    @(11, $S.gpt4all, 'GPT4All document reader (optional)',                  $Z.gpt4all))
  $total = Get-PlanTotal $S $Z
  Write-Host ''
  Write-Host '  WHAT GOES ON THIS DRIVE' -ForegroundColor Cyan
  Write-Host ("  Space to use: {0:N0} GB  (keeping {1:N0} GB free so the drive doesn't fill to the brim)" -f $space, ($space-$budget))
  Write-Host ''
  foreach($r in $rows){
    $mark = if($r[1]){'[x]'}else{'[ ]'}
    $line = "{0,4}  {1}  {2}" -f $r[0], $mark, $r[2]
    Write-Host ("{0,-74}{1,7:N1} GB" -f $line, $r[3]) -ForegroundColor $(if($r[1]){'White'}else{'DarkGray'})
  }
  Write-Host ("{0,-74}{1,7:N1} GB" -f '         Guides, tools and the Library Assistant (always)', $Z.core)
  Write-Host ('  ' + ('-' * 82))
  if($total -le $budget){ Write-Host ("  Total {0:N1} GB of {1:N0} GB - fits, with {2:N1} GB to spare" -f $total,$budget,($budget-$total)) -ForegroundColor Green }
  else { Write-Host ("  Total {0:N1} GB of {1:N0} GB - TOO BIG by {2:N1} GB: switch something off" -f $total,$budget,($total-$budget)) -ForegroundColor Yellow }
  if($S.viewer -and $S.map -ge 0){
    Write-Host ("  Note: {0:N1} GB of that is left EMPTY on purpose. The PC map viewer fills it the first time" -f $Z.areas[$S.map].unz) -ForegroundColor DarkGray
    Write-Host  "  you open it, to unpack the maps - until then the drive shows that much free space." -ForegroundColor DarkGray
  }
  return $total
}
function Set-Plan($S,$Z){
  $script:SkipLocal = -not $S.local
  $script:SkipModels = -not $S.bigai
  $script:SkipOtherDevices = -not $S.devices
  $script:SkipWikipedia = ($S.wiki -eq 'none')
  if($S.wiki -ne 'none'){ $script:WikipediaSize = $S.wiki }
  $script:SkipMaps = ($S.map -lt 0)
  if($S.map -ge 0){ $script:Region = $Z.areas[$S.map].r }
  $script:LocalOnly = $false
  $script:Get = @{ ai=($S.ai -or $S.bigai); medical=$S.medical; repair=$S.repair; reader=$S.reader; viewer=($S.viewer -and $S.map -ge 0); gpt4all=$S.gpt4all }
}
if($UsePlanner){
  # space: the -DriveSize you gave, or the free space on the drive plus anything already downloaded there
  $space = $DriveSize
  if($space -le 0){
    try{
      $full = [IO.Path]::GetFullPath($Destination)
      $space = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($full)).AvailableFreeSpace/1GB
      $have = Join-Path $full 'OfflineLibrary'
      if(Test-Path -LiteralPath $have){ $space += ((Get-ChildItem -LiteralPath $have -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum)/1GB }
    }catch{ $space = 0 }
  }
  if($space -le 0){ Write-Host 'Could not tell how much space the drive has - use -DriveSize, e.g. -DriveSize 116' -ForegroundColor Yellow; exit 1 }
  $budget = [int][math]::Floor([math]::Max(0.0, $space - [math]::Max(1.0, $space*0.02)))
  $Z = Get-PlanSizes
  $S = Get-AutoPlan $Z $budget
  if($PlanJson){
    $j = @{ space=[math]::Round($space,1); budget=$budget; z=$Z; auto=$S }
    Write-Output ('PLANJSON:' + ($j | ConvertTo-Json -Depth 5 -Compress))
    return
  }
  $ask = (-not $PlanOnly) -and ($AskedDestination -or $Choose)
  while($true){
    $total = Show-Plan $S $Z $space $budget
    if(-not $ask){ break }
    Write-Host ''
    Write-Host '  Type a number to switch that part on or off.   W = change Wikipedia   M = change the map area'
    Write-Host '  A = fill the drive automatically again   Enter = start downloading   Q = quit'
    $a = (Read-Host '  Your choice').Trim()
    if($a -eq ''){
      if($total -le $budget){ break }
      if((Read-Host '  That is more than the space you have. Start anyway? (y/N)') -match '^[yY]'){ break } else { continue }
    }
    $n = 0
    if($a -match '^[qQ]'){ Write-Host 'Nothing was downloaded.'; return }
    elseif($a -match '^[aA]'){ $S = Get-AutoPlan $Z $budget }
    elseif($a -match '^[wW]'){ $order = @('maxi','nopic','mini','none'); $S.wiki = $order[($order.IndexOf($S.wiki)+1) % 4] }
    elseif($a -match '^[mM]'){ $S.map = if($S.map + 1 -ge $Z.areas.Count){ -1 } else { $S.map + 1 } }
    elseif([int]::TryParse($a,[ref]$n)){
      switch($n){
        1 { $S.local = -not $S.local }
        2 { $S.ai = -not ($S.ai -or $S.bigai); if(-not $S.ai){ $S.bigai = $false } }
        3 { $S.devices = -not $S.devices }
        4 { $S.medical = -not $S.medical }
        5 { $S.reader = -not $S.reader }
        6 { $S.repair = -not $S.repair }
        7 { $S.map = if($S.map -ge 0){ -1 } else { 0 } }
        8 { $S.viewer = -not ($S.viewer -and $S.map -ge 0); if($S.viewer -and $S.map -lt 0){ $S.map = 0 } }
        9 { $S.wiki = if($S.wiki -ne 'none'){ 'none' } else { 'nopic' } }
        10 { $S.bigai = -not $S.bigai; if($S.bigai){ $S.ai = $true } }
        11 { $S.gpt4all = -not $S.gpt4all }
        default { Write-Host '  (no such number)' }
      }
    }
  }
  if($PlanOnly){ Write-Host ''; Write-Host '  (-PlanOnly: nothing was downloaded.)'; return }
  Set-Plan $S $Z
  $PlanSummary = "plan: {0:N1} GB of {1:N0} GB - local={2} ai={3} devices={4} medical={5} reader={6} repair={7} maps={8} viewer={9} wikipedia={10} bigai={11} gpt4all={12}" -f `
    $total,$budget,$S.local,($S.ai -or $S.bigai),$S.devices,$S.medical,$S.reader,$S.repair,$(if($S.map -ge 0){$Z.areas[$S.map].r}else{'none'}),$Get.viewer,$S.wiki,$S.bigai,$S.gpt4all
}

if (-not $Destination) { Write-Host 'No destination given. Exiting.' -ForegroundColor Red; exit 1 }
$Root = Join-Path $Destination 'OfflineLibrary'
try { New-Item -ItemType Directory -Force $Root -ErrorAction Stop | Out-Null
      # (-Force hides some errors, e.g. a write-protected SD card: check something can really be saved there)
      [IO.File]::AppendAllText((Join-Path (Resolve-Path -LiteralPath $Root -ErrorAction Stop).ProviderPath '_download.log'), '') }
catch { Write-Host "Cannot create $Root : $($_.Exception.Message)" -ForegroundColor Red; exit 1 }

$Log = Join-Path $Root '_download.log'
# Anything that couldn't be downloaded is also noted in _failed.txt (started fresh each run), so the
# end of the run - and the point-and-click page - can say exactly what's missing instead of "all done".
$FailFile = Join-Path $Root '_failed.txt'
try { [IO.File]::WriteAllText((Join-Path (Resolve-Path -LiteralPath $Root).ProviderPath '_failed.txt'), '') } catch {}
function Log($m){ $s = "{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m; Add-Content $Log $s; Write-Host $s
  if(($m -cmatch 'FAILED|ERROR|NOT FOUND|NO PDF') -or ($m -match 'not found \(|could not find|not reachable|no maps matched|doc missing|converter missing')){
    if($FailFile){ Add-Content -LiteralPath $FailFile $m -ErrorAction SilentlyContinue } } }
# --retry-all-errors needs curl 7.71 or newer: an older curl.exe (early Windows 10) stops with "option
# is unknown", which would make EVERY download fail - so use it only if this curl.exe knows it
$RetryAll = @(); try { curl.exe --retry-all-errors --version 2>$null | Out-Null; if($LASTEXITCODE -eq 0){ $RetryAll = @('--retry-all-errors') } } catch {}
function Fetch($url,$out){ curl.exe -f -L -C - --retry 10 --retry-delay 5 @RetryAll -s -o $out $url
  $rc = $LASTEXITCODE
  if($rc -ne 0){ Log "  FAILED: $(Split-Path $out -Leaf) (download error $rc) - will retry on the next run" }
  $global:LASTEXITCODE = $rc }
function UA(){ 'Mozilla/5.0' }

# free-space check (base library ~40 GB + Wikipedia + local pack ~3 GB + ~30 GB working room
# for unzipping maps on first use)
try {
  $drive = (Get-Item $Root).PSDrive
  $freeGB = [math]::Round((Get-PSDrive $drive.Name).Free/1GB,1)
  Log "Destination: $Root   (free space: $freeGB GB)"
  if($PlanSummary){ Log $PlanSummary }
  $wikiSizes = @{maxi=120; nopic=50; mini=13}
  $wikiGB = $wikiSizes[$WikipediaSize]
  if($SkipWikipedia){ $wikiGB = 0 }
  $needGB = if($Community){ 12 } elseif($LocalOnly){ 5 } else { 75 + $wikiGB }
  if (-not $UsePlanner -and -not $Parts -and $freeGB -lt $needGB) { Log "WARNING: about $needGB GB free space recommended. You have $freeGB GB free. Consider -WikipediaSize nopic / -SkipMaps / -SkipModels." }
} catch {}
# the drive's format decides which devices can open it: exFAT works on all of them
try {
  $rootPath = [IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $Root).Path)
  $fsName = ([IO.DriveInfo]::new($rootPath)).DriveFormat
  $isSystem = ($rootPath.TrimEnd('\') -ieq $env:SystemDrive)
  if($fsName){ Log "Drive format: $fsName" }
  if($fsName -match '^FAT'){
    Log "WARNING: this drive is formatted $fsName, which can't hold a file over 4 GB - Wikipedia and the large AI are skipped. For a drive that holds everything and works on every kind of device, format it as exFAT first (this erases it)."
    $SkipWikipedia = $true; $SkipModels = $true
  } elseif(-not $isSystem -and $fsName -and $fsName -ne 'exFAT'){
    $who = if($fsName -eq 'NTFS'){ "Windows and Linux can use it, but Macs can only read it and most Android tablets can't open it" } else { "not every kind of computer can open it" }
    Log "NOTE: this drive is formatted $fsName - $who. For a drive that works on every kind of device, format it as exFAT first (this erases it)."
  }
} catch {}

# ---------------------------------------------------------------- folder tree
$dirs = @(
 'AI-Offline','AI-Offline\engine','AI-Offline\models','AI-Offline\DocReader-GPT4All',
 'Manuals','Manuals\ArmyFieldManuals','Manuals\Repair-iFixit','Manuals\DIY-Appropedia',
 'Manuals\Survival-Water-Food','Manuals\Radio-Communications',
 'Medical','Medical\WikiMed','Medical\zimgit-medicine','Medical\Manuals-PDF',
 'Wikipedia','OsmAnd','Kiwix-Reader','Kiwix-Reader\app','Phone-Apps','Southern-Oregon'
)
foreach($d in $dirs){ New-Item -ItemType Directory -Force (Join-Path $Root $d) | Out-Null }

# ---------------------------------------------------------------- helpers
function Latest-Zim($dirUrl,$prefix){
  $html = curl.exe -sL -A (UA) $dirUrl
  $names = [regex]::Matches($html, [regex]::Escape($prefix)+'[^"<]*\.zim') | ForEach-Object {$_.Value} | Sort-Object -Unique
  if($names){ return ($names | Select-Object -Last 1) } else { return $null }
}
function Gh-ReleaseWith($repo,$needle){
  $rels = Invoke-RestMethod "https://api.github.com/repos/$repo/releases?per_page=20" -Headers @{'User-Agent'='ps'}
  foreach($r in $rels){ if($r.assets | Where-Object { $_.name -match $needle }){ return $r } }
  return $null
}
# Download for the local pack: saves to "<file>.part", checks it really is a PDF/ZIP (not an
# error page), then gives it its real name. Finished files are skipped on re-runs; a failed
# or interrupted .part file is resumed next time.
function Fetch-Checked($url,$out,$expMB){
  if(Test-Path -LiteralPath $out){ return 'have' }
  $part = "$out.part"; $why = ''
  # Try as a web browser first; a few government sites only answer plain curl, so try that second.
  foreach($ua in @((UA),'')){
    $uaArgs = if($ua){ @('-A',$ua) } else { @() }
    curl.exe -f -L -C - --retry 3 --retry-delay 5 @RetryAll -s @uaArgs -o $part $url
    if($LASTEXITCODE -eq 33){   # server can't resume: start this file over
      Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
      curl.exe -f -L --retry 3 --retry-delay 5 @RetryAll -s @uaArgs -o $part $url
    }
    if($LASTEXITCODE -ne 0){ $why = "curl error $LASTEXITCODE"; continue }
    $magic = ''
    try{
      $fs = [System.IO.File]::OpenRead($part); $buf = New-Object byte[] 4
      $n = $fs.Read($buf,0,4); $fs.Close()
      $magic = [System.Text.Encoding]::ASCII.GetString($buf,0,$n)
    }catch{}
    # a real file far smaller than the list says is usually an error page dressed up as a PDF
    $exp = 0.0; [void][double]::TryParse([string]$expMB, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$exp)
    $got = (Get-Item -LiteralPath $part).Length / 1MB
    if($magic -match '^(%PDF|PK)' -and -not ($exp -ge 0.5 -and $got -lt $exp * 0.25)){
      Move-Item -LiteralPath $part -Destination $out -Force
      return 'ok'
    }
    Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
    $why = 'the site sent an error page instead of the file - it may have moved'
  }
  return "FAILED ($why) - will retry on the next run"
}
function Read-LocalList(){
  if(-not (Test-Path -LiteralPath $LocalList)){ return @() }
  Get-Content -LiteralPath $LocalList -Encoding UTF8 | Where-Object { $_.Trim() -and -not $_.TrimStart().StartsWith('#') } | ForEach-Object {
    $f = $_ -split '\|'
    if($f.Count -ge 3){
      [pscustomobject]@{ Folder=$f[0].Trim(); Name=$f[1].Trim(); Url=$f[2].Trim()
                         SizeMB=$(if($f.Count -ge 4){$f[3].Trim()}else{''})
                         Desc=$(if($f.Count -ge 5){$f[4].Trim()}else{''}) }
    }
  }
}

# ================================================================ LOCAL PACK (Illinois Valley / southern Oregon)
# Small (a few GB) and goes first, so the local maps and guides are on the drive early.
if(-not $SkipLocal){
  Log '=== [Local] Illinois Valley / southern Oregon pack (maps, hunting, fishing, gardening, wildfire, quake, radio) ==='
  $items = @(Read-LocalList)
  if($items.Count -eq 0){ Log "local pack: list not found or empty ($LocalList)" }
  $ok = 0; $have = 0; $bad = 0
  foreach($it in $items){
    $dir = Join-Path $Root $it.Folder
    New-Item -ItemType Directory -Force $dir | Out-Null
    $r = Fetch-Checked $it.Url (Join-Path $dir $it.Name) $it.SizeMB
    if($r -eq 'ok'){ $ok++; Log "local: $($it.Name)" }
    elseif($r -eq 'have'){ $have++ }
    else { $bad++; Log "local: $($it.Name) - $r" }
  }
  if($items.Count -gt 0){ Log "local pack: $ok downloaded, $have already on the drive, $bad failed" }
} else { Log '=== [Local] pack SKIPPED ===' }

# ================================================================ programs for every kind of device
# One drive serves Windows, Mac, Linux (incl. Raspberry Pi) and Android, so the AI engine and the
# archive-search program are kept in one folder per platform (AI-Offline\engine\<platform>,
# Kiwix-Reader\tools\<platform>). The Library Assistant picks the right one when it starts.
# ($Models - the AI model list with sizes - is defined with the planner near the top)
function Expand-Any($arc,$dir){
  New-Item -ItemType Directory -Force $dir | Out-Null
  if($arc -match '\.zip$'){ try{ Expand-Archive $arc -DestinationPath $dir -Force }catch{ Log "  extract failed: $($_.Exception.Message)" }; return }
  tar.exe -xf $arc -C $dir 2>$null
  # Mac/Linux archives contain "symbolic links", which Windows and exFAT drives can't store:
  # put a copy of the real file in their place so the programs still find their libraries.
  $links = @(tar.exe -tvf $arc 2>$null | Where-Object { $_ -match '^l' })
  foreach($pass in 1..3){
    foreach($line in $links){
      if($line -match '\s(\S+) -> (\S+)$'){
        $link = Join-Path $dir ($Matches[1] -replace '/','\')
        $target = Join-Path (Split-Path $link) ($Matches[2] -replace '/','\')
        if(-not (Test-Path -LiteralPath $link) -and (Test-Path -LiteralPath $target -PathType Leaf)){ Copy-Item -LiteralPath $target -Destination $link -Force }
      }
    }
  }
}
function Get-Archive($name,$url,$dir,$label){
  $mark = Join-Path $dir 'downloaded.txt'
  if((Test-Path -LiteralPath $mark) -and ((Get-Content -LiteralPath $mark -Raw).Trim() -eq $name)){ Log "${label}: already on the drive"; return }
  New-Item -ItemType Directory -Force $dir | Out-Null
  $arc = Join-Path $dir $name
  Log "${label}: $name"; Fetch $url $arc
  if($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $arc)){   # (an interrupted download is resumed next time)
    Expand-Any $arc $dir
    Remove-Item -LiteralPath $arc -Force -ErrorAction SilentlyContinue
    Set-Content -LiteralPath $mark $name -Encoding ascii
  } else { Log "${label}: download failed - will retry on the next run" }
}
function Get-AIEngines{
  try{
    $rel = Gh-ReleaseWith 'ggml-org/llama.cpp' 'bin-win-cpu-x64'
    if(-not $rel){ Log 'engine: no suitable llama.cpp release found'; return }
    foreach($pat in @('bin-win-cpu-x64\.zip$','bin-win-cpu-arm64\.zip$','bin-win-vulkan-x64\.zip$')){
      $a = $rel.assets | Where-Object { $_.name -match $pat } | Select-Object -First 1
      if($a){
        $sub = if($a.name -match 'arm64'){'arm64'} elseif($a.name -match 'vulkan'){'vulkan-x64'} else {'x64'}
        Get-Archive $a.name $a.browser_download_url (Join-Path $Root "AI-Offline\engine\$sub") "engine ($sub)"
      }
    }
    if($SkipOtherDevices){ return }
    $eng = Join-Path $Root 'AI-Offline\engine'
    foreach($p in @(@('bin-macos-arm64\.(tar\.gz|zip)$','mac-arm64','engine for Macs with Apple chips'),
                    @('bin-macos-x64\.(tar\.gz|zip)$','mac-x64','engine for Intel Macs'),
                    @('bin-ubuntu-x64\.(tar\.gz|zip)$','linux-x64','engine for Linux PCs'),
                    @('bin-ubuntu-vulkan-x64\.(tar\.gz|zip)$','linux-vulkan-x64','engine for Linux PCs with a graphics card'),
                    @('bin-ubuntu-arm64\.(tar\.gz|zip)$','linux-arm64','engine for Linux ARM / Raspberry Pi'))){
      $a = $rel.assets | Where-Object { $_.name -match $p[0] } | Select-Object -First 1
      if($a){ Get-Archive $a.name $a.browser_download_url (Join-Path $eng $p[1]) $p[2] } else { Log "$($p[2]): not in this release" }
    }
  }catch{ Log "engine ERROR: $($_.Exception.Message)" }
}
function Get-ArchiveSearch{   # kiwix-serve: lets the Library Assistant search Wikipedia and the other .zim archives
  try{
    $tdir = 'https://download.kiwix.org/release/kiwix-tools/'
    $html = (curl.exe -sL -A (UA) $tdir) -join "`n"
    $newest = { param($rx) [regex]::Matches($html,$rx) | ForEach-Object {$_.Value} | Sort-Object -Unique | Select-Object -Last 1 }
    $tz = & $newest 'kiwix-tools_win-x86_64-[0-9][^"<]*\.zip'
    if($tz){
      $out = Join-Path $Root "Kiwix-Reader\$tz"
      Log "kiwix-serve: $tz"; Fetch ($tdir+$tz) $out
      try{ Expand-Archive $out -DestinationPath (Join-Path $Root 'Kiwix-Reader\tools') -Force }catch{ Log "  extract failed: $($_.Exception.Message)" }
    } else { Log 'kiwix-serve: no Windows kiwix-tools build found' }
    if($SkipOtherDevices){ return }
    foreach($p in @(@('linux-x86_64-musl','linux-x64'),@('linux-aarch64-musl','linux-arm64'),@('macos-arm64','mac-arm64'),@('macos-x86_64','mac-x64'))){
      $tz = & $newest ('kiwix-tools_' + $p[0] + '-[0-9][^"<]*\.tar\.gz')
      if($tz){ Get-Archive $tz ($tdir+$tz) (Join-Path $Root ("Kiwix-Reader\tools\"+$p[1])) ("kiwix-serve ("+$p[1]+")") }
    }
  }catch{ Log "kiwix-tools ERROR: $($_.Exception.Message)" }
}
function Get-AndroidKit($pa){   # Termux + the AI and Wikipedia helper packages, so a tablet can be set up with no internet
  if($SkipOtherDevices){ return }
  try{
    $tx = Join-Path $pa 'Android-Termux'; $txp = Join-Path $tx 'packages'
    New-Item -ItemType Directory -Force $txp | Out-Null
    $api = Invoke-RestMethod 'https://f-droid.org/api/v1/packages/com.termux' -Headers @{'User-Agent'='ps'}
    $vc = $api.suggestedVersionCode
    $apk = Join-Path $tx "Termux-$vc.apk"
    if(-not (Test-Path -LiteralPath $apk)){ Log "phone app: Termux (com.termux_$vc)"; Fetch "https://f-droid.org/repo/com.termux_$vc.apk" $apk }
    $repo = 'https://packages.termux.dev/apt/termux-main'
    $gz = Join-Path $env:TEMP 'termux-Packages.gz'
    curl.exe -s -L -o $gz "$repo/dists/stable/main/binary-aarch64/Packages.gz"
    $fs = [IO.File]::OpenRead($gz); $z = New-Object IO.Compression.GZipStream($fs,[IO.Compression.CompressionMode]::Decompress)
    $sr = New-Object IO.StreamReader($z); $txt = $sr.ReadToEnd(); $sr.Close()
    $lst = Join-Path $ScriptDir 'local\launchers\android-termux-packages.txt'
    $want = if(Test-Path -LiteralPath $lst){ @(Get-Content -LiteralPath $lst | Where-Object { $_ -and -not $_.StartsWith('#') } | ForEach-Object { $_.Trim() }) } else { @('llama-cpp','kiwix-tools') }
    $keep = @(); $got = @{}
    foreach($blk in ($txt -split "`n`n")){
      if($blk -match '(?m)^Package: (\S+)'){
        $name = $Matches[1]
        if(($want -contains $name) -and -not $got[$name] -and $blk -match '(?m)^Filename: (\S+)'){
          $got[$name] = $true
          $fn = $Matches[1]; $leaf = Split-Path $fn -Leaf; $keep += $leaf
          $out = Join-Path $txp $leaf
          if(-not (Test-Path -LiteralPath $out)){ Fetch "$repo/$fn" $out }
        }
      }
    }
    Get-ChildItem -LiteralPath $txp -Filter *.deb | Where-Object { $keep -notcontains $_.Name } | Remove-Item -Force   # older versions
    Log "android: Termux + $(@(Get-ChildItem -LiteralPath $txp -Filter *.deb).Count) of $($want.Count) helper packages (AI + Wikipedia search)"
  }catch{ Log "android kit ERROR: $($_.Exception.Message)" }
}

if($true){   # ---- the big library: each part below checks its own switch ($Get / -Skip...)

# ================================================================ 1. AI engine
if($Get.ai){
  Log '=== [1/8] Offline AI engine (llama.cpp) for every kind of device ==='
  Get-AIEngines
} else { Log '=== [1/8] AI engine SKIPPED ===' }

# ================================================================ 2. AI models
Log '=== [2/8] AI chat models (GGUF, Q4_K_M) ==='
foreach($m in $Models){
  if(($m.big -and $SkipModels) -or (-not $m.big -and -not $Get.ai)){ Log "model (skipped): $($m.n)"; continue }
  Log "model: $($m.n)"; Fetch $m.u (Join-Path $Root "AI-Offline\models\$($m.n)")
}

# ================================================================ 3. GPT4All
Log '=== [3/8] GPT4All (offline document Q&A) ==='
if($Get.gpt4all){ try{
  $rel = Gh-ReleaseWith 'nomic-ai/gpt4all' 'installer-win64-v'
  $a = $rel.assets | Where-Object { $_.name -match 'installer-win64-v.*\.exe$' -and $_.name -notmatch 'arm' } | Select-Object -First 1
  if($a){ Log "gpt4all: $($a.name)"; Fetch $a.browser_download_url (Join-Path $Root "AI-Offline\DocReader-GPT4All\$($a.name)") }
}catch{ Log "gpt4all ERROR: $($_.Exception.Message)" } } else { Log 'gpt4all: SKIPPED' }

# ================================================================ 4. Kiwix reader
Log '=== [4/8] Kiwix reader (portable) ==='
if($Get.reader){ try{
  $kdir = 'https://download.kiwix.org/release/kiwix-desktop/'
  $html = curl.exe -sL -A (UA) $kdir
  $zip = [regex]::Matches($html,'kiwix-desktop_windows_x64_[0-9][^"<]*\.zip') | ForEach-Object {$_.Value} | Sort-Object -Unique | Select-Object -Last 1
  if($zip){
    $out = Join-Path $Root "Kiwix-Reader\$zip"
    Log "kiwix: $zip"; Fetch ($kdir+$zip) $out
    try{ Expand-Archive $out -DestinationPath (Join-Path $Root 'Kiwix-Reader\app') -Force }catch{ Log "  extract failed: $($_.Exception.Message)" }
  }
}catch{ Log "kiwix ERROR: $($_.Exception.Message)" } } else { Log 'kiwix reader: SKIPPED' }
# kiwix-serve (command-line search server for the .zim archives - used by the Library Assistant)
if($Get.medical -or $Get.repair -or -not $SkipWikipedia){ Get-ArchiveSearch }

# ================================================================ 5. ZIM archives
# Kiwix publishes new editions of these archives every few months. Get the newest one; if an older
# edition is already here, update only when the drive has room for both, and delete the old one once
# the new one is complete. Unfinished older downloads are removed. A .zim is complete when its size is
# the checksum position written in its header (bytes 72-79) plus the 16-byte checksum.
function Test-ZimComplete($path){
  try{
    $fs = [IO.File]::Open($path, 'Open', 'Read', 'ReadWrite')
    try{ if($fs.Length -lt 80){ return $false }; $fs.Position = 72; $br = New-Object IO.BinaryReader($fs)
         return ($fs.Length -eq ([int64]$br.ReadUInt64() + 16)) } finally { $fs.Dispose() }
  }catch{ return $false }
}
function Get-RemoteBytes($url){
  $n = [int64]0
  foreach($l in @(curl.exe -sIL -A (UA) --max-time 30 $url 2>$null)){ if($l -match '^content-length:\s*(\d+)'){ $n = [int64]$Matches[1] } }
  return $n
}
function Get-FreeBytes($dir){ try{ return [int64]([IO.DriveInfo]::new([IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $dir).ProviderPath)).AvailableFreeSpace) }catch{ return [int64]0 } }
function Remove-Zims($dir,$rx,$keep){
  Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $rx -and $_.Name -ne $keep } | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue; Log "  removed $($_.Name) (making way for $keep)" }
}
function Get-Zim($srv,$pre,$dir,$label,$note,$replaces){   # $replaces: regex of other files the new one replaces
  New-Item -ItemType Directory -Force $dir | Out-Null
  $html  = (curl.exe -sL -A (UA) $srv) -join "`n"
  $avail = @([regex]::Matches($html, [regex]::Escape($pre) + '[0-9-]+\.zim') | ForEach-Object { $_.Value } | Sort-Object -Unique)
  if($avail.Count -eq 0){ Log "${label}: could not find $pre*.zim on $srv"; return }
  $newest = $avail[-1]
  $own  = '^' + [regex]::Escape($pre) + '[0-9-]+\.zim$'
  $have = @(Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $own } | Sort-Object Name)
  if(-not ($have | Where-Object { $_.Name -eq $newest })){
    $old = $null
    foreach($f in $have){
      if(Test-ZimComplete $f.FullName){ $old = $f }
      else { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue; Log "${label}: removed an unfinished older download ($($f.Name))" }
    }
    $need = Get-RemoteBytes ($srv + $newest); $free = Get-FreeBytes $dir
    if($old){
      if($need -gt 0 -and $free -gt ($need + 1GB)){ Log "${label}: updating $($old.Name) to the newer $newest (the old one is deleted once the new one is complete)" }
      elseif($need -gt 0){ Log ("{0}: keeping {1} - the newer {2} needs about {3} GB free beside it to update" -f $label, $old.Name, $newest, ([math]::Ceiling($need / 1GB) + 1)); return }
      else { Log "${label}: keeping $($old.Name) (couldn't check the size of the newer $newest - try again later)"; return }
    } elseif($replaces -and $need -gt 0 -and $free -lt ($need + 1GB)){
      Remove-Zims $dir $replaces $newest   # switching to another size of Wikipedia: make room first
    }
  }
  Log ("${label}: $newest" + $(if($note){ " $note" } else { '' }))
  $dest = Join-Path $dir $newest
  Fetch ($srv + $newest) $dest
  if($LASTEXITCODE -eq 0 -and (Test-ZimComplete $dest)){ Remove-Zims $dir $(if($replaces){ $replaces } else { $own }) $newest }
}

Log '=== [5/8] Offline archives (Kiwix ZIM: repair, DIY, medical, survival) ==='
$zims = @(
 @{dir='https://download.kiwix.org/zim/ifixit/'; pre='ifixit_en_all_';            d='Manuals\Repair-iFixit'; g='repair'}
 @{dir='https://download.kiwix.org/zim/other/';  pre='appropedia_en_all_maxi_';   d='Manuals\DIY-Appropedia'; g='repair'}
 @{dir='https://download.kiwix.org/zim/other/';  pre='zimgit-post-disaster_en_';  d='Manuals\Survival-Water-Food'; g='repair'}
 @{dir='https://download.kiwix.org/zim/other/';  pre='zimgit-water_en_';          d='Manuals\Survival-Water-Food'; g='repair'}
 @{dir='https://download.kiwix.org/zim/other/';  pre='zimgit-food-preparation_en_'; d='Manuals\Survival-Water-Food'; g='repair'}
 @{dir='https://download.kiwix.org/zim/other/';  pre='zimgit-knots_en_';          d='Manuals\Survival-Water-Food'; g='repair'}
 @{dir='https://download.kiwix.org/zim/wikipedia/'; pre='wikipedia_en_medicine_maxi_'; d='Medical\WikiMed'; g='medical'}
 @{dir='https://download.kiwix.org/zim/other/';  pre='zimgit-medicine_en_';       d='Medical\zimgit-medicine'; g='medical'}
)
foreach($z in $zims){
  if(-not $Get[$z.g]){ Log "zim (skipped): $($z.pre)"; continue }
  try{ Get-Zim $z.dir $z.pre (Join-Path $Root $z.d) 'zim' '' '' }catch{ Log "zim ERROR $($z.pre): $($_.Exception.Message)" }
}

# ================================================================ 6. PDFs (Internet Archive)
Log '=== [6/8] Public-domain manuals (PDF) ==='
$pdfs = @(
 @{id='fm-21-76-us-army-survival-manual';                    n='FM 21-76 Army Survival Manual.pdf';               d='Manuals\ArmyFieldManuals'}
 @{id='fm-3-05.70-survival-2002';                            n='FM 3-05.70 Survival (2002).pdf';                  d='Manuals\ArmyFieldManuals'}
 @{id='105-page-survival-field-manual';                      n='105-Page Survival Field Manual.pdf';              d='Manuals\ArmyFieldManuals'}
 @{id='UsArmyFirstAidManualFm4-25.11';                       n='FM 4-25.11 First Aid.pdf';                        d='Manuals\ArmyFieldManuals'}
 @{id='Survival-FirstAidForSoldiers-AFieldManual';           n='Survival and First Aid for Soldiers.pdf';         d='Manuals\ArmyFieldManuals'}
 @{id='use-and-care-of-hand-tools-and-measuring-tools-1983'; n='TM 9-243 Use and Care of Hand Tools.pdf';         d='Manuals\ArmyFieldManuals'}
 @{id='fm-5-426-carpentry-1995';                             n='FM 5-426 Carpentry.pdf';                          d='Manuals\ArmyFieldManuals'}
 @{id='tm-9-8000-principles-of-automotive-vehicles-1985';    n='TM 9-8000 Principles of Automotive Vehicles.pdf'; d='Manuals\ArmyFieldManuals'}
 @{id='u-s-army-guide-to-rigging';                           n='FM 5-125 Army Guide to Rigging.pdf';              d='Manuals\ArmyFieldManuals'}
 @{id='fm-90-3-desert-operations-1993';                      n='FM 90-3 Desert Operations.pdf';                   d='Manuals\ArmyFieldManuals'}
 @{id='tm-10-412-armed-forces-recipe-service-2003';          n='TM 10-412 Armed Forces Recipe Service.pdf';       d='Manuals\ArmyFieldManuals'}
 @{id='where-there-is-no-dentist-13th-printing-2010';        n='Where There Is No Dentist.pdf';                   d='Medical\Manuals-PDF'}
 # (Where There Is No Doctor and Ship's Medicine Chest were archive.org lending copies that refuse
 #  downloads; working copies now come from local\illinois-valley-files.txt)
)
foreach($p in $pdfs){
  if(-not $Get.reader){ Log 'pdf: SKIPPED (Army manuals not chosen)'; break }
  try{
    $meta = curl.exe -sL "https://archive.org/metadata/$($p.id)" -A (UA) | ConvertFrom-Json
    $f = $meta.files | Where-Object {$_.name -match '\.pdf$' -and $_.name -notmatch '_text\.pdf$'} | Sort-Object {[double]$_.size} -Descending | Select-Object -First 1
    if($f){ Log "pdf: $($p.n)"; Fetch "https://archive.org/download/$($p.id)/$([uri]::EscapeDataString($f.name))" (Join-Path $Root "$($p.d)\$($p.n)") }
    else { Log "pdf: NO PDF for $($p.id)" }
  }catch{ Log "pdf ERROR $($p.n): $($_.Exception.Message)" }
}

# ================================================================ 7. Wikipedia + Maps
if(-not $SkipWikipedia){
  # Readable offline Wikipedia = Kiwix's ready-made .zim file (opens in the bundled Kiwix
  # reader and the Kiwix phone app). The old raw "pages-articles.xml.bz2" dump could not be
  # opened by anything in this kit, so it is no longer downloaded.
  Log "=== [7/8] Wikipedia (Kiwix ZIM, '$WikipediaSize' edition - maxi ~120 GB with pictures) ==="
  try{
    # (a newer edition replaces the old one only when there's room for both; choosing another size
    #  replaces the old size once the new one is complete - or first, if there's no room for both)
    Get-Zim 'https://download.kiwix.org/zim/wikipedia/' "wikipedia_en_all_$($WikipediaSize)_" (Join-Path $Root 'Wikipedia') 'wikipedia' `
      '(this is the longest download - often overnight)' '^wikipedia_en_all_(maxi|nopic|mini)_[0-9-]+\.zim$'
  }catch{ Log "wikipedia ERROR: $($_.Exception.Message)" }
} else { Log '=== [7/8] Wikipedia SKIPPED ===' }

if(-not $SkipMaps){
  Log "=== [8/8] Offline maps (OsmAnd) - region: $Region ==="
  try{
    $idxFile = Join-Path $env:TEMP 'osmand_idx.xml'
    curl.exe -s 'https://download.osmand.net/get_indexes' -o $idxFile
    [xml]$idx = Get-Content $idxFile
    $allmaps = $idx.osmand_regions.region | Where-Object { $_.type -eq 'map' }
    # resolve the -Region tokens (comma/space separated) to a file set
    $tokens = ($Region -split '[,; ]') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
    $sel = @()
    foreach($t in $tokens){
      if($t -ieq 'world'){ $sel = $allmaps; break }
      elseif($Continents -contains $t.ToLower()){ $sel += $allmaps | Where-Object { $_.name -match ('_' + [regex]::Escape($t.ToLower()) + '_') } }
      else { $sel += $allmaps | Where-Object { $_.name -match ('^' + [regex]::Escape($t) + '_') } }
    }
    $sel = $sel | Sort-Object name -Unique
    if(-not $sel){
      Log "osmand: no maps matched region '$Region'. Run with -ListRegions to see valid names. Skipping maps."
    } else {
      $mb = ($sel | Measure-Object -Property size -Sum).Sum
      Log ("osmand: {0} map files for '{1}' (~{2:N1} GB download)" -f $sel.Count, $Region, ($mb/1024))
      if($mb -gt 40000){ Log ("WARNING: that's ~{0:N0} GB of maps - make sure you have room (and time)." -f ($mb/1024)) }
      foreach($r in $sel){
        $out = Join-Path $Root "OsmAnd\$($r.name)"
        Fetch "https://download.osmand.net/download.php?standard=yes&file=$($r.name)" $out
      }
    }
  }catch{ Log "osmand ERROR: $($_.Exception.Message)" }
} else { Log '=== [8/8] Maps SKIPPED ===' }

# ---------------- desktop map viewer (use the maps on a PC, no phone needed) -----------
if(-not $SkipMaps -and $Get.viewer){
  Log '=== [8b] Desktop map viewer (OsmAndMapCreator + portable Java) ==='
  $mvd = Join-Path $Root 'OsmAnd\MapViewer-Desktop'
  New-Item -ItemType Directory -Force $mvd,(Join-Path $mvd 'app') | Out-Null
  try{
    $mc = Join-Path $mvd 'OsmAndMapCreator.zip'
    Log 'mapviewer: OsmAndMapCreator'
    Fetch 'https://download.osmand.net/latest-night-build/OsmAndMapCreator-main.zip' $mc
    Expand-Archive $mc -DestinationPath (Join-Path $mvd 'app') -Force
    # if the zip nested everything in a single subfolder, pull it up to \app
    if(-not (Test-Path (Join-Path $mvd 'app\OsmAndMapCreator.bat'))){
      $inner = Get-ChildItem (Join-Path $mvd 'app') -Directory | Select-Object -First 1
      if($inner -and (Test-Path (Join-Path $inner.FullName 'OsmAndMapCreator.bat'))){
        Get-ChildItem $inner.FullName -Force | Move-Item -Destination (Join-Path $mvd 'app') -Force
      }
    }
    $jz = Join-Path $mvd 'jre.zip'
    Log 'mapviewer: portable Java runtime'
    Fetch 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse' $jz
    $tmp = Join-Path $mvd '_jre_tmp'
    if(Test-Path $tmp){ Remove-Item $tmp -Recurse -Force }
    Expand-Archive $jz -DestinationPath $tmp -Force
    $jreSrc = Get-ChildItem $tmp -Directory | Select-Object -First 1
    $jreDst = Join-Path $mvd 'jre'
    if(Test-Path $jreDst){ Remove-Item $jreDst -Recurse -Force }
    if($jreSrc){ Move-Item $jreSrc.FullName $jreDst }
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
  }catch{ Log "mapviewer ERROR: $($_.Exception.Message)" }

  # helper: unzip the downloaded .obf.zip map files into an \obf folder the viewer can read
  $prep = @'
$ErrorActionPreference='Continue'
$maps = Split-Path -Parent $PSScriptRoot      # ...\OsmAnd
$obf  = Join-Path $maps 'obf'
New-Item -ItemType Directory -Force $obf | Out-Null
$zips = Get-ChildItem (Join-Path $maps '*.obf.zip') -ErrorAction SilentlyContinue
$i=0
foreach($z in $zips){
  $i++
  $target = Join-Path $obf ($z.Name -replace '\.zip$','')
  if(-not (Test-Path $target)){
    Write-Host ("[{0}/{1}] unzipping {2}" -f $i,$zips.Count,$z.Name)
    try{ Expand-Archive $z.FullName -DestinationPath $obf -Force }catch{ Write-Host "  failed: $($_.Exception.Message)" }
  }
}
Write-Host "Maps ready in: $obf"
'@
  Set-Content -Path (Join-Path $mvd 'prepare-maps.ps1') -Value $prep -Encoding utf8

  $mvbat = @"
@echo off
title Offline Maps on PC - OsmAndMapCreator
cd /d "%~dp0"
set "JAVA_HOME=%~dp0jre"
set "PATH=%~dp0jre\bin;%PATH%"
echo Preparing map files for desktop viewing (first run can take several minutes)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0prepare-maps.ps1"
echo.
echo Launching the desktop map viewer...
echo In the app, your maps are the .obf files in the  OsmAnd\obf  folder.
cd /d "%~dp0app"
call OsmAndMapCreator.bat
pause
"@
  Set-Content -Path (Join-Path $mvd 'VIEW-MAPS-ON-PC.bat') -Value $mvbat -Encoding ascii
}

# ================================================================ phone apps
Log '=== Phone apps (port the library to a phone) ==='
$pa = Join-Path $Root 'Phone-Apps'
New-Item -ItemType Directory -Force $pa | Out-Null
# Kiwix for Android - reads ALL the .zim archives (Wikipedia, medical, repair, survival)
if($Get.reader){ try{
  $kr = Invoke-RestMethod 'https://api.github.com/repos/kiwix/kiwix-android/releases/latest' -Headers @{'User-Agent'='ps'}
  $ka = $kr.assets | Where-Object { $_.name -match 'universal-standalone\.apk$' } | Select-Object -First 1
  if(-not $ka){ $ka = $kr.assets | Where-Object { $_.name -match '\.apk$' } | Select-Object -First 1 }
  if($ka){ Log "phone app: Kiwix ($($ka.name))"; Fetch $ka.browser_download_url (Join-Path $pa $ka.name) }
}catch{ Log "kiwix apk ERROR: $($_.Exception.Message)" } }
# OsmAnd for Android - offline maps (only if maps were downloaded)
if(-not $SkipMaps){
  try{
    $api = Invoke-RestMethod 'https://f-droid.org/api/v1/packages/net.osmand.plus' -Headers @{'User-Agent'='ps'}
    $vc = $api.suggestedVersionCode
    Log "phone app: OsmAnd~ (net.osmand.plus_$vc)"
    Fetch "https://f-droid.org/repo/net.osmand.plus_$vc.apk" (Join-Path $pa "OsmAnd-$vc.apk")
  }catch{ Log "osmand apk ERROR: $($_.Exception.Message)" }
}
# Termux and its packages let an Android tablet run the Library Assistant and Wikipedia search (and the AI)
if($Get.ai -or (($Parts -or $UsePlanner) -and -not $SkipOtherDevices)){ Get-AndroidKit $pa }

# ================================================================ launchers
if($Get.ai){
Log '=== Writing launchers (.bat) ==='
function WriteBat($path,$text){ Set-Content -Path $path -Value $text -Encoding ascii }
$ao = Join-Path $Root 'AI-Offline'
WriteBat (Join-Path $ao 'CHAT-3B-light.bat') @"
@echo off
title Offline AI - Llama 3.2 3B (light)
cd /d "%~dp0"
"%~dp0engine\x64\llama-cli.exe" -m "%~dp0models\Llama-3.2-3B-Instruct-Q4_K_M.gguf" -c 4096 -cnv
pause
"@
WriteBat (Join-Path $ao 'CHAT-8B-smart.bat') @"
@echo off
title Offline AI - Llama 3.1 8B (smart)
cd /d "%~dp0"
"%~dp0engine\x64\llama-cli.exe" -m "%~dp0models\Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf" -c 4096 -cnv
pause
"@
WriteBat (Join-Path $ao 'CHAT-GPU-Qwen7B.bat') @"
@echo off
title Offline AI - Qwen2.5 7B (GPU)
cd /d "%~dp0"
echo If this errors with out-of-memory, your GPU is too small - change -ngl 99 to a lower
echo number (e.g. -ngl 20) or use a CPU launcher instead.
"%~dp0engine\vulkan-x64\llama-cli.exe" -m "%~dp0models\Qwen2.5-7B-Instruct-Q4_K_M.gguf" -c 4096 -ngl 99 -cnv
pause
"@
WriteBat (Join-Path $ao 'WEB-UI.bat') @"
@echo off
title Offline AI - Web UI
cd /d "%~dp0"
echo When it says "server listening", open a browser to http://127.0.0.1:8080
"%~dp0engine\x64\llama-server.exe" -m "%~dp0models\Llama-3.2-3B-Instruct-Q4_K_M.gguf" -c 4096 --host 127.0.0.1 --port 8080
pause
"@

}   # ---- end of: if($Get.ai) launchers
}   # ---- end of the big library (the community kit is now just a preset of these switches)

# ================================================================ documentation
Log '=== Documentation (Markdown + HTML) ==='
# doc source: local .\docs if present (repo folder), else download pre-rendered files from GitHub raw
$localDocs = Join-Path $ScriptDir 'docs'
# both .md and .html ship in the repo /docs; copy them byte-for-byte. (Reading them with
# Get-Content on Windows PowerShell 5.1 decodes UTF-8 as ANSI and garbles dashes/emoji.)
function PlaceDoc($srcName,$destPath,$title){
  $base = $srcName -replace '\.md$',''
  foreach($ext in '.md','.html'){
    $lp = Join-Path $localDocs ($base + $ext)
    if(Test-Path -LiteralPath $lp){ Copy-Item -LiteralPath $lp -Destination "$destPath$ext" -Force }
    else {
      curl.exe -sfL -A (UA) -o "$destPath$ext" "$RepoRaw/docs/$base$ext"
      if($LASTEXITCODE -ne 0){ Log "  doc missing: $base$ext" }
    }
  }
}
PlaceDoc 'START-HERE.md'            (Join-Path $Root 'START-HERE')                                  'Offline Emergency Kit - Start Here'
PlaceDoc 'START-ON-ANY-DEVICE.md'   (Join-Path $Root 'START-ON-ANY-DEVICE')                         'Start the Library on Any Device'
PlaceDoc 'AMMO-CAN-COMPUTER-GUIDE.md' (Join-Path $Root 'AMMO-CAN-COMPUTER-GUIDE')                 'Ammo-Can Library Computer'
PlaceDoc 'GET-THE-LIBRARY.md'      (Join-Path $Root 'GET-THE-LIBRARY')                            'Get the Whole Library on a USB Drive'
PlaceDoc 'EMERGENCY-FINDER.md'     (Join-Path $Root 'EMERGENCY-FINDER')                           'Emergency Finder'
PlaceDoc 'SUBJECT-INDEX.md'        (Join-Path $Root 'SUBJECT-INDEX')                              'Subject Index A-Z'
PlaceDoc 'HOW-TO-RUN-OFFLINE-AI.md' (Join-Path $Root 'AI-Offline\HOW-TO-RUN-OFFLINE-AI')            'Offline AI - How To Run'
PlaceDoc 'HOW-TO-ASK-YOUR-DOCS.md'  (Join-Path $Root 'AI-Offline\DocReader-GPT4All\HOW-TO-ASK-YOUR-DOCS') 'Ask Your Documents - GPT4All'
PlaceDoc 'HOW-TO-USE-KIWIX.md'      (Join-Path $Root 'Kiwix-Reader\HOW-TO-USE-KIWIX')               'How to Use Kiwix'
PlaceDoc 'Manuals-READ-ME-FIRST.md' (Join-Path $Root 'Manuals\READ-ME-FIRST')                       'Manuals - Read Me First'
PlaceDoc 'Medical-READ-ME-FIRST.md' (Join-Path $Root 'Medical\READ-ME-FIRST')                       'Medical - Read Me First'
PlaceDoc 'RADIO-GUIDE.md'           (Join-Path $Root 'Manuals\Radio-Communications\RADIO-GUIDE')     'Emergency Radio Communications Guide'
PlaceDoc 'HOW-TO-VIEW-MAPS.md'      (Join-Path $Root 'OsmAnd\HOW-TO-VIEW-MAPS')                      'Offline Maps - How to View'
PlaceDoc 'USE-ON-PHONE.md'          (Join-Path $Root 'Phone-Apps\USE-ON-PHONE')                      'Use the Library on a Phone'
PlaceDoc 'ILLINOIS-VALLEY-START-HERE.md' (Join-Path $Root 'Southern-Oregon\ILLINOIS-VALLEY-START-HERE') 'Illinois Valley - Start Here'
PlaceDoc 'MAKE-DO-HOUSEHOLD-GUIDE.md' (Join-Path $Root 'Southern-Oregon\MAKE-DO-HOUSEHOLD-GUIDE') 'Make-Do Household Guide'
PlaceDoc 'FOOD-FROM-SCRATCH-GUIDE.md' (Join-Path $Root 'Southern-Oregon\FOOD-FROM-SCRATCH-GUIDE') 'Food From Scratch'
PlaceDoc 'ENGINES-AND-MOTORS-GUIDE.md' (Join-Path $Root 'Southern-Oregon\ENGINES-AND-MOTORS-GUIDE') 'Engines Motors and Generators'
PlaceDoc 'NUCLEAR-FALLOUT-GUIDE.md' (Join-Path $Root 'Southern-Oregon\NUCLEAR-FALLOUT-GUIDE') 'Nuclear Fallout Guide'
PlaceDoc 'MUSHROOM-GUIDE.md' (Join-Path $Root 'Southern-Oregon\MUSHROOM-GUIDE') 'Mushroom Guide'
PlaceDoc 'BLACKSMITHING-GUIDE.md' (Join-Path $Root 'Southern-Oregon\BLACKSMITHING-GUIDE') 'Blacksmithing and Hand Tools'
PlaceDoc 'FUEL-GUIDE.md' (Join-Path $Root 'Southern-Oregon\FUEL-GUIDE') 'Fuel Guide'
PlaceDoc 'HORSE-GUIDE.md' (Join-Path $Root 'Southern-Oregon\HORSE-GUIDE') 'Horses Mules and Draft Animals'
PlaceDoc 'ROOT-CELLAR-GUIDE.md' (Join-Path $Root 'Southern-Oregon\ROOT-CELLAR-GUIDE') 'Root Cellars and Food Storage'
PlaceDoc 'SEED-BANK-GUIDE.md' (Join-Path $Root 'Southern-Oregon\SEED-BANK-GUIDE') 'Your Seed Bank'
PlaceDoc 'EMP-GUIDE.md' (Join-Path $Root 'Southern-Oregon\EMP-GUIDE') 'EMP Solar Storms and Faraday Cages'
PlaceDoc 'WATER-WELLS-GUIDE.md' (Join-Path $Root 'Southern-Oregon\WATER-WELLS-GUIDE') 'Water Wells Pumps Springs and Cisterns'
PlaceDoc 'WATER-PURIFICATION-GUIDE.md' (Join-Path $Root 'Southern-Oregon\WATER-PURIFICATION-GUIDE') 'Water Purification'
PlaceDoc 'FIREWOOD-GUIDE.md' (Join-Path $Root 'Southern-Oregon\FIREWOOD-GUIDE') 'Firewood'
PlaceDoc 'SIGNALS-MORSE-GUIDE.md' (Join-Path $Root 'Southern-Oregon\SIGNALS-MORSE-GUIDE') 'Signals, Morse Code and Messages'
PlaceDoc 'NAVIGATION-WEATHER-GUIDE.md' (Join-Path $Root 'Southern-Oregon\NAVIGATION-WEATHER-GUIDE') 'Navigation and Weather'
PlaceDoc 'FOOD-SECURITY-GUIDE.md' (Join-Path $Root 'Southern-Oregon\FOOD-SECURITY-GUIDE') 'Food When It Is Scarce'
PlaceDoc 'FIELD-CARE-GUIDE.md' (Join-Path $Root 'Southern-Oregon\FIELD-CARE-GUIDE') 'Injuries and Illness - No Help Coming'
PlaceDoc 'COMMUNITY-BARTER-GUIDE.md' (Join-Path $Root 'Southern-Oregon\COMMUNITY-BARTER-GUIDE') 'Community, Barter and Keeping Watch'
PlaceDoc 'BICYCLES-CARTS-GUIDE.md' (Join-Path $Root 'Southern-Oregon\BICYCLES-CARTS-GUIDE') 'Bicycles, Carts and Hauling'
PlaceDoc 'SHELTER-BUILDING-GUIDE.md' (Join-Path $Root 'Southern-Oregon\SHELTER-BUILDING-GUIDE') 'Shelter, Building and Repair'
PlaceDoc 'RABBITS-CHICKENS-GUIDE.md' (Join-Path $Root 'Southern-Oregon\RABBITS-CHICKENS-GUIDE') 'Rabbits and Chickens'
PlaceDoc 'NATURAL-BUILDING-GUIDE.md' (Join-Path $Root 'Southern-Oregon\NATURAL-BUILDING-GUIDE') 'Natural Building - Cob, Straw, Clay, Hemp and Lime'
PlaceDoc 'MASONRY-ROADS-GUIDE.md' (Join-Path $Root 'Southern-Oregon\MASONRY-ROADS-GUIDE') 'Mortar, Concrete and Roads'
PlaceDoc 'SANITATION-GUIDE.md' (Join-Path $Root 'Southern-Oregon\SANITATION-GUIDE') 'Sanitation, Hygiene and Stopping Disease'
PlaceDoc 'OFF-GRID-POWER-GUIDE.md' (Join-Path $Root 'Southern-Oregon\OFF-GRID-POWER-GUIDE') 'Off-Grid Power - Solar, Batteries and Creek Hydro'
PlaceDoc 'STORING-ENERGY-GUIDE.md' (Join-Path $Root 'Southern-Oregon\STORING-ENERGY-GUIDE') 'Storing Energy Without Batteries'
PlaceDoc 'LIGHTING-GUIDE.md' (Join-Path $Root 'Southern-Oregon\LIGHTING-GUIDE') 'Light Without the Grid - Candles, Lamps and Lamp Oil'
PlaceDoc 'PRESERVING-FOOD-GUIDE.md' (Join-Path $Root 'Southern-Oregon\PRESERVING-FOOD-GUIDE') 'Preserving Food Without a Freezer'
PlaceDoc 'HUNTING-TRAPPING-FISHING-GUIDE.md' (Join-Path $Root 'Southern-Oregon\HUNTING-TRAPPING-FISHING-GUIDE') 'Hunting, Trapping and Fishing for Food'
PlaceDoc 'GOATS-DAIRY-BEES-GUIDE.md' (Join-Path $Root 'Southern-Oregon\GOATS-DAIRY-BEES-GUIDE') 'Milk Goats, Home Dairy and Bees'
PlaceDoc 'CHILDBIRTH-CHILDREN-GUIDE.md' (Join-Path $Root 'Southern-Oregon\CHILDBIRTH-CHILDREN-GUIDE') 'Childbirth, Newborns and Young Children'
PlaceDoc 'CLOTHING-LEATHER-GUIDE.md' (Join-Path $Root 'Southern-Oregon\CLOTHING-LEATHER-GUIDE') 'Clothing, Textiles, Leather and Shoes'
PlaceDoc 'PAPER-INK-GUIDE.md' (Join-Path $Root 'Southern-Oregon\PAPER-INK-GUIDE') 'Paper, Ink and Toilet Paper'
PlaceDoc 'WILDFIRE-GUIDE.md' (Join-Path $Root 'Southern-Oregon\WILDFIRE-GUIDE') 'Wildfire - Defending Your Place With No Grid'
PlaceDoc 'NATIVE-SKILLS-GUIDE.md' (Join-Path $Root 'Southern-Oregon\NATIVE-SKILLS-GUIDE') 'Skills of the Valley First Peoples'
PlaceDoc 'ON-FOOT-GUIDE.md' (Join-Path $Root 'Southern-Oregon\ON-FOOT-GUIDE') 'On Foot - Backpacking and Travel When the Roads Are Empty'
PlaceDoc 'PRACTICAL-MATH-GUIDE.md' (Join-Path $Root 'Southern-Oregon\PRACTICAL-MATH-GUIDE') 'Practical Math, Measuring and Geometry'
PlaceDoc 'WHAT-TO-EXPECT-GUIDE.md' (Join-Path $Root 'Southern-Oregon\WHAT-TO-EXPECT-GUIDE') 'What to Expect: Disaster Scenarios and Timelines'
PlaceDoc 'HOME-DEFENSE-GUIDE.md'   (Join-Path $Root 'Southern-Oregon\HOME-DEFENSE-GUIDE')   'Home and Property Protection (Defensive Only)'
# offline Pill Identifier (NLM Pillbox data, shipped in local\pill-identifier)
$piSrc = Join-Path $ScriptDir 'local\pill-identifier'
if(Test-Path -LiteralPath $piSrc){
  $piDst = Join-Path $Root 'Medical\Pill-Identifier'
  New-Item -ItemType Directory -Force $piDst | Out-Null
  Copy-Item -Path (Join-Path $piSrc '*') -Destination $piDst -Recurse -Force
  Log 'pill identifier: copied to Medical\Pill-Identifier'
}
# Unit converter and calculators (one offline page at the top of the drive)
$ucSrc = Join-Path $ScriptDir 'local\unit-converter\UNIT-CONVERTER.html'
if(Test-Path -LiteralPath $ucSrc){ Copy-Item -LiteralPath $ucSrc -Destination (Join-Path $Root 'UNIT-CONVERTER.html') -Force; Log 'unit converter: copied to UNIT-CONVERTER.html' }
else { curl.exe -sfL -A (UA) -o (Join-Path $Root 'UNIT-CONVERTER.html') "$RepoRaw/local/unit-converter/UNIT-CONVERTER.html"; if($LASTEXITCODE -ne 0){ Log '  unit converter missing' } }
# calculator (basic + scientific, offline), next to the unit converter at the top of the drive
$caSrc = Join-Path $ScriptDir 'local\calculator\CALCULATOR.html'
if(Test-Path -LiteralPath $caSrc){ Copy-Item -LiteralPath $caSrc -Destination (Join-Path $Root 'CALCULATOR.html') -Force; Log 'calculator: copied to CALCULATOR.html' }
else { curl.exe -sfL -A (UA) -o (Join-Path $Root 'CALCULATOR.html') "$RepoRaw/local/calculator/CALCULATOR.html"; if($LASTEXITCODE -ne 0){ Log '  calculator missing' } }
# Library Assistant (one chat page that searches everything; needs the AI engine + models)
$laSrc = Join-Path $ScriptDir 'local\library-assistant'
if(Test-Path -LiteralPath $laSrc){
  $laDst = Join-Path $Root 'AI-Offline\Library-Assistant'
  New-Item -ItemType Directory -Force $laDst | Out-Null
  Get-ChildItem -LiteralPath $laSrc | Where-Object { $_.Name -ne 'src' } | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $laDst -Recurse -Force }
  Log 'library assistant: copied to AI-Offline\Library-Assistant (double-click START-LIBRARY-ASSISTANT.bat)'
}
# one start file per kind of device, at the top of the drive
$lnSrc = Join-Path $ScriptDir 'local\launchers'
if(Test-Path -LiteralPath $lnSrc){
  Get-ChildItem -LiteralPath $lnSrc | Where-Object { $_.Name -like 'START-*' -or $_.Name -like 'SETUP-*' } | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $Root $_.Name) -Force }
  Log 'start files: START-Windows.bat, START-Mac.command, START-Linux.sh, START-Android.sh (+ SETUP-Raspberry-Pi.sh for a Pi with no screen)'
}
# walking routes from Cave Junction (pre-built pages + GPX tracks, shipped in local\walking-routes)
$wrSrc = Join-Path $ScriptDir 'local\walking-routes'
if(Test-Path -LiteralPath $wrSrc){
  $wrDst = Join-Path $Root 'Southern-Oregon\Walking-Routes'
  New-Item -ItemType Directory -Force $wrDst | Out-Null
  Copy-Item -Path (Join-Path $wrSrc '*') -Destination $wrDst -Recurse -Force
  Log 'walking routes: copied to Southern-Oregon\Walking-Routes'
}

# ================================================================ README index
Log '=== Building README.html (full index of everything) ==='
function Esc2($s){ $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;' }
function Rel2($full){ ($full.Substring($Root.Length)).TrimStart('\','/') -replace '\\','/' }
function Nice2($name){ ($name -replace '\.[A-Za-z0-9]+$','') -replace '[-_]',' ' }
function Human2($b){ if($b -ge 1GB){"{0:N2} GB" -f ($b/1GB)}elseif($b -ge 1MB){"{0:N0} MB" -f ($b/1MB)}else{"{0:N0} KB" -f ($b/1KB)} }
$idxCss = @'
<style>:root{--bg:#0f1420;--card:#171f2e;--ink:#e7ecf3;--muted:#9fb0c3;--accent:#4fd1c5;--accent2:#f6ad55;--line:#273246;--code:#0b0f17}@media(prefers-color-scheme:light){:root:not([data-theme=dark]){--bg:#f4f6fb;--card:#fff;--ink:#15202b;--muted:#56657a;--accent:#0d9488;--accent2:#b45309;--line:#e2e8f0;--code:#f1f5f9}}:root[data-theme=light]{--bg:#f4f6fb;--card:#fff;--ink:#15202b;--muted:#56657a;--accent:#0d9488;--accent2:#b45309;--line:#e2e8f0;--code:#f1f5f9}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.65 -apple-system,Segoe UI,Roboto,Arial,sans-serif}.wrap{max-width:1000px;margin:0 auto;padding:28px 20px 80px}h1{font-size:30px;background:linear-gradient(135deg,var(--accent),var(--accent2));-webkit-background-clip:text;background-clip:text;color:transparent}h2{font-size:21px;border-bottom:2px solid var(--line);padding-bottom:6px;margin-top:32px}a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}code{background:var(--code);padding:2px 6px;border-radius:6px;font-family:Consolas,monospace;font-size:13px}table{border-collapse:collapse;width:100%;margin:10px 0;font-size:14.5px}th,td{border:1px solid var(--line);padding:8px 11px;text-align:left;vertical-align:top}th{background:rgba(127,127,127,.12)}.muted{color:var(--muted);font-size:13px}.hero{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px;margin:14px 0}details.sec{background:var(--card);border:1px solid var(--line);border-radius:14px;margin:12px 0;padding:0 14px}details.sec>summary{cursor:pointer;font-weight:700;font-size:20px;padding:12px 0}details.sec .n{font-size:12px;font-weight:600;padding:0 8px;border-radius:999px;background:rgba(127,127,127,.16);color:var(--muted);margin-left:8px;vertical-align:middle}</style><script>document.addEventListener('DOMContentLoaded',function(){[].slice.call(document.querySelectorAll('.wrap > h2')).forEach(function(h,i){var d=document.createElement('details'),s=document.createElement('summary');d.className='sec';if(i===0)d.open=true;s.innerHTML=h.innerHTML;h.parentNode.insertBefore(d,h);d.appendChild(s);var n=h.nextSibling;h.parentNode.removeChild(h);while(n&&!(n.nodeType===1&&n.tagName==='H2')){var x=n.nextSibling;d.appendChild(n);n=x}var c=d.querySelectorAll('tr').length-d.querySelectorAll('table').length;if(c>0){var b=document.createElement('span');b.className='n';b.textContent=c;s.appendChild(b)}})});</script><style>:root{color-scheme:dark}@media(prefers-color-scheme:light){:root:not([data-theme=dark]){color-scheme:light}}:root[data-theme=light]{color-scheme:light}.themebtn{font:inherit;font-size:14px;line-height:1.3;background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:999px;padding:3px 11px;cursor:pointer;white-space:nowrap;text-decoration:none}.themefloat{position:absolute;top:10px;right:12px;z-index:9}@media print{.themebtn{display:none}}</style><script>/* so-theme: light or dark screen */(function(){var K="so-theme",d=document.documentElement,L={auto:"\uD83C\uDF13 Auto",dark:"\uD83C\uDF19 Dark",light:"\u2600\uFE0F Light"},N={auto:"dark",dark:"light",light:"auto"},cur="auto";try{cur=localStorage.getItem(K)||"auto"}catch(e){}function a(){if(cur==="dark"||cur==="light")d.setAttribute("data-theme",cur);else d.removeAttribute("data-theme");var b=document.querySelectorAll(".themebtn");for(var i=0;i<b.length;i++){b[i].textContent=L[cur]||L.auto;b[i].title="Screen: "+cur+" - tap to change (Auto follows this device)"}}a();window.soTheme=function(){cur=N[cur]||"dark";try{localStorage.setItem(K,cur)}catch(e){}a()};function btn(){var b=document.createElement("button");b.type="button";b.className="themebtn";return b}document.addEventListener("DOMContentLoaded",function(){if(!document.querySelector(".themebtn")){var n=document.querySelector(".topnav"),b=btn();if(n){n.appendChild(document.createTextNode(" \u00B7 "));n.appendChild(b)}else{b.className+=" themefloat";document.body.appendChild(b)}}var all=document.querySelectorAll(".themebtn");for(var i=0;i<all.length;i++)all[i].onclick=window.soTheme;a()})})();</script>
'@
# ---- local pack index: Southern-Oregon\LOCAL-FILES.html (what each local file is, with links)
# Grouped on the same "shelves" as the Library Assistant's Books tab; every group folds open/closed.
$ShelfNames = @('&#x1F9ED; Start here','&#x1FA79; Health &amp; medicine','&#x1F4A7; Water','&#x1F35E; Food','&#x1F332; Living off the land','&#x1F410; Animals','&#x1F3E0; Shelter &amp; building','&#x1F4A1; Heat, light &amp; power','&#x1F6E0;&#xFE0F; Making &amp; repair','&#x1F97E; Getting around','&#x1F4E1; Radio, community &amp; protection','&#x1F6A8; Disasters','&#x1F4BE; Using this library','&#x1F4C1; Other')
$ShelfOf = @{ 'Local-Contacts'=0
  'Medical'=1; 'Sanitation-Hygiene'=1; 'Children-Learning'=1
  'Water'=2; 'Water-Purification'=2; 'Water-Wells-Pumps'=2
  'Food-Security'=3; 'Food-From-Scratch'=3; 'Food-Storage'=3; 'Gardening-Food'=3
  'Wild-Plants'=4; 'Mushrooms'=4; 'Hunting'=4; 'Trapping'=4; 'Fishing'=4; 'Native-Skills'=4
  'Animals'=5; 'Small-Livestock'=5; 'Horses-Draft-Animals'=5
  'Shelter-Building'=6; 'Natural-Building'=6
  'Firewood'=7; 'Off-Grid-Power'=7; 'Fuel'=7; 'Engines-Motors'=7
  'Homestead-Skills'=8; 'Blacksmithing-Tools'=8; 'Clothing-Leather'=8; 'Electronics-Repair'=8; 'Math-Measuring'=8
  'Travel-On-Foot'=9; 'Bicycles-Carts'=9; 'Navigation-Weather'=9; 'Maps'=9; 'Walking-Routes'=9
  'Comms-Signals'=10; 'Radio-Weather'=10; 'Community-Barter'=10; 'Home-Security'=10
  'Wildfire'=11; 'Disaster-Scenarios'=11; 'Earthquake-Tsunami'=11; 'Nuclear-Radiation'=11; 'EMP-Solar-Storms'=11
  'Manuals'=12 }
function ShelfNum($folder){
  $f = $folder -replace '^Southern-Oregon\\',''
  if($f -like 'Manuals\Radio*'){ return 10 }
  $k = ($f -split '\\')[0]
  if($ShelfOf.ContainsKey($k)){ return $ShelfOf[$k] } else { return 13 }
}
$navCss = '<style>.topnav{font-size:14.5px;margin:-28px -20px 8px;padding:10px 20px 8px;color:var(--muted);position:sticky;top:0;z-index:4;background:var(--bg);border-bottom:1px solid var(--line)}.topnav a{text-decoration:none;white-space:nowrap}</style>'
$lfCss = '<style>details{background:var(--card);border:1px solid var(--line);border-radius:14px;margin:10px 0}details details{border:none;border-top:1px solid var(--line);border-radius:0;margin:0}summary{cursor:pointer;padding:12px 16px;font-weight:700;font-size:18px}details details summary{font-size:15.5px;color:var(--accent2);padding:10px 16px}.in{padding:0 12px 10px}.n{font-size:12px;font-weight:600;padding:0 8px;border-radius:999px;background:rgba(127,127,127,.16);color:var(--muted);margin-left:6px;vertical-align:middle}input[type=search]{width:100%;font:inherit;padding:10px 12px;border-radius:12px;border:1px solid var(--line);background:var(--card);color:var(--ink)}button{font:inherit;font-size:14px;background:none;border:none;color:var(--accent);text-decoration:underline;cursor:pointer;padding:4px 0}table{display:block;overflow-x:auto}</style>'
$lfJs = '<script>function filt(v){v=v.toLowerCase().trim();document.querySelectorAll("tr.f").forEach(function(r){r.style.display=(!v||r.textContent.toLowerCase().indexOf(v)>=0)?"":"none"});document.querySelectorAll("details").forEach(function(d){var n=0;d.querySelectorAll("tr.f").forEach(function(r){if(r.style.display!=="none")n++});d.style.display=n?"":"none";d.open=!!v&&n>0})}function openAll(o){document.querySelectorAll("details").forEach(function(d){d.open=o})}</script>'
function LocalHref($it){
  $p = Join-Path $it.Folder $it.Name
  if($p -like 'Southern-Oregon\*'){ $p = $p.Substring(16) } else { $p = '..\' + $p }
  (($p -replace '\\','/') -replace ' ','%20') -replace '#','%23'
}
try{
  $items = @(Read-LocalList)
  if($items.Count -gt 0){
    $i = 0
    $items = @($items | ForEach-Object { $i++; $_ | Add-Member -NotePropertyName Shelf -NotePropertyValue (ShelfNum $_.Folder) -PassThru | Add-Member -NotePropertyName Seq -NotePropertyValue $i -PassThru } | Sort-Object Shelf, Seq)
    $lb = New-Object System.Text.StringBuilder
    [void]$lb.Append("<!DOCTYPE html><html lang=`"en`"><head><meta charset=`"utf-8`"><meta name=`"viewport`" content=`"width=device-width,initial-scale=1`"><title>Illinois Valley - Local Files</title>$idxCss$navCss$lfCss$lfJs</head><body><div class=`"wrap`"><p class='topnav'><a href='../START-HERE.html#guides-by-subject'>&#x1F4D8; Guides</a> &middot; <a href='../EMERGENCY-FINDER.html'>&#x1F198; Emergency</a> &middot; <a href='../SUBJECT-INDEX.html'>&#x1F4C7; Index A&ndash;Z</a> &middot; <a href='../README.html'>&#x1F4DA; Every file</a></p>")
    [void]$lb.Append("<h1>Illinois Valley &amp; Southern Oregon &mdash; Local Files</h1>")
    [void]$lb.Append("<div class='hero'>Every file in the local pack, what it is, and a link to open it &mdash; grouped by subject. Tap a heading to open it. For the one-page quick reference (radio, weather, contacts, seasons) open <a href='ILLINOIS-VALLEY-START-HERE.html'><b>ILLINOIS-VALLEY-START-HERE.html</b></a>.<br><span class='muted'>Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm'). Anything marked <i>not downloaded yet</i> failed or was skipped &mdash; run the installer again (or <code>local-pack-only.bat</code>) to retry.</span></div>")
    [void]$lb.Append("<p><input type='search' placeholder='Filter by title or topic...' oninput='filt(this.value)'></p><p><button onclick='openAll(true)'>Open all</button> &middot; <button onclick='openAll(false)'>Close all</button></p>")
    foreach($sg in ($items | Group-Object Shelf | Sort-Object { [int]$_.Name })){
      [void]$lb.Append("<details><summary>$($ShelfNames[[int]$sg.Name]) <span class='n'>$($sg.Count)</span></summary><div class='in'>")
      foreach($g in ($sg.Group | Group-Object { $_.Folder -replace '^Southern-Oregon\\','' })){
        [void]$lb.Append("<details><summary>$(Esc2 (($g.Name -replace '\\',' / ') -replace '-',' ')) <span class='n'>$($g.Count)</span></summary><div class='in'><table><tr><th>File</th><th>What it is</th><th>Size</th></tr>")
        foreach($it in $g.Group){
          $full = Join-Path (Join-Path $Root $it.Folder) $it.Name
          $got  = Test-Path -LiteralPath $full
          $nm   = Esc2 $it.Name
          $cell = if($got){ "<a href=`"$(LocalHref $it)`">$nm</a>" } else { "$nm <span class='muted'>(not downloaded yet)</span>" }
          $sz   = if($got){ Human2 (Get-Item -LiteralPath $full).Length } else { '' }
          [void]$lb.Append("<tr class='f'><td>$cell</td><td>$(Esc2 $it.Desc)</td><td>$sz</td></tr>")
        }
        [void]$lb.Append("</table></div></details>")
      }
      [void]$lb.Append("</div></details>")
    }
    [void]$lb.Append("</div></body></html>")
    [System.IO.File]::WriteAllText((Join-Path $Root 'Southern-Oregon\LOCAL-FILES.html'), $lb.ToString(), [System.Text.UTF8Encoding]::new($false))
    Log 'Southern-Oregon\LOCAL-FILES.html written.'
  }
}catch{ Log "local index ERROR: $($_.Exception.Message)" }

try{
  $all = Get-ChildItem $Root -Recurse -File -ErrorAction SilentlyContinue
  $htmlDocs = $all | Where-Object {$_.Extension -eq '.html' -and $_.Name -ne 'README.html' -and $_.FullName -notmatch '\\Walking-Routes\\directions\\'} | Sort-Object {Rel2 $_.FullName}
  $mdDocs   = $all | Where-Object {$_.Extension -eq '.md'} | Sort-Object {Rel2 $_.FullName}
  $pdfs     = $all | Where-Object {$_.Extension -eq '.pdf'} | Sort-Object {Rel2 $_.FullName}
  $zims     = $all | Where-Object {$_.Extension -eq '.zim'} | Sort-Object {Rel2 $_.FullName}
  $apks     = $all | Where-Object {$_.Extension -eq '.apk'} | Sort-Object {Rel2 $_.FullName}
  $progs    = $all | Where-Object {$e=$_.Extension.ToLower(); ($e -in @('.bat','.sh','.command','.appimage','.run','.dmg')) -or ($e -eq '.exe' -and $_.Name -match 'installer|kiwix-desktop')} | Sort-Object {Rel2 $_.FullName}
  $data     = $all | Where-Object {$_.Name -like '*.bz2' -or $_.Name -like '*.obf.zip'} | Sort-Object {Rel2 $_.FullName}
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append("<!DOCTYPE html><html lang=`"en`"><head><meta charset=`"utf-8`"><meta name=`"viewport`" content=`"width=device-width,initial-scale=1`"><title>Offline Emergency Library - Full Index</title>$idxCss$navCss</head><body><div class=`"wrap`"><p class='topnav'><a href='START-HERE.html#guides-by-subject'>&#x1F4D8; Guides</a> &middot; <a href='EMERGENCY-FINDER.html'>&#x1F198; Emergency</a> &middot; <a href='SUBJECT-INDEX.html'>&#x1F4C7; Index A&ndash;Z</a> &middot; <a href='Southern-Oregon/LOCAL-FILES.html'>&#x1F3D4;&#xFE0F; Local books</a></p>")
  [void]$sb.Append("<h1>&#128703; Offline Emergency Library &mdash; Full Index</h1>")
  [void]$sb.Append("<div class='hero'>Every guide, document, manual, archive, app and data file on this drive, with links.<br><span class='muted'>Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm')</span></div>")
  if(Test-Path (Join-Path $Root 'START-HERE.html')){ [void]$sb.Append("<p>&#128073; New here? Start with <a href='START-HERE.html'><b>START-HERE.html</b></a>.</p>") }
  [void]$sb.Append("<h2>&#128214; Guides &amp; Documentation</h2><table><tr><th>Guide</th><th>Folder</th><th>Open</th></tr>")
  foreach($h in $htmlDocs){ $rel=Rel2 $h.FullName; $dir=Split-Path $rel -Parent; if(-not $dir){$dir='(root)'}; $mdRel=$rel -replace '\.html$','.md'; $mdLink=if(Test-Path (Join-Path $Root $mdRel)){" &middot; <a href='$mdRel'>md</a>"}else{''}; [void]$sb.Append("<tr><td>$(Esc2 (Nice2 $h.Name))</td><td class='muted'>$dir</td><td><a href='$rel'>HTML</a>$mdLink</td></tr>") }
  [void]$sb.Append("</table>")
  if($pdfs){ [void]$sb.Append("<h2>&#128218; Manuals &amp; Books (PDF)</h2><table><tr><th>Document</th><th>Folder</th><th>Size</th><th>Open</th></tr>"); foreach($p in $pdfs){ $rel=Rel2 $p.FullName; [void]$sb.Append("<tr><td>$(Esc2 (Nice2 $p.Name))</td><td class='muted'>$(Split-Path $rel -Parent)</td><td>$(Human2 $p.Length)</td><td><a href='$rel'>PDF</a></td></tr>") }; [void]$sb.Append("</table>") }
  if($zims){ [void]$sb.Append("<h2>&#127760; Offline Archives (ZIM &mdash; open with Kiwix)</h2><table><tr><th>Archive</th><th>Folder</th><th>Size</th><th>File</th></tr>"); foreach($z in $zims){ $rel=Rel2 $z.FullName; [void]$sb.Append("<tr><td>$(Esc2 (Nice2 $z.Name))</td><td class='muted'>$(Split-Path $rel -Parent)</td><td>$(Human2 $z.Length)</td><td><a href='$rel'>open</a></td></tr>") }; [void]$sb.Append("</table>") }
  if($progs){ [void]$sb.Append("<h2>&#9881; Programs &amp; Launchers</h2><table><tr><th>Item</th><th>Folder</th></tr>"); foreach($x in $progs){ $rel=Rel2 $x.FullName; $dir=Split-Path $rel -Parent; if(-not $dir){$dir='(root)'}; [void]$sb.Append("<tr><td><a href='$rel'>$(Esc2 $x.Name)</a></td><td class='muted'>$dir</td></tr>") }; [void]$sb.Append("</table>") }
  if($apks){ [void]$sb.Append("<h2>&#128241; Phone Apps (Android APK)</h2><table><tr><th>App</th><th>Folder</th><th>Size</th></tr>"); foreach($a in $apks){ $rel=Rel2 $a.FullName; [void]$sb.Append("<tr><td><a href='$rel'>$(Esc2 $a.Name)</a></td><td class='muted'>$(Split-Path $rel -Parent)</td><td>$(Human2 $a.Length)</td></tr>") }; [void]$sb.Append("</table>") }
  if($data){ [void]$sb.Append("<h2>&#128451; Data</h2><table><tr><th>Item</th><th>Folder</th><th>Size</th></tr>"); foreach($d in ($data|Where-Object{$_.Name -like '*.bz2'})){ $rel=Rel2 $d.FullName; [void]$sb.Append("<tr><td>$(Esc2 $d.Name) <span class='muted'>(Wikipedia)</span></td><td class='muted'>$(Split-Path $rel -Parent)</td><td>$(Human2 $d.Length)</td></tr>") }; $maps=$data|Where-Object{$_.Name -like '*.obf.zip'}; if($maps){ $sum=($maps|Measure-Object Length -Sum).Sum; [void]$sb.Append("<tr><td>Offline maps - $($maps.Count) files</td><td class='muted'>OsmAnd</td><td>$(Human2 $sum)</td></tr>") }; [void]$sb.Append("</table>") }
  [void]$sb.Append("</div></body></html>")
  [System.IO.File]::WriteAllText((Join-Path $Root 'README.html'), $sb.ToString(), [System.Text.UTF8Encoding]::new($false))
  Log "README.html index written."
}catch{ Log "README index ERROR: $($_.Exception.Message)" }

# the PC map viewer unpacks the maps the first time it is opened: say why that much of the drive is still empty
try {
  $mz = @(Get-ChildItem (Join-Path $Root 'OsmAnd\*.obf.zip') -ErrorAction SilentlyContinue)
  $unpacked = @(Get-ChildItem (Join-Path $Root 'OsmAnd\obf\*.obf') -ErrorAction SilentlyContinue).Count
  if($mz.Count -and (Test-Path -LiteralPath (Join-Path $Root 'OsmAnd\MapViewer-Desktop\VIEW-MAPS-ON-PC.bat')) -and -not $unpacked){
    $rgb = (($mz | Measure-Object Length -Sum).Sum/1GB)*1.8; $rgb = [math]::Round($rgb, $(if($rgb -lt 10){1}else{0}))
    Log "NOTE: about $rgb GB of the drive is left EMPTY on purpose. The PC map viewer (OsmAnd\MapViewer-Desktop\VIEW-MAPS-ON-PC) unpacks the maps into it the first time you open it. Phones don't need it."
  }
} catch {}
$nFail = @(Get-Content -LiteralPath $FailFile -ErrorAction SilentlyContinue | Where-Object { $_ } | Sort-Object -Unique).Count
if($nFail -gt 0){ Log "=== DONE, but $nFail item(s) could not be downloaded this time (listed in _failed.txt) - run the installer again later to try them again ===" }
else { Log '=== DONE. Open README.html (full index) or START-HERE.html ===' }
Write-Host ''
Write-Host "  Finished. Your offline library is in: $Root" -ForegroundColor Green
if($nFail -gt 0){
  Write-Host "  $nFail item(s) could not be downloaded this time - they are listed in _failed.txt." -ForegroundColor Yellow
  Write-Host "  Everything else is ready. Run the installer again later; it only fetches what's missing." -ForegroundColor Yellow
}
Write-Host "  Open README.html for a full index, or START-HERE.html to begin." -ForegroundColor Green
Write-Host "  Local info: Southern-Oregon\ILLINOIS-VALLEY-START-HERE.html" -ForegroundColor Green
