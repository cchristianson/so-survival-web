# 🛟 Offline Emergency Library

[![Stars](https://img.shields.io/github/stars/cchristianson/so-survival?style=flat)](https://github.com/cchristianson/so-survival/stargazers)
[![Forks](https://img.shields.io/github/forks/cchristianson/so-survival?style=flat)](https://github.com/cchristianson/so-survival/network/members)
[![License: MIT](https://img.shields.io/badge/license-MIT-informational)](LICENSE)
![Platforms](https://img.shields.io/badge/platforms-Windows%20%7C%20macOS%20%7C%20Linux-informational)

**A complete, offline, no-internet "survival knowledge" kit you can download with a single
command.** Built for emergencies, grid-down scenarios, remote areas, or anyone who wants a
self-contained offline reference + AI on a drive.

One command asks you **only one thing — where to save the files — then downloads
everything** and writes all the documentation (Markdown **and** HTML). After that, it all
works with **no internet**.

> ### 🏔️ Illinois Valley edition
> This copy is customized for the **Illinois Valley / Josephine County, southern Oregon**:
> - **Wikipedia fixed:** downloads Kiwix's readable Wikipedia **with pictures** (one ~120 GB
>   `.zim` file) instead of the original raw 24 GB dump, which nothing in the kit could open.
> - **Local pack** (`Southern-Oregon\` and `Medical\`, ~1,500 files, ~8.6 GB): topo and forest
>   maps of the valley, hunting/fishing/trapping rules and how-to, gardening & food
>   preservation, food from scratch (flour, masa, sourdough, staples), water, wild plants and
>   mushrooms, animal husbandry & vet care, horses, mules & draft animals, off-grid power &
>   creek hydro, engines, motors & generators, fuel storage & recovery, blacksmithing & hand tools, seed saving & fruit-tree grafting, root
>   cellars & food storage without power, EMP/solar storms & Faraday cages, water wells & pumps, water purification
>   from raw materials, firewood, food rationing & nutrition when food is scarce, injuries with no help
>   coming, signals & Morse code, navigation & weather, community & barter, bicycles & carts, shelter &
>   building repair, natural building (cob, straw bale, clay, hemp, lime), rabbits & chickens, sanitation & stopping disease,
>   preserving food, goats/dairy/bees, childbirth & young children, clothing/leather/shoes, homestead
>   skills (soap, fuels, stoves, sanitation, crafts), household make-do and electronics repair, wildfire, earthquake & tsunami, nuclear
>   fallout, local radio/weather, and medical books, drug references and a **pill identifier**.
>   **54 plain-English guides** link straight to the exact book and page on the drive (📖), to the
>   drawings and diagrams in those books (🖼️) and to offline Wikipedia photos (📷); each ends with a
>   *Pictures & diagrams* gallery, and Previous / Next links to the other guides in its group. They are
>   grouped by subject (Health, Water, Food, Living off the land, Animals, Shelter & building, Heat,
>   light & power, Making & repair, Getting around, Radio & community, Disasters) in folding sections —
>   the same groups in the Library Assistant's Guides and Books tabs and in the drive's file lists — and
>   start from the one-page quick reference (`Southern-Oregon\ILLINOIS-VALLEY-START-HERE.html`). The download lists are
>   `lists/core-files.txt` (every area), `regions/oregon/files.txt` and `regions/illinois-valley/files.txt` — one
>   line per file, easy to add to.
> - **Library Assistant — runs on almost anything:** start files at the top of the drive
>   (`START-Windows.bat`, `START-Mac.command`, `START-Linux.sh` for Linux/Raspberry Pi/Chromebook,
>   `START-Android.sh` for Android tablets and phones via Termux) open one chat page that searches
>   every PDF, guide and Kiwix archive (Wikipedia, WikiMed, iFixit…) and has the offline AI answer
>   with clickable sources. It **sizes the AI to the device** (Off / Quick 1.5B / Standard 3B /
>   Smart 8B / graphics card), times a test answer and steps down if too slow; change it in
>   ⚙️ Settings. See `docs/START-ON-ANY-DEVICE.md`. Source in `local/library-assistant/src` (Go,
>   standard library only); search index pre-built.
> - **Share with every phone nearby (iPhones too):** ⚙️ Settings → *Share with phones nearby* lets
>   any phone, tablet or laptop on the same Wi-Fi (a phone hotspot or travel router is enough, no
>   internet) use the library in its browser, with the AI running on the sharing device. Only the
>   sharing device can change settings.
> - **Ammo-can library computer:** a Raspberry Pi kept in a sealed steel ammo can (safe from EMP).
>   Open the lid, plug in power, and every phone nearby uses the library and the AI over the Pi's
>   own Wi-Fi - no screen, keyboard or internet. `SETUP-Raspberry-Pi.sh` (top of the drive) sets it
>   up once; `docs/AMMO-CAN-COMPUTER-GUIDE.md` covers parts, building, packing and use.
> - **Community kit (~11 GB, fits a 16 GB stick or SD card):** run the installer and pick a
>   16 GB drive - it chooses this set for you: all the guides and local books plus the Library
>   Assistant with a small AI for every kind of device, made to copy for neighbors. (Helpers:
>   `community-kit.bat` or `./get-offline-library.sh --community` does the same with no questions.)
> - **Storing energy without batteries, and reusing generators:** a guide to what gravity batteries
>   (lifted water, sand, weights) really hold and what works instead (high water tanks, hot water, masonry
>   heaters, ice and cold water, timing the work), with two DOE build books added in
>   `Off-Grid-Power\Energy-Storage`; and a section in the Engines guide on taking apart a standard or inverter
>   generator to run its parts from water or wind once fuel is gone.
> - **Tools tab and calculator:** the Library Assistant and the website have a **🧮 Tools** tab with a basic and
>   scientific calculator (`CALCULATOR.html` at the top of the drive), the unit converter, the pill identifier and
>   the routes, all working offline.
> - **Unit converter & calculators (works offline):** `UNIT-CONVERTER.html` at the top of the drive converts
>   any measurement (type "5 gal" or "72 F") and works out area and fence posts, concrete, roof pitch and
>   rafters, tanks and wells, rainwater, water pressure and flow, dilutions, volts/watts, battery time,
>   solar panels, wire size, recipes, two-stroke mix, walking time and doses by weight. The **Practical
>   Math, Measuring & Geometry** guide explains the formulas with worked examples.
> - **Fits any drive:** the installer checks how big each part is right now, fills in a list that fits
>   your drive (or `-DriveSize 116` / `--drive-size 116`), and lets you switch parts on and off before
>   anything downloads - Wikipedia with or without pictures, the whole USA or just Oregon and California
>   for maps, small or large AI, and so on.
> - **Walking routes:** back-road and highway walking routes from Cave Junction to every Oregon
>   city and N. California down to Walnut Creek, with turn-by-turn pages and GPX tracks.
> - **Guides fixed:** the HTML guides no longer show garbled characters (â€” etc.).
> - **Point-and-click installer:** no typing commands. Unzip the kit and double-click
>   **`INSTALL-Windows`** (or **`INSTALL-Mac`** / **`INSTALL-Linux.sh`**). A page opens in your web
>   browser: pick the drive, tick the parts you want (it shows what fits), press **Start**, and watch
>   the progress bar. If it is stopped or the internet drops, run it again and press **Continue**.
> - **To run:** download the installer kit from the website (*Offline* tab → *Get the whole library*)
>   or this repo, unzip it, and double-click **`INSTALL-Windows`**. A full library wants about
>   **250 GB free**, but any size drive works - it fills what fits. **`local-pack-only.bat`** grabs
>   just the local pack in minutes — good for a test run, or for refreshing regulations each year.

## 🗺️ Make a version for your own area

Everything here is built to be reused: the guides are written for any area, and what is local
(maps, county plans, local rules, frost dates, radio frequencies, the START HERE page) lives in one
small folder per area under [`regions/`](regions/). To build a library for your town, copy
`regions/_template/`, fill in the names and your local downloads, and run the build;
[`regions/README.md`](regions/README.md) walks through it step by step. Areas in the same state
share a state layer (like `regions/oregon/`), so the second area in a state has much less to do.

---

## What you get

| Component | What it is | Size (approx) | Needs to run |
|---|---|---|---|
| **Offline AI chat** | 3 local AI models (Llama 3.2 3B, Llama 3.1 8B, Qwen2.5 7B) + CPU & GPU engines (llama.cpp) | ~11 GB | CPU only (GPU optional) |
| **Offline doc-Q&A** | GPT4All — ask an AI questions about your PDFs, with citations | ~0.7 GB | CPU, one-time install |
| **Wikipedia** | Full English Wikipedia **with pictures** (Kiwix ZIM). Smaller: `-WikipediaSize nopic` ≈ 50 GB text-only, `mini` ≈ 13 GB intros only | ~120 GB | Kiwix |
| **Offline maps** | Maps for the region you pick (**default US**; any country/region/continent — see below) + **bundled desktop viewer** (OsmAndMapCreator + portable Java) + **bundled Android app (APK)** | US ≈17 GB; varies by region (+~0.4 GB tools) | **PC (no phone) or phone** |
| **Repair archive** | iFixit — cars, appliances, electronics, phones | ~3.4 GB | Kiwix |
| **DIY archive** | Appropedia — plumbing, electrical, construction, energy, water, food | ~0.6 GB | Kiwix |
| **Medical** | Offline medical Wikipedia (WikiMed) + curated medical guide | ~1.8 GB | Kiwix |
| **Survival** | Post-disaster, water, food prep, knots (zimgit) | ~0.8 GB | Kiwix |
| **Army manuals** | Public-domain US Army field/technical manuals (survival, first aid, hand tools, carpentry, auto mechanics, rigging, field cooking) | ~0.2 GB | Any browser (PDF) |
| **Medical books** | *Where There Is No Doctor / No Dentist*, *Ship's Medicine Chest* | ~45 MB | Any browser (PDF) |
| **Radio guide** | How ham/CB/shortwave/GMRS radio works + emergency comms | tiny | Any browser |
| **Kiwix reader** | Portable app to read all `.zim` archives (no install) | ~0.15 GB | — |
| **Phone apps** | Bundled Android APKs (Kiwix + OsmAnd) to port the library to a phone offline | ~0.4 GB | sideload on Android |
| **Illinois Valley pack** | Maps, hunting/fishing/trapping, gardening, food from scratch, water, wild plants & mushrooms, animals & vet, horses & draft animals, seed saving, root cellars & food storage, wells & pumps, water purification, firewood, food scarcity & rationing, field care for injuries, signals & Morse, navigation & weather, community & barter, bicycles & carts, shelter & building, natural building (cob, straw, lime), chickens, ducks, geese, turkeys, rabbits, goats, sheep, pigs, cattle, bees & dogs (one guide each), sanitation & disease, preserving food, hunting/trapping/fishing guide, milk/butter/cheese, rehab after injuries, childbirth & young children, clothing/leather/shoes, off-grid power, engines & generators, fuel, EMP & Faraday cages, blacksmithing, homestead & make-do skills, mortar/concrete/roads, candles & lamp oil, paper & ink, wildfire defense with no grid, skills of the valley's first peoples, travel on foot, classic stories for every age with games, songs and things to make, wildfire, quake, nuclear fallout, radio, medical books & drug references, pill identifier, walking routes + plain-English guides | ~8.6 GB | Any browser (PDF) |
| **Library Assistant** | One chat page that searches everything above and answers with sources; runs on Windows, Mac, Linux/Raspberry Pi and Android, and sizes the AI to the device | ~0.1 GB | the AI models above |
| **Total** | | **≈ 168 GB** | |

Everything is **free and legally redistributable** — open-weight AI models, openly-licensed
Kiwix archives, and public-domain US-government manuals. **No piracy.**

---

## 📦 Storage requirements — what kind of drive do I need?

The full library is **~168 GB** (most of it is Wikipedia with pictures). Always leave
headroom (unzipping maps for the PC viewer takes ~30 GB more, plus GPT4All and future
updates), so plan for about **250 GB free**.

| Drive | Recommendation |
|---|---|
| **Minimum** | **256 GB** drive (full library + working room) |
| **Comfortable** | **500 GB+** drive (room to add your own files, Survivor Library, etc.) |
| **USB flash drive** | Works for **storage + reading** PDFs/Wikipedia/maps. Use **USB 3.0+ / 128 GB+**. Cheap flash drives are slow — fine for reading, slow for AI. |
| **External SSD** ⭐ | **Best choice.** Running the AI models from an SSD is far faster than from a flash drive or spinning disk. A 256 GB+ USB-C SSD is ideal. |
| **Internal HDD/SSD** | Perfect if you're keeping it on a PC. |

> **Tip:** On a smaller drive, use `-WikipediaSize nopic` (text-only Wikipedia, ~50 GB —
> whole library ~90 GB) or `-WikipediaSize mini` (~13 GB — whole library ~55 GB).
> `-SkipWikipedia -SkipMaps` leaves the AI + manuals + local pack in ~20 GB.

---

## 💻 Hardware requirements — what machine do I need to USE it?

**To download:** any 64-bit **Windows, macOS, or Linux** computer with internet.
- Windows: uses `curl` + PowerShell (both built in).
- macOS/Linux: uses `curl` + `tar` (built in); `unzip` enables the desktop map viewer.

Downloading ~60 GB can take a few hours.

**To use it afterward (offline):**

| Task | Needs |
|---|---|
| Read PDFs, HTML guides, Wikipedia, maps | **Any computer** with a web browser. Even an old/weak PC. |
| Read `.zim` archives | **Kiwix** — bundled portable on Windows & Linux; on macOS install Kiwix (App Store/kiwix.org). |
| **Offline AI — small model (3B)** | Any 64-bit PC, **~4 GB RAM**. Works on CPU; no graphics card needed. |
| **Offline AI — big model (8B)** | **~8 GB RAM** recommended. CPU only. |
| **Offline AI — GPU model (Qwen 7B)** | A graphics card with **~6 GB VRAM** (NVIDIA/AMD/Intel) for a big speed boost. Optional. |
| **GPT4All doc-Q&A** | 64-bit PC, ~8 GB RAM recommended. CPU only. Self-contained (no Python/CUDA). |
| **Maps on a computer** | **No phone needed** — bundled desktop viewer (OsmAndMapCreator) + bundled portable Java. First use unzips maps (~30 GB). |
| **Maps on a phone** | Android: bundled **OsmAnd~ APK** (sideload offline). iPhone/iPad: install **OsmAnd** from the App Store while online. |

**Key points:**
- **No GPU is required** for the AI — it runs on an ordinary CPU (just slower). A 6 GB GPU
  is a bonus.
- The AI engine ships **x64, ARM64, and Vulkan-GPU** builds, so it runs on Intel/AMD and
  ARM Windows machines.
- The whole kit is **portable** — copy the `OfflineLibrary` folder to any PC and use it.

---

## 🚀 How to download (pick one)

> **Illinois Valley edition:** use **A** (double-click `INSTALL-Windows`) or **E**. Methods B–D
> fetch the *original* project from GitHub, which doesn't have the fixes or the local pack.

### A) Easiest — double-click `INSTALL-Windows` (or `INSTALL-Mac` / `INSTALL-Linux.sh`)
Download the installer kit (a zip) from the website, or download/clone this repo. Unzip it
(Windows: right-click → **Extract All**). The kit shows READ-ME-FIRST, the INSTALL files and a
`files` folder holding everything else. Double-click:

- **Windows:** `INSTALL-Windows`. If Windows SmartScreen warns, click **More info → Run anyway**.
- **Mac:** `INSTALL-Mac`. The first time, **right-click it → Open → Open** (Macs block
  double-clicking a downloaded program the first time).
- **Linux:** `INSTALL-Linux.sh` (or run `bash INSTALL-Linux.sh` in a terminal).

A page opens in your web browser. It lists your drives with their free space; pick one, tick the
parts you want (it fills in a list that fits and shows the total), and press **Start**. Leave the
computer on until the bar reaches 100%. If it stops, run it again and press **Continue** - it
picks up where it left off. If the page can't open, the same choices appear in a text window
instead (the old `install.bat` still works and does the same thing).

### B) In Claude Code (one prompt)
Install this repo's skill, then say:
```
/offline-emergency-library
```
It will ask **only**: *"Where would you like to save these files?"* — then download
everything.

### C) Windows — PowerShell one-liner (no Claude needed)
```powershell
irm https://raw.githubusercontent.com/elhajahmadj/offline-emergency-library/main/Get-OfflineLibrary.ps1 | iex
```
It will prompt you for the save location, then download everything.

### D) macOS / Linux — one-liner
```bash
curl -fsSL https://raw.githubusercontent.com/elhajahmadj/offline-emergency-library/main/get-offline-library.sh | bash
```
It will prompt you for the save location, then download everything.
(Requires `curl` and `tar`; `unzip` enables the desktop map viewer. All are standard.)

### E) Clone and run
```bash
git clone https://github.com/cchristianson/so-survival.git
cd so-survival
# Windows:
./Get-OfflineLibrary.ps1 -Destination "E:\"
# macOS / Linux:
./get-offline-library.sh -d /path/to/drive
```

**All methods are resumable** — if the download is interrupted, run the same command again
and it continues where it left off.

### Platform support
| | Windows | macOS | Linux |
|---|---|---|---|
| Installer | `Get-OfflineLibrary.ps1` / `install.bat` | `get-offline-library.sh` | `get-offline-library.sh` |
| Offline AI chat | ✅ (x64/ARM + Vulkan GPU) | ✅ (Metal GPU) | ✅ (x64/ARM + Vulkan GPU) |
| GPT4All doc-Q&A | ✅ `.exe` | ✅ `.dmg` | ✅ `.run` |
| Kiwix desktop | ✅ bundled portable | App Store / kiwix.org | ✅ bundled AppImage (x64) |
| Maps on PC | ✅ bundled viewer+Java | ✅ bundled viewer+Java | ✅ bundled viewer+Java |
| All content (Wikipedia, ZIM, PDF, maps, APKs) | ✅ | ✅ | ✅ |

---

## 🔐 Trust & verification

This project **hosts nothing** — it downloads from the official upstream sources below and
runs 100% offline afterward:

| What | From |
|---|---|
| AI models (GGUF) | huggingface.co (bartowski) |
| AI engine (llama.cpp) | github.com/ggml-org/llama.cpp |
| GPT4All | github.com/nomic-ai/gpt4all |
| Kiwix reader + ZIM archives | download.kiwix.org |
| Wikipedia | dumps.wikimedia.org |
| Maps + desktop viewer | download.osmand.net |
| Portable Java | api.adoptium.net (Eclipse Temurin) |
| Manuals (PDF) | archive.org |
| Phone apps (APK) | github.com/kiwix/kiwix-android, f-droid.org |

**Verify the installer before running it.** Each script's SHA-256 is published in
[`SHA256SUMS.txt`](SHA256SUMS.txt) and CI checks they stay in sync.

```bash
# macOS / Linux
curl -fsSLO https://raw.githubusercontent.com/cchristianson/so-survival/main/get-offline-library.sh
sha256sum get-offline-library.sh      # compare against SHA256SUMS.txt
bash get-offline-library.sh
```
```powershell
# Windows
irm https://raw.githubusercontent.com/cchristianson/so-survival/main/Get-OfflineLibrary.ps1 -OutFile Get-OfflineLibrary.ps1
Get-FileHash Get-OfflineLibrary.ps1 -Algorithm SHA256   # compare against SHA256SUMS.txt
./Get-OfflineLibrary.ps1
```

The scripts are plain Bash/PowerShell — you're encouraged to read them first. (Hashes match
the files served by GitHub `raw` and the release assets; a `git clone` on Windows rewrites
line endings, so local hashes will differ there.)

---

## 🗺️ Choosing your map region (optional — default is US)

The maps default to the **United States**. To download a different country, region, or
continent, add `-Region` (Windows) / `--region` (macOS/Linux):

```bash
# Windows
./Get-OfflineLibrary.ps1 -Destination "E:\" -Region France
./Get-OfflineLibrary.ps1 -Destination "E:\" -Region "Germany,Austria"
./Get-OfflineLibrary.ps1 -Destination "E:\" -Region Europe      # whole continent
# macOS / Linux
./get-offline-library.sh -d /mnt/usb --region Japan
./get-offline-library.sh -d /mnt/usb --region US_texas          # a sub-region
./get-offline-library.sh -d /mnt/usb --region world             # everything (hundreds of GB!)
```

**Not sure of the name? List what's available (no download):**
```bash
./Get-OfflineLibrary.ps1 -ListRegions              # Windows: all countries/regions
./Get-OfflineLibrary.ps1 -ListRegions -Filter US   # Windows: sub-regions of the US
./get-offline-library.sh --list-regions            # macOS/Linux: all
./get-offline-library.sh --list-regions France     # macOS/Linux: sub-regions of France
```

Accepts a country (`France`), several (`"Germany,Austria"`), a continent (`Europe`,
`Africa`, `Asia`, `North-America`, `South-America`, `Central-America`,
`Australia-Oceania`), a sub-region (`US_texas`, `Germany_bayern`), or `world`.
**Size varies:** US ≈17 GB, a small country <1 GB, a continent tens of GB, `world`
hundreds of GB — the installer prints the size and warns before large downloads.

## 🧭 After it finishes

The installer writes a **`README.html`** at the root of the download folder — a full,
clickable **index of every guide, document, manual, archive, app and data file** on the
drive (auto-generated by scanning the folders). Open that first for a complete map of
everything, or **`START-HERE.html`** for a guided intro.

(You can regenerate the index any time with `build-readme-index.ps1 -Root "<folder>"`.)

Both pages link to each component's guide:

- `AI-Offline\HOW-TO-RUN-OFFLINE-AI.html` — run the offline AI chat
- `AI-Offline\DocReader-GPT4All\HOW-TO-ASK-YOUR-DOCS.html` — ask AI about your PDFs
- `Kiwix-Reader\HOW-TO-USE-KIWIX.html` — read the `.zim` archives
- `OsmAnd\HOW-TO-VIEW-MAPS.html` — view maps on a PC (no phone) or phone
- `Phone-Apps\USE-ON-PHONE.html` — port the library to a phone
- `Manuals\READ-ME-FIRST.html` and `Medical\READ-ME-FIRST.html`
- `Manuals\Radio-Communications\RADIO-GUIDE.html` — emergency radio comms

---

## Options (optional, for small drives)

| Flag | Effect |
|---|---|
| `-Region <name>` / `--region <name>` | Choose map region (default `US`); country, continent, sub-region, or `world` |
| `-ListRegions` / `--list-regions [filter]` | List available map regions, then exit (no download) |
| `-WikipediaSize maxi\|nopic\|mini` / `--wikipedia-size …` | Wikipedia edition: `maxi` (default, with pictures, ~120 GB), `nopic` (text only, ~50 GB), `mini` (article intros, ~13 GB) |
| `-SkipWikipedia` / `--skip-wikipedia` | Don't download Wikipedia at all |
| `-DriveSize 116` / `--drive-size 116` | Fill that many GB with the most useful parts (sizes are checked live). Without it, a double-click install fills the drive's free space |
| `-Choose` / `--choose` | Show the "what goes on this drive" list (with sizes, switch parts on/off) even when you give `-Destination` |
| `-PlanOnly` / `--plan-only` | Just show what would fit, download nothing (e.g. `-DriveSize 64 -PlanOnly`) |
| `-LocalOnly` / `--local-only` | Download only the Illinois Valley pack + guides (what `local-pack-only.bat` does) |
| `-Community` / `--community` | The shareable kit (~11 GB): local pack + guides + Library Assistant with the small AI models and the AI engine for every kind of device, plus the Android (Termux) setup (what `community-kit.bat` does) |
| `-SkipOtherDevices` / `--skip-other-devices` | Only this computer's programs, not the Mac/Linux/Android ones (saves ~300 MB) |
| `-SkipLocal` / `--skip-local` | Skip the Illinois Valley pack |
| `-SkipMaps` / `--skip-maps` | Don't download the maps (~17 GB saved for US) |
| `-SkipModels` / `--skip-models` | Skip the large 8B/7B AI models, keep the small 3B (~9 GB saved) |

Example: `./Get-OfflineLibrary.ps1 -Destination "F:\" -SkipWikipedia -SkipMaps`

---

## ⚠️ Disclaimers

- Offline AIs and older manuals **can be wrong or outdated**. Verify anything
  safety-critical (medical, electrical, structural) against authoritative sources when
  possible. This kit is reference material, **not** professional advice.
- Modern copyrighted code books (NEC/UPC) and brand auto manuals (Haynes/Chilton) are
  **not** included. Their topics are covered by the openly-licensed iFixit/Appropedia
  archives and public-domain Army technical manuals.
- Respect your local laws for radio transmission (listening is always fine; see the radio
  guide).

## ⭐ Star history
[![Star History Chart](https://api.star-history.com/svg?repos=cchristianson/so-survival&type=Date)](https://star-history.com/#cchristianson/so-survival&Date)

## Contributing
Issues and PRs welcome — see [CONTRIBUTING](.github/CONTRIBUTING.md), the
[ROADMAP](ROADMAP.md), and issues labeled **good first issue**. Testers for the macOS/Linux
installers especially wanted.

## Credits
This library started from [elhajahmadj/offline-emergency-library](https://github.com/elhajahmadj/offline-emergency-library)
(MIT), the original one-command offline kit, and has been heavily changed and expanded since:
the guides, the local packs, the Library Assistant, the website and the region template are new.

## License
Code and documentation in this repo: **MIT** (see `LICENSE`). Downloaded content retains
its original licenses (open-weight model licenses, CC licenses for Kiwix content, public
domain for US-government works).
