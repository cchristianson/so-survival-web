#!/bin/bash
# SETUP-Raspberry-Pi.sh - make a Raspberry Pi a library box that needs no screen or keyboard,
# for example the ammo-can library computer (see AMMO-CAN-COMPUTER-GUIDE.html).
#
# Run it ONCE, on the Pi, with a screen and keyboard plugged in (a TV is fine):
#   in the file manager, right-click this file > "Run in Terminal" - or open a terminal here and type
#       bash SETUP-Raspberry-Pi.sh
# After the Pi restarts it needs no screen, keyboard or internet:
#   plug in power > wait 2-3 minutes > join the Pi's Wi-Fi on a phone > open the address on the card.
#
# What it changes on the Pi (all undone by:  bash SETUP-Raspberry-Pi.sh --undo):
#   - the Pi makes its own Wi-Fi network every time it starts (a NetworkManager hotspot, 192.168.4.1)
#   - the library starts by itself, shared with phones (a system service called emergency-library)
#   - a USB library drive is mounted at /mnt/emergency-library at start-up (one /etc/fstab line;
#     the original is backed up to /etc/fstab.before-emergency-library)
#   - the desktop is switched off: more memory for the AI, and one press of the power button
#     shuts the Pi down safely. With a TOUCHSCREEN on the Pi (it asks), the desktop stays on
#     instead and the library opens on that screen by itself, full size, with its own on-screen
#     keyboard (a small start-up file: /usr/local/bin/emergency-library-screen and one in
#     ~/.config/autostart). Phones can still join the Pi's Wi-Fi at the same time
#   - Raspberry Pi 5 on a power bank: lets the USB ports give the library drive full power
#     (usb_max_current_enable=1 in config.txt) - it asks first
#   - Raspberry Pi 4 and older (no power button): turns pins 5 and 6 into a power button
#     (dtoverlay=gpio-shutdown in config.txt). Wire a push button across them: one press shuts
#     down safely, the next press starts the Pi again
#   - it writes PI-WIFI-CARD.html next to this file: the Wi-Fi name, password and address to print
# Options:  --undo   --name "Wi-Fi name"   --password "8 to 63 characters"   --country US
#           --battery / --no-battery (answer the power-bank question)
#           --screen / --no-screen (answer the touchscreen question)   --yes (no questions: use
#           the names given or the ones from last time; with no restart at the end)

CON="Emergency-Library-WiFi"         # the Pi's hotspot, as NetworkManager calls it
SERVICE="emergency-library"
UNIT="/etc/systemd/system/$SERVICE.service"
CONF="/etc/emergency-library.conf"   # remembers the Wi-Fi name and password for next time
MNT="/mnt/emergency-library"
ADDR="192.168.4.1"
PORT=8096                            # the library shares on the port after its own (8095)
TAG="# emergency-library: the library drive (added by SETUP-Raspberry-Pi.sh; --undo removes it)"
USBTAG="# emergency-library: full USB power for the library drive on a power bank (SETUP-Raspberry-Pi.sh)"
BTNTAG="# emergency-library: a push button on pins 5 and 6 shuts down and starts the Pi (SETUP-Raspberry-Pi.sh)"
SCREEN_BIN="/usr/local/bin/emergency-library-screen"   # opens the library on a touchscreen on the Pi
LOCAL_PORT=8095                      # the library's own page on the Pi (full control, Settings too)

cd "$(dirname "$0")" || exit 1
HERE="$(pwd -P)"
SELF="$HERE/$(basename "$0")"

pause(){ [ -t 0 ] && [ "${YES:-0}" != 1 ] && { echo; read -r -p "Press Enter to close this window. " _; }; }
die(){ echo; echo "STOPPED: $*"; pause; exit 1; }
ask(){ # question default -> REPLY
  if [ -t 0 ] && [ "${YES:-0}" != 1 ]; then read -r -p "$1 [$2]: " REPLY; REPLY="${REPLY:-$2}"; else REPLY="$2"; fi
}
yes_no(){ ask "$1 (y/n)" "${2:-y}"; case "$REPLY" in [Yy]*) return 0;; esac; return 1; }

UNDO=0 YES=0 OPT_NAME="" OPT_PASS="" OPT_COUNTRY="" OPT_BATT="" OPT_SCREEN=""
while [ $# -gt 0 ]; do
  case "$1" in
    --undo|--remove) UNDO=1;;
    --yes|-y) YES=1;;
    --name) OPT_NAME="${2:-}"; shift;;
    --password) OPT_PASS="${2:-}"; shift;;
    --country) OPT_COUNTRY="${2:-}"; shift;;
    --battery|--usb-power) OPT_BATT=y;;
    --no-battery) OPT_BATT=n;;
    --screen|--touchscreen) OPT_SCREEN=y;;
    --no-screen|--no-touchscreen) OPT_SCREEN=n;;
    -h|--help) awk 'NR>1 && /^#/{sub(/^# ?/,""); print; next} NR>1{exit}' "$SELF"; exit 0;;
    *) die "Unknown option: $1  (try --help)";;
  esac
  shift
done
ARGS=(); [ $UNDO = 1 ] && ARGS+=(--undo); [ $YES = 1 ] && ARGS+=(--yes)
[ -n "$OPT_NAME" ] && ARGS+=(--name "$OPT_NAME"); [ -n "$OPT_PASS" ] && ARGS+=(--password "$OPT_PASS")
[ -n "$OPT_COUNTRY" ] && ARGS+=(--country "$OPT_COUNTRY")
[ "$OPT_BATT" = y ] && ARGS+=(--battery); [ "$OPT_BATT" = n ] && ARGS+=(--no-battery)
[ "$OPT_SCREEN" = y ] && ARGS+=(--screen); [ "$OPT_SCREEN" = n ] && ARGS+=(--no-screen)

# opened with a double-click and no terminal window? open one, so the questions can be seen
if [ ! -t 0 ] && [ $YES != 1 ]; then
  if [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] && command -v x-terminal-emulator >/dev/null; then
    exec x-terminal-emulator -e bash "$SELF" "${ARGS[@]}"
  fi
  echo "Run this in a terminal window:  bash SETUP-Raspberry-Pi.sh   (or add --yes for no questions)"; exit 1
fi

# ---------------------------------------------------------------- is this the right kind of computer?
[ "$(uname -s)" = Linux ] || die "This is for a Raspberry Pi (or another Linux computer). On Windows or a Mac, use the START file instead."
case "$(uname -m)" in
  aarch64|arm64) EXE=library-assistant-linux-arm64;;
  x86_64|amd64)  EXE=library-assistant-linux-x64;;
  armv6l|armv7l) die "This Pi is running the 32-bit system. Put the 64-bit Raspberry Pi OS on it (Raspberry Pi Imager > Raspberry Pi OS (64-bit)), then run this again.";;
  *) die "This kind of computer ($(uname -m)) can't run the Library Assistant.";;
esac

if [ "$(id -u)" -ne 0 ]; then
  echo "This needs administrator rights. If it asks for a password, type the Pi's password."
  exec sudo bash "$SELF" "${ARGS[@]}"
fi

# the everyday user the library runs as (not root)
RUN_USER="${SUDO_USER:-}"
if [ -z "$RUN_USER" ] || [ "$RUN_USER" = root ]; then RUN_USER="$(getent passwd 1000 | cut -d: -f1)"; fi
[ -n "$RUN_USER" ] && id "$RUN_USER" >/dev/null 2>&1 || die "Couldn't find the Pi's normal user account."
RUN_UID="$(id -u "$RUN_USER")"; RUN_GID="$(id -g "$RUN_USER")"; RUN_GROUP="$(id -gn "$RUN_USER")"
RUN_HOME="$(getent passwd "$RUN_USER" | cut -d: -f6)"
SCREEN_AUTO="$RUN_HOME/.config/autostart/emergency-library-screen.desktop"

OLD_TARGET="" WIFI_NAME="" WIFI_PASS="" WIFI_COUNTRY="" SCREEN=""
# shellcheck source=/dev/null
[ -f "$CONF" ] && . "$CONF"
save_conf(){ ( umask 077; { printf 'WIFI_NAME=%q\n' "$WIFI_NAME"; printf 'WIFI_PASS=%q\n' "$WIFI_PASS"
  printf 'WIFI_COUNTRY=%q\n' "$WIFI_COUNTRY"; printf 'OLD_TARGET=%q\n' "$OLD_TARGET"
  printf 'SCREEN=%q\n' "$SCREEN"; } > "$CONF" ); }

# fstab without our lines (the comment tag and the line that mounts $MNT)
fstab_without_ours(){ awk -v m="$MNT" -v t="$TAG" '$0==t{next} ($1 !~ /^#/ && $2==m){next} {print}' /etc/fstab; }

# the Pi's firmware settings file (newer systems keep it in /boot/firmware)
BOOTCFG=""; for f in /boot/firmware/config.txt /boot/config.txt; do [ -f "$f" ] && { BOOTCFG="$f"; break; }; done
MODEL=""; [ -r /proc/device-tree/model ] && MODEL="$(tr -d '\0' < /proc/device-tree/model)"
IS_PI5=0; IS_OLDPI=0     # Pi 5 has a power button; Pi 1-4 can get one on pins 5 and 6
case "$MODEL" in *"Raspberry Pi "[5-9]*) IS_PI5=1;; *"Raspberry Pi"*) IS_OLDPI=1;; esac
bootcfg_strip(){ # config.txt without our tagged block (tag line, the setting after it, and its [all])
  awk -v t="$1" '{l[NR]=$0} END{for(i=1;i<=NR;i++){
    if(l[i]=="[all]" && l[i+1]==t){i+=2; continue} if(l[i]==t){i+=1; continue} print l[i]}}' "$BOOTCFG"; }
bootcfg_set(){ # tag setting 1|0 - add or remove one of our tagged blocks at the end of config.txt
  [ -n "$BOOTCFG" ] || return 0
  local tmp; tmp="$(mktemp)"
  bootcfg_strip "$1" > "$tmp"
  [ "$3" = 1 ] && printf '[all]\n%s\n%s\n' "$1" "$2" >> "$tmp"
  cmp -s "$tmp" "$BOOTCFG" || { [ -f "$BOOTCFG.before-emergency-library" ] || cp -p "$BOOTCFG" "$BOOTCFG.before-emergency-library"; cat "$tmp" > "$BOOTCFG"; }
  rm -f "$tmp"
}
set_usb_power(){ bootcfg_set "$USBTAG" usb_max_current_enable=1 "$1"; }   # 1 = on, 0 = off
set_button(){ bootcfg_set "$BTNTAG" dtoverlay=gpio-shutdown "$1"; }

restart_prompt(){
  echo
  if [ "$YES" = 1 ]; then echo "Restart the Pi to finish (sudo reboot)."; exit 0; fi
  if yes_no "Restart the Pi now to finish?" y; then echo "Restarting..."; systemctl reboot; exit 0; fi
  echo "OK - it takes effect the next time the Pi starts."
  pause; exit 0
}

# ---------------------------------------------------------------- undo
if [ $UNDO = 1 ]; then
  echo "Undoing the library-box setup..."
  systemctl disable --now "$SERVICE" >/dev/null 2>&1
  rm -f "$UNIT"; systemctl daemon-reload
  command -v nmcli >/dev/null && nmcli connection delete "$CON" >/dev/null 2>&1 && echo " - the Pi's own Wi-Fi is removed (it joins your saved Wi-Fi again)"
  if awk -v m="$MNT" '$1 !~ /^#/ && $2==m{f=1} END{exit !f}' /etc/fstab; then
    tmp="$(mktemp)"; fstab_without_ours > "$tmp" && cat "$tmp" > /etc/fstab; rm -f "$tmp"
    echo " - the library drive is no longer mounted at $MNT (the desktop opens it as usual)"
  fi
  if [ -n "$OLD_TARGET" ] && [ "$(systemctl get-default)" != "$OLD_TARGET" ]; then
    systemctl set-default "$OLD_TARGET" >/dev/null 2>&1 && echo " - the desktop is back on"
  fi
  if [ -n "$BOOTCFG" ] && grep -qxF "$USBTAG" "$BOOTCFG"; then set_usb_power 0; echo " - USB power back to normal"; fi
  if [ -n "$BOOTCFG" ] && grep -qxF "$BTNTAG" "$BOOTCFG"; then set_button 0; echo " - pins 5 and 6 are no longer a power button"; fi
  if [ -f "$SCREEN_BIN" ] || [ -f "$SCREEN_AUTO" ]; then
    rm -f "$SCREEN_BIN" "$SCREEN_AUTO"; echo " - the library no longer opens on the Pi's screen by itself"
  fi
  OLD_TARGET=""; [ -f "$CONF" ] && save_conf    # keeps the Wi-Fi name and password for next time
  systemctl daemon-reload
  echo "Done."
  restart_prompt
fi

# ---------------------------------------------------------------- checks
[ -f "$HERE/START-Linux.sh" ] || die "Run this from the library drive - the folder that has START-Linux.sh in it."
[ -f "$HERE/AI-Offline/Library-Assistant/$EXE" ] || die "The Library Assistant isn't on this drive (AI-Offline/Library-Assistant/$EXE). Run the installer again with the AI part ticked."
if ! command -v nmcli >/dev/null || ! systemctl is-active --quiet NetworkManager; then
  die "This Pi's system is too old to make its own Wi-Fi. Put the latest Raspberry Pi OS (64-bit) on it with Raspberry Pi Imager, then run this again."
fi
rfkill unblock wifi >/dev/null 2>&1
WIFI_DEV="$(nmcli -t -f DEVICE,TYPE device status 2>/dev/null | awk -F: '$2=="wifi"{print $1; exit}')"
[ -n "$WIFI_DEV" ] || die "No Wi-Fi found on this Pi. (A Raspberry Pi 4 or 5 has it built in; a Pi Zero 2 W or Pi 3 also works but is slow for the AI.)"
if command -v iw >/dev/null && ! iw list 2>/dev/null | grep -q '^[[:space:]]*\* AP$'; then
  die "This Wi-Fi ($WIFI_DEV) can't make its own network."
fi

# ---------------------------------------------------------------- where the library lives
TGT="$(findmnt -n -o TARGET -T "$HERE")"
SRC="$(findmnt -n -o SOURCE -T "$HERE")"
FST="$(findmnt -n -o FSTYPE -T "$HERE")"
in_fstab_elsewhere(){ # is the drive already mounted at start-up by someone else's fstab line?
  awk -v t="$TGT" -v m="$MNT" '$1 !~ /^#/ && $2!=m { gsub(/\\040/," ",$2); if($2==t) f=1 } END{exit !f}' /etc/fstab
}
FSTAB_LINE="" NEEDS=""
if [ "$TGT" = / ]; then
  LIB="$HERE"; WHERE="on the Pi's own disk"
elif [ "$TGT" != "$MNT" ] && in_fstab_elsewhere; then
  LIB="$HERE"; WHERE="on a drive this Pi already mounts at start-up ($TGT)"
  case "$TGT" in *" "*) ;; *) NEEDS="$TGT";; esac
else
  UUID="$(blkid -s UUID -o value "$SRC" 2>/dev/null)"
  BTYPE="$(blkid -s TYPE -o value "$SRC" 2>/dev/null)"
  [ -n "$UUID" ] || die "Couldn't identify the library drive ($SRC)."
  OWN="uid=$RUN_UID,gid=$RUN_GID,umask=022"
  case "$BTYPE" in
    exfat) FT=exfat; OPTS="$OWN";;
    vfat)  FT=vfat;  OPTS="$OWN";;
    ntfs)  if [ "$FST" = fuseblk ] && command -v ntfs-3g >/dev/null; then FT=ntfs-3g; else FT=ntfs3; fi; OPTS="$OWN";;
    ext2|ext3|ext4|btrfs|xfs|f2fs) FT="$BTYPE"; OPTS="defaults";;
    *) die "The library drive's format (${BTYPE:-unknown}) can't be mounted at start-up. exFAT, NTFS and ext4 work.";;
  esac
  FSTAB_LINE="UUID=$UUID $MNT $FT $OPTS,nofail,noatime,x-systemd.device-timeout=30s 0 0"
  LIB="$MNT${HERE#"$TGT"}"; WHERE="on the USB drive (it will be mounted at $MNT)"; NEEDS="$MNT"
fi

# ---------------------------------------------------------------- questions
newpass(){ local a=abcdefghjkmnpqrstuvwxyz23456789 p="" i n
  for i in 1 2 3 4 5 6 7 8 9 10 11 12; do
    n=$(od -An -N2 -tu2 /dev/urandom | tr -d ' '); p+="${a:$((n % ${#a})):1}"
    case $i in 4|8) p+="-";; esac
  done; printf '%s' "$p"; }
WIFI_NAME="${OPT_NAME:-${WIFI_NAME:-Emergency-Library}}"
WIFI_PASS="${OPT_PASS:-${WIFI_PASS:-$(newpass)}}"

cat <<EOF

================================================================
  LIBRARY BOX SETUP - one time only
================================================================
After this, the Pi needs no screen, keyboard or internet. Every time it
gets power it will:
  - make its own Wi-Fi network for phones to join
  - start the library and the AI, shared with every phone on that Wi-Fi
It also switches off the desktop (more memory for the AI; one press of
the power button then shuts the Pi down safely) - unless you use a
touchscreen on the Pi: then the library opens on that screen instead.

The library is $WHERE.
Undo it all any time:  bash SETUP-Raspberry-Pi.sh --undo
EOF
echo
yes_no "Go ahead?" y || { echo "Nothing was changed."; pause; exit 0; }
echo

while :; do
  ask "Name for the Pi's Wi-Fi (letters, numbers, - and _)" "$WIFI_NAME"
  if printf '%s' "$REPLY" | grep -Eq '^[A-Za-z0-9_-]{1,32}$'; then WIFI_NAME="$REPLY"; break; fi
  echo "  Use 1 to 32 letters, numbers, - or _ (no spaces)."; [ $YES = 1 ] && die "Bad Wi-Fi name: $REPLY"
done
while :; do
  ask "Wi-Fi password (8 or more characters)" "$WIFI_PASS"
  if printf '%s' "$REPLY" | grep -Eq '^[A-Za-z0-9_.,!@#%+=:-]{8,63}$'; then WIFI_PASS="$REPLY"; break; fi
  echo "  Use 8 to 63 letters, numbers or simple symbols (no spaces)."; [ $YES = 1 ] && die "Bad Wi-Fi password."
done

# Pi 5 on a power bank: it holds the USB ports to low power, and some library drives then won't start
BATT=n
if [ $IS_PI5 = 1 ] && [ -n "$BOOTCFG" ]; then
  if [ -n "$OPT_BATT" ]; then BATT="$OPT_BATT"
  else
    echo
    echo "On a power bank or battery, a Pi 5 gives its USB ports only a little power, and some"
    echo "library drives then won't start. Answer y to let the drive have full power."
    yes_no "Will this Pi ever run on a power bank or battery?" y && BATT=y
  fi
fi

# a touchscreen on the Pi (a 7-inch screen in a case, say): keep the desktop and open the library on it
HAS_DSI=0
for f in /sys/class/drm/card*-DSI-*/status; do [ -r "$f" ] && [ "$(cat "$f")" = connected ] && HAS_DSI=1; done
if [ -n "$OPT_SCREEN" ]; then SCREEN="$OPT_SCREEN"
else
  DEF="${SCREEN:-n}"; [ $HAS_DSI = 1 ] && DEF=y
  if [ "$YES" = 1 ]; then SCREEN="$DEF"
  else
    echo
    echo "A touchscreen on the Pi (for example a 7-inch screen in a case) can show the library"
    echo "by itself, with no phone. Phones can still join the Pi's Wi-Fi at the same time."
    [ $HAS_DSI = 1 ] && echo "(A screen is plugged into this Pi's display connector.)"
    SCREEN=n; yes_no "Use a touchscreen on this Pi for the library?" "$DEF" && SCREEN=y
  fi
fi

# the Wi-Fi country must be set or the Pi's Wi-Fi stays switched off
CUR_COUNTRY=""
command -v raspi-config >/dev/null && CUR_COUNTRY="$(raspi-config nonint get_wifi_country 2>/dev/null)"
WIFI_COUNTRY="${OPT_COUNTRY:-${CUR_COUNTRY:-${WIFI_COUNTRY:-US}}}"
WIFI_COUNTRY="$(printf '%s' "$WIFI_COUNTRY" | tr '[:lower:]' '[:upper:]')"
printf '%s' "$WIFI_COUNTRY" | grep -Eq '^[A-Z]{2}$' || die "Country must be a 2-letter code like US."

# ---------------------------------------------------------------- do it
echo
echo "Setting up..."
if command -v raspi-config >/dev/null && [ "$CUR_COUNTRY" != "$WIFI_COUNTRY" ]; then
  raspi-config nonint do_wifi_country "$WIFI_COUNTRY" >/dev/null 2>&1 && echo " - Wi-Fi country: $WIFI_COUNTRY"
fi
rfkill unblock wifi >/dev/null 2>&1

# 1. the Pi's own Wi-Fi (comes up at every start; it wins over any saved home Wi-Fi)
nmcli connection delete "$CON" >/dev/null 2>&1
nmcli connection add type wifi ifname "$WIFI_DEV" con-name "$CON" ssid "$WIFI_NAME" \
  connection.autoconnect yes connection.autoconnect-priority 100 connection.autoconnect-retries 0 \
  802-11-wireless.mode ap 802-11-wireless.band bg 802-11-wireless.channel 6 \
  ipv4.method shared ipv4.addresses "$ADDR/24" ipv6.method disabled \
  wifi-sec.key-mgmt wpa-psk wifi-sec.proto rsn wifi-sec.pairwise ccmp wifi-sec.group ccmp \
  wifi-sec.pmf disable wifi-sec.psk "$WIFI_PASS" >/dev/null \
  || die "Couldn't create the Pi's Wi-Fi network (nmcli failed)."
echo " - Wi-Fi network \"$WIFI_NAME\" (the Pi will be at $ADDR)"

# 2. mount the library drive at the same place every start
if [ -n "$FSTAB_LINE" ]; then
  [ -f /etc/fstab.before-emergency-library ] || cp -p /etc/fstab /etc/fstab.before-emergency-library
  tmp="$(mktemp)"
  { fstab_without_ours; printf '%s\n%s\n' "$TAG" "$FSTAB_LINE"; } > "$tmp"
  if findmnt --verify --tab-file "$tmp" 2>&1 | grep -Eq '(^|[^0-9])[1-9][0-9]* parse error'; then
    rm -f "$tmp"; die "The start-up drive line didn't check out; /etc/fstab was not changed."
  fi
  cat "$tmp" > /etc/fstab; rm -f "$tmp"
  mkdir -p "$MNT"
  echo " - the library drive will be at $MNT"
fi

# 3. start the library by itself, shared with phones
q(){ printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/%/%%/g' -e 's/\$/$$/g'; }
{
  echo "[Unit]"
  echo "Description=Offline Emergency Library, shared with phones over the Pi's own Wi-Fi"
  echo "After=network.target NetworkManager.service"
  [ -n "$NEEDS" ] && echo "RequiresMountsFor=$NEEDS"
  echo
  echo "[Service]"
  echo "User=$RUN_USER"
  echo "Group=$RUN_GROUP"
  echo "ExecStart=/bin/bash \"$(q "$LIB/START-Linux.sh")\" -nobrowser -share"
  echo "Restart=always"
  echo "RestartSec=15"
  echo
  echo "[Install]"
  echo "WantedBy=multi-user.target"
} > "$UNIT"
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1 || die "Couldn't set the library to start by itself."
echo " - the library starts by itself, shared with phones"

# 4. no desktop: more memory for the AI, and the power button shuts down with one press.
#    With a touchscreen: the desktop stays, and the library opens on the screen by itself.
CUR_TARGET="$(systemctl get-default)"
if [ "$SCREEN" = y ]; then
  if [ "$CUR_TARGET" != graphical.target ]; then
    systemctl set-default graphical.target >/dev/null 2>&1 && echo " - desktop on (for the touchscreen)"
  fi
  command -v raspi-config >/dev/null && raspi-config nonint do_boot_behaviour B4 >/dev/null 2>&1 \
    && echo " - the desktop starts by itself, with no password to type"
  cat > "$SCREEN_BIN" <<'EOS'
#!/bin/bash
# Opens the library on the Pi's own touchscreen when the desktop starts, with the page's own
# on-screen keyboard (?touch=1). Put here by SETUP-Raspberry-Pi.sh; its --undo removes it.
PORT=__PORT__
URL="http://127.0.0.1:$PORT/?touch=1"
# wait for the library to start (up to 5 minutes: the first start after setup is the slowest)
for _ in $(seq 1 150); do (exec 3<>"/dev/tcp/127.0.0.1/$PORT") 2>/dev/null && break; sleep 2; done
# after a power cut the browser offers to "restore pages": tell it the last run ended normally
P="$HOME/.config/chromium/Default/Preferences"
[ -f "$P" ] && sed -i -e 's/"exited_cleanly":false/"exited_cleanly":true/' -e 's/"exit_type":"[^"]*"/"exit_type":"Normal"/' "$P"
B="$(command -v chromium || command -v chromium-browser)"
[ -n "$B" ] || exec xdg-open "$URL"
exec "$B" --start-maximized --no-first-run --noerrdialogs --password-store=basic --disable-features=Translate "$URL"
EOS
  sed -i "s/__PORT__/$LOCAL_PORT/" "$SCREEN_BIN"
  chmod 755 "$SCREEN_BIN"
  install -d -o "$RUN_USER" -g "$RUN_GROUP" "$RUN_HOME/.config" "$RUN_HOME/.config/autostart"
  printf '%s\n' '[Desktop Entry]' 'Type=Application' 'Name=Emergency Library on this screen' \
    "Exec=$SCREEN_BIN" 'X-GNOME-Autostart-enabled=true' > "$SCREEN_AUTO"
  chown "$RUN_USER:$RUN_GROUP" "$SCREEN_AUTO"
  echo " - the library opens on the touchscreen by itself"
else
  if [ "$CUR_TARGET" != multi-user.target ]; then
    [ -n "$OLD_TARGET" ] || OLD_TARGET="$CUR_TARGET"
    systemctl set-default multi-user.target >/dev/null 2>&1 && echo " - desktop switched off"
  fi
  rm -f "$SCREEN_BIN" "$SCREEN_AUTO"
fi
save_conf

# 5. Pi 5 on a power bank: full power for the library drive
if [ $IS_PI5 = 1 ] && [ -n "$BOOTCFG" ]; then
  if [ "$BATT" = y ]; then set_usb_power 1; echo " - full USB power for the library drive (for power banks)"
  else set_usb_power 0; fi
fi

# 6. Pi 4 and older: a push button across pins 5 and 6 becomes a power button (shut down / start)
BUTTON=0
if [ $IS_OLDPI = 1 ] && [ -n "$BOOTCFG" ]; then
  if grep -Eq '^[[:space:]]*dtparam=i2c_arm=on' "$BOOTCFG"; then
    echo " - power button skipped: pins 5 and 6 are in use (I2C is turned on)"
  elif bootcfg_strip "$BTNTAG" | grep -Eq '^[[:space:]]*dtoverlay=gpio-shutdown'; then
    BUTTON=2; echo " - a power button is already set up on this Pi"
  else
    set_button 1; BUTTON=1; echo " - power button ready: wire a push button across pins 5 and 6"
  fi
fi

# 7. a card to print and keep in the lid
URL="http://$ADDR:$PORT"
if [ $IS_PI5 = 1 ]; then
  OFF="press the Pi's power button <b>once</b>. Wait until the light turns red, then unplug. (To start it again, press the button or plug it back in.)"
  OFF_TXT="press its power button once, wait for the red light, then unplug"
elif [ $BUTTON = 2 ]; then
  OFF="press the Pi's power button <b>once</b>. Wait until the green light stays off, about 20 seconds, then unplug."
  OFF_TXT="press its power button once, wait until the green light stays off, then unplug"
elif [ $BUTTON = 1 ]; then
  OFF="press the power button (the one on the pins) <b>once</b>. Wait until the green light stays off, about 20 seconds, then unplug. (To start it again, press the button or plug it back in.) No button? Unplug it when nobody is asking the AI anything."
  OFF_TXT="press the button on pins 5 and 6 once, wait until the green light stays off, then unplug"
else
  OFF="this Pi has no power button: unplug it when nobody is asking the AI anything."
  OFF_TXT="unplug it when nobody is asking the AI anything (no power button)"
fi
SCREEN_LI=""
if [ "$SCREEN" = y ]; then   # the desktop is on: the power button may ask first, and the screen has a Shutdown menu
  OFF="on the touchscreen, tap the <b>raspberry menu</b> (top left) &rarr; <b>Shutdown</b> &rarr; <b>Shutdown</b>. (Or press the power button; if the screen asks, tap Shutdown.) Wait until the green light stays off, then unplug."
  OFF_TXT="on the touchscreen tap the raspberry menu > Shutdown, wait until the green light stays off, then unplug"
  SCREEN_LI="<li><b>Or use the touchscreen:</b> the library opens on it by itself. Tap the question box and type on the keyboard that appears; tap <b>&#9166; Go</b> to ask.</li>"
fi
CARD="$HERE/PI-WIFI-CARD.html"
cat > "$CARD" <<EOF
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Library box - Wi-Fi card</title>
<style>body{font:17px/1.5 Arial,Helvetica,sans-serif;color:#111;background:#fff;margin:0}.card{max-width:640px;margin:20px auto;border:3px solid #111;border-radius:14px;padding:18px 24px}
h1{font-size:24px;margin:0 0 10px}table{border-collapse:collapse;width:100%;margin:8px 0 14px}td{border:1px solid #999;padding:8px 10px;font-size:20px}
td:first-child{width:34%;font-size:16px;color:#333}b.big{font:bold 22px "Courier New",monospace;letter-spacing:.5px;overflow-wrap:anywhere}ol{padding-left:22px;margin:6px 0}li{margin:4px 0}
.small{font-size:14px;color:#333}@media print{.card{margin:0 auto}.noprint{display:none}}</style></head><body><div class="card">
<h1>&#128218; Library box</h1>
<table><tr><td>Wi-Fi name</td><td><b class="big">$WIFI_NAME</b></td></tr>
<tr><td>Wi-Fi password</td><td><b class="big">$WIFI_PASS</b></td></tr>
<tr><td>Then open</td><td><b class="big">$URL</b></td></tr></table>
<ol>
<li><b>Plug in the power.</b> Wait 2&ndash;3 minutes (longer the first time).</li>
<li>On a phone, open <b>Settings &rarr; Wi-Fi</b> and join <b>$WIFI_NAME</b> with the password above.
If it says <i>no internet</i>, tap <b>Stay connected</b> or <b>Keep</b>.</li>
<li>Open the phone's web browser and type <b>$URL</b> exactly.</li>
$SCREEN_LI
<li><b>To turn it off:</b> $OFF</li>
</ol>
<p class="small">Page won't open? Turn on airplane mode, then turn Wi-Fi back on (phones sometimes use mobile data instead).
Still nothing? Wait a minute and try again. The AI answers one person at a time.<br>
Keep this card in the lid. Anyone with the password can read the library, so keep it in the family.</p>
<p class="noprint small">Print this page, or copy it out by hand.</p>
</div></body></html>
EOF
chown "$RUN_USER:$RUN_GROUP" "$CARD" 2>/dev/null

cat <<EOF

================================================================
  DONE. After the restart, the Pi needs no screen (or keyboard).
================================================================
  Wi-Fi name:      $WIFI_NAME
  Wi-Fi password:  $WIFI_PASS
  Then open:       $URL

  WRITE THESE DOWN. They're also on PI-WIFI-CARD.html at the top of
  the drive - print it and keep it in the lid.
  To turn the Pi off: $OFF_TXT.
  Need home Wi-Fi again (for updates)?  plug in a network cable, or
  run:  bash SETUP-Raspberry-Pi.sh --undo
EOF
[ "$SCREEN" = y ] && echo "  The library opens on the touchscreen by itself after the restart."
restart_prompt
