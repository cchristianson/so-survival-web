# ⚡ EMP, Solar Storms & Faraday Cages

What a nuclear electromagnetic pulse (EMP) or a severe solar storm would really do, how to protect
radios, solar gear and this library, how to build and test a Faraday container, what to do when a
solar-storm warning comes, and how to check and repair equipment afterward. It's based on what
**government tests actually measured**, not internet stories. The reports are in `EMP-Solar-Storms\`
(`Effects-and-Threat`, `Protection-Shielding`, `Grounding-Surge`, `Recovery`).

> ### The short version
> - **The danger comes in through long wires** — power lines, antennas, long cables. Small gear
>   that isn't plugged into anything mostly survives.
> - **Unplugged, switched-off cars and trucks were not affected in tests;** a few running ones
>   stalled and restarted.
> - **A solar storm threatens the power grid, not your phone.** You'd likely get 18–72 hours' warning.
> - **The real long-term problem is the grid going down for months.** Plan for that (see the
>   off-grid power section of the [Illinois Valley guide](guide:ILLINOIS-VALLEY-START-HERE)).
> - **Keep spares and a second copy of this library in a metal container**, sealed at the seams.

---

## ⚡ Two different threats

| | **Nuclear EMP** (a bomb exploded high above the U.S.) | **Solar storm** (geomagnetic storm, like 1859, 1921, 1989, May 2024) |
|---|---|---|
| Warning | None | **18–72 hours** after the Sun erupts; 20–45 min final warning ([CISA, p. 21](lib:emp-protection-and-resilience-guidelines#page=21)) |
| Parts | **E1:** a pulse rising in billionths of a second — hits electronics through wires and antennas. **E2:** like lightning over a huge area. **E3:** slow, seconds to minutes — like a solar storm ([EMP Commission 2004, p. 13](lib:emp-commission-executive-report#page=13); [🖼️ the three parts drawn](lib:meta-r-320#page=12)) | Like a weak, hours-long E3 only — **no fast pulse** ([Geomagnetically induced current](wiki:Geomagnetically_induced_current)) |
| What it hits | Electronics connected to wires/antennas; computers and control systems; the power grid | **Very long conductors**: power lines, big transformers, pipelines, long phone cables. Also **GPS and HF radio** |
| What it doesn't | People (a high-altitude burst puts **no radiation on the ground**) | Unplugged phones, laptops, radios, cars, solar panels |

**Why only long wires matter in a solar storm:** the storm induces a few volts **per kilometer** — measured
worst cases are about 7–20 V/km, and under 1.1 V/km in Colorado during the May 2024 storm
([Meta-R-319](lib:meta-r-319-geomagnetic-storms); [LANL 2024 storm study](lib:mothers-day-superstorm)).
A 6-ft cord sees hundredths of a volt; a 100-mile power line sees hundreds to thousands
*(rule of thumb arithmetic)*. In 1989 that was enough to collapse Quebec's grid in 90 seconds and destroy a
large transformer in New Jersey — and big transformers take about a year to replace
([Meta-R-319, p. 149](lib:meta-r-319-geomagnetic-storms#page=149);
[🖼️ photo of transformer damage from the 1989 storm](lib:emp-commission-critical-national-infrastructures#page=47);
[🖼️ map of how far the 1989 storm reached](lib:emp-commission-executive-report#page=25);
[March 1989 geomagnetic storm](wiki:March_1989_geomagnetic_storm), [Transformer](wiki:Transformer)).

**E1 isn't the same strength everywhere:** it's strongest south of the point under the burst, and averages
only about a tenth of the peak over the affected area ([Meta-R-320, p. 38](lib:meta-r-320#page=38);
[🖼️ the "smile" map of E1 strength](lib:meta-r-320#page=14);
[🖼️ how one high burst covers a continent](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=321)).
The 1962 test that showed it: [🖼️ Starfish photo](lib:emp-commission-executive-report#page=13), [Starfish Prime](wiki:Starfish_Prime).

📚 **Go deeper:** [EMP Commission Executive Report](lib:emp-commission-executive-report) — the plain overview; [NOAA *A Profile of Space Weather*](lib:a-profile-of-space-weather); [Wikipedia: nuclear EMP](wiki:Nuclear_electromagnetic_pulse) · [geomagnetic storm](wiki:Geomagnetic_storm) · [Carrington Event](wiki:Carrington_Event).

## 🔬 What the tests actually found

| Claim | What testing showed |
|---|---|
| "Every car will die." | **37 cars and 18 trucks** were tested up to about 50 kV/m. **Vehicles that were off: no effects.** Of running cars, 3 stalled (at 30 kV/m or more) and needed a restart; one had dashboard electronics damaged; most just had blinking lights. Of running trucks, 3 stalled — 2 restarted at once, 1 needed towing ([EMP Commission 2008, p. 131](lib:emp-commission-critical-national-infrastructures#page=131)). |
| "All electronics fry." | Handheld and vehicle radios — stored, idle or operating — had **no damage up to 50 kV/m**; some locked up and worked after switching off and on ([EMP Commission 2008, p. 169](lib:emp-commission-critical-national-infrastructures#page=169)). Plugged-in household gear: at 6.7 kV/m 20% were upset (fixed by power-cycling); at 16.6 kV/m about 6% were damaged — **mostly items on antenna cables** ([Harry Diamond Labs, p. 44](lib:consumer-electronics-testing#page=44)). |
| "Pocket radios are useless after." | Small battery radios weren't damaged unless near cables carrying huge currents ([DCPA 1975](lib:electromagnetic-pulse-and-civil-preparedness)). |
| "Solar panels get destroyed." | Panels hit with **up to 100 kV/m** showed only very minor change ([Sandia, p. 39](lib:hemp-testing-of-photovoltaic-modules#page=39); [🖼️ panels in the test chamber](lib:hemp-testing-of-photovoltaic-modules#page=17)); rooftop microinverters survived 20–60 kV pulses ([Sandia microinverter tests](lib:residential-solar-microinverters)). **The surge travels down the panel wires toward the charge controller/inverter — that's the part to keep a spare of.** |
| "A surge strip or the breaker protects me." | Lightning-rated surge suppressors **don't stop E1** ([Sandia TVSS tests](lib:transient-voltage-surge-suppressors); [🖼️ the suppressor tested](lib:transient-voltage-surge-suppressors#page=16)); circuit breakers survive but give **no real protection — some pulse passes even when they're off** ([Sandia, p. 6](lib:ul489-circuit-breakers#page=6); [🖼️ the breakers tested](lib:ul489-circuit-breakers#page=12)). |
| "Ham radios are toast." | 15 ham stations survived repeated simulated pulses **when the power cord was unplugged and the coax disconnected**; with protectors on both lines they were also fine ([NCS TIB 85-10](lib:transient-protection-devices-for-amateur); [🖼️ the power and antenna protectors](lib:transient-protection-devices-for-amateur#page=181)). |
| "Networked computers will be fine." | They're the weak point — dispatch computers began failing at 3–6 kV/m, and every industrial control system tested failed ([EMP Commission 2008](lib:emp-commission-critical-national-infrastructures)). |

How the tests were done: [🖼️ the outdoor pulse simulator used on household gear](lib:consumer-electronics-testing#page=10);
[🖼️ an EMP simulator with test buildings](lib:emp-commission-critical-national-infrastructures#page=19).

📚 **Go deeper:** [EMP Commission Critical Infrastructures Report — vehicles, p. 131](lib:emp-commission-critical-national-infrastructures#page=131); [Consumer Electronics Testing](lib:consumer-electronics-testing).

## 🔌 Rule one: unplug and disconnect

**Wires are the antennas.** Even a few feet of cable can pick up thousands of volts from E1; long power and
antenna lines pick up far more ([Low Cost EMP Protection (Navy 1982)](lib:low-cost-emp-protection)).
([CISA guidelines, p. 44](lib:emp-protection-and-resilience-guidelines#page=44);
[🖼️ drawing: E1 reaches a radio the way a broadcast or lightning does](lib:meta-r-320#page=16))

- **Unplug at the device** — power, data and antenna cables — not just at the wall. Coil any cable you
  can't remove.
- **Pull battery packs** from small electronics in storage; turn phones and radios off and take them off
  chargers.
- **Disconnect outdoor antennas and coax** ([Coaxial cable](wiki:Coaxial_cable)) from radios when not in use.
- **Unplug everything or nothing:** pulling only a TV's power cord while it stays on cable or phone lines
  removes its ground path ([NIST *Surges Happen*, p. 11](lib:surges-happen#page=11);
  [🖼️ NIST drawing of a surge crossing between two connections](lib:surges-happen#page=20)).
- **Backup generators:** don't leave one connected to the grid through an automatic transfer switch without
  strong surge protection — the utility line can carry the pulse in
  ([CISA, p. 45](lib:emp-protection-and-resilience-guidelines#page=45); [Transfer switch](wiki:Transfer_switch)). A generator stored disconnected
  is far better off.
- Surge protectors still help with lightning and the surge when power comes back — just don't count on them
  for E1. Keep **spare** protectors and fuses ([Surge protector](wiki:Surge_protector)).

📚 **Go deeper:** [CISA *EMP Protection and Resilience Guidelines* — Level 1 steps, p. 44](lib:emp-protection-and-resilience-guidelines#page=44); [NIST *Surges Happen*](lib:surges-happen); [MIL-HDBK-419A Vol 2 — grounding and surge arresters](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2).

## 🗑️ Faraday containers: building one that works

**How it works:** a closed metal shell keeps the pulse on the outside. It only works if the shell is
**continuous** — the leaks are at **seams, lid edges and holes**, and a long narrow slot leaks far more
than a round hole. **Seams must be bare metal touching bare metal** (no paint)
([MIL-HDBK-419A Vol 1, p. 275](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275);
[🖼️ how fields leak through an opening](lib:meta-r-320#page=51);
[🖼️ a badly joined seam, warped between rivets](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=212);
[Electromagnetic shielding](wiki:Electromagnetic_shielding)).
**A plain metal box is not automatically a Faraday cage** — ordinary cabinets gave little protection
until their seams were taped and gasketed ([Navy 1982](lib:low-cost-emp-protection)).

**Options, best to simplest** ([CISA, pp. 45, 86](lib:emp-protection-and-resilience-guidelines#page=45)):

1. **Metal can with a tight metal lid** (galvanized trash can, paint can, cookie tin, steel ammo can —
   [Waste container](wiki:Waste_container), [Ammunition box](wiki:Ammunition_box)):
   - Wrap each item in a **plastic or paper bag or cardboard** so it doesn't touch the metal.
   - **Seal the lid seam with conductive tape** (aluminum or copper foil tape — the kind with conductive
     glue) all the way around. Trash cans leak at the **lid, handles and base** unless sealed.
   - **Ammo cans:** the rubber gasket breaks metal contact — scrape a strip of bare metal at the rim and add
     conductive tape over the closed lid seam *(rule of thumb)*.
   - **No wires passing through.** Don't drill holes
     ([🖼️ right and wrong ways through a shield](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)).
2. **Foil wrap:** item in a plastic bag, then **2 or more layers of heavy-duty foil**, every seam folded
   and overlapped, any cables inside the wrap ([Aluminium foil](wiki:Aluminium_foil); folded-over joint:
   [🖼️ overlap seam](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=187)).
3. **Nesting adds protection:** a foil-wrapped item inside a sealed metal can is better than either alone.
4. **Microwave oven** (unplugged, never switched on; [Microwave oven](wiki:Microwave_oven)): an expedient shield for small items — test it first.

**Weak or useless:** Mylar food bags (little protection); refrigerators (plastic liner and rubber gasket);
many cheap "Faraday bags" (the closure leaks).

**Does it need a ground wire?** No — a closed storage container doesn't need to be grounded
*(rule of thumb)*.

**How good is good enough?** For stored spare electronics, CISA considers **20 dB** of shielding adequate
([CISA appendix, p. 126](lib:emp-protection-and-resilience-guidelines#page=126)); critical military gear uses
80 dB ([DHS 2022](lib:emp-shielding-mitigations-best-practices)). See the difference:
[🖼️ modeled damage with 0, 10, 20 and 30 dB of protection](lib:emp-protection-and-resilience-guidelines#page=77);
what "dB" means: [Decibel](wiki:Decibel).

**Testing yours (and what it doesn't prove):**
- Put a **phone** inside and call it, and a **battery AM/FM radio** tuned to a station. If the call won't ring
  and the radio goes silent, the shell has no big leaks at those frequencies.
- This is a **rough check, not a measurement** — silence just means the signal dropped below what the radio
  can hear. The **AM test matters most** (low frequencies are hardest to block). Close the lid the same way
  every time ([CISA, p. 45](lib:emp-protection-and-resilience-guidelines#page=45)).

📚 **Go deeper:** [CISA guidelines — foil and container methods, pp. 45 & 86](lib:emp-protection-and-resilience-guidelines#page=45); [MIL-HDBK-419A Vol 1 — seams and slots, p. 275](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275); [Wikipedia: Faraday cage](wiki:Faraday_cage).

## 📦 What to keep in it

From CISA's list plus practical extras *(rule of thumb where not cited)*:
- **A second copy of this library** on a USB drive or small SSD — and a cheap laptop or tablet with its
  charger to read it. Or build the [Ammo-Can Library Computer](guide:AMMO-CAN-COMPUTER-GUIDE): a Raspberry
  Pi that lives in a sealed can and shares the library and AI to phones when you open it.
- **Battery AM/FM/NOAA weather radio**, and a handheld ham or GMRS radio with a spare antenna
  ([CISA, p. 44](lib:emp-protection-and-resilience-guidelines#page=44)).
- **Spare solar charge controller and a small inverter** — the parts of a solar system most at risk
  ([Charge controller](wiki:Charge_controller), [Power inverter](wiki:Power_inverter)).
- **Multimeter** ([Multimeter](wiki:Multimeter)), LED flashlights/headlamps, rechargeable batteries and a small USB solar charger.
- **Spare fuses** (vehicle, equipment, solar), spare surge protectors and MOVs
  ([Fuse](wiki:Fuse_(electrical)), [Varistor](wiki:Varistor)).
- Small spare electronics you depend on (a phone, a radio's spare power supply).
- For older vehicles, a spare ignition module or electronic part if you can get one.

Handheld gear with no long wires attached is fairly tough anyway; the container is cheap insurance
([CISA, p. 45](lib:emp-protection-and-resilience-guidelines#page=45)).

📚 **Go deeper:** [ORNL — radio communications and spare-equipment procedures](lib:effects-of-emp-on-state-and-local-radio-communications); [CISA — Level 1 steps for small equipment, p. 44](lib:emp-protection-and-resilience-guidelines#page=44); [Radio guide](guide:RADIO-GUIDE).

## ☀️ When a solar-storm warning comes

Pictures of where a storm starts: [🖼️ the May 2024 sunspot group](lib:mothers-day-superstorm#page=11);
[🖼️ computer model of its eruptions heading for Earth](lib:mothers-day-superstorm#page=12);
[Coronal mass ejection](wiki:Coronal_mass_ejection), [Sunspot](wiki:Sunspot).
NOAA rates geomagnetic storms **G1 to G5** ([NOAA Space Weather Scales](lib:noaa-space-weather-scales#page=1)):

| Level | How often (per 11-year cycle) | What happens |
|---|---|---|
| G3 strong | ~200 | Grid voltage corrections; GPS and HF radio come and go; auroras as far south as Oregon ([Aurora](wiki:Aurora)) |
| G4 severe | ~100 | Widespread grid voltage problems; some protection systems trip; GPS degraded for hours |
| G5 extreme | ~4 | **Grid collapse and transformer damage possible**; HF radio out 1–2 days; GPS degraded for days |

**For a G4–G5 warning** *(rule of thumb)*:
1. **Charge** batteries, power banks, radios and laptops; **fill water containers**; get fuel.
2. **Unplug sensitive electronics** from the wall — the risk is outages and surges when power returns.
3. **Disconnect long outdoor antennas and feedlines.**
4. Expect **GPS and HF radio** to be unreliable; have paper maps (`Maps\`) and use VHF/UHF locally.
5. **Solar panels don't need protecting** from a solar storm — their wiring is far too short. (S5 "solar
   panel damage" on NOAA's scale means *satellites*.)
6. Have the generator ready, connected only through a transfer switch or interlock — **never backfeed**.

📚 **Go deeper:** [NOAA scales, p. 1](lib:noaa-space-weather-scales#page=1); [LANL May 2024 storm study](lib:mothers-day-superstorm); [Wikipedia: May 2024 solar storms](wiki:May_2024_solar_storms).

## 🔧 After an event: check and repair

1. **Power-cycle** anything that's locked up — in tests most "upsets" cleared this way
   ([Harry Diamond Labs, p. 44](lib:consumer-electronics-testing#page=44)).
2. **Vehicles:** restart. If one won't run, **disconnect the battery for several minutes** to reset the
   electronics, then check fuses ([EMP Commission 2008, p. 131](lib:emp-commission-critical-national-infrastructures#page=131)).
3. **Fuses and breakers** ([Circuit breaker](wiki:Circuit_breaker)): a surge protector firing can blow the equipment's fuse — check and replace.
   Breakers are likely fine; reset them ([ORNL radio study](lib:effects-of-emp-on-state-and-local-radio-communications);
   [Sandia breakers](lib:ul489-circuit-breakers)).
4. **Surge protectors** fail one of two ways: no power, or power with no protection left. Replace any that
   took a hit ([NIST *Surges Happen*, p. 7](lib:surges-happen#page=7)).
5. **Look and sniff:** burnt smell, scorch marks, swollen or leaking capacitors. **Discharge big capacitors
   before touching** (inverters, microwaves, power supplies). What to look for:
   [🖼️ scorch marks where a capacitor blew off a board](lib:meta-r-320#page=111);
   [🖼️ a resistor exploding under a test pulse](lib:meta-r-320#page=110);
   swollen capacitors: [Capacitor plague](wiki:Capacitor_plague).
6. **Radios:** if dead, suspect the **antenna input stage and power supply** first — those took the damage
   in tests ([ORNL radio study](lib:effects-of-emp-on-state-and-local-radio-communications)).
7. **Solar:** panels are probably fine; test the charge controller and inverter; **swap in shielded spares**.
8. **Generators:** check the output breaker, brushes and voltage regulator — see the
   [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE).
9. **Expect the grid to stay down a long time** — the EMP Commission expected **months to years** for
   recovery ([Executive Report, p. 27](lib:emp-commission-executive-report#page=27)). Switch to off-grid power,
   radios and the rest of this library.

**Repair skills** — finding and replacing burned parts, using a multimeter, soldering, salvaging parts — are in
the electronics section of the [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) and the Navy NEETS
modules in `Off-Grid-Power\Electrical-Basics`.

📚 **Go deeper:** [ORNL *HEMP Emergency Planning for Electric Power Systems*](lib:hemp-emergency-planning-and-operating-procedures) — why grid recovery is slow; [EMP Commission 2008](lib:emp-commission-critical-national-infrastructures).

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**The two threats**
- The E1, E2 and E3 parts of a nuclear pulse — [🖼️ Meta-R-320, p. 12](lib:meta-r-320#page=12); [Nuclear electromagnetic pulse](wiki:Nuclear_electromagnetic_pulse)
- The 1962 Starfish test — [🖼️ EMP Commission 2004, p. 13](lib:emp-commission-executive-report#page=13); [Starfish Prime](wiki:Starfish_Prime)
- Where E1 is strongest (the "smile" map) — [🖼️ Meta-R-320, p. 14](lib:meta-r-320#page=14); [🖼️ MIL-HDBK-419A Vol 1, p. 321](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=321)
- The 1989 storm: how far it reached, and a damaged transformer — [🖼️ EMP Commission 2004, p. 25](lib:emp-commission-executive-report#page=25); [🖼️ EMP Commission 2008, p. 47](lib:emp-commission-critical-national-infrastructures#page=47); [March 1989 geomagnetic storm](wiki:March_1989_geomagnetic_storm)
- Big grid transformers and long lines — [Transformer](wiki:Transformer); [Geomagnetically induced current](wiki:Geomagnetically_induced_current)

**How the tests were done**
- Outdoor pulse simulator for household gear — [🖼️ Harry Diamond Labs, p. 10](lib:consumer-electronics-testing#page=10)
- EMP simulator with test buildings — [🖼️ EMP Commission 2008, p. 19](lib:emp-commission-critical-national-infrastructures#page=19)
- Solar panels in the test chamber — [🖼️ Sandia, p. 17](lib:hemp-testing-of-photovoltaic-modules#page=17)
- The surge suppressor and breakers tested — [🖼️ Sandia TVSS, p. 16](lib:transient-voltage-surge-suppressors#page=16); [🖼️ Sandia breakers, p. 12](lib:ul489-circuit-breakers#page=12); [Surge protector](wiki:Surge_protector); [Circuit breaker](wiki:Circuit_breaker)
- Ham-radio power and antenna protectors — [🖼️ NCS TIB 85-10, p. 181](lib:transient-protection-devices-for-amateur#page=181)

**Wires, surges and unplugging**
- E1 reaches a radio like a broadcast or lightning — [🖼️ Meta-R-320, p. 16](lib:meta-r-320#page=16)
- A surge crossing between power and cable/phone lines — [🖼️ NIST *Surges Happen*, p. 20](lib:surges-happen#page=20); [🖼️ whole-house protector, p. 21](lib:surges-happen#page=21)
- Coax and transfer switches — [Coaxial cable](wiki:Coaxial_cable); [Transfer switch](wiki:Transfer_switch)

**Faraday containers**
- How fields leak through openings and slots — [🖼️ Meta-R-320, p. 51](lib:meta-r-320#page=51); [🖼️ MIL-HDBK-419A Vol 1, p. 276](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=276)
- Good and bad seams — [🖼️ MIL-HDBK-419A Vol 1, p. 212](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=212); [🖼️ Vol 2, p. 187](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=187)
- Why no wire may pass through — [🖼️ MIL-HDBK-419A Vol 2, p. 315](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315); [🖼️ Vol 1, p. 333](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=333)
- What 10, 20 and 30 dB of shielding buys — [🖼️ CISA, p. 77](lib:emp-protection-and-resilience-guidelines#page=77)
- Containers — [Faraday cage](wiki:Faraday_cage); [Electromagnetic shielding](wiki:Electromagnetic_shielding); [Ammunition box](wiki:Ammunition_box); [Aluminium foil](wiki:Aluminium_foil)

**Solar storms**
- The May 2024 sunspot group and its eruptions — [🖼️ LANL 2026, p. 11](lib:mothers-day-superstorm#page=11); [🖼️ p. 12](lib:mothers-day-superstorm#page=12); [May 2024 solar storms](wiki:May_2024_solar_storms)
- The Sun's side of it — [Sunspot](wiki:Sunspot); [Coronal mass ejection](wiki:Coronal_mass_ejection); [Geomagnetic storm](wiki:Geomagnetic_storm)
- Auroras over Oregon — [Aurora](wiki:Aurora)

**Checking gear afterward**
- Pulse damage on circuit boards — [🖼️ Meta-R-320, p. 111](lib:meta-r-320#page=111); [🖼️ p. 110](lib:meta-r-320#page=110)
- Swollen and leaking capacitors — [Capacitor plague](wiki:Capacitor_plague)
- The meter for testing — [Multimeter](wiki:Multimeter)

## 🔗 Related guides

- [Ammo-Can Library Computer](guide:AMMO-CAN-COMPUTER-GUIDE) — this library in a sealed can, shared to phones
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — electronics repair and salvage
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE)
- [Emergency Radio Guide](guide:RADIO-GUIDE)
- [Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE) — if the EMP came from a nuclear attack
- [Fuel Guide](guide:FUEL-GUIDE)
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE)
