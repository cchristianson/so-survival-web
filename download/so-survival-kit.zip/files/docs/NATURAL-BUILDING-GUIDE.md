# 🧱 Natural Building: Cob, Straw, Clay, Hemp & Lime

Building walls, plasters and floors from local earth, straw, hemp and lime that stand up to Cascadia
shaking, wet winters and fire season — plus burning your own lime and thatching sheds. The books are in
`Natural-Building\` (`Cob-Earth`, `Straw-Bale-Light-Clay`, `Hemp-Lime`, `Plasters-Lime-Floors`,
`Roofs-Thatch`, `Quake-Moisture`). The soil ribbon test, adobe, rammed earth, log chinking and quake
retrofits are in the [Shelter guide](guide:SHELTER-BUILDING-GUIDE); cordwood and earthbag how-tos are only
in the Appropedia archive in `Manuals\DIY-Appropedia`.

> ### ⚠️ Rules that prevent the worst outcomes
> - **Never build earth or straw walls where floods reach.** Cob walls collapsed outright when floodwater
>   rose up them ([DSIR 1922, p. 19](lib:special-report-5#page=19)). Our river soils flood
>   ([Soil Survey, p. 17](lib:josephine-county-oregon-1983-full-scan#page=17)).
> - **Keep the roof light and off the earth walls.** The deadliest quake failure is walls falling out and
>   the roof falling in ([Minke, p. 13](lib:minke#page=13)). One storey.
> - **Quicklime burns eyes and skin, and damp quicklime can start a fire.** Goggles and gloves; store it
>   airtight ([NBS Circular 30, p. 10](lib:lime-its-properties-and-uses#page=10)).
> - **No cement or plastic over earth or straw.** They trap water and rot the wall from inside
>   ([NPS Brief 5, p. 5](lib:preservation-brief-5#page=5); [BSD-112, p. 12](lib:bsd-112#page=12)).
> - **Loose straw is tinder.** In fire season plaster bales promptly, sweep up straw daily, and never
>   thatch a house with a stove *(rule of thumb)*.
> - **Serpentine rock can carry natural asbestos.** Never crush or sieve it dry *(rule of thumb)*.

---

## 🧭 Choosing a system for our conditions

**The key advice:** in Cascadia country, build a **braced [timber frame](wiki:Timber_framing) that carries a light roof**, and
use earth or straw only as **infill or a skin**. Keep it **one storey**. Never build on floodplain soils.

Shaking forces grow with weight, and mud-walled houses have caused the most quake deaths
([PA *EQ Housing*, p. 2](lib:earthquake-resistant-housing-practical-action#page=2)). The safest layout puts
the roof on its own posts ([Minke, p. 38](lib:minke#page=38)): if the walls fall, the roof stays up. Make
brace joints strong — a diagonal that tears loose lets the wall go ([p. 12](lib:minke#page=12)).

| System | Quake | Wet winters | Fire | Insulation | Labor | Buy or make |
|---|---|---|---|---|---|---|
| **Cob** (load-bearing) | Poor — heavy | Good if kept dry | Good | Poor | Very high | Nothing |
| **Straw bale** in a frame | Good — light | Risky on north walls | Good once plastered | Excellent | Medium | Grain-straw bales |
| **Light straw-clay** | Good — ductile | Good — dries fast | Very good | Fair | High | Straw, clay, frame |
| **Hempcrete** | Good — light | Good | Untested here | Good | High | Lime binder, hemp |
| **Wattle and daub** | Best | Fair — needs patching | Fair | Poor | Low | Poles, sticks, clay |
| **Earthbag** | Fair with ring beam | Fair once plastered | Good once plastered | Poor | High | Bags, earth |
| **Pressed blocks** | Poor without steel bands | Good if stabilised | Good | Poor | High | Block press, lime |
| **Cordwood** | Poor — heavy | Fair — log ends rot | Fair | Fair | High | Mortar |

(Ratings summarise the sections below *(rule of thumb)*.)

📚 **Go deeper:** [Minke *Earthquake-Resistant Houses*](lib:minke#page=12) — three ways to quake-proof earth walls; [PA *Earthquake Resistant Housing*](lib:earthquake-resistant-housing-practical-action#page=2) — why heavy houses kill. Pictures: [🖼️ a roof on its own posts, Minke p. 38](lib:minke#page=38), [🖼️ a fallen earth house and a quake-resistant quincha house, PA p. 1](lib:earthquake-resistant-housing-practical-action#page=1).

## 🌎 Quake rules for earth walls

**Minke's 10 mistakes that collapse earth houses** ([p. 12](lib:minke#page=12)): (1) no ring beam;
(2) [lintels](wiki:Lintel) too short; (3) too little wall between a door and a window; (4) openings too close to
corners; (5) no [plinth](wiki:Pedestal); (6) windows too wide for their height; (7) walls too thin for their height;
(8) poor mortar — part-filled joints, or joints over 15 mm (⅝ in); (9) too heavy a roof; (10) a roof
not fixed to the walls.

**Shape and size:** square beats rectangle, circle beats square; split an L-shape into separate blocks
([Minke, p. 9](lib:minke#page=9)). Walls no taller than **11.5 ft**, no unsupported wall longer than
**23 ft**, no [gables](wiki:Gable), wall tops tied together
([PA, p. 3](lib:earthquake-resistant-housing-practical-action#page=3)).

**Doors and windows** ([Minke, p. 41](lib:minke#page=41); PA, p. 3):
- Windows no wider than **4 ft**, nor more than ⅓ of the wall's length.
- Openings at least **2 ft** from corners; wall between openings at least 3¼ ft and ⅓ of its height.
- Lintels bear 40 cm (Minke) or 50 cm (PA) into the wall each side — **use 20 in**, or make the lintel
  part of the ring beam.
- Doors open **outward**, with a big window or second door opposite as an emergency exit.

**Ring beam:** a closed timber ring with stiff corners, tied down by vertical wooden rods from the
foundation up to a **double timber ring beam** ([Minke, p. 35](lib:minke#page=35); [🖼️ PA timber bond-beam drawings](lib:earthquake-resistant-housing-practical-action#page=4)). Block walls also need
vertical bars at corners, openings and every 5 ft ([CSEB manual, p. 12](lib:compressed-stabilised-earth-block#page=12)).

**Siting:** don't cut into a slope, build on one, or sit below a steep one; level a platform well back
([Minke, p. 8](lib:minke#page=8)). Avoid fill, river banks, landslide ground and slopes over 20°
([CSEB, p. 2](lib:compressed-stabilised-earth-block#page=2)).

📚 **Go deeper:** [Minke](lib:minke#page=34) — plinths, ring beams and separate roofs, drawn; [CSEB manual](lib:compressed-stabilised-earth-block#page=26) — bands and reinforcement step by step. Pictures: [🖼️ the ten mistakes drawn, Minke p. 12](lib:minke#page=12), [🖼️ good and bad openings, p. 41](lib:minke#page=41), [🖼️ where not to build, p. 8](lib:minke#page=8).

## 🎩 "A good hat and good boots": keeping walls dry

*"Giv'un a gude hat and pair of butes an' 'er'l last for ever"* — cob asks only for dry foundations and
a good roof ([Williams-Ellis, p. 46](lib:williams-ellis#page=46)).

**Boots — raise the wall off the ground:**

| Wall | Stone or masonry base above ground |
|---|---|
| Cob | About **2 ft** ([Williams-Ellis, p. 56](lib:williams-ellis#page=56)) |
| Earth walls in quake country | At least **12 in**, on a footing 8 in wider than the wall and 16 in deep ([Minke, p. 34](lib:minke#page=34)) |
| Plastered straw bales | At least **6 in**; **8–12 in** better ([BSD-112, p. 6](lib:bsd-112#page=6)) |

Don't lay a smooth damp-proof layer on the plinth — in a quake the wall slides off. Key it with
**vertical wooden rods every 12–20 in** and a rough plinth top (Minke, p. 34).

**Hat:** an overhang, a pitched roof and nearby shelter can cut the rain on a wall **tenfold**
([BSD-112, p. 5](lib:bsd-112#page=5); [🖼️ how walls get wet](lib:bsd-112#page=6)). Minimum [overhangs](wiki:Eaves): **16 in** on one storey, **24 in** on two, with
gutters ([p. 11](lib:bsd-112#page=11)); here, go wider *(rule of thumb)*. [Hip the roof](wiki:Hip_roof) rather than build
tall earth gables ([Williams-Ellis, p. 57](lib:williams-ellis#page=57)).

**Splash zone:** puddles and splash hollow out the base ("coving"); rising ground water makes walls
erode and bulge ([NPS Brief 5, p. 4](lib:preservation-brief-5#page=4)). Grade the ground away, dig a
gravel drain trench, keep shrubs off ([p. 5](lib:preservation-brief-5#page=5)).

**Let the wall breathe:**
- **Cement doesn't bond to earth.** It hangs on nails that rust, cracks, lets water in and stops the
  wall drying ([NPS Brief 5, pp. 3, 5](lib:preservation-brief-5#page=3)). A New Mexico church plastered in
  cement in 1967 had to be stripped 11 years later ([Minke, p. 49](lib:minke#page=49)).
- **No building paper or plastic behind plaster on straw** — it stops the wall drying
  ([BSD-112, p. 12](lib:bsd-112#page=12); [🖼️ how walls dry](lib:bsd-112#page=8)).

📚 **Go deeper:** [NPS Preservation Brief 5](lib:preservation-brief-5#page=4) — how water destroys earth walls; [BSD-112](lib:bsd-112#page=10) — rain control for straw walls. Pictures: [🖼️ plinth and foundation, Minke p. 34](lib:minke#page=34), [Damp proofing](wiki:Damp_proofing).

## ⛏️ Local materials: clay, sand, straw and stone

**[Clay](wiki:Clay) — the Pollard soils.** Under the loam topsoil is red subsoil about **50% clay**; the typical
profile is half a mile south of Kerby ([Soil Survey, p. 157](lib:josephine-county-oregon-1983-full-scan#page=157)).
They cover high terraces and hillsides in the Illinois River and Deer Creek valleys
([p. 18](lib:josephine-county-oregon-1983-full-scan#page=18)) and are rated "too clayey," with moderate
shrink-swell ([p. 223](lib:josephine-county-oregon-1983-full-scan#page=223)): a fat clay that needs lots
of sand. Use the ribbon test in the [Shelter guide](guide:SHELTER-BUILDING-GUIDE) and a **shrink box** —
pack damp soil in a 2-ft box; more than ¼ in of shrinkage means it will crack
([PA *Mud Plasters*, p. 4](lib:mud-plasters-and-renders#page=4)).

**Be wary of [serpentine clay](wiki:Serpentine_soil).** Brockman soils, on alluvial fans in the valley ([🖼️ photo](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=34)), formed from
[serpentinite](wiki:Serpentinite) and are "very sticky and very plastic"
([Soil Survey, p. 141](lib:josephine-county-oregon-1983-full-scan#page=141)). Expect bad cracking; make
test bricks first, and keep it damp *(rule of thumb)*.

**Sand and gravel:** the Takilma and Kerby low terraces are cobbly loam over extremely gravelly sand
([p. 18](lib:josephine-county-oregon-1983-full-scan#page=18)). Screen out stones over ¼ in (5–6 mm) for
blocks and plaster ([PA *Soil Blocks*, p. 10](lib:making-stabilised-soil-blocks#page=10)).

**[Straw](wiki:Straw), never [hay](wiki:Hay).** Building straw is the dead stalks of wheat, barley or oats
([BSD-112, p. 3](lib:bsd-112#page=3)). Hay molds *(rule of thumb)*, and leftover grain draws mice and
birds that tunnel in ([Beard, p. 80](lib:shelters-shacks-and-shanties#page=80)). Grain straw comes from
the Klamath Basin and Willamette Valley; buy tight, dry, bright bales and store them off the ground
under cover *(rule of thumb)*.

**Limestone and marble:** see the deposit table under *Making lime*.

📚 **Go deeper:** [Josephine County Soil Survey](lib:josephine-county-oregon-1983-full-scan#page=18) — maps of clay and gravel; [PA *Soil Blocks*](lib:making-stabilised-soil-blocks#page=8) — shrink and drop tests. Pictures: [🖼️ shrink-test photos: clayey vs. sandy soil, PA *Soil Blocks* p. 8](lib:making-stabilised-soil-blocks#page=8), [Serpentinite](wiki:Serpentinite).

## 🏺 Cob, step by step

Cob is mostly aggregate held by about one-fifth clay: old Devon cob tested at 24% stones, 52% sand, 21%
clay, about 1% straw ([DSIR, p. 16](lib:special-report-5#page=16)). Here, use it for **infill between
frame posts**, garden walls and small sheds — not tall load-bearing walls. [Cob](wiki:Cob_(material)); [🖼️ old Devon cob cottages](lib:special-report-5#page=25).

**Season:** Devon built March to September ([Williams-Ellis, p. 56](lib:williams-ellis#page=56)). Here,
build **May–September** and get the roof on before the October rains *(rule of thumb)*.

1. **Plinth:** stone, about 2 ft high, keyed with wooden rods (see above; [🖼️ drawing](lib:minke#page=34)).
2. **Mix:** heap the earth beside the wall and pick out big stones. Four people turn the heap with forks,
   **treading all the while**; one sprinkles water, another straw. Turn it twice
   ([p. 53](lib:williams-ellis#page=53)).
3. **Lay:** tread it onto the wall in **diagonal layers**, working the heels, overhanging the base about
   an inch for paring ([pp. 54–55](lib:williams-ellis#page=55)).
4. **Lifts:** about **2 ft**; each takes **2–3 weeks** to dry, so work several walls in turn. Pare each
   lift plumb when firm (p. 55).
5. **Thickness:** **18 in minimum**, one storey only ([p. 57](lib:williams-ellis#page=57)).
6. **Openings:** wooden lintels well tailed in (20 in each side); frames fixed to wooden blocks built into
   the cob ([p. 61](lib:williams-ellis#page=61)).
7. **Corners** crack, so round them ([DSIR, p. 16](lib:special-report-5#page=16)).
8. **Top:** a closed timber ring beam ([🖼️ drawing](lib:minke#page=35)), then a light hipped roof with good eaves.
9. **Dry:** don't render the outside for **one to two years**; protect it from frost and rain meanwhile
   ([Williams-Ellis, p. 56](lib:williams-ellis#page=56)).

**Labor:** eight mostly green men took three months to raise one cottage's walls
([p. 49](lib:williams-ellis#page=49)).

📚 **Go deeper:** [Williams-Ellis *Cottage Building in Cob*](lib:williams-ellis#page=50) — mixing, lifts, finishing; [DSIR *Building in Cob and Pisé*](lib:special-report-5#page=14) — regional methods and why cob fails. Pictures: [🖼️ cob walls ready for mud render, PA *Mud Plasters* p. 1](lib:mud-plasters-and-renders#page=1), [🖼️ clay-lump and mud-wall houses, DSIR p. 31](lib:special-report-5#page=31).

## 🌾 Straw bale

**Bales** ([BSD-112, p. 3](lib:bsd-112#page=3)): two-string 18 × 14 in; three-string 24 × 16–18 in;
32–40 in long; at least **7 lb per cubic foot**. Straw is fine up to about **20% moisture**; rot begins
at 25–30% ([CMHC 00-103, p. 2](lib:straw-bale-house-moisture-research#page=2)).
[Straw-bale construction](wiki:Straw-bale_construction).

**How it works:** plaster skins (lime or cement 1–1½ in, earth 2–3 in) carry 95–99% of the load; the bales
insulate ([BSD-112, p. 4](lib:bsd-112#page=4)). Here, use bales as **infill in a [timber frame](wiki:Timber_framing)**
*(rule of thumb)*.

**Building it:** toe-up 6 in or more, with a **capillary break** between foundation and plaster
([CMHC, p. 3](lib:straw-bale-house-moisture-research#page=3)); wide overhangs and gutters; careful
flashing at window and door sills and heads, where rain gets in ([BSD-112, p. 11](lib:bsd-112#page=11));
earth or lime plaster straight onto the straw.

**The wet-coast warning** ([CMHC 00-103, pp. 2–3](lib:straw-bale-house-moisture-research#page=3)): the walls
that rotted had **two or more** of these: minimal overhangs; no capillary break; heavy indoor wetting;
bales below grade; poor splash protection; a north-facing wall. Straw in floors rotted to "nothing but
a pile of black compost." On the rainy coast a north wall stayed damp from humid air alone; CMHC urges
**"extreme caution" with north walls** in high-rain climates. Never put straw under a floor.

**Fire:** a wall of 7.5 lb/ft³ wheat bales with **1 in of earth plaster each side** passed a **1-hour**
fire test and the hose stream. The plaster: **3 parts clay, 2 chopped straw, 6 sand**, in two ½-in
coats ([Intertek, pp. 13, 16](lib:1-hour-fire-test#page=13)).

**Fire-season site rules** *(rule of thumb)*: plaster within days; rake up loose straw every evening; keep
water and a hose on site; no grinding or welding near straw; store spare bales well away from
buildings — FEMA puts sheds holding combustibles 50 ft or more from a house
([FEMA P-737, p. 23](lib:fema-p-737#page=23)).

📚 **Go deeper:** [BSD-112 *Building Science for Strawbale*](lib:bsd-112#page=3) — moisture, overhangs, plaster; [Intertek fire test](lib:1-hour-fire-test#page=16) — photos and plaster mix. Pictures: [🖼️ wetting and drying of straw walls, BSD-112 pp. 6, 8](lib:bsd-112#page=6), [🖼️ fire-test photos, Intertek appendix D](lib:1-hour-fire-test#page=32).

## 🪵 Lighter systems: straw-clay, hempcrete, wattle, bags, blocks, cordwood

**Light straw-clay (slip-straw)** ([CMHC 05-109, pp. 2–3](lib:straw-light-clay#page=2);
[Light clay](wiki:Light_clay)): clay-coated straw packed into forms around a timber frame. It carries no
load, dries fast (no vapour retarder over it), and insulates R-0.8 to 2.1 per inch. It **settles about
7%** as it dries, so top it up. Four hours of propane torch burned only 2 in in, and it is ductile — it
soaks up quake energy. *Method (general practice):* dip straw in thick clay slip, tamp it into 12-in
forms on the frame, and let it dry through a summer before plastering.

**Hempcrete** ([Hempitecture, pp. 6, 9, 11](lib:hempcrete-cast-in-place#page=9); [Hempcrete](wiki:Hempcrete)):
binder (lime plus [pozzolan](wiki:Pozzolan)) to [hemp](wiki:Hemp) hurd **1.5 to 1 by weight** — 50 lb of binder, 33 lb of hurd, about
6 gallons of water. A squeezed ball should hold when tossed 2–3 ft. Use within **30 minutes**, out of the
sun; place **2 in at a time**, tamping hardest along the forms. Walls are 8–12 in, R-2.2 to 2.5 per inch,
and need **diagonal bracing** since they can't be sheathed in plywood. Gloves and eye protection (p. 3).
*Reality (general practice):* hurd means retting and breaking stalks by hand, and the binder needs lime.

**[Wattle and daub](wiki:Wattle_and_daub)** ([quincha](wiki:Quincha)): poles and woven sticks packed
with earth — **the most flexible earth system**; one survived a heavy Guatemala quake
([Minke, pp. 13, 28](lib:minke#page=28); [🖼️ a wattle-and-daub store](lib:solar-and-energy-conserving-food#page=57)). It cracks as the wood moves and holes harbor insects, so
patch it yearly. Keep poles out of the soil, where they rot
([PA, p. 3](lib:earthquake-resistant-housing-practical-action#page=3)).

**Earthbags:** test houses used jute or cotton tubes of earth, given **4 coats of lime** against rot,
with a ring beam and the roof on separate posts ([Minke, p. 30](lib:minke#page=30)). Plastic bags rot in
sunlight within months — plaster them soon *(general practice)*. [Earthbag construction](wiki:Earthbag_construction).

**Pressed blocks** ([Compressed earth block](wiki:Compressed_earth_block)): the mix is right when a ball
dropped from shoulder height breaks into a few pieces
([PA *Soil Blocks*, p. 10](lib:making-stabilised-soil-blocks#page=10); [🖼️ pressing a block](lib:handbook-for-building-homes-of-earth#page=98)). A 50%-clay soil like Pollard
subsoil needs lime: try blocks at **5, 7 and 9% lime** by weight
([p. 8](lib:making-stabilised-soil-blocks#page=8)). Keep lime blocks damp a week and don't use them for
**37 days** ([p. 12](lib:making-stabilised-soil-blocks#page=12)).

**Cordwood:** seasoned log rounds laid crosswise in mortar — heavy, unreinforced, so for sheds, not
houses *(general practice)*. [Cordwood construction](wiki:Cordwood_construction).

📚 **Go deeper:** [Hempitecture manual](lib:hempcrete-cast-in-place#page=11) — forms and packing; [Minke](lib:minke#page=28) — wattle and daub, earth-filled bags. Pictures: [🖼️ earth-filled cloth hoses, Minke p. 30](lib:minke#page=30), [🖼️ CINVA-Ram block press, Peace Corps p. 99](lib:handbook-for-building-homes-of-earth#page=99), [Rammed earth](wiki:Rammed_earth).

## 🎨 Earth plasters, lime plaster, limewash and floors

**Earth plaster** ([PA *Mud Plasters*, pp. 3–5](lib:mud-plasters-and-renders#page=3);
[Earthen plaster](wiki:Earthen_plaster)):
1. Aim for **10–15% clay** — at least **3 parts sand to 1 clay** — plus straw chopped to 1–2 in, about
   85 lb per cubic yard. Try test patches.
2. Brush off dust and **wet the wall**. Throw on a clay-rich first coat up to ¾ in thick; scratch it.
3. When dry, dampen it and add a **thinner, sandier finish coat** ([🖼️ photo](lib:mud-plasters-and-renders#page=4)). Shade the work; skip hot, windy days.
4. Limewash it. **Lime-soil plaster** is 1 hydrated lime : 2 clayey soil : 3–6 sand (p. 4).
- Fill holes with **dry earth bricks** in slurry, not wet mud, which shrinks
  ([Irish *Thatch* guide, p. 50](lib:thatch-a-guide#page=50)).

**[Lime plaster](wiki:Lime_plaster) and [stucco](wiki:Stucco):**
- Mortar: **1 lime putty : 3 sand** ([NPS Brief 2, p. 2](lib:repointing-mortar-joints#page=2); [🖼️ mixing it, photos](lib:repointing-mortar-joints#page=11)).
- Stucco: base coats 1 lime : 3 sand with 6 lb of goat or cattle hair (½–2 in) per cubic yard; finish
  1:3 without hair ([NPS Brief 22, p. 15](lib:preservation-brief-22#page=15); [🖼️ stucco layers drawn](lib:preservation-brief-22#page=5)). Best is ⅜-in scratch and
  brown coats, then a ⅛-in finish ([NPS Brief 21, p. 3](lib:preservation-brief-21#page=3); [🖼️ plastering tools](lib:preservation-brief-21#page=2)).
- **Cure slowly:** mist and cover with burlap for 3 days; plastic only if tented off the wall
  ([NPS Brief 2, p. 11](lib:repointing-mortar-joints#page=11)).

**[Limewash](wiki:Whitewash)** yearly to fill hairline cracks before they let water in
([NPS Brief 22, p. 7](lib:preservation-brief-22#page=7)); one coat lasts about a year
([Irish guide, p. 50](lib:thatch-a-guide#page=50)). Make the first coat watery so it soaks 2–3 mm in
([Minke, p. 49](lib:minke#page=49)). Tint with [ochre](wiki:Ochre) or [umber](wiki:Umber) *(rule of thumb)*.

**[Earthen floors](wiki:Earthen_floor)** ([Peace Corps, pp. 139–141](lib:handbook-for-building-homes-of-earth#page=139)):
1. Dig out topsoil to 6–7 in below the finished floor and tamp — but **don't ram swelling clay**.
2. Lay **4 in of tamped sandy gravel** (6 in over swelling soil) against rising damp.
3. Ram two **1½-in layers** of stabilised earth; the top one with enough lime that a nail barely scratches it.
4. Cure it damp several days. Seal with oil, hot beeswax or tallow. Old floors were painted with ox blood
   ([DSIR, p. 17](lib:special-report-5#page=17)).

**Farm-made stabilisers** ([PA *Additives to Clay*, pp. 3–4](lib:additives-to-clay-organic#page=3); [🖼️ a bark-stabilised render](lib:additives-to-clay-organic#page=2)):
**dung** (up to a third, fermented several days); **horse urine**; **fresh blood** with lime; **[casein](wiki:Casein)**
from soured milk; **glue** from boiled skins and bones; **linseed oil**; **oak bark [tannin](wiki:Tannin)** (here, oak
or tanoak *(rule of thumb)*). Use animal products only from healthy animals — **anthrax**. Often none
is needed.

📚 **Go deeper:** [PA *Mud Plasters and Renders*](lib:mud-plasters-and-renders#page=3) — mixes and two-coat work; [NPS Brief 21](lib:preservation-brief-21#page=3) — three-coat lime-and-hair plaster. Pictures: [🖼️ kinds of lath, NPS Brief 21 p. 4](lib:preservation-brief-21#page=4), [Lime mortar](wiki:Lime_mortar).

## 🔥 Making lime

Mortar mixes, concrete, lime concrete and pozzolans are in
[Mortar, Concrete & Roads](guide:MASONRY-ROADS-GUIDE).

> ### ⚠️ Lime burns
> - **[Quicklime](wiki:Calcium_oxide) is hazardous** ([PA *Lime*, p. 1](lib:lime-an-introduction#page=1)) and "highly caustic"
>   ([Irish guide, p. 50](lib:thatch-a-guide#page=50)). Alkali burns, as from plaster and cement, are worse
>   than acid burns ([ATP 4-02.11, p. 118](lib:atp-4-02-11#page=118)).
> - **Lime in an eye:** flood it with clean water at once and keep rinsing **at least 20 minutes**
>   (p. 118). Plain water only.
> - **Goggles, gloves, long sleeves.** Slake in an **open** tub, never a closed one; keep children away
>   *(rule of thumb)*.
> - **Damp quicklime heats up and can start a fire.** Store it airtight
>   ([NBS Circular 30, p. 10](lib:lime-its-properties-and-uses#page=10)).
> - **Burn lime only in the wet season**, never in fire season *(rule of thumb)*.

**Stone:** at least **95% [calcium carbonate](wiki:Calcium_carbonate)**; [marble](wiki:Marble) and shells work too
([PA *Lime*, p. 1](lib:lime-an-introduction#page=1)). Known deposits
([DOGAMI Ore Bin 1958, p. 5](lib:limestone-occurrences-in-western-oregon#page=5)):

| Deposit | Where | Notes |
|---|---|---|
| Lime Rock (Holton Creek) | ~2 mi southeast of Kerby | Marble, over 98% |
| Elder Creek | Near Takilma | Burned for the old Takilma smelter |
| Jones Marble Quarry | ~4 mi west of Williams | Over 99% |
| Turvey | ~4 mi west of Williams | 95% |
| Grizzly Gulch | 2 mi south of Oregon Caves | Small; may now be inside the park, which was enlarged in 2014 — check before digging *(rule of thumb)* |
| Oregon Caves | National monument and preserve | "Not available" — **never quarry there** |

Get the landowner's or agency's permission *(rule of thumb)*.

**Burning** ([PA *Lime*, pp. 1–2](lib:lime-an-introduction#page=2); [Lime kiln](wiki:Lime_kiln)): break
stone to **4–6 in** and hold it at about **1,830°F (1,000°C) for several hours**. The simplest burn — a
ring of logs with [limestone](wiki:Limestone) heaped on top — gives under 1,100 lb of lime ([🖼️ loading a kiln](lib:lime-an-introduction#page=1)). A **shaft kiln** must be at
least **6 times as tall as it is wide** ([PA *Kiln*, p. 1](lib:vertical-shaft-lime-kiln#page=1); [🖼️ building drawings](lib:vertical-shaft-lime-kiln#page=4)); stone
and fuel go in the top, lime comes out the bottom. A wood-fired kiln used about **½ cord per ton of
lime** ([NBS Circular 337, p. 117](lib:manufacture-of-lime#page=117); [🖼️ old shaft kilns](lib:manufacture-of-lime#page=31)). **Underburn rather than
overburn:** overburned lime is yellow, heavy and won't slake; underburned stone can go back in
([p. 13](lib:manufacture-of-lime#page=13)).

**Slaking** ([NBS Circular 337, p. 119](lib:manufacture-of-lime#page=119)):
1. **Test:** barely cover two or three fist-sized lumps with water. Crumbling in under 5 minutes =
   quick-slaking; 5–30 = medium; over 30 = slow.
2. **Quick:** add lime **to** plenty of water, never water to lime, and hoe hard at the first steam.
   **Medium:** water to half-cover. **Slow:** moisten, wait, add water a little at a time. Too hot and
   it "burns"; too much water "drowns" it ([NBS 30, p. 11](lib:lime-its-properties-and-uses#page=11)).
3. Sieve the putty and keep it under water **at least two weeks** before plastering (p. 119). Pit-slake
   **[dolomitic](wiki:Dolomite_(mineral))** lime much longer, or it swells in the wall ([PA *Lime*, p. 3](lib:lime-an-introduction#page=3)).
4. **Always add sand** — putty alone cracks to pieces (NBS 30, p. 11).

📚 **Go deeper:** [PA *Small Vertical Shaft Lime Kiln*](lib:vertical-shaft-lime-kiln#page=1) — drawings and a day-by-day build; [PA *Testing Lime*](lib:methods-for-testing-lime#page=2) — field tests for homemade lime. Pictures: [🖼️ a working shaft kiln, PA *Lime* p. 2](lib:lime-an-introduction#page=2), [Calcium hydroxide](wiki:Calcium_hydroxide).

## 🏚️ Thatch — for sheds only

- **Pitch** 45° or steeper ([Irish guide, p. 18](lib:thatch-a-guide#page=18)).
- **Material:** any stiff, hollow-stemmed grass or [reed](wiki:Phragmites) at least **3 ft long**
  ([p. 19](lib:thatch-a-guide#page=19)). Thresh grain straw clean or mice dig in; lay it **10–12 in
  thick** ([Beard, p. 80](lib:shelters-shacks-and-shanties#page=80)).
- **Life:** reed wears about ¼ in a year, so 6 in of cover lasts about 24 years
  ([Irish guide, p. 31](lib:thatch-a-guide#page=31)). A re-thatch can weigh 3 tonnes — check the timbers
  ([p. 41](lib:thatch-a-guide#page=41)).

**Fire:** most thatch fires start at the chimney — cracked flues, sparks, stovepipes through the thatch
([pp. 61–62](lib:thatch-a-guide#page=61)). Oregon calls even untreated shakes "not desirable"
([Oregon BCD, p. 3](lib:oregon-wildfire-home-hardening-guide-bcd#page=3)). **Thatch only sheds 50 ft or
more from the house** ([FEMA P-737, p. 23](lib:fema-p-737#page=23)), never a dwelling with a stove. [Thatching](wiki:Thatching).

📚 **Go deeper:** [Irish *Thatch* guide](lib:thatch-a-guide#page=19) — materials, fixing, repair, fire prevention; [Beard](lib:shelters-shacks-and-shanties#page=80) — a simple thatched roof. Pictures: [🖼️ fixing a course with scollops, Irish guide p. 31](lib:thatch-a-guide#page=31).

## 🛠️ If this goes wrong

| Problem | Likely cause | What to do |
|---|---|---|
| **Cracks at corners** | Earth swells and shrinks ([Irish guide, p. 50](lib:thatch-a-guide#page=50)) | Round new corners; fill with earth plaster, limewash |
| **Diagonal cracks after a quake** | Shear ([Minke, p. 13](lib:minke#page=13)) | Stay out until the roof is propped; rebuild with a ring beam and narrower openings |
| **Plaster cracks all over** | Too much clay, or dried too fast ([PA *Mud Plasters*, p. 3](lib:mud-plasters-and-renders#page=3)) | More sand and straw; shade and mist; a sandier second coat |
| **Damp, hollowing base** | Splash, puddles, rising damp ([NPS Brief 5, p. 4](lib:preservation-brief-5#page=4)) | Gutters, regrade, gravel trench, clear plants; never patch with cement |
| **Musty smell in a straw wall** | Wet straw: leaks, splash, bathrooms ([CMHC, p. 3](lib:straw-bale-house-moisture-research#page=3)) | Stop the water; open a small hole to check *(rule of thumb)*; replace black straw |
| **Plaster falling off** | Cement over earth, or no key ([NPS Brief 5, p. 3](lib:preservation-brief-5#page=3)) | Strip it; wet and score the wall; replaster in earth or lime |
| **Lime won't slake** | Overburned ([NBS 337, p. 13](lib:manufacture-of-lime#page=13)) or spoiled in damp air ([NBS 30, p. 10](lib:lime-its-properties-and-uses#page=10)) | Discard yellow, heavy lumps; reburn cores; store airtight. Spoiled lime fizzes in dilute acid ([PA *Testing Lime*, p. 3](lib:methods-for-testing-lime#page=3)) |

📚 **Go deeper:** [NPS Preservation Brief 5](lib:preservation-brief-5#page=5) — diagnosing water damage; [Irish *Thatch* guide](lib:thatch-a-guide#page=50) — repairing earth walls. Pictures: [🖼️ patching a hole in plaster, NPS Brief 21 p. 9](lib:preservation-brief-21#page=9), [🖼️ a quake-damaged earth house that stood, Minke p. 13](lib:minke#page=13).

## ⚠️ Old advice in the library to ignore

- **Hot pitch or tar "skirting"** on cob bases ([Williams-Ellis, p. 61](lib:williams-ellis#page=61)). Coal
  tar causes cancer; use a high stone plinth and limewash.
- **Cement-lime render as "probably the best" for cob** (same page). Use lime or earth
  ([NPS Brief 5, p. 5](lib:preservation-brief-5#page=5)).
- **Powdered glass in the wall base against rats** ([p. 62](lib:williams-ellis#page=62)). Use render over
  wire mesh (same page).
- **"Salamanders"** (open coke braziers) to speed lime setting indoors
  ([NBS Circular 30, p. 11](lib:lime-its-properties-and-uses#page=11)). Carbon monoxide kills.
- **Hot bitumen cut with kerosene** in plaster ([PA *Mud Plasters*, p. 4](lib:mud-plasters-and-renders#page=4)).
  Fire and fume hazard; not needed.
- **Copper sulphate ("bluestone") on thatch** ([Irish guide, p. 41](lib:thatch-a-guide#page=41)). It
  irritates eyes and skin and poisons streams.
- **Whitewash called "fireproof," tinted with chrome yellow**
  ([Household Discoveries, p. 270](lib:household-discoveries#page=270)). It isn't fireproof, and chrome
  yellow is a lead pigment. Use ochre and umber.
- **Tall unreinforced cob** — "no apparent limit" to height ([Williams-Ellis, p. 57](lib:williams-ellis#page=57)).
  Both old cob books pre-date quake design; follow the quake rules above.

📚 **Go deeper:** [Minke](lib:minke#page=49) — plasters and paints that work on earth; [NPS Brief 5](lib:preservation-brief-5#page=3) — why cement fails on earth walls.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Quake-safe layout**
- Where not to build on a slope — [🖼️ Minke, p. 8](lib:minke#page=8)
- House shapes that survive — [🖼️ Minke, p. 9](lib:minke#page=9)
- The ten mistakes that collapse earth houses — [🖼️ Minke, p. 12](lib:minke#page=12)
- Plinth, footing and wooden keys — [🖼️ Minke, p. 34](lib:minke#page=34); [Plinth](wiki:Pedestal)
- Timber ring beams and bond beams — [🖼️ Minke, p. 35](lib:minke#page=35), [🖼️ PA, p. 4](lib:earthquake-resistant-housing-practical-action#page=4); [Lintel](wiki:Lintel)
- Wall reinforcement with mesh, wire and bamboo — [🖼️ PA, pp. 5–6](lib:earthquake-resistant-housing-practical-action#page=6)
- Roof on its own posts — [🖼️ Minke, p. 38](lib:minke#page=38)
- Safe sizes for doors and windows — [🖼️ Minke, p. 41](lib:minke#page=41)
- Vertical bars in block walls — [🖼️ CSEB manual, p. 12](lib:compressed-stabilised-earth-block#page=12)

**Local materials**
- A Brockman (serpentine) soil area — [🖼️ Soil Survey text edition, p. 34](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=34); [Serpentine soil](wiki:Serpentine_soil)
- Shrink test: clayey vs. sandy soil — [🖼️ PA *Soil Blocks*, p. 8](lib:making-stabilised-soil-blocks#page=8); [Clay](wiki:Clay)
- Straw, not hay — [Straw](wiki:Straw), [Hay](wiki:Hay)

**Walls**
- How rain wets a wall, and how it dries — [🖼️ BSD-112, p. 6](lib:bsd-112#page=6), [🖼️ p. 8](lib:bsd-112#page=8); [Straw-bale construction](wiki:Straw-bale_construction)
- Old Devon cob — [🖼️ DSIR, p. 25](lib:special-report-5#page=25); [Cob](wiki:Cob_(material))
- Wattle and daub — [🖼️ Minke, p. 28](lib:minke#page=28), [🖼️ Peace Corps food manual, p. 57](lib:solar-and-energy-conserving-food#page=57); [Wattle and daub](wiki:Wattle_and_daub)
- Earth-filled cloth hoses — [🖼️ Minke, p. 30](lib:minke#page=30); [Earthbag construction](wiki:Earthbag_construction)
- Pressing blocks with a CINVA-Ram — [🖼️ Peace Corps, pp. 98–99](lib:handbook-for-building-homes-of-earth#page=98); [Compressed earth block](wiki:Compressed_earth_block)
- Other systems — [Light clay](wiki:Light_clay), [Hempcrete](wiki:Hempcrete), [Cordwood construction](wiki:Cordwood_construction)

**Plasters and floors**
- Mud render on cob, and a finish coat — [🖼️ PA *Mud Plasters*, p. 1](lib:mud-plasters-and-renders#page=1), [🖼️ p. 4](lib:mud-plasters-and-renders#page=4); [Earthen plaster](wiki:Earthen_plaster)
- Bark-stabilised render — [🖼️ PA *Additives*, p. 2](lib:additives-to-clay-organic#page=2)
- Mixing lime mortar — [🖼️ NPS Brief 2, p. 11](lib:repointing-mortar-joints#page=11); [Lime mortar](wiki:Lime_mortar)
- Plastering tools and lath — [🖼️ NPS Brief 21, p. 2](lib:preservation-brief-21#page=2), [🖼️ p. 4](lib:preservation-brief-21#page=4); [Lime plaster](wiki:Lime_plaster)
- Stucco coats on a wall — [🖼️ NPS Brief 22, p. 5](lib:preservation-brief-22#page=5); [Stucco](wiki:Stucco)
- Earthen floors — [Earthen floor](wiki:Earthen_floor)

**Lime and thatch**
- Loading a lime kiln; a small shaft kiln — [🖼️ PA *Lime*, p. 1](lib:lime-an-introduction#page=1), [🖼️ p. 2](lib:lime-an-introduction#page=2); [Lime kiln](wiki:Lime_kiln)
- Building drawings for a shaft kiln — [🖼️ PA *Kiln*, pp. 4–5](lib:vertical-shaft-lime-kiln#page=4)
- Old kiln types — [🖼️ NBS Circular 337, p. 31](lib:manufacture-of-lime#page=31)
- Lime itself — [Calcium oxide](wiki:Calcium_oxide), [Limestone](wiki:Limestone)
- Thatch fixings — [🖼️ Irish guide, p. 31](lib:thatch-a-guide#page=31); [Thatching](wiki:Thatching), [Phragmites](wiki:Phragmites)

---

## 🔗 Related guides

- [Mortar, Concrete & Roads](guide:MASONRY-ROADS-GUIDE) — mortar and concrete mixes, curing, gravel roads
- [Shelter, Building & Repair](guide:SHELTER-BUILDING-GUIDE) — ribbon test, adobe, rammed earth, quake retrofits
- [Firewood guide](guide:FIREWOOD-GUIDE) — fuel for kilns, chimney safety
- [Blacksmithing and Hand Tools](guide:BLACKSMITHING-GUIDE) — forks, spades and framing tools
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — serpentine soils, Cascadia, fire season
- [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — casein glue, household repairs
- [Field Care guide](guide:FIELD-CARE-GUIDE) — treating burns with no help coming
