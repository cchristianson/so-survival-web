# 🏠 Shelter, Building & Repair

The best shelter you will ever have is the house you already live in — if you keep the water out. This
guide covers keeping an existing house sound (roof leaks, flashing, gutters, rot and insects), heating one
warm room, reglazing windows, durable local woods, hand-tool carpentry, splitting your own shakes,
drying lumber, log and earth building, chimneys, earthquake and wildfire hardening, and emergency tarp
shelters. The books are in `Shelter-Building\` (`House-Repair`, `Carpentry-Timber`,
`Earth-Natural-Building`, `Wildfire-Quake-Hardening`). Hand tools and saws are in
`Blacksmithing-Tools\Hand-Tools`; quake and fire guides are in `Earthquake-Tsunami\` and `Wildfire\`;
cob, straw bale, light straw-clay, hempcrete, earth and lime plasters, making lime and thatch are in the
**[Natural Building guide](guide:NATURAL-BUILDING-GUIDE)** and `Natural-Building\`.

> ### ⚠️ Rules that prevent the worst outcomes
> - **Roof work kills.** Use scaffolds, ladders or a safety rope
>   ([USDA FB 1751, p. 24](lib:roof-coverings-for-farm-buildings#page=24)). Never work on a wet or mossy
>   roof, or alone *(rule of thumb)*.
> - **Old houses hold lead paint (before 1978) and asbestos** (old shingles, siding, pipe wrap). Don't
>   sand, cut, heat or burn them. Scrape paint wet and keep children away *(rule of thumb)*.
> - **Carbon monoxide.** Any fuel heater without a chimney needs an open window — 1 sq in per 1,000 Btu
>   ([MSU E-1669, p. 3](lib:some-considerations-about-portable-kerosene-heaters-msu-extension-e-1669-1982#page=3)).
>   Keep a battery [CO alarm](wiki:Carbon_monoxide_detector) by the beds.
> - **Cascadia will shake hard.** Brick chimneys were damaged in most big U.S. quakes
>   ([FEMA 232, p. 144](lib:fema-232#page=144)), and heavy unreinforced earth walls can collapse. Build
>   light, keep earth walls low and single-story, and bolt the house to its foundation
>   ([FEMA 232, p. 168](lib:fema-232#page=168)).
> - **Wildfire comes as embers.** Screen vents with 1/8-in metal mesh, keep gutters clear, and keep
>   firewood 30 ft from the house ([OSFM, p. 8](lib:osfm-defensible-space-homeowner-guide-2025#page=8);
>   [FEMA P-737, p. 23](lib:fema-p-737#page=23)).
> - **Never use the old poisons** the old bulletins recommend — DDT, arsenic, pentachlorophenol,
>   coal-tar creosote. See the last section.

---

## 🏚️ Finding and patching roof leaks

**Inspect the roof regularly** for breaks, missing shingles, choked gutters and damaged flashing
([USDA FB 1751, p. 22](lib:roof-coverings-for-farm-buildings#page=22)) — every fall before the rains,
and after big storms *(rule of thumb)*.

**Finding the leak** (p. 22):
- A wet spot near a chimney or outside wall usually means **bad flashing or loose mortar**.
- Under an open roof, the drip can land **well downslope** from the hole. Follow the stain uphill.
- If you see daylight from the attic, **push a straw through the hole** so you can find it from outside.
- **South-facing slopes wear out faster.** Check them most often.

**Emergency patches:**
- **Missing wood shingle:** cut a piece of **tin-can metal**, paint it on both sides, and slide it under
  the course above. Don't loosen the good shingles. Cut old nails with a long, thin cold chisel, and dab
  roofer's cement on any exposed nail heads (p. 22).
- **Metal roof or gutter, no solder:** plug small holes with roofer's cement. For big holes, stick
  **canvas or several layers of cloth** over the hole with thick paint, then give it several more coats
  ([p. 23](lib:roof-coverings-for-farm-buildings#page=23)).
- **Bigger damage:** tarp it (see the tarp section) until you can repair it.

**Illinois Valley:** our wet winters grow **[moss](wiki:Moss) and [lichen](wiki:Lichen)** on roofs, and overhanging branches keep
shingles wet. Both shorten a wood roof's life
([NPS Brief 19, p. 6](lib:preservation-brief-19#page=6)). Cut back limbs over the roof — that helps in
fire season too.

📚 **Go deeper:** [USDA FB 1751 *Roof Coverings for Farm Buildings*](lib:roof-coverings-for-farm-buildings#page=22) — finding leaks and repairing every kind of roof; [FM 5-426 *Carpentry*](lib:fm-5-426-carpentry#page=119) — roofing and flashing details. Pictures: [🖼️ scaffolds for roof work, FB 1751 p. 13](lib:roof-coverings-for-farm-buildings#page=13), [Roof shingle](wiki:Roof_shingle).

## 💧 Flashing, gutters and keeping water away

**Roofs leak most where two surfaces meet:** valleys, chimneys, dormers and walls. Flash these with
galvanized or copper sheet ([FM 5-426, p. 119](lib:fm-5-426-carpentry#page=119); valleys at
[p. 124](lib:fm-5-426-carpentry#page=124); [🖼️ valley flashing drawings](lib:roof-coverings-for-farm-buildings#page=29) *(ignore its red-lead paint)*;
[🖼️ chimney flashing](lib:fireplaces-and-chimneys#page=12)). Flashing over window and door heads should run **at least
4 in up** behind the siding above the drip cap
([USDA AH 73, p. 163](lib:wood-frame-house-construction#page=163); [🖼️ where flashing goes](lib:wood-frame-house-construction#page=164)).

**Move the water away from the house** ([AH 73, pp. 8–9, 169](lib:wood-frame-house-construction#page=169)):
- Downspouts should empty onto **splash blocks at least 3 ft long** that carry water away from the
  foundation ([🖼️ drawing](lib:wood-frame-house-construction#page=170)).
- The top of the foundation should sit **at least 8 in above the ground**.
- A [crawl space](wiki:Crawl_space) needs **at least 18 in** between the soil and the floor joists, with vents on opposite
  sides ([FB 1993, p. 3](lib:decay-and-termite-damage#page=3)).
- Grade the soil so it slopes away from the walls, and clean gutters every fall *(rule of thumb)*.

📚 **Go deeper:** [USDA *Wood-Frame House Construction* (AH 73)](lib:wood-frame-house-construction#page=163) — illustrated flashing, gutters, foundations and crawl spaces; [FM 5-426](lib:fm-5-426-carpentry#page=124) — valley flashing. Pictures: [Flashing](wiki:Flashing_(weatherproofing)), [Rain gutter](wiki:Rain_gutter), [🖼️ gutters and downspouts, AH 73 p. 168](lib:wood-frame-house-construction#page=168), [🖼️ eaves troughs and downspout fittings, FB 1751 p. 31](lib:roof-coverings-for-farm-buildings#page=31).

## 🔥 One warm room: drafts, plastic and heat

With little fuel, **heat one room, not the house.** The relief-shelter order of priorities in winter
([IFRC/Oxfam *Plastic Sheeting*, p. 30](lib:plastic-sheeting#page=30)):
1. **Clothing and bedding** first.
2. **Waterproofing** (the roof).
3. **Bedding up off the damp floor.**
4. **Windproofing.**
5. Then heat one room. Make a **plastic-curtained buffer (a lobby)** between the warm room and the cold rest
   of the house. Insulate floors and walls with **straw sandwiched between plastic**. Treat any stove in a
   small room as a fire risk.

**Seal the drafts** ([HUD, *In the Bank or Up the Chimney*, pp. 36–37](lib:in-the-bank-or-up-the-chimney#page=36);
[🖼️ caulking drawings](lib:in-the-bank-or-up-the-chimney#page=37)):
- **[Caulk](wiki:Caulk) wherever two different materials meet:** drip caps over windows and doors, frame-to-siding
  joints, sills, siding corners, where wood meets the foundation, pipe and wire holes, and where a chimney
  meets siding.
- Stuff **wide cracks** (like the sill) with [oakum](wiki:Oakum) or fiber first, then caulk.

**Plastic [storm windows](wiki:Storm_window)** ([HUD, p. 42](lib:in-the-bank-or-up-the-chimney#page=42)): tape clear plastic
over the **inside** of the window frame (easier, and it lasts longer), or tack it outside with 1/4 × 1 1/4
in wood slats. Pull it tight and trim the extra.

**Heaters without a chimney make carbon monoxide.** Leave **1 sq in of open window for every 1,000 Btu**
of heater output. A 9,100-Btu heater in a room with a 24-in window means opening it almost 1/2 in
([MSU E-1669, p. 3](lib:some-considerations-about-portable-kerosene-heaters-msu-extension-e-1669-1982#page=3)).

**No fuel at all?** Insulate the people: towels, paper bags and layers of newspaper held under old
raincoats and shirts ([Kearny, p. 130](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=130)).

📚 **Go deeper:** [HUD *In the Bank or Up the Chimney*](lib:in-the-bank-or-up-the-chimney#page=36) — caulking, weatherstripping and insulation, step by step; [IFRC/Oxfam *Plastic Sheeting*](lib:plastic-sheeting#page=30) — warm rooms in winter; [CMHC wood-heating guide](lib:guide-to-residential-wood-heating#page=36) — stove and pipe safety. Pictures: [🖼️ weatherstripping types, HUD p. 38](lib:in-the-bank-or-up-the-chimney#page=38), [Weatherstripping](wiki:Weatherstripping), [Kerosene heater](wiki:Kerosene_heater).

## 🪟 Reglazing and saving windows

> ⚠️ **Paint on windows made before 1978 almost certainly contains lead.** Don't sand it dry or heat it
> until it scorches. Scrape it wet, collect the chips, and keep children away *(rule of thumb)*.

**Replacing a pane** ([NPS Brief 9, p. 5](lib:preservation-brief-9#page=5); [🖼️ window parts named](lib:preservation-brief-9#page=2)):
1. Dig out the old putty without gouging the wood. Soaking the glass in **[linseed oil](wiki:Linseed_oil)** loosens putty stuck
   to it.
2. Pull the **glazing points** (the small metal tabs) and lift out the glass.
3. Lay a **thin bed of putty** in the rabbet (the groove the glass sits in) and press the pane in.
4. Push in new glazing points.
5. Run a final bead of putty and **bevel it** with a putty knife so water runs off.
6. **Paint when the putty skins over**, usually in 2–3 days. Lap the paint slightly onto the glass to seal
   it.

**Where window rot starts:** the sill, the sill-to-jamb joints, the bottom-rail corners and the [muntin](wiki:Muntin)
(glass-bar) joints — wherever water sits. **The sill must slope outward.** Cracked putty lets water soak
the joints ([NPS Brief 9, p. 2](lib:preservation-brief-9#page=2)).

**Saving partly rotted wood:** let it dry, brush on **2–3 coats of boiled linseed oil, 24 hours apart**,
fill cracks with putty, then paint ([p. 5](lib:preservation-brief-9#page=5)). Rags soaked in linseed oil
can **catch fire by themselves** — dry them spread flat outdoors or keep them in a can of water
*(rule of thumb)*.

📚 **Go deeper:** [NPS Preservation Brief 9](lib:preservation-brief-9#page=5) — reglazing, sash cords, weatherstripping and sill repair. Pictures: [Putty](wiki:Putty), [Sash window](wiki:Sash_window), [Putty knife](wiki:Putty_knife).

## 🐜 Rot, termites, carpenter ants — and woods that last

**Dry wood does not rot.** Decay needs wood wetter than about 30% moisture. Air-dried wood is at or below
20%, and decay already in the wood stops if it's kept dry
([Wood Handbook, p. 314](lib:wood-handbook#page=314); [🖼️ rot fungi](lib:decay-and-termite-damage#page=8)).

**What rots houses and draws termites** ([USDA FB 1993, p. 7](lib:decay-and-termite-damage#page=7)):
wet, unventilated crawl spaces; scrap wood left on the soil; **wood touching soil** (especially
dirt-filled porches); wood buried in masonry near the ground; no gutters or roof overhang; roof and
plumbing leaks.

**The fixes** ([FB 1993, p. 3](lib:decay-and-termite-damage#page=3)): no wood touching soil, an 18-in
crawl space, vents on opposite sides (or roll roofing laid over the soil), and an inspection every winter
or early spring. **Termites build earthen tubes** up foundations ([🖼️ photo](lib:decay-and-termite-damage#page=6)): break them, and block the route with
mortar or pitch.

**Carpenter ants** ([USFS R10-TP-128, pp. 4, 7](lib:carpenter-ants#page=4); [🖼️ winged ants](lib:carpenter-ants#page=5)):
- **More than 20 ants indoors, especially in winter,** means a nest inside the house.
- Their **[frass](wiki:Frass)** looks like sawdust mixed with insect parts ([🖼️ photo](lib:carpenter-ants#page=8)).
- They don't eat wood — they hollow out **wet, softening wood**. Fix the moisture, find and remove the nest
  wood, keep firewood and debris away from the house, and store food sealed.

**Which woods last** (heartwood only;
[Wood Handbook, Table 14-1, p. 316](lib:wood-handbook#page=316)):

| Decay resistance | Western species |
|---|---|
| **Very resistant** | [Pacific yew](wiki:Taxus_brevifolia) |
| **Resistant** | **Port-Orford-cedar**, **incense-cedar**, [western redcedar](wiki:Thuja_plicata), junipers, white oaks, old-growth [redwood](wiki:Sequoia_sempervirens) |
| **Moderately resistant** | [Douglas-fir](wiki:Douglas_fir), [western larch](wiki:Western_larch) |
| **Slightly or not resistant** | True firs, hemlocks, [red alder](wiki:Alnus_rubra), maples, [tanoak](wiki:Notholithocarpus), cottonwood, most pines |

**Locally,** [Port-Orford-cedar](wiki:Chamaecyparis_lawsoniana) and
[incense-cedar](wiki:Calocedrus_decurrens) grow in the valley and the Siskiyous. Use their heartwood for
sills, posts, shakes and anything touching the ground. Port-Orford-cedar killed by root disease still has
sound, durable heartwood *(rule of thumb)*.

📚 **Go deeper:** [USDA FB 1993 *Decay and Termite Damage in Houses*](lib:decay-and-termite-damage#page=7) — spotting decay and termite tubes (ignore its poisons); [Wood Handbook ch. 14](lib:wood-handbook#page=314) — decay, insects and durable species; [USFS *Carpenter Ants*](lib:carpenter-ants#page=7) — finding the nest. Pictures: [Carpenter ant](wiki:Carpenter_ant), [Termite](wiki:Termite), [Wood-decay fungus](wiki:Wood-decay_fungus), [🖼️ termite or winged ant? FB 1993 p. 5](lib:decay-and-termite-damage#page=5).

## 🪚 Hand-tool carpentry and drying lumber

**Square a corner with 6-8-10** ([FM 5-426, p. 48](lib:fm-5-426-carpentry#page=48); [🖼️ the same idea with 3-4-5](lib:handbook-for-building-homes-of-earth#page=62)):
1. Measure **6 ft** along one line and **8 ft** along the other.
2. Move the lines until the diagonal between those two marks is **exactly 10 ft**. Never use less than 6 ft.
3. When the whole rectangle is laid out, check that **both diagonals are equal** ([🖼️ drawing](lib:handbook-for-building-homes-of-earth#page=63)). Batter boards hold the
   lines ([p. 46](lib:fm-5-426-carpentry#page=46); [🖼️ batter boards](lib:wood-frame-house-construction#page=10)).

**[Handsaw](wiki:Hand_saw) basics** ([Disston, p. 10](lib:disston-saw-tool-and-file-book-1929#page=10)): start on the
**waste side** of the line with your thumb against the blade, and draw back a few times to make a groove.
Crosscut at about **45°** to the board with full-length strokes. Support the waste piece so it doesn't
splinter off.

**Hewing a log flat** ([*An Ax to Grind*, p. 52](lib:usfs-an-ax-to-grind-a-practical-ax-manual-1999#page=52)):
hew **green, freshly cut logs** — dry logs hew badly. Set the log on V-notched **yokes** about knee high.
Snap a [chalk line](wiki:Chalk_line), **score** down to it with a single-bit axe, then flatten with a **broadaxe**
([🖼️ step-by-step drawings](lib:usfs-an-ax-to-grind-a-practical-ax-manual-1999#page=53)).

**Roofs and joints:** rafter lengths by the step-off method
([FM 5-426, p. 108](lib:fm-5-426-carpentry#page=108)) or the [steel square](wiki:Steel_square)
([Brace and Mayne, p. 199](lib:brace-and-mayne-farm-shop-work-1915#page=199); [🖼️ rafter pitch](lib:brace-and-mayne-farm-shop-work-1915#page=198)); [mortise-and-tenon](wiki:Mortise_and_tenon) joints
([Griffith, p. 105](lib:griffith-essentials-of-woodworking-1908#page=105); [🖼️ drawing](lib:brace-and-mayne-farm-shop-work-1915#page=69)).

**Air-drying lumber** ([OCHA/IFRC/CARE *Timber*, pp. 45, 68](lib:timber-as-a-construction-material#page=45)):
- A 1-inch (2.5 cm) board takes **about a year** to air-dry, depending on species. Thicker takes longer.
- Stack it **off the ground on bearers**, with **stickers** (spacer sticks) between every layer
  ([🖼️ stacking drawing](lib:timber-as-a-construction-material#page=68)).
- **Seal or paint the ends** — they dry fastest and crack.
- Cover the top loosely so air still moves through.

**Wood shrinks** most along the growth rings, about half as much across them, and hardly at all along its
length ([Wood Handbook, p. 84](lib:wood-handbook#page=84)). Green wood opens gaps as it dries.

📚 **Go deeper:** [FM 5-426 *Carpentry*](lib:fm-5-426-carpentry#page=46) — layout, framing, rafters and roofing; [USFS *Handtools for Trail Work*, p. 46](lib:usfs-mtdc-handtools-for-trail-work-2005#page=46) — adzes and broadaxes; [*Timber in Humanitarian Operations*](lib:timber-as-a-construction-material#page=45) — felling, drying and joining timber. Pictures: [Broadaxe](wiki:Broadaxe), [Hewing](wiki:Hewing), [Adze](wiki:Adze), [Wood drying](wiki:Wood_drying), [🖼️ air-drying yard, Wood Handbook p. 317](lib:wood-handbook#page=317).

## 🪵 Splitting and laying your own shingles and shakes

**Splitting** ([NPS Brief 19, p. 2](lib:preservation-brief-19#page=2)):
1. Cut the log into **bolts** as long as the shingle, then quarter them.
2. Rive off thin boards along the grain with a [froe](wiki:Froe) and mallet (or an axe)
   ([🖼️ froe drawing](lib:shelters-shacks-and-shanties#page=149); [🖼️ photos](lib:preservation-brief-19#page=3)).
3. For a **taper**, flip the bolt end-for-end after each split.
4. Use **heartwood only**. Sapwood rots fast.
5. Old shingles were 3/8–3/4 in thick, 3–8 in wide and 14–36 in long, smoothed with a
   [drawknife](wiki:Drawknife) so rain doesn't sit in the grain.

If a split runs off to one side, start again from the other end of the billet and split back to meet it
([Beard, p. 115](lib:shelters-shacks-and-shanties#page=115)).

**Laying wood shingles** ([USDA FB 1751, pp. 6–7](lib:roof-coverings-for-farm-buildings#page=6)) on a roof
of 1/4 pitch or steeper (flatter roofs are hard to keep tight):

| Shingle length | Show to the weather |
|---|---|
| 16 in | 5 in |
| 18 in | 5 1/2 in |
| 24 in | 7 1/2 in |

- Gaps of 1/4 in between dry shingles, 1/8 in between green ones.
- **Two rust-resistant nails** per shingle, no more than 3/4 in from the edges and 1–2 in above the next
  butt line.
- Break joints by **at least 1 1/2 in** from the course below.
- **Double the first course** at the eaves and let it overhang about 1 in.

**For our wet winters, nail shingles to spaced 1×4 slats** (spaced the same as the exposure) instead of
solid boards. Air reaches the underside so they dry out, and it takes less lumber
([FB 1751, p. 6](lib:roof-coverings-for-farm-buildings#page=6)). A cedar roof on raised, ventilated
battens lasted over 60 years in a harsh, wet climate ([NPS Brief 19, p. 4](lib:preservation-brief-19#page=4)).

📚 **Go deeper:** [NPS Preservation Brief 19](lib:preservation-brief-19#page=2) — hand-split shingles and why wood roofs fail; [Beard *Shelters, Shacks and Shanties*](lib:shelters-shacks-and-shanties#page=111) — shakes and clapboards with only an axe. Pictures: [Wood shingle](wiki:Wood_shingle), [Shaving horse](wiki:Shaving_horse), [🖼️ shingles on slats, FB 1751 p. 6](lib:roof-coverings-for-farm-buildings#page=6), [🖼️ hips and ridges, p. 7](lib:roof-coverings-for-farm-buildings#page=7), [🖼️ historic roof details chart, NPS Brief 19 p. 5](lib:preservation-brief-19#page=5).

## 🏕️ Log buildings

**Cutting the logs** ([USDA FB 1660, pp. 5–6](lib:use-of-logs-and-poles#page=5)):
- If you will peel the logs, **fell in winter**. Spring-cut logs stain and decay.
- Logs over 20 ft are heavy and seldom needed.
- Season them stacked in the shade with air around them. **Peel them** — bark has no practical advantage
  and invites beetles ([🖼️ peeling with a drawknife or bark spud](lib:usfs-an-ax-to-grind-a-practical-ax-manual-1999#page=52)).

**Foundations:**
- Wicks sets **cedar posts** in holes at least 3 ft deep, or uses **stone piers** — large flat stones or
  cobbles bedded firmly and chinked with small stones. Hew the **sill logs** flat on top
  ([Wicks, pp. 15–17](lib:wicks-log-cabins#page=15)).
- **Keep the bottom logs high and dry.** Wicks cuts posts off 10 in above ground; later Forest Products Lab
  guidance is **12–18 in**, with eaves of about 24 in on a one-story cabin (that bulletin is not on the
  drive). A sill log touching soil is already rotting or soon will be
  ([NPS Brief 26, p. 8](lib:preservation-brief-26#page=8)).

**Notching:** the common corner notches — saddle, V, [dovetail](wiki:Dovetail_joint), square — are drawn in
[NPS Brief 26, p. 5](lib:preservation-brief-26#page=5) and [FB 1660, p. 12](lib:use-of-logs-and-poles#page=12).
Notches that **cup upward** hold rain and rot first ([Brief 26, p. 9](lib:preservation-brief-26#page=9)),
so cut the notch in the **underside** of the upper log *(rule of thumb)*.

**Chinking and daubing** ([NPS Brief 26, pp. 6, 12–13](lib:preservation-brief-26#page=6); [🖼️ methods drawn](lib:preservation-brief-26#page=13)) — three layers:
1. **Blocking:** wood slabs or stones wedged into the gap.
2. **Soft packing:** moss, oakum or clay.
3. **Daub:** clay mixed with lime, troweled on wet. Wet the joint first; mix only what you can use in about
   30 minutes; don't daub in full sun, heat or frost (p. 13).

Daubing is **the least durable part** of a log building. Patching it is a seasonal chore (p. 12). Delay
chinking as long as you can so the logs dry first ([FB 1660, p. 12](lib:use-of-logs-and-poles#page=12)),
and fit doors and windows only after the logs have shrunk
([Wood Handbook, p. 84](lib:wood-handbook#page=84)).

📚 **Go deeper:** [Wicks *Log Cabins and Cottages*](lib:wicks-log-cabins#page=15) — a cabin step by step; [USDA FB 1660 *Logs and Poles*](lib:use-of-logs-and-poles#page=11) — notching, chinking and pole buildings; [NPS Brief 26](lib:preservation-brief-26#page=6) — repairing rotted logs and daubing mixes. Pictures: [Log cabin](wiki:Log_cabin), Chinking, [Log building](wiki:Log_building), [🖼️ log-hewing tools, NPS Brief 26 p. 5](lib:preservation-brief-26#page=5).

## 🧱 Earth building — with the Cascadia caution

> ⚠️ **Heavy, unreinforced earth walls can collapse in a big quake.** The Peace Corps handbook calls for
> **steel reinforcement** in footings and walls in earthquake areas
> ([*Building Homes of Earth*, pp. 70–75](lib:handbook-for-building-homes-of-earth#page=70)). In southern
> Oregon, keep earth walls **low, light and single-story**, or use earth only as infill or inside walls
> within a braced wood frame *(rule of thumb)*.

**Ribbon test for building soil** ([*Building Homes of Earth*, pp. 24–25](lib:handbook-for-building-homes-of-earth#page=24);
[🖼️ drawing](lib:handbook-for-building-homes-of-earth#page=25)):
roll damp soil into a cigar shape and squeeze it out between thumb and finger into a ribbon.

| Ribbon length | What it means |
|---|---|
| 8–10 in | Lots of clay — walls last only if you stabilize or temper it |
| 2–4 in | Medium clay — often good |
| No ribbon | Too little clay |
| Springs back like a sponge | Organic topsoil — unusable |

**[Adobe bricks](wiki:Mudbrick)** ([USDA FB 1720, pp. 9–10](lib:adobe-or-sun-dried-brick#page=9)):
1. Puddle clayey loam with water. Mix in **no more than 1 part loose straw to 5 parts mud**. Too much straw,
   or manure, weakens the brick.
2. Mould the bricks ([🖼️ forms](lib:adobe-or-sun-dried-brick#page=6); [🖼️ step by step](lib:adobe-or-sun-dried-brick#page=8)). After a few days, stand them on edge.
3. Dry them **2–3 weeks under cover from rain**. Never let uncured brick freeze.
4. Lay them in mud mortar with 1/2–1 in joints.

Adobe works in wet climates only if the walls are kept dry and the site never floods
([p. 3](lib:adobe-or-sun-dried-brick#page=3)) — so give it wide eaves and a raised foundation.

**Rammed earth** ([USDA FB 1500, pp. 9, 11–12](lib:rammed-earth-walls#page=9)):
- Right moisture is about 7–14% water by weight (p. 8): a squeezed handful should **break apart when dropped**.
- Ram it in **4–5 in layers** between forms ([🖼️ rammers](lib:rammed-earth-walls#page=10); [🖼️ forms](lib:rammed-earth-walls#page=12)).
- The foundation is masonry as thick as the wall (generally 18 in), at least 12 in above ground so rain
  can't splash the earth, with a **[damp-proof course](wiki:Damp_proofing)** on top.

**Cob, straw bale, light straw-clay, hempcrete, earth and lime plasters:** see the
[Natural Building guide](guide:NATURAL-BUILDING-GUIDE).

📚 **Go deeper:** [Peace Corps *Handbook for Building Homes of Earth*](lib:handbook-for-building-homes-of-earth#page=24) — soil tests, blocks, footings and roofs; [USDA FB 1720 *Adobe*](lib:adobe-or-sun-dried-brick#page=9) — mixing, curing and plasters; [USDA FB 1500 *Rammed Earth*](lib:rammed-earth-walls#page=9) — forms and rammers. Pictures: [Adobe](wiki:Adobe), [Rammed earth](wiki:Rammed_earth), [🖼️ adobe footings, FB 1720 p. 13](lib:adobe-or-sun-dried-brick#page=13), [🖼️ rammed-earth forms, Peace Corps p. 120](lib:handbook-for-building-homes-of-earth#page=120).

## 🧯 Chimneys and stovepipe

**Building or checking a masonry chimney** ([USDA FB 1889](lib:fireplaces-and-chimneys#page=4); [🖼️ whole-chimney diagram](lib:fireplaces-and-chimneys#page=5)):
- It should rise **at least 3 ft above a flat roof** and **2 ft above any ridge within 10 ft** (p. 4).
- It needs a **fire-clay [flue](wiki:Flue) lining** and a footing on solid ground below the frost line (p. 6).
- Keep **2 in of air** between the chimney masonry and any wood framing (p. 8).
- **Smoke test** before use: build a smoky fire at the base, cover the top tightly with a wet blanket, and
  look for smoke leaking through the walls. Fix every leak first
  ([p. 10](lib:fireplaces-and-chimneys#page=10)).
- Stovepipe must **never pass through floors, closets or hidden spaces**, or enter the chimney in the attic
  (p. 10).

**Single-wall stovepipe needs 18 in** from anything that burns; only proper shielding allows less
([CMHC, p. 36](lib:guide-to-residential-wood-heating#page=36)).

**[Repointing](wiki:Repointing)** loose chimney mortar: rake it out and refill with 1 part portland cement, 1 part lime and
6 parts sand ([FB 1751, p. 24](lib:roof-coverings-for-farm-buildings#page=24)). When cement runs out, use
lime and sand, about 1:3 — and keep hard cement off soft old brick *(rule of thumb)*.

**Cleaning and chimney fires:** see the [Firewood guide](guide:FIREWOOD-GUIDE).

📚 **Go deeper:** [USDA FB 1889 *Fireplaces and Chimneys*](lib:fireplaces-and-chimneys#page=6) — flues, footings, clearances and cleanouts; [CMHC *Guide to Residential Wood Heating*](lib:guide-to-residential-wood-heating#page=36) — current clearances. Pictures: [Chimney](wiki:Chimney), [🖼️ soot pocket and cleanout, FB 1889 p. 9](lib:fireplaces-and-chimneys#page=9) *(ignore its asbestos insulation)*.

## 🌎 Earthquake and wildfire hardening

**Earthquake** ([FEMA 232](lib:fema-232#page=168)):
- **Masonry chimneys** are heavy, rigid and often brittle. They have been damaged in most moderate to
  severe U.S. earthquakes, and a damaged chimney becomes a falling hazard. Light flues do better
  ([pp. 144–145](lib:fema-232#page=144)). Don't put beds beside a brick chimney *(rule of thumb)*.
- **The best-value retrofits:** bolt the **sill plate to the foundation**, and sheathe crawl-space
  **cripple walls** (the short stud walls between foundation and floor) with plywood. Replace decayed sill
  wood while you're there (pp. 168–170; [🖼️ sill bolts](lib:fema-232#page=169); [🖼️ cripple-wall bracing](lib:fema-232#page=171)).
- **Check your house:** look under it for [bolts](wiki:Anchor_bolt) in the sill — **no more than 6 ft apart on a one-story
  house, 4 ft on a two-story** ([*Living on Shaky Ground*, p. 15](lib:living-on-shaky-ground-oregon-earthquake-and-tsunami-guide#page=15)).

**Wildfire — embers cause up to 90% of house ignitions** and can fly miles ahead of a fire
([OSFM, p. 5](lib:osfm-defensible-space-homeowner-guide-2025#page=5)). They blow into vents and light the
debris in gutters ([FEMA P-737, p. 13](lib:fema-p-737#page=13)):
- **Vents:** cover with **1/8-in metal mesh**, or fit ember-rated vents
  ([OSFM, p. 8](lib:osfm-defensible-space-homeowner-guide-2025#page=8)). 1/16-in mesh stops more embers but
  clogs; replace or cover any 1/4-in mesh ([Oregon BCD, p. 5](lib:oregon-wildfire-home-hardening-guide-bcd#page=5)).
- **Gutters:** metal gutters with **noncombustible leaf guards**. Mesh guards still let pine needles
  build up, so check and clear them ([FEMA P-737, pp. 45–46](lib:fema-p-737#page=45)).
- **Woodpiles at least 30 ft** from the house, on bare or gravelled ground
  ([P-737, p. 23](lib:fema-p-737#page=23)). Never store firewood or fuel under a house on an open
  foundation ([p. 58](lib:fema-p-737#page=58)), and keep the space under decks clear
  ([p. 59](lib:fema-p-737#page=59)).

📚 **Go deeper:** [FEMA 232 ch. 9](lib:fema-232#page=168) — retrofitting existing houses; [Living on Shaky Ground](lib:living-on-shaky-ground-oregon-earthquake-and-tsunami-guide#page=15) — Oregon's checklist; [FEMA P-737](lib:fema-p-737#page=39) — vents, roofs, decks, windows and siding; [Oregon Home Hardening Guide](lib:oregon-wildfire-home-hardening-guide-bcd#page=5). Pictures: [Seismic retrofit](wiki:Seismic_retrofit), [Ember](wiki:Ember), [🖼️ chimney quake damage, FEMA 232 p. 144](lib:fema-232#page=144), [🖼️ gutter debris and leaf guards, FEMA P-737 p. 45](lib:fema-p-737#page=45).

## ⛺ Emergency tarp and plastic shelters

**Fixing plastic so it doesn't tear** ([IFRC/Oxfam *Plastic Sheeting*, p. 26](lib:plastic-sheeting#page=26)):
- **Spread the load.** Plain nails pull straight through. Nail through **wooden battens**, or use
  **washers or bottle caps** (sharp side away from the plastic), or fold the plastic over a rope.
- **Fold the sheet over on itself** wherever you fasten it ([🖼️ good and bad fixings](lib:plastic-sheeting#page=27)).

**Keep it tight and sloped** ([p. 29](lib:plastic-sheeting#page=29)): a loose sheet flaps in the wind and
holds puddles, and both tear it. Keep nail heads flush, smooth anything that touches the plastic, and keep
branches and hot metal (stovepipes) away.

**Tarping a damaged roof** *(rule of thumb)*: run the [tarp](wiki:Tarpaulin) **over the ridge** so rain can't get under its
top edge, and hold it down with battens nailed through it, not with nails alone.

**Out in the open:** a [poncho](wiki:Poncho) [lean-to](wiki:Lean-to) needs only a poncho, 2–3 m of cord, three stakes and two trees
([FM 21-76, p. 49](lib:fm-21-76-army-survival-manual#page=49); [🖼️ drawing](lib:fm-3-05-70-survival-2002#page=69)). For fallout shelters, see the
[Nuclear Fallout guide](guide:NUCLEAR-FALLOUT-GUIDE).

📚 **Go deeper:** [IFRC/Oxfam *Plastic Sheeting*](lib:plastic-sheeting#page=26) — fixing, repairs and warm rooms; [Beard](lib:shelters-shacks-and-shanties) — bark and brush lean-tos up to pole houses; [Kearny *Expedient Shelter Handbook*](lib:expedient-shelter) — quickly built earth-covered shelters.

## ⚠️ Old advice in the library to ignore

- **Poisons for termites and rot:** DDT, sodium arsenite, pentachlorophenol and trichlorobenzene
  ([USDA FB 1993, pp. 26–27](lib:decay-and-termite-damage#page=26); [p. 20](lib:decay-and-termite-damage#page=20)).
  All are banned or highly toxic. Use none. Control moisture, keep wood off the soil, and break termite
  tubes instead.
- **Coal-tar creosote** painted on logs, cut ends and posts ([FB 1660, p. 5](lib:use-of-logs-and-poles#page=5);
  [FB 1500, p. 13](lib:rammed-earth-walls#page=13); [Beard, p. 188](lib:shelters-shacks-and-shanties#page=188)).
  It is toxic and causes cancer; never use it in living space. Use durable heartwood and keep it dry.
- **Asbestos** shingles, siding and heat shields ([FB 1751, p. 9](lib:roof-coverings-for-farm-buildings#page=9);
  [AH 73, p. 92](lib:wood-frame-house-construction#page=92); [NPS Brief 9, p. 5](lib:preservation-brief-9#page=5)).
  Don't cut, break, sand or burn it. For a heat shield use aluminum foil on gypsum board, which the same page offers.
- **Lead paint** — white-lead and red-lead paints for roofs, flashing and primer
  ([FB 1751, p. 21](lib:roof-coverings-for-farm-buildings#page=21); [AH 73, p. 194](lib:wood-frame-house-construction#page=194)),
  and **heat on old paint** ([NPS Brief 9, p. 3](lib:preservation-brief-9#page=3)). Don't make or use lead
  paint; scrape old paint wet, never heat it.
- **Stovepipe 9 in from woodwork** ([FB 1889, p. 10](lib:fireplaces-and-chimneys#page=10)). Use 18 in for
  single-wall pipe. The same bulletin lets framing sit **1/2 in** from 8-in masonry
  ([p. 11](lib:fireplaces-and-chimneys#page=11)) — keep 2 in.
- **1/4-in vent mesh** ([FEMA P-737, p. 40](lib:fema-p-737#page=40)). Oregon now says 1/8 in.
- **Cabin posts 10 in above ground** ([Wicks, p. 15](lib:wicks-log-cabins#page=15)). Go 12–18 in.
- **FEMA 232's code numbers** (2003 IRC, e.g. [p. 144](lib:fema-232#page=144)) are out of date; its
  bolting, cripple-wall and chimney advice still holds.

📚 **Go deeper:** [Wood Handbook ch. 14](lib:wood-handbook#page=316) — durable species instead of poisons; [Oregon Home Hardening Guide](lib:oregon-wildfire-home-hardening-guide-bcd#page=5) — current vent rules.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Roofs, flashing and gutters**
- Scaffolds for roof work — [🖼️ FB 1751, p. 13](lib:roof-coverings-for-farm-buildings#page=13)
- Wood shingles on spaced slats; hips and ridges — [🖼️ FB 1751, p. 6](lib:roof-coverings-for-farm-buildings#page=6), [🖼️ p. 7](lib:roof-coverings-for-farm-buildings#page=7); [Wood shingle](wiki:Wood_shingle)
- Valley flashing — [🖼️ FB 1751, p. 29](lib:roof-coverings-for-farm-buildings#page=29) *(ignore its red-lead paint)*; [Flashing](wiki:Flashing_(weatherproofing))
- Chimney flashing and cricket — [🖼️ FB 1889, p. 12](lib:fireplaces-and-chimneys#page=12)
- Where flashing goes on a wall — [🖼️ AH 73, p. 164](lib:wood-frame-house-construction#page=164)
- Gutters, downspouts and splash blocks — [🖼️ AH 73, p. 168](lib:wood-frame-house-construction#page=168), [🖼️ p. 170](lib:wood-frame-house-construction#page=170); [Rain gutter](wiki:Rain_gutter)

**Drafts and windows**
- Caulking and weatherstripping — [🖼️ HUD, p. 37](lib:in-the-bank-or-up-the-chimney#page=37), [🖼️ p. 38](lib:in-the-bank-or-up-the-chimney#page=38); [Weatherstripping](wiki:Weatherstripping)
- Parts of a wooden window — [🖼️ NPS Brief 9, p. 2](lib:preservation-brief-9#page=2); [Sash window](wiki:Sash_window)
- Putty and muntins — [Putty](wiki:Putty), [Muntin](wiki:Muntin)

**Rot and insects**
- Termite or winged ant? — [🖼️ FB 1993, p. 5](lib:decay-and-termite-damage#page=5); [Termite](wiki:Termite)
- Termite shelter tubes — [🖼️ FB 1993, p. 6](lib:decay-and-termite-damage#page=6)
- Rot fungi — [🖼️ FB 1993, p. 8](lib:decay-and-termite-damage#page=8); [Wood-decay fungus](wiki:Wood-decay_fungus)
- Carpenter ants and their frass — [🖼️ USFS, p. 5](lib:carpenter-ants#page=5), [🖼️ p. 8](lib:carpenter-ants#page=8); [Carpenter ant](wiki:Carpenter_ant)
- Durable local woods — [Port-Orford-cedar](wiki:Chamaecyparis_lawsoniana), [Incense-cedar](wiki:Calocedrus_decurrens), [Pacific yew](wiki:Taxus_brevifolia)

**Carpentry, hewing and shingles**
- Squaring a layout (3-4-5) and checking diagonals — [🖼️ Peace Corps, p. 62](lib:handbook-for-building-homes-of-earth#page=62), [🖼️ p. 63](lib:handbook-for-building-homes-of-earth#page=63)
- Batter boards — [🖼️ AH 73, p. 10](lib:wood-frame-house-construction#page=10)
- Holding a handsaw — [🖼️ Disston, p. 10](lib:disston-saw-tool-and-file-book-1929#page=10); [Hand saw](wiki:Hand_saw)
- Steel square and rafter pitch — [🖼️ Brace and Mayne, p. 194](lib:brace-and-mayne-farm-shop-work-1915#page=194), [🖼️ p. 198](lib:brace-and-mayne-farm-shop-work-1915#page=198); [Steel square](wiki:Steel_square)
- Mortise and tenon — [🖼️ Brace and Mayne, p. 69](lib:brace-and-mayne-farm-shop-work-1915#page=69); [Mortise and tenon](wiki:Mortise_and_tenon)
- Hewing: chalk line, juggling, broadaxe — [🖼️ *An Ax to Grind*, pp. 53–55](lib:usfs-an-ax-to-grind-a-practical-ax-manual-1999#page=53); [Broadaxe](wiki:Broadaxe)
- Stacking lumber to dry — [🖼️ *Timber*, p. 68](lib:timber-as-a-construction-material#page=68), [🖼️ Wood Handbook, p. 317](lib:wood-handbook#page=317)
- Froe and riving shakes — [🖼️ Beard, p. 149](lib:shelters-shacks-and-shanties#page=149), [🖼️ NPS Brief 19, p. 3](lib:preservation-brief-19#page=3); [Froe](wiki:Froe)

**Log and earth buildings**
- Corner notches — [🖼️ NPS Brief 26, p. 5](lib:preservation-brief-26#page=5), [🖼️ FB 1660, p. 12](lib:use-of-logs-and-poles#page=12); [Log cabin](wiki:Log_cabin)
- Chinking and daubing — [🖼️ NPS Brief 26, p. 13](lib:preservation-brief-26#page=13)
- Ribbon test — [🖼️ Peace Corps, p. 25](lib:handbook-for-building-homes-of-earth#page=25)
- Adobe forms and brick-making — [🖼️ FB 1720, p. 6](lib:adobe-or-sun-dried-brick#page=6), [🖼️ p. 8](lib:adobe-or-sun-dried-brick#page=8); [Mudbrick](wiki:Mudbrick)
- Rammed-earth rammers and forms — [🖼️ FB 1500, p. 10](lib:rammed-earth-walls#page=10), [🖼️ p. 12](lib:rammed-earth-walls#page=12); [Rammed earth](wiki:Rammed_earth)

**Chimneys, quakes, fire and tarps**
- A whole chimney, its top and cleanout — [🖼️ FB 1889, p. 5](lib:fireplaces-and-chimneys#page=5), [🖼️ p. 9](lib:fireplaces-and-chimneys#page=9) *(ignore its asbestos insulation)*; [Chimney](wiki:Chimney)
- Quake-damaged chimneys — [🖼️ FEMA 232, p. 144](lib:fema-232#page=144)
- Sill bolts and cripple-wall bracing — [🖼️ FEMA 232, p. 169](lib:fema-232#page=169), [🖼️ p. 171](lib:fema-232#page=171); [Seismic retrofit](wiki:Seismic_retrofit)
- Gutter debris and leaf guards — [🖼️ FEMA P-737, p. 45](lib:fema-p-737#page=45)
- Fixing plastic sheeting — [🖼️ *Plastic Sheeting*, p. 26](lib:plastic-sheeting#page=26), [🖼️ p. 27](lib:plastic-sheeting#page=27); [Tarpaulin](wiki:Tarpaulin)
- Poncho lean-to — [🖼️ FM 3-05.70, p. 69](lib:fm-3-05-70-survival-2002#page=69); [Lean-to](wiki:Lean-to)

---

## 🔗 Related guides

- [Natural Building](guide:NATURAL-BUILDING-GUIDE) — cob, straw bale, light clay, hempcrete, lime and earth plasters, thatch
- [Firewood guide](guide:FIREWOOD-GUIDE) — stoves, chimney cleaning, clearances and woodpiles
- [Blacksmithing and Hand Tools](guide:BLACKSMITHING-GUIDE) — axes, froes, saws and sharpening
- [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — heat, light and repairs without stores
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — defensible space and Cascadia
- [Bicycles, Carts and Hauling](guide:BICYCLES-CARTS-GUIDE) — moving lumber, logs and stone without fuel
- [Nuclear Fallout guide](guide:NUCLEAR-FALLOUT-GUIDE) — expedient shelters and shielding
