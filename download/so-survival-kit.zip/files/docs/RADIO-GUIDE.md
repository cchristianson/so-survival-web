# Emergency Radio Communications Guide
### Ham (Amateur), CB, Shortwave, GMRS/FRS & MURS — how they work and how to use them

This guide explains, in plain language, how to communicate by radio when the
internet and phones are down. It covers what each type of radio is, what it can do,
which frequencies/channels matter in an emergency, and the basic procedures for
calling for help.

> **Legal note (normal times):** Transmitting on **ham (amateur)** frequencies
> requires a license (easy to get — see below). **GMRS** requires a cheap license
> (no test). **CB, FRS, MURS** need **no license**. **Shortwave listening** needs no
> license (you're only receiving). **In a genuine life-or-death emergency, calling
> for help on whatever radio you have is generally accepted** (the ham rules, 47 CFR §97.405, say
> nothing in them stops a station in distress from using any means it has).
> Listening is always legal. Learn and practice *before* you need it.

---

## 1. The quick version — what to grab and what to know

| Need | Best tool | License | Range (typical) |
|---|---|---|---|
| Talk to family nearby (same property / neighborhood) | **FRS / GMRS** walkie-talkie ([FRS](wiki:Family_Radio_Service)) | FRS none; GMRS cheap | 0.5–2 mi (up to 5+ with GMRS + height) |
| Talk across town / coordinate a group | **GMRS** (with repeater) or **Ham VHF/UHF** ([GMRS](wiki:General_Mobile_Radio_Service)) | GMRS cheap; Ham test | 5–50 mi via repeater |
| Talk regionally / long distance / into other states | **Ham HF** ([Amateur radio](wiki:Amateur_radio)) | Ham (General class) | 100s–1000s mi |
| Hear news & official broadcasts from anywhere | **Shortwave receiver** ([Shortwave radio](wiki:Shortwave_radio)) | none (listening) | Worldwide |
| Road / vehicle convoy, truckers | **CB** ([Citizens band radio](wiki:Citizens_band_radio)) | none | 1–15 mi |

**Three things everyone should know:**
1. **Monitor, don't just transmit.** A cheap receiver tells you what's happening.
2. **Higher antenna = more range.** Antenna height matters more than watts
   ([🖼️ why: line-of-sight drawing](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=97)).
3. **Have a plan:** agree on a channel/frequency and check-in times with your group
   *in advance* (write them down — see the card at the end).

📚 **Go deeper:** [ARRL ARES Field Resources Manual, p. 6](lib:arrl-ares-field-resources-manual#page=6) — what to do first, checklists, message forms; [NOAA Weather Radio brochure](lib:noaa-weather-radio-all-hazards-brochure#page=2) — how alerts work.

---

## 2. In the Illinois Valley 🏔️

The valley is ringed by mountains ([Klamath Mountains](wiki:Klamath_Mountains)): **VHF/UHF needs a repeater on a peak**
([🖼️ why: radio waves travel in straight lines](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=97)), and NOAA warns
that **mountain valleys may get little or no weather radio** even inside the usual 40-mile
range ([NOAA brochure, p. 3](lib:noaa-weather-radio-all-hazards-brochure#page=3)).

- **Weather radio:** try Medford **162.400**, Mt. Ashland **162.475** and Brookings
  **162.550 MHz**; SAME code **041033**.
- **Ham:** JCEC repeater **145.490** (−, tone 136.5), Eight Dollar Mtn; net Mondays 8:00 pm.
- **No license:** Monday check-in on **FRS channel 3** and **MURS channel 3** after the
  7:00 pm IVARC net.
- **HF:** Oregon Emergency Net, nightly 6:00 pm, **3.980 MHz LSB**.

*(Club websites, Nov 2026 — verify. Full lists: [Illinois Valley guide](guide:ILLINOIS-VALLEY-START-HERE).)*

📚 **Go deeper:** [FM 24-18, p. 144](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=144) — radio in mountains; [FM 24-18, p. 102](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=102) — picking a radio site; [NOAA Weather Radio brochure, p. 3](lib:noaa-weather-radio-all-hazards-brochure#page=3) — reception in valleys.

---

## 3. How radio actually works (the 60-second version)

- A radio turns your voice into **radio waves** at a certain **frequency** (measured
  in kilohertz **kHz** or megahertz **MHz**). Another radio tuned to the same
  frequency turns the wave back into sound.
- **Both radios must be on the same frequency/channel AND the same mode** (e.g. FM,
  AM, SSB) to hear each other.
- **Only one person talks at a time.** You press **PTT** ([push-to-talk](wiki:Push-to-talk)) to transmit,
  release it to listen. You cannot hear others while you hold PTT.
- **Frequency bands** behave very differently:
  - **VHF/UHF (high frequency numbers, ~30 MHz–3 GHz):** travel in roughly straight
    "line of sight." Great locally, blocked by hills/buildings. Used by FRS, GMRS,
    MURS, and ham 2m/70cm. Extended by **repeaters** (see below).
  - **HF / shortwave (low numbers, ~3–30 MHz):** can **bounce off the ionosphere**
    and travel hundreds or thousands of miles ("skip"). Used by ham HF, CB (27 MHz),
    and shortwave broadcasters. Range changes with time of day and the sun.
    ([🖼️ ground waves and sky waves](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=94);
    [🖼️ layers of the ionosphere](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=100);
    [Ionosphere](wiki:Ionosphere), [Skywave](wiki:Skywave))
- **Skip zone:** HF can leave a **zone of silence** — a nearby station unheard while a far
  one is loud ([NEETS 10, p. 106](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=106);
  [🖼️ skip-zone drawing](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=106)).
- **Match the antenna:** vertical talks best to vertical, horizontal to horizontal
  ([FM 24-18, p. 45](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=45);
  [🖼️ polarization drawing](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=63)).
  Handhelds and car whips are vertical — hold the radio upright.

📚 **Go deeper:** [NEETS Module 10, p. 100](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=100) — the ionosphere by day and night; [NEETS Module 12](lib:neets-module-12-modulation) — AM, FM and SSB.

---

## 4. CB Radio (Citizens Band) — no license, simple, vehicle-friendly

- **What it is:** 40 channels around **27 MHz** (in the HF band). No license needed.
  Cheap, everywhere, popular with truckers and off-roaders.
- **Range:** usually **1–15 miles** (more in flat/open terrain; occasionally hundreds
  of miles when "skip" conditions bounce signals off the ionosphere).
- **Power limit:** 4 watts AM / 12 watts SSB (SSB radios reach farther).
- **Key channels:**
  - **Channel 9** — traditional **emergency / help** channel.
  - **Channel 19** — highway / trucker channel (road conditions, traffic, convoys).
  - **Channel 1–40** — general use; pick an unused one for your group.
- **Modes:** Most CB is **AM**. Higher-end radios add **SSB** (USB/LSB) for more
  range — but both radios must use the same mode ([Single-sideband modulation](wiki:Single-sideband_modulation)).
- **Good for:** vehicle-to-vehicle, convoys, short local coordination with zero setup
  ([🖼️ common whip antennas](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=74);
  [Whip antenna](wiki:Whip_antenna)).

📚 **Go deeper:** [FM 24-18, p. 55](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=55) — repairing a broken whip antenna ([🖼️ repair drawing](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=86)); [Citizens band radio](wiki:Citizens_band_radio) — channels, history and photos.

---

## 5. FRS / GMRS / MURS — the walkie-talkie families

These are the little handheld radios ("[walkie-talkies](wiki:Walkie-talkie)"). Great for family/group.

### FRS (Family Radio Service) — no license
- The blister-pack walkie-talkies ([Family Radio Service](wiki:Family_Radio_Service)). **22 channels** in **UHF (462/467 MHz)**.
- Low power (0.5–2 W), fixed antenna. **Range ~0.5–2 miles.**
- No license, no setup. Good for keeping a family/group in touch on foot.

### GMRS (General Mobile Radio Service) — cheap license, no test
- Shares channels with FRS but allows **higher power (up to 50 W)**, **detachable
  antennas**, and **repeaters** — so range can reach **5–50+ miles** via a repeater.
- One **GMRS license (~$35, no exam)** covers your **entire family** for 10 years.
- **Best all-round family emergency radio:** cheap, legal, powerful, easy
  ([General Mobile Radio Service](wiki:General_Mobile_Radio_Service)).

### MURS (Multi-Use Radio Service) — no license
- **5 channels** in **VHF (151/154 MHz)**, up to 2 W. No license ([Multi-Use Radio Service](wiki:Multi-Use_Radio_Service)).
- VHF often works better outdoors/rural than FRS/GMRS UHF. Good for property/farm.

**In hill country:** use high ground, get clear of buildings and leafy trees (they soak up
more signal than evergreens), and keep away from power lines
([🖼️ good radio sites](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=108);
[🖼️ poor radio sites](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=109)).

📚 **Go deeper:** [FM 24-18, p. 102](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=102) — choosing a good radio spot; [Walkie-talkie](wiki:Walkie-talkie) — photos of handheld radios.

---

## 6. Ham (Amateur) Radio — the serious emergency option

**Ham radio is the backbone of emergency communications.** When everything else
fails, hams relay health-and-welfare traffic, weather, and coordination across towns,
states, and continents ([Amateur radio](wiki:Amateur_radio);
[Amateur radio emergency communications](wiki:Amateur_radio_emergency_communications)).

### Licensing (USA) — easier than you think
Three license levels, each a multiple-choice test (questions are public — you can
study the exact pool):
1. **Technician** — entry level. Grants **VHF/UHF** (local, repeaters) plus some HF.
   Enough for local/regional emergency comms. ~1 evening of study.
2. **General** — adds most **HF** privileges → **long-distance / cross-country**.
3. **Amateur Extra** — full privileges.

> Get at least a **Technician** license now while it's easy, and ideally **General**
> so you can use HF for long distance. In a true life-or-death emergency, calling for
> help without a license is generally accepted (see 47 CFR §97.405) — but you'll be far more
> effective if you've practiced.

### The main ham bands and what they do
- **2 meters (144–148 MHz, VHF)** and **70 cm (420–450 MHz, UHF):** local
  simplex + **repeaters**. Your everyday "talk around town" bands.
- **HF bands (e.g. 80m, 40m, 20m):** long distance.
  - **40m (7 MHz):** reliable regional (100s of miles), day and night — great for a
    state/region emergency net.
  - **20m (14 MHz):** long-distance (cross-country / international) in daytime.
  - **80m (3.5 MHz):** regional at night.

### Repeaters — how hams get range from a handheld
A **repeater** is a radio on a tower/hilltop that **receives your weak signal and
re-transmits it with a big antenna and power**, massively extending range. To use one
you set your radio to the repeater's **output frequency**, an **offset** (so it
transmits on the input), and sometimes a **CTCSS "tone."** Local repeater lists
(and emergency nets) are worth printing out for your area ([Repeater](wiki:Repeater)).

### Simplex (radio-to-radio, no repeater)
If repeaters are down, you talk **simplex** — directly, radio to radio, line of sight.
The national 2m simplex calling frequency is **146.520 MHz**.

**Wilderness protocol:** back-country hams listen and call on **146.52** for **5 minutes at
the top of the hour, every 3 hours from 7 AM to 7 PM**, so someone beyond a repeater can be
relayed ([ARRL manual, p. 84](lib:arrl-ares-field-resources-manual#page=84)).

### HF from a valley: "NVIS"
A wire **dipole hung low — 1/10 to 1/4 of a wavelength up** (roughly 25–60 ft on 80m,
*worked from the formula in section 8*) sends its signal almost straight up; it comes back
down like a fountain over a few hundred miles **with no skip zone**, and the hills matter
much less ([FM 24-18, p. 279](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=279);
[🖼️ the "fountain" drawing](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=283);
[🖼️ Army NVIS antennas](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=83);
[Near vertical incidence skywave](wiki:Near_vertical_incidence_skywave)).

### Nets
A **net** is a scheduled on-air meeting. In a **directed** net a **net control station**
says who talks next. Listen first, check in when invited, keep a log, and tell net control
if you leave ([ARRL manual, p. 7, 18](lib:arrl-ares-field-resources-manual#page=18)).

### Ham digital & data (advanced, FYI)
Hams can also send text/email/images with no internet via **Winlink** (email over
radio), **FT8** (weak-signal), and **APRS** (position/text). Useful but needs more gear
and practice ([Winlink](wiki:Winlink), [FT8](wiki:FT8),
[APRS](wiki:Automatic_Packet_Reporting_System)).

📚 **Go deeper:** [ARRL manual, p. 14](lib:arrl-ares-field-resources-manual#page=14) — ARES, traffic nets and RACES; [FM 24-18, p. 278](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=278) — NVIS in full.

---

## 7. Shortwave (SWL) — hearing the outside world

- **What it is:** Using a **shortwave receiver** to *listen* to broadcasts on the HF
  bands (roughly **1.8–30 MHz**). **No license needed to listen.**
- **Why it matters:** When local media and internet are down, shortwave lets you hear
  **international news, government/emergency broadcasts, and ham traffic** from far
  away — because HF signals bounce worldwide.
- **What to listen for:**
  - **International broadcasters** (news from outside the affected area).
  - **NOAA Weather Radio** (VHF **162.400–162.550 MHz**) — continuous US weather &
    emergency alerts. *Every emergency kit should have a NOAA weather radio.*
  - **Ham bands** (40m/20m) — to hear emergency nets and relays.
  - **AM/FM broadcast** and **Emergency Alert System (EAS)** on a normal radio.
- **Modes:** Broadcasts are usually **AM**; ham/utility voice is often **SSB**
  (USB/LSB). A radio with SSB hears far more.
- **Tip:** A simple long wire antenna dramatically improves shortwave reception
  ([🖼️ long-wire antenna drawing](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=98)).
- **[NOAA Weather Radio](wiki:NOAA_Weather_Radio):** repeats every 4–6 minutes; a **SAME**
  radio set to your county code wakes up only for your county's alerts
  ([NOAA brochure, p. 2](lib:noaa-weather-radio-all-hazards-brochure#page=2);
  [Specific Area Message Encoding](wiki:Specific_Area_Message_Encoding)).
- **No batteries at all:** a [crystal radio](wiki:Crystal_radio) — wire, a homemade coil, a
  crystal detector and headphones — hears AM stations; in 1922 tests, high-power ones up to
  about 50 miles away ([NBS Circular 120, p. 4](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922#page=4);
  [🖼️ wiring diagram and parts](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922#page=12)).

📚 **Go deeper:** [NBS Circular 120](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922) — build a crystal set step by step; [NBS Circular 121](lib:nbs-circular-121-two-circuit-crystal-radio-receiver-1922) — a sharper version.

---

## 8. Antennas, power & range (the practical stuff)

- **Antenna height beats power.** Getting the antenna up high (roof, tree, mast) adds
  more range than buying a bigger amplifier.
- **Use the right antenna for the band.** A proper **resonant** antenna (correct
  length for the frequency) works far better than a random wire.
- **Line of sight (VHF/UHF):** range ≈ limited by the horizon and obstructions. Height
  = range. Repeaters overcome this.
- **HF skip:** range changes with the **time of day** and **solar conditions**. Lower
  bands (80m) are better at night; higher bands (20m) are better in daytime.
- **Power:** keep radios charged. Stock **spare batteries, a 12V battery, a solar
  panel, and car-charging cables.** A radio with a dead battery is a paperweight.
- **Grounding & safety:** never put an antenna where it can touch power lines; ground
  equipment to reduce static/lightning risk.
- **EMP and solar storms:** in government tests, most ham equipment wasn't damaged when its
  power cord was unplugged and the antenna coax disconnected
  ([NCS TIB 85-10, p. 166](lib:emp-and-transient-protection-devices-for-amateur-and-mars-radio-vol-1-ncs-tib-85-10-1985#page=166))
  — more in the **[EMP Guide](guide:EMP-GUIDE)**.

### Build a wire antenna (half-wave [dipole](wiki:Dipole_antenna))
Total length in feet = **468 ÷ MHz** (3–50 MHz; [FM 24-18, p. 47](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=47)),
cut in two equal halves with the coax at the center. 3.980 MHz (Oregon Emergency Net):
117.6 ft · 7.2 MHz: 65 ft · 14.3 MHz: 32.7 ft. Look first:
[🖼️ center-fed wire antenna between two supports](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=72),
[🖼️ improvised half-wave doublet](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=93),
[🖼️ how a dipole radiates](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=230).

1. Any wire works in an emergency; copper or aluminum is best.
2. **Insulators** at the ends and center — plastic or glass (plastic spoons, bottle necks)
   beat wood or rope. The wire must touch nothing else
   ([FM 24-18, p. 55](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=55);
   [🖼️ improvised insulators](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=87);
   [Insulator](wiki:Insulator_(electricity))).
3. Tie one end through a spring or strip of inner tube so swaying trees don't snap it.
4. Adjust length and height for the strongest signal from a distant station.
   ⚠️ **Transmitter off before touching the antenna** — it can cause serious injury
   ([p. 56](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=56)).

For 2m/70cm, a [J-pole](wiki:J-pole_antenna) from TV twin-lead is cheap
([ARRL manual, p. 12](lib:arrl-ares-field-resources-manual#page=12);
[🖼️ what twin-lead looks like](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=138);
[Twin-lead](wiki:Twin-lead)). Rocky mountain ground
is a poor ground, so use a dipole, or a vertical with a **counterpoise** — wires spread just
above the ground ([FM 24-18, p. 144](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=144);
[🖼️ wire counterpoise](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=66);
[🖼️ ground-plane antenna](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=77)).
Set up high on a slope, not in a ravine, and away from your own generator and battery
charger — they add noise ([p. 102–103](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=102)).

**Batteries:** a car battery survives only about 20 deep discharges; deep-cycle batteries
take 1,000 or more, and shallow use lasts far longer (about 800 cycles at 80% discharge vs
6,000 at 20%). Recharge stored sealed batteries about every 3 months. Charging batteries give
off **hydrogen** — no sparks or flames ([Practical Action, p. 5–6](lib:practical-action-batteries-technical-brief#page=5)).

**Lightning:** a lightning switch grounds the antenna whenever you're not using it — No. 14
or heavier copper wire to a water pipe or ground rod, **never a gas pipe**
([NBS Circular 120, p. 8](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922#page=8);
[Lightning arrester](wiki:Lightning_arrester)).

📚 **Go deeper:** [FM 24-18, p. 55](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=55) — field repair and expedient antennas; [NEETS Module 10](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=204) — how antennas work.

---

## 9. How to call for help (procedure)

1. **Listen first.** Make sure you're not interrupting other emergency traffic.
2. **Use the emergency call:**
   - Voice distress: say **"MAYDAY, MAYDAY, MAYDAY"** (life-threatening) or
     **"PAN-PAN"** (urgent but not immediately life-threatening), then your info
     ([Mayday](wiki:Mayday), [Pan-pan](wiki:Pan-pan)).
   - On CB, call on **Channel 9**. On ham, break into the local **emergency net** or
     call on a repeater / **146.520** simplex.
3. **Give the essentials — slowly, clearly, repeat:**
   - **Who** you are (name / call sign).
   - **Where** you are (address, cross-streets, GPS coords, landmarks).
   - **What** the emergency is (injury, fire, trapped, etc.).
   - **What** you need (medical, rescue, relay a message).
4. **Spell hard words with the phonetic alphabet** (below).
5. **Stay on, don't wander off frequency.** Keep the radio on so responders can
   call back. Repeat your message at intervals if no answer.

### NATO phonetic alphabet
Alpha Bravo Charlie Delta Echo Foxtrot Golf Hotel India Juliet Kilo Lima Mike
November Oscar Papa Quebec Romeo Sierra Tango Uniform Victor Whiskey X-ray Yankee
Zulu. Numbers: say digits individually ("one-two-zero"). ([NATO phonetic alphabet](wiki:NATO_phonetic_alphabet))

### Common "pro-words"
- **"Over"** = I'm done talking, your turn.
- **"Out"** = conversation finished (don't say "over and out").
- **"Roger" / "Copy"** = I received and understand.
- **"Say again"** = repeat (don't say "repeat").
- **"Affirmative / Negative"** = yes / no.
- **"Break"** = pause / someone with emergency traffic wants in.
  ([Procedure word](wiki:Procedure_word))

📚 **Go deeper:** [ARRL manual, p. 58](lib:arrl-ares-field-resources-manual#page=58) — procedure words, phonetic alphabet, signal reports; [Pub 102, pp. 148–149](lib:pub-102#page=148) — the international voice distress procedure, with worked Mayday examples.

---

## 10. Passing messages for others

Much of radio's work after a disaster is carrying short messages for people with no radio.
Send in this order ([ARRL manual, p. 36](lib:arrl-ares-field-resources-manual#page=36)):
**EMERGENCY** (life and death — when in doubt, don't) → **PRIORITY** (important,
time-limited) → **WELFARE** ("Is my family OK?" / "All well here") → **ROUTINE** (last).

- Write the message down first and count the words, so the receiver can check it
  ([🖼️ a filled-in radiogram, part by part](lib:arrl-ares-field-resources-manual#page=35)).
- Ready-made welfare texts include **"Everyone safe here. Please don't worry."**
  ([🖼️ blank welfare message form](lib:arrl-ares-field-resources-manual#page=33))
- Log the time, station, frequency and message.

📚 **Go deeper:** [ARRL manual, p. 33–34](lib:arrl-ares-field-resources-manual#page=34) — welfare form, standard texts, how to write a radiogram; [ICS 213 General Message form](lib:nims-ics-forms#page=65) — the standard paper form emergency offices use.

---

## 11. When the radio can't reach: signals without one

- **Three of anything** means distress: three fires in a triangle, three columns of smoke,
  three shots ([FM 21-76, p. 238–243](lib:fm-21-76-army-survival-manual#page=238)). In
  wildfire country keep signal fires small, cleared around and watched *(rule of thumb)*.
- A **whistle** is usually heard within about 200 yards (a few reports claim up to a mile —
  [AFH 10-644, p. 509](lib:afh-10-644#page=509)); a **mirror** is the best signal on a sunny day
  ([🖼️ aiming a signal mirror](lib:afh-10-644#page=510)).
  **SOS:** three short, three long, three short ([SOS](wiki:SOS)).
- **Ground-to-air symbols** in a clearing: **V** = need help · **X** = need medical help ·
  **N** = no · **Y** = yes · **arrow** = going this way. Make them at least 6 m (20 ft) long
  (the two Army manuals differ on width) ([FM 3-05.70, p. 329](lib:fm-3-05-70-survival-2002#page=329);
  [🖼️ the symbols drawn](lib:fm-3-05-70-survival-2002#page=329)).

📚 **Go deeper:** [FM 3-05.70, p. 318](lib:fm-3-05-70-survival-2002#page=318) — signaling devices and how to use them; [Signals and Morse guide](guide:SIGNALS-MORSE-GUIDE) — mirrors, ground symbols, Morse by light and sound; [AFH 10-644, p. 509](lib:afh-10-644#page=509) — the Air Force signaling chapter, with pictures.

---

## 12. If this goes wrong

| Problem | Try this |
|---|---|
| Nobody answers | Get higher and clear of buildings and leafy trees; hold the radio upright; try a repeater |
| Repeater ignores you | Check the offset and tone |
| Two radios won't talk | Same channel *and* same mode? Same privacy code on FRS? |
| HF is dead | Lower band at night, higher in daytime *(rule of thumb)* |
| Buzz or hum | Move away from power lines, generators, chargers ([FM 24-18, p. 103](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=103)) |
| Broken antenna | Splice it, or replace with wire of the same length ([🖼️ whip repair drawing](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=86)) |
| Battery dies fast | Lower power, transmit less, listen at set times |

📚 **Go deeper:** [FM 24-18, p. 106](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=106) — sources of interference; [FM 24-18, p. 55](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=55) — field repair of antennas, guys and masts.

---

## 13. A sensible emergency radio kit (shopping / checklist)

- [ ] **NOAA weather radio** (hand-crank/solar + battery) — alerts & forecasts.
- [ ] **Shortwave receiver with SSB** — hear news & ham traffic worldwide (RX only).
- [ ] **A pair+ of GMRS radios** (and a **GMRS license**) — family/group, best bang
      for buck. FRS works with no license at shorter range.
- [ ] **A dual-band (2m/70cm) ham handheld (HT)** — cheap; huge capability with a
      Technician license. Add a better antenna.
- [ ] **(Advanced) An HF ham radio** + General license — true long distance.
- [ ] **CB** if you travel by vehicle/convoy.
- [ ] **Power:** spare batteries, 12V battery, **solar panel**, car charger ([Solar panel](wiki:Solar_panel)).
- [ ] **Better antennas** + coax; a roll of wire for an HF/long-wire antenna ([Coaxial cable](wiki:Coaxial_cable)).
- [ ] **Printed frequency card** (below), local repeater list, notebook & pencil.
- [ ] **Go-bag extras:** earphone, mag-mount antenna, 50 ft of coax with barrel
      connectors, alkaline pack for the handheld.

📚 **Go deeper:** [ARRL manual, p. 10–12](lib:arrl-ares-field-resources-manual#page=10) — basic and 72-hour go-kit checklists; [Amateur Radio Emergency Service](wiki:Amateur_Radio_Emergency_Service) — how volunteer emergency hams are organized.

---

## 14. Print-and-keep frequency card

Fill in your group's agreed channels and local repeaters, then print this page.

```
=====================  EMERGENCY RADIO CARD  =====================
 Our group PRIMARY channel : _______________   Mode: _______
 Our group BACKUP channel  : _______________   Mode: _______
 Check-in times (daily)    : _______  _______  _______

 CB emergency / help ....... Channel 9
 CB highway / travel ....... Channel 19
 Ham 2m simplex calling .... 146.520 MHz  (FM)
 Wilderness protocol ....... 146.520 - 5 min at top of hour,
                             every 3 hrs, 7 AM to 7 PM
 NOAA Weather Radio ........ 162.400 / 162.425 / 162.450 /
                             162.475 / 162.500 / 162.525 / 162.550 MHz
 FRS/GMRS family channel ... _______   (GMRS license #: __________)

 Local repeaters (output / offset / tone):
   1) ________ MHz  /  ____  /  tone ______  (____________)
   2) ________ MHz  /  ____  /  tone ______  (____________)
   3) ________ MHz  /  ____  /  tone ______  (____________)

 Distress voice: "MAYDAY x3" (life threat) or "PAN-PAN x3" (urgent)
 Say: WHO you are - WHERE you are - WHAT's wrong - WHAT you need
 No radio? Three fires / three shots / ground symbols V and X
==================================================================
```

📚 **Go deeper:** [ARRL manual, p. 59](lib:arrl-ares-field-resources-manual#page=59) — a phonetic alphabet to print alongside; [NOAA Weather Radio brochure, p. 2](lib:noaa-weather-radio-all-hazards-brochure#page=2) — how the broadcasts and SAME county codes work, with station frequencies.

---

## 15. Where to learn more offline (already in this kit)

- **Appropedia** and **iFixit** archives (in `E:\OfflineLibrary\Manuals\`, via the Kiwix reader)
  include antenna, electronics and repair articles.
- **Radio books** in `Southern-Oregon\Electronics-Repair\` and `Southern-Oregon\Radio-Weather\`:
  *FM 24-18*, the Navy NEETS modules, the ARRL field manual (links above).
- **WikiMed / Wikipedia-medicine** (`E:\OfflineLibrary\Medical\`) for treating injuries while you
  wait for help — start with the [Medical guide](guide:Medical-READ-ME-FIRST).
- Study the **ham license question pools** (download them now while you have internet;
  the exact questions and answers are public) so you can get licensed quickly.

> Practice now: tune around, learn your radios' menus, program the channels above, and
> do a test check-in with your group. Skills and muscle memory matter more than gear.

📚 **Go deeper:** [NEETS Module 17](lib:neets-module-17-radio-frequency-communications-principles) — how radio systems work; [NASA hand soldering workbook](lib:nasa-hand-soldering-student-workbook) — repairing radios and cables.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**How radio travels**
- Ground waves and sky waves — [🖼️ NEETS 10, p. 94](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=94); [Skywave](wiki:Skywave)
- Layers of the ionosphere — [🖼️ NEETS 10, p. 100](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=100); [🖼️ FM 24-18, p. 34](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=34); [Ionosphere](wiki:Ionosphere)
- The skip zone — [🖼️ NEETS 10, p. 106](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=106)
- Line of sight for VHF/UHF — [🖼️ NEETS 10, p. 97](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=97); [Line-of-sight propagation](wiki:Line-of-sight_propagation)
- Vertical and horizontal antennas — [🖼️ FM 24-18, p. 63](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=63); [Polarization](wiki:Polarization_(waves))

**The radios**
- CB radio and whip antennas — [🖼️ FM 24-18, p. 74](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=74); [Citizens band radio](wiki:Citizens_band_radio); [Whip antenna](wiki:Whip_antenna)
- FRS, GMRS and MURS handhelds — [Walkie-talkie](wiki:Walkie-talkie); [Family Radio Service](wiki:Family_Radio_Service); [General Mobile Radio Service](wiki:General_Mobile_Radio_Service); [Multi-Use Radio Service](wiki:Multi-Use_Radio_Service)
- Ham radio and repeaters — [Amateur radio](wiki:Amateur_radio); [Repeater](wiki:Repeater)
- Shortwave and weather radios — [Shortwave radio](wiki:Shortwave_radio); [NOAA Weather Radio](wiki:NOAA_Weather_Radio)
- Homemade crystal set — [🖼️ NBS Circular 120, p. 12](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922#page=12); [Crystal radio](wiki:Crystal_radio)

**Antennas you can build**
- Wire dipole between two supports — [🖼️ FM 24-18, p. 72](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=72); [Dipole antenna](wiki:Dipole_antenna)
- Improvised half-wave doublet and center-fed antennas — [🖼️ FM 24-18, p. 93](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=93); [🖼️ p. 94](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=94)
- How a dipole radiates — [🖼️ NEETS 10, p. 230](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=230)
- Improvised insulators — [🖼️ FM 24-18, p. 87](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=87)
- End-fed half-wave and long-wire antennas — [🖼️ FM 24-18, p. 92](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=92); [🖼️ p. 98](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=98)
- Vertical half-wave hung from a tree — [🖼️ FM 24-18, p. 96](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=96)
- Ground-plane antenna and counterpoise — [🖼️ FM 24-18, p. 77](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=77); [🖼️ p. 66](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=66); [🖼️ NEETS 10, p. 233](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=233); [🖼️ p. 270](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=270)
- J-pole from twin-lead — [🖼️ twin-lead, NEETS 10, p. 138](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=138); [J-pole antenna](wiki:J-pole_antenna); [Twin-lead](wiki:Twin-lead)
- Coax — [🖼️ NEETS 10, p. 141](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=141); [Coaxial cable](wiki:Coaxial_cable)
- NVIS: a low dipole for valley-to-valley HF — [🖼️ FM 24-18, p. 283](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=283); [🖼️ p. 83](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=83); [Near vertical incidence skywave](wiki:Near_vertical_incidence_skywave)

**Siting and repair**
- Good and poor radio sites — [🖼️ FM 24-18, p. 108](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=108); [🖼️ p. 109](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=109)
- Splicing a broken whip — [🖼️ FM 24-18, p. 86](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=86)
- Lightning protection — [Lightning arrester](wiki:Lightning_arrester)

**Calling for help and passing messages**
- Distress words and spelling — [Mayday](wiki:Mayday); [Pan-pan](wiki:Pan-pan); [NATO phonetic alphabet](wiki:NATO_phonetic_alphabet)
- Radiogram and welfare forms — [🖼️ ARRL manual, p. 35](lib:arrl-ares-field-resources-manual#page=35); [🖼️ p. 33](lib:arrl-ares-field-resources-manual#page=33)
- ICS 213 message form — [🖼️ ICS Forms Booklet, p. 65](lib:nims-ics-forms#page=65)
- Ground-to-air symbols and mirror aiming — [🖼️ FM 3-05.70, p. 329](lib:fm-3-05-70-survival-2002#page=329); [🖼️ AFH 10-644, p. 510](lib:afh-10-644#page=510)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local repeaters, nets, weather-radio stations and contacts
- [Medical guide](guide:Medical-READ-ME-FIRST) — first aid while you wait for help
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — charging batteries from a generator or alternator
- [Fuel Guide](guide:FUEL-GUIDE) — keeping a generator running
- [Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE) — staying informed while sheltering
- [EMP Guide](guide:EMP-GUIDE) — protecting radios and batteries from an EMP or solar storm
