# 🏔️ Illinois Valley — START HERE

Local quick reference for **Cave Junction, Kerby, Selma, O'Brien, Takilma** and the rest of
the Illinois Valley (Josephine County, southern Oregon). Every local map and guide on this
drive is listed, with a one-line description, in **[LOCAL-FILES.html](LOCAL-FILES.html)**
(same folder as this page).

> **Built for the long haul.** This pack is meant to stay useful even if normal services,
> stores and law enforcement are gone. Practical how-to comes first; where laws and seasons
> matter *while they're still enforced*, there's a short note.
>
> **How current is this?** Gathered in **November 2026** from official sources (county,
> state, NOAA, ODFW, Forest Service, club websites). Phone numbers, radio nets and seasons
> change. Anything marked *(verify)* came from a less official source.

---

## ✅ Do these NOW, while you still have internet

1. **Sign up for Josephine County "Citizen Alert"** (free; calls, texts and emails about
   evacuations): <https://member.everbridge.net/1332612387832182/login>. Landlines in the
   area get called automatically, but **cell phones and email only if you register them**.
   You can add up to 5 addresses in Josephine or Jackson County.
   Also text your ZIP code to **888777** for Oregon state alerts (ORAlert.gov).
2. **Look up your evacuation zone** at <https://protect.genasys.com/search> and write it
   here: ____________
3. **Test a weather radio at home** — see *Radio & weather* below. NOAA's official coverage
   list shows **no transmitter covering the Illinois Valley**, so find out now what you can
   actually hear.
4. **[Phone apps](guide:USE-ON-PHONE):** install **Kiwix** and **OsmAnd** (iPhone: App Store), and **Avenza Maps**
   (it shows your GPS position on the topo PDFs in `Maps\`, with no cell service).
5. **Try the [Library Assistant](guide:HOW-TO-RUN-OFFLINE-AI) on your laptop:** double-click
   **`START-Windows`** (or **`START-Mac`**) at the top of the drive. It's one search box for
   everything here (including this folder and Wikipedia), and it answers with sources. Ask it a few things now so you know how
   long answers take on your machine.
6. **Print** this page and `Earthquake-Tsunami\`
   [Oregon OEM *My Pocket Plan* 2023](lib:oregon-oem-my-pocket-plan-2023)
   (fill it in — meeting places, out-of-area contact).
7. If someone in your home would need help evacuating, join the **Disaster Registry**:
   RVCOG Senior & Disability Services, **(541) 664-6674**.

📚 **Go deeper:** [Be 2 Weeks Ready toolkit](lib:oregon-be-2-weeks-ready-complete-toolkit) — water, food and family plans step by step; [FEMA *Are You Ready?*](lib:fema-are-you-ready-citizen-preparedness-guide-2020) — the national checklist.

---

## 📻 Radio & weather

### NOAA Weather Radio

| Station | Frequency | Transmitter | Notes |
|---|---|---|---|
| WXL85 | **162.400 MHz** | Medford (Nugget Butte) | Officially covers *eastern* Josephine County |
| WWF97 | **162.475 MHz** | Mt. Ashland | |
| KIH37 | **162.550 MHz** | Palmer Butte, near Brookings | Coast — Curry and Del Norte alerts, not Josephine |

- **SAME code** to program a weather radio for Josephine County: **041033**.
  Neighbors: Jackson 041029 · Curry 041015 · Del Norte CA 006015 · Siskiyou CA 006093.
- ⚠️ No NOAA transmitter is officially listed for western Josephine County (where the
  Illinois Valley is). Try all three frequencies at home and note which one works:
  ____________
- NWS Medford weather-radio questions: (541) 773-1067.
  *(Sources: weather.gov/mfr/nwr, weather.gov/nwr county coverage.)*

### AM / FM / TV for local news and emergency alerts

The county's official emergency media list: **KOBI, KTVL, KDRV** (TV) · **KLDR, KAJO, KXCJ**
(radio) · *Illinois Valley News*.

| Station | Where | Notes |
|---|---|---|
| **KXCJ 105.7 FM** (also 101.3 FM) | Cave Junction | Volunteer Illinois Valley community radio |
| **KCNA 102.7 FM** | Cave Junction | Carries Emergency Alert System messages |
| **JPR 89.5 FM / 90.9 FM** | Cave Junction | Jefferson Public Radio (Classics & News / Rhythm & News) |
| **KAGI 930 AM / 97.9 FM** | Grants Pass | JPR News & Information |
| **KAJO 1270 AM** (also 99.7 FM) | Grants Pass | Named on the county's emergency media list |
| **KLDR 98.3 FM** | Grants Pass area | Named on the county's emergency media list |
| **KOBI-TV Ch. 5** (Ch. 49 Grants Pass) | Medford | The area's main Emergency Alert System station |
| Heading south on US-199 | | JPR 89.1 Gasquet · KHEC 91.1 Crescent City · KPOD 1240 AM Crescent City |

*(Sources: Josephine County "Stay Informed" page; Oregon EAS Plan 2022; FCC station records; ijpr.org.)*

### Ham radio, GMRS, FRS / MURS *(club websites, Nov 2026 — verify)*

**Josephine County Emergency Communications (JCEC) linked repeaters** — all linked together:

| Frequency | Offset | Tone | Site |
|---|---|---|---|
| **145.490** | − | 136.5 | **Eight Dollar Mtn** — closest to Selma / Kerby / Cave Junction |
| 146.640 | − | 136.5 | Fiddler Mtn |
| 145.150 | − | 162.2 | Onion Mtn |
| 146.760 | − | 136.5 | Fielder |
| 146.270 | − | 136.5 | Elk Mt. |
| 146.860 | − | 136.5 | Big Meadow |
| 147.140 | + | 162.2 | Bluey Mt. |
| 147.340 | + | 136.5 | King Mt. |
| 147.300 | + | 136.5 | Gilbert Peak (Southern Oregon ARC club repeater) |

**Regular nets** (good to listen to now, so you know the voices and the routine):

- **JCEC net:** Mondays 8:00 pm on the linked repeaters. First Monday of the month:
  simplex **146.460** (no tone).
- **Southern Oregon ARC net:** Mondays 7:30 pm, 147.300.
- **Illinois Valley ARC (IVARC):** Mondays 7:00 pm on GMRS repeater **462.600** (tone 141.3,
  Eight Dollar Mtn). It's followed by a **"Channel 3 Project" check-in on FRS channel 3
  (462.6125) and MURS channel 3 (151.940)** — **no license needed** for FRS or MURS.
  Wednesdays 7:00 pm: ham simplex 146.420.
- **HF:** District 5 ARES, Sundays 4:30 pm, 3.964 MHz LSB · Oregon Emergency Net, nightly
  6:00 pm, 3.980 MHz LSB.
- While the FCC still functions, **ham radio** and **GMRS** need a license (**FRS** and
  **MURS** don't), and in a life-threatening emergency any radio may be used to call for help.
  Either way: **listen first** — the nets above tell you who is organized and where.

*(Sources: soarc.org/repeaters and /nets; ivarc.org. More detail on radio in the
**[Radio Guide](guide:RADIO-GUIDE)** and the ARRL guides in `Radio-Weather\`. Protecting radios
from an EMP or solar storm: **[EMP Guide](guide:EMP-GUIDE)**.)*

**No radio, or no one to call?** Morse code by flashlight, horn or mirror, the ground-to-air
distress symbols, signal fires (careful in fire season), runners and written message forms:
**[Signals & Morse Code](guide:SIGNALS-MORSE-GUIDE)**. Organizing the neighbors (OK/HELP cards, a
meeting spot, a skills list): **[Community & Barter](guide:COMMUNITY-BARTER-GUIDE)**.

📚 **Go deeper:** [NOAA Weather Radio brochure, p. 3](lib:noaa-weather-radio-all-hazards-brochure#page=3) — Oregon transmitters, and why mountain valleys get poor reception; [ARRL ARES Field Resources Manual](lib:arrl-ares-field-resources-manual) — nets, message forms, go-kit lists; [ARRL ARES Plan](lib:arrl-ares-plan-july-2025) — how ARES works with the county.

---

## ☎️ Local contacts

| Who | Phone | Notes |
|---|---|---|
| **Emergency** | **911** | |
| Josephine County Emergency Management | (541) 474-5300 | 250 Tech Way, Grants Pass |
| Sheriff — non-emergency | (541) 474-5123, option 3 | Cave Junction substation: 222 Lister St, (541) 592-5151 |
| Illinois Valley Fire District | (541) 592-2225 | 681 Caves Hwy, Cave Junction |
| Burn information line | (541) 476-9663 | Josephine County daily burn status |
| Oregon State Police — non-emergency | *OSP (*677) from a cell · 800-442-2068 | |
| **Asante Three Rivers Medical Center** (ER, 24/7) | (541) 472-7000 | 500 SW Ramsey Ave, Grants Pass |
| **Sutter Coast Hospital** (ER, 24/7) | (707) 464-8511 | 800 E Washington Blvd, Crescent City CA |
| Siskiyou Community Health Center — walk-in | (541) 592-4111 | 25647 Redwood Hwy, Cave Junction, Mon–Fri 8–5. *There is no 24-hour ER in the Illinois Valley.* |
| **Oregon Poison Center** | **1-800-222-1222** | 24/7 |
| Josephine County Public Health | (541) 474-5325 | Answered 24/7 |
| Road conditions | 511 · 800-977-6368 · Caltrans (800) 427-7623 | TripCheck.com |
| Pacific Power outages | 1-877-508-5088 · text OUT to 722797 | |
| American Red Cross | 1-800-733-2767 | |
| 211info (help finding services) | 211 · 866-698-6155 · text ZIP to 898211 | |
| Oregon Caves National Monument | (541) 592-5125 | 19000 Caves Hwy |
| Dr. Joe's Pet Hospital (dogs & cats) | (541) 592-4589 | 369 Caves Hwy, Cave Junction, Mon–Thu |
| Crossroads Animal Hospital | (541) 592-3222 | 421 Caves Hwy, Cave Junction *(verify)* |
| Massie Vet — mobile large & small animal | (541) 636-1191 (call/text) | Central Point; ask whether they reach Cave Junction |
| **Southern Oregon Veterinary Specialty Center** (pets, **24/7** ER) | (541) 282-7711 | 4901 Biddle Rd, Central Point |
| OSU large-animal hospital (24/7 phone advice) | (541) 737-2858 | Corvallis |
| Oregon State Veterinarian (sick/dead livestock reports) | 503-986-4711 · 1-800-347-7028 | |
| Forest Service — Wild Rivers Ranger District | (541) 592-4000 | 26568 Redwood Hwy, Cave Junction |
| ODFW — Central Point office | (541) 826-8774 | 1495 E Gregory Rd, Central Point |
| OSP poaching tip line (TIP) | 1-800-452-7888 · *OSP | |
| OSU Extension — Josephine County | (541) 241-3050 | 3345 Redwood Hwy, Grants Pass — gardening & canning help |

When no one can come, first aid and medicines: **[Medical guide](guide:Medical-READ-ME-FIRST)**.

Bleeding, wounds, burns, broken bones, snakebite and nursing someone for weeks with no hospital:
**[Injuries & Illness When No Help Is Coming](guide:FIELD-CARE-GUIDE)**.

Birth with no hospital, newborn care, childhood illness and teaching children at home:
**[Childbirth, Newborns & Young Children](guide:CHILDBIRTH-CHILDREN-GUIDE)**.

📚 **Go deeper:** [Josephine County Emergency Operations Plan 2025](lib:josephine-county-emergency-operations-plan-2025) — who does what in a county emergency; [Where There Is No Animal Doctor](lib:where-there-is-no-animal-doctor-cvm-2024) — when the vet can't come.

---

## 🔥 Wildfire

### Evacuation levels (Josephine County)

| Level | Means | Do |
|---|---|---|
| **1 — BE READY** (green) | Danger in the area | Pack, plan your route, move people with special needs, pets and livestock **early**. |
| **2 — BE SET** (yellow) | Significant danger | Be ready to leave **at a moment's notice**. Leaving now is fine. *"This may be the only notice you receive."* |
| **3 — GO NOW** (red) | Leave immediately | Don't stop to gather things or protect the house. *"This will be the last notice you receive."* |

The state's advice: **leave whenever you feel unsafe — you don't need to wait for a notice.**
Alerts come by Citizen Alert, Wireless Emergency Alerts on phones, radio/TV, door-to-door,
and ham radio.

### Go-kit (Oregon OEM checklist)
Medications and medical devices · glasses · food and plenty of water · important documents ·
phone chargers · battery AM/FM radio · first-aid kit · flashlight · **N95 masks** · long
sleeves, long pants, sturdy shoes, hat. Plan **two routes out**. Move livestock early.

### Around the house (defensible space)
- First **5 ft** around the house ([🖼️ the three zones](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=23)): nothing that burns. Firewood and lumber **30 ft** away
  ([OSFM, p. 13](lib:osfm-defensible-space-homeowner-guide-2025#page=13); the ODF Josephine
  County handout says at least 20 ft).
- Within **100 ft**: grass mowed to 4 in or less, 10 ft between tree crowns, limbs 10 ft
  from the chimney, no "ladder fuels" (brush under trees — [🖼️ drawing](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=21)).
- Clean roofs and gutters; cover vents with **1/8-inch metal mesh** ([🖼️ how embers get in](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=40)); clear around propane
  tanks; keep the driveway clear enough for a fire engine.

### Smoke
Make one **cleaner-air room** (windows shut, AC on recirculate). A DIY air cleaner = a box
fan (made 2012 or later, UL/ETL label) + a **MERV-13** furnace filter. Unplug it when you
leave the house. Use N95 masks outdoors.

Details: the `Wildfire\` folder ([Ready-Set-Go guide](lib:ready-set-go-wildland-fire-action-guide-iafc-10th-edition),
[OSFM defensible-space guide](lib:osfm-defensible-space-homeowner-guide-2025), [OSU
fire-resistant plants](lib:osu-pnw-590-fire-resistant-plants-for-home-landscapes),
[EPA](lib:epa-how-to-create-a-cleaner-air-room-at-home)/[OHA](lib:oha-diy-box-fan-air-filter-fact-sheet)
smoke sheets). Fire news: swofire.com (ODF Southwest Oregon).

📚 **Go deeper:** [Evacuation levels flyer](lib:oregon-evacuation-levels-flyer-be-ready-be-set-go-now) and [checklist](lib:oregon-wildfire-evacuation-checklist) — print for the fridge; [ODF Josephine County handout](lib:odf-defensible-space-handout-josephine-county) — defensible space on one page; [EPA Wildfire Smoke Guide, p. 61](lib:epa-wildfire-smoke-guide-2026#page=61) — setting up a cleaner-air room; [Wildfire prep for pets and livestock](lib:wildfire-prep-for-pets-and-livestock-oregon-oda).

---

## 🌎 Earthquake (Cascadia) and tsunami

- A [Cascadia](wiki:Cascadia_subduction_zone) magnitude-9 quake would shake for **4–6 minutes**, with aftershocks for months
  ([CREW scenario, p. 10](lib:crew-cascadia-m9-earthquake-scenario#page=10)).
  **Drop, Cover, Hold On.**
- Expect **[landslides](wiki:Landslide)** on mountain roads and damage to bridges. Coast-to-inland routes like
  **US-199** are exactly the kind expected to be cut, so the valley may be isolated for a long
  time.
- State estimates for inland western Oregon: **power out 1–3 months**, water/sewer 1 month to
  1 year, main highways 6–12 months to partly reopen, **fuel shortages** (Oregon's fuel hub
  is near Portland) ([Oregon Resilience Plan, p. 6](lib:oregon-resilience-plan-executive-summary-cascadia#page=6)).
- Plan to be on your own for **at least 2 weeks** — longer in rural areas.
- **At the coast** (Brookings, Gold Beach, Crescent City): if you feel a long quake, **walk**
  to high ground immediately. The first waves can arrive in **15–30 minutes**; surges continue
  12+ hours and the first is not the largest.

Details: `Earthquake-Tsunami\` ([Living on Shaky Ground](lib:living-on-shaky-ground-oregon-earthquake-and-tsunami-guide),
[2 Weeks Ready toolkit](lib:oregon-be-2-weeks-ready-complete-toolkit), [Cascadia
scenario](lib:crew-cascadia-m9-earthquake-scenario), tsunami evacuation maps for
[Brookings-Harbor](lib:dogami-tsunami-evacuation-brochure-brookings-harbor),
[Gold Beach](lib:dogami-tsunami-evacuation-brochure-gold-beach),
[Crescent City](lib:crescent-city-ca-tsunami-evacuation-brochure),
[Smith River](lib:smith-river-ca-tsunami-evacuation-brochure)).

Bolting the house to its foundation, bracing cripple walls, chimneys, roof and window repair,
and building with logs or earth: **[Shelter, Building & Repair](guide:SHELTER-BUILDING-GUIDE)**. Cob, straw bale,
clay and lime plasters, and which natural walls stand up to a quake: **[Natural Building](guide:NATURAL-BUILDING-GUIDE)**.

📚 **Go deeper:** [FEMA P-530 Earthquake Safety at Home](lib:fema-p-530-earthquake-safety-at-home) — strapping the water heater, bolting the house; [Living on Shaky Ground](lib:living-on-shaky-ground-oregon-earthquake-and-tsunami-guide) — Oregon's quake and tsunami guide.

## ☢️ Nuclear fallout

- **Get inside, stay inside, stay tuned.** Fallout is dust; put mass between you and the roof
  and outside walls ([🖼️ drawing](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=24)). It loses **90% of its strength in 7 hours and 99% in 2 days**
  ([FEMA H-20, p. 8](lib:protection-in-the-nuclear-age-fema-h-20-1985#page=8)).
- **A one-story wood house with no basement is poor shelter.** Know now where you'd go: a
  basement or masonry building nearby, a shielded crawl space, or a trench shelter.
- **Potassium iodide (KI)** protects only the thyroid, from radioactive iodine — adults 130 mg,
  children less ([FDA, p. 9](lib:potassium-iodide-as-a-thyroid-blocking-agent-dosing-guidance-fda-2001#page=9)).
- Everything else — shielding, how long to stay in, decontamination, food, water, livestock,
  homemade fallout meter: **[Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE)** and
  `Nuclear-Radiation\`.

📚 **Go deeper:** [CDC: Get Inside, Stay Inside, Stay Tuned](lib:where-to-go-in-a-radiation-emergency-get-inside-stay-inside-stay-tuned-cdc) — where to shelter, on one page; [Nuclear War Survival Skills](lib:nuclear-war-survival-skills-1987-updated-edition-kearny-oism) — expedient shelters and fallout meters.

---

## 🗺️ Maps

**Topo maps** (`Maps\Topo-USGS`, `Maps\Forest-Service`) are **GeoPDFs**: open them in the
free **Adobe Acrobat Reader** on a PC (the Layers panel turns contours, roads and aerial
photos on/off; the Measure tool → *Geospatial Location* shows latitude/longitude), or in
**Avenza Maps** on a phone to see your live GPS position. **FSTopo** maps show **Forest Service
road numbers and trails**; the **USGS** maps are the standard topo series.

Which map covers what (north at top):

| | West ← | | | | | → East |
|---|---|---|---|---|---|---|
| **North** | Silver Peak | York Butte | Chrome Ridge (Briggs Valley) | Onion Mtn | Wilderville | Grants Pass |
| | Tincup Peak | Pearsoll Peak (Illinois River Falls) | Eight Dollar Mtn | **Selma** (Lake Selmac, Wonder) | Murphy Mtn | Murphy |
| | Chetco Peak (Vulcan Lake) | Josephine Mtn (Babyfoot Lake) | **Cave Junction** (Kerby) | Holland | Kerby Peak | Williams |
| | Biscuit Hill | Buckskin Peak | **O'Brien** | **Takilma** | Oregon Caves | Grayback Mtn |
| **South (CA)** | High Plateau Mtn | Shelly Creek Ridge | Broken Rib Mtn (US-199 tunnel) | Polar Bear Mtn | Deadman Point | Figurehead Mtn |

Big-picture maps: [USFS Wild Rivers Ranger District Map](lib:usfs-wild-rivers-ranger-district-map-1-63360-2025) (whole district, 1 inch = 1 mile)
and [USFS Grants Pass 1-100000 Map](lib:usfs-grants-pass-1-100000-map-2025) (the whole valley on one sheet). Road maps: the ODOT
Josephine County sheets (`Maps\Road`; [Illinois Valley sheet](lib:odot-josephine-county-sheet-3-illinois-valley-2024)). Street maps for the whole US are also in the main
`OsmAnd\` folder ([how to view them](guide:HOW-TO-VIEW-MAPS)).

**Forest roads:** the **[Motor Vehicle Use Maps (MVUM)](lib:usfs-mvum-wild-rivers-ranger-district-2019)** show which forest roads are
drivable and by what kind of vehicle — useful for knowing which roads are real roads.
Road signs: **2-digit** numbers = main roads passable by cars; **4-digit horizontal** = other
car-passable roads; **vertical** markers = *not* maintained for passenger cars.

**[Kalmiopsis Wilderness](wiki:Kalmiopsis_Wilderness):** 180,000 acres, 500–5,098 ft (Pearsoll Peak). No motors or bikes;
groups of no more than 12 people / 9 stock; trails are rough with standing dead trees from
past fires.

📚 **Go deeper:** [FSTopo Cave Junction](lib:fstopo-cave-junction-or-2025) — the valley floor with Forest Service road numbers; [Eight Dollar Mountain trails](lib:blm-eight-dollar-mountain-and-jeffrey-pine-loop-trails); [FM 21-76, p. 231](lib:fm-21-76-army-survival-manual#page=231) — finding direction without a compass.

---

## 🦌 Hunting and 🎣 Fishing

> **While seasons and tags are still enforced,** the 2026 rule booklets are in `Hunting\`
> and `Fishing\` ([big game](lib:odfw-2026-big-game-hunting-regulations), [fishing](lib:odfw-2026-oregon-sport-fishing-regulations)) (the 2027 big game and fishing booklets come out around December 2026 — see
> *Keeping this current*). With or without rules, the units, waters and seasons below tell
> you **where game and fish are, and when** — and leaving breeding animals and spawning
> runs alone is what keeps them there next year.

**Hunting units:** **US-199 is the line.** West of the highway (Illinois River canyon,
Kalmiopsis) is **[Chetco Unit 27](lib:odfw-chetco-unit-27-map-2026)** (82% public land). East of it (Lake Selmac, Takilma, Oregon
Caves, Williams) is **[Applegate Unit 28](lib:odfw-applegate-unit-28-map)** (57% public land). In Cave Junction, Kerby, Selma
and O'Brien, which side of the highway you're on decides the unit. North of the Rogue at
Grants Pass is [Evans Creek Unit 29](lib:odfw-evans-creek-unit-29-map).

**2026 general seasons, for orientation** (check the current booklet):
western Oregon buck rifle Oct 3–Nov 6 · archery deer & elk Aug 29–Sep 27 · Unit 28 coast
elk rifle Nov 14–17 and Nov 21–27 (Unit 27 is controlled hunts only) · black bear Aug 1–Dec 31
· cougar all year (quotas) — **bear and cougar must be checked in at ODFW within 10 days** ·
grouse and quail Sep 1–Jan 31 · fall turkey Sep 1–Jan 31 · spring turkey Apr 15–May 31.
Chronic wasting disease has not been found in Oregon (it has in CA, ID and WA).

**Fishing nearby** (2026–27 rules):
- **[Illinois River](wiki:Illinois_River_(Oregon)):** artificial flies and lures only; wild trout must be released; all
  tributaries closed; closed Oct 1–Nov 30 from Eight Dollar Bridge to the forks; wild
  steelhead over 24 in may be kept only in listed sections and months.
- **Lake Selmac** (Josephine County's largest lake): rainbow trout stocked Feb–May; largemouth
  bass (**1 per day** here), crappie, bluegill and bullhead in summer and fall. County park
  with boat ramps.
- **Rogue River:** hatchery steelhead and coho open all year; Chinook seasons vary by section.
- **New for 2026:** a **Rogue-South Coast Steelhead Validation** is required to fish for
  steelhead Dec 1–Apr 30.

Details, maps and fish ID: `Hunting\` and `Fishing\`. Game care: *[Big Game from Hunt to
Home](lib:osu-pnw517-big-game-from-hunt-to-home)* (OSU), the NDSU *[Wild Side of the Menu](lib:ndsu-wild-side-of-the-menu-1-care-and-cookery)* series, [canning](lib:pnw361-canning-meat-poultry-and-game), [jerky](lib:pnw632-making-jerky-at-home-safely) and [smoking](lib:pnw238-smoking-fish-at-home-safely) guides.
How-to: `Hunting\How-To` ([hunter-ed handbook](lib:todays-hunter-in-new-york-hunter-education-manual), [shot placement](lib:making-a-quick-clean-kill-shot-placement-ct-deep), [blood trailing](lib:big-game-recovery-blood-trailing-mass-wildlife), [gutless
quartering](lib:field-quartering-your-deer-gutless-method-kentucky-fw) of deer and elk, [bear skinning](lib:bear-skinning-and-hide-field-care-alaska-dfg), plucking birds, [track ID](lib:guide-to-common-mammal-tracks-maryland-dnr)) and `Fishing\How-To`
([knots, rigs](lib:basic-fishing-tackle-and-techniques-knots-and-rigs-nysdec), casting, [cleaning and filleting](lib:care-of-your-catch-cleaning-and-filleting-fish-nysdec)).

**Game meat safety:**
- Cook **bear** and other wild game to **165 °F** inside. Freezing, curing, smoking or
  drying does *not* reliably kill the trichinella worms in wild game.
- Wear **gloves** when cleaning rabbits and rodents (tularemia).
- Shot with lead? Trim **generously** around the bullet path: fast-expanding lead bullets scatter fragments **5–14 in** from the wound, sometimes 18 in ([Minnesota DNR X-ray study, p. 6](lib:bullet-fragmentation-and-lead#page=6); the older 4-in rule in [OSU PNW 517, p. 1](lib:osu-pnw517-big-game-from-hunt-to-home#page=1) is too small). Give lead-shot meat to adults, not children or pregnant women *(rule of thumb)*.
- Don't bring deer or elk **brain or spine** parts back into Oregon from another state
  (chronic wasting disease rule).

Local game and its habits, field dressing in hot weather, butchering, snares and fish traps,
and game diseases: **[Hunting, Trapping & Fishing for Food](guide:HUNTING-TRAPPING-FISHING-GUIDE)**.

📚 **Go deeper:** [Big Game from Hunt to Home, p. 4](lib:osu-pnw517-big-game-from-hunt-to-home#page=4) — field care, cooling, chronic wasting disease; [Native fishes of the Rogue River](lib:odfw-native-fishes-of-the-rogue-river-poster) — fish ID poster; [Identifying adult salmon and steelhead](lib:california-sea-grant-identifying-adult-salmon-and-steelhead).

## 🪤 Trapping

**How-to:** start with the national **[Trapper Education Manual](lib:trapper-education-manual-iafwa)** and the [NY trapper manual](lib:trapping-furbearers-student-manual-nysdec)
(trap types, baits, water and land sets, snares, running a trapline, fur handling), then the
species guides ([beaver](lib:trapping-bmps-beaver-afwa), [coyote](lib:trapping-bmps-coyote-afwa), [raccoon](lib:trapping-bmps-raccoon-afwa), [bobcat](lib:trapping-bmps-bobcat-afwa), [gray fox](lib:trapping-bmps-gray-fox-afwa)). For improvised traps with no
store-bought gear, see the 1907 *[Deadfalls and Snares](lib:deadfalls-and-snares-harding-1907)* (illustrated) and the snare and
deadfall chapters of the Army survival manuals (`Manuals\ArmyFieldManuals`; [FM 21-76, p. 95](lib:fm-21-76-army-survival-manual#page=95)). Hides and furs:
USDA *[Home Tanning of Leather and Small Fur Skins](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334)*.

- **Check traps at least daily** — animals spoil, suffer, or get taken by other predators.
- **Beaver, raccoon, muskrat** and **rabbits** are the most dependable meat from traps here;
  wear gloves for rabbits and rodents (tularemia), and cook all wild meat thoroughly.
- **Don't catch your own dogs:** the [AFWA dog-friendly guides](lib:dog-friendly-strategies-for-trapping-public-land-afwa) show sets that avoid pets.

**While Oregon's rules are still enforced** (details in the [2026–2028 furbearer booklet](lib:oregon-furbearer-trapping-and-hunting-regulations-2026-2028-odfw) in
`Trapping\`):

- **License:** trapping needs an Oregon **Furtaker's License** — that includes "unprotected"
  animals like coyote, skunk, opossum and porcupine. A landowner can get a **free** license
  for land they own and live on (register the land with ODFW first).
- **Trapper education** (free, online at hunter-ed.com/oregon/trapper) is required if you
  were born after June 30, 1968 or are trapping in Oregon for the first time — except on your
  own or family land, or when controlling damage to livestock or crops.
- **Every trap and snare must carry your ODFW brand number.** Check traps **at least every
  48 hours**.
- **Banned:** toothed jaws; oversized footholds and land killing traps (size limits are in the
  booklet); game meat as bait; visible bait within 15 ft of a foothold set for carnivores.
  In the Rogue River-Siskiyou National Forest west of I-5 (that includes the Illinois Valley),
  **no traps or snares hung in trees**. On public land, stay 50 ft from trails and 300 ft
  from trailheads, campgrounds and picnic areas.
- **2026–27 seasons:** bobcat Dec 1–Feb 28 (needs a record card) · gray fox Oct 15–Feb 28 ·
  raccoon, river otter and beaver Nov 15–Mar 15 · mink and muskrat Nov 15–Mar 31 · marten
  closed west of I-5 · fisher and ringtail closed all year.
- **[Wolves](wiki:Wolf)** are federally endangered here. Use coyote traps no bigger than #3 and snares
  with breakaways. A wolf track is about **5 in** long; a [coyote](wiki:Coyote)'s is about 2.5 in
  ([furbearer booklet, p. 16](lib:oregon-furbearer-trapping-and-hunting-regulations-2026-2028-odfw#page=16);
  [🖼️ side by side](lib:oregon-furbearer-trapping-and-hunting-regulations-2026-2028-odfw#page=16)). Report
  any wolf caught by accident right away: ODFW, US Fish & Wildlife (503) 231-6179, or OSP
  (541) 664-4600.

📚 **Go deeper:** [Furbearer booklet, p. 16](lib:oregon-furbearer-trapping-and-hunting-regulations-2026-2028-odfw#page=16) — wolf vs coyote, side by side; [Best Management Practices for Trapping](lib:best-management-practices-for-trapping-introduction-afwa) — humane, selective sets.

---

## 🌱 Gardening and food

**Climate at Cave Junction** (NOAA 1991–2020 normals, station at 1,377 ft):

| | Typical date | Play it safe |
|---|---|---|
| Last spring frost (32 °F) | **May 1** | 1-in-10 years it's after **May 23** |
| Last chilly night (36 °F) — matters in frost pockets | May 28 | 1-in-10 after June 17 |
| First fall frost (32 °F) | **Oct 12** | 1-in-10 years it's before **Sep 23** |
| Frost-free growing season | **~161 days** | at least 133 days 9 years out of 10 |

- **USDA hardiness zone 8b** (winter lows 15–20 °F) for Cave Junction, Takilma, Kerby, O'Brien
  and Selma — but valley-floor **frost pockets run colder**. Record low: −6 °F (1972).
- About 61 in of precipitation a year, but only **5–7 in falls April–September**, so summer
  gardens need irrigation (see the [drip](lib:uc-anr-drip-irrigation-in-the-food-garden) and [water-wise](lib:uc-anr-food-gardening-with-less-water) guides).
- **[Serpentine soils](lib:uc-anr-trees-and-shrubs-for-serpentine-landscapes-pub-8400#page=2)** (common here — greenish rock, sparse "barrens"; [photos](wiki:Serpentine_soil)): very high magnesium,
  low calcium, plus nickel and chromium, and they can contain **natural asbestos**.
  - Grow vegetables in **raised beds with imported soil** and lots of compost.
  - Wet the soil before digging, don't work it when it's dusty or windy, keep it mulched
    3–6 in, and take shoes off indoors.
  - **Get a [soil test](lib:osu-soil-test-interpretation-guide-ec-1478) before adding amendments** (don't add gypsum by default).
  - Some local clay soils drain slowly and stay waterlogged in winter, which is another reason
    for raised beds.
- Local help: **OSU Extension, Josephine County** — (541) 241-3050; Master Gardener plant
  clinic Wednesdays 1–3 pm, (458) 291-7302.

**Making flour, masa, sourdough, salt and syrup from local resources, and bread, tortillas and
pasta from them: see the [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) guide.**
Keeping seed going year after year: **[Seed Bank Guide](guide:SEED-BANK-GUIDE)**. Storing the
harvest with no power: **[Root Cellar Guide](guide:ROOT-CELLAR-GUIDE)**.

Details: `Gardening-Food\` — OSU [vegetable](lib:osu-vegetable-gardening-in-oregon-ec-871), orchard, berry, soil, compost and [seed-saving](lib:uga-seed-saving-in-home-gardens-starter-guide-c-1242)
guides; [winter gardening west of the Cascades](lib:pnw-winter-vegetable-production-west-of-the-cascades-pnw-548); the USDA *[Complete Guide to Home Canning](lib:usda-complete-guide-to-home-canning-2015-guide-1-principles)*;
freezing, pickling, [root-cellar storage](lib:wsu-storing-vegetables-and-fruits-at-home-root-cellars-eb1326e); chicken coop and laying-hen feeding; beekeeping;
the 1983 Josephine County soil survey ([text](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition), plus the [full scan with soil maps](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-full-scan-with-maps)).

How much food a household needs for a year, storing it, rationing it fairly, avoiding
scurvy and other deficiency diseases, and a month-by-month local foraging calendar:
**[Food When It's Scarce](guide:FOOD-SECURITY-GUIDE)**.

Canning safely at our elevation (and what to do with no pressure canner), drying, smoking,
curing and fermenting: **[Preserving Food Without a Freezer](guide:PRESERVING-FOOD-GUIDE)**.

📚 **Go deeper:** [Soil Survey, p. 13](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=13) — the valley's serpentine (ultramafic) soils; [OSU Growing Your Own](lib:osu-growing-your-own-practical-guide-to-gardening-in-oregon-em-9027) — a whole Oregon garden season; [OSU Preserving Dry Beans](lib:osu-preserving-dry-beans-em-9435) — a staple that stores.

## 💧 Water

- Store at least **1 gallon per person per day for 2 weeks**, plus water for animals.
- To treat questionable water, bring it to a **rolling boil for 1 minute**, or use plain
  unscented household bleach as shown in the dosing table in
  `Water\` [EPA - Emergency Disinfection of Drinking Water](lib:epa-emergency-disinfection-of-drinking-water-2017#page=1).
- After a flood or wildfire, **shock-chlorinate your well** and have it tested ([OHA](lib:oha-well-disinfection-technical-bulletin) and [OWRD](lib:owrd-maintaining-your-well-after-wildfire)
  sheets in `Water\`). [Rainwater collection rules](lib:osu-rainwater-harvesting-in-tanks-or-cisterns-oregon-regulations-em-9448) for Oregon are in `Water\` too.

**Wells, pumps and springs** — running the well pump with no grid, hand and ram pumps, spring boxes and cisterns:
**[Water Wells, Pumps, Springs & Cisterns](guide:WATER-WELLS-GUIDE)**. **Making any water safe** — settling, homemade sand,
biosand and clay filters, charcoal, boiling, bleach and pool shock: **[Water Purification](guide:WATER-PURIFICATION-GUIDE)**.

Toilets when the sewer or septic pump stops, handwashing with little water, and stopping
dysentery or cholera from spreading: **[Sanitation, Hygiene & Stopping Disease](guide:SANITATION-GUIDE)**.

📚 **Go deeper:** [OSU Survival Basics: Water, p. 3](lib:osu-survival-basics-water-em-9285#page=3) — bleach drops per quart, step by step; [Wilderness Medical Society guidelines](lib:wilderness-medical-society-water-disinfection-guidelines-2019) — boiling, filters and chemicals compared; [CAWST biosand filter manual](lib:cawst-biosand-filter-construction-manual-2012) — build a household filter.

## ⚡ Off-grid power and creek hydro

Start with the US Navy **[NEETS](lib:neets-module-01-matter-energy-and-direct-current)** modules (electricity basics, AC, circuit protection, wiring,
generators) in `Off-Grid-Power\Electrical-Basics`, then the solar guides, then the
micro-hydro handbooks in `Off-Grid-Power\Micro-Hydro`.

**Generators**
- **Never run one indoors, in a garage, crawlspace or shed**, even with doors open.
  Carbon monoxide kills in minutes. Keep it outdoors, away from windows and vents, and use
  battery-powered CO alarms.
- **Never plug a generator into a wall outlet ("backfeeding").** It sends power back
  through the lines and can kill anyone working on them. Wire into the house only through a
  transfer switch.
- Store fuel outside living areas, in proper cans. Let the engine cool before refueling.
- **Engine won't start, carburetor gummed up, generator makes no power?** See the
  **[Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE)** guide — it also covers
  chainsaws, rewinding motors, and turning motors and car alternators into generators.
- **Fuel:** how long gas and diesel keep, rescuing stale or watery fuel, and getting fuel out
  of station tanks, drums and vehicles with no power: **[Fuel Guide](guide:FUEL-GUIDE)**.
- **EMP or solar storm:** protecting solar gear, inverters and spares, and Faraday
  containers: **[EMP Guide](guide:EMP-GUIDE)**.

**Sizing a solar system** ([Sandia](lib:sandia-sizing-small-off-grid-solar-systems-for-rural-homes#page=20) and [IEA](lib:iea-pvps-lead-acid-battery-guide-for-stand-alone-pv) guides)
- Panel size (kW) ≈ (kWh you use per day ÷ peak sun hours) × 1.2.
- Lead-acid batteries: count on only **40% of the rated capacity**. At our latitude, plan
  **7–9 days** of storage for a solar-only system, and vent battery rooms at the top
  (hydrogen rises).
- System voltage: **12 V** under 1 kWh/day, **24 V** for 1–4 kWh/day, **48 V** above that.
  Low voltage over long wires needs very heavy wire.

**Sizing creek hydro** ([NRCan](lib:nrcan-micro-hydropower-systems-a-buyers-guide), [NCAT](lib:ncat-attra-micro-hydro-power-beginners-guide#page=8))
- Real output (watts) ≈ **flow (liters/second) × drop (meters) × 9.8 × 0.5**.
  In US units: kW ≈ flow (cubic ft/min) × drop (ft) ÷ 709 × 0.5.
  Example: 50 gallons/minute falling 100 ft ≈ **470 W around the clock ≈ 11 kWh a day**,
  more than solar gives most of the year here.
- **Design for late-summer low flow** (the flow you have 95% of the time). Size the pipe so
  friction eats less than 10% of the drop. Screen the intake and leave water in the creek.
- A **[hydraulic ram](wiki:Hydraulic_ram) pump** ([Clemson plans](lib:clemson-extension-homemade-hydraulic-ram-pump)) lifts creek water uphill with no fuel or power.

*While Oregon's water laws are enforced:* hydropower needs a state water right, and most
Illinois Valley creeks are **closed to hydro by state rule**, including the Illinois River and
its forks, Althouse, Sucker, Deer, Josephine, Rough and Ready and many more (OAR
690-515-0050). The [OWRD guides](lib:oregon-owrd-water-rights-in-oregon) and forms are in `Micro-Hydro\`.

Step by step — sizing solar for our cloudy winters, salvaged panels and batteries, wiring and
fuses, lithium safety, and measuring a creek for hydro: **[Off-Grid Power](guide:OFF-GRID-POWER-GUIDE)**.

📚 **Go deeper:** [CPSC generator hazards](lib:cpsc-portable-generator-hazards-co-backfeed-and-fuel-safety) — carbon monoxide, backfeeding, fuel; [Sandia, p. 20](lib:sandia-sizing-small-off-grid-solar-systems-for-rural-homes#page=20) — a worked solar sizing example; [USBR Water Measurement Manual](lib:usbr-water-measurement-manual-weirs-and-stream-flow) — measuring creek flow.

## 🧼 Homestead skills: soap, fuel, heat, sanitation, crafts

Everything is in `Homestead-Skills\` — start with the short **[Practical Action](lib:practical-action-soap-making-technical-brief)** briefs
(illustrated, step by step), then the longer manuals. For everyday necessities — cleaners,
laundry soap, tooth powder, fire starters, oil lamps, glue, mending, tire sandals, pads and
diapers — see the **[Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)** in this folder.
For forging, heat-treating scrap steel, and making or sharpening hand tools, see
**[Blacksmithing and Hand Tools](guide:BLACKSMITHING-GUIDE)**.

**Firewood** ([OSU](lib:osu-extension-home-heating-fuels-firewood-vs-pellets-ec1628#page=4), heat per cord when dry): **[Oregon white oak](wiki:Quercus_garryana) and [madrone](wiki:Arbutus_menziesii) ≈ 30 million BTU**,
Douglas-fir ≈ 21, alder ≈ 18, ponderosa pine ≈ 17. Each 1% of extra moisture costs about 1%
of the heat: split and stack wood **through one dry summer** (two is better) and keep it
covered through the rains. A good stove is 60–80% efficient; an open fireplace 10–15%.

**Carbon monoxide kills.** Never run a generator, grill, charcoal, camp stove or a wood-gas
unit indoors, in a garage or near windows. CO feels like **flu without a fever**. A
battery CO alarm near the bedrooms is cheap insurance. A wood-gas generator keeps making
CO-rich gas for ~20 minutes after the engine stops.

**Lye** (for soap and biodiesel): wear gloves and goggles, keep children away, **add lye to
cold water a little at a time** (never water to lye), never use aluminum pots. On skin or in
eyes: **flush with lots of water** for a long time (not vinegar).

**Methanol** (for biodiesel): very flammable, vapors creep along the ground to flames, absorbed
through the skin, and swallowing it causes **blindness**. Work outdoors, away from any flame.

**[Stored fuel](guide:FUEL-GUIDE):** gasoline stays good about **6 months** (longer with stabilizer), diesel
6–12 months. Approved cans, outside the house, in a tub to catch spills.

**Sanitation** is what keeps disease away when water and sewer stop: the OSU **[twin-bucket
toilet](lib:osu-extension-survival-basics-sanitation-twin-bucket-toilet)**, then a proper latrine ([Army FM 21-10](lib:us-army-fm-21-10-field-hygiene-and-sanitation-2000), the [WHO notes](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies)) at least 100 ft downhill from
any well or creek, and **handwashing with soap** every time.

*While laws are enforced:* making fuel alcohol needs a free federal TTB permit first; Oregon
requires permits for graywater systems and composting toilets/privies; and burning needs a
Josephine County burn permit and a burn day ((541) 476-9663).

**Firewood** — which local trees burn best, how much you need, felling, splitting, drying, chimneys and ashes:
**[Firewood](guide:FIREWOOD-GUIDE)**.

Dressing for our wet winters, mending, wool from sheep to yarn, tanning hides and fixing
shoes: **[Clothing, Leather & Shoes](guide:CLOTHING-LEATHER-GUIDE)**.

📚 **Go deeper:** [CPSC: Carbon Monoxide, the Invisible Killer](lib:cpsc-carbon-monoxide-the-invisible-killer) — symptoms and alarms; [Practical Action soap-making brief](lib:practical-action-soap-making-technical-brief) — lye safety and soap step by step; [Penn State biodiesel safety](lib:penn-state-biodiesel-safety-for-small-scale-production) — methanol and lye handling.

## 🐐 Animals and vet care

Start with **`Animals\Veterinary\`[Where There Is No Animal Doctor](lib:where-there-is-no-animal-doctor-cvm-2024)** — the illustrated handbook
for exactly this situation — then the species books (*Raising Healthy [Goats](lib:raising-healthy-goats-cvm) / [Sheep](lib:raising-healthy-sheep-cvm) / [Cattle](lib:raising-healthy-cattle-cvm)
/ [Pigs](lib:raising-healthy-pigs-cvm) / [Poultry](lib:raising-healthy-poultry-cvm) / [Rabbits](lib:raising-healthy-rabbits-cvm) / [Horses](lib:raising-healthy-horses-cvm)*).

**Normal vital signs at rest** (Merck Veterinary Manual). Excitement, heat and work raise all
three, so compare with the same animal when calm:

| Animal | Temperature (°F) | Heart (beats/min) | Breaths/min |
|---|---|---|---|
| Horse | 99.0–100.8 | 28–40 | 10–14 |
| Cow (dairy) | 100.4–102.8 | 48–84 | 26–50 |
| Sheep | 100.9–103.8 | 70–80 | 16–34 |
| Goat | 101.3–103.5 | 70–80 | — |
| Pig | 101.6–103.6 | 70–120 | 32–58 |
| Rabbit | 101.5–104.2 | 180–350 | — |
| Dog | 99.5–102.5 | 70–120 | 18–34 |
| Chicken | 105–109 | — | — |

**Births:**
- **Goats and sheep:** most deliver within **30–45 minutes** of the water bag showing. Help
  if there's no progress after 30 minutes, if she strains with no water bag, or if a kid is
  mispositioned (the [KSU](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689) and [Langston](lib:lambing-and-kidding-assistance-langston) guides show how to correct positions).
- **Newborn kids/lambs** need colostrum, about 10% of body weight, **within the first
  hour**. Warm a chilled kid before feeding.
- **Cows:** heifers should calve within **2–3 hours** of the water sac, cows within 1–2.
  When pulling, loop the chain above and below the ankle and pull **one leg at a time**.
  The calf should nurse within an hour.

**[Horse colic](lib:first-aid-for-horse-owners-uf-vm275#page=4)** (pawing, rolling, looking at the flank, no manure): don't force-feed, don't
put a hose down the throat, don't repeat painkillers.

**Humane euthanasia:** see the illustrated [UF guide](lib:humane-euthanasia-of-sick-and-injured-livestock-uf-vm114) (aim points by species) and the [AVMA
guidelines](lib:avma-guidelines-for-the-euthanasia-of-animals-2020). Hold the firearm a few inches from the head; adult cattle and horses need a
**9mm/.357 or larger** — a .22 may not penetrate an adult skull.

**Poisonous plants:** most have no antidote. Poisoning mostly happens to **hungry, stressed
or newly moved** animals — don't turn hungry stock onto weedy ground. Watch for **[tansy
ragwort](wiki:Jacobaea_vulgaris)**, poison and water hemlock, [yew](wiki:Taxus_brevifolia) and oak ([USDA color guide](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415) in `Animals\Planning-...`).

**Predators:** [cougar](wiki:Cougar), [bear](wiki:American_black_bear) and [coyote](wiki:Coyote) all take livestock here. Guardian dogs, solid
night-time housing, electric fencing and not leaving feed out are the proven defenses
([USDA guardian-dog guides](lib:livestock-guarding-dogs-usda-aib588), ODFW [cougar](lib:oregon-is-cougar-country-odfw) and [bear](lib:living-with-black-bears-odfw) brochures).

**Wildfire:** evacuate animals **early and in daylight**; have 2–3 destinations. The
**Josephine County Fairgrounds** (Grants Pass, (541) 476-3215) has sheltered evacuated
livestock, and **Southern Oregon Emergency Aid** volunteers move livestock for free
((541) 226-1124 — call *before* it's urgent). If animals must stay: a grazed-down pasture,
gates open, 7–10 days of water and feed.

**Stock up now:** since 2023, livestock antibiotics need a vet's prescription. Ask your vet
now about a basic kit for your animals (wound care, dewormers, antibiotics, calcium for milk
fever, electrolytes) — *[Drugs and Their Usage](lib:drugs-and-their-usage-cvm)* explains doses and withdrawal times.

**Horses, mules and donkeys** — choosing, feeding, hoof care and shoeing, riding, packing
and harness work: **[Horses, Mules and Draft Animals](guide:HORSE-GUIDE)** and `Horses-Draft-Animals\`.

**Rabbits and chickens** — meat and eggs on little bought feed, hatching chicks, predators,
butchering: **[Rabbits & Chickens](guide:RABBITS-CHICKENS-GUIDE)**.

**Milk goats, cheese and bees** — selenium-poor Oregon soils, kidding, butter, cheese with
homemade rennet, swarms and varroa: **[Goats, Dairy & Bees](guide:GOATS-DAIRY-BEES-GUIDE)**.

📚 **Go deeper:** [Where There Is No Animal Doctor, p. 65](lib:where-there-is-no-animal-doctor-cvm-2024#page=65) — examining a sick animal; [Nebraska calving guide](lib:calving-difficulty-and-assistance-nebraska-ec1907) — helping a cow calve; [Zoonoses](lib:zoonoses-diseases-animals-give-people-cvm) — diseases animals give people; [Tansy ragwort (WSU)](lib:tansy-ragwort-wsu).

## 🍄 Wild plants — the deadly look-alikes

**Never eat a wild plant or mushroom you can't identify with certainty.** Cooking does
**not** make a poisonous mushroom safe. If someone may be poisoned: **Oregon Poison Center
1-800-222-1222**.

| Deadly | Grows | Mistaken for | Tell-tale signs |
|---|---|---|---|
| **[Western waterhemlock](wiki:Cicuta_douglasii)** — most poisonous plant in North America | Wet ground, ditches, creek edges | [Water parsley](wiki:Oenanthe_sarmentosa), [wild carrot](wiki:Daucus_carota), [cow parsnip](wiki:Heracleum_maximum) | Root and stem base are **hollow with chambered cross-walls** ([🖼️ photo](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1)); a walnut-sized piece of root can kill |
| **[Poison hemlock](wiki:Conium_maculatum)** | Roadsides, pastures, disturbed ground | Wild carrot (Queen Anne's lace), [parsnip](wiki:Parsnip), [parsley](wiki:Parsley), [fennel](wiki:Fennel) | **Hairless stem with purple spots** ([🖼️ drawing](lib:fm-3-05-70-survival-2002#page=513)) |
| **[Death camas](wiki:Toxicoscordion_venenosum)** | Meadows | [Edible camas](wiki:Camassia_quamash) bulbs, wild onion | Bulbs have **no onion smell** ([🖼️ photos](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2)) |
| **[Foxglove](wiki:Digitalis_purpurea)** | Garden escape, clearings | **[Comfrey](wiki:Symphytum_officinale)** (before it flowers) | Has caused fatal "comfrey tea" poisonings |
| **[Death cap mushroom](wiki:Amanita_phalloides)** ([🖼️ photos](lib:bccdc-death-cap-mushrooms-in-city-environments-briefing#page=4)) | Under **oaks and filberts** | [Puffballs](wiki:Puffball) (young), [paddy-straw mushrooms](wiki:Volvariella_volvacea) | Poisoned 5 Oregonians in 1988 — 4 needed liver transplants |

Details: `Wild-Plants\` — USDA *[Plants Poisonous to Livestock in the Western States](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415)* (color
photos), PNW [waterhemlock](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109) and [death camas](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104) guides, [death cap ID sheets](lib:bccdc-death-cap-mushroom-brochure), the Forest Service
*[Special Forest Products Species Guide](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513)* and *[Wild Edible Mushrooms of the Pacific Northwest](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest-pnw-gtr-309)*,
OSU guides to [stinging nettle](lib:osu-wild-edibles-stinging-nettle-em-9373) and [elderberries](lib:osu-play-it-safe-when-preserving-elderberries-em-9446).

**Mushrooms:** the **[Mushroom Guide](guide:MUSHROOM-GUIDE)** covers our local killers and
their look-alikes, spore prints, what to do after a bad meal, the good edibles (chanterelle,
hedgehog, morel, bolete, oyster), drying, and growing shiitake and oysters. Books in `Mushrooms\`.

📚 **Go deeper:** [Protect your horses and livestock from toxic plants, p. 34](lib:wsnwcb-protect-your-horses-and-livestock-from-toxic-plants#page=34) — poison and water hemlock side by side; [PNW 109, p. 1](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1) — waterhemlock's hollow, chambered stem; [CDC: death cap poisonings, 2017](lib:cdc-mmwr-amanita-phalloides-death-cap-poisonings-northern-california-2017) — what happened to people who ate them.

---

## 🥾 Walking out

`Walking-Routes\WALKING-ROUTES.html` has routes on foot from Cave Junction to **every Oregon
city and Northern California down to Walnut Creek** (359 cities), each with two walking options,
a **bicycle route** with riding hours, the **normal driving time** and fuel needed,
printable turn-by-turn directions, and a **GPX track** to load into OsmAnd, Avenza or Gaia
(shows the route and where you are, no signal needed).

- **Highway route** — US-199, I-5, US-101 and other main roads, freeways included. Usually
  the **shortest**, with gentle grades and real bridges, but exposed and where other people
  will be.
- **Back-road route** — avoids freeways; county, Forest Service and BLM roads and trails.
  Quieter and less exposed, but usually **longer and steeper**, remote, and snow-prone on
  passes. Road numbers match the Forest Service maps.

| Destination | Highway route | Back roads |
|---|---|---|
| Grants Pass, OR | **29 mi** · 2 days | 40 mi · 3 days |
| Crescent City, CA | **53 mi** · 4 days | 64 mi · 4 days |
| Medford, OR | **59 mi** · 4 days | 62 mi · 4 days |
| Brookings, OR | **70 mi** · 5 days | 97 mi · 6 days |
| Roseburg, OR | **101 mi** · 7 days | 122 mi · 8 days |
| Klamath Falls, OR | **131 mi** · 9 days | 141 mi · 9 days |
| Eureka, CA | **137 mi** · 9 days | 149 mi · 10 days |
| Eugene, OR | **172 mi** · 11 days | 195 mi · 13 days |
| Redding, CA | **206 mi** · 14 days | 215 mi · 14 days |
| Bend, OR | **219 mi** · 15 days | 244 mi · 16 days |
| Salem, OR | **231 mi** · 15 days | 261 mi · 17 days |
| Portland, OR | **278 mi** · 19 days | 314 mi · 21 days |
| Sacramento, CA | **368 mi** · 25 days | 394 mi · 26 days |
| Walnut Creek, CA | **404 mi** · 27 days | 450 mi · 30 days |

Days assume **15 miles a day** with a pack. Neither route knows about washed-out or burned
bridges, landslides, snow, fire, water or food — plan water for every day.

Map and compass, finding north without one, and reading the weather on the way:
**[Navigation & Weather](guide:NAVIGATION-WEATHER-GUIDE)**. Moving loads by bike, trailer or
handcart, and keeping a bike running: **[Bicycles, Carts & Hauling](guide:BICYCLES-CARTS-GUIDE)**.

📚 **Go deeper:** [FM 21-76, p. 231](lib:fm-21-76-army-survival-manual#page=231) — direction finding without a compass; [OSU Survival Basics: Water](lib:osu-survival-basics-water-em-9285) — treating water on the way; [Horse packing (USFS 1943)](lib:instructions-on-horse-packing-usfs-north-pacific-region-1943) — if you go with pack animals.

---

## 🔄 Keeping this current

- **Hunting and fishing regulations** change every year. Once a year, download the newest
  installer kit from the website, run it and pick the same drive. It only downloads what's new
  (see [Get the whole library](guide:GET-THE-LIBRARY)).
- If a file shows *not downloaded yet* in `LOCAL-FILES.html`, run the installer again and pick
  the same drive. It retries anything that failed.
- **Practice now:** open the maps, tune the radios, try the AI on a few questions. Things
  are much easier in an emergency if you've used them once.

📚 **Go deeper:** [ODFW 2026 big game regulations](lib:odfw-2026-big-game-hunting-regulations) and [furbearer booklet](lib:oregon-furbearer-trapping-and-hunting-regulations-2026-2028-odfw) — compare dates with the newest booklets; [Josephine County Emergency Operations Plan](lib:josephine-county-emergency-operations-plan-2025) — check contacts against it.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Plants and animals that can hurt you**
- Western poison oak — [🖼️ OSU EM 9184 photos, p. 24](lib:osu-em-9184-keeping-your-home-and-property-safe-from-wildfire#page=24); [🖼️ FM 3-05.70, p. 514](lib:fm-3-05-70-survival-2002#page=514); [Western poison oak](wiki:Toxicodendron_diversilobum)
- Western waterhemlock and its look-alikes — [🖼️ PNW 109, p. 1](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ look-alikes, pp. 3–4](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3); [Western waterhemlock](wiki:Cicuta_douglasii)
- Poison hemlock — [🖼️ FM 3-05.70, p. 513](lib:fm-3-05-70-survival-2002#page=513); [🖼️ beside waterhemlock, WSNWCB p. 34](lib:wsnwcb-protect-your-horses-and-livestock-from-toxic-plants#page=34); [Poison hemlock](wiki:Conium_maculatum)
- Death camas — [🖼️ PNW 104, pp. 1–2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=1); [🖼️ FM 3-05.70, p. 507](lib:fm-3-05-70-survival-2002#page=507); [Death camas](wiki:Toxicoscordion_venenosum)
- Death cap mushroom and what it is mistaken for — [🖼️ BCCDC, p. 4](lib:bccdc-death-cap-mushrooms-in-city-environments-briefing#page=4); [🖼️ look-alikes, p. 7](lib:bccdc-death-cap-mushrooms-in-city-environments-briefing#page=7); [Death cap](wiki:Amanita_phalloides)
- Tansy ragwort (a livestock poison) — [🖼️ WSU fact sheet, p. 1](lib:tansy-ragwort-wsu#page=1); [Tansy ragwort](wiki:Jacobaea_vulgaris)
- Rattlesnakes: how to tell a pit viper — [🖼️ FM 4-25.11, p. 132](lib:fm-4-25-11-first-aid#page=132); [Western rattlesnake](wiki:Crotalus_oreganus)
- Black widow spider — [🖼️ AFH 10-644, p. 78](lib:afh-10-644#page=78); [Western black widow](wiki:Latrodectus_hesperus)
- Ticks — [🖼️ CDC tick ID, p. 4](lib:tickborne-diseases-of-the-united-states-reference-manual-6th-ed-cdc-2022#page=4); [Western blacklegged tick](wiki:Ixodes_pacificus)
- Cougar, bear, wolf and coyote — [🖼️ wolf vs coyote, furbearer booklet p. 16](lib:oregon-furbearer-trapping-and-hunting-regulations-2026-2028-odfw#page=16); [🖼️ track ID, pp. 2–3](lib:guide-to-common-mammal-tracks-maryland-dnr#page=2); [Cougar](wiki:Cougar); [American black bear](wiki:American_black_bear)

**Fire, quake and fallout**
- Defensible-space zones and ladder fuels — [🖼️ FEMA P-737, p. 23](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=23); [🖼️ p. 21](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=21)
- How embers get into a house — [🖼️ vents, FEMA P-737 p. 40](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=40); [🖼️ gutters, p. 45](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=45)
- Big local fires — [Biscuit Fire](wiki:Biscuit_Fire); [Slater Fire](wiki:Slater_fire); [Wildfire](wiki:Wildfire)
- Landslides — [🖼️ FEMA 232, p. 26](lib:fema-232-homebuilders-guide-to-earthquake-resistant-design-and-construction-fema-2006#page=26); [Landslide](wiki:Landslide)
- Cascadia quake prep: strapping the water heater — [🖼️ FEMA 232, p. 155](lib:fema-232-homebuilders-guide-to-earthquake-resistant-design-and-construction-fema-2006#page=155); [Cascadia subduction zone](wiki:Cascadia_subduction_zone)
- Shielding from fallout — [🖼️ *Nuclear War Survival Skills*, p. 24](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=24); [Nuclear fallout](wiki:Nuclear_fallout)

**The land, fish and trees**
- Reading contour lines on the topo maps — [🖼️ PMS 475, p. 40](lib:basic-land-navigation-pms-475#page=40); [Topographic map](wiki:Topographic_map)
- Serpentine soils and the Kalmiopsis — [Serpentine soil](wiki:Serpentine_soil); [Kalmiopsis Wilderness](wiki:Kalmiopsis_Wilderness)
- Salmon, steelhead and other Rogue fish — [🖼️ Sea Grant ID, pp. 1–4](lib:california-sea-grant-identifying-adult-salmon-and-steelhead#page=1); [🖼️ ODFW Rogue fishes poster](lib:odfw-native-fishes-of-the-rogue-river-poster#page=1); [Coho salmon](wiki:Coho_salmon)
- Best firewood trees — [Oregon white oak](wiki:Quercus_garryana); [Pacific madrone](wiki:Arbutus_menziesii)

## 🔗 Related guides

- [Radio Guide](guide:RADIO-GUIDE) — how to use ham, GMRS, FRS, MURS and CB, and call for help
- [Medical guide](guide:Medical-READ-ME-FIRST) — first aid and medicines with no doctor
- [Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE) — shelter, decontamination, food and water
- [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — flour, masa, salt and syrup from local resources
- [Mushroom Guide](guide:MUSHROOM-GUIDE) — local killers, look-alikes and good edibles
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — everyday necessities when stores are gone
- [Seed Bank](guide:SEED-BANK-GUIDE) and [Root Cellar](guide:ROOT-CELLAR-GUIDE) guides — growing, saving and storing food here
- [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE) — a year of food, fair rations, deficiency diseases, foraging
- [Injuries & Illness, No Help Coming](guide:FIELD-CARE-GUIDE) — bleeding, wounds, fractures, bites, long-term care
- [Signals & Morse Code](guide:SIGNALS-MORSE-GUIDE) and [Navigation & Weather](guide:NAVIGATION-WEATHER-GUIDE) — when phones and GPS are gone
- [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) — organizing neighbors, fair trade, keeping watch
- [Shelter, Building & Repair](guide:SHELTER-BUILDING-GUIDE), [Natural Building](guide:NATURAL-BUILDING-GUIDE), [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE) and [Rabbits & Chickens](guide:RABBITS-CHICKENS-GUIDE)
- [Sanitation](guide:SANITATION-GUIDE), [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) and [Preserving Food](guide:PRESERVING-FOOD-GUIDE)
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE), [Goats, Dairy & Bees](guide:GOATS-DAIRY-BEES-GUIDE) and [Clothing, Leather & Shoes](guide:CLOTHING-LEATHER-GUIDE)
- [Childbirth, Newborns & Young Children](guide:CHILDBIRTH-CHILDREN-GUIDE)
- [Start the Library on Any Device](guide:START-ON-ANY-DEVICE) — Windows, Mac, Linux, Android; sharing it with neighbors
