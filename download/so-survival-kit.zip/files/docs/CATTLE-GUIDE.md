# 🐄 Cattle: a Family Milk Cow, Beef and Oxen

How to keep cattle with no feed store, no vet and no freezer: whether your ground can carry a cow, dairy, beef and
dual-purpose breeds, fences, water and sheds for our wet winters, pasture, hay and roots, the plants that kill cattle
here, a family milk cow's daily routine and drying her off, breeding with a bull, calving and when to help, calves,
castration, sickness with no vet, training and working oxen, butchering a beef and keeping 400 lb of meat without a
freezer, hides and tallow, predators, fire season, and a year's work in the valley. What to do with the milk is in the
[Milk, Butter & Cheese guide](guide:DAIRY-GUIDE). The cattle books are in `Animals\Cattle-Horses-Pigs`, no-vet
medicine in `Animals\Veterinary`, yokes in `Horses-Draft-Animals\Draft-Harness`, predators and fire in
`Animals\Planning-Predators-Toxic-Plants`, poisonous plants in `Wild-Plants`, and tanning in `Trapping`.

> ### The short version
> - **A cow needs real land.** Even farmed hard, **2 acres** is "the least possible area" for one cow ([*Keeping One
>   Cow*, p. 15](lib:keeping-one-cow#page=15)). On unwatered valley ground plan **3–5 acres and about 3 tons of hay** a
>   year *(rule of thumb)*; on brush or serpentine, keep goats.
> - **Cold rain is the enemy.** Give a mud-free, three-sided shed ([OSU EC1514, p. 7](lib:beef-production-for-small-farms-osu-ec1514#page=7)),
>   and **never work oxen in cold, wet weather**: a wet yoke rubs necks raw ([*Animal Management*, p. 312](lib:animal-management-british-war-office-1908#page=312)).
> - **Change feed slowly, over a week or more.** Lush clover or alfalfa causes bloat: the **left** side swells
>   drum-tight ([EC1514, pp. 13–14](lib:beef-production-for-small-farms-osu-ec1514#page=13)).
> - **Keep pregnant cows away from ponderosa pine needles**, **never feed yew or hedge trimmings**, and keep bracken
>   and tansy ragwort out of pasture and hay ([AIB 415, pp. 84, 113, 24, 105](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=84)).
> - **Calving:** the calf should come **within about 2 hours of the water bag**; pull only while she strains; a
>   **backward calf must come out fast** ([*Raising Healthy Cattle*, pp. 53, 56](lib:raising-healthy-cattle-cvm#page=53)).
> - **Colostrum: about 10% of the calf's weight within 4 hours**; after 24 hours it can't absorb it
>   ([EC1514, p. 5](lib:beef-production-for-small-farms-osu-ec1514#page=5); [*Raising Healthy Cattle*, p. 67](lib:raising-healthy-cattle-cvm#page=67)).
> - **Brucellosis and TB reach people** through raw milk and birth fluids: gloves at calvings; boil or pasteurize
>   milk from untested cows ([*Raising Healthy Cattle*, pp. 114, 117–118](lib:raising-healthy-cattle-cvm#page=117)).
> - **A beef is about 400 lb of carcass.** Butcher in cold weather, share it, and corn, salt, dry or pressure-can what
>   can't be eaten in days ([USDA FB 2209, pp. 19, 31–33](lib:beef-slaughtering#page=31)).

---

## 🐄 Is a cow right for your land?

**Land.** An Ottawa writer found "two acres of land is the least possible area that will provide cow-food for the
entire year": an acre of clover and timothy for hay, an acre of green fodder and mangels, well manured
([*Keeping One Cow*, p. 15](lib:keeping-one-cow#page=15)). One family fed a cow from **half an acre of clover cut three
times** plus an acre of garden crops ([pp. 20–21](lib:keeping-one-cow#page=20)); a good cow lived on about 1 acre of
pasture until late July ([p. 46](lib:keeping-one-cow#page=46)). On rough range one cow needs from 1¼ acres in wet
country to **25 acres in dry country**, and cattle over a year eat twice what younger ones do
([*Raising Healthy Cattle*, p. 37](lib:raising-healthy-cattle-cvm#page=37)). Our valley-floor soils are "used mainly
for irrigated pasture and hay" ([Soil Survey, p. 9](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=9));
serpentine grows poor, low-calcium forage and holds no stock pond ([p. 49](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=49)).
Pasture browns from June to the October rains, so **without irrigation plan 3–5 acres of decent grass per cow and
calf, plus hay** *(rule of thumb)*.

**Cow or goats?** "From 6 to 8 goats can be kept upon the feed required for 1 cow," and a goat "can be kept where it would be
impossible to keep a cow" ([USDA FB 920, pp. 3, 25](lib:milk-goats-usda-farmers-bulletin-920#page=3)): brush and steep ground suit the
[Goats guide](guide:GOATS-GUIDE); grass, water and hay ground suit a cow. "Two to five families ... can readily unite
in having one cow kept, dividing the milk and expenses" ([*Keeping One Cow*, p. 11](lib:keeping-one-cow#page=11)).

**Which kind** ([OSU EC1514, pp. 3–6](lib:beef-production-for-small-farms-osu-ec1514#page=3)): **a family milk cow**
bred every year, her heifers replacing her and her steers becoming beef or oxen *(rule of thumb)*; **beef cows with
calves**, which need the most land and year-round feed but little daily work; or **weaned calves** bought at about 7
months, grazed one season and butchered when the grass ends, the least land and commitment.

**Buying.** Beginners should buy "good, young, bred cows that have calved at least once," all from one reputable herd
([EC1514, pp. 3–4](lib:beef-production-for-small-farms-osu-ec1514#page=3)). Pick a gentle cow not over 5 years old,
with a large barrel, a big well-formed udder and teats set well apart ([*Keeping One Cow*, p. 84](lib:keeping-one-cow#page=84));
one with her second calf "you can keep her profitably for five years" ([p. 17](lib:keeping-one-cow#page=17)). **Age by
the front teeth:** the first pair of big permanent incisors at 1½–2 years, the second at 2–2½, the third at 3–3½,
the fourth at 4–5 ([*Raising Healthy Cattle*, p. 78](lib:raising-healthy-cattle-cvm#page=78)). Pass over an animal
that stays thin on a good appetite ([Johne's disease](wiki:Paratuberculosis); [EC1514, p. 13](lib:beef-production-for-small-farms-osu-ec1514#page=13)).
**Keep new cattle apart 3 weeks** ([p. 6](lib:beef-production-for-small-farms-osu-ec1514#page=6)), and test for TB and
brucellosis if anyone still can ([USDA FB 1470, p. 30](lib:care-and-management-of-dairy-cows#page=30)).

## 🧬 Breeds: dairy, beef and dual-purpose

Match breed and size to your feed and ground, and ask local ranchers ([EC1514, p. 3](lib:beef-production-for-small-farms-osu-ec1514#page=3));
cattle already adapted to an area outlast imported ones, and gentle breeds suit a small place
([*Raising Healthy Cattle*, pp. 41–42](lib:raising-healthy-cattle-cvm#page=41)).

| Breed | Type | What the books say |
|---|---|---|
| [Jersey](wiki:Jersey_cattle) | Milk | Smallest dairy breed ([UNH, p. 5](lib:4-h-working-steer#page=5)); richest milk, **5.2% fat** against 3.6% for Holstein ([FB 920, p. 6](lib:milk-goats-usda-farmers-bulletin-920#page=6)). The classic family cow: "We keep a good grade Jersey" ([*Keeping One Cow*, p. 96](lib:keeping-one-cow#page=96)). As oxen, Jerseys are "very aggressive and somewhat high-strung" ([UNH, p. 5](lib:4-h-working-steer#page=5)) |
| [Guernsey](wiki:Guernsey_cattle), [Ayrshire](wiki:Ayrshire_cattle) | Milk | Standard U.S. dairy breeds in 1930 ([FB 1470, p. 16](lib:care-and-management-of-dairy-cows#page=16)); not described on the drive. Medium-sized family cows *(rule of thumb)* |
| [Holstein](wiki:Holstein_Friesian) | Milk | Black-and-white, the most common; bull calves even-tempered but "grow very fast" and huge ([UNH, p. 5](lib:4-h-working-steer#page=5)). Most milk, least fat ([FB 920, p. 6](lib:milk-goats-usda-farmers-bulletin-920#page=6)); eats the most *(rule of thumb)* |
| [Brown Swiss](wiki:Brown_Swiss_cattle) | Milk, oxen | "Very docile," slow, heavy muscle, strong feet and legs; "excellent pullers" ([UNH, p. 6](lib:4-h-working-steer#page=6)) |
| [Milking Shorthorn](wiki:Milking_Shorthorn) | Dual-purpose | Red, white or roan; even-tempered, slow-maturing ([UNH, p. 5](lib:4-h-working-steer#page=5)); a beef breed also milked ([FB 1470, p. 17](lib:care-and-management-of-dairy-cows#page=17)) |
| [Devon](wiki:North_Devon_cattle), [Red Poll](wiki:Red_Poll) | Dual-purpose | Beef breeds kept for milk ([FB 1470, p. 17](lib:care-and-management-of-dairy-cows#page=17)). Milking Devons: small, fast, smart, aggressive oxen, not for beginners ([UNH, p. 6](lib:4-h-working-steer#page=6)). Red Polls are hornless, no good in a yoke ([p. 45](lib:4-h-working-steer#page=45)) |
| [Dexter](wiki:Dexter_cattle) | Small dual-purpose | A minor breed used for oxen ([UNH, p. 6](lib:4-h-working-steer#page=6)); small cattle for small ground *(rule of thumb)* |
| [Hereford](wiki:Hereford_cattle), [Angus](wiki:Angus_cattle) | Beef | Beef breeds are "thicker fleshed, fatten more readily," with less waste fat inside ([USDA FB 2209, p. 5](lib:beef-slaughtering#page=5)). Herefords also make oxen ([UNH, p. 6](lib:4-h-working-steer#page=6)) |

**Crosses are fine:** crossbred calves have "extra vigor" ([EC1514, p. 3](lib:beef-production-for-small-farms-osu-ec1514#page=3)),
and a beef × dairy cow milks enough for a family and raises a meatier calf *(rule of thumb)*.

## 🏠 Fences, water and shelter

**Fences** ([*Raising Healthy Cattle*, pp. 17–18](lib:raising-healthy-cattle-cvm#page=17)): a **board fence** is the
strongest, for corrals and handling pens; **split rail** lasts, "except that it generally cannot be built tall enough to be cattle
proof"; a **sapling fence** (2–3-in saplings 6–8 ft long, crossed every 8–16 ft) takes moderate pressure; thorn brush
is a stopgap; **3–6 strands of wire** is "very cattle proof." Brace the corners of the outside fence and use electric
wire for inside paddocks ([EC1514, p. 8](lib:beef-production-for-small-farms-osu-ec1514#page=8)); electric fences "can be
run off of solar charged batteries" ([*Raising Healthy Sheep*, p. 131](lib:raising-healthy-sheep-cvm#page=131)). In
closed range **you pay for damage if your cattle get out** ([EC1514, p. 8](lib:beef-production-for-small-farms-osu-ec1514#page=8)).
Barbed wire, staples and roofing nails cause "hardware disease" ([UNH, p. 15](lib:4-h-working-steer#page=15)): pick up
wire scraps, and cut baling wire with pliers in one cut, never a hatchet ([USDA FB 1470, pp. 35–36](lib:care-and-management-of-dairy-cows#page=35)).

**Handling.** A corral with a narrow alley and a squeeze chute or head catch makes every job safer; no electric prods
([EC1514, p. 7](lib:beef-production-for-small-farms-osu-ec1514#page=7)). By hand, lift the tail near its base from one
side, or pinch the nose between thumb and finger ([*Raising Healthy Cattle*, pp. 19–25](lib:raising-healthy-cattle-cvm#page=19)).
Strap a kicker's hind legs above the hocks, and **never strike a cow for kicking** ([FB 1470, p. 38](lib:care-and-management-of-dairy-cows#page=38)).

**Shelter.** "Under most weather conditions, cattle do very well outside." In the Northwest they need "a mud-free area
with protection from wind and rain" such as a three-sided shed, gutters on the roofs, and manure runoff kept out of
creeks ([EC1514, p. 7](lib:beef-production-for-small-farms-osu-ec1514#page=7)). Dry, draft-free, airy and sunny matters;
temperature hardly does, and cows do best in the coldest weather and worst in summer heat ([FB 1470, p. 17](lib:care-and-management-of-dairy-cows#page=17)).
In a shared open shed timid cows get pushed off the feed, so tie them at feeding and dehorn loose cows
([p. 19](lib:care-and-management-of-dairy-cows#page=19)). A tie stall can be **5 ft wide and 5 ft long with a 2-ft
manger** ([*Keeping One Cow*, p. 21](lib:keeping-one-cow#page=21)); a tied cow uses about **4 lb of straw bedding a
day**, 8 lb to soak up all the urine, 14 lb in a box stall ([FB 1470, p. 24](lib:care-and-management-of-dairy-cows#page=24)).
**Store hay apart from the animals:** wet hay heats and can catch fire ([EC1514, p. 7](lib:beef-production-for-small-farms-osu-ec1514#page=7);
[PNW783, p. 8](lib:wildfires-smoke-and-livestock-pnw783#page=8)).

**Water.** Cattle drink **4–20 gallons a day**, much more in heat ([EC1514, p. 9](lib:beef-production-for-small-farms-osu-ec1514#page=9));
cows drank **80% more in hot summer** than in cold winter, and cows watered at will milked better than cows watered
once a day ([FB 1470, pp. 26–27](lib:care-and-management-of-dairy-cows#page=26)). Barrels, tires and tubs make troughs,
never ones that held chemicals ([EC1514, p. 7](lib:beef-production-for-small-farms-osu-ec1514#page=7)). Rats spread
leptospirosis through water, and liver flukes live in snails on wet ground: fence off marshy spots
([*Raising Healthy Cattle*, pp. 118, 164](lib:raising-healthy-cattle-cvm#page=118)). Plan water for a power failure
([PNW783, p. 7](lib:wildfires-smoke-and-livestock-pnw783#page=7)).

## 🌾 Pasture, hay and winter feed

**How much:** **2–2.5% of body weight** in dry feed a day, up to 3% for calves under 500 lb ([UNH, p. 11](lib:4-h-working-steer#page=11));
on poor, mature grass hay intake falls to 1.5% and the animal goes short ([EC1514, p. 9](lib:beef-production-for-small-farms-osu-ec1514#page=9)).
A 1,000-lb cow eats about **25 lb of hay a day** *(arithmetic)*.

**Change feed slowly**, over a week or more, or the rumen sours and bloats ([EC1514, p. 13](lib:beef-production-for-small-farms-osu-ec1514#page=13)).
Turn cattle onto spring grass a little at a time ([UNH, p. 15](lib:4-h-working-steer#page=15)) and give hungry stock dry
hay before green feed ([*Animal Management*, p. 316](lib:animal-management-british-war-office-1908#page=316)); young
clover or alfalfa, "especially with the dew on," causes bloat ([FB 1470, pp. 34–35](lib:care-and-management-of-dairy-cows#page=34)).
Don't graze below 3 inches, where the worms are ([EC1514, p. 14](lib:beef-production-for-small-farms-osu-ec1514#page=14)).

**Making hay** ([*Raising Healthy Cattle*, p. 37](lib:raising-healthy-cattle-cvm#page=37)): cut just before the plants
flower, after the dew is off; dry it on the ground 1–3 days, out of rain; stack it on dry ground near where you feed,
peaked or covered so rain runs off, fenced from the cattle. Good hay is leafy with few seed heads; refuse moldy, dusty
or hot bales ([UNH, p. 12](lib:4-h-working-steer#page=12)). Sun-bleached hay causes vitamin A shortage: watery eyes,
rough coat, night blindness ([EC1514, p. 8](lib:beef-production-for-small-farms-osu-ec1514#page=8)).

**Roots and fodder with no feed store** ([*Keeping One Cow*](lib:keeping-one-cow#page=15)): peas and oats sown early
and cut green from about 6 weeks ([p. 15](lib:keeping-one-cow#page=15)); mangels, which keep until April if handled
gently ([p. 16](lib:keeping-one-cow#page=16)); sugar beets, which don't flavor milk, while turnips do, so feed turnips
only to a dry cow ([pp. 18, 20](lib:keeping-one-cow#page=18)); winter rye for spring ([p. 21](lib:keeping-one-cow#page=21));
and **Jerusalem artichokes**, a bushel a day in winter plus 8–10 lb of hay, about **1 ton of hay for 8 months**
([pp. 73–74](lib:keeping-one-cow#page=73)). Cut up roots and apples: whole ones cause choke ([*Raising Healthy Cattle*, p. 166](lib:raising-healthy-cattle-cvm#page=166)).
Feed at the same hours daily; cows mind a change in feeding more than in milking times ([FB 1470, p. 9](lib:care-and-management-of-dairy-cows#page=9)).
Mature oxen and dry cows do well on hay or pasture alone ([UNH, p. 12](lib:4-h-working-steer#page=12)).

**Salt and minerals.** Salt always, about **1 ounce a day** for a cow in milk, kept out of the rain ([FB 1470, p. 27](lib:care-and-management-of-dairy-cows#page=27));
trace-mineral salt where you can, and calcium to phosphorus near 1–2 to 1 (bone meal supplies both)
([*Raising Healthy Cattle*, p. 30](lib:raising-healthy-cattle-cvm#page=30)). **Oregon is short of selenium:** it
causes [white muscle disease](wiki:Nutritional_muscular_dystrophy) in calves and retained afterbirths, mastitis and poor
fertility in cows ([OSU EM 9094, pp. 1, 3](lib:selenium-supplementation-strategies#page=3)). Feed a selenium mineral
in a covered feeder ([p. 5](lib:selenium-supplementation-strategies#page=5)), but **too much is toxic**
([EC1514, p. 11](lib:beef-production-for-small-farms-osu-ec1514#page=11)); stock a year or more now *(rule of thumb)*.
Lush spring grass can bring [grass tetany](wiki:Grass_tetany): add magnesium to the mineral ([*No Animal Doctor*, p. 329](lib:where-there-is-no-animal-doctor-cvm-2024#page=329)).
**Without irrigation, put up hay for the dry summer as well as the wet winter** *(rule of thumb)*.

## ☠️ Plants that poison cattle here

Most poisonings happen when cattle are **hungry**, thirsty, moved or stressed, or turned out in early spring when
poisonous plants are the only green ones; for most there is **no treatment** ([AIB 415, p. 11](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=11)).
Walk a new paddock before turning cattle in. The "where" column is local knowledge *(rule of thumb)*.

| Plant | Where | What happens |
|---|---|---|
| [Ponderosa pine](wiki:Pinus_ponderosa) needles | Under pines, slash piles, windfalls | **Abortion** in the last third of pregnancy, mostly late fall to early spring; the afterbirth stays and some cows die. Dry or green needles and bark; some cedars and junipers too ([AIB 415, pp. 84–85](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=84)) |
| [Bracken fern](wiki:Pteridium_aquilinum) | Woods edges, burns, gravelly pasture | Builds up over **2–4 weeks**: fever, bleeding, bloody urine; "losses have been high in the Pacific Coast States." Also in hay ([pp. 23–25](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=23)) |
| [Tansy ragwort](wiki:Jacobaea_vulgaris) | Pastures and hayfields | Slow liver damage, signs **6 months** later; worst for cattle and horses; also in hay ([pp. 105–106](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=105); [WSU sheet](lib:tansy-ragwort-wsu#page=1)) |
| [Water hemlock](wiki:Cicuta_douglasii) | Wet meadows, creeks, ditches | "The most violently toxic plant" in North America: convulsions, death within hours; roots turned up by ditch cleaning kill ([pp. 108–109](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=108)) |
| [Poison hemlock](wiki:Conium_maculatum) | Ditches, waste ground | A little poisons; deformed calves if eaten on days 40–100 of pregnancy ([p. 81](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=81)) |
| Lupine | Dry hillsides | 1–12 lb kills a hungry cow; **crooked calves** if eaten on days 40–100 ([p. 65](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=65)); WSU says days 40–70 ([p. 15](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=15)) |
| Larkspur, death camas | Meadows, early spring | Larkspur kills suddenly, worst in early growth ([pp. 57–58](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=57)); death camas is among the first green plants ([p. 34](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=34)) |
| Oak | Oak woodland | Young leaves, buds and green acorns for 2–3 weeks wreck the kidneys; mature leaves are safer ([pp. 78–79](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=78); [WSU, p. 27](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=27)) |
| [Yew](wiki:Taxus_brevifolia), garden yew | Shady creeks; hedges | Death "so rapid that signs ... may not have time to develop" ([pp. 113–114](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=113)); **never feed trimmings** ([WSU, p. 2](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=2)) |
| [St. Johnswort](wiki:Hypericum_perforatum) ("Klamath weed") | Roadsides, pastures | Sunburned, peeling white skin; also from hay ([p. 100](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=100)) |
| Pigweed; drought-stressed or heavily manured crops | Gardens, corrals | Nitrate poisoning: gasping, brown or blue gums, sudden death ([WSU, p. 4](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=4); [*Raising Healthy Cattle*, pp. 171–172](lib:raising-healthy-cattle-cvm#page=171)) |

📚 **Go deeper:** [USDA AIB 415](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=11) — color photos, signs and prevention; the [Goats guide](guide:GOATS-GUIDE) covers garden poisons (azalea, oleander, cherry).

## 🥛 The family milk cow: daily routine, milk and drying off

**How much milk.** Over 14,000 grade (mixed-breed) cows averaged **6,261 lb of milk a year** ([USDA FB 1470, p. 5](lib:care-and-management-of-dairy-cows#page=5)):
about **2,900 quarts**, or 9–10 a day over a 10-month lactation *(arithmetic)*. Family cows gave **10–20 quarts a day**
in full flow ([*Keeping One Cow*, p. 19](lib:keeping-one-cow#page=19)); one "fills a twelve-quart pail each night and
morning," butter for six people ([p. 20](lib:keeping-one-cow#page=20)). Don't expect 30 quarts: "be quite satisfied if
your cow gives half that" ([p. 18](lib:keeping-one-cow#page=18)). **Fall-calving cows gave the most milk** in a year;
spring calvers slump in summer heat, flies and short pasture ([FB 1470, p. 8](lib:care-and-management-of-dairy-cows#page=8)).
Milking three times a day gave about 12% more over 40 days and 18% over a year ([p. 10](lib:care-and-management-of-dairy-cows#page=10)).

**Every milking:**
1. **Twice a day, same times.** Grain before milking; hay, and anything strong-smelling such as turnips, after it, so
   dust and taints stay out of the milk ([FB 1470, p. 26](lib:care-and-management-of-dairy-cows#page=26)).
2. **Wipe each teat** with a clean damp cloth, one per cow, and dry it; never wash teats in the milk pail
   ([*Keeping One Cow*, p. 17](lib:keeping-one-cow#page=17)). Strip the first squirts into a strip cup and look for
   clots ([*Raising Healthy Cattle*, pp. 82, 89](lib:raising-healthy-cattle-cvm#page=82)).
3. **Milk with dry hands**, short nails and a steady grip; rough, slow milking makes cows kick. Near the end, press up
   on each quarter to bring the last milk down ([FB 1470, pp. 10–11](lib:care-and-management-of-dairy-cows#page=10)),
   and milk until the udder is slack ([*Raising Healthy Cattle*, p. 82](lib:raising-healthy-cattle-cvm#page=82)): about
   10 minutes a cow ([*Keeping One Cow*, p. 17](lib:keeping-one-cow#page=17)).
4. **Dip the teats** after ([*Raising Healthy Cattle*, p. 89](lib:raising-healthy-cattle-cvm#page=89)), and dry them before
   she goes out in the cold, or they chap; oil cracked teats ([FB 1470, pp. 37–38](lib:care-and-management-of-dairy-cows#page=37)).
5. **Weigh the milk now and then**: a drop is often the first sign of sickness ([FB 1470, p. 12](lib:care-and-management-of-dairy-cows#page=12)).
   Strain and cool it at once, then see "Clean milking" and "Raw milk dangers" in the [Milk, Butter & Cheese guide](guide:DAIRY-GUIDE).

**Sharing with the calf.** For the most milk, take the calf off after 2–3 days ([*Raising Healthy Cattle*, p. 82](lib:raising-healthy-cattle-cvm#page=82));
a calf left with the cow is "the way in which nature adjusts the supply to meet the demand" ([FB 1470, p. 11](lib:care-and-management-of-dairy-cows#page=11)).
If you can't milk twice a day, let the calf run with her by day, pen it at night, and milk once in the morning: less
milk, far less work *(rule of thumb)*.

**Drying off.** The dry spell rests the udder, feeds the unborn calf and rebuilds the cow ([FB 1470, p. 5](lib:care-and-management-of-dairy-cows#page=5)):
**a month to six weeks** for an ordinary cow in good flesh, **two months or more** for a heavy milker or a thin cow
([p. 6](lib:care-and-management-of-dairy-cows#page=6)). *Sources differ:* *Keeping One Cow* says 4–6 weeks
([p. 91](lib:keeping-one-cow#page=91)), "some eight weeks" ([p. 108](lib:keeping-one-cow#page=108)), and no more than 6
for a one-cow family ([p. 49](lib:keeping-one-cow#page=49)); plan on **6–8 weeks** *(our reading)*. **How:** skip one
milking, then two, then three; when she is down to **6–8 lb (3–4 quarts) a day**, stop, leave the udder alone, and cut
her grain ([FB 1470, p. 6](lib:care-and-management-of-dairy-cows#page=6)). Watch for a hot, hard quarter
([*Raising Healthy Cattle*, p. 87](lib:raising-healthy-cattle-cvm#page=87)). **July is a good time to dry her off,**
with pasture short and milk hard to keep ([*Keeping One Cow*, p. 49](lib:keeping-one-cow#page=49)); she should calve
neither fat nor thin ([EC1514, p. 3](lib:beef-production-for-small-farms-osu-ec1514#page=3)).

## 🐂 Breeding without AI

**Heat** comes every **21 days** and lasts **12–18 hours** ([EC1514, p. 21](lib:beef-production-for-small-farms-osu-ec1514#page=21)):
bellowing, restlessness, riding other cows or standing to be ridden, clear mucus. The egg comes about 11 hours after
heat ends, so **put her with the bull toward the end of heat**, while she is gaining weight ([*Raising Healthy Cattle*, pp. 42–43](lib:raising-healthy-cattle-cvm#page=42)).
Keep a cow in heat away from heavily pregnant cows, which get ridden and hurt ([FB 1470, p. 6](lib:care-and-management-of-dairy-cows#page=6)).
Breed **heifers at 18 months or more** and growing; give a cow **2 months' rest after calving** ([*Raising Healthy Cattle*, p. 43](lib:raising-healthy-cattle-cvm#page=43)),
but rebreed within 3 months for a calf every 12 months ([EC1514, p. 5](lib:beef-production-for-small-farms-osu-ec1514#page=5)).
**Pregnancy lasts 283 days, give or take 19** ([p. 4](lib:beef-production-for-small-farms-osu-ec1514#page=4)). Due
date: count back 3 months from breeding and add 10 days, so bred March 10 is due December 20 ([FB 1470, p. 15](lib:care-and-management-of-dairy-cows#page=15)).
Write every breeding down. A short season of **45–60 days** gives calves of one age ([EC1514, p. 4](lib:beef-production-for-small-farms-osu-ec1514#page=4)).

**The bull.** One bull serves about **25 cows**: own one, share one, or lease one tested free of the venereal diseases
trich and vibrio; a shared bull brings disease, and "bulls also pose a safety risk" ([EC1514, p. 4](lib:beef-production-for-small-farms-osu-ec1514#page=4)).
One family gave its calf to the bull's owner for three seasons of service ([*Keeping One Cow*, p. 46](lib:keeping-one-cow#page=46)).
Pick sound feet and legs, big testicles and a good mother. A bull is half of every calf and over the years up to 80% of
the herd's blood, so avoid inbreeding, which brings dwarf and deformed calves ([*Raising Healthy Cattle*, p. 41](lib:raising-healthy-cattle-cvm#page=41));
swap bulls between neighborhoods every few years *(rule of thumb)*. Many cows coming back into heat points to vibriosis
([p. 118](lib:raising-healthy-cattle-cvm#page=118)). Horned bulls are "decidedly more dangerous" ([FB 1470, p. 38](lib:care-and-management-of-dairy-cows#page=38)):
**never turn your back on a bull or handle one alone** *(rule of thumb)*. A skilled hand can feel a calf through the
rectum at 60 days ([*Raising Healthy Cattle*, p. 44](lib:raising-healthy-cattle-cvm#page=44)); otherwise watch for the
next heat 3 weeks after breeding *(rule of thumb)*.

## 🍼 Calving: when and how to help

**When to calve here.** In western Oregon, late fall and winter calving brings mud, scours and pneumonia; spring
calving puts cows on growing grass ([EC1514, p. 4](lib:beef-production-for-small-farms-osu-ec1514#page=4)). **Beef
cows: March–April. The family cow: September–October**, dry through the hot, smoky end of summer and milking all
winter ([FB 1470, p. 8](lib:care-and-management-of-dairy-cows#page=8); *rule of thumb*).

**Signs and setting.** 24–72 hours ahead the ligaments beside the tailhead loosen, the vulva swells, mucus shows and
the udder fills ([*Raising Healthy Cattle*, p. 53](lib:raising-healthy-cattle-cvm#page=53)); close to it she may wander
off, stop eating, and get up and down ([Mississippi P2675, p. 2](lib:calving-management-mississippi-p2675#page=2)). Give a
clean, dry, well-bedded pen in wet weather, keep children and dogs away ([FB 1470, pp. 7, 32](lib:care-and-management-of-dairy-cows#page=7)),
and **check at least every 3 hours** ([Mississippi, p. 2](lib:calving-management-mississippi-p2675#page=2)). Have
lubricant, shoulder-length sleeves, soap, warm water, towels, and obstetric (OB) chains or soft ropes with handles
([p. 5](lib:calving-management-mississippi-p2675#page=5)). **Wear gloves:** brucellosis and other birth infections reach
people ([*Raising Healthy Cattle*, pp. 54, 118](lib:raising-healthy-cattle-cvm#page=54)).

**Stages:** getting ready, **2–6 hours**, contractions 15 minutes apart, then the water bag; **delivery, 30–60
minutes**, heifers longer; **afterbirth, 2–12 hours** ([Nebraska EC1907, pp. 2–3](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=2);
[Mississippi, p. 2](lib:calving-management-mississippi-p2675#page=2)). **Help when** there is no calf **2 hours after the
water bag** ([*Raising Healthy Cattle*, p. 53](lib:raising-healthy-cattle-cvm#page=53)), after **30 minutes of straining
with no progress** ([Mississippi, p. 5](lib:calving-management-mississippi-p2675#page=5)), or sooner if the legs look wrong
or she is worn out; Nebraska allows heifers 2–3 hours and cows 1–2 ([p. 3](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=3)).

**Helping** ([Nebraska, pp. 3–4](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=3); [Mississippi, pp. 6–7](lib:calving-management-mississippi-p2675#page=6); [FB 1470, p. 32](lib:care-and-management-of-dairy-cows#page=32)):
1. Scrub her vulva and your arms; sleeve and lubricate. **Feel which legs are coming** (the picture).
2. **Size check:** pulling the front legs, the whole head should enter her pelvis and each fetlock come a hand's width
   past the vulva. If not, the calf may be too big: get the most skilled person you can.
3. **Chains:** two loops on each leg (the picture); **never a chain on the jaw**.
4. **Pull only while she strains**, a few inches on one leg, then the other ("walking out" the shoulders); once head and
   shoulders are out, pull **down at about 45°**. Hips stuck: push back a little and turn the calf a quarter turn.
5. **Never pull with a vehicle;** a calf jack pulls like seven men and kills in unskilled hands
   ([Mississippi, p. 6](lib:calving-management-mississippi-p2675#page=6); [Nebraska, p. 4](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=4)).

![Three drawings: a front leg coming with sole down and both joints folding the same way, nose on top; a hind leg coming with sole up and the hock folding the opposite way; and a calf's leg with a chain looped above the fetlock and half-hitched between fetlock and hoof](img:CATTLE-GUIDE/calving-front-or-hind-legs-and-chains.svg)
*Front or hind? Feel the soles and the two joints; then two loops of chain on each leg ([Mississippi, pp. 6–7](lib:calving-management-mississippi-p2675#page=6); [Nebraska, p. 3](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=3)) (a diagram drawn for this guide).*

**Wrong positions**, about 5% of calves ([Nebraska, p. 2](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=2);
[*Raising Healthy Cattle*, pp. 55–58](lib:raising-healthy-cattle-cvm#page=55); [Mississippi, pp. 4–5](lib:calving-management-mississippi-p2675#page=4)).
Push the calf back between contractions, and **cup each hoof in your hand** as you bring it up, so it can't tear the womb.
- **A leg back:** push the calf back, lift the knee, then bring the foot forward. **Head back or down:** push the legs
  back, bring the head (gently by the jaw or a nostril) onto them, then the legs.
- **Hind feet first:** pull it **quickly**; the cord is pinched and the calf drowns if you wait
  ([*Raising Healthy Cattle*, p. 56](lib:raising-healthy-cattle-cvm#page=56)). **Only the tail (breech):** push the rump
  forward, bring each hock up, then each foot; check for a twin ([p. 58](lib:raising-healthy-cattle-cvm#page=58)).
- **Upside down:** maybe a twisted womb; skilled help only (same page).

![Six old drawings of a calf in the womb in wrong positions: 1 one front leg back, 2 front legs bent at the knee, 3 a front leg crossed over the neck, 4 head bent down, 5 head turned back, 6 calf on its back](img:CATTLE-GUIDE/wrong-calf-positions.png)
*Wrong positions: 1 one leg back, 2 knees bent, 3 leg over the neck, 4 head down, 5 head back, 6 upside down ([Diseases of Cattle, pp. 237, 239](lib:usda-special-report-on-diseases-of-cattle-1923#page=237)).*

**The first hours:**
1. **Breathing:** clear nose and mouth by hand, rub the calf hard or tickle a nostril with a straw. Still not breathing?
   Put a short hose in one nostril, hold the mouth and other nostril shut, and blow every 5–7 seconds ([Nebraska, p. 4](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=4)).
2. **Navel:** soak it in **7% iodine**; tie a bleeding cord with iodined string ([*Raising Healthy Cattle*, p. 67](lib:raising-healthy-cattle-cvm#page=67)).
3. **[Colostrum](wiki:Colostrum):** nursing **within an hour** ([Nebraska, p. 5](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=5));
   **10% of its weight within 4 hours, 20% within 24** ([EC1514, p. 5](lib:beef-production-for-small-farms-osu-ec1514#page=5)),
   about 8 lb (4 quarts) in 4 hours for an 80-lb calf *(arithmetic)*. None is absorbed after 24 hours; spare colostrum
   can be "allowed to sour" and kept ([*Raising Healthy Cattle*, p. 67](lib:raising-healthy-cattle-cvm#page=67)).
4. **The cow:** warm water to drink, and **don't milk her out for a day or two**, against milk fever
   ([FB 1470, p. 7](lib:care-and-management-of-dairy-cows#page=7)).
5. **Afterbirth: never pull it.** If she eats well, let it drop by itself, even 10 days ([*Raising Healthy Cattle*, p. 62](lib:raising-healthy-cattle-cvm#page=62);
   [Mississippi, p. 3](lib:calving-management-mississippi-p2675#page=3)); fever or a stinking discharge needs skilled help.
   Bury afterbirths: they draw predators ([Mississippi, p. 5](lib:calving-management-mississippi-p2675#page=5)).
6. **Womb pushed out (prolapse):** keep her lying still, the womb clean and wet in a clean sheet *(rule of thumb)*, and
   get the most skilled hands you can ([*Raising Healthy Cattle*, p. 61](lib:raising-healthy-cattle-cvm#page=61)).

📚 **Go deeper:** [*Raising Healthy Cattle*, pp. 52–65](lib:raising-healthy-cattle-cvm#page=53) — positions with drawings, prolapse, milk fever; [Nebraska EC1907](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=2) and [Mississippi P2675](lib:calving-management-mississippi-p2675#page=4) — stages, positions, chains.

## 🐮 Raising calves

**On the cow,** beef calves nurse until **7–8 months** ([EC1514, p. 5](lib:beef-production-for-small-farms-osu-ec1514#page=5));
wean across a fence with a couple of hot wires, so cow and calf still see and hear each other ([p. 6](lib:beef-production-for-small-farms-osu-ec1514#page=6)).
**By bucket:** take the calf off after colostrum and feed whole milk at **4–5% of its weight twice a day**
([*Raising Healthy Cattle*, p. 68](lib:raising-healthy-cattle-cvm#page=68)), **2–4 quarts at 101–105 °F**
([OSU EM 9280, p. 2](lib:new-calf-care-osu-em9280#page=2)). Teach it to drink by letting it suck your fingers as you
lower its nose into the pail ([*Keeping One Cow*, pp. 16–17](lib:keeping-one-cow#page=16)). Offer a little grain from
2–4 weeks and hay from 4–5 weeks; **wean when it eats 1 lb of grain a day**, at 6–8 weeks ([*Raising Healthy Cattle*, pp. 68, 71](lib:raising-healthy-cattle-cvm#page=68)),
or 8–14 weeks ([UNH, p. 11](lib:4-h-working-steer#page=11)). Always clean water, scalded buckets, and a mineral block
from 3 months. House each calf in 18 sq ft, or a 4×8-ft hutch facing the sun with a small yard
([*Raising Healthy Cattle*, p. 70](lib:raising-healthy-cattle-cvm#page=70)), on deep dry straw with fresh air but no
drafts; ammonia smell at calf height means new bedding ([EM 9280, p. 2](lib:new-calf-care-osu-em9280#page=2)). Don't let
calves suck each other: it brings mastitis later ([*Raising Healthy Cattle*, p. 88](lib:raising-healthy-cattle-cvm#page=88)).

**Scours (diarrhea)** kill more calves than anything else ([*Raising Healthy Cattle*, p. 68](lib:raising-healthy-cattle-cvm#page=68)).
Mix **2 liters (about 2 quarts) of water, 1 teaspoon of salt and 2 teaspoons of baking soda**; give 1–2 liters 2–3
times a day, by tube if the calf is too weak ([p. 69](lib:raising-healthy-cattle-cvm#page=69)). **Keep feeding milk**
and give the electrolyte between feeds, never mixed in ([EM 9280, p. 2](lib:new-calf-care-osu-em9280#page=2)); *Raising
Healthy Cattle* says stop milk 24–48 hours, but follow OSU's newer advice. A calf that won't drink, can't stand or runs
over **104 °F** needs skilled help (same page). Prevent scours with colostrum, dry pens and sick calves kept apart
([*Raising Healthy Cattle*, p. 70](lib:raising-healthy-cattle-cvm#page=70)). Most Northwest calves need a **selenium shot
at birth**, label dose only; while vaccines last, give a 7- or 8-way clostridial vaccine with tetanus at 2–3 months,
a booster 3–6 weeks later and again at 6 months ([EC1514, p. 11](lib:beef-production-for-small-farms-osu-ec1514#page=11)).
One-cow families once sold the calf at 4 weeks ([*Keeping One Cow*, p. 17](lib:keeping-one-cow#page=17)); now keep
heifers to replace the cow and raise steers for beef or a team *(rule of thumb)*.

## ✂️ Castration, dehorning and marking

Steers are safer, easier to handle and gain faster than bulls ([*No Animal Doctor*, p. 187](lib:where-there-is-no-animal-doctor-cvm-2024#page=187)).
**When:** beef calves as young as you can, from a few days to **3 months** ([*Raising Healthy Cattle*, p. 73](lib:raising-healthy-cattle-cvm#page=73)),
or 2–3 months ([*No Animal Doctor*, p. 187](lib:where-there-is-no-animal-doctor-cvm-2024#page=187)); **future oxen at
6 months to 1 year**, so they grow a wider head and stronger horns first ([UNH, p. 20](lib:4-h-working-steer#page=20)).
Very young castration brings more urinary stones later ([*No Animal Doctor*, p. 187](lib:where-there-is-no-animal-doctor-cvm-2024#page=187)).
Pick cool weather out of fly season, after a clostridial and tetanus shot if you have one ([UNH, p. 20](lib:4-h-working-steer#page=20);
[*Raising Healthy Cattle*, p. 73](lib:raising-healthy-cattle-cvm#page=73)).

**The knife** ([*No Animal Doctor*, pp. 188–189](lib:where-there-is-no-animal-doctor-cvm-2024#page=188); [*Raising Healthy Cattle*, pp. 73–74](lib:raising-healthy-cattle-cvm#page=73)):
1. Tie the calf; wash your hands and the scrotum with soap, clean water and disinfectant; local anesthetic if you have it.
2. Pull the scrotum tight and cut off its **lower third**. Pull each testicle out steadily until the cord breaks (or
   scrape the cord through); trim hanging tissue. **Over about 6 months,** tie each cord tightly twice with clean string
   and cut below the tie.
3. Fly ointment on the wound, and **walk the calf daily for 1–2 weeks** so it drains. Bleeding steadily over 15
   minutes: pack the scrotum with clean cotton and close it with clothespins for 12–24 hours ([*Raising Healthy Cattle*, p. 74](lib:raising-healthy-cattle-cvm#page=74)).

**[Burdizzo](wiki:Burdizzo) (crushing clamp):** no wound. Crush each cord separately, **twice, at different heights**,
never across both at one level, or the scrotum dies ([*Raising Healthy Cattle*, p. 74](lib:raising-healthy-cattle-cvm#page=74);
[*No Animal Doctor*, pp. 187–188](lib:where-there-is-no-animal-doctor-cvm-2024#page=187)). **Rubber ring:** only young
calves with small testicles, at 1–2 months ([UNH, p. 20](lib:4-h-working-steer#page=20)); "less preferable" where tetanus
is about ([*No Animal Doctor*, p. 189](lib:where-there-is-no-animal-doctor-cvm-2024#page=189)). Pain relief such as
meloxicam needs a vet's prescription ([EM 9280, p. 2](lib:new-calf-care-osu-em9280#page=2)).

**Dehorning:** a hot iron before **4 months** ([*Raising Healthy Cattle*, p. 75](lib:raising-healthy-cattle-cvm#page=75));
caustic paste works only in the first 10 days and runs into eyes in rain ([p. 76](lib:raising-healthy-cattle-cvm#page=76)),
so use the iron in our wet winters. On older cattle saw the horn off close, taking a ring of skin or it regrows, dress
with pine tar, stop bleeding with a string twisted around the stubs for about 12 hours, and do it late fall to early
spring, when there are no flies ([FB 1470, p. 39](lib:care-and-management-of-dairy-cows#page=39)). **Leave horns on
oxen** ([UNH, p. 7](lib:4-h-working-steer#page=7)) and on cows that must guard calves: some "let the horns grow so the
animals will be able to protect themselves" ([*Raising Healthy Cattle*, p. 75](lib:raising-healthy-cattle-cvm#page=75)).

**Marking:** ear tags, a neck strap with a tag, or a tattoo; slitting ears is "a cruel practice" ([FB 1470, pp. 15–16](lib:care-and-management-of-dairy-cows#page=15));
a red-hot brand held about 3 seconds on dry hide ([*Raising Healthy Cattle*, p. 77](lib:raising-healthy-cattle-cvm#page=77)).
**Oregon law:** a brand inspection to move cattle, except calves under 30 days ([EM 9280, p. 1](lib:new-calf-care-osu-em9280#page=1)).
Brands and tags also bring evacuated cattle home after a fire ([PNW783, p. 7](lib:wildfires-smoke-and-livestock-pnw783#page=7)).

## 🩺 Cattle health with no vet

**Know normal** ([*No Animal Doctor*, pp. 66–67](lib:where-there-is-no-animal-doctor-cvm-2024#page=66)): **101.5 °F**
over a year old, 102.5 °F under, and worry over **103 °F** ([UNH, p. 13](lib:4-h-working-steer#page=13)); pulse about
**50** in adults and 125 in newborns, felt in the groove under the tail; about **16** breaths a minute. A fist pressed
into the left flank should feel the rumen roll **2–3 times a minute** ([*Raising Healthy Cattle*, p. 106](lib:raising-healthy-cattle-cvm#page=106)).
A healthy animal is alert, eats, chews its cud, drinks, and has a shiny coat, normal manure and an easy walk
([UNH, p. 13](lib:4-h-working-steer#page=13)). **A drooling, bellowing cow may have rabies:** keep your hands out of
her mouth ([*Raising Healthy Cattle*, p. 127](lib:raising-healthy-cattle-cvm#page=127)).

| Problem | Signs | What to do |
|---|---|---|
| **[Bloat](wiki:Ruminal_tympany)** | Left side high and drum-tight, then both; hard breathing; after lush legumes or grain | Keep her up, head uphill; pass a stomach tube or hose ([*No Animal Doctor*, p. 205](lib:where-there-is-no-animal-doctor-cvm-2024#page=205)). Frothy bloat: vegetable oil by tube, about a pint ([*Raising Healthy Cattle*, pp. 169–170](lib:raising-healthy-cattle-cvm#page=169)); *No Animal Doctor* gives 1–4 liters every 2–4 hours ([p. 207](lib:where-there-is-no-animal-doctor-cvm-2024#page=207)). **Going down:** puncture the left flank (the picture) |
| **Choke** | Drools, coughs, stops eating; a lump on the left of the neck | Work the lump up by hand; a pint of raw linseed or olive oil helps ([FB 1470, p. 34](lib:care-and-management-of-dairy-cows#page=34)). A stiff tube can tear the gullet ([*Raising Healthy Cattle*, p. 166](lib:raising-healthy-cattle-cvm#page=166)) |
| **[Hardware disease](wiki:Hardware_disease)** | Off feed, arched back, a grunt at each step | Keep her quiet, little bulky feed; a magnet by mouth if you have one ([FB 1470, p. 36](lib:care-and-management-of-dairy-cows#page=36); [*Raising Healthy Cattle*, p. 166](lib:raising-healthy-cattle-cvm#page=166)) |
| **[Milk fever](wiki:Milk_fever)** | Within 2 days of calving: staggers, goes down with her head turned to her flank, cold | **Calcium gluconate** under the skin in 3–4 places, or slowly into a vein while listening to the heart; milk her only a little ([*No Animal Doctor*, pp. 289–290](lib:where-there-is-no-animal-doctor-cvm-2024#page=289)). With no calcium, the old way pumped filtered air into all four quarters through a sterile milk tube and tied the teats ([FB 1470, p. 33](lib:care-and-management-of-dairy-cows#page=33)); the same page names milk tubes as a cause of mastitis |
| **Ketosis** | Days to weeks after calving: off feed, milk drops, sweet breath | **Propylene glycol, 200–500 mL by mouth daily** for several days; treat the illness behind it ([*No Animal Doctor*, p. 290](lib:where-there-is-no-animal-doctor-cvm-2024#page=290)) |
| **[Grass tetany](wiki:Grass_tetany)** | On lush spring grass: nervous, staggers, falls thrashing, or found dead | Calcium-magnesium into the vein, slowly ([*No Animal Doctor*, p. 329](lib:where-there-is-no-animal-doctor-cvm-2024#page=329)) |
| **[Mastitis](wiki:Mastitis)** | Hot, hard quarter; clots or watery milk | **Strip that quarter every 2–3 hours**, warm packs, dry bedding; udder tubes per label, milk discarded for the withdrawal time ([*Raising Healthy Cattle*, pp. 87–88](lib:raising-healthy-cattle-cvm#page=87)) |
| **Foot rot** | Lame, red and swollen between the claws, foul smell | Clean the foot, keep her dry; bad cases get cotton smeared with pine tar between the claws, bandaged ([FB 1470, p. 34](lib:care-and-management-of-dairy-cows#page=34)); antibiotics help early ([*Raising Healthy Cattle*, p. 115](lib:raising-healthy-cattle-cvm#page=115)) |
| **Pneumonia, shipping fever** | Cough, fever, snotty nose after stress or bad weather | Daily temperatures; antibiotics early; fresh air, no drafts ([*Raising Healthy Cattle*, pp. 116–117](lib:raising-healthy-cattle-cvm#page=116)) |
| **Pinkeye** | Watery, then cloudy eye; flies | Shade, fly control, antibiotic in the eye ([*Raising Healthy Cattle*, p. 120](lib:raising-healthy-cattle-cvm#page=120)) |
| **Lice, warbles** | Hair falling out at the tailhead and withers; lumps along the back | Treat the whole herd; squeeze the warble grubs out ([FB 1470, p. 36](lib:care-and-management-of-dairy-cows#page=36)) |
| **Worms, liver fluke** | Thin, rough coat, pot belly, bottle jaw | No grazing under 3 in; treat only poor-doers ([EC1514, pp. 14–15](lib:beef-production-for-small-farms-osu-ec1514#page=14)); fence off snail ground |
| **Blackleg, tetanus** | Young cattle found dead with a crackling, swollen leg; or stiff, lockjawed after a wound | Rarely cured: vaccinate. **Don't open a blackleg carcass** (it looks like anthrax); burn or bury it deep ([*Raising Healthy Cattle*, pp. 109–111](lib:raising-healthy-cattle-cvm#page=109)) |
| **Abortion: [brucellosis](wiki:Brucellosis), lepto** | Calves lost; afterbirth kept | Pen her apart while she discharges; burn or bury calf, afterbirth and bedding ([FB 1470, p. 31](lib:care-and-management-of-dairy-cows#page=31)); boil her milk ([*Raising Healthy Cattle*, pp. 117–119](lib:raising-healthy-cattle-cvm#page=117)) |
| **Waterbelly** (steers) | Strains, tail twitching, no urine | Needs surgery ([*Raising Healthy Cattle*, pp. 167–168](lib:raising-healthy-cattle-cvm#page=167)); with none, butcher him early while fit to eat *(rule of thumb)* |
| **Ringworm** | Round bald patches | Catches on people: wash your hands; don't share halters ([UNH, p. 18](lib:4-h-working-steer#page=18)) |

![The left side of a cow showing the backbone, the last rib and the point of the hip, with a shaded triangle between them and an X halfway from the last rib to the hip, the same distance down from the backbone](img:CATTLE-GUIDE/bloat-puncture-site-left-flank.svg)
*Bloat, last resort: on the LEFT side, halfway from the last rib to the hip bone and the same distance down from the backbone ([*Raising Healthy Cattle*, p. 169](lib:raising-healthy-cattle-cvm#page=169); [FB 1470, p. 35](lib:care-and-management-of-dairy-cows#page=35); [*No Animal Doctor*, p. 206](lib:where-there-is-no-animal-doctor-cvm-2024#page=206)) (a diagram drawn for this guide).*

**Medicines:** the label dose, the full course, and the **withdrawal time** before using milk or meat; a fever should
start to fall within 24–48 hours, and keep epinephrine for drug reactions ([*Raising Healthy Cattle*, pp. 94–96](lib:raising-healthy-cattle-cvm#page=94)).
See [Medical — Read Me First](guide:Medical-READ-ME-FIRST). **No scale?** Weight in pounds ≈ heart girth × heart girth
× length from point of shoulder to pin bone, in inches, ÷ 300 ([UNH, p. 12](lib:4-h-working-steer#page=12)); the
manual prints "2 × heart girth," a misprint for girth squared *(our reading)*. A 70-in girth and 60-in length gives
about 980 lb *(arithmetic)*. **Wounds:** pressure, soap and water; stitch only wounds under 12 hours old; open an abscess
at its lowest point; a grown animal over about 440 lb with a broken leg seldom heals, so butcher it
([*Raising Healthy Cattle*, pp. 92–93](lib:raising-healthy-cattle-cvm#page=92)). **Hooves:** handle feet from calfhood;
trim with nippers, rasp and hoof knife a little at a time, stopping before the pink "quick" and leaving the heel, until
a flat board sits square on the sole; oxen worked daily wear their own down ([UNH, pp. 20–21](lib:4-h-working-steer#page=20)).

**Butcher or put down?** Slaughter an animal that can stand and walk, isn't in severe pain and carries no drug; kill and
dispose of one that can't ([UF VM114, p. 4](lib:humane-euthanasia-of-sick-and-injured-livestock-uf-vm114#page=4)). Cull
cows that suck themselves ([FB 1470, p. 38](lib:care-and-management-of-dairy-cows#page=38)), ruined udders, cows that
won't settle, and chronic poor-doers *(rule of thumb)*. **Stock now** ([*Raising Healthy Cattle*, pp. 91–92](lib:raising-healthy-cattle-cvm#page=91);
[Mississippi, p. 5](lib:calving-management-mississippi-p2675#page=5)): rope halters, nose tongs, thermometer; OB chains,
sleeves, lubricant, 7% iodine; bandages, needles, syringes and suture; penicillin, tetracycline, mastitis tubes, calcium
gluconate, propylene glycol, electrolyte mix, epinephrine; a stomach tube, trocar, burdizzo, hoof knife, nippers, and
selenium mineral.

📚 **Go deeper:** [*Raising Healthy Cattle*, pp. 100–172](lib:raising-healthy-cattle-cvm#page=104) — every disease with drawings; [*Where There Is No Animal Doctor*](lib:where-there-is-no-animal-doctor-cvm-2024#page=66) — exams, drenching, injections; [Zoonoses](lib:zoonoses-diseases-animals-give-people-cvm#page=29) — brucellosis and TB in people.

## 🐃 Oxen: choosing and training a team

An **ox** is a castrated bull trained to pull ([Peace Corps *Animal Traction*, p. 17](lib:animal-traction-peace-corps#page=17)):
slower than a horse, but it lives on rough feed, needs little harness and ends as beef *(rule of thumb)*. Harness,
carts and hauling are in the [Horses guide](guide:HORSE-GUIDE).

**Choosing** ([UNH *Working Steer Manual*, pp. 5–7](lib:4-h-working-steer#page=5)): **two young bull calves** of the
same size and bone (half-brothers from one dairy match well; a fine-boned calf won't keep up with a heavy-boned one).
Look for an alert calf that stretches when it gets up, a straight back, square feet, strong pasterns, a wide chest, no
navel hernia, two testicles, and clean coat, eyes and nose. **They must have horns:** horns hold a cart back downhill,
and hornless cattle "do not make a desirable team" ([p. 45](lib:4-h-working-steer#page=45)). For breeds, see the table above.

**Training** ([UNH, pp. 22–27](lib:4-h-working-steer#page=22); [Peace Corps, p. 59](lib:animal-traction-peace-corps#page=59)):
1. **Bond first:** feed them yourself daily. Give short names that don't rhyme with each other or a command ("Bow" and "Whoa").
2. **Halter-train one calf at a time,** walking at its shoulder, not in front. Every day, same place and hours; early
   morning and late afternoon are best. Peace Corps trainers ran two sessions of about 1½ hours a day.
3. **One command at a time,** at least a week each: **Whoa** (stop, and you stop too), **Giddup**, **Gee** (turn right),
   **Haw** (turn left), and **Back** last. Say the steer's name with the command.
4. **Then yoke them** and teach it all again as a pair, without halters and without pushing on the yoke. Put the slower
   steer next to you (the "nigh" steer; the far one is the "off" steer).
5. **The goad** is a light stick no longer than 4 ft, for **light taps only**: the rump for Giddup, both briskets for
   Whoa, the outside flank or ear to turn. "Never use this tool to hurt your animals" ([p. 25](lib:4-h-working-steer#page=25)).
   Reward with a chin scratch and a kind word.
6. **Cart and drag** only after all five commands. Start the drag on a pole, not a chain, so they can't step over it;
   later a chain must clear the stone-boat by 6 in when the longest steer stretches out ([pp. 28, 31](lib:4-h-working-steer#page=28)).

A team learns in **2 weeks to 2 months** ([Peace Corps, p. 59](lib:animal-traction-peace-corps#page=59)); an old
teamster said of his eight-year-old team, "They're still learning" ([UNH, p. 27](lib:4-h-working-steer#page=27)).

**Simple yokes.** A **bow yoke** is a carved hardwood beam with a U-shaped bow under each neck; it pushes against the
front of the withers ([Peace Corps, p. 83](lib:animal-traction-peace-corps#page=83)). A **head yoke** is strapped behind
the horns and makes a tight pair, good for carts that must back and brake ([p. 85](lib:animal-traction-peace-corps#page=85)).
Making a bow yoke ([UNH, pp. 39–43](lib:4-h-working-steer#page=39)): its **size** is the space between one bow's two holes,
and calves start in a **4-in yoke**, moving up as their necks grow. Use basswood or poplar for small yokes and maple,
birch or oak for big ones, straight-grained, knots cut out, weak heartwood out of the neck seats; round the seats
smooth "like the curve of your thumb"; drill the holes dead straight, about ⅛ in bigger than the bows. **Bows** are split
from straight hickory, white oak or ash, shaved, **steamed about 20 minutes** (small ones), bent, tied until dry, and
left in the yoke when not in use. **Fit:** an open hand slips between bow and neck; pulling, the yoke pushes on the neck
just above the shoulders; head tossing or balking usually means a bad fit.

![A 6-inch bow yoke seen from the front: a hardwood beam with two neck seats, a bow under each neck, 6 in between the holes of each bow, 20 in between the inside holes, ends 4–5 in, a staple and ring in the center](img:CATTLE-GUIDE/bow-yoke-6-inch-front-view.svg)
*A 6-inch yoke: 6 in between each bow's holes, 20 in between the inside holes, 1½-in bows ([UNH, pp. 39–42](lib:4-h-working-steer#page=39)) (a diagram drawn for this guide).*

**Work limits** ([*Animal Management*, pp. 311–316](lib:animal-management-british-war-office-1908#page=311)):
- **Age:** no heavy transport work before **4–5 years**; oxen work to 16–17 years on good grass, 11–12 on poor.
- **Hours:** **7–8 a day** at 2–2½ mph, **never more than 4 at a stretch**, with **6 hours' grazing** and time to chew
  the cud; graze an hour before starting. "Ruminants cannot stand being hurried."
- **Water** 3 times a day in summer, twice in winter. **Heat:** work early morning and evening, not in hot sun.
- **Cold rain:** "Bovine tolerance of wet with cold weather is small ... it is advisable to knock off work altogether."
  If you must work in rain, **grease the yoke and the necks**: a wet yoke makes "sore necks" ([p. 312](lib:animal-management-british-war-office-1908#page=312)).
- **Condition:** thin oxen pull only half as much; ease off while they shed their coats. Uphill they pull well but may
  lose heart and lie down; carts need a brake downhill ([pp. 311–312, 316](lib:animal-management-british-war-office-1908#page=311)).

**How much:** about **one-tenth of body weight in steady pull all day**; a 660-lb (300-kg) bull holds a 66-lb pull all
day but tires in 3–4 hours at 286 lb ([Peace Corps, p. 20](lib:animal-traction-peace-corps#page=20)). A 4-H team drags
**half its combined weight** on a stone-boat for a short pull, resting between turns ([UNH, pp. 31–32](lib:4-h-working-steer#page=31)).
**Here:** plow and haul in the dry months, start at dawn in summer, and rest the team through the cold rains of
November–March *(rule of thumb)*.

📚 **Go deeper:** [UNH *Working Steer Manual*](lib:4-h-working-steer#page=22) — commands, drags, yoke and bow tables; [Peace Corps *Animal Traction*](lib:animal-traction-peace-corps#page=57) — training schedules, yokes, carts and plows; [Starkey](lib:harnessing-and-implements#page=23) — yoke types and neck sores.

## 🔪 Slaughter and butchering

**When.** Only healthy animals past any drug withdrawal ([UF VM114, p. 4](lib:humane-euthanasia-of-sick-and-injured-livestock-uf-vm114#page=4));
a moderately finished yearling or 2-year-old is tenderest ([USDA FB 2209, p. 5](lib:beef-slaughtering#page=5)). **Pick
cold weather:** the carcass must chill below 40 °F inside within 24 hours without freezing ([p. 19](lib:beef-slaughtering#page=19)),
which here means **November to February** on a cold night *(rule of thumb)*. Pen the animal alone the day before, **off
feed 24 hours with water**, and don't excite it: a fevered animal bleeds poorly and bruises ([p. 6](lib:beef-slaughtering#page=6)).
**Gear** (same page): a rifle, a block and tackle, a spreader (a doubletree will do), a 6-in skinning knife, a steak
knife, steel and whetstone, a cleaver, a 28-in meat saw, a prop pole, buckets, plenty of cold water and clean cloths.

**Killing** ([UF VM114, pp. 5, 7](lib:humane-euthanasia-of-sick-and-injured-livestock-uf-vm114#page=5)):
1. **Aim** where lines from each eye to the base of the opposite horn (or just above the opposite ear) cross: mid-forehead,
   **above the eyes, not between them**. Hold the muzzle **a few inches from the head**, square to the skull; watch for ricochet.
2. **Caliber:** a **.22 long rifle** for a calf or young animal; **bulls and some grown cows need a 9 mm or .357** or larger.
3. **Bleed at once:** hoist by the hind legs, head 18–24 in off the floor; open the hide down the middle of the dewlap,
   slip the knife in under the point of the breastbone and cut the big vessels where they fork. **Don't stick the
   heart**; let it pump ([FB 2209, p. 7](lib:beef-slaughtering#page=7)).

![Photo of a black steer's face with two white lines crossing on its forehead above the eyes, from each horn base to the opposite eye](img:CATTLE-GUIDE/where-to-aim-on-a-steer.png)
*Where to aim: where lines from each horn (or poll) to the opposite eye cross, above the eyes ([USDA FB 2209, p. 6](lib:beef-slaughtering#page=6)).*

**Skinning and gutting** ([FB 2209, pp. 7–17](lib:beef-slaughtering#page=7); [*Slaughter and Preservation of Meat*, pp. 54–59](lib:slaughter-and-preservation-of-meat-cvm#page=54)):
take the head off at the first joint and the feet at their joints; skin belly and sides with the carcass propped on its
back, keeping hair off the meat; tie off the gullet and the rear gut (bung) with string; open the belly with the edge
facing out, guarded by your hand, and **don't cut the paunch or guts**; cut the gall bladder off the liver; lift out
heart and lungs together; saw down the middle of the backbone, wash in cold water, and **hang the sides apart** to chill.
**Look at the organs:** single abscesses and bruises can be trimmed, but inflamed lungs or guts, or yellowish pearl-like
growths scattered through the organs, are serious ([FB 2209, p. 17](lib:beef-slaughtering#page=17)). Boil and bury offal
with worms or cysts; never feed it raw to dogs ([*Slaughter and Preservation of Meat*, p. 59](lib:slaughter-and-preservation-of-meat-cvm#page=59)).
Save tongue, cheek meat, heart, liver and tail in cold water; the first two stomachs make tripe ([FB 2209, pp. 9, 17](lib:beef-slaughtering#page=17)).

**How much meat.** A **750-lb steer** gives a **420-lb carcass** ([FB 2209, p. 31](lib:beef-slaughtering#page=31)): about
**170 lb of steaks and roasts, 84 lb of pot roasts, 84 lb of stew and ground meat, 80 lb of fat and bone** *(arithmetic
from the book's percentages; its table prints 112 lb for steaks, a misprint)*.

![Outline of a side of beef with dashed cutting lines and labels: hock, round, rump, loin end, short loin, flank, prime rib, plate, brisket, chuck, fore shank, with numbered points for each cut](img:CATTLE-GUIDE/side-of-beef-primal-cuts.png)
*A side of beef and its main cuts; the numbered points are where FB 2209 cuts, step by step ([USDA FB 2209, p. 22](lib:beef-slaughtering#page=22)).*

### No freezer: what to do with 400 lb of beef

Fresh beef keeps only at **34–36 °F** ([FB 2209, p. 31](lib:beef-slaughtering#page=31)); hung in a cool, airy place
without that, **no more than 3 days** ([*Slaughter and Preservation of Meat*, p. 89](lib:slaughter-and-preservation-of-meat-cvm#page=89)).
1. **Make it smaller:** a veal calf of 1–3 months (160–200 lb) ([FB 2209, p. 34](lib:beef-slaughtering#page=34)), or share
   the beef. Under Oregon rules, neighbors splitting a beef should each **own a share of the live animal**; custom-cut
   meat can't be sold, traded or given away ([OSU EM 9345, pp. 2–3](lib:oregon-custom-exempt-slaughter-faq-osu-em9345#page=2)).
2. **Eat fresh first:** in cold weather hang the sides about a week, then cut ([FB 2209, p. 31](lib:beef-slaughtering#page=31)).
   **Bone it hot** for ground meat and sausage the same day ([*Slaughter and Preservation of Meat*, p. 131](lib:slaughter-and-preservation-of-meat-cvm#page=131)).
3. **[Corned beef](wiki:Corned_beef)** from the plate, rump and chuck ([FB 2209, p. 32](lib:beef-slaughtering#page=32)): per
   100 lb of boned meat, rub with **8–10 lb of coarse salt** and pack in a clean barrel or crock; after 24 hours cover
   with **4 lb sugar, 4 oz saltpeter and 2 oz baking soda in 4 gallons of water**; weight it and cure **30–40 days**,
   below about 38 °F. Weigh the saltpeter; never add extra. Ropy brine: wash the meat, fresh brine.
4. **Dried beef:** cure the round the same way (a pound more sugar), dry 24 hours, and smoke at **130–140 °F** for 70–80
   hours until quite dry; store it dry, dark and fly-free (same page).
5. **Plain salt:** 1 part salt to 3 parts meat, strips under 1 in thick, layered in salt and kept under the brine at least
   **28 days**; throw it out if the brine turns sour, thick or ropy ([*Slaughter and Preservation of Meat*, pp. 90–93](lib:slaughter-and-preservation-of-meat-cvm#page=90)).
6. **Can it in a pressure canner only:** a water bath doesn't get hot enough ([FB 2209, p. 33](lib:beef-slaughtering#page=33)).
   **Jerky** from lean strips. Steps and safety: "Jerky and pemmican," "Settings for the Illinois Valley" and "Curing pork
   and venison" in the [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE).

## ♻️ Hides and tallow

**The hide:** let it cool, spread it hair side down, scrape off flesh and blood, and **rub in about 1 lb of clean salt
per pound of hide**, well into edges, head, legs and folds ([USDA FB 2209, p. 34](lib:beef-slaughtering#page=34)); it keeps
**3–5 months** if it never freezes or heats ([USDA FB 1334, p. 8](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=8)).
A cow or steer hide of **40–70 lb** makes sole, harness and belting leather; a 20–40-lb hide makes lace leather (same
page). Split a big hide down the backbone into two sides. Warble holes spoil hides ([FB 1470, p. 36](lib:care-and-management-of-dairy-cows#page=36)),
and a beginner shouldn't try a hair-on cattle robe or rug ([FB 1334, p. 23](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=23)).
Bark tanning and rawhide: "Tanning hides" in the [Clothing, Leather & Shoes guide](guide:CLOTHING-LEATHER-GUIDE).

**[Tallow](wiki:Tallow):** save the caul and ruffle fat around the paunch and guts "as tallow for soap" ([FB 2209, p. 17](lib:beef-slaughtering#page=17))
and the kidney fat ([p. 25](lib:beef-slaughtering#page=25)). Render it within a week, slowly, never in copper ("Salt,
sweeteners and fat" in the [Food From Scratch guide](guide:FOOD-FROM-SCRATCH-GUIDE)); then make candles ([Light Without
the Grid](guide:LIGHTING-GUIDE)), soap ("Soap from fat and ashes" in the [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)),
pemmican, or **[dubbin](wiki:Dubbin)** for boots and harness: about equal parts tallow and neatsfoot or cod oil
([FB 1334, p. 23](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=23)). **Manure:** spread it soon,
but not on snow or soggy ground; store the rest packed and moist under cover ([FB 1470, p. 24](lib:care-and-management-of-dairy-cows#page=24)),
and compost it before it touches food crops ([Sanitation guide](guide:SANITATION-GUIDE)).

## 🐺 Predators and loose dogs

**Calves are what predators take:** in California, predators caused about **1% of grown cattle deaths but 6% of calf
deaths** ([UC ANR 8598, p. 3](lib:livestock-protection-tools#page=3)). **Calve in a shed or pen near the house**, rated
highly effective against dogs, coyotes, lions, bears, wolves, foxes and bobcats ([p. 5](lib:livestock-protection-tools#page=5)).
Remove dead stock, gut piles and afterbirths, which draw predators ([p. 9](lib:livestock-protection-tools#page=9)); they
go for cows struggling to calve and calves slow to stand ([Mississippi, p. 5](lib:calving-management-mississippi-p2675#page=5)).
See "Dead animals and gut piles" in the [Sanitation guide](guide:SANITATION-GUIDE). **[Cougars](wiki:Cougar):** "Fence
and shelter livestock. Move them to sheds or barns at night"; **Oregon law lets a landowner kill a cougar that is
damaging livestock**; call ODFW ([ODFW, p. 2](lib:oregon-is-cougar-country-odfw#page=2)). **Bears:** "Store livestock food
in a secure place" ([ODFW bears, p. 2](lib:living-with-black-bears-odfw#page=2)). **Guardian dogs** bonded to cattle cut
coyote and wolf visits ([UC ANR, p. 6](lib:livestock-protection-tools#page=6)); see the [Dogs guide](guide:DOGS-GUIDE). Cattle grazed with
sheep or goats give the small stock some cover ([p. 5](lib:livestock-protection-tools#page=5)), and a horned cow can
defend her calf ([*Raising Healthy Cattle*, p. 75](lib:raising-healthy-cattle-cvm#page=75)).

## 🔥 Fire season and smoke

**Grazing is fire prevention:** grazing 40–50% of the growing grass breaks up fuel, and ungrazed bunchgrass was **200%
more likely to burn** than grass grazed in spring ([PNW783, p. 3](lib:wildfires-smoke-and-livestock-pnw783#page=3));
graze hard along roads and around buildings each spring *(rule of thumb)*. **Plan before July:** which animals leave,
where to (two or three places), who moves them, and water if the power fails ([p. 7](lib:wildfires-smoke-and-livestock-pnw783#page=7)).
Evacuate early, calmly, in daylight (same page). Cattle that stay go in a **heavily grazed pasture**, gates open, with
feed and water for **7–10 days**; store hay apart; with milk cows, sheltering in place may be best, but move calves,
heifers and dry cows ([p. 8](lib:wildfires-smoke-and-livestock-pnw783#page=8)). **In smoke:** less work (no oxen), no
weaning, vaccinating or moving, clean water always, shade, wet down dust; heat makes smoke harm worse in cattle
([p. 10](lib:wildfires-smoke-and-livestock-pnw783#page=10)). **After:** keep cattle off ash-fouled feed and water, check
burned animals daily, and give smoke-hurt lungs **several weeks** ([ODA, p. 1](lib:caring-for-livestock-after-wildfire-oregon-oda#page=1)).
**No open burning June–October:** bury afterbirths and carcasses in summer *(rule of thumb)*. See "Animals and livestock"
in the [Wildfire guide](guide:WILDFIRE-GUIDE).

## 📅 A cattle year in the Illinois Valley

| When | Cattle | Work |
|---|---|---|
| Dec–Feb | Rain and mud; beef cows late in pregnancy; family cow milking on hay | Dry footing and bedding; **pregnant cows away from ponderosa pines**; butcher on cold nights; oxen rested in cold rain; make bows, yokes and goads; breed the family cow (December) for a September calf |
| Mar–Apr | **Beef calving**; grass starts | Calving pen ready; colostrum and iodine; castrate and dehorn before the flies; onto pasture slowly (bloat); watch for death camas and larkspur |
| May–Jun | Fast grass; breeding | Bull in for **45–60 days** (bred June 1 → calves about March 10, *arithmetic*); **make hay** before it flowers; plow and haul in cool mornings |
| Jul–Aug | Brown pasture, heat, smoke, fire season | **Dry off the family cow**; water and shade; hay for the dry spell; oxen at dawn only; fire plan; graze down fuel near buildings |
| Sep–Oct | **Family cow calves**; first rains | Wean spring calves at 7–8 months across a fence; trim feet, fix sheds and gutters before the mud; haul firewood; **butcher steers when nights turn cold** |
| Nov | Rains set in | Oxen off work in cold rain; hay inside; check for lice at the tailhead |

The calving seasons follow [EC1514, p. 4](lib:beef-production-for-small-farms-osu-ec1514#page=4) and
[FB 1470, p. 8](lib:care-and-management-of-dairy-cows#page=8); the local fit is a *rule of thumb*.

## 👪 Numbers for a family

| Goal | What it takes | Source |
|---|---|---|
| Milk | One average cow: about **2,900 quarts a year**, 9–10 a day in milk; enough for 2–5 families | [FB 1470, p. 5](lib:care-and-management-of-dairy-cows#page=5); [*Keeping One Cow*, p. 11](lib:keeping-one-cow#page=11) *(arithmetic)* |
| Butter | An old rule: a quart of milk a day gives about a pound of butter a week | [*Keeping One Cow*, p. 18](lib:keeping-one-cow#page=18) |
| Beef | A 750-lb steer: about **340 lb of trimmed meat**, some 6½ lb a week for a year | [FB 2209, p. 31](lib:beef-slaughtering#page=31) *(arithmetic)* |
| Calves | One a year per cow: 283 days' pregnancy, rebred within 3 months | [EC1514, pp. 4–5](lib:beef-production-for-small-farms-osu-ec1514#page=4) |
| Hay, one cow | About **25 lb a day**: 2 tons for a 5-month winter, plus about 1½ tons if summer pasture isn't watered | [UNH, p. 11](lib:4-h-working-steer#page=11) *(arithmetic; season lengths rule of thumb)* |
| Hay, a team | 900–1,300-lb oxen eat **22–25 lb each** a day: about 4 tons for the pair over a 6-month winter | [UNH, p. 11](lib:4-h-working-steer#page=11) *(arithmetic)* |
| Land | 2 acres farmed hard is the minimum for one cow; 3–5 acres of unwatered grass plus hay | [*Keeping One Cow*, p. 15](lib:keeping-one-cow#page=15); *rule of thumb* |
| Water | **4–20 gallons** each a day, more in heat: a cow, a calf and a team need 60–80 gallons on an August day | [EC1514, p. 9](lib:beef-production-for-small-farms-osu-ec1514#page=9) *(rule of thumb)* |
| Salt | About 1 oz a day for a milking cow: some **25 lb a year** | [FB 1470, p. 27](lib:care-and-management-of-dairy-cows#page=27) *(arithmetic)* |
| Bull | One bull for about 25 cows: share one among neighbors | [EC1514, p. 4](lib:beef-production-for-small-farms-osu-ec1514#page=4) |

## 🧯 If this goes wrong

| Problem | Likely cause and fix |
|---|---|
| Cow aborts in winter | Ponderosa pine needles; or brucellosis, so gloves, and burn or bury the calf ([AIB 415, p. 84](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=84); [FB 1470, p. 31](lib:care-and-management-of-dairy-cows#page=31)) |
| Down and cold a day after calving | Milk fever: calcium ([*No Animal Doctor*, p. 289](lib:where-there-is-no-animal-doctor-cvm-2024#page=289)) |
| Left side blown up after new pasture | Bloat: tube, oil; puncture only if she's going down ([p. 205](lib:where-there-is-no-animal-doctor-cvm-2024#page=205)) |
| Calf weak and stiff at a few weeks | Selenium shortage, white muscle disease ([EC1514, p. 11](lib:beef-production-for-small-farms-osu-ec1514#page=11)) |
| Milk drops, clots in the strip cup | Mastitis: strip every 2–3 hours ([*Raising Healthy Cattle*, p. 87](lib:raising-healthy-cattle-cvm#page=87)) |
| Cows keep coming back into heat | Vibriosis from the bull, or a bull that isn't working ([p. 118](lib:raising-healthy-cattle-cvm#page=118)) |
| Oxen toss heads, pull away, balk | A bad yoke fit, or sore necks from working wet ([UNH, p. 39](lib:4-h-working-steer#page=39); [*Animal Management*, p. 312](lib:animal-management-british-war-office-1908#page=312)) |
| Hay barn smells hot or sour | Wet hay heating: pull it apart before it catches fire ([EC1514, p. 7](lib:beef-production-for-small-farms-osu-ec1514#page=7)) |
| Corned-beef brine thick and ropy | Too warm: wash the meat, fresh brine, a cooler place ([FB 2209, p. 32](lib:beef-slaughtering#page=32)) |

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Pull a retained afterbirth by hand after 2 days and flush the womb daily — [FB 1470, p. 32](lib:care-and-management-of-dairy-cows#page=32); by hand within 24 hours, arms in "carbolized lard" — [*Diseases of Cattle*, p. 254](lib:usda-special-report-on-diseases-of-cattle-1923#page=254) | Let it drop, even 10 days ([*Raising Healthy Cattle*, p. 62](lib:raising-healthy-cattle-cvm#page=62)); pulling it lowers fertility ([Nebraska, p. 5](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=5)) and "should never" be done ([Mississippi, p. 3](lib:calving-management-mississippi-p2675#page=3)) |
| Cresol or "other coal-tar preparation" on the navel; cresol drench for bloat; carbolic acid on foot rot; coal-tar creosote dips for lice; formalin in sweetened milk as fly bait — [FB 1470, pp. 32–37](lib:care-and-management-of-dairy-cows#page=32) | Leave them out. Navel: 7% iodine ([*Raising Healthy Cattle*, p. 67](lib:raising-healthy-cattle-cvm#page=67)); bloat: tube and oil ([*No Animal Doctor*, pp. 206–207](lib:where-there-is-no-animal-doctor-cvm-2024#page=206)); foot rot: dry pen and a pine-tar pad; flies: clean up manure and wet straw ([FB 1470, p. 37](lib:care-and-management-of-dairy-cows#page=37)) |
| A 4% formaldehyde foot bath — [*Raising Healthy Cattle*, p. 115](lib:raising-healthy-cattle-cvm#page=115) | Formaldehyde "should not be used" ([*Raising Healthy Sheep*, pp. 116–117](lib:raising-healthy-sheep-cvm#page=116)); dry ground and foot care |
| Hold a newborn calf up by its hind legs to drain fluid — [*Raising Healthy Cattle*, p. 67](lib:raising-healthy-cattle-cvm#page=67) | Clear nose and mouth by hand, rub hard, straw in a nostril ([Nebraska, p. 4](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=4); [Mississippi, p. 7](lib:calving-management-mississippi-p2675#page=7)) *(no book on the drive says outright not to hang it)* |
| Caustic soda or potash on horn buttons — [FB 1470, p. 39](lib:care-and-management-of-dairy-cows#page=39) | It runs into eyes in rain ([*Raising Healthy Cattle*, p. 76](lib:raising-healthy-cattle-cvm#page=76)); hot iron before 4 months |
| Bore the horns and pour in turpentine for "hollow horn" | The 1923 book itself calls it "useless and cruel" ([*Diseases of Cattle*, p. 33](lib:usda-special-report-on-diseases-of-cattle-1923#page=33)) |
| Plenty of calcium-rich legume hay for the dry cow right up to calving — [FB 1470, p. 6](lib:care-and-management-of-dairy-cows#page=6) | No high-calcium alfalfa late in pregnancy, against milk fever ([*No Animal Doctor*, p. 290](lib:where-there-is-no-animal-doctor-cvm-2024#page=290); [*Raising Healthy Cattle*, p. 65](lib:raising-healthy-cattle-cvm#page=65)) |
| "Breeds of dairy cattle should never be crossed" — [FB 1470, p. 4](lib:care-and-management-of-dairy-cows#page=4) | Written for pedigree dairies; crossbreds have extra vigor ([EC1514, p. 3](lib:beef-production-for-small-farms-osu-ec1514#page=3)) |
| Spray insecticide over the slaughter area first — [FB 2209, p. 4](lib:beef-slaughtering#page=4) | Skip it: butcher in cold weather, when flies are gone |

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings and photos in the books on this drive; the other links open the offline Wikipedia.

- Breeds for oxen; parts of a steer; fences, halters, holds and casting ropes; a one-cow stable — [🖼️ UNH, pp. 5–6](lib:4-h-working-steer#page=5); [🖼️ p. 46](lib:4-h-working-steer#page=46); [🖼️ *Raising Healthy Cattle*, pp. 17–25](lib:raising-healthy-cattle-cvm#page=17); [🖼️ *Keeping One Cow*, p. 14](lib:keeping-one-cow#page=14); [Jersey cattle](wiki:Jersey_cattle); [Dexter cattle](wiki:Dexter_cattle); [Milking Shorthorn](wiki:Milking_Shorthorn)
- Poisonous plants in color — [🖼️ ponderosa pine, AIB 415, p. 85](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=85); [🖼️ bracken, p. 23](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=23); [🖼️ tansy ragwort, p. 105](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=105); [🖼️ water hemlock, p. 108](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=108); [🖼️ lupine, p. 65](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=65)
- Calf in the womb, normal and wrong; prolapse; calf hutch — [🖼️ *Diseases of Cattle*, pp. 236–238](lib:usda-special-report-on-diseases-of-cattle-1923#page=236); [🖼️ *Raising Healthy Cattle*, pp. 54–63](lib:raising-healthy-cattle-cvm#page=54); [🖼️ pp. 69–70](lib:raising-healthy-cattle-cvm#page=69); [🖼️ Mississippi, pp. 3–5](lib:calving-management-mississippi-p2675#page=4); [🖼️ chains, p. 7](lib:calving-management-mississippi-p2675#page=7); [🖼️ Nebraska, pp. 2–4](lib:calving-difficulty-and-assistance-nebraska-ec1907#page=2)
- Castration, burdizzo, dehorning, age by the teeth; bloat trocar; drenching and injections — [🖼️ *Raising Healthy Cattle*, pp. 73–79](lib:raising-healthy-cattle-cvm#page=73); [🖼️ pp. 94–95, 170](lib:raising-healthy-cattle-cvm#page=94); [🖼️ *No Animal Doctor*, pp. 187–189](lib:where-there-is-no-animal-doctor-cvm-2024#page=187); [🖼️ p. 206](lib:where-there-is-no-animal-doctor-cvm-2024#page=206)
- Hooves, turning a team, cart, drag and chain length; yokes — [🖼️ UNH, p. 21](lib:4-h-working-steer#page=21); [🖼️ pp. 24–31](lib:4-h-working-steer#page=24); [🖼️ pp. 43, 45](lib:4-h-working-steer#page=43); [🖼️ Peace Corps, pp. 84–85](lib:animal-traction-peace-corps#page=84); [🖼️ Starkey, pp. 23–28](lib:harnessing-and-implements#page=23); [Yoke](wiki:Yoke); [Ox](wiki:Ox)
- Aim, bleeding, skinning, cutting beef; salting meat; tanning tools — [🖼️ UF VM114, p. 7](lib:humane-euthanasia-of-sick-and-injured-livestock-uf-vm114#page=7); [🖼️ FB 2209, pp. 6–30](lib:beef-slaughtering#page=7); [🖼️ *Slaughter and Preservation of Meat*, pp. 51–59](lib:slaughter-and-preservation-of-meat-cvm#page=52); [🖼️ pp. 90–92](lib:slaughter-and-preservation-of-meat-cvm#page=90); [🖼️ FB 1334, p. 7](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=7)

## 🔗 Related guides

- [Milk, Butter & Cheese](guide:DAIRY-GUIDE) — clean milking, raw milk dangers, pasteurizing, butter and cheese
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — harness, hitching, carts, hauling and pulling power
- [Preserving Food](guide:PRESERVING-FOOD-GUIDE) — pressure canning beef, jerky, curing and smoking
- [Goats](guide:GOATS-GUIDE) — milk and brush for smaller or rougher ground; garden poisons
- [Clothing, Leather & Shoes](guide:CLOTHING-LEATHER-GUIDE) — bark tanning, rawhide, boots
- [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE), [Light Without the Grid](guide:LIGHTING-GUIDE), [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — rendering tallow, candles, soap
- [Wildfire](guide:WILDFIRE-GUIDE) — fire plans, animals and livestock, burning seasons
- [Sanitation](guide:SANITATION-GUIDE) — manure compost; dead animals and gut piles
- [Home Defense](guide:HOME-DEFENSE-GUIDE) — protecting livestock from theft; [Bicycles, Carts & Hauling](guide:BICYCLES-CARTS-GUIDE) — carts and sledges
- [Food Security](guide:FOOD-SECURITY-GUIDE) — a family's food for a year; [Chickens](guide:CHICKENS-GUIDE) — skim milk and whey for hens
- The [Sheep](guide:SHEEP-GUIDE), [Pigs](guide:PIGS-GUIDE) and [Dogs](guide:DOGS-GUIDE) guides — grazing with sheep, skim milk for pigs, guardian dogs
- [Medical — Read Me First](guide:Medical-READ-ME-FIRST) — medicines and doses in general
