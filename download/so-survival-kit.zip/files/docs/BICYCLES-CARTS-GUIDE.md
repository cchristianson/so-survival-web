# 🚲 Bicycles, Carts & Hauling Without Fuel

When the gas runs out, everything you move goes on your back, on wheels you push, or on a bicycle.
This guide covers how much one person can move and how fast, travel times from Cave Junction, loading
a bike, building a trailer (welded steel or no-weld pallets), hitches and trailer brakes, wheelbarrows
and handcarts, hills, keeping a bike running with few tools, spares to stock, and local hazards. The
books are in `Bicycles-Carts\` (`Bicycle-Repair` and `Trailers-Carts`). Pack animals, wagons and
harness are in `Horses-Draft-Animals\` and the [Horse guide](guide:HORSE-GUIDE); brazing and forge
work are in `Blacksmithing-Tools\` and the [Blacksmithing guide](guide:BLACKSMITHING-GUIDE).

**Know the limits of the books.** The repair manuals date from 1896 to 1978. Their methods for tubes,
tyres, spokes, cup-and-cone hubs, chains and steel frames still work. But **the library has little on
modern parts**: hydraulic disc brakes, tubeless tyres, indexed ("click") shifting, suspension and
e-bikes. Stock their spares (pads, bleed kit and fluid, sealant, cables) now. A plain steel bike with
rim brakes is the easiest to keep running *(rule of thumb)*.

> ### ⚠️ Rules that prevent the worst outcomes
> - **A loaded bike takes longer to stop** ([Adult Cycling Manual, p. 97](lib:adult-cycling-instructors-manual#page=97)),
>   **and wet rim brakes stop much worse.** Start every descent slowly, test the brakes at the top, and
>   remember that a trailer with no brake **shoves the bike** downhill *(rule of thumb)*.
> - **Don't wreck your body.** A normal day load on your back is 10–20 kg (22–44 lb); 50 kg (110 lb)
>   only for short distances ([World Bank, p. 65](lib:improving-rural-mobility#page=65)). Put heavy
>   loads on wheels.
> - **Never ride a kinked frame tube or fork.** A buckled tube is weakened and must be replaced
>   ([Burr, p. 73](lib:burr-bicycle-repairing#page=73)). Keep at least 2 in of seat post inside the
>   frame ([Henry, p. 54](lib:henry-cycle-building#page=54)).
> - **Never clean parts in gasoline.** Use kerosene, diesel or degreaser, outdoors, away from flames.
> - **Fire season (June–October): don't drag metal.** A chain or trailer part scraping on rock can start
>   a wildfire. Haul in the cool early morning and carry water *(rule of thumb)*.
> - **Braze outdoors, and only steel frames.** Brass gives off zinc fumes. Aluminium and carbon frames
>   cannot be brazed.

---

## 🏋️ How much one person can move

The biggest lesson in these books: **get the load off your back and onto wheels.** The World Bank's
planning table — rough, order-of-magnitude numbers only ([World Bank, p. 66](lib:improving-rural-mobility#page=66)):

| How you move it | Load | Speed | Typical trip |
|---|---|---|---|
| Carried (back or head) | 20 kg (44 lb) | 5 km/h (3 mph) | up to 10 km (6 mi) |
| Sledge (dragged) ([Sled](wiki:Sled)) | 100 kg (220 lb) | 4 km/h (2.5 mph) | short |
| Wheelbarrow | 100 kg (220 lb) | 4 km/h (2.5 mph) | about 1 km |
| [Handcart](wiki:Cart) | 150 kg (330 lb) | 4 km/h (2.5 mph) | about 5 km (3 mi) |
| Bicycle | 60 kg (130 lb) | 10 km/h (6 mph) | about 20 km (12 mi) |
| [Cycle rickshaw](wiki:Cycle_rickshaw) or [tricycle](wiki:Tricycle) | 150 kg (330 lb) | 8 km/h (5 mph) | — |

**On your back:**
- A wheelbarrow or handcart lets the same person move 50–100 kg (110–220 lb) comfortably, against a
  normal 10–20 kg carried ([World Bank, p. 65](lib:improving-rural-mobility#page=65)).
- **Weight costs distance.** In a 6-hour march you cover about 2 km less for every 10 lb carried over
  40 lb ([FM 21-18, p. 65](lib:fm-21-18-foot-marches#page=65)). Porters can carry 120 lb for several
  days at 12 mi a day; 150 lb brings exhaustion and injury ([p. 71](lib:fm-21-18-foot-marches#page=71)).
- **A packboard (pack frame)** makes 50 lb an easy load; most people can manage 100 lb. Pack it compact
  and high, **heaviest items on the upper half**, lashed tight. To lift it, sit against the upright
  board, put on the straps, roll onto hands and knees and stand. Rest it on a stump — never drop it
  ([*Use of the Packboard*, pp. 1–2](lib:use-of-the-packboard#page=1);
  [🖼️ lifting and resting it, drawn](lib:use-of-the-packboard#page=1);
  [🖼️ lashing a load](lib:use-of-the-packboard#page=2);
  [🖼️ why a high load costs less energy](lib:load-carriage-in-military-operations#page=33)).

**On wheels:**
- In a US Army test, pushing 50 kg (110 lb) in a cart on a smooth surface took **88% less energy**
  than carrying it ([Knapik, p. 37](lib:load-carriage-in-military-operations#page=37);
  [🖼️ ways of carrying loads that were tested](lib:load-carriage-in-military-operations#page=26)).
- Ordinary bicycles carry up to about 100 kg (220 lb). For very big loads the bike is pushed, not
  ridden. Bikes work best on flat, hard surfaces ([World Bank, p. 65](lib:improving-rural-mobility#page=65)).

**Ground matters** — effort of walking with a load ([Knapik, p. 42](lib:load-carriage-in-military-operations#page=42)):

| Paved road | Dirt road | Light brush | Heavy brush | Swampy bog | Loose sand |
|---|---|---|---|---|---|
| 1.0× | 1.1× | 1.2× | 1.5× | 1.8× | 2.1× |

📚 **Go deeper:** [World Bank *Improving Rural Mobility*](lib:improving-rural-mobility#page=65) — loads, speeds and costs for every kind of human and animal transport; [Knapik *Load Carriage*](lib:load-carriage-in-military-operations#page=37) — carts, terrain and injuries; [*Use of the Packboard*](lib:use-of-the-packboard#page=1) — illustrated loading and lashing.

## 🗺️ Travel times from Cave Junction

**Walking pace with a load** ([FM 21-18, p. 89](lib:fm-21-18-foot-marches#page=89)): on roads
4.0 km/h (2.5 mph) by day, 3.2 km/h at night; cross-country 2.4 km/h by day, 1.6 km/h at night. A
normal day is 20–32 km (12–20 mi), or 5–8 hours on the move.
- **Rest 15 minutes after the first 45 minutes**, then 10 minutes in every hour
  ([FM 21-18, p. 48](lib:fm-21-18-foot-marches#page=48)).
- At halts, lie down with your feet up. Carry spare socks; tape known hot spots before they blister
  ([FM 21-18, p. 101](lib:fm-21-18-foot-marches#page=101);
  [🖼️ photo of friction blisters](lib:load-carriage-in-military-operations#page=48);
  [Blister](wiki:Blister)).

**In hills, plan by time, not miles.** Add one-third to the map distance, then **1 hour for every
1,000 ft (300 m) of climb**, or every 2,000 ft (600 m) of descent
([FM 3-97.6, p. 72](lib:fm-3-97-6-mountain-operations#page=72)).

**From Cave Junction** (library walking routes: highway miles, back roads in brackets):

| To | Miles | On foot (15 mi a day) | Loaded bike at about 6 mph | By car, normal times |
|---|---|---|---|---|
| Grants Pass | 29 (40) | 2 days (3) | about 5 hours (7) — one day | 44 min |
| Crescent City | 53 (64) | 4 days (4) | about 9 hours (11) — a long day or two | 1 h 15 min |
| Medford | 59 (62) | 4 days (4) | about 10 hours (10–11) — a long day or two | 1 h 23 min |
| Roseburg | 101 (122) | 7 days (8) | about 17 hours (20) — 2–3 days | 2 h 11 min |

Car times are normal driving times with roads open, from the route pages. Bike times use the World Bank's loaded-bicycle speed of 10 km/h
([p. 66](lib:improving-rural-mobility#page=66)) and are **moving time only**. Add the climbing allowance,
rests, flats and pushing up steep grades *(rule of thumb)*. A handcart moves at walking pace but carries
several times as much.

**Local notes** ([Start Here guide](guide:ILLINOIS-VALLEY-START-HERE)): back roads are longer, steeper
and remote, and **high passes can get snow**. After a Cascadia quake, expect landslides and broken
bridges on routes like US-199. Walking, bicycle and driving routes with GPX tracks for 359 towns are in `Walking-Routes\WALKING-ROUTES.html`.

📚 **Go deeper:** [FM 21-18 *Foot Marches*](lib:fm-21-18-foot-marches#page=89) — march rates, halts, loads and foot care; [FM 3-97.6 *Mountain Operations*](lib:fm-3-97-6-mountain-operations#page=72) — time rules for steep country.

🎒 **Walking instead?** Loads, packs, feet, water, camps, river crossings and safety on the road are in [On Foot](guide:ON-FOOT-GUIDE).

## 🎒 Loading a bicycle

**How to load it** ([Adult Cycling Manual, p. 97](lib:adult-cycling-instructors-manual#page=97)):
- Touring cyclists usually carry **30–50 lb**, on the bike — a backpack makes balance harder.
  ([Bicycle touring](wiki:Bicycle_touring))
- Put **heavy items low** in the panniers and split the load front and rear. Too much weight in front
  spoils the steering.
- A loaded bike needs lower gears, sways more and **takes longer to stop**. Practise with the load before
  a real trip.

**Making a bike carry more** ([Practical Action, *Bicycles*](lib:practical-action-bicycles-technical-brief#page=2)):
- Panniers can be sacks or baskets hung from wood across the carrier, or a light steel frame. Keep the
  sides balanced, and **strengthen the carrier** (p. 2; [🖼️ pannier frame drawing](lib:practical-action-bicycles-technical-brief#page=2);
  [Pannier](wiki:Pannier)).
- The load is **limited by the rear wheel and tyre**; a stronger rear wheel helps (p. 3).
- **Longer carrier without cutting the frame:** bolt on extra stays and move the rear wheel back about
  250 mm (10 in). The chain and brake rods must be lengthened (p. 3;
  [🖼️ extension drawings](lib:practical-action-bicycles-technical-brief#page=3)).
- **A small 20-inch rear wheel** is stronger, keeps the load low and makes pedalling easier, but handles
  potholes worse (p. 4; [🖼️ drawing](lib:practical-action-bicycles-technical-brief#page=4)).

**Pushing big loads:** in Zambia, people pushed **two 50 kg sacks of maize** on one bicycle up to
30 km (19 mi) to town ([Bicycle Trailers in Zambia, p. 1](lib:bicycle-trailers-in-zambia#page=1)).

**Before a loaded trip** *(rule of thumb)*: tyres firm, brakes grabbing hard, carrier bolts tight,
nothing able to swing into the spokes, and patch kit, pump and water aboard. Learn the names of the
parts from a [🖼️ labeled bicycle drawing](lib:adult-cycling-instructors-manual#page=30) (the key is on
[p. 31](lib:adult-cycling-instructors-manual#page=31)).

📚 **Go deeper:** [Adult Cycling Manual](lib:adult-cycling-instructors-manual#page=97) — loaded touring and riding skills; [Practical Action *Bicycles*](lib:practical-action-bicycles-technical-brief#page=2) — dimensioned pannier frames and carrier extensions. Pictures: [Cargo bike](wiki:Cargo_bike).

## 🛒 Bicycle trailers: welded steel or no-weld pallets

A trailer lets a rider move about **three times** the bike's own load, roughly 200 kg (450 lb)
([Practical Action, *Bicycle Trailers*, p. 1](lib:bicycle-trailers-technical-brief#page=1)).

**But not always.** In northern Ghana, trailers promoted in the 1990s failed: heavy to pull loaded, poor
on footpaths, and twice the cost of a bicycle. A plain bike with a strong carrier was more flexible
([World Bank, p. 39](lib:improving-rural-mobility#page=39)).

**Welded steel trailer** ([*Bicycle Trailers*, pp. 3–4](lib:bicycle-trailers-technical-brief#page=3);
frame drawings: [🖼️ p. 2](lib:bicycle-trailers-technical-brief#page=2),
[🖼️ p. 3](lib:bicycle-trailers-technical-brief#page=3)):
- Frame: 19 mm (3/4 in) mild-steel square tube, or round tube at least 22 × 1.5 mm (25 × 1.5 mm is
  better). **Reinforce each joint** with a piece of tube or bar inside it.
- Ordinary bike wheels are fine for light loads on good roads, but **not for heavy loads on rough
  tracks**. Use strengthened wheels (p. 4).
- A local welder in Zambia built these from the drawings for about $100 each
  ([Zambia report, p. 1](lib:bicycle-trailers-in-zambia#page=1)).

**No-weld pallet trailer** — about one day and about 20 euros
([Low-tech Lab](lib:wooden-bicycle-trailer#page=3)). You need 2 pallets, 2 bicycle wheels, wood screws
and 1 old inner tube; a crowbar, hammer, saw and screwdriver.
1. Decide what it must carry. **Keep it no wider than 1 m (39 in)** (p. 3).
2. Take the pallets apart with the crowbar and hammer (p. 3).
3. Build the frame from the centre outward. The side boards must be as thick as the wheel so they frame
   it (p. 4; [🖼️ the numbered boards](lib:wooden-bicycle-trailer#page=4); [Pallet](wiki:Pallet)).
4. Fix the wheels **before** the outer boards go on (p. 5).
5. Hitch it to the bike's rear rack with the inner tube (p. 6).

**Hitches** ([*Bicycle Trailers*, p. 4](lib:bicycle-trailers-technical-brief#page=4);
[🖼️ hitch design](lib:bicycle-trailers-technical-brief#page=4);
[🖼️ Poston's scrap-steel hitch](lib:bicycle-trailer-hitch#page=2)):
- Hitch **above the rear wheel**, to the carrier or the frame under the seat. It is simpler than an
  axle-level hitch, works on earth roads, and lets the trailer double as a handcart.
- The recommended joint is a **rubber ball in a steel socket**.
- Any hitch must hold the load, **let the bike lean**, come off easily, and take braking and pulling
  forces from every direction ([Low-tech Lab, p. 6](lib:wooden-bicycle-trailer#page=6)).

**Trailer brakes and carrying the injured** ([*Bicycle Ambulance*, pp. 2–3](lib:bicycle-ambulance#page=2);
[🖼️ frame diagram](lib:bicycle-ambulance#page=5)):
a stretcher trailer carries **two people**, with a shock absorber and a ball-joint hitch so the bike can
turn. Its **overrun brake** works by itself: when the bike slows, the trailer pushes a rod into a sprung
tube, which pulls a brake cable on the trailer wheel. No trailer brake? Slow down early, drag a foot, or
walk it down steep hills *(rule of thumb)*.

📚 **Go deeper:** [Practical Action *Bicycle Trailers*](lib:bicycle-trailers-technical-brief#page=3) — parts list with tube sizes and frame drawings; [Low-tech Lab pallet trailer](lib:wooden-bicycle-trailer#page=3) — the no-weld build; [*Bicycle Ambulance*](lib:bicycle-ambulance#page=3) — hitch and overrun-brake part sizes; [*Trailer Hitch* (Poston)](lib:bicycle-trailer-hitch) — a lathe-free hitch from scrap steel and rubber. Pictures: [Bicycle trailer](wiki:Bicycle_trailer).

## 🛞 Wheelbarrows, handcarts, sledges and travois

**A better wheelbarrow** ([Wilson, *The Wheelbarrow*](lib:the-wheelbarrow-wilson#page=1)):
- Use **one large wheel** with most of the load **directly over it**. Leave little weight on the handles,
  and take that with a **shoulder strap**. The traditional Chinese barrow built this way carried up to
  six people (p. 1).
- A homemade barrow wheel can run on a **standard bicycle axle and cone bearings**, with a solid tyre of
  strips cut from old car tyres (p. 2; [🖼️ wheel drawing](lib:the-wheelbarrow-wilson#page=2)).
- Choose **air-filled tyres** (adjust pressure for rough ground), keep the load low, and make several
  light trips rather than one heavy one
  ([USFS *Handtools for Trail Work*, p. 42](lib:usfs-mtdc-handtools-for-trail-work-2005#page=42), with
  [🖼️ wheelbarrow drawings](lib:usfs-mtdc-handtools-for-trail-work-2005#page=42)).

**Handcarts:**
- A **balanced handcart**, with most of the weight on the wheels, is easier than a one-wheel barrow
  ([World Bank, p. 65](lib:improving-rural-mobility#page=65)).
- A good load cart has a **low centre of gravity, a wide wheelbase and big wheels**. Pulled carts are
  easier to control on rough ground. A cart pulled from a **hip belt** finished a 3.2 km mixed course
  54% faster than people carrying rucksacks. The carts were noisy in brush and rock, and gear caught in
  the wheels — so guard the wheels ([Knapik, p. 37](lib:load-carriage-in-military-operations#page=37)).
- Cart bodies are often built on **scrap car or pickup axles**. Large wheels roll through ruts and holes
  better than small ones ([Starkey, p. 85](lib:harnessing-and-implements-for-animal-traction-starkey-gate-1989#page=85);
  [🖼️ big wheel vs small wheel in a rut](lib:harnessing-and-implements-for-animal-traction-starkey-gate-1989#page=85);
  [🖼️ cart wheel, hub and bearing, labeled](lib:harnessing-and-implements-for-animal-traction-starkey-gate-1989#page=87);
  [Handcart](wiki:Cart)).

**Sledges** are cheap and narrow, and go where carts can't — too steep, muddy or narrow. But they pull
harder, snag on stumps, and their ruts turn into gullies
([Starkey, p. 83](lib:harnessing-and-implements-for-animal-traction-starkey-gate-1989#page=83);
[🖼️ simple wooden sledge](lib:harnessing-and-implements-for-animal-traction-starkey-gate-1989#page=83);
[Sled](wiki:Sled)).

**Travois** (behind a horse or mule): two straight poles 14–20 ft long with a platform 2–3 ft wide
behind the animal, and three people to handle it at ditches and streams
([FM 25-7, p. 166](lib:pack-transportation-war-dept-fm-25-7-1944#page=166);
[🖼️ travois drawing](lib:pack-transportation-war-dept-fm-25-7-1944#page=165)).

📚 **Go deeper:** [Wilson *The Wheelbarrow*](lib:the-wheelbarrow-wilson#page=1) — the big-wheel barrow and a homemade wheel; [Wheelbarrow construction drawings](lib:wheelbarrow-construction-drawings) — six dimensioned sheets for a steel barrow; [Selvidge, p. 104](lib:selvidge-and-allton-blacksmithing-shop-manual-1925#page=104) — replacing a wagon spoke, and [p. 95](lib:selvidge-and-allton-blacksmithing-shop-manual-1925#page=95) — shrinking on an iron tyre. Pictures: [Wheelbarrow](wiki:Wheelbarrow), [Travois](wiki:Travois).

## ⛰️ Hills and grades

**The extra push on a slope is roughly the total weight times the grade** *(rule of thumb, simple
physics)*. A 10% grade rises 10 ft for every 100 ft along the road ([Grade](wiki:Grade_(slope))).

| Grade | Extra push for a 220 lb (100 kg) load |
|---|---|
| 5% | about 11 lb |
| 10% | about 22 lb |
| 15% | about 33 lb |

That is **on top of** the push needed on the flat. *(Rules of thumb:)*
- Pushing much over **25–30 lb** for long is very tiring.
- On grades **over about 10%**, use two people (one pulling with a rope or hip belt), or split the load.
- A loaded bike on a steep Forest Service road is often **faster walked and pushed** than ridden.
- **Going down:** a trailer with no brake shoves the bike. Slow down at the top, not halfway. Drag a foot
  or add a brake. On a handcart, put someone behind holding back on a rope.

📚 **Go deeper:** [Knapik *Load Carriage*](lib:load-carriage-in-military-operations#page=42) — terrain factors and energy cost; [FM 3-97.6](lib:fm-3-97-6-mountain-operations#page=72) — moving in steep country.

## 🩹 Flat tyres: patching tubes and booting tyres

**Patching a tube** ([Henry, pp. 61–65](lib:henry-cycle-building#page=63)):
1. **Before you take the tyre off,** mark where it sits against the valve, or count spokes from the
   valve, so you can find the thorn later (p. 63).
2. Lever one side of the tyre off and pull the tube out. Careless levering tears the tube (p. 64;
   [Tire lever](wiki:Tire_iron), [Inner tube](wiki:Inner_tube)).
3. **Find the leak:** pump the tube up a little and listen or feel near your face, or dunk it in water
   and watch for bubbles (p. 64).
4. **Find the cause:** feel inside the tyre at the matching spot for the thorn (p. 64).
5. Roughen around the hole with sandpaper (p. 65).
6. Coat tube and patch with rubber cement. **Wait about 10 minutes** until it is tacky (p. 65).
7. Press the patch on hard, dust with talc ("French chalk") and refit the tube dry (p. 65).

**Tips:** **old inner tubes make good patch rubber** (p. 61). A patch kit **more than a year old** may
have gone bad (p. 62). If a tyre goes soft with no hole, check the valve first (p. 62). Tyres lose
10–20 psi within a week anyway, so **check pressure often**
([Adult Cycling Manual, p. 72](lib:adult-cycling-instructors-manual#page=72)).

**Booting a cut or burst tyre:**
- Glue canvas inside the tyre over the damage, or a patch cut from an old tyre
  ([Henry, p. 70](lib:henry-cycle-building#page=70)).
- Fill small tread cuts with **leather dust** (rasped from scrap leather) mixed into rubber cement
  ([Henry, p. 69](lib:henry-cycle-building#page=69)).
- A modern road kit: **two denim boots about 1 × 2 in**, 6 patches, 2 tyre levers, a spare tube, talc
  and a pressure gauge ([Adult Cycling Manual, p. 34](lib:adult-cycling-instructors-manual#page=34)).

📚 **Go deeper:** [Henry *Cycle Building and Repairing*](lib:henry-cycle-building#page=61) — tyres, tubes, valves and repairs; [Adult Cycling Manual](lib:adult-cycling-instructors-manual#page=34) — the tool and tyre kit. Pictures: [Bicycle tire](wiki:Bicycle_tire).

## 🔩 Wheels, hub bearings and chains

**Truing a wobbly wheel** ([Henry, pp. 44–46](lib:henry-cycle-building#page=44);
[🖼️ truing a wheel in its own fork with chalk](lib:burr-bicycle-repairing#page=97);
[Wheelbuilding](wiki:Wheelbuilding)):
1. Spin the wheel in the frame and hold **chalk** beside the rim so it marks the spots that stick out.
2. **A spoke pulls the rim toward its own side of the hub.** At each chalk mark, tighten the spokes that
   run to the **other** side of the hub, a little at a time, with a spoke (nipple) key.
3. Fix out-of-round the same way: tighten spokes at the high spots, loosen them at the low spots.
4. File off spoke ends that poke through the nipples, or they will puncture the tube.
5. Replace broken spokes **one at a time**, so you keep the lacing pattern
   ([🖼️ lacing drawing](lib:henry-cycle-building#page=38); [Spoke](wiki:Spoke)).

**Hub bearings** ([Henry, pp. 46–47](lib:henry-cycle-building#page=46);
[🖼️ hub parts named](lib:henry-cycle-building#page=42);
[🖼️ cup, cone, balls and locknut, with how to hold the spanners](lib:adult-cycling-instructors-manual#page=58)):
- A **clicking** wheel usually has a broken ball or worn cones. Open the hub; clean cups, cones and axle
  in kerosene.
- Throw away chipped balls. **Take a sample ball** when you look for new ones.
- Grease the cups, put the balls back, screw the cone up tight, then **back it off about half a turn**.
  Twisted by its spokes, the wheel should spin freely with almost no side play.

**Chains:**
- Soak a filthy chain in kerosene for 2–3 days, hang it to drip, wipe it, then oil it
  ([Henry, p. 52](lib:henry-cycle-building#page=52)).
- To shorten an old **riveted** chain, file off the burred pin heads and punch the pins out
  ([Henry, p. 53](lib:henry-cycle-building#page=53); [🖼️ chain links drawn](lib:henry-cycle-building#page=53);
  [🖼️ putting a chain on](lib:burr-bicycle-repairing#page=139)).
- Modern chains need a **chain tool**: push the pin almost out, leaving about 1/32 in in the side plate
  so it can go back in. **A chain wears out in 1–2 years of average use**, and a new chain may skip on a
  worn freewheel, so the two often need replacing together
  ([Adult Cycling Manual, p. 104](lib:adult-cycling-instructors-manual#page=104);
  [Freewheel](wiki:Freewheel)).

📚 **Go deeper:** [Henry](lib:henry-cycle-building#page=44) — lacing and truing wheels, hubs and chains; [Adult Cycling Manual, p. 103](lib:adult-cycling-instructors-manual#page=103) — chain cleaning, oiling and stiff links; [Burr *Bicycle Repairing*](lib:burr-bicycle-repairing) — bearings, forks and shop-made tools. Pictures: [Bicycle wheel](wiki:Bicycle_wheel), [Bicycle chain](wiki:Bicycle_chain).

## 🛑 Brakes, gears and field fixes

**Rim brakes** ([Adult Cycling Manual, p. 48](lib:adult-cycling-instructors-manual#page=48);
[🖼️ center-pull and side-pull brakes](lib:adult-cycling-instructors-manual#page=47)): released,
the pads should sit about **1/16 in from the rim**, and they should hit the rim before the lever reaches
the handlebar. **New cables stretch** — tighten them again after about a week.

**Derailleur gears** ([p. 81](lib:adult-cycling-instructors-manual#page=81);
[🖼️ rear derailleur with its screws lettered](lib:adult-cycling-instructors-manual#page=80)): won't shift onto the largest
cog? Back out its **limit (stop) screw**. Still short? Take up cable slack with the **barrel adjuster**.
Shifts by itself? Tighten the **thumbscrew** holding the shift lever.

**Field fixes:**
- **Bent crank:** hold the bike steady and push the crank back with your foot — usually straight enough
  to finish the trip ([Henry, p. 47](lib:henry-cycle-building#page=47)).
- **Bent frame tube:** a slight bend can be straightened, but a **buckled (kinked)** tube cannot. Replace
  it ([Burr, p. 73](lib:burr-bicycle-repairing#page=73); [🖼️ truing a frame](lib:burr-bicycle-repairing#page=77);
  [Bicycle frame](wiki:Bicycle_frame)).
- **Broken steel frame tube — braze it over a sleeve** ([Rowe, pp. 60–61](lib:rowe-hard-soldering#page=60);
  [🖼️ Burr's drawings of a tube mended over an inner sleeve](lib:burr-bicycle-repairing#page=72);
  [Lugged steel frame](wiki:Lugged_steel_frame_construction)):
  1. File the broken ends smooth and clean them bright, inside and out.
  2. Fit a sleeve of light steel tube **inside** both ends; pin it if needed to hold the frame in line.
  3. Coat the joint with borax mixed with water to a paste (the flux) ([Borax](wiki:Borax)).
  4. Heat it in a charcoal fire or a blacksmith's forge. At a **low red heat**, lay on brass spelter and
     let it flow into the joint. Don't overheat.
  5. Work **outdoors** (zinc fumes). **Steel only** — aluminium frames (smooth welds, no lugs, often
     marked 6061 or 7005) and carbon frames cannot be brazed.

**Old words in the old books:** paraffin = kerosene; French chalk = talc; spanner = wrench;
cover = tyre; solution = rubber cement.

📚 **Go deeper:** [Adult Cycling Manual](lib:adult-cycling-instructors-manual#page=48) — brake, derailleur, headset and bottom-bracket adjustment; [Rowe *Hard Soldering*](lib:rowe-hard-soldering#page=60) — brazing with blowpipe, charcoal or forge; [Burr](lib:burr-bicycle-repairing#page=73) — frame tubes, lugs and forks. Pictures: [Bicycle brake](wiki:Bicycle_brake), [Derailleur](wiki:Derailleur), [Brazing](wiki:Brazing).

## 📦 Spares to stockpile

*(Rule of thumb, building on the kit list in the [Adult Cycling Manual, p. 34](lib:adult-cycling-instructors-manual#page=34).)*

- **A good floor pump** — above all ([Bicycle pump](wiki:Bicycle_pump))
- Tubes and patch kits for **every tyre size you own**; spare tyres
- Chains with spare links; brake pads; inner cables and housing
- Spokes in the right lengths for each wheel
- Loose bearing balls (3/16 in and 1/4 in are common), grease, chain oil, rim tape, valve cores
- Tools: tyre levers, chain tool, spoke key, pressure gauge ([Bicycle tools](wiki:Bicycle_tools))

**Match tyres by the ISO number on the sidewall, not by "26 inch."** A size like **37-622** means 37 mm
wide on a 622 rim *(rule of thumb)*. ([ISO 5775 tyre sizes](wiki:ISO_5775))

| ISO rim number | Sold as |
|---|---|
| **559** | 26-inch mountain bike |
| **584** | 650B (also called 27.5) |
| **622** | 700C, or 29er |
| **590** | old "26 × 1 3/8" (3-speeds) — **will not fit a 559 rim** |

**Valves:** Schrader (car-type) valves fill from any car pump; Presta (thin) valves need a matching pump
head or adapter. **Store rubber** cool and dark, away from electric motors, which make ozone that cracks
it *(rule of thumb)*.

📚 **Go deeper:** [Adult Cycling Manual, p. 34](lib:adult-cycling-instructors-manual#page=34) — tool kit and tyre kit lists; [Henry, p. 61](lib:henry-cycle-building#page=61) — patch rubber from old tubes. Pictures: [Presta valve](wiki:Presta_valve), [Schrader valve](wiki:Schrader_valve).

## 🌲 Illinois Valley hazards

*(Rules of thumb for our area.)*
- **Goatheads (puncturevine)** grow in dry, disturbed ground — road edges, driveways, bare lots. Carry
  extra patches or thorn-resistant tubes. Learn the plant and pull it before it seeds
  ([weed photo list, p. 53](lib:wsnwcb-protect-your-horses-and-livestock-from-toxic-plants#page=53);
  [Puncturevine](wiki:Tribulus_terrestris)).
- **Rocky and serpentine Forest Service roads** cause **pinch flats** under load. Run tyres firmer when
  loaded, and walk the worst rock. ([Serpentinite](wiki:Serpentinite))
- **Fire season (June–October):** keep chains and metal parts from dragging and throwing sparks. Haul in
  the early morning with plenty of water.
- **Wet winters** wash the oil off chains and rust them. Wipe and re-oil after every rain ride.
- **Rim brakes stop much worse when wet.** Brake earlier; drag them lightly first to wipe the rims.

📚 **Go deeper:** [Adult Cycling Manual, p. 97](lib:adult-cycling-instructors-manual#page=97) — riding a loaded bike safely; [Knapik, p. 37](lib:load-carriage-in-military-operations#page=37) — carts on rough ground.

## ⚠️ Old advice in the library to ignore

- **Homemade rubber cement from rubber dissolved in "benzine"** (gasoline or naphtha)
  ([Henry, p. 61](lib:henry-cycle-building#page=61)). Very flammable, and benzene fumes are toxic. Use
  bought cement; if you must make it, mix it outdoors, far from any flame.
- **Boiling a chain in mutton tallow** ([Henry, p. 52](lib:henry-cycle-building#page=52)). Hot fat is a
  fire hazard, and tallow holds grit. Soak in kerosene, wipe, and oil lightly.
- **Wrapping joints in asbestos cloth or wicking** while brazing ([Rowe, p. 61](lib:rowe-hard-soldering#page=61);
  [p. 60](lib:rowe-hard-soldering#page=60)). Asbestos causes cancer — use wet rags or a sheet-metal
  shield. Brass spelter gives off zinc fumes that cause "metal fume fever," so braze outdoors.
- **"Cleaning solvent from gasoline station"** in the tool list
  ([Adult Cycling Manual, p. 34](lib:adult-cycling-instructors-manual#page=34)). Never clean parts in
  gasoline. Use kerosene, diesel or degreaser, outdoors.
- **Obsolete parts:** single-tube and beaded-edge tyres, cotter-pin cranks
  ([Henry, p. 47](lib:henry-cycle-building#page=47)) and 1890s frames. Skip those pages; the hub, wheel,
  patching, brazing and truing methods are still good.
- **Military load limits** of 30–45% of body weight ([Knapik, p. 20](lib:load-carriage-in-military-operations#page=20))
  are for fit young soldiers. Plan family loads on 10–20 kg.

📚 **Go deeper:** [Henry, p. 46](lib:henry-cycle-building#page=46) — the sound old method: hubs cleaned in kerosene; [Adult Cycling Manual, p. 103](lib:adult-cycling-instructors-manual#page=103) — kerosene chain cleaning.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Carrying loads**
- Ways of carrying loads, compared — [🖼️ Knapik, p. 26](lib:load-carriage-in-military-operations#page=26)
- Why a high load is easier — [🖼️ Knapik, p. 33](lib:load-carriage-in-military-operations#page=33)
- Packboard: lifting, resting and lashing — [🖼️ *Use of the Packboard*, p. 1](lib:use-of-the-packboard#page=1); [🖼️ p. 2](lib:use-of-the-packboard#page=2)
- Friction blisters (what to prevent) — [🖼️ Knapik, p. 48](lib:load-carriage-in-military-operations#page=48); [Blister](wiki:Blister)
- Cargo bikes, rickshaws and tricycles — [Cargo bike](wiki:Cargo_bike); [Cycle rickshaw](wiki:Cycle_rickshaw); [Tricycle](wiki:Tricycle)

**Loading a bicycle and trailers**
- A bicycle with every part named — [🖼️ Adult Cycling Manual, p. 30](lib:adult-cycling-instructors-manual#page=30)
- Pannier frames — [🖼️ Practical Action *Bicycles*, p. 2](lib:practical-action-bicycles-technical-brief#page=2); [Pannier](wiki:Pannier)
- Lengthened carrier and small-rear-wheel conversion — [🖼️ p. 3](lib:practical-action-bicycles-technical-brief#page=3); [🖼️ p. 4](lib:practical-action-bicycles-technical-brief#page=4)
- Welded steel trailer frames — [🖼️ *Bicycle Trailers*, p. 2](lib:bicycle-trailers-technical-brief#page=2); [🖼️ p. 3](lib:bicycle-trailers-technical-brief#page=3); [Bicycle trailer](wiki:Bicycle_trailer)
- Trailer hitches — [🖼️ *Bicycle Trailers*, p. 4](lib:bicycle-trailers-technical-brief#page=4); [🖼️ Poston hitch, p. 2](lib:bicycle-trailer-hitch#page=2)
- Pallet trailer build — [🖼️ Low-tech Lab, p. 4](lib:wooden-bicycle-trailer#page=4)
- Bicycle ambulance frame — [🖼️ *Bicycle Ambulance*, p. 5](lib:bicycle-ambulance#page=5)

**Wheelbarrows, carts, sledges and travois**
- Big-wheel barrow and homemade wheel — [🖼️ Wilson, p. 2](lib:the-wheelbarrow-wilson#page=2); [Wheelbarrow](wiki:Wheelbarrow)
- Steel wheelbarrow, six dimensioned sheets — [🖼️ construction drawings](lib:wheelbarrow-construction-drawings#page=1)
- Wheelbarrows for trail work — [🖼️ USFS, p. 42](lib:usfs-mtdc-handtools-for-trail-work-2005#page=42)
- Big wheels vs small in ruts; cart hub and bearing — [🖼️ Starkey, p. 85](lib:harnessing-and-implements-for-animal-traction-starkey-gate-1989#page=85); [🖼️ p. 87](lib:harnessing-and-implements-for-animal-traction-starkey-gate-1989#page=87); [Handcart](wiki:Cart)
- Wooden sledge — [🖼️ Starkey, p. 83](lib:harnessing-and-implements-for-animal-traction-starkey-gate-1989#page=83); [Sled](wiki:Sled)
- Travois — [🖼️ FM 25-7, p. 165](lib:pack-transportation-war-dept-fm-25-7-1944#page=165); [Travois](wiki:Travois)

**Wheels, tyres and chains**
- Tyre levers and inner tubes — [Tire lever](wiki:Tire_iron); [Inner tube](wiki:Inner_tube); [Bicycle tire](wiki:Bicycle_tire)
- Truing a wheel in its fork — [🖼️ Burr, p. 97](lib:burr-bicycle-repairing#page=97); [Wheelbuilding](wiki:Wheelbuilding)
- Lacing spokes — [🖼️ Henry, p. 38](lib:henry-cycle-building#page=38); [Spoke](wiki:Spoke)
- Cup-and-cone hub, named parts — [🖼️ Henry, p. 42](lib:henry-cycle-building#page=42); [🖼️ Adult Cycling Manual, p. 58](lib:adult-cycling-instructors-manual#page=58)
- Chain links; putting a chain on — [🖼️ Henry, p. 53](lib:henry-cycle-building#page=53); [🖼️ Burr, p. 139](lib:burr-bicycle-repairing#page=139); [Bicycle chain](wiki:Bicycle_chain)
- Valves — [Presta valve](wiki:Presta_valve); [Schrader valve](wiki:Schrader_valve)

**Brakes, gears and frames**
- Center-pull and side-pull rim brakes — [🖼️ Adult Cycling Manual, p. 47](lib:adult-cycling-instructors-manual#page=47); [Bicycle brake](wiki:Bicycle_brake)
- Rear derailleur adjusting screws — [🖼️ Adult Cycling Manual, p. 80](lib:adult-cycling-instructors-manual#page=80); [Derailleur](wiki:Derailleur)
- Mending a broken tube over an inner sleeve — [🖼️ Burr, p. 72](lib:burr-bicycle-repairing#page=72); [🖼️ p. 73](lib:burr-bicycle-repairing#page=73); [Brazing](wiki:Brazing)
- Truing a frame; straightening a fork — [🖼️ Burr, p. 77](lib:burr-bicycle-repairing#page=77); [🖼️ p. 84](lib:burr-bicycle-repairing#page=84); [Lugged steel frame](wiki:Lugged_steel_frame_construction)

**Local hazards**
- Goatheads (puncturevine) — [Puncturevine](wiki:Tribulus_terrestris)
- Serpentine rock on Forest Service roads — [Serpentinite](wiki:Serpentinite)

---

## 🔗 Related guides

- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — pack animals, carts, harness and travois
- [Blacksmithing and Hand Tools](guide:BLACKSMITHING-GUIDE) — brazing, forge work and wagon tyres
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — walking routes, wildfire and Cascadia
- [Navigation and Weather](guide:NAVIGATION-WEATHER-GUIDE) — finding your way and reading the weather
- [Firewood guide](guide:FIREWOOD-GUIDE) — the heaviest thing most households haul
- [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — repairs and making do without stores
- [Shelter, Building and Repair](guide:SHELTER-BUILDING-GUIDE) — hauling lumber and building with what you have
- [On Foot: backpacking and travel](guide:ON-FOOT-GUIDE) — how much to carry, packs, feet and blisters, water and food on the move, camps, river crossings and safety on the road.
