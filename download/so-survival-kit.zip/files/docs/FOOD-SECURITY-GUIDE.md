# 🥫 Food When It's Scarce: Storage, Rationing & Nutrition

How to keep a household fed for a year or more with no stores: how much food people need, what to
store and how to keep it good for decades, how to share it out fairly, how to prevent the hunger
diseases, how to refeed someone who is starving, how to keep babies alive, and what wild food the
Illinois Valley gives month by month. The books are in `Food-Security\` (`Storage-Rationing`,
`Nutrition-Deficiency`, `Foraging`). Growing, milling and cooking staples are in
`Food-From-Scratch\`, and cellars and drying in `Food-Storage\`.

> ### ⚠️ Rules that prevent the worst outcomes
> - **Grain alone is not enough.** Stored wheat, rice and beans have almost **no vitamin C**.
>   Store vitamin C tablets and learn to sprout seeds. Under 10 mg a day can cause
>   life-threatening scurvy within months ([BYU, p. 1](lib:longer-term-food-storage#page=1)).
> - **Never oxygen-pack or vacuum-seal moist food.** It can grow **botulism**. Dry food under 10%
>   moisture only ([USU, p. 97](lib:food-storage-for-emergencies#page=97)).
> - **Feed a starving person slowly.** Big meals all at once can kill them.
> - **Babies: breast milk first.** Never give plain animal milk under 6 months
>   ([WHO 2004, p. 40](lib:feeding-infants-and-young-children-during-emergencies#page=40)).
> - **Never cut the share of children, pregnant or nursing women, or the sick first.**
> - **Eat no wild plant you have not identified for certain.** Death camas and water hemlock grow
>   right here and kill.

---

## 🍽️ How much food people need

**Daily needs** (US official tables; "active" there only means walking over 3 miles a day — wood,
water and hand-digging are heavier, so plan from the **top** of each range)
([Dietary Guidelines, pp. 153–154](lib:dietary-guidelines-for-americans-2020-2025#page=153);
protein [p. 146](lib:dietary-guidelines-for-americans-2020-2025#page=146),
[p. 148](lib:dietary-guidelines-for-americans-2020-2025#page=148)):

| Person | Calories a day | Protein a day |
|---|---|---|
| Man, 19+ | 2,200–2,600 inactive; **2,800–3,000 active** | 56 g |
| Woman, 19+ | 1,600–2,000 inactive; **2,000–2,400 active** | 46 g |
| Teen boy | up to 3,200 | 52 g |
| Child 9–13 | — | 34 g |
| Child 2–8 | 1,000–2,000 | 13–19 g |
| Pregnant | **+340** (2nd trimester), **+452** (3rd) | **71 g** |
| Nursing | **+330** (first 6 months), **+400** after | **71 g** |

**Plan on 2,100 kcal per person per day**, averaged over all ages, with at least 10–12% from protein
and 17% from fat ([WHO 2002, p. 6](lib:food-and-nutrition-needs-in-emergencies#page=6);
[Sphere, p. 228](lib:sphere-handbook-2018#page=228)) — at least **53 g protein and 40 g fat**
([Sphere, p. 260](lib:sphere-handbook-2018#page=260)).

**Adjust it** ([WHO 2002, pp. 11–13](lib:food-and-nutrition-needs-in-emergencies#page=11)):
- **Cold:** add **100 kcal for every 9 °F** (5 °C) the average temperature is below 68 °F. Valley
  winter days average about 40 °F, so a poorly heated house should plan about **+300 kcal per person,
  November–March** *(rule of thumb from that formula)*.
- **Sick or already thin:** add 100–200 kcal. **Heavy work:** more.

**What 2,100 kcal looks like:** 400 g cereal (about 2 cups dry), 60 g beans, 25 g oil (2 Tbsp),
50 g fortified flour, 15 g sugar, 5 g iodized salt = 2,113 kcal, 58 g protein
([WHO 2002, p. 14](lib:food-and-nutrition-needs-in-emergencies#page=14)). For a year: about **322 lb
grain, 48 lb beans, 20 lb oil, 12 lb sugar, 4 lb salt** per person *(our arithmetic)*.

**Handy number:** 790 g (1.74 lb) of dry wheat gives 2,600 kcal and 103 g protein — so **1 lb of dry
grain ≈ 1,500 kcal** ([Kearny, p. 90](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=90)).

📚 **Go deeper:** [*Food and Nutrition Needs in Emergencies*, p. 11](lib:food-and-nutrition-needs-in-emergencies#page=11) — adjusting for cold, sickness and work; [Dietary Guidelines, p. 153](lib:dietary-guidelines-for-americans-2020-2025#page=153) — calories by age and activity.

## 📋 A year's food: the list and a worked example

**BYU's one-year list for one adult** ([BYU, p. 1](lib:longer-term-food-storage#page=1)), and the same
for **2 adults + 2 children under 8**, who count as about **3 adults** (children under 8 need about
half — [USU, p. 65](lib:food-storage-for-emergencies#page=65)):

| Item | 1 adult | Household (×3) | Sealed shelf life |
|---|---|---|---|
| Wheat | 132 lb | ~400 lb | 30+ years |
| White rice | 65 lb | ~195 lb | 30+ years |
| Rolled oats | 29 lb | ~87 lb | 20 years |
| Pasta | 21 lb | ~63 lb | — |
| Beans, peas, lentils | 62 lb | ~186 lb | 25 years |
| Nonfat dry milk | 60 lb | 180 lb | 15 years (cool) |
| Sugar or honey | 70 lb | 210 lb | 30+ years |
| Iodized salt | 8 lb | 24 lb | 30+ years |
| Cooking oil | 2 gallons | 6 gallons | **about 1 year** |
| Butter (frozen), peanut butter | 6 lb each | 18 lb each | — |

That is roughly 2,200 kcal a day *(our rough arithmetic)*. **Also:** baking soda, baking powder,
yeast, can openers, **a grain grinder** ([🖼️ hand mill and metate, FAO p. 17](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=17)), and recipes that use only stored food. USU's simpler rule:
**about 300 lb of grain per person per year**, 25–60 lb of it rice
([USU, p. 68](lib:food-storage-for-emergencies#page=68)).

**Fill the gaps** *(rule of thumb)*: vitamin C tablets (multivitamins keep less long — BYU), vitamin D
or [cod-liver oil](wiki:Cod_liver_oil), extra [iodized salt](wiki:Iodised_salt), whole grains and beans (not only white rice and flour), [seeds to
sprout](wiki:Sprouting), and a plan for fat once the oil goes rancid (lard, oil seeds, animals).

📚 **Go deeper:** [BYU *Longer-Term Food Storage*](lib:longer-term-food-storage#page=1) — the one-page table; [USU *Food Storage for Emergencies*, p. 65](lib:food-storage-for-emergencies#page=65) — wheat, rice, oats and beans chapter by chapter.

## 📦 Storing it for years

**Heat is the main enemy.** Keep food at **40–70 °F**. In BYU research, wheat stayed good **25 years
in a cool basement but only 5 in a hot garage or attic**. Keep containers off bare concrete
([USU, p. 31](lib:food-storage-for-emergencies#page=31)). Our summers pass 100 °F and sheds get hotter —
use the coolest inside room or a cellar ([Root Cellar guide](guide:ROOT-CELLAR-GUIDE)).

**Keep grain dry.** Above **12% moisture** it starts to break down, above 15% it molds, at 20% bacteria
grow. Freezing does not harm it ([USU, p. 66](lib:food-storage-for-emergencies#page=66)). **Seal it in
the dry season (July–September)**, not in wet winter air *(rule of thumb)*.

**Packing with oxygen absorbers** ([USU, p. 98](lib:food-storage-for-emergencies#page=98)):
1. Use **oxygen-tight** containers only: #10 cans or **[Mylar](wiki:Mylar)/foil bags**. Plastic buckets slowly let
   oxygen in — put a Mylar bag **inside** the bucket; the bucket keeps rats out.
2. [Absorber](wiki:Oxygen_scavenger) size: **100 cc** per quart jar, **300 cc** per gallon bag or #10
   can, **2,000 cc** per 5-gallon bucket. (Some charts say 500 cc, but a full bucket of grain holds
   about 1,500 cc of oxygen *(arithmetic)*; extra absorber does no harm.)
3. **Work fast:** an opened pack starts in 20 minutes and is spent in about 5 hours. Reseal spare
   packets in a small jar. Label every bag with contents and date.
- Absorbers are **not edible**; hand warmers are **not** a substitute.
- **Dry food under 10% moisture only.** Never moist food, home-canned butter or oil-coated raw eggs
  at room temperature — **botulism** ([USU, p. 32](lib:food-storage-for-emergencies#page=32)).

![A plastic bucket cut away to show a sealed Mylar bag of dry grain inside it, with an oxygen absorber packet on top of the grain, and a table of absorber sizes](img:FOOD-SECURITY-GUIDE/mylar-bag-in-bucket.svg)
*The Mylar bag keeps oxygen out and the bucket keeps rats out; the absorber goes in just before you seal (a diagram drawn for this guide).*

**Bugs** ([USU, p. 95](lib:food-storage-for-emergencies#page=95)): oxygen held under 1% for **12 days**
kills every stage, so Mylar with absorbers kills [weevils](wiki:Rice_weevil) ([🖼️ the common grain pests, FAO p. 78](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=78)). **[Dry ice](wiki:Dry_ice):** 3–4 inches of grain in a bucket,
2–3 oz crushed dry ice, fill, lid loose 30 minutes, then seal ([p. 66](lib:food-storage-for-emergencies#page=66)).
**Freeze** 2–3 days, warm a day, freeze again. **Heat** in a 130 °F oven for 30 minutes — but heated
grain will **not sprout**, so never heat seed grain.

| Sealed, low-oxygen | Keeps (USU) |
|---|---|
| Wheat | good bread after **32 years** ([p. 66](lib:food-storage-for-emergencies#page=66)) |
| White rice | 25–30 years ([p. 69](lib:food-storage-for-emergencies#page=69)) |
| Dry beans | 20–30 years ([p. 49](lib:food-storage-for-emergencies#page=49)) |
| Rolled oats | up to ~30 years ([p. 73](lib:food-storage-for-emergencies#page=73)) |
| Nonfat dry milk | 3–5 years cool, **as little as 3 months hot** ([p. 52](lib:food-storage-for-emergencies#page=52)) |
| Brown rice, whole-wheat flour, cornmeal, nuts, pearled barley | **not for long storage** — oils go rancid; store whole grain and grind as needed ([p. 32](lib:food-storage-for-emergencies#page=32)) |

**Rotate by eating it.** Cooking one day a week only from storage rotates everything about **every 7
years**. Before throwing old food out, cook a sample — the stale smell on opening often fades. **Old
beans that won't soften:** add **⅛ tsp baking soda per cup** ([BYU, p. 1](lib:longer-term-food-storage#page=1)).

📚 **Go deeper:** [USU, p. 97](lib:food-storage-for-emergencies#page=97) — oxygen removal and the botulism warning; [USU *Grain Insect Control*, p. 11](lib:food-storage-in-the-home-grain-insect-control-usu#page=11) — temperature, food-grade containers, container sizes.

## ⚖️ Setting and running a fair ration

**Work out the ration** *(rule of thumb)*:
1. **Weigh everything**, item by item.
2. Count the days to the next harvest and **add about 3 months of reserve**.
3. **Daily ration per person = stock ÷ (people × days)**, for each food.
4. Turn it into calories (1 lb dry grain ≈ 1,500 kcal) and compare with **2,100**. The gap is what the
   garden, hunting, fishing, foraging and animals must make up.

*Example (our arithmetic):* 3 adult-equivalents, 13 months (395 days). 900 lb of grain ÷ (3 × 395) ≈
**0.76 lb per person per day ≈ 1,100 kcal** — half the need. Start the garden and the
[rabbits](guide:RABBITS-GUIDE) and [chickens](guide:CHICKENS-GUIDE) now.

**Keep it fair** *(rule of thumb, except where cited)*:
- **One standard scoop** per food, marked with its weight. **A written daily log:** date, what went out,
  to whom, what is left.
- **Two people present** whenever stores are opened. Keep stores locked and out of sight.
- **Make sure children, the sick, older people and pregnant and nursing women really get their
  share** — give them **smaller, more frequent portions** ([Sphere, p. 235](lib:sphere-handbook-2018#page=235)).
- **Fuel, pots and water matter as much as food** — lacking any one hurts as much as a short ration
  ([WHO *Management of Nutrition*, p. 74](lib:management-of-nutrition-in-major-emergencies#page=74)).
  **Store salt and spices:** people eat more of a dull diet when it tastes good ([p. 75](lib:management-of-nutrition-in-major-emergencies#page=75)).
- **Grind just before eating** ([🖼️ Kearny's pipe-and-can grinder](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=83)). Milling loses about 10% of wheat or corn (WHO, p. 75), and ground whole
  corn keeps only 6–8 weeks ([Sphere, p. 232](lib:sphere-handbook-2018#page=232)).

**If this goes wrong:** one person losing weight faster → check they really eat their share (children
and old people often give theirs away). Stores shrinking faster than the log → reweigh, check for rats
and spoilage before suspecting people.

📚 **Go deeper:** [Sphere, p. 235](lib:sphere-handbook-2018#page=235) — fair distribution; [WHO *Management of Nutrition*, p. 74](lib:management-of-nutrition-in-major-emergencies#page=74) — rations, fuel, milling (scanned, not searchable); [Kearny, p. 84](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=84) — a homemade grain grinder.

## 🔥 Cooking with little fuel

**A fuel shortage is a nutrition problem:** one refugee pellagra outbreak happened partly because people
had no fuel to cook the beans they were given ([WHO *Pellagra*, p. 29](lib:pellagra-and-its-prevention#page=29)).

1. **Soak beans** first ([USU *Dry Beans*, p. 2](lib:dry-beans-and-peas-soaking-and-cooking-usu#page=2)).
2. **Crack or grind grain** — meal cooks much faster than whole kernels.
3. **Boil briefly, let insulation finish it.** Cook meal with at least **4 parts water to 1**, boil
   briefly, then finish in a fireless cooker for **4–5 hours**
   ([Kearny, p. 89](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=89)).
4. **Build a [haybox](wiki:Haybox):** a box packed with hay, wool or blankets around a lidded pot
   ([🖼️ the parts](lib:practical-action-fireless-cookers-haybox-technical-brief#page=2); [🖼️ cut-away drawing](lib:usda-homemade-fireless-cookers-fb771-1919#page=9)).
   Beans and meat boil 20–25 minutes before going in
   ([Practical Action, p. 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5));
   old beans longer ([USDA FB 771, p. 16](lib:usda-homemade-fireless-cookers-fb771-1919#page=16)).

![Cut-away drawing of a fireless cooker: a lidded cooking pot sitting on a tray of ash and sand inside a basket packed with insulation, lined with cloth and plastic, with a stuffed cushion as the lid](img:FOOD-SECURITY-GUIDE/haybox-parts.png)
*A haybox: insulation packed all around the pot, a tray under it and a thick cushion on top, so no heat escapes ([Practical Action, p. 2](lib:practical-action-fireless-cookers-haybox-technical-brief#page=2)).*

📚 **Go deeper:** [USDA *Homemade Fireless Cookers*, p. 4](lib:usda-homemade-fireless-cookers-fb771-1919#page=4) — building one; [Firewood guide](guide:FIREWOOD-GUIDE) — making the wood count.

## 🩺 Hunger diseases: spot them, prevent them

These come from **eating the same few stored foods for months**, and each is easy to prevent.

| Disease | Missing | Signs | Prevent with |
|---|---|---|---|
| **[Scurvy](wiki:Scurvy)** | Vitamin C | Tired, aching legs → swollen bleeding gums, tiny bleeds at hair roots, swollen joints | **Sprouts**, [rose hips](wiki:Rose_hip), berries, raw greens, potatoes, tablets |
| **[Beriberi](wiki:Thiamine_deficiency)** | Thiamine (B1) | Numb, burning, weak legs; or swelling and heart failure | Whole wheat, oats, beans, peas |
| **[Pellagra](wiki:Pellagra)** | Niacin | Dark, rough, sunburn-like rash on hands, neck, face ([🖼️ drawing](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=8)); diarrhoea; depression or confusion | **Lime- or ash-treated corn**, beans, peanuts, meat |
| **[Rickets](wiki:Rickets)** | Vitamin D | Swollen wrists and rib ends ("beads"), bowed legs, late walking ([🖼️ drawing](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=19)) | Sun on bare skin, eggs, liver, fish, cod-liver oil |
| **[Goitre](wiki:Goitre)** | Iodine | Swelling at the front of the neck ([🖼️ drawing](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=24)); miscarriage; brain damage in babies | **Iodized salt**, seafood, kelp |

**Scurvy** ([WHO *Scurvy*, pp. 15–17](lib:scurvy-and-its-prevention#page=15)): **10 mg of vitamin C a
day** prevents and cures it; gums improve within about 2 weeks. Rose hips and many berries have **over
300 mg per 100 g**; cooking destroys it; breast milk covers a nursing baby ([p. 33](lib:scurvy-and-its-prevention#page=33)).

**Sprouting for vitamin C** ([WHO *Scurvy*, pp. 35, 50](lib:scurvy-and-its-prevention#page=35); [🖼️ Kearny's sprouting drawing](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=92); [photos](wiki:Sprouting)):
1. Soak **whole** (unsplit) beans, peas, lentils or wheat **12–21 hours**.
2. Drain and spread between **damp cloths**; keep them damp.
3. Eat when shoots are **½–1 inch** (30–48 hours) — the shoot holds the vitamin. Raw, or cooked **under
   30 minutes**. Dried sprouts lose it.
4. **1½–2 oz of dry seed per person per day** is enough.
- Sprouted 3 days **in light** so they turn green, they also give some vitamin A
  ([Kearny, p. 92](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=92)).

![Three steps of sprouting: whole seeds soaking in a jar of water, seeds spread between two damp cloths, and seeds with shoots half an inch to an inch long beside a ruler](img:FOOD-SECURITY-GUIDE/sprouting-for-vitamin-c.svg)
*Soak, spread between damp cloths, eat when the shoots are ½–1 inch (a diagram drawn for this guide).*

**Beriberi** can appear within **2–3 months** on white rice or white flour
([WHO *Thiamine*, p. 14](lib:thiamine-deficiency-beriberi#page=14)). **Babies nursed by deficient mothers
can die within hours**, usually at 1–3 months old ([p. 22](lib:thiamine-deficiency-beriberi#page=22)).
Don't over-wash rice or pour off its water. Strong tea, raw fermented fish and molds in damp food block
thiamine ([p. 17](lib:thiamine-deficiency-beriberi#page=17)).

**Pellagra** comes from corn-heavy diets with untreated corn ([WHO *Pellagra*, p. 13](lib:pellagra-and-its-prevention#page=13));
one outbreak began **4 months after peanuts were dropped** from a ration. If corn is a staple,
**[nixtamalize](wiki:Nixtamalization)** it ([FAO, p. 19](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=19);
[Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE)) and eat beans or meat with it.

**Rickets and our winter sun:** **10–15 minutes of sun on a child's bare skin daily** prevents it.
Treatment: 5,000 IU vitamin D daily for 4–6 weeks, then 1,000 IU daily for 6 months, usually from
fish-liver oil ([WHO *Management of Nutrition*, p. 46](lib:management-of-nutrition-in-major-emergencies#page=46)).
*Rule of thumb:* at 42° N the **November–February sun is too weak** to make vitamin D, and the valley is
often cloudy — store cod-liver oil or vitamin D, and get children into the summer sun.

**Iodine:** adults need about **150 µg a day** ([WHO, pp. 36–37](lib:management-of-nutrition-in-major-emergencies#page=36)),
and **250 µg when pregnant or nursing** (WHO 2007). About ½ teaspoon of US iodized salt gives roughly
150 µg — you don't need more salt than that. The Pacific
Northwest was historically part of the US **"goitre belt"** *(rule of thumb)* — store iodized salt
sealed, dry and dark, and use fish and [kelp](wiki:Kelp) from the coast.

📚 **Go deeper:** [WHO *Scurvy*, p. 35](lib:scurvy-and-its-prevention#page=35) — the famine sprouting method; [WHO *Thiamine*, p. 19](lib:thiamine-deficiency-beriberi#page=19) — forms of beriberi; [WHO *Pellagra*, p. 8](lib:pellagra-and-its-prevention#page=8) — the rash and outbreaks; [*Where There Is No Doctor*, p. 24](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=24) — goitre.

## 🦴 Starvation and refeeding slowly

**Recognize it** ([WHO *Management of Nutrition*, pp. 25–26](lib:management-of-nutrition-in-major-emergencies#page=25); [malnutrition](wiki:Malnutrition); [🖼️ signs in children, mild to severe](lib:where-there-is-no-doctor-21-health-and-sicknesses-of-children#page=12)):
- **[Marasmus](wiki:Marasmus)** — "skin and bones", an old man's face, loose "baggy pants" skin on the buttocks ([🖼️ drawing](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=6)).
- **[Kwashiorkor](wiki:Kwashiorkor)** — swollen feet and legs, peeling "flaky-paint" skin, thin loose
  hair, misery, no appetite ([🖼️ drawing](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=7)).
- **Adults** — wasting and weakness, sometimes swelling.
- For every severe case there may be about **10 moderate ones**.

**Refeed low and slow:**
1. Sudden big meals can cause fatal **[refeeding syndrome](wiki:Refeeding_syndrome)** *(rule of thumb)*.
2. **Starter formula (WHO F-75)** for a severely malnourished child, used for the first days until
   appetite returns: 25 g dried skim milk + 70 g sugar + 35 g cereal flour + 27 g oil +
   water to 1 litre, **boiled 5–7 minutes**. Or 300 mL fresh cow's milk + 70 g sugar + 35 g flour +
   17 g oil + water to 1 litre ([WHO *Severe Malnutrition*, p. 21](lib:management-of-severe-malnutrition#page=21)).
   After it cools, WHO adds **20 mL of mineral mix** per litre (potassium and magnesium — "it must be added")
   and 140 mg vitamin mix or a multivitamin; recipes on [p. 61](lib:management-of-severe-malnutrition#page=61).
3. **Small feeds every 2–3 hours, day and night** ([p. 22](lib:management-of-severe-malnutrition#page=22)).
   **No iron in the first week** ([p. 9](lib:management-of-severe-malnutrition#page=9)).
4. **Adults:** WHO aims for about **40 kcal per kg of body weight a day**; once appetite returns, give
   ordinary food with added oil ([WHO, p. 111](lib:management-of-nutrition-in-major-emergencies#page=111)).
   **But if they've eaten almost nothing for a week or more, start lower** — about 10–20 kcal per kg a
   day, building up over 4–7 days (UK NICE guidance). Feeding too much too fast can stop the heart
   ([refeeding syndrome](wiki:Refeeding_syndrome)).
5. **Dehydrated and starving:** don't give full-strength rehydration salts. One [ORS](wiki:Oral_rehydration_therapy) packet in **2 litres**
   plus 50 g sugar and 40 mL mineral mix (ReSoMal) ([WHO *Severe Malnutrition*, p. 18](lib:management-of-severe-malnutrition#page=18)).

**Note:** these manuals are from 1999–2000; **WHO updated its guidance in 2013**, including some drug
doses. F-75 and ReSoMal are still used — leave the drugs to someone trained.

📚 **Go deeper:** [WHO *Severe Malnutrition*, p. 21](lib:management-of-severe-malnutrition#page=21) — F-75 and F-100 recipes and charts; [*Where There Is No Doctor*, p. 6](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=6) — recognizing malnutrition; [WTND ch. 21, p. 12](lib:where-there-is-no-doctor-21-health-and-sicknesses-of-children#page=12) — malnourished children.

## 🍼 Babies and toddlers in a shortage

**[Breastfeeding](wiki:Breastfeeding) first** ([WHO 2004, pp. 21–23](lib:feeding-infants-and-young-children-during-emergencies#page=21)):
- **Only extreme hunger lowers a mother's milk** — feed the mother well. **Keep nursing when mother or
  baby is sick**, and nurse more often.
- Weak or premature babies: express milk and feed it from an **open cup** ([🖼️ removing milk by hand](lib:a-book-for-midwives-16-breastfeeding#page=6); [🖼️ cup feeding](lib:a-book-for-midwives-16-breastfeeding#page=7)).
- Substitutes only for babies with no breast milk, **by cup, not bottle**
  ([p. 27](lib:feeding-infants-and-young-children-during-emergencies#page=27)). If a baby is due or small,
  store real infant formula as a backup: about **110 g a day, 3.3 kg (7¼ lb) a month** (same page).

**If the milk has stopped or the mother is gone:**
- **Relactation:** a woman who stopped breastfeeding can make milk again, for her own or an adopted
  baby, without another pregnancy; even a woman never pregnant (a grandmother) can sometimes make some
  ([WHO *Relactation*, p. 7](lib:relactation-review#page=7); scanned). Frequent suckling brings the milk.
- **A healthy [wet-nurse](wiki:Wet_nurse)** is next best ([WHO 2004, p. 23](lib:feeding-infants-and-young-children-during-emergencies#page=23)).
- Homemade dry-milk formulas in two old books are a **last resort** — see the last section.

**Babies 6–24 months:**
- Porridge **thick enough to stay on the spoon**, not thin gruel, enriched with mashed beans, oil, egg or
  greens. Flour from **sprouted grain** cooks thinner, so more food fits a small stomach
  ([WHO *Complementary Feeding*, pp. 17–18](lib:complementary-feeding-family-foods#page=17)).
- Non-breastfed babies under one need **5 meals a day**, not 3 ([p. 37](lib:complementary-feeding-family-foods#page=37)).
- Non-breastfed toddlers: **200–400 mL milk a day** if they eat other animal foods, otherwise **300–500 mL**.
  Goat, cow or sheep milk — **boil raw milk** ([WHO 2005, pp. 14–16](lib:feeding-non-breastfed-children#page=14)).

📚 **Go deeper:** [WHO *Infant Feeding in Emergencies*, p. 21](lib:feeding-infants-and-young-children-during-emergencies#page=21) — keeping breastfeeding going; [*A Book for Midwives*, p. 7](lib:a-book-for-midwives-16-breastfeeding#page=7) — cup feeding removed milk; [*Where There Is No Doctor*, p. 14](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=14) — the first 6 months.

## 🌿 Wild food around the valley

> 📷 **Not sure what it is?** Photograph it with the [plant and mushroom identifier](guide:PLANT-ID) (🧮 Tools tab). It suggests names and flags poisonous groups, but it's often wrong: confirm every feature here before you eat or use anything.

**What the Takelma ate here.** The Takelma people lived along the middle Rogue and south toward the
Illinois River ([Sapir 1907, p. 3](lib:takelma-indians#page=3)). Their staple was the **"black
acorn"** ([Sapir, p. 8](lib:takelma-indians#page=8); [California black oak](wiki:Quercus_kelloggii); [🖼️ photo](lib:california-black-oak-plant-guide#page=1)), pounded, sifted, **leached with hot water on
clean sand** and boiled as mush ([Sapir, p. 9](lib:takelma-indians#page=9)).
**[Camas](wiki:Camassia_quamash)** ([🖼️ photo](lib:great-camas-plant-guide-usda-nrcs#page=1)) was [pit-roasted](wiki:Earth_oven) on alder over hot stones, sometimes for days, then
mashed into cakes for winter. **[Manzanita](wiki:Arctostaphylos_viscida)** berries ([🖼️ flowers and berries](lib:whiteleaf-manzanita#page=2)) were pounded to flour
with [sugar-pine](wiki:Pinus_lambertiana) nuts; tarweed and sunflower-type seeds were parched and ground. They also ate [madrone](wiki:Arbutus_menziesii)
berries, pine nuts, salmon, steelhead, trout, crawfish and freshwater mussels.

**Month by month** (compiled from several books; dates shift 2–4 weeks with elevation and weather):

| Months | Gather | Notes |
|---|---|---|
| **Dec–Feb** | [Bigleaf maple](wiki:Acer_macrophyllum) sap ([🖼️ tapping](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=4)); stored nuts; rose hips ([🖼️ wild rose](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=103)); [cattail](wiki:Typha_latifolia) roots; first [miner's lettuce](wiki:Claytonia_perfoliata) and [chickweed](wiki:Stellaria_media) | Sap runs on freeze–thaw days ([OSU, p. 2](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=2)); [Saunders, p. 161](lib:useful-wild-plants-of-the-united-states#page=161) |
| **Mar–Apr** | [Nettle](wiki:Urtica_dioica) tops ([🖼️ drawing](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=121)), miner's lettuce, [dock](wiki:Rumex_crispus), cattail shoots, [morels](wiki:Morchella) (especially after a burn) | Young nettles before flowering ([OSU, p. 2](lib:osu-wild-edibles-stinging-nettle-em-9373#page=2)); [morels](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest-pnw-gtr-309#page=24) |
| **Apr–May** | **Mark camas while it blooms** ([🖼️ camas](lib:great-camas-plant-guide-usda-nrcs#page=1) vs. [🖼️ death camas](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2)) | **Death camas blooms in May at about 1,400 ft — our elevation** ([PNW 104, p. 2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2)) |
| **Jun–Aug** | Wild strawberry, [thimbleberry](wiki:Rubus_parviflorus), [serviceberry](wiki:Amelanchier_alnifolia), manzanita berries, [Oregon grape](wiki:Berberis_aquifolium) (July–Aug) | [NRCS Manzanita, p. 1](lib:whiteleaf-manzanita#page=1); [Oregon grape](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=46) ([🖼️ drawing](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=45)) |
| **Aug–Sep** | Blackberries; [salal](wiki:Gaultheria_shallon); [huckleberries](wiki:Vaccinium_membranaceum) up high; [blue elderberry](wiki:Sambucus_cerulea) (**cooked only**); [hazelnuts](wiki:Corylus_cornuta); sugar pine nuts | [Salal, p. 75](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=75); [huckleberry, p. 126](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=126) ([🖼️ drawing, p. 125](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=125)); hazelnuts in early autumn ([NRCS](lib:beaked-and-california-hazelnut#page=1)) — Food from Scratch says June–July, so start looking in summer |
| **Sep–Nov** | Acorns (black oak, [white oak](wiki:Quercus_garryana), [tanoak](wiki:Notholithocarpus)); [chinquapin](wiki:Chrysolepis_chrysophylla); [wapato](wiki:Sagittaria_latifolia) from ponds; [chanterelles](wiki:Cantharellus_formosus) after soaking rains; **rose hips** ([photos](wiki:Rose_hip)); abandoned-orchard fruit | [Wapato, p. 1](lib:wapato-broadleaf-arrowhead#page=1); [Mushroom guide](guide:MUSHROOM-GUIDE) |

Leaching acorns, roasting camas and using cattail: [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE).

📚 **Go deeper:** [Sapir, *Notes on the Takelma*, p. 8](lib:takelma-indians#page=8) — local foods and how they were made; [UCCE *Foods from the Tanoak Forest*, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2) — acorn processing; [USFS *Special Forest Products*, p. 75](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=75) — berries and shrubs with seasons.

🌰 **How the first peoples did it, step by step** (acorns, camas, pinole, salmon, the year's round): [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE).

## ☠️ Foraging safety rules

> 📷 **Not sure what it is?** Photograph it with the [plant and mushroom identifier](guide:PLANT-ID) (🧮 Tools tab). It suggests names and flags poisonous groups, but it's often wrong: confirm every feature here before you eat or use anything.

1. **Eat nothing not 100% identified** — ideally confirmed by two people with a book.
2. **Skip the whole wild-carrot family** (white umbrella-shaped flower heads — [🖼️ poison and water hemlock photos](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=13); [wild carrot](wiki:Daucus_carota), [poison hemlock](wiki:Conium_maculatum)). **[Western water
   hemlock](wiki:Cicuta_douglasii)** grows along valley creeks and kills fast, by seizures
   ([PNW 109, p. 5](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=5); [🖼️ chambered root and stem, p. 1](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ look-alikes side by side, pp. 3–4](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3)).
3. **Camas:** dig only from a patch you watched bloom and marked plant by plant, only blue-flowered
   plants. **Skip every white or cream-flowered plant** — [death camas](wiki:Toxicoscordion_venenosum)
   is creamy-white and every part is poisonous ([PNW 104, p. 2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2); [🖼️ WSU photos](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=4); [🖼️ Army drawing](lib:fm-3-05-70-survival-2002#page=507)).
4. **Always leach acorns. Always cook elderberries**; never eat their stems, leaves or green berries
   ([OSU, p. 4](lib:osu-play-it-safe-when-preserving-elderberries-em-9446#page=4); [🖼️ elderberry drawing](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=111)).
5. **Never eat [bracken fern](wiki:Pteridium_aquilinum)** — it holds a cancer-causing compound and an
   enzyme that destroys thiamine ([WSU, p. 11](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=11); [🖼️ drawing](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=101)).
6. **Cook anything from ponds** (wapato, cattail, watercress) — parasites *(rule of thumb)*.
7. **Throw out moldy, damp or discolored grain**, and grass seed heads with black [ergot](wiki:Claviceps_purpurea) spurs
   ([USU, p. 66](lib:food-storage-for-emergencies#page=66); rule of thumb; [🖼️ ergot photo](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=9)).
8. **Lean meat alone starves you.** Living on rabbit or lean venison without fat causes "rabbit
   starvation" — keep fat in the diet ([render lard](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=2); rule of thumb).
9. **Try a new wild food in a small amount first**, and **take no more than a third of a patch**
   *(rule of thumb)*.

![USDA photograph of a western water hemlock rootstalk split lengthwise, showing the stacked hollow chambers inside, with thick tubers and fine roots below](img:FOOD-SECURITY-GUIDE/water-hemlock-root.png)
*Western water hemlock: the thick rootstalk is hollow, with cross-walls making chambers full of poisonous juice ([AIB 415, p. 110](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=110)).*

![USDA photograph of western water hemlock in flower: small white flowers in flat umbrella-like clusters on tall stems](img:FOOD-SECURITY-GUIDE/water-hemlock-flowers.png)
*Water hemlock flowers: white umbrellas like the rest of the carrot family; leaf side veins run to the notches, not the tips ([AIB 415, p. 109](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=109)).*

![Two USDA photographs of death camas in bloom: clusters of small yellowish-white flowers on short stalks above grass-like leaves](img:FOOD-SECURITY-GUIDE/death-camas-in-bloom.png)
*Death camas in bloom: yellowish-white flower clusters above grass-like leaves; skip every white or cream-flowered plant ([AIB 415, p. 35](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=35)).*

**If someone may be poisoned:** death camas causes drooling, mouth numbness, vomiting, weakness,
confusion and an irregular heartbeat 1–8 hours after eating ([PNW 104, p. 2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2)).
Keep them warm, on their side if drowsy, watch their breathing, and keep a piece of the plant
*(rule of thumb)*. See the [Field Care guide](guide:FIELD-CARE-GUIDE).

📚 **Go deeper:** [PNW 109 *Western Waterhemlock*, p. 5](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=5) — look-alikes side by side; [USDA *Plants Poisonous to Livestock*, p. 23](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=23) — bracken; [PNW 104, p. 2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2) — death camas bloom time and symptoms.

## ⚠️ Old advice in the library to ignore

- **"Two pounds of cooked grain per day"** as an adequate diet ([FEMA HS-4, p. 111](lib:preparedness-planning-for-a-nuclear-crisis#page=111)).
  It should be about **1½–2 lb of DRY grain**; 2 lb *cooked* is only about 800–1,200 kcal. The same page
  says **"adults do not get rickets"** — they do (it is called osteomalacia). **Instead:** plan from
  2,100 kcal and the tables above.
- **Grain puree for babies under 6 months**, and scarce cow's milk saved for them
  ([FEMA HS-4, p. 114](lib:preparedness-planning-for-a-nuclear-crisis#page=114)) — outdated and
  dangerous. **Instead:** breast milk, relactation or a wet-nurse; no animal milk or solids before 6 months.
- **Homemade skim-milk + oil + sugar infant formula** ([FEMA HS-4, p. 114](lib:preparedness-planning-for-a-nuclear-crisis#page=114);
  [Kearny, p. 96](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=96)) — a **last
  resort only**, when no breast milk, wet-nurse or real formula exists. It is not a complete infant food,
  and emergencies make all artificial feeding riskier ([WHO 2004, p. 27](lib:feeding-infants-and-young-children-during-emergencies#page=27)).
  If you must: boiled water, a cup not a bottle, made fresh. Kearny himself says mother's milk is best.
- **"Ferns on toast"** — [Saunders 1920, pp. 146–147](lib:useful-wild-plants-of-the-united-states#page=146)
  recommends bracken. **Don't** (cancer, thiamine loss).
- **Camas with no death-camas warning** — [Saunders, pp. 43–45](lib:useful-wild-plants-of-the-united-states#page=43).
  **Instead:** follow rule 3 above.
- **Drug doses in the WHO 1999–2000 malnutrition manuals** predate WHO's 2013 update. Use the feeding
  methods; leave the drugs to trained hands.

📚 **Go deeper:** [WHO 2004, p. 40](lib:feeding-infants-and-young-children-during-emergencies#page=40) — why no animal milk before 6 months; [WHO *Severe Malnutrition*, p. 21](lib:management-of-severe-malnutrition#page=21) — the feeding methods that still hold.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Storing, grinding and cooking**
- Hand grain mill and stone metate — [🖼️ FAO, p. 17](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=17); [Quern-stone](wiki:Quern-stone)
- Kearny's homemade pipe-and-can grain grinder — [🖼️ Kearny, p. 83](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=83)
- Weevils and moths in stored grain — [🖼️ FAO, p. 78](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=78); [Rice weevil](wiki:Rice_weevil)
- Mylar bags, oxygen absorbers, dry ice — [BoPET (Mylar)](wiki:Mylar); [Oxygen scavenger](wiki:Oxygen_scavenger); [Dry ice](wiki:Dry_ice)
- Hay-box (fireless) cooker — [🖼️ Practical Action, p. 2](lib:practical-action-fireless-cookers-haybox-technical-brief#page=2); [🖼️ USDA FB 771, pp. 8–9](lib:usda-homemade-fireless-cookers-fb771-1919#page=8); [Haybox](wiki:Haybox)

**Hunger diseases and starvation**
- Scurvy and beriberi — [Scurvy](wiki:Scurvy); [Thiamine deficiency](wiki:Thiamine_deficiency)
- Pellagra rash — [🖼️ WTND, p. 8](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=8); [Pellagra](wiki:Pellagra)
- Rickets — [🖼️ WTND, p. 19](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=19); [Rickets](wiki:Rickets)
- Goitre — [🖼️ WTND, p. 24](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=24); [Goitre](wiki:Goitre)
- Marasmus ("skin and bones") and kwashiorkor (swollen) — [🖼️ WTND, p. 6](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=6); [🖼️ WTND, p. 7](lib:where-there-is-no-doctor-11-nutrition-what-to-eat-to-be-healthy#page=7); [Marasmus](wiki:Marasmus); [Kwashiorkor](wiki:Kwashiorkor)
- Signs of malnutrition in children — [🖼️ WTND ch. 21, p. 12](lib:where-there-is-no-doctor-21-health-and-sicknesses-of-children#page=12)
- Sprouting seeds — [🖼️ Kearny, p. 92](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=92); [Sprouting](wiki:Sprouting)
- Removing breast milk by hand, and cup feeding — [🖼️ A Book for Midwives, p. 6](lib:a-book-for-midwives-16-breastfeeding#page=6); [🖼️ p. 7](lib:a-book-for-midwives-16-breastfeeding#page=7)

**Wild foods of the valley**
- California black oak and its acorns — [🖼️ NRCS, p. 1](lib:california-black-oak-plant-guide#page=1); [🖼️ Army oak drawing](lib:fm-3-05-70-survival-2002#page=449); [Quercus kelloggii](wiki:Quercus_kelloggii)
- Camas — [🖼️ NRCS, p. 1](lib:great-camas-plant-guide-usda-nrcs#page=1); [Camassia quamash](wiki:Camassia_quamash)
- Manzanita flowers and berries — [🖼️ NRCS, pp. 1–2](lib:whiteleaf-manzanita#page=1); [Arctostaphylos viscida](wiki:Arctostaphylos_viscida)
- Tapping bigleaf maple — [🖼️ OSU, p. 4](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=4); [Acer macrophyllum](wiki:Acer_macrophyllum)
- Stinging nettle — [🖼️ USFS, p. 121](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=121); [🖼️ OSU photo](lib:osu-wild-edibles-stinging-nettle-em-9373#page=1); [Urtica dioica](wiki:Urtica_dioica)
- Oregon grape, salal, huckleberry — [🖼️ USFS, p. 45](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=45); [🖼️ p. 75](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=75); [🖼️ p. 125](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=125); [Gaultheria shallon](wiki:Gaultheria_shallon)
- Elderberry (cook it) and wild rose hips — [🖼️ USFS, p. 111](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=111); [🖼️ USFS, p. 103](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=103); [Rose hip](wiki:Rose_hip)
- Hazelnut — [🖼️ NRCS, p. 1](lib:beaked-and-california-hazelnut#page=1); [Corylus cornuta](wiki:Corylus_cornuta)
- Wapato — [🖼️ NRCS, p. 1](lib:wapato-broadleaf-arrowhead#page=1); [Sagittaria latifolia](wiki:Sagittaria_latifolia)
- Morel — [🖼️ USFS mushrooms, p. 24](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest-pnw-gtr-309#page=24); [Morchella](wiki:Morchella)

**The deadly look-alikes**
- Western water hemlock: chambered root, leaves, look-alikes — [🖼️ PNW 109, p. 1](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ pp. 3–4](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3); [🖼️ WSU, p. 14](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=14); [Cicuta douglasii](wiki:Cicuta_douglasii)
- Poison hemlock and wild carrot — [🖼️ WSU, p. 13](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=13); [Conium maculatum](wiki:Conium_maculatum); [Daucus carota](wiki:Daucus_carota)
- Death camas — [🖼️ PNW 104, p. 2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2); [🖼️ WSU, p. 4](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=4); [🖼️ Army drawing](lib:fm-3-05-70-survival-2002#page=507); [Toxicoscordion venenosum](wiki:Toxicoscordion_venenosum)
- Bracken fern — [🖼️ WSU, p. 11](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=11); [🖼️ USFS, p. 101](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=101); [Pteridium aquilinum](wiki:Pteridium_aquilinum)
- Ergot on grain heads — [🖼️ WSU, p. 9](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=9); [Claviceps purpurea](wiki:Claviceps_purpurea)

---

## 🔗 Related guides

- [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — milling, acorn flour, camas, nixtamal corn, lard
- [Root Cellar guide](guide:ROOT-CELLAR-GUIDE) — a cool, dry, rat-proof place for stored food
- [Seed Bank guide](guide:SEED-BANK-GUIDE) — growing next year's food and the calorie crops
- [Chickens](guide:CHICKENS-GUIDE), [Rabbits](guide:RABBITS-GUIDE), [Goats](guide:GOATS-GUIDE) and [Milk, Butter & Cheese](guide:DAIRY-GUIDE) — meat, eggs, milk and fat on little bought feed
- [Mushroom guide](guide:MUSHROOM-GUIDE) — fall mushrooms and the deadly look-alikes
- [Field Care guide](guide:FIELD-CARE-GUIDE) — poisoning, dehydration and sickness with no help coming
- [Firewood guide](guide:FIREWOOD-GUIDE) — the fuel cooking depends on
- [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE) — acorns, camas, salmon, cordage and baskets, houses, and tending the land with fire, the way people here lived for thousands of years.
