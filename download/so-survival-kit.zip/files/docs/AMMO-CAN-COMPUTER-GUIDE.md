# 🧰 Ammo-Can Library Computer

How to build a small computer that lives in a steel ammo can and runs this whole library,
including the offline AI. While the can is shut and sealed, it shields the computer from an EMP
or a solar storm. When you need it, open the lid and plug in power. Any phone nearby then uses
the library and the AI in its web browser, with **no screen, keyboard or internet**. It's a
Raspberry Pi (a computer the size of a deck of cards), a library drive, a battery and an old phone.

> ### The short version
> - **Shut = protected, open = in use.** The can only shields while the lid is closed and sealed.
>   Never run the computer with the lid shut: it overheats, and phones can't reach it.
> - **The phone is the screen.** The AI and the books run on the Pi. An old phone with no SIM
>   card or phone plan is fine.
> - **One-time setup** with a TV and keyboard: run **`SETUP-Raspberry-Pi.sh`** from the drive.
>   After that: plug in power → wait 2–3 minutes → join the Pi's Wi-Fi → open the address.
> - **Steel can only.** Plastic ammo cans block nothing. Scrape the paint at the rim and tape the
>   lid seam with conductive foil tape (see the [EMP guide](guide:EMP-GUIDE)).
> - **Practice now.** Build it, test it on battery with the internet off, pack it, and check it
>   every few months.

---

## 🧭 How it works

| | Lid **shut** and taped (storage) | Lid **open** (in use) |
|---|---|---|
| Shielded from EMP? | **Yes**: a closed metal shell keeps the pulse out ([EMP guide](guide:EMP-GUIDE)) | No, but an EMP lasts seconds to minutes. Solar storms come with hours of warning |
| Running? | No: it's off, unplugged, nothing passes through the can | Yes: power cable in, Wi-Fi out to the phones |
| Heat | None | The Pi gets warm. The open lid lets the heat out |

**Why not run it sealed?** A computer that's on needs power coming in, Wi-Fi going out and a
way to shed heat. Every cable or hole through the can breaks the shield. The government
guidance is plain: **no wires through, no holes drilled**
([🖼️ right and wrong ways through a shield](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)).
So the can is the computer's **storage box and shield**, not its case while it runs.

**What the phones see:** the Pi makes its **own Wi-Fi network**. No router or internet is
needed. Phones join it and open the library in the browser, the same way as
[sharing with phones nearby](guide:START-ON-ANY-DEVICE). Several phones can use it at once.
Search and the books answer instantly. The AI answers one person at a time, in about a minute.

![The ammo can open, with the Raspberry Pi, library drive and power bank in a foam tray; the Pi sends out its own Wi-Fi to two phones, which open the address http://192.168.4.1:8096 in the browser](img:AMMO-CAN-COMPUTER-GUIDE/how-it-works.svg)
*Lid open, power in: the Pi makes its own Wi-Fi and the phones open the library in the browser (a diagram drawn for this guide).*

---

## 🛒 What to buy

| Part | What to get | Why |
|---|---|---|
| **Computer** | **Raspberry Pi 5, 8 GB** memory (or **16 GB** for the bigger AI) | 8 GB runs the "Standard" AI; 16 GB can run "Smart". It has a **power button** for safe shutdown. A **Pi 4** (4 GB or more) also works: a smaller, slower AI, but easier on batteries. Add a push button for a few dollars ([step 5](#5-raspberry-pi-4-add-a-power-button)) |
| **Cooler** | Raspberry Pi **Active Cooler** (clips on). Pi 4: a heatsink set or a small fan case | The AI works the chip hard. Without a cooler the Pi slows itself down |
| **Memory card** | microSD card, **32 GB or more** | Holds the Pi's own system (Raspberry Pi OS) |
| **Library drive** | A small **USB SSD**, 256 GB or more, formatted **exFAT** | The full library is about 170 GB; see [How big a drive?](guide:GET-THE-LIBRARY). It can be the same drive the installer filled |
| **Power, at home** | The official **Raspberry Pi 27W USB-C power supply** | Gives the Pi 5 everything it wants |
| **Power, off-grid** | A **USB-C power bank**, 20,000 mAh or more; or a 12-volt battery with a **USB-C car charger** | Recharge from a small solar panel; see the [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE) |
| **Screen** | An **old phone or tablet** with a web browser, and its charging cable. Or a **7-inch touchscreen** on the Pi itself ([touchscreen option](#option-a-touchscreen-on-the-pi)) | Any phone works, iPhones too. No phone plan needed |
| **The can** | A **steel .50 cal ammo can** (inside about 11 × 5.5 × 7 inches) | Fits the Pi, drive, power bank and a phone. Go bigger for a tablet |
| **Padding** | A sheet of closed-cell foam (camping pad or gun-case foam) | Holds everything still and keeps it off the bare metal |
| **Seal** | Copper or aluminum **foil tape with conductive glue** | Closes the gap the rubber gasket leaves ([EMP guide](guide:EMP-GUIDE)) |
| **Pi 4 only: power button** | A small **push button** (the spring-back kind) on two wires with **female jumper plugs** | Becomes a safe shut-down and start button ([step 5](#5-raspberry-pi-4-add-a-power-button)) |
| **For setup only** | A TV or monitor, a **micro-HDMI to HDMI** cable, a USB keyboard and mouse | Borrow them. You need them once |

**Plastic cans don't work.** Plastic and fiberglass cans let the pulse straight through. Buy
steel ([Ammunition box](wiki:Ammunition_box)).

---

## 🔧 Build it, step by step

### 1. Fill the library drive (on your regular computer)

Run the installer onto the USB SSD as described in
[Get the whole library](guide:GET-THE-LIBRARY). Keep the drive **exFAT** and keep **AI** ticked.
The setup file, **`SETUP-Raspberry-Pi.sh`**, ends up at the top of the drive next to the START
files.

### 2. Put Raspberry Pi OS on the memory card (on your regular computer)

1. Download and install **Raspberry Pi Imager** from raspberrypi.com.
2. Plug in the microSD card. In Imager choose **Raspberry Pi 5** (or 4), then
   **Raspberry Pi OS (64-bit)**, then the card.
3. When it asks about **customisation settings**, say **Edit settings / Yes** and fill in a
   **user name and password** (write them down), **your home Wi-Fi**, and your
   **country/time zone**. Then **Write**.

### 3. First start (with the TV)

1. Clip the cooler onto the Pi. Put the memory card in the slot underneath.
2. Plug in the TV (micro-HDMI port 0, next to the power socket), keyboard and mouse, and the
   library drive (a **blue** USB port).
3. Plug in power. After a minute or two the desktop appears. If it offers updates, let it
   finish. Your home internet is fine to use now.

### 4. Run the setup

1. Open the library drive in the **File Manager** (a window usually pops up when it's plugged
   in) and open **OfflineLibrary**.
2. Double-click **`SETUP-Raspberry-Pi.sh`** and choose **Execute in Terminal**. If that isn't
   offered, press **F4** to open a terminal in that folder, type `bash SETUP-Raspberry-Pi.sh` and
   press Enter.
3. If it asks for a password, type the Pi's password from step 2.
4. Answer the questions. **Pressing Enter accepts each suggestion**, and the suggestions are fine:
   - **Go ahead?** y
   - **Wi-Fi name** (default **Emergency-Library**) and **password** (it makes one up for you)
   - **Use a touchscreen on this Pi for the library?** n, unless you added one (see the
     [touchscreen option](#option-a-touchscreen-on-the-pi))
   - **Will this Pi ever run on a power bank or battery?** y (on a Pi 5 this lets the library
     drive get enough power from a power bank)
5. **Write down the Wi-Fi name, password and address** it shows, for example
   `http://192.168.4.1:8096`. Say **y** to restart.

What the setup changed: the Pi now makes its **own Wi-Fi** every time it starts (instead of
joining your home Wi-Fi), **starts the library by itself** and shares it, mounts the library drive
in the same place every time, and **turns off the desktop**. That leaves more memory for the AI
and makes one press of the power button a safe shutdown. On a Pi 4 it also turns two of the
pins into a power button (next step). Running `bash SETUP-Raspberry-Pi.sh --undo` puts it all back.

### 5. Raspberry Pi 4: add a power button

A Pi 5 has a power button built in; skip to step 6. A Pi 4 doesn't, but the setup turned two of
its pins into one. All you add is the button: five minutes, no soldering.

**What to get:** a small **push button** of the spring-back kind, on two wires ending in
**female jumper plugs** (search for *push button female jumper wire Raspberry Pi*), or any small
push button plus two female jumper wires. **Not** a switch that goes on the power cable: that just
cuts the power, which is what you're avoiding.

**Fitting it (with the Pi unplugged):**

1. Find the double row of 40 pins along one long edge of the Pi.
2. Start at the end of that row **farthest from the USB ports**. Count **three pairs** of pins in.
   That third pair is **pins 5 and 6**.
3. Push one wire onto each of those two pins. Either way round is fine.
4. Lead the button out where you can reach it, or tape it to the foam tray.

![A Raspberry Pi 4 seen from above, with the USB ports at the right end; the push button's two wires go onto the third pair of pins counted from the left end of the 40-pin row, pins 5 and 6](img:AMMO-CAN-COMPUTER-GUIDE/pi4-power-button-pins.svg)
*Count three pairs in from the end farthest from the USB ports: pins 5 and 6 (a diagram drawn for this guide).*

**Using it:** press once and the Pi shuts down safely. Wait until the **green light stays off**
(about 20 seconds), then unplug. If it's still plugged in, **press again** and it starts back up.

### 6. Test it the way you'll use it

1. Unplug the TV, keyboard and mouse. You won't need them again.
2. Turn the Pi on and wait **2–3 minutes** (a bit longer the first time, while the AI times itself
   and picks its size).
3. On the phone, open **Settings → Wi-Fi**, join **Emergency-Library** with the password. If it
   says *no internet*, tap **Stay connected** / **Keep**.
4. Open the phone's browser and type the address **exactly**: `http://192.168.4.1:8096`.
5. Search for something, open a guide, and ask the AI a question.
6. Press the power button and check that the Pi shuts down (see above).
7. **Now do it all again on the power bank**, the way it'll run in an emergency.

### 7. Print the Wi-Fi card

The setup saved **`PI-WIFI-CARD.html`** at the top of the library drive. It has the Wi-Fi name,
password, address and the four steps for using the Pi. Plug the drive into your regular
computer, open the card and print it (or copy it out by hand). Tape it inside the lid.

---

## 🖐️ Option: a touchscreen on the Pi

A small touchscreen lets you use the library **right on the Pi, with no phone**. Phones can still
join the Pi's Wi-Fi at the same time.

**What to get:** a **7-inch touchscreen made for the Raspberry Pi**, such as the official
Raspberry Pi Touch Display 2, or a kit that comes in a case with a fan. Screens that plug into the
Pi's flat **ribbon-cable display connector** (called DSI) need no extra cables or drivers. A
7-inch screen is about 7½ × 4¾ inches, so it fits a .50 cal can lying flat.

**Setting it up:**
1. Connect the screen before the first start (step 3). You can do the whole setup on it; plug in
   a **USB keyboard** for typing, and you won't need it afterward.
2. In step 4, answer **y** to **Use a touchscreen on this Pi for the library?** It suggests **y**
   by itself when a screen is plugged into the ribbon connector. (Or run the setup with
   `--screen`.)
3. After the restart, the desktop comes up by itself and, **2–3 minutes later**, the library
   opens full-size on the screen.

What changes: the setup **keeps the desktop on** (it normally switches it off) and opens the
library in the web browser at every start. `--undo` removes that too.

**Using it:**
- **Tap the question box** and a keyboard appears at the bottom of the screen. Tap **⏎ Go** to
  ask, **⌄ Hide** to put it away; **⇧ ABC** gives one capital letter.
- The browser's **back arrow** (top left) and tabs work as usual, and the guides have their own
  **← Back**.
- **To turn it off:** tap the **raspberry menu** (top left) → **Shutdown** → **Shutdown**. Wait
  until the green light stays off, then unplug. The power button works too; the screen may ask
  first.
- **Memory:** a 4 GB Pi 4 runs the small "Quick" AI with or without the screen. On an 8 GB Pi the
  screen leaves plenty for the bigger AI.
- **Power:** the screen adds a few watts *(rule of thumb)*. Turn the Pi off when nobody needs it.

---

## 📦 Packing the can

1. **Cut a foam tray** with pockets for the Pi, drive, power bank, phone and cables. **Nothing
   should touch bare metal.** The EMP guidance is to keep items off the can's walls, and loose
   metal can short out the Pi when it's running
   ([CISA, p. 45](lib:emp-protection-and-resilience-guidelines#page=45)).
2. **Leave the drive plugged into the Pi** if it fits. That's one less thing to forget.
3. **Get the lid ready to seal.** The rubber gasket stops metal touching metal, so scrape a strip
   of bare metal at the rim (see the EMP guide's
   [Faraday containers](guide:EMP-GUIDE) section) and keep a roll of **conductive foil tape**
   in the can. Every time you put it away, tape all the way around the closed lid seam
   ([🖼️ why seams matter](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275)).
4. **Charge the power bank and phone to about half to three-quarters.** That's kinder to
   batteries in storage than 100%. Top them up every few months.
5. **Test the seal** with the phone-and-radio test in the [EMP guide](guide:EMP-GUIDE): close and
   tape the can with a phone inside and call it, then a battery AM radio tuned to a station.
   Silence means no big leaks.

![Left: the open ammo can seen from above, with the Pi and its drive, a power bank and a phone in foam pockets, nothing touching the metal. Right: a cut-through view of the closed lid seam, with the rubber gasket at the rim, paint scraped to bare metal, and conductive foil tape over the seam](img:AMMO-CAN-COMPUTER-GUIDE/packing-and-sealing-the-can.svg)
*Pack everything in foam, off the metal; after closing, tape the lid seam over scraped bare metal (a diagram drawn for this guide).*

Store it somewhere cool and dry, not in a hot car or shed.

---

## 🆘 Using it in an emergency

1. **Open the lid** and lift out the tray, or leave it in the open can. Keep it in the shade.
2. **Plug the Pi into power** (power bank, 12-volt adapter or the wall supply). Plug in the library
   drive if it isn't already.
3. **Wait 2–3 minutes.**
4. **On each phone:** join the Pi's Wi-Fi, open the browser, type the address from the card.
5. **To shut down:** press the power button **once**. Wait until the light turns **red** (Pi 5) or
   the **green light stays off** (Pi 4), then unplug. Pack it and **tape the lid** again.

**Is it safe to have it out?** A nuclear EMP is over in seconds to minutes. A solar storm comes
with 18–72 hours' warning. If a warning comes, shut the Pi down and seal the can (see
[when a solar-storm warning comes](guide:EMP-GUIDE)). Use it the rest of the time.

**Save the battery:** turn it off when nobody needs it. Searching and reading use little power;
the AI uses the most.

---

## 🔋 Power: how long it runs

The Pi 5 uses roughly **3–5 watts** while it sits waiting and around **10 watts** while the AI
writes an answer, about the same as charging a phone *(rule of thumb)*. A Pi 4 uses a bit less,
so a battery lasts longer.

| Power source | About how long *(rule of thumb)* |
|---|---|
| 10,000 mAh power bank | 4–6 hours of normal use |
| 20,000 mAh power bank | 8–12 hours |
| 12-volt car or deep-cycle battery (100 Ah) through a USB-C car charger | Several days. Don't run a car battery flat; see the [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE) |
| Small solar panel (20 watts or more) charging a power bank | Several hours of use per sunny day; much less in winter |

**Power bank tips:** use one with a **USB-C output** that can give at least **3 amps** (look for
"PD" or "fast charging" and 15 W or more on the label). A weak bank makes the Pi restart or the
drive disappear. Test it before you need it.

---

## 🛠️ If something goes wrong

| Problem | Try this |
|---|---|
| The Wi-Fi name doesn't show up on the phone | Wait the full 3 minutes. Is the lid open? Unplug the Pi, plug it back in and wait again. Still nothing: plug in the TV and look for error messages |
| Joined the Wi-Fi, but the page won't open | Type the address exactly, including `http://` and `:8096`. Turn on **airplane mode**, then turn **Wi-Fi** back on (some phones use mobile data instead of a Wi-Fi with no internet). Right after power-up, wait another minute |
| The page opens but the AI says it isn't ready | It's still loading. Give it a minute or two. Search and the books work meanwhile |
| The AI is very slow | It picks a size to suit the Pi. On a Pi 4 or a 4 GB Pi it uses the small AI. Searching and reading the books stay fast |
| Works on the wall supply but not on the power bank | The bank is too weak, or (Pi 5) the power-bank question was answered **n**. Plug in the TV and keyboard, log in, and run the setup again with `--battery` (step 4) |
| The Pi keeps restarting | Not enough power. Use the official supply or a stronger power bank |
| The Pi 4 button does nothing | Check it's on the **third pair** of pins from the end farthest from the USB ports. The setup switches those pins on, so run it on this Pi and restart once afterward |
| Forgot the Wi-Fi password | Plug the drive into any computer and open **`PI-WIFI-CARD.html`** |
| The touchscreen shows the desktop but not the library | Wait 5 minutes: the first start is the slowest. Still nothing: tap the raspberry menu → **Internet** → **Chromium** and type `http://127.0.0.1:8095/?touch=1` |
| The touchscreen shows no keyboard | Open the library with `?touch=1` at the end of the address, as above. It remembers after that |
| Want home internet on the Pi again (for updates), or the desktop back | Plug in a network cable for internet. For both, run the setup with `--undo` and restart. Run the setup again afterward; it keeps the same Wi-Fi name and password |

**Running the setup again later** (with the TV and keyboard): log in, then type
`bash /mnt/emergency-library/OfflineLibrary/SETUP-Raspberry-Pi.sh` (or the path to wherever
your library is) and press Enter.

---

## 🔄 Every few months

- **Top up** the power bank and phone to about half to three-quarters.
- **Power it up once** and run through the test in step 6. Then shut down, pack it and re-tape
  the lid.
- **Updating the library:** plug the drive into your regular computer and run the installer
  again (it adds what's new). Nothing needs to change on the Pi.
- Swap the foil tape if it's torn or stops sticking.

---

## 🖼️ Pictures & diagrams

- The Raspberry Pi itself — [Raspberry Pi](wiki:Raspberry_Pi)
- Steel ammunition cans — [Ammunition box](wiki:Ammunition_box)
- How a closed metal box blocks a pulse — [Faraday cage](wiki:Faraday_cage); [Electromagnetic shielding](wiki:Electromagnetic_shielding)
- Why a wire through the box ruins it — [🖼️ MIL-HDBK-419A Vol 2, p. 315](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)
- How fields leak through seams and slots — [🖼️ MIL-HDBK-419A Vol 1, p. 275](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275)
- What 10, 20 and 30 dB of shielding buys — [🖼️ CISA, p. 77](lib:emp-protection-and-resilience-guidelines#page=77)
- Power banks and SSDs — [Power bank](wiki:Battery_pack); [Solid-state drive](wiki:Solid-state_drive)

## 🔗 Related guides

- [EMP, Solar Storms & Faraday Cages](guide:EMP-GUIDE): building and testing the shield
- [Start the Library on Any Device](guide:START-ON-ANY-DEVICE): sharing with phones, and other devices
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE): batteries and solar to keep it running
- [Get the Whole Library](guide:GET-THE-LIBRARY): filling the library drive
- [Emergency Radio Guide](guide:RADIO-GUIDE): another thing worth keeping in a sealed can
