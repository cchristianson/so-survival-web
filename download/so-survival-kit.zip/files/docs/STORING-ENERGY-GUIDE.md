# 🧱 Storing Energy Without Batteries

How to keep the energy from a sunny afternoon, a hot fire, a cold night or a running creek for later,
when batteries are worn out or gone. It covers gravity batteries (lifting water, sand or weights) and
why they hold so little; heat stored in water, stone and masonry; cold stored as ice and cold water;
compressed air and flywheels; and the simplest store of all, doing the work while the power is there.
The numbers come from the books on this drive. Where this guide works one out, it says *(arithmetic)*,
and you can check it with the [Practical Math guide](guide:PRACTICAL-MATH-GUIDE) or the
[Calculator](guide:CALCULATOR). The two DOE books added for this guide are in
`Off-Grid-Power\Energy-Storage`.

> ### The short version
> - **Lifting things stores almost nothing.** 1,000 gallons of water raised 30 ft holds about **94
>   watt-hours**: a light and a phone for one evening *(arithmetic)*. The DOE's example: hoist a car
>   100 ft and you get back "only about 800 watts for ten minutes"
>   ([*Wind Power for Farms*, p. 129](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=129)).
> - **Heat stores about a thousand times more.** The same 1,000 gallons warmed 50 °F holds about
>   **122,000 watt-hours** *(arithmetic)*. Store energy as **heat** (water, stone, masonry) and
>   **cold** (ice, cold water), not as height.
> - **Spare electricity goes into hot water.** An electric water heater stores it at close to 100%;
>   batteries manage 60 to 80% ([*Wind Power for Farms*, p. 130](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=130)).
> - **Pump the water you need anyway** into a high tank while the sun shines. The tank is the battery
>   ([NRCS Tech Note 1, p. 27](lib:design-of-small-solar-powered-water-pump-systems-tech-note-1-nrcs-north-dakota-2017#page=27)).
> - **Insulation decides how long any store lasts:** hot, cold or ice.
> - **Skip compressed air and homemade flywheels.** Compressed air is 10 to 15% efficient, and fast
>   wheels can burst.
> - **A woodpile is a battery too.** One pound of dry wood holds about twice what a 12-volt,
>   100 amp-hour battery holds *(arithmetic)*.

---

## 🧮 How much each way holds: the honest numbers

Lifting stores **weight × height**; warming stores **weight × degrees × how well it holds heat**.
Water takes 1 BTU per pound for each °F; dry soil and rock about 0.2
([*Fire Weather*, p. 12](lib:fire-weather-agriculture-handbook-360-schroeder-and-buck-usfs-1970#page=12));
melting ice soaks up **144 BTU per pound**
([p. 13](lib:fire-weather-agriculture-handbook-360-schroeder-and-buck-usfs-1970#page=13)).
1 kWh (1,000 watt-hours) = 3,412 BTU, and water weighs 8.34 lb a gallon (Practical Math guide).

| Store it as | Example | Holds about | What that runs |
|---|---|---|---|
| **Height** | A 55-gal drum of water raised 20 ft | 3.5 Wh | Less than one phone charge |
| **Height** | 1 ton (2,000 lb) of sand raised 10 ft | 7.5 Wh | A small LED bulb for about an hour |
| **Height** | 1,000 gal of water raised 30 ft | 94 Wh | A light and a phone for an evening |
| **Heat** | A 55-gal drum of water warmed 40 °F | 18,000 BTU = 5.4 kWh | About an hour of house heat in a cold snap |
| **Heat** | 1,000 lb of stone heated to about 200 °F | 40,000 BTU | About 2 hours of house heat |
| **Heat** | 1,000 gal of water warmed 50 °F | 417,000 BTU = 122 kWh | About 20 hours of house heat |
| **Cold** | 1 ton of ice melting | 288,000 BTU = 84 kWh of cooling | 3–4 days of a walk-in farm cooler, which uses about 100 tons a year |
| **Compressed air** | An 80-gal shop tank at 150 psi | 25–45 Wh you can use | A few minutes of an air tool |
| **Spinning** | A 100-lb steel wheel, 2 ft across, at 1,000 rpm | 3 Wh | Not worth the danger |
| **Battery, for comparison** | 12 V × 100 Ah | 1,200 Wh | The same as 1,000 gal raised **380 ft** |
| **Firewood, for comparison** | 1 lb of dry wood | 8,600 BTU = 2.5 kWh | Twice that battery |

*(Arithmetic, except the stone row: [Aprovecho *Capturing Heat Three*, p. 16](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=16).
"House heat" uses Aprovecho's tight house losing about 20,000 BTU an hour, same page; the wood figure is
[p. 18](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=18). The air-tank
row assumes the DOE's 10–15% efficiency, below; the farm-cooler figure is
[USDA FB 475, p. 17](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=17).)*

![The same 1,000 gallons of water: lifted 30 feet it stores about 94 watt-hours, a light and a phone for an evening; warmed 50 degrees it stores about 122,000 watt-hours, about 20 hours of house heat](img:STORING-ENERGY-GUIDE/same-tank-lifted-or-warmed.svg)
*The same water holds about a thousand times more energy as heat than as height (a diagram drawn for this guide).*

**Per cubic foot**, water still holds about twice what concrete or stone does: 62 lb × 1 against
144 lb × 0.2 *(arithmetic)*. Aprovecho puts it as "Per pound water stores 5 times more heat than
rock", and the rock's weight "offsets this difference to some degree"
([p. 9](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=9);
[🖼️ water and sand compared](lib:aviation-weather-ac-00-6b-faa-and-nws-2016#page=32)).

📚 **Go deeper:** [DOE *Wind Power for Farms*, Ch. 5 "Energy Storage", pp. 123–134](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=123) — the library's only overview of every storage method; [*Fire Weather*, pp. 12–14](lib:fire-weather-agriculture-handbook-360-schroeder-and-buck-usfs-1970#page=12) — heat, melting and evaporation explained.

## 💧 Gravity that works: store the water, not the electricity

A tank of water up the hill doesn't store much energy, but it stores something better: **water you
can use with no power at all**. Pump it when the sun shines, the wind blows or the creek runs, and let
gravity deliver it later.

- **The tank is the cheapest battery** for a solar pump: "The most effective and typically least
  expensive means of utilizing excess incoming solar energy is to incorporate a water storage tank"
  ([NRCS Tech Note 1, p. 27](lib:design-of-small-solar-powered-water-pump-systems-tech-note-1-nrcs-north-dakota-2017#page=27)).
  North Dakota's NRCS requires **3 days** of storage on solar systems (same page).
- **Put it high enough.** The tank must sit above every faucet. Each foot of height gives 0.43 psi
  ([USDA FB 1448, p. 27](lib:farmstead-water-supply-farmers-bulletin-1448-usda-1933#page=27)), so a
  tank 40 ft up gives about 17 psi, a weak but usable house pressure (see the
  [Practical Math guide](guide:PRACTICAL-MATH-GUIDE)).
- **Where:** "an underground concrete tank on a hill is very desirable, avoiding trouble with frost";
  attic, loft and trestle tanks are "unsatisfactory". Hold "more than one day's supply", a week or more
  for a windmill, and cover it tightly against heat, cold, dust, vermin and sunlight
  ([FB 1448, p. 35](lib:farmstead-water-supply-farmers-bulletin-1448-usda-1933#page=35);
  [🖼️ underground concrete tank](lib:farmstead-water-supply-farmers-bulletin-1448-usda-1933#page=35)).
- **Steadier power needs less tank.** "The more constant the power, the more reliable the equipment …
  the less is the need of large water storage"
  ([FB 1448, p. 37](lib:farmstead-water-supply-farmers-bulletin-1448-usda-1933#page=37)). A ram pump
  that runs day and night (see the [Water Wells guide](guide:WATER-WELLS-GUIDE)) needs a smaller tank
  than a solar pump that only runs at midday.
- **Pressure tanks hold little.** Only about one-fifth of a pressure tank's size is usable water, and it
  must be "absolutely air-tight"; never use a thin-walled tank
  ([FB 1448, pp. 35–36](lib:farmstead-water-supply-farmers-bulletin-1448-usda-1933#page=36)).

![A solar pump at a well fills a covered tank on the hill while the sun shines; the water runs down to the house by gravity, 40 feet of height giving about 17 psi at the highest faucet](img:STORING-ENERGY-GUIDE/hill-tank-is-the-battery.svg)
*Pump while the sun shines; gravity delivers the water later, 0.43 psi for each foot the tank sits above the faucet (a diagram drawn for this guide).*

**Pumped-storage hydro** (pump water up to a pond, run it back through a turbine later) works for
power companies because their lakes are huge
([*Wind Power for Farms*, p. 127](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=127);
[🖼️ the hill-pond scheme](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=127)).
At home scale: a pond 1 acre across and 1 ft deep (326,000 gallons), 100 ft above the turbine, holds
about **100 kWh** before losses, perhaps 50 kWh back after pumping and turbine losses *(arithmetic)*.
That's a lot of digging and, in Oregon, a water right. Hot water does it with a tank.

## ⚖️ Gravity batteries from sand, rocks or weights

**How it works:** raise a heavy weight with spare power; later let it fall slowly, turning a generator.
The energy is exactly **weight × height**: raising a 550-lb rock one foot takes 550 foot-pounds, and
550 foot-pounds a second is one horsepower (746 watts)
([*Wind Power for Farms*, p. 27](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=27);
foot-pounds × 0.0000003766 = kWh, [NEETS 19, p. 87](lib:neets-module-19-the-technicians-handbook#page=87)).

**Why it disappoints:** a person cranking steadily makes about 50 watts. One hour of cranking
equals lifting 1,000 gallons just **16 ft**, or a ton of sand about 70 ft *(arithmetic)*. The DOE puts it
plainly: a few 55-gallon drums in the attic "would not produce much power"
([p. 127](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=127)). Every winch, gear
and generator also loses some, so expect half back at best *(rule of thumb)*.

**If you build one anyway** (a night light, a teaching model):
1. A weight you can raise by hand or with a winch: a bucket of sand or a bag of rocks, 50–100 lb.
2. A rope over a **drum or pulley** that turns slowly as the weight falls.
3. **Gearing up** a lot, 100 to 1 or more (bicycle sprockets and chain, or belts and pulleys), so the
   slow drop spins a small **permanent-magnet DC motor** fast enough to make power (see "Motors as
   generators" in the [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE)).
4. One **LED** of a watt or less, and a way to slow the fall: the load itself does that.
5. **What to expect:** 50 lb dropping 8 ft holds 0.15 Wh, a 1-watt LED for about 9 minutes with no
   losses, more like 4–5 minutes in practice *(arithmetic)*.

Keep people and animals out from under a raised weight, and check the rope every time *(rule of thumb)*.
Weights are good at slow, steady mechanical jobs, like turning a clock or a spit, not at making
electricity *(rule of thumb)*.

## 🔥 Heat: the store that works

### Getting heat into stone or water

"Just piling mass near a stove will result in poor heat transfer to the mass. Only a small percentage
of the heat will end up in the mass"
([Aprovecho, p. 16](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=16)).
The fire's hot gases have to pass **through** the mass (a masonry heater), through **water** (a water
jacket or tank), or warm the room air directly
([p. 6](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=6)).
And seal the drafts first: a tight house needs far less stored heat (see "One warm room" in the
[Shelter guide](guide:SHELTER-BUILDING-GUIDE)).

### Masonry heaters (big stone stoves)

- **How:** "Masonry heaters use tonnes of mass in the form of bricks or stone"; you burn "one or two
  fires per day", fast and hot, and the masonry "continues to radiate warmth for many hours"
  ([CMHC *Residential Wood Heating*, p. 20](lib:cmhc-a-guide-to-residential-wood-heating-2008#page=20);
  [🖼️ a masonry heater](lib:cmhc-a-guide-to-residential-wood-heating-2008#page=20);
  [Masonry heater](wiki:Masonry_heater)).
- **How much:** 1,000 lb of stone heated to about 200 °F holds 40,000 BTU, about two hours for a house
  losing 20,000 BTU an hour; **five tons** carries about ten hours
  ([Aprovecho, p. 16](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=16)).
  A good one holds about **half a day**
  ([p. 17](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=17)).
- **Good:** stored heat keeps the house warm overnight, the radiant heat feels good, and the big hot
  fire burns clean
  ([p. 7](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=7)).
- **Bad:** it heats whether you need it or not, so a warm day can overheat the room; it must weigh
  many tons; and it can't warm a cold house fast
  ([p. 8](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=8)).
- **Building one:** "The mason must be experienced … simple errors can result in the failure of the
  heater", and clearances to anything that burns must meet fireplace codes
  ([CMHC, p. 39](lib:cmhc-a-guide-to-residential-wood-heating-2008#page=39)). Several tons on a floor is
  also an **earthquake** load: see the quake rules in the [Natural Building guide](guide:NATURAL-BUILDING-GUIDE).
- **Rocket mass heaters and cob benches** are a homemade version. The library has no tested plans
  (Aprovecho only sketches a "Hot Cob" bench, [p. 17](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=17));
  treat them like any stove: a working chimney and a carbon monoxide alarm
  ([Rocket mass heater](wiki:Rocket_mass_heater)).

### Stone and water that warm in the sun

- **Thermal mass evens out the day.** Water in drums or a thick cob wall "tends to stay at the average
  24 hour temperature"; a very thick wall averages several days
  ([Aprovecho, p. 35](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=35)).
- **Passive solar:** south-facing windows let the winter sun warm masonry floors or walls, which give the
  heat back at night
  ([HUD *In the Bank*, p. 73](lib:in-the-bank-or-up-the-chimney-energy-saving-home-improvements-hud-1977#page=73)).
  A **Trombe wall** is a thick masonry wall behind glass on the south side; a **sunspace** is a glassed
  room with a masonry floor or water containers that you close off from the house at night
  ([Trombe wall](wiki:Trombe_wall); [Sunroom](wiki:Sunroom)). Drums of water painted dark, in the sun,
  inside the glass, do the same job *(rule of thumb)*.
- **Rock bins:** an active solar system can blow warm air from a collector through a bin of rocks, which
  "carries enough heat to get through a few overcast days and nights" (HUD, same page). It needs a fan,
  so it needs power.

### Hot water: where spare electricity should go

- **The best way to store surplus power:** "Where batteries are 60 to 80 percent efficient, electric
  heaters approach 100 percent"; the only losses are a poorly insulated tank and the wiring. One kWh
  warms 30 gallons by about 13.5 °F
  ([*Wind Power for Farms*, p. 130](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=130);
  [🖼️ a simple electric heating system](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=131)).
- **How:** a water-heater element as the **dump load** on a hydro or wind controller (see the
  [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) and [Engines](guide:ENGINES-AND-MOTORS-GUIDE) guides), or
  a solar panel wired straight to a DC element. The thermal mass of the water, or of concrete floors and
  brick walls, does the storing (same page).
- **Use an old electric water heater as the tank,** insulated well. A tank that sits still keeps its
  hottest water at the top *(rule of thumb)*.
- **Safety:** a heated, closed tank needs a **pressure-and-temperature relief valve** — boiling water
  makes pressure, and even Aprovecho's carefully built wood-fired showers "occasionally leaked or even
  exploded!" ([Aprovecho, p. 9](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=9)).
  Water at 140 °F burns skin badly in about 5 seconds, at 158 °F in 1
  ([Ciochetti & Metcalf, p. 5](lib:pasteurization-of-naturally-contaminated-water-with-solar-energy-ciochetti-metcalf-1984#page=5)).

### Solar water heaters you can build

**Thermosiphon heater** (no pump): a flat black panel of two seamed metal sheets, with an insulated tank
mounted above it. Hot water rises into the tank and cool water sinks back to the panel. A panel about
3 × 6 ft heated **70 liters (74 quarts) to 140 °F by noon** on a clear summer day. Raise the tank about
18 in off the ground "so that the coolest water will be in the heater", keep the water level above the
tank's upper hose connection so it can circulate, insulate the tank with sawdust, straw or mud, and draw
hot water from the top
([VITA *Village Technology Handbook*, pp. 317–318](lib:village-technology-handbook-vita-usaid#page=317);
[🖼️ the heater on its stand](lib:village-technology-handbook-vita-usaid#page=317)).

![A homemade thermosiphon solar water heater: a flat metal panel on mud bricks, connected by a lower and an upper hose to a 70-liter tank raised at least 45 cm on bricks](img:STORING-ENERGY-GUIDE/thermosiphon-water-heater.png)
*The tank sits above the panel, raised at least 45 cm (18 in), with its water level above the upper hose ([VITA, p. 317](lib:village-technology-handbook-vita-usaid#page=317)).*

**Breadbox (batch) heater:** water tanks sit right inside a glazed, insulated box in the sun.
- **Box:** insulated to **at least R-10** on the sides and bottom, one layer of glazing on top, on a stand
  of pressure-treated lumber set on footings
  ([DOE *Breadbox Solar Water Heaters*, p. 18](lib:breadbox-solar-water-heaters-principles-and-construction-doe-region-iv#page=18)).
- **Tanks:** the cheapest are **old glass-lined electric water heaters** with the outer jacket stripped.
  Don't use galvanized tanks, which rust; test a used tank for leaks with a garden hose. Tilt the tanks
  upright so the hot water collects at the top
  ([pp. 18–19](lib:breadbox-solar-water-heaters-principles-and-construction-doe-region-iv#page=19)).
- **Weight:** about **300 lb per full tank**; a two-tank system weighs about 850 lb, so check a roof
  before putting one on it (p. 19).
- **Plumbing:** inlet, outlet, drain lines and **pressure-and-temperature relief valves**
  ([p. 28](lib:breadbox-solar-water-heaters-principles-and-construction-doe-region-iv#page=28);
  materials list [p. 32](lib:breadbox-solar-water-heaters-principles-and-construction-doe-region-iv#page=32)).
- **Freezing:** "Draining the breadbox is the safest option"
  ([p. 21](lib:breadbox-solar-water-heaters-principles-and-construction-doe-region-iv#page=21)). Our
  valley freezes most winters, so drain it from the first hard frost to spring *(rule of thumb)*.

![Cross-section of a breadbox solar water heater: an old glass-lined water-heater tank inside a box insulated on the sides and bottom, with one layer of glazing facing the sun, cold water in at the low end, hot water out at the high end through a relief valve, and a drain valve](img:STORING-ENERGY-GUIDE/breadbox-water-heater.svg)
*Tilt the tank so hot water collects at its high end; fit a relief valve and a drain (a diagram drawn for this guide).*

### Hot stones and hay-boxes for cooking

A hay-box (fireless cooker) is a heat store for the cooking pot. Measured: a 6-quart kettle of boiling
water in a newspaper-packed box was still **172 °F after 4 hours** and **155 °F after 8**. Fill empty
space with boiling water, which "will take up and hold the heat better than air would"
([USDA FB 771, p. 11](lib:usda-homemade-fireless-cookers-fb771-1919#page=11)). For higher heat, add a hot
**soapstone, brick or stove lid** under the pot in a metal-lined nest, kept away from anything that burns
([pp. 4–6](lib:usda-homemade-fireless-cookers-fb771-1919#page=6)). Heavy pots of clay or iron hold heat
best, and a good cooker holds cooking heat at least 8 hours
([Peace Corps T-17, pp. 123–124](lib:solar-and-energy-conserving-food-technologies-training-manual-peace-corps-t-17-1984#page=123)).
How to build one is in the "Hay-box cooking" section of the
[Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE).

![Cross-section of a fireless cooker: a cooking kettle standing on a hot soapstone plate in a metal-lined nest, packed all round with insulation inside a wooden box, with a pad on top and a hinged lid](img:STORING-ENERGY-GUIDE/hay-box-with-hot-stone.png)
*The kettle (D) sits on a hot soapstone (E) in a metal-lined nest (C), packed all round with insulation (B) ([USDA FB 771, p. 9](lib:usda-homemade-fireless-cookers-fb771-1919#page=9)).*

## ❄️ Cold: storing winter for summer

Melting ice soaks up 144 BTU per pound; that's why a block of ice is such a good "cold battery"
([*Fire Weather*, p. 13](lib:fire-weather-agriculture-handbook-360-schroeder-and-buck-usfs-1970#page=13)).
The springhouse, zeer pot, ice house and cellar details are in the
[Root Cellar guide](guide:ROOT-CELLAR-GUIDE) ("Cooling without power"); here are the storage numbers.

**Ice:**
- **Our valley rarely makes pond ice thick enough to cut** *(rule of thumb)*; even eastern Virginia only
  counts on 4–6 in ([USDA FB 475, p. 5](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=5)).
  Make it in **cans** on the coldest nights instead: galvanized cans 22 in square at the top; tip out the
  1½–2 in shell, refill a few quarts at a time until solid
  ([p. 10](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=10)).
- **How it keeps** depends on "the shape of the mass, its insulation, its drainage, and its solidity"
  ([p. 6](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=6)). Stack it as near
  a **cube** as you can ([p. 5](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=5)).
- **Packing:** on a bed of sawdust or shavings **at least 15 in deep**, and at least **15–18 in** from the
  walls ([p. 13](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=13)).
- **Drain it.** A 50-lb block on slats at 80 °F lasts more than a day; sitting in its own meltwater it is
  gone in six or seven hours
  ([*Household Discoveries*, p. 109](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=109)).
- **How much:** 1 ton of ice takes about 35 cu ft
  ([FB 475, p. 12](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=12)). A
  14 × 20 ft ice house filled eight or ten layers high lasts two or three families a year
  ([*Household Discoveries*, p. 110](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=110)),
  but a walk-in farm refrigerator burns through about **100 tons** a year
  ([FB 475, p. 17](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=17)). Cool a
  small box, not a room.

![Cross-section of stored ice: blocks stacked close to a cube on a sawdust bed at least 15 inches deep, with 15 to 18 inches of rammed sawdust between the ice and the walls, sawdust over the top, and a drained gravel floor](img:STORING-ENERGY-GUIDE/packing-ice-in-sawdust.svg)
*At least 15 in of sawdust under the ice, 15–18 in between the ice and the walls, and a floor that drains (a diagram drawn for this guide).*

**Cold water and insulation:**
- **Water holds the cold:** a 10-gallon can of milk at 85 °F set in 30 gallons of 37 °F water ends at about
  50 °F; with 60 gallons, about 45 °F
  ([USDA FB 976, p. 6](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=6);
  [🖼️ insulated cooling tank](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=7)).
- **Cover and insulate it:** an open metal tank in the sun lost more than ten times as much ice as a
  covered, cork-insulated wooden tank
  ([p. 12](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=12)).
  A **1-inch felt jacket** let cold milk travel 33 times farther before warming to 60 °F
  ([p. 16](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=16)).
- **The hay-box works cold too:** with a little cracked ice, milk "will keep its temperature for 24 hours,
  even in hot weather" ([FB 771, p. 17](lib:usda-homemade-fireless-cookers-fb771-1919#page=17)).

**Night air and night sky:**
- A shaded **draft box** on the north side uses cold night air; in the Willamette Valley's 30s-at-night,
  50s-by-day seasons it averages around 40 °F
  ([Aprovecho, p. 34](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=34)).
- A **buried box** stays at 52–58 °F: cool, but not cold enough to stop bacteria
  ([p. 36](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=36)).
- **Night-sky trays:** shallow trays of water under a clear sky lose about 20 BTU per square foot per hour,
  and froze below about 45 °F; they don't work on cloudy or windy nights
  ([p. 38](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=38)).
- **Don't build a homemade ammonia "Icy Ball" refrigerator:** Aprovecho stopped theirs over "the potential
  for explosion" ([p. 37](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=37)).

## 🌬️ Compressed air and flywheels: why not

**Compressed air:**
- **Most of the energy turns into heat** in the compressor: "When air is compressed, heat is generated"
  ([Navy *Construction Mechanic*, p. 344](lib:navy-construction-mechanic-3-and-2-1978#page=344)). Then the
  air chills and freezes up the tool as it expands
  ([p. 345](lib:navy-construction-mechanic-3-and-2-1978#page=345)).
- **Overall:** "Typical overall efficiency is 10 to 15 percent"
  ([DOE *Compressed Air Sourcebook*, p. 32](lib:improving-compressed-air-system-performance-sourcebook-doe-2016#page=32)),
  and it is "probably the most expensive form of energy" in a shop
  ([p. 29](lib:improving-compressed-air-system-performance-sourcebook-doe-2016#page=29)). An 80-gallon
  tank gives back a few dozen watt-hours (table above).
- **Tanks burst.** A receiver tank must be welded steel with a drain and a **safety valve**
  ([Navy, p. 345](lib:navy-construction-mechanic-3-and-2-1978#page=345)). Never use a rusty, dented or
  homemade tank *(rule of thumb)*.
- **Where air does make sense:** running air tools directly from a compressor driven by a water wheel or
  windmill, not as storage *(rule of thumb)*.

**Flywheels:**
- Energy rises with the **square of the speed**: twice as fast holds four times as much
  ([*Wind Power for Farms*, p. 28](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=28)).
  So a useful flywheel spins very fast, and modern ones need a housing that contains the wheel "should the
  wheel fracture or fail" ([p. 132](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=132);
  [🖼️ old and modern flywheels](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=132)).
- **A wheel spun too fast "may fly apart."** Stand to one side when it starts, and never run a cracked or
  unbalanced wheel ([Navy *Steelworker*, p. 22](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=22)).
- **Good use:** smoothing out a pedal, treadle or water-wheel drive over a few seconds, not storing power
  for later *(rule of thumb)*.

## 🗓️ The best store of all: work while the power is there

Most of what a battery does can be done by **timing the work** *(rule of thumb)*:

- **Sunny midday:** pump water up to the tank, run the grain mill and power tools, heat water, wash
  clothes, charge radios, lights and phones.
- **Rainy months (strongest creek):** the heavy jobs move to hydro power; hot water from the dump load.
- **Hot fire:** cook, heat water and bake in one firing; a masonry heater or hay-box holds the heat.
- **Cold nights:** freeze ice in cans; cool the cellar with night air (see the
  [Root Cellar guide](guide:ROOT-CELLAR-GUIDE)).
- **Store the product, not the power:** a full water tank, ground flour, dried food, split firewood and
  charged rechargeable batteries for small lights are all stored energy.
- **The woodpile** is the biggest store most households have: 8,600 BTU in a pound of dry wood
  ([Aprovecho, p. 18](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=18)).
  See the [Firewood guide](guide:FIREWOOD-GUIDE).

## ⚠️ Myths and dangers

| You may hear | What the books say |
|---|---|
| "A few drums of water in the attic will run the lights all night." | They "would not produce much power" ([DOE, p. 127](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=127)); one drum raised 20 ft is 3.5 Wh *(arithmetic)*. Attic tanks are also "unsatisfactory" for water ([FB 1448, p. 35](lib:farmstead-water-supply-farmers-bulletin-1448-usda-1933#page=35)). |
| "A gravity battery of sand can replace my batteries." | A ton of sand raised 10 ft is 7.5 Wh *(arithmetic)*; a 100 Ah battery is 160 times that. |
| "Pile stones around the stove to store heat." | Little heat gets in unless the hot gases pass through the mass ([Aprovecho, p. 16](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=16)). |
| "Any old tank will do for hot water." | Closed tanks need relief valves; homemade water heaters have exploded ([Aprovecho, p. 9](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=9)). |

## 🖼️ Pictures & diagrams

- Water and sand warming in the sun, compared — [🖼️ FAA *Aviation Weather*, p. 32](lib:aviation-weather-ac-00-6b-faa-and-nws-2016#page=32)
- Pumped storage with a hill pond — [🖼️ DOE *Wind Power*, p. 127](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=127); water-splash heater, [🖼️ p. 129](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=129); wind furnace, [🖼️ p. 131](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=131); flywheels, [🖼️ p. 132](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=132)
- Underground concrete water tank — [🖼️ USDA FB 1448, p. 35](lib:farmstead-water-supply-farmers-bulletin-1448-usda-1933#page=35); cooling room with round tank, [🖼️ p. 37](lib:farmstead-water-supply-farmers-bulletin-1448-usda-1933#page=37)
- Masonry heater — [🖼️ CMHC, p. 20](lib:cmhc-a-guide-to-residential-wood-heating-2008#page=20); [Masonry heater](wiki:Masonry_heater)
- Thermosiphon solar water heater — [🖼️ VITA, p. 317](lib:village-technology-handbook-vita-usaid#page=317); breadbox heater construction, [🖼️ DOE, p. 28](lib:breadbox-solar-water-heaters-principles-and-construction-doe-region-iv#page=28)
- Hay-box cooker in section — [🖼️ USDA FB 771, p. 9](lib:usda-homemade-fireless-cookers-fb771-1919#page=9)
- Ice houses: storing floe ice in a pit, [🖼️ USDA FB 475, p. 10](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=10); ice above, fruit below, [🖼️ p. 14](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=14); farm refrigerator walls, [🖼️ p. 18](lib:ice-houses-harvesting-storing-and-making-ice-usda-fb-475-rev-1918#page=18)
- Ice needed to cool and hold a can of milk — [🖼️ USDA FB 976, p. 11](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=11)
- Ideas, with photos — [Trombe wall](wiki:Trombe_wall); [Thermal mass](wiki:Thermal_mass); [Solar water heating](wiki:Solar_water_heating); [Icehouse (building)](wiki:Icehouse_(building)); [Pumped-storage hydroelectricity](wiki:Pumped-storage_hydroelectricity); [Gravity battery](wiki:Gravity_battery)

## 🔗 Related guides

- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) — solar, batteries, creek hydro and dump loads
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — motors as generators, and reusing a generator for water or wind
- [Water Wells, Pumps, Springs & Cisterns](guide:WATER-WELLS-GUIDE) — ram pumps, tanks and cisterns
- [Root Cellars & Food Storage](guide:ROOT-CELLAR-GUIDE) — springhouses, zeer pots, ice houses
- [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — building a hay-box cooker
- [Firewood](guide:FIREWOOD-GUIDE) and [Shelter & Building](guide:SHELTER-BUILDING-GUIDE) — heat, stoves and one warm room
- [Practical Math](guide:PRACTICAL-MATH-GUIDE) — the arithmetic behind every number here
