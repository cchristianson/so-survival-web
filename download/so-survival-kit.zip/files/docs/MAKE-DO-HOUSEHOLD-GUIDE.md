# 🧰 Make-Do Household Guide

How to make or replace everyday necessities when the store is gone — from basic supplies,
things you can scavenge, and what grows around the Illinois Valley. Each section points to
the detailed manuals in `Homestead-Skills\` (especially `Household-Make-Do\`, `Soap-Candles\`
and `Sanitation-Water\`) and `Electronics-Repair\`. The links open each book on the drive at the
right page.

> ### ⚠️ Rules that prevent the worst accidents
> - **Never mix cleaning chemicals.** Bleach + ammonia (or urine) makes toxic chloramine gas;
>   bleach + vinegar or any acid makes chlorine gas. Use one product, rinse, then the next.
> - **Lye (from ashes or the store) burns skin and blinds.** Gloves and eye protection; flush
>   any splash with plenty of water for at least 20 minutes (longer for an eye that still stings). Never use aluminum pots with lye.
> - **Label every container.** Never store chemicals or fuel in food or drink bottles, and
>   never reuse a container that held chemicals or fuel for food or water.
> - **Never put gasoline in a lamp, stove or heater**, and never burn charcoal, a camp stove
>   or a generator indoors (carbon monoxide).
> - **Never throw water on burning wax or fat** — it spreads the fire. Cut the heat and smother
>   it with a metal lid or damp cloth.

---

## 🧽 Cleaning and disinfecting

- **Most cleaning is just soap, hot water and scrubbing** — it removes most germs along with
  the dirt. Homemade lye soap works fine (see the soap section below).
- **Scouring powder:** baking soda, fine wood ash, or fine sand on a damp rag.
- **Glass and hard-water film:** white vinegar mixed half and half with water (not on
  marble or stone, and never together with bleach).
- **Disinfecting with bleach** (for kitchen surfaces, sickrooms, after flooding): plain
  unscented household bleach, **5 tablespoons (⅓ cup) per gallon of water, or 4 teaspoons
  per quart.** Clean first, leave it wet for at least a minute, and **mix it fresh every
  day** — diluted bleach loses strength. *Drinking water needs a much weaker dose* — use the
  table in `Water\EPA - Emergency Disinfection of Drinking Water` ([p. 2](lib:epa-emergency-disinfection-of-drinking-water-2017#page=2)).
- **No bleach?** Boiling water, scrubbing with soap, and drying things in full sun all kill
  germs.
- **Wash hands with soap** ([🖼️ how-to drawing](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=40); [Hand washing](wiki:Hand_washing)) before handling food or eating, after the toilet, after cleaning up
  a child or caring for a sick person, and after touching animals or garbage. Hand sanitizer
  (at least 60% alcohol) only works on hands that aren't visibly dirty.
  ([OSU *Twin-Bucket Toilet*, p. 4](lib:osu-extension-survival-basics-sanitation-twin-bucket-toilet#page=4))

📚 **Go deeper:** [WHO/WEDC *Technical Notes on Water, Sanitation and Hygiene in Emergencies*](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=43) — chlorine, latrines and hygiene after disasters; [Army FM 21-10 *Field Hygiene and Sanitation*](lib:us-army-fm-21-10-field-hygiene-and-sanitation-2000#page=10) — keeping a group healthy in the field; [EPA *Emergency Disinfection of Drinking Water*, p. 2](lib:epa-emergency-disinfection-of-drinking-water-2017#page=2) — the bleach-drops table.

## 🧼 Soap from fat and ashes

**1. Make lye from ashes.** Use **hardwood** ashes (they make the best lye); ashes of paper, cloth
or garbage won't work ([VITA, p. 342](lib:village-technology-handbook-vita-usaid#page=342)). Fill a
bucket with ashes ([🖼️ VITA's leaching drawing](lib:village-technology-handbook-vita-usaid#page=342); [Lye](wiki:Lye)), pour on boiling water and stir, top up with ashes and water, then let it stand
12–24 hours and carefully pour off the clear liquid
([Practical Action *Soapmaking*, p. 2](lib:practical-action-soap-making-technical-brief#page=2)).

**2. Check the strength.** Lye that floats **a fresh egg or a potato** is right. Too weak? Run it
through fresh ashes again, or boil it down. ([VITA, p. 343](lib:village-technology-handbook-vita-usaid#page=343))

**3. Make soft soap.** Boil **½ cup of ash lye for every cup of clean fat** until it is thick,
rubbery and foamy. Age the brown jelly at least a month before use. ([VITA, p. 344](lib:village-technology-handbook-vita-usaid#page=344))
Ash lye is **[potash](wiki:Potash)**, which only makes **soft** [soap](wiki:Soap); hard bars need store lye (caustic soda), or
boiled soap "salted out" with salt water
([USDA 1940, p. 3](lib:usda-soap-making-and-wood-ash-lye-1940#page=3); [Practical Action, p. 4](lib:practical-action-soap-making-technical-brief#page=4)).

**Hard soap with store lye** (USDA): weigh **2½ lb clean fat**, melt it and let it cool to
lukewarm. Dissolve **5½ oz lye in 11 oz cold water** (lye into water, never water onto lye), pour
it into the fat and stir, heat and stir until smooth, stir in another 5½ oz water, and pour into a
box. Cut into cakes after 24 hours; let them harden a week or more out of the sun.
([USDA 1940, p. 3](lib:usda-soap-making-and-wood-ash-lye-1940#page=3))

- **Clean kitchen grease first:** melt it with about an equal amount of hot water, stir, let it
  cool, and lift the clean fat off the top ([USDA 1940, p. 3](lib:usda-soap-making-and-wood-ash-lye-1940#page=3)).
- **Is it done?** Cool a drop on a plate. Clear = ready. Weak and grey = needs more lye. A grey
  skin that slides on the plate = too much lye — add more fat
  ([Practical Action, p. 3](lib:practical-action-soap-making-technical-brief#page=3)).
- **New ("green") soap is still caustic.** Wear gloves to handle it and let bars cure at least 3
  weeks ([Practical Action, p. 4](lib:practical-action-soap-making-technical-brief#page=4)).
- Keep children away and don't breathe the fumes. Splashes: **water, lots of it** (some old books
  say vinegar — use water).

| Soap problem | Likely cause ([Practical Action, p. 4](lib:practical-action-soap-making-technical-brief#page=4)) |
|---|---|
| Won't thicken | Not enough lye, too much water, too cool, not stirred enough, or too much liquid oil |
| Oily layer on top as it cools | Too much fat or not enough lye |
| Hard and brittle | Too much lye |

📚 **Go deeper:** [Practical Action *Soapmaking*](lib:practical-action-soap-making-technical-brief#page=1) — lye from ashes, soft and hard soap, recipes; [VITA *Village Technology Handbook*, p. 342](lib:village-technology-handbook-vita-usaid#page=342) — leaching lye and soft soap with drawings; [CAWST *Soap Making Fact Sheet*](lib:cawst-soap-making-fact-sheet-2014#page=2) — modern measured recipes; [MSU *Making Soap at Home*](lib:msu-extension-making-soap-at-home-1942) — store-lye bars.

## 👕 Laundry

- **Laundry soap:** grate one bar of soap and mix with 1 cup washing soda (add 1 cup [borax](wiki:Borax)
  if you have it). Use 1–2 tablespoons per load, dissolved in hot water first.
- **Make [washing soda](wiki:Sodium_carbonate) from baking soda:** spread baking soda in a pan and bake at
  **400 °F (200 °C) for about an hour**, stirring now and then, until it turns dull and
  grainy. It's stronger than baking soda — wear gloves.
- **Ash water (old-time "lye wash"):** soak hardwood ashes in water, let it settle, and use
  only the clear liquid for greasy or very dirty clothes. It's caustic — gloves, and never on
  wool or silk.
- **Washing by hand:** soak overnight, agitate with a clean plunger in a bucket (or a
  [washboard](wiki:Washboard_(laundry))), rinse twice, wring hard, and **dry in the sun** — sunlight helps disinfect.

**Stains** ([USDA *Stain Removal from Fabrics*](lib:usda-stain-removal-from-fabrics-fb1474-1942#page=4)):
- **Treat it while fresh**, and try **cold water first** — hot water and soap set many stains.
  Test any remover on a hidden seam. ([pp. 4, 6](lib:usda-stain-removal-from-fabrics-fb1474-1942#page=6))
- **Blood:** soak in cold water until the stain turns light brown, then wash in warm soapy water.
  Strong salt water (about 2 cups salt per gallon) loosens old stains. Never hot water.
  ([p. 15](lib:usda-stain-removal-from-fabrics-fb1474-1942#page=15))
- **Grease:** rub in cornstarch, chalk or talc, let it soak up the grease, brush off
  ([p. 8](lib:usda-stain-removal-from-fabrics-fb1474-1942#page=8)).
- **Chlorine bleach destroys wool and silk**, and rots cotton if left on more than a minute or two
  ([p. 5](lib:usda-stain-removal-from-fabrics-fb1474-1942#page=5)). Skip the bulletin's gasoline and
  carbon tetrachloride — fire and poison hazards.

📚 **Go deeper:** [USDA *Stain Removal from Fabrics*, p. 4](lib:usda-stain-removal-from-fabrics-fb1474-1942#page=4) — an A-to-Z of stains; [*Household Discoveries* (1909)](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=178) — washing, soap and laundry methods.

## 🪥 Personal care

- **Teeth:** *how* you brush matters more than the paste. Brush twice a day with water, a
  little **baking soda**, or **salt** (or a 50-50 mix of the two). No brush? Chew the end of a fresh
  green twig until it frays into bristles ([chew stick](wiki:Miswak)), or wrap rough towel around a finger. Use thread as
  floss. ([*Where There Is No Doctor*, ch. 17, p. 2](lib:where-there-is-no-doctor-17-the-teeth-gums-and-mouth#page=2);
  `Medical\Manuals-PDF\Where There Is No Dentist`, [p. 63](lib:where-there-is-no-dentist#page=63))
- **Deodorant:** wash daily; dust on **baking soda or cornstarch** (baking soda can irritate
  some skin).
- **Salve:** melt **1 part [beeswax](wiki:Beeswax) with 4 parts oil or clean tallow** (by weight) over low
  heat and pour into small tins. **Lip balm** is firmer: about 1 part wax to 2 parts oil.
- **Hair:** wash with soap, then rinse with a cup of water with a spoonful of vinegar in it to
  remove soap film.

📚 **Go deeper:** [*Where There Is No Dentist*, p. 63](lib:where-there-is-no-dentist#page=63) — gum care and keeping teeth without a dentist; [*Where There Is No Doctor*, ch. 17](lib:where-there-is-no-doctor-17-the-teeth-gums-and-mouth#page=1) — teeth, gums and mouth.

## 🩲 Menstrual pads and diapers

- **Reusable pads** ([photos](wiki:Cloth_menstrual_pad)): several layers of absorbent cotton (old flannel or towel) sewn or folded
  into a pad, held in underwear. Rinse in **cold** water first, wash with soap, and **dry in
  the sun**. See *Where Women Have No Doctor* (`Medical\`). Change pads several times a day; a
  homemade tampon must be changed **at least 3 times a day** or it can cause a serious infection
  ([*Where Women Have No Doctor*, ch. 5, p. 4](lib:where-women-have-no-doctor-05-health-concerns-of-girls#page=4)).
- **A pad that buttons on:** a sleeve of heavy cotton about 4½ × 9½ inches with two button wings,
  plus removable folded towel liners about 6 × 8 inches. Wash and add bleach if you have it; dry in
  the sun, **never under the bed** — damp pads mold and cause itching.
  ([WASHplus pattern](lib:making-reusable-menstrual-pads-washplus-2015#page=1) — [🖼️ step-by-step drawings](lib:making-reusable-menstrual-pads-washplus-2015#page=1))
- **[Cloth diapers](wiki:Cloth_diaper):** absorbent cotton folded in layers, with a wool or plastic cover. Rinse,
  soak in a lidded bucket, wash hot with soap, dry in the sun.

📚 **Go deeper:** [WASHplus *Making Reusable Menstrual Pads*](lib:making-reusable-menstrual-pads-washplus-2015#page=1) — sewing pattern with drawings; [*Where Women Have No Doctor*, ch. 5](lib:where-women-have-no-doctor-05-health-concerns-of-girls#page=4) — periods and staying clean.

## 🧻 Toilet paper alternatives

More detail (water washing, washing cloth wipes safely, which plants to avoid) is in
[Paper, Ink & Toilet Paper](guide:PAPER-INK-GUIDE).

- **Water:** a squeeze bottle of water, then wash your hands with soap — the cleanest option.
- **"Family cloth":** cotton squares, used once, kept in a lidded bucket and washed hot,
  separately from other laundry.
- **Leaves:** big soft **[thimbleberry](wiki:Rubus_parviflorus)** leaves (common along roads and
  forest edges here in summer) or first-year **[mullein](wiki:Verbascum_thapsus)** leaves.
- ⚠️ **Learn [poison oak](wiki:Toxicodendron_diversilobum) first — it's everywhere in the Illinois
  Valley.** Leaves in **threes**, lobed like small oak leaves, shiny or dull, red in fall. The
  **bare stems in winter still cause the rash.** ([🖼️ drawing](lib:fm-3-05-70-survival-2002#page=514)) It grows as a shrub or a climbing vine, and the
  roots and stems carry the oil too ([OSU EM 9184, p. 24](lib:osu-em-9184-keeping-your-home-and-property-safe-from-wildfire#page=24)).
  Also avoid [stinging nettle](wiki:Urtica_dioica).

📚 **Go deeper:** [OSU EM 9184, p. 24](lib:osu-em-9184-keeping-your-home-and-property-safe-from-wildfire#page=24) — poison oak photos and control; [FM 3-05.70 *Survival*, p. 514](lib:fm-3-05-70-survival-2002#page=514) — poison oak and other plants to avoid.

## 🚽 Toilets when the water is off

- **Don't flush** if the sewer lines might be broken, even if your pipes look fine. A septic
  system can keep working if nothing leaks or backs up.
  ([OSU *Twin-Bucket Toilet*, pp. 4–5](lib:osu-extension-survival-basics-sanitation-twin-bucket-toilet#page=5))
- **Twin-bucket toilet** ([Bucket toilet](wiki:Bucket_toilet)): two 5-gallon buckets marked **"pee"** and **"poo"**. The poo bucket is
  lined with a heavy (3 mil or thicker) black bag; after each use, cover it with about ½ cup of
  sawdust, wood shavings, shredded paper or peat. **Keeping urine out** of the poo bucket is what
  stops the smell. ([OSU, pp. 2–3](lib:osu-extension-survival-basics-sanitation-twin-bucket-toilet#page=3))
- **Emptying:** dilute urine with wash water and pour it on the ground, a different spot each time.
  Fill the poo bucket no more than half, then double-bag it with gloves on and store it sealed, away
  from food and water. In the country you can bury it — **never within 100 feet of a well, spring
  or creek.** ([OSU, p. 3](lib:osu-extension-survival-basics-sanitation-twin-bucket-toilet#page=3))
- **Hand-washing station:** a jug of clean water with a spigot, a catch bucket, and soap in the toe
  of a sock tied to the jug — one by the toilet, one by the kitchen
  ([OSU, p. 3](lib:osu-extension-survival-basics-sanitation-twin-bucket-toilet#page=3)).
- **Trench latrine** ([🖼️ drawing](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=53); [Pit latrine](wiki:Pit_latrine)) for longer outages: about 1 foot wide, 5 feet deep and 13 feet long, well away
  from and downhill of any well or creek. Cover each use with soil; fill it in when the contents are 1 foot from the top
  ([WHO/WEDC, p. 56](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=56)).
  Hot ashes tipped into a pit cut smell and flies
  ([Practical Action *VIP Latrine*, p. 2](lib:practical-action-ventilated-improved-pit-latrine-technical-brief#page=2)).

📚 **Go deeper:** [OSU *Survival Basics: Sanitation*](lib:osu-extension-survival-basics-sanitation-twin-bucket-toilet#page=2) — twin-bucket setup and supply list; [WHO/WEDC *Technical Notes*, p. 55](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=55) — trench, family and borehole latrines; [Practical Action *Compost Toilets*](lib:practical-action-compost-toilets-technical-brief#page=1) — longer-term options; [EPA *Composting Toilets*](lib:epa-composting-toilets-fact-sheet) — how they work.

## 🔥 Fire and light without stores

For candles, wicks, lamp oils and homemade lamps in detail, see
[Light Without the Grid](guide:LIGHTING-GUIDE).

- **Fire starters:** cotton balls rubbed with petroleum jelly; **[fatwood](wiki:Fatwood)** (resin-soaked
  heartwood from old pine or fir stumps — smells like turpentine and lights even when damp);
  dry bark and pine pitch.
- **[Char cloth](wiki:Char_cloth)** (catches a spark): put squares of **100% cotton** cloth in a metal tin with a
  small nail hole in the lid, set it in a fire until smoke stops coming out, then let it cool
  **before** opening.
- **No matches:** a [ferro rod](wiki:Ferrocerium) or flint-and-steel onto char cloth ([🖼️ drawing](lib:afh-10-644#page=229)) (steel struck on flint, quartz
  or pyrite throws sparks); a magnifying glass in sun ([🖼️ drawing](lib:fm-3-05-70-survival-2002#page=111)); touching a 9-volt battery (or two AAs)
  to fine steel wool ([🖼️ drawing](lib:afh-10-644#page=230)); or a **[bow drill](wiki:Bow_drill)** ([🖼️ drawing](lib:fm-3-05-70-survival-2002#page=114)) — drill about ⅝ in thick and a foot long, of dry
  **cedar, fir, cottonwood or basswood**, on a board of the same wood with a notch cut to the
  center of the pit; tinder of dry grass with shredded cedar bark (Seton's *Book of
  Woodcraft*, [pp. 192–194](lib:seton-the-book-of-woodcraft-1913#page=214), and the Army survival manuals —
  [FM 21-76, ch. 7](lib:fm-21-76-army-survival-manual#page=86)).
- **[Oil lamp](wiki:Oil_lamp):** a glass jar or tin, a wick of twisted cotton string or a cotton strip held up
  by a bent wire or a tin-lid holder, and any **vegetable oil or melted fat**. Keep the flame
  small. **Never gasoline.** Tallow candles: `Soap-Candles\`.
- **Dipped [candles](wiki:Candle):** dip wicks in melted [tallow](wiki:Tallow), cool, dip again until thick enough
  ([🖼️ hand-dipping drawing](lib:practical-action-candlemaking-technical-brief#page=5))
  ([*Household Discoveries*, p. 98](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=98)).
  **2 parts beeswax to 1 part tallow** is firmer than plain tallow
  ([p. 99](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=99)).
  Melt wax in a pot set in hot water, not over the flame ([Practical Action *Candlemaking*, p. 3](lib:practical-action-candlemaking-technical-brief#page=3)).
- **[Rushlights](wiki:Rushlight):** peel rushes and dip the pith in tallow like a candle
  ([*Household Discoveries*, p. 99](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=99)).

**How much light you get** (lumens, roughly — [Practical Action *Rural Lighting*, p. 3](lib:practical-action-rural-lighting-technical-brief#page=3)):
candle **1** · wick oil lamp **1–10** · hurricane lantern **10–100** · mantle lamp **~1,000** ·
a 1-watt white LED **25–50** in that old table — a modern 1-watt LED gives about 80–150
([Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE)).

📚 **Go deeper:** [FM 21-76 *Army Survival Manual*, ch. 7](lib:fm-21-76-army-survival-manual#page=78) — tinder, fire lays and fire without matches; [Seton *Book of Woodcraft*, p. 192](lib:seton-the-book-of-woodcraft-1913#page=214) — the classic bow-drill method; [Practical Action *Candlemaking*](lib:practical-action-candlemaking-technical-brief#page=1) — dipping, pouring and molding; [Practical Action *Rural Lighting*](lib:practical-action-rural-lighting-technical-brief#page=3) — lamps, LEDs and batteries compared.

## 🪵 Glue, patching and waterproofing

- **Pine pitch glue:** gently melt pine [resin](wiki:Resin) ([🖼️ pine drawing](lib:fm-3-05-70-survival-2002#page=455)) (it's flammable — heat beside the fire, not
  in it), stir in **powdered charcoal (about 1 part to 3–4 parts resin)** plus a pinch of fine
  plant fiber, and use while warm. Sets hard — for hafting tools, patching containers and
  seams. Plain heated resin works as glue too ([FM 3-05.70, p. 455](lib:fm-3-05-70-survival-2002#page=455)).
- **Flour paste:** cook flour and water to a thick paste — for paper and labels.
- **Casein (milk) glue** — skim-milk curd mixed with slaked lime and two other chemicals — makes
  wood joints as strong as the wood — water-resistant but not waterproof. Full recipe:
  [VITA, p. 313](lib:village-technology-handbook-vita-usaid#page=313).
- **Waterproof cloth or leather:** rub in beeswax, tallow or a beeswax–oil mix, then warm it
  so it soaks in.
- **Waterproof boots** (USDA): melt together **1 lb petroleum jelly + 2 oz beeswax**, or **12 oz
  tallow + 4 oz cod oil**. Apply warm (never hotter than your hand can bear), working it into the
  welt and sole edge, where shoes leak most.
  ([USDA *Care of Leather*, pp. 12–13](lib:usda-the-care-of-leather-fb1183-1920#page=12))

📚 **Go deeper:** [Henley's *Twentieth Century Formulas* (1916)](lib:henleys-twentieth-century-formulas-recipes-and-processes-1916#page=38) — hundreds of glues, pastes and cements; [VITA *Village Technology Handbook*, p. 313](lib:village-technology-handbook-vita-usaid#page=313) — casein glue; [USDA *Care of Leather*, p. 10](lib:usda-the-care-of-leather-fb1183-1920#page=10) — oiling and waterproofing shoes and harness.

## 👟 Clothing and footwear

- **Mending:** [running stitch](wiki:Straight_stitch) for seams ([🖼️ drawing](lib:general-fabric-repair#page=75)), [backstitch](wiki:Backstitch) where it must be strong
  ([🖼️ drawing](lib:general-fabric-repair#page=76)), whipstitch for edges ([🖼️ drawing](lib:general-fabric-repair#page=22)), and **[darning](wiki:Darning)** for holes (weave thread
  back and forth across the hole, then across the other way — [🖼️ drawing](lib:dillmont-encyclopedia-of-needlework-1890#page=24)). Patch from the **inside** for strength. Needles from stiff wire; thread from
  unraveled fabric, dental floss or fishing line.
- **Mend early** — a few stitches on a weak seam or loose button save a big patch later.
  **Shrink new patch cloth first** and cut it on the straight of the weave. Darn with yarn raveled from a
  seam allowance, and don't pull it tight (it puckers). ([USDA *ABCs of Mending*, pp. 4–8](lib:usda-abcs-of-mending-fb1925-1943#page=7))
- **Sandals from old tires:** trace your foot on tire tread, cut with a very sharp knife
  wetted with soapy water (steel belts make it slow — choose worn tread with no wire
  showing), sand the edges, and tie on with straps cut from an inner tube or with cord through
  slots.
- **Shoe care:** work grease in well where the sole meets the upper, and let shoes dry somewhere
  warm, **not hot**. Re-sole **before** the
  welt and insole wear through — after that they're rarely worth fixing.
  ([USDA *Care of Leather*, pp. 10–11](lib:usda-the-care-of-leather-fb1183-1920#page=10))
- **Stay warm:** wool keeps you warm even when wet; **wet cotton pulls heat away** — avoid it
  in cold rain.

📚 **Go deeper:** [USDA *ABCs of Mending*](lib:usda-abcs-of-mending-fb1925-1943#page=4) — patches, darns and tears for every fabric; [Bower *Practical Shoe Repairing*](lib:practical-shoe-repairing-bower-1923) — soles, heels and stitching; [Leland *Manual of Mending and Repairing*](lib:leland-a-manual-of-mending-and-repairing-1896) — fixing almost anything in the house; [USDA *Knitwear Make-Overs*](lib:usda-knitwear-make-overs-mp575-1945) — reusing worn sweaters.

## 🔧 Simple plumbing

- **Dripping [faucet](wiki:Tap_(valve)):** shut the water off first, then replace the washer ([🖼️ cut-away drawing](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=5)). A temporary washer
  can be cut from **leather (cold taps)** or **rubber (hot taps)**. If the washer screw is stuck,
  put on a drop of kerosene and tap it; if the head splits, deepen the slot with a hacksaw.
  ([USDA *Simple Plumbing Repairs*, pp. 4–5](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=5))
- **Toilet tank keeps running:** usually a leaky, waterlogged float or a worn flapper/ball ([🖼️ ball cock drawing](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=9); [Ballcock](wiki:Ballcock)). A tank
  should empty in about 10 seconds. ([pp. 9–11](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=9))
- **Clogged drain:** put a little water in the sink and plunge hard; if that fails, open the [trap](wiki:Trap_(plumbing)) under the
  sink ([🖼️ drawing](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=12)) and dig out the grease and hair with a bent wire
  ([p. 12](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=12)).
- **When you shut off the water** for repairs, open the highest faucet so a vacuum can't suck
  dirty water back into the pipes from a tub or toilet ([p. 12](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=12)).
- **Frozen pipe:** open the faucet and thaw **from the faucet end back toward the supply** —
  never from the middle, where trapped water can burst the pipe ([🖼️ drawing](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=14)). Thaw drains from the low end
  upward. (USDA *Simple Plumbing Repairs*, [p. 14](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=14).)

📚 **Go deeper:** [USDA *Simple Plumbing Repairs in the Home*](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=4) — faucets, valves, tanks, clogs and thawing, with drawings; [Oregon DEQ *Reusing Graywater*](lib:oregon-deq-reusing-graywater-in-your-landscape#page=1) — using wash water on the garden.

## 🔌 Electronics: repair and salvage

Manuals are in `Electronics-Repair\` (and device-by-device guides in the **iFixit** archive in
Kiwix). Start with the Navy safety manual and the Kuphaldt multimeter and soldering guides. To protect
spare radios and parts from an EMP or solar storm, see the [EMP Guide](guide:EMP-GUIDE).

**Which book for what**

| You want to… | Read |
|---|---|
| Learn electricity from zero | [NEETS 1 *Matter, Energy and DC*](lib:neets-module-01-matter-energy-and-direct-current), then [Kuphaldt *Lessons in Electric Circuits* vol. 1](lib:lessons-in-electric-circuits-vol-1-dc-kuphaldt) |
| Stay alive around it | [Navy *Electronics Technician* vol. 1 *Safety*, p. 31](lib:navy-electronics-technician-vol-1-safety#page=31) |
| Fix power supplies, diodes, transistors | [NEETS 7 *Solid-State Devices and Power Supplies*](lib:neets-module-07-solid-state-devices-and-power-supplies#page=203) |
| Use a meter | [Kuphaldt *Multimeters*](lib:multimeters-how-to-measure-voltage-current-resistance-kuphaldt), [NEETS 16 *Test Equipment*](lib:neets-module-16-test-equipment) |
| Find a fault logically | [Kuphaldt *Troubleshooting Strategy*, p. 26](lib:electrical-troubleshooting-strategy-kuphaldt#page=26), [NEETS 21 *Test Methods*](lib:neets-module-21-test-methods-and-practices) |
| Solder | [Kuphaldt *Soldering and Desoldering*, p. 24](lib:soldering-and-desoldering-tutorial-kuphaldt#page=24), [NASA *Hand Soldering Workbook*](lib:nasa-hand-soldering-student-workbook) |
| Antennas and radio repair | [Army FM 24-18, p. 55](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=55), [NEETS 10 *Antennas*](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas) |

**Safety first**
- **Unplugged isn't safe.** Capacitors hold a charge after unplugging. Discharge them with an
  insulated tool or shorting probe ([🖼️ drawing](lib:neets-module-16-test-equipment#page=31)) across the terminals and to the metal chassis, and recheck.
  ([NEETS 16, p. 31](lib:neets-module-16-test-equipment#page=31); [NEETS 21, p. 33](lib:neets-module-21-test-methods-and-practices#page=33))
- **Microwave ovens can kill**: the capacitor holds about **2,000 volts**. Short it out before
  touching anything inside, never run the oven with the cover off, and don't break the
  magnetron's ceramic parts (toxic). Old **tube TVs and monitors (CRTs)** hold high voltage and
  can implode — leave them alone unless you know how.
- **Household 120 V can kill** — especially with wet hands. Work with one hand when anything
  might be live. With a typical body resistance of about 1,500 ohms, 120 V pushes about **80 milliamps** through the body — more than
  enough to stop a heart; wet skin lets far more through. Take off rings and watches first.
  ([Navy ET *Safety*, pp. 32–34](lib:navy-electronics-technician-vol-1-safety#page=32))
- **If someone is being shocked,** don't touch them. Cut the power, or push them free with a dry
  rope, belt or wooden stick, then start CPR if needed ([p. 33](lib:navy-electronics-technician-vol-1-safety#page=33)).
- **[Lithium batteries](wiki:Lithium-ion_battery)** (laptops, phones, tools): throw out any that are **swollen, dented, hot,
  or below about 2.5 volts**. Charge only with a proper lithium charger, on a non-flammable
  surface, never unattended. Heat, overcharging and age can set off a fire that spreads fast
  with toxic fumes — get out ([Lithium battery FAQ, pp. 2–3](lib:home-lithium-ion-battery-fire-safety-faq#page=2)).

**Finding the fault** — check the simple things first: power cord and plug, fuse, switch,
batteries and their contacts, loose wires. Then measure voltages, then test parts. Test a part
in the circuit before you desolder it. **Bulging or leaking capacitors** ([photos](wiki:Capacitor_plague)) are the most common
failure in power supplies and chargers.
- **Look before you plug in** — about 2 minutes finds most visible faults: loose or corroded
  connections, stray solder or wire bits (shake it and listen), charred resistors, and a white
  crust at an [electrolytic capacitor](wiki:Electrolytic_capacitor)'s seal ([🖼️ how one is built](lib:neets-module-02-alternating-current-and-transformers#page=99)). A discolored or leaking transformer means a short somewhere.
  If anything smokes or sizzles when powered, **pull the plug** at once.
  ([NEETS 6, pp. 210–211](lib:neets-module-06-electronic-emission-tubes-and-power-supplies#page=210))
- The simplest explanation that fits all the symptoms is usually right
  ([Kuphaldt, p. 37](lib:electrical-troubleshooting-strategy-kuphaldt#page=37)).

**[Multimeter](wiki:Multimeter) quick tests** (touch the probes together first — the meter should
read near zero ohms — [Kuphaldt *Multimeters*, p. 30](lib:multimeters-how-to-measure-voltage-current-resistance-kuphaldt#page=30))
- **Continuity** (beep): fuses, switches, cords, broken wires.
- **[Diode](wiki:Diode)** ([🖼️ test drawing](lib:navy-construction-mechanic-3-and-2-1978#page=188)): conducts one way only — about 0.5–0.7 V on the diode setting forward, nothing
  backward. Both ways = shorted; neither = open. On an ohmmeter, a power rectifier should read at
  least 10 times higher backward than forward ([NEETS 7, pp. 56–57](lib:neets-module-07-solid-state-devices-and-power-supplies#page=56)).
- **Transistor** ([🖼️ ohmmeter test](lib:neets-module-07-solid-state-devices-and-power-supplies#page=110)): test it like two diodes back to back (base-emitter, base-collector), and check
  collector-emitter reads high both ways. Avoid the lowest ohms range (R×1), which can damage small
  transistors. ([NEETS 7, p. 111](lib:neets-module-07-solid-state-devices-and-power-supplies#page=111))
- **Capacitor** (discharged first): on the ohms setting a good one shows a brief "kick" then
  rising resistance; no kick = open, steady low reading = shorted.
  ([NEETS 6, p. 171](lib:neets-module-06-electronic-emission-tubes-and-power-supplies#page=171))

**[Resistor color code](wiki:Electronic_color_code)** ([🖼️ chart](lib:neets-module-01-matter-energy-and-direct-current#page=55)): black 0, brown 1, red 2, orange 3, yellow 4, green 5, blue 6,
violet 7, gray 8, white 9. Bands 1–2 are digits, band 3 is the number of zeros, the last band
is tolerance (gold 5%, silver 10%). Example: yellow–violet–orange–gold = 47,000 Ω ±5%.
([Kuphaldt vol. 5, pp. 26–27](lib:lessons-in-electric-circuits-vol-5-reference-and-color-codes-kuphaldt#page=26))

**[Soldering](wiki:Soldering):** use **rosin-core** solder (never acid-core plumbing solder); a 25-watt iron for
circuit boards. Make the wires hold mechanically first, **heat the joint, not the solder**, and
don't move it while it cools ([🖼️ a good joint](lib:navy-2m-miniature-microminiature-electronics-repair-manual-2023#page=198); [🖼️ a joint moved while cooling](lib:navy-2m-miniature-microminiature-electronics-repair-manual-2023#page=203)). Remove old solder with copper wick or a solder sucker.
- Put the iron's tip on the **bigger piece of metal** (the pad or lug), not the thin wire; a little
  fresh solder on the tip helps the heat flow. ([Kuphaldt *Soldering*, pp. 24–26](lib:soldering-and-desoldering-tutorial-kuphaldt#page=24))
- 63/37 tin-lead solder is best for electronics; zinc-chloride (acid) fluxes corrode circuit boards
  ([NEETS 14, p. 80](lib:neets-module-14-introduction-to-microelectronics#page=80); [Navy 2M, p. 195](lib:navy-2m-miniature-microminiature-electronics-repair-manual-2023#page=195)).

**Batteries** ([Practical Action *Batteries*](lib:practical-action-batteries-technical-brief#page=3)):
- Run dry cells in a radio until it quits, then **finish them in a flashlight**. Don't mix old and
  new cells ([pp. 3–4](lib:practical-action-batteries-technical-brief#page=3)).
- A **car battery** is ruined after only about 20 deep discharges. Any lead-acid battery lasts far
  longer if you only use about half its charge before recharging.
  ([p. 5](lib:practical-action-batteries-technical-brief#page=5); [*Rural Lighting*, p. 5](lib:practical-action-rural-lighting-technical-brief#page=5))
- Top up vented lead-acid batteries with **distilled water or clean rainwater** — never acid
  ([*Rural Lighting*, p. 5](lib:practical-action-rural-lighting-technical-brief#page=5)).

**What to salvage** before throwing anything out:
- **Radios and clock radios:** power transformers, cords, switches, knobs, speakers.
- **Computer power supplies:** 12 V and 5 V power, fans, heat sinks, wire, connectors.
- **Printers and scanners:** small motors, gears, rods, belts, switches.
- **Microwaves** (after discharging!): fan and turntable motors, door switches, fuses, magnets.
- **Cars:** batteries, alternators (12 V charging), lights, wire, fuses, relays — see Army
  TM 9-8000 in `Manuals\ArmyFieldManuals` ([charging systems, p. 304](lib:tm-9-8000-principles-of-automotive-vehicles#page=304)).
- Also: LEDs, magnet wire from motors and transformers, fuses, batteries, cords.
- Motor **run** capacitors can be reused; motor **start** capacitors can burst if used
  continuously.
- **Insulators** for antennas: plastic or glass is best (spoons, buttons, bottle necks), then dry
  wood, then rope. A broken wire antenna: clean, twist and solder the ends.
  ([FM 24-18, p. 55](lib:army-fm-24-18-radio-techniques-field-repair-and-expedient-antennas-1987#page=55))

**[Crystal radio](wiki:Crystal_radio) — no batteries needed** (NBS Circular 120, 1922): a long wire antenna (about
75 ft, on insulators), a ground wire to a **water pipe (never gas)** or a rod in damp soil, a
tuning coil wound on an oatmeal box, a crystal detector (the 1922 plans use a galena crystal; a
**germanium diode** salvaged from an old radio does the same job and is easier *(rule of thumb)*), and
a high-impedance earphone. It picks up AM stations with no power at all ([🖼️ wiring diagram](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922#page=12)).
The 1922 plans put the antenna at least 30 feet up with a **lightning switch** to ground it when not
in use, and drive the ground rod 3–6 feet into moist soil.
([NBS 120, pp. 5–11](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922#page=5))

📚 **Go deeper:** [Navy *Electronics Technician* vol. 1 *Safety*, p. 31](lib:navy-electronics-technician-vol-1-safety#page=31) — shock, measuring live circuits, shorting probes; [NEETS 7, p. 203](lib:neets-module-07-solid-state-devices-and-power-supplies#page=203) — how power supplies work and fail; [Kuphaldt *Troubleshooting Strategy*, p. 26](lib:electrical-troubleshooting-strategy-kuphaldt#page=26) — a method for finding any fault; [NBS Circular 120](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922#page=5) — build a crystal set.

## 🍲 Hay-box cooking (saves fuel)

Bring the pot to a **full boil**, then nest it tightly in hay, wool, newspaper or blankets in
a box with a padded lid; it keeps cooking for hours on its own heat. Bring food back to a
boil before eating if it has cooled below hot (food is safest kept above 140 °F).

- **Building one** ([*Haybox*](wiki:Haybox); [🖼️ cut-away drawing](lib:usda-homemade-fireless-cookers-fb771-1919#page=8)): a wooden box, old trunk or bucket with **at least 4
  inches of packing** all round the pot, below it and in a thick cushion on top. **Crumpled newspaper**,
  packed hard, is the best cheap packing. Use a pot with straight sides and a tight lid, sized to
  the food — a big half-empty pot cools fast. ([USDA FB 771, pp. 6–9](lib:usda-homemade-fireless-cookers-fb771-1919#page=7))
  (The 1919 bulletin suggests asbestos — never use it.)
- **Times:** boil beans or meat **20–25 minutes** first, then 2–2½ hours in the box; soft foods need
  only a few minutes' boil and about 25 minutes in the box. It cuts fuel use by about 40%.
  ([Practical Action *Fireless Cookers*, pp. 2, 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5))
- **Meat and beans are the riskiest** — don't leave them in the box too long, and reboil before
  eating ([p. 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5)).
- A **hot stone or brick** under the pot cooks hotter, but then the nest must be **metal-lined** so it
  can't scorch the packing ([FB 771, p. 6](lib:usda-homemade-fireless-cookers-fb771-1919#page=6)).

📚 **Go deeper:** [USDA FB 771 *Homemade Fireless Cookers*](lib:usda-homemade-fireless-cookers-fb771-1919#page=5) — building plans and recipes; [Practical Action *Fireless Cookers*](lib:practical-action-fireless-cookers-haybox-technical-brief#page=3) — a basket cooker from scraps; [Aprovecho *Capturing Heat*](lib:aprovecho-capturing-heat-five-earth-friendly-cooking-technologies) — haybox, rocket stove and solar cooker plans.

## 🫙 Containers and storage

- **Food-grade buckets** (recycling number 1 or 2 on the bottom, from bakeries and
  restaurants), glass jars and metal cans with lids. Wash with soap, then rinse with the bleach solution above.
  **Never** store food in trash bags, paint cans or chemical drums. Containers of 20–30 lb are
  easy to lift and get used up before bugs move in.
  ([USU *Food Storage in the Home*, pp. 11–12](lib:food-storage-in-the-home-grain-insect-control-usu#page=11))
- **Keep mice out:** metal cans or glass; hang sacks from wire. Set [snap traps](wiki:Mousetrap) along walls.
  Seal cracks, keep food off the floor, and keep the store room between freezing and 70 °F —
  cooler keeps longer ([USU, p. 9](lib:food-storage-in-the-home-grain-insect-control-usu#page=9)).
- **[Clay-pot cooler](wiki:Pot-in-pot_refrigerator) (zeer):** a small clay pot inside a bigger
  one with wet coarse sand between, and a wet cloth on top ([🖼️ how it works](lib:practical-action-clay-pot-cooler-zeer-pot-technical-brief#page=2)). Evaporation keeps vegetables cool — it
  works best in **hot, dry weather**, which suits our summers. Keep it in shade with a breeze and wet
  the sand three times a day. ([Practical Action *Clay Pot Cooler*, pp. 1, 6](lib:practical-action-clay-pot-cooler-zeer-pot-technical-brief#page=6))

📚 **Go deeper:** [USU *Food Storage in the Home*](lib:food-storage-in-the-home-grain-insect-control-usu#page=9) — containers, storage rooms and shelf life; [Practical Action *Clay Pot Cooler*](lib:practical-action-clay-pot-cooler-zeer-pot-technical-brief#page=1) — making and using a zeer pot; [WSU *Root Cellars*](lib:wsu-storing-vegetables-and-fruits-at-home-root-cellars-eb1326e) — storing vegetables and fruit without power.

## 💧 Clean water from plastic bottles (SODIS)

Fill **clear plastic (PET) bottles of 2 liters or less** with clear water, lay them on a
roof or shiny surface in **full sun for 6 hours** ([🖼️ drawing](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=21); [SODIS](wiki:Solar_water_disinfection)) (two full days if it's more than half
cloudy). Doesn't work with cloudy water — let it settle or filter it first. Details:
`Sanitation-Water\` and `Water\`.
- **Clear enough?** Stand the full, open bottle on a page of large print (letters about ½ inch
  high) and look down through it. If you can read it, the water is clear enough.
- **Fill ¾, shake 20 seconds, then top up** — the air helps kill germs. Lay bottles **flat**, on
  metal roofing if you have it. Drink straight from the bottle so it isn't re-contaminated.
- **Not** green or brown bottles; replace scratched, cloudy ones (about yearly). SODIS does
  **nothing** for chemical pollution. ([Eawag *SODIS Manual*, pp. 26, 86–87](lib:sodis-solar-water-disinfection-manual-eawag-2002#page=86))
- In long rainy spells, **boil** or use stored or rainwater instead
  ([p. 27](lib:sodis-solar-water-disinfection-manual-eawag-2002#page=27)).

📚 **Go deeper:** [Eawag *SODIS Manual*, p. 26](lib:sodis-solar-water-disinfection-manual-eawag-2002#page=26) — step by step, with a question-and-answer section from p. 85; [OSU *Survival Basics: Water*, p. 3](lib:osu-survival-basics-water-em-9285#page=3) — boiling and bleach; [CAWST *Biosand Filter Manual*](lib:cawst-biosand-filter-construction-manual-2012) — build a filter for cloudy water.

## 🐜 Pests

- **Roaches and ants** ([🖼️ common roaches](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=301); [German cockroach](wiki:German_cockroach)): powdered **borax mixed with sugar or flour**, dusted into cracks
  (roaches), or a sponge soaked in borax-and-sugar syrup in their trail (ants). Keep borax away
  from children and pets.
- **Mosquitoes:** screens, [netting over beds](wiki:Mosquito_net) ([🖼️ drawing](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=85)), and smoke; homemade repellents are weak. Cover
  water barrels and screen their vents so they don't breed there
  ([Practical Action *Household Water Treatment*, p. 2](lib:practical-action-household-water-treatment-systems-technical-brief#page=2)).
- **Lice** ([🖼️ drawing](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=266); [head louse](wiki:Head_louse), [body louse](wiki:Body_louse)): comb wet hair with a fine-tooth (nit) comb
  ([🖼️ drawing](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=271)) every day for two weeks; wash bedding
  hot. Body lice live in clothing seams — wash clothes and bedding at least weekly
  ([FM 21-10, p. 96](lib:us-army-fm-21-10-field-hygiene-and-sanitation-2000#page=96)).
- **Ticks** ([🖼️ western blacklegged tick photo](lib:tickborne-diseases-of-the-united-states-reference-manual-6th-ed-cdc-2022#page=4); [Ixodes pacificus](wiki:Ixodes_pacificus)): check every evening, especially after brush; pull straight out with tweezers.
  Grip close to the skin and pull with gentle, steady force without crushing it, and
  protect your fingers with cloth or gloves ([FM 21-10, p. 98](lib:us-army-fm-21-10-field-hygiene-and-sanitation-2000#page=98)).

📚 **Go deeper:** [Army FM 21-10 *Field Hygiene and Sanitation*, p. 96](lib:us-army-fm-21-10-field-hygiene-and-sanitation-2000#page=96) — lice, ticks, mites and other pests; [USU *Food Storage in the Home*, p. 13](lib:food-storage-in-the-home-grain-insect-control-usu#page=13) — pantry pests.

---

*For hundreds more recipes — cleaners, polishes, glues, inks, waterproofing, pest control and
home remedies — see the classic formula books in `Homestead-Skills\Household-Make-Do\`. They
are old: use their **methods**, but follow the modern safety rules above, and **skip any recipe
using** mercury (bichloride), arsenic, cyanide, lead, benzene, carbon tetrachloride or carbolic
acid, or any "remedy" taken by mouth that contains kerosene — those are poisons. The safe
staples in the same books are soap, washing soda, borax, vinegar and absorbent powders.*

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Cleaning, soap and personal care**
- Washing hands properly — [🖼️ WHO/WEDC, p. 40](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=40); [Hand washing](wiki:Hand_washing)
- Leaching lye from ashes — [🖼️ VITA, p. 342](lib:village-technology-handbook-vita-usaid#page=342); [Lye](wiki:Lye); [Potash](wiki:Potash)
- Washboard and washing soda — [Washboard](wiki:Washboard_(laundry)); [Sodium carbonate](wiki:Sodium_carbonate)
- Chew-stick toothbrush — [Miswak](wiki:Miswak)
- Button-on cloth pad, step by step — [🖼️ WASHplus pattern](lib:making-reusable-menstrual-pads-washplus-2015#page=1); [Cloth menstrual pad](wiki:Cloth_menstrual_pad); [Cloth diaper](wiki:Cloth_diaper)

**Plants to know, toilets and latrines**
- Poison oak — [🖼️ OSU EM 9184 photos, p. 24](lib:osu-em-9184-keeping-your-home-and-property-safe-from-wildfire#page=24); [🖼️ FM 3-05.70, p. 514](lib:fm-3-05-70-survival-2002#page=514); [Western poison oak](wiki:Toxicodendron_diversilobum)
- Mullein and thimbleberry (soft leaves) — [🖼️ mullein, AFH 10-644 p. 91](lib:afh-10-644#page=91); [Mullein](wiki:Verbascum_thapsus); [Thimbleberry](wiki:Rubus_parviflorus)
- Bucket toilet — [Bucket toilet](wiki:Bucket_toilet); [Composting toilet](wiki:Composting_toilet)
- Trench latrines — [🖼️ simple trench, WHO/WEDC p. 53](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=53); [🖼️ deep trench, p. 57](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=57); [Pit latrine](wiki:Pit_latrine)
- How a vented pit latrine beats smell and flies — [🖼️ WHO *Vector Control*, p. 163](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=163)

**Fire and light**
- Fire lays — [🖼️ FM 3-05.70, p. 110](lib:fm-3-05-70-survival-2002#page=110); [🖼️ AFH 10-644, p. 237](lib:afh-10-644#page=237)
- Bow drill — [🖼️ FM 3-05.70, p. 114](lib:fm-3-05-70-survival-2002#page=114); [🖼️ AFH 10-644, p. 234](lib:afh-10-644#page=234); [Bow drill](wiki:Bow_drill)
- Flint and steel, battery and steel wool, lens — [🖼️ AFH 10-644, p. 229](lib:afh-10-644#page=229); [🖼️ p. 230](lib:afh-10-644#page=230); [🖼️ FM 3-05.70, p. 111](lib:fm-3-05-70-survival-2002#page=111); [Ferrocerium](wiki:Ferrocerium)
- Fatwood and char cloth — [Fatwood](wiki:Fatwood); [Char cloth](wiki:Char_cloth)
- Dipping candles and wicks — [🖼️ Practical Action, p. 5](lib:practical-action-candlemaking-technical-brief#page=5); [🖼️ wicks, p. 2](lib:practical-action-candlemaking-technical-brief#page=2); [Candle](wiki:Candle)
- Oil lamps and rushlights — [Oil lamp](wiki:Oil_lamp); [Rushlight](wiki:Rushlight)
- Pine, for pitch glue — [🖼️ FM 3-05.70, p. 455](lib:fm-3-05-70-survival-2002#page=455); [Resin](wiki:Resin)

**Mending and plumbing**
- Hand stitches: running stitch, backstitch, whipstitch — [🖼️ TM 4-42.21, p. 75](lib:general-fabric-repair#page=75); [🖼️ p. 76](lib:general-fabric-repair#page=76); [🖼️ p. 22](lib:general-fabric-repair#page=22); [Backstitch](wiki:Backstitch)
- Darns and patches — [🖼️ TM 4-42.21, pp. 40–44](lib:general-fabric-repair#page=40); [🖼️ Dillmont, p. 24](lib:dillmont-encyclopedia-of-needlework-1890#page=24); [Darning](wiki:Darning)
- Faucet washer, toilet ball cock, sink trap, thawing a pipe — [🖼️ USDA FB 1460, p. 5](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=5); [🖼️ p. 9](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=9); [🖼️ p. 12](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=12); [🖼️ p. 14](lib:usda-simple-plumbing-repairs-in-the-home-fb1460-1948#page=14); [Ballcock](wiki:Ballcock)

**Electronics**
- Safety shorting probe — [🖼️ NEETS 21, p. 33](lib:neets-module-21-test-methods-and-practices#page=33); [🖼️ NEETS 16, p. 31](lib:neets-module-16-test-equipment#page=31)
- Multimeters — [🖼️ NEETS 21, p. 17](lib:neets-module-21-test-methods-and-practices#page=17); [Multimeter](wiki:Multimeter)
- Testing diodes and transistors — [🖼️ NEETS 7, p. 56](lib:neets-module-07-solid-state-devices-and-power-supplies#page=56); [🖼️ p. 111](lib:neets-module-07-solid-state-devices-and-power-supplies#page=111); [Transistor](wiki:Transistor)
- Electrolytic capacitors, and what bulging ones look like — [🖼️ NEETS 2, p. 99](lib:neets-module-02-alternating-current-and-transformers#page=99); [Capacitor plague](wiki:Capacitor_plague)
- Resistor color bands — [🖼️ NEETS 1, p. 55](lib:neets-module-01-matter-energy-and-direct-current#page=55); [Electronic color code](wiki:Electronic_color_code)
- Good and bad solder joints — [🖼️ Navy 2M, p. 198](lib:navy-2m-miniature-microminiature-electronics-repair-manual-2023#page=198); [🖼️ pp. 202–204](lib:navy-2m-miniature-microminiature-electronics-repair-manual-2023#page=202); [Soldering](wiki:Soldering)
- Crystal radio — [🖼️ NBS Circular 120, p. 12](lib:nbs-circular-120-simple-homemade-radio-receiving-outfit-1922#page=12); [Crystal radio](wiki:Crystal_radio)

**Cooking, storage, water and pests**
- Hay-box (fireless) cooker — [🖼️ USDA FB 771, pp. 8–9](lib:usda-homemade-fireless-cookers-fb771-1919#page=8); [🖼️ Practical Action, p. 2](lib:practical-action-fireless-cookers-haybox-technical-brief#page=2); [Haybox](wiki:Haybox)
- Clay-pot cooler — [🖼️ Practical Action, p. 2](lib:practical-action-clay-pot-cooler-zeer-pot-technical-brief#page=2); [🖼️ p. 5](lib:practical-action-clay-pot-cooler-zeer-pot-technical-brief#page=5); [Pot-in-pot refrigerator](wiki:Pot-in-pot_refrigerator)
- SODIS bottles in the sun — [🖼️ WHO/WEDC, p. 21](lib:who-wedc-technical-notes-on-water-sanitation-and-hygiene-in-emergencies#page=21); [Solar water disinfection](wiki:Solar_water_disinfection)
- Lice and the nit comb — [🖼️ WHO *Vector Control*, p. 266](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=266); [🖼️ p. 271](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=271); [Head louse](wiki:Head_louse)
- Ticks — [🖼️ CDC tick ID, p. 4](lib:tickborne-diseases-of-the-united-states-reference-manual-6th-ed-cdc-2022#page=4); [🖼️ WHO *Vector Control*, p. 278](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=278); [Ixodes pacificus](wiki:Ixodes_pacificus)
- Cockroaches and bed nets — [🖼️ WHO *Vector Control*, p. 301](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=301); [🖼️ p. 85](lib:vector-control-methods-for-use-by-individuals-and-communities-who-rozendaal-1997#page=85); [Mosquito net](wiki:Mosquito_net)

## 🔗 Related guides

- [Light Without the Grid](guide:LIGHTING-GUIDE) — candles, wicks, lamp oils and lamps in detail
- [Paper, Ink & Toilet Paper](guide:PAPER-INK-GUIDE) — making paper and ink, and toilet paper alternatives
- [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — flour, masa, sourdough, lard, syrup and storing food.
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — water, sanitation, carbon monoxide and local hazards.
- [Radio Guide](guide:RADIO-GUIDE) — receivers, antennas and staying informed without power.
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — salvaged motors, alternators and generator safety.
- [EMP Guide](guide:EMP-GUIDE) — shielding electronics from EMP and solar storms (Faraday cages).
- [Medical — Read Me First](guide:Medical-READ-ME-FIRST) — where the doctor, dentist and women's health books are.
