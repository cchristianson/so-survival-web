# 🪵 Firewood: Cutting, Splitting, Seasoning & Burning

How to keep a household warm and cooking with wood: which local trees give the most heat, how much
you'll need, felling and bucking safely, splitting, drying wood in our wet winters, burning it cleanly,
keeping the chimney from catching fire, handling ashes in fire country, and growing your own firewood
from oak, madrone and tanoak stumps. The manuals are in `Firewood\` (`Cutting-Felling`,
`Splitting-Seasoning`, `Burning-Stoves-Chimneys`, `Woodlot`); saws, axes and sharpening are in
`Engines-Motors\Chainsaws-and-Saws` and the [Blacksmithing guide](guide:BLACKSMITHING-GUIDE).

> ### ⚠️ Rules that prevent the worst injuries and fires
> - **Felling kills more woodcutters than anything else.** Leave **snags and dead trees** to someone
>   experienced, never cut alone, and keep everyone **two tree-lengths away**
>   ([WorkSafeBC Part 1, p. 13](lib:bc-faller-training-standard-part-1#page=13)).
> - **Plan your escape before you cut**, about 45° back and away from where the tree will fall
>   ([🖼️ drawing](lib:an-ax-to-grind#page=47)).
> - **Never use an axe as a wedge** or to drive one; wear eye protection when striking steel wedges
>   ([U. of Minnesota, p. 12](lib:heating-the-home-with-wood#page=12)).
> - **Ashes start wildfires.** Lidded metal can, on bare ground, well away from the house, for days.
> - **Carbon monoxide and chimney fires** — a [CO alarm](wiki:Carbon_monoxide_detector) near the bedrooms, and a clean chimney.

---

## 🔥 Which wood, and how much

**All dry wood gives about the same heat per pound** (~9,000 BTU) — so **heavier (denser) wood gives more
heat per cord** ([PNW-GTR-810, p. 9](lib:fuelwood-characteristics#page=9)).

| Local tree | Heat per cord (million BTU, dry) | How it burns |
|---|---|---|
| [Oregon white oak](wiki:Quercus_garryana) | **~30** | Hard to light, long-lasting coals — best overnight wood |
| [Pacific madrone](wiki:Arbutus_menziesii) | **~30** | Same; dries slowly and checks |
| [Tanoak](wiki:Notholithocarpus) | ~24–27 *(estimated from density)* | Excellent coals |
| [California black oak](wiki:Quercus_kelloggii) | ~22–24 *(estimated)* | Good coals |
| [Douglas-fir](wiki:Douglas_fir) | ~21–24 | Easy to light, hot, some sparks |
| [Bigleaf maple](wiki:Acer_macrophyllum) | ~20–24 *(estimated)* | Good all-round |
| [Red alder](wiki:Alnus_rubra) | ~17–18 | Fast, clean; spring and fall fires |
| [Ponderosa pine](wiki:Pinus_ponderosa) / [sugar pine](wiki:Pinus_lambertiana) | ~15–22 | Lights easily, burns fast, poor coals |
| [Incense cedar](wiki:Calocedrus_decurrens) | ~15–17 *(estimated)* | **Kindling** — lights instantly, sparks a lot |

(Oak, madrone, fir, alder and pine from [OSU EC1628, p. 4](lib:home-heating-fuels-firewood-vs-pellets#page=4)
and [PNW-GTR-810](lib:fuelwood-characteristics); burn traits from [U. of Minnesota, p. 14](lib:heating-the-home-with-wood#page=14).)

**Use the right wood for the job:** cedar and pine for kindling and quick spring or fall fires; oak, madrone
and tanoak for cold nights and overnight burns *(rule of thumb)*. [Creosote](wiki:Creosote) comes mostly from **wet wood and
smoldering fires**, more than from the kind of tree ([E-1388, p. 2](lib:the-creosote-problem#page=2)).

**How much:**
- **A [cord](wiki:Cord_(unit))** is a stack 4 ft × 4 ft × 8 ft (128 cubic ft) ([🖼️ drawing](lib:heating-the-home-with-wood#page=3)). A **face cord** is 4 ft high by 8 ft long with
  shorter pieces — three face cords of 16-inch wood make one full cord
  ([CMHC, pp. 62, 64](lib:guide-to-residential-wood-heating#page=62)). A cord of green wood weighs roughly
  5,000 lb ([Cornell](lib:estimating-the-volume-of-firewood)).
- **A whole house heated only by wood: 2–4 cords a winter; a stove that helps out: 1–2 cords**
  ([CMHC, p. 64](lib:guide-to-residential-wood-heating#page=64)). Add a cord or two if you also cook with
  wood, and keep **a year ahead** so next winter's wood is drying now *(rule of thumb)*.
- **Trees per cord** (trunk width at chest height): 10-inch ≈ 0.15 cord; 14-inch ≈ ⅓ cord; **22-inch ≈ 1
  cord** ([Cornell, p. 1](lib:estimating-the-volume-of-firewood#page=1)).

📚 **Go deeper:** [PNW-GTR-810 *Fuelwood Characteristics*](lib:fuelwood-characteristics) — tables for every Northwest tree; [CMHC *Guide to Residential Wood Heating*](lib:guide-to-residential-wood-heating); [OSU EC1628](lib:home-heating-fuels-firewood-vs-pellets). Pictures: [Firewood](wiki:Firewood), [Pacific madrone](wiki:Arbutus_menziesii), [Oregon white oak](wiki:Quercus_garryana).

## 🌲 Felling trees safely

([OSU EC 1124 *Safe and Effective Use of Chain Saws*](lib:safe-and-effective-use-of-chain-saws), written for
Oregon woodland owners; [USFS sawyer course](lib:chain-saw-and-crosscut-saw-training-course))

1. **Size it up.** Don't fell in gusty wind, fog, snow or ice. Check the lean from two sides (a weight on a
   string works), look up for **dead limbs ("widow-makers")** and vines tying it to other trees, and bore in
   once to check for rot ([🖼️ drawing](lib:safe-and-effective-use-of-chain-saws#page=4)). Alder and maple often have rotten hearts ([EC 1124, pp. 3–4](lib:safe-and-effective-use-of-chain-saws#page=3)).
2. **Dead trees and [snags](wiki:Snag_(ecology)) are a different job.** They can fail across a circle **1–1½ times their height**,
   farther downhill ([USFS FS-1273, p. 36](lib:tree-risk-assessments#page=36)). Tanoak killed by **[Sudden Oak
   Death](wiki:Phytophthora_ramorum)** rots fast and can snap before it's fully dead — treat it as very high risk, and **don't move
   infected tanoak wood** to new areas ([FS-1273, p. 181](lib:tree-risk-assessments#page=181)).
3. **Clear an escape path** about 45° back and away from the fall direction, and clear brush around the trunk
   ([EC 1124, p. 5](lib:safe-and-effective-use-of-chain-saws#page=5)).
4. **Notch (undercut)** on the side it will fall, about **one-third of the way through** the trunk. The two
   cuts must **meet exactly** — if they don't, the trunk can split up and kick back ("barber chair"). An
   open-face notch (about 90°) is the most controlled ([EC 1124, pp. 6–7](lib:safe-and-effective-use-of-chain-saws#page=6);
   [🖼️ the three notches](lib:safe-and-effective-use-of-chain-saws#page=7)).
5. **Back cut** from the other side, level and **about 1 inch higher than the floor of the notch**. Stop to
   leave a **hinge** of uncut wood 1–1½ in thick — the hinge steers the tree. **Wedge the back cut early**.
   When it goes, set the saw down and **walk out your escape path** ([EC 1124, pp. 7–8](lib:safe-and-effective-use-of-chain-saws#page=7);
   [🖼️ back cut and hinge](lib:safe-and-effective-use-of-chain-saws#page=8)).
6. **Hung up in another tree?** Don't cut the tree it's leaning on and don't work under it — see the
   professional fallers' methods for hang-ups and leaners ([WorkSafeBC Part 2](lib:bc-faller-training-standard-part-2)).

**With hand tools:** a sharp [crosscut saw](wiki:Crosscut_saw) and axe still fell and buck trees when fuel runs out — the USFS
[*Crosscut Saw Manual*](lib:crosscut-saw-manual), [*Saws That Sing*](lib:saws-that-sing) ([🖼️ how the teeth cut](lib:saws-that-sing#page=14)) and
[*An Ax to Grind*](lib:an-ax-to-grind) ([🖼️ felling with an axe](lib:an-ax-to-grind#page=46)) cover it, and the [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE)
covers chainsaw care.

📚 **Go deeper:** [OSU EC 1124](lib:safe-and-effective-use-of-chain-saws) — the whole felling sequence with drawings; [WorkSafeBC Faller Standard Part 1](lib:bc-faller-training-standard-part-1); [USFS hazard-tree guide](lib:tree-risk-assessments) — reading snags and rot. Pictures: [🖼️ how far a snag can reach, FS-1273 p. 36](lib:tree-risk-assessments#page=36), [🖼️ felling factors, U. of Minnesota p. 9](lib:heating-the-home-with-wood#page=9), [Tree felling](wiki:Felling).

## 🪚 Bucking and limbing

- **Stand uphill** of the log. **Cut the side that's being squeezed (compression) first** with a shallow cut,
  then finish from the side that's being stretched (tension) — this keeps the saw from pinching
  ([EC 1124, pp. 8–9](lib:safe-and-effective-use-of-chain-saws#page=8); [🖼️ uphill stance](lib:safe-and-effective-use-of-chain-saws#page=9)).
- **Log supported at both ends** (it sags in the middle): cut down from the top first, then up from below.
  **Supported at one end:** cut up from below first ([U. of Minnesota, p. 11](lib:heating-the-home-with-wood#page=11)).
- **Bent-over saplings ("springpoles") whip when cut.** Stand to the side and shave the inside of the bend
  with shallow cuts ([EC 1124, p. 10](lib:safe-and-effective-use-of-chain-saws#page=10)).
- **Cut length to fit your stove** — usually 16 in, a little shorter than the firebox.
- **Fire season:** saws start fires. Cut early in the morning, keep the **spark arrester** in place, carry a
  shovel and extinguisher, and stay a while after you stop *(rule of thumb)*.

📚 **Go deeper:** [WorkSafeBC Part 2 — binds and safe bucking](lib:bc-faller-training-standard-part-2); [U. of Minnesota — bucking without pinching, p. 11](lib:heating-the-home-with-wood#page=11). Pictures: [🖼️ chainsaw kickback, EC 1124 p. 11](lib:safe-and-effective-use-of-chain-saws#page=11), [🖼️ limbing with an axe, *An Ax to Grind* p. 48](lib:an-ax-to-grind#page=48), [🖼️ bucking with an axe, p. 50](lib:an-ax-to-grind#page=50), [Chainsaw](wiki:Chainsaw).

## 🪓 Splitting

([UW-Extension *Harvesting Firewood*, pp. 15–16](lib:harvesting-firewood-from-your-woods#page=15);
[U. of Minnesota, pp. 11–12](lib:heating-the-home-with-wood#page=11))

- **Tools:** a **6–8 lb [splitting maul](wiki:Splitting_maul)** handles nearly everything; two steel **wedges** and a sledge for tough
  rounds. Keep wedge heads ground smooth — mushroomed steel throws chips.
- **Set up:** a big round as a chopping block, at a height where the maul handle is **level** when it hits. An old
  tire bolted on top holds pieces upright.
- **Technique:** swing with your legs and body, all the way through — half swings stick the maul. **Aim for
  existing cracks**, put knots at the bottom, and **work slabs off the edges** of big rounds before trying the
  middle ([🖼️ safe and unsafe splitting](lib:an-ax-to-grind#page=51)).
- **Size:** split everything to **6 inches or less** so it dries — rounds of 6–10 in at least in half, 10–14 in
  at least in quarters.
- **Safety:** goggles, boots and shin protection; bystanders 20 ft away.
- **Easiest when:** green wood splits easier than dry for most species; frozen wood splits easier still
  *(rule of thumb)*.

📚 **Go deeper:** [UW-Extension *Harvesting Firewood from Your Woods*](lib:harvesting-firewood-from-your-woods); [*An Ax to Grind* — axes and mauls](lib:an-ax-to-grind). Pictures: [🖼️ twist the axe as it bites, *An Ax to Grind* p. 52](lib:an-ax-to-grind#page=52), [Axe](wiki:Axe), [Wedge](wiki:Wedge).

## ☀️ Seasoning: drying wood in a wet climate

**Wet wood wastes heat** — a ton of wood at 60% moisture gives about 5.6 million BTU; dried to 20% it gives
about **10.7 million** ([U. of Minnesota, p. 14](lib:heating-the-home-with-wood#page=14)). It also makes
creosote and smoke.

- **How long:** softwoods about **6 months**, hardwoods about **12** ([EPA *Wet Wood is a Waste*, p. 2](lib:wet-wood-is-a-waste#page=2));
  big oak and madrone pieces up to 2 years ([CMHC, p. 61](lib:guide-to-residential-wood-heating#page=61)).
  **In western Oregon: cut and split by spring, stack through a dry summer, cover before the rains — two
  summers is better** ([OSU EC1628, p. 2](lib:home-heating-fuels-firewood-vs-pellets#page=2)).
- **Cut early.** Wood split in August is only half dry by November, and **wood that isn't dry by November won't
  dry outdoors over the winter** — move it under cover ([USFS 1943 test](lib:summer-seasoned-fuelwood)).
- **Stacking:** single rows, **off the ground** on rails or pallets (4–6 in), bark side up, in **sun and wind**
  ([🖼️ stacked piles](lib:heating-the-home-with-wood#page=13)).
  **Cover only the top** — side tarps trap moisture. Wood dried inside a closed shed takes nearly twice as long as
  wood in sun and wind ([UW-Extension, pp. 16–18](lib:harvesting-firewood-from-your-woods#page=16);
  [EPA, p. 2](lib:wet-wood-is-a-waste#page=2)).
- **Keep the woodpile at least 30 ft from the house** so it can't carry a wildfire to the walls
  ([UW-Extension, p. 17](lib:harvesting-firewood-from-your-woods#page=17)).
- **Is it dry?** Cracks in the ends, faded gray color, a **hollow knock** when two pieces are struck together,
  lighter weight, no hissing in the fire — or a **[moisture meter](wiki:Moisture_meter) reading 20% or less on a freshly split face**
  ([CMHC, p. 61](lib:guide-to-residential-wood-heating#page=61); [EPA, p. 2](lib:wet-wood-is-a-waste#page=2)).
- **Woodsheds and racks:** plans for a 1-cord shed and cheap pallet or block racks
  ([EPA shed plans](lib:build-a-firewood-storage-shed); [EPA 4 simple racks](lib:4-easy-to-build-structures);
  [🖼️ rack drawings](lib:4-easy-to-build-structures#page=1); [🖼️ shed drawing](lib:build-a-firewood-storage-shed#page=3)).

📚 **Go deeper:** [EPA *Wet Wood is a Waste*](lib:wet-wood-is-a-waste); [UW-Extension — stacking and drying](lib:harvesting-firewood-from-your-woods#page=16); [CMHC — drying tests, p. 61](lib:guide-to-residential-wood-heating#page=61). Pictures: [Wood drying](wiki:Wood_drying).

## 🏠 Burning safely: stoves, chimneys, ashes

**Burn hot and dry.** Smoldering fires and wet wood coat the chimney with creosote, which condenses below about
250 °F and turns to sticky tar below 150 °F ([E-1388, p. 2](lib:the-creosote-problem#page=2)). Flaky, dry
creosote means you're burning well; black, shiny tar means you're not
([CMHC, p. 46](lib:guide-to-residential-wood-heating#page=46)).

**Chimney cleaning:** at least **once a year**; some say every 3 cords. After cleaning, check after 2 weeks, 1 month
and 2 months to learn how fast yours builds up, and check the stovepipe every 2–3 months
([E-1388, pp. 3, 5](lib:the-creosote-problem#page=3)). A stiff brush on rods or a rope ([🖼️ chimney brushes](lib:the-creosote-problem#page=4)), from the top down, with
the stove sealed below *(rule of thumb)*.

**[Chimney fire](wiki:Chimney_fire)** — roaring sound, shaking pipes, sparks out the top ([E-1388, p. 3](lib:the-creosote-problem#page=3)):
1. **Close every air inlet and the damper** to starve it.
2. **Get everyone out**; have someone watch the roof for sparks and check the attic.
3. A **dry-chemical (ABC) [extinguisher](wiki:Fire_extinguisher) or baking soda thrown into the firebox** can knock it down.
4. Chimney fires reach 2,000–3,000 °F — **inspect the chimney before using it again**; metal chimneys can be
   ruined after 2–3 fires.

**Clearances:** follow the stove's label. For an unlabeled stove: **36–48 in** from anything that burns, 18 in for
stovepipe, and a non-combustible floor pad reaching 18 in in front ([CMHC, p. 31](lib:guide-to-residential-wood-heating#page=31);
[U. of Minnesota, p. 24](lib:heating-the-home-with-wood#page=24); [🖼️ clearances and a wall shield](lib:guide-to-residential-wood-heating#page=32)). Keep wood, furniture and drying clothes 3 ft away
([USFA card](lib:fireplace-and-wood-stove-safety-card)).

**Ashes in fire country** ([Crystal Lakes fire district](lib:fireplace-and-ash-disposal-safety);
[USFA](lib:fireplace-and-wood-stove-safety-card)):
- Leave ashes in the stove **4+ days** if you can; then into a **metal can with a tight metal lid**, set on dirt or
  concrete **at least 10 ft** from anything that burns, for **at least a week** — or soak and stir them with water.
- **Never** a plastic bucket, cardboard box, or the garden in fire season. Buried "dead" coals have started wildfires.
- **Cold, wet [wood ash](wiki:Wood_ash)** is useful: lye for [soap](guide:MAKE-DO-HOUSEHOLD-GUIDE), nixtamal for
  [corn](guide:FOOD-FROM-SCRATCH-GUIDE), and potash for the garden.

**Carbon monoxide:** [smoke](wiki:Smoke_detector) and [CO alarms](wiki:Carbon_monoxide_detector) near bedrooms; both wear out after about 10 years
([Crystal Lakes, p. 2](lib:fireplace-and-ash-disposal-safety#page=2)).

📚 **Go deeper:** [E-1388 *The Creosote Problem*](lib:the-creosote-problem); [CMHC — stoves, chimneys and clearances](lib:guide-to-residential-wood-heating); [Aprovecho *Capturing Heat* — homemade stoves](lib:capturing-heat-three); [Arkansas *Basics of Heating with Firewood*](lib:basics-of-heating-with-firewood). Pictures: [🖼️ chimney height above the roof, U. of Minnesota p. 25](lib:heating-the-home-with-wood#page=25), [Wood-burning stove](wiki:Wood-burning_stove), [Chimney sweep](wiki:Chimney_sweep).

## 🌳 Growing your own: thinning and coppicing

**Our hardwoods regrow from the stump** — cut once, harvest again and again ("coppicing")
([USFS PSW-GTR-185](lib:seeds-seedlings-and-sprouts)):
- **Black oak, tanoak and madrone all resprout** from the root crown ([🖼️ tanoak sprouts](lib:seeds-seedlings-and-sprouts#page=12)), and it's almost impossible to stop them.
- **Cut stumps low — under 8 inches.** Sprouts from tall stumps attach weakly and rot early (p. 35).
- **Cut in winter or spring:** black oaks cut December–May sprouted 92% of the time; cut June–November, only 45% (p. 36).
- In full sun, black oak and tanoak sprout clumps reached about **20 ft tall in 10 years** (p. 36). Thin clumps to
  3–4 of the best stems after a few years.
- Bigleaf maple resprouts strongly; red alder only from young stumps *(rule of thumb)*.

**Thin for firewood and fire safety at the same time:** remove small, crowded trees and lower limbs ("ladder fuels", [🖼️ drawing](lib:reducing-hazardous-fuels-on-woodland-property-thinning#page=2))
and space out the crowns — the cut becomes firewood, and the woods burn less hot in a wildfire
([OSU EC 1573, p. 3](lib:reducing-hazardous-fuels-on-woodland-property-thinning#page=3);
[EC 1574](lib:disposing-of-woody-material)). In oak woodland, removing the Douglas-fir crowding the oaks gives both
firewood and healthier oaks ([KBO/Lomakatsi oak guide](lib:restoring-oak-habitats)).

📚 **Go deeper:** [PSW-GTR-185 — sprouting of black oak, tanoak and madrone](lib:seeds-seedlings-and-sprouts#page=35); [OSU EC 1573 — thinning](lib:reducing-hazardous-fuels-on-woodland-property-thinning); [Restoring Oak Habitats in Southern Oregon](lib:restoring-oak-habitats); [Wikipedia: coppicing](wiki:Coppicing). Pictures: [🖼️ a stand before and after thinning, EC 1573 p. 3](lib:reducing-hazardous-fuels-on-woodland-property-thinning#page=3), [California black oak](wiki:Quercus_kelloggii).

## 📆 A firewood year *(rule of thumb)*

| When | Do this |
|---|---|
| **Jan–Mar** | Fell and coppice hardwoods (best resprouting, sap down, easy to see the woods). Buck to length. |
| **Mar–May** | **Split and stack** everything for next winter, in sun and wind. Clean the chimney after the heating season. |
| **June–Sept** | Fire season: little or no saw work; let the woodpile dry. Clear brush around the house and woodpile. |
| **Oct** | Cover the tops of the stacks before the rains; move a month's wood into the shed or porch. Check the stovepipe. |
| **Nov–Feb** | Burn last year's wood; check the chimney after the first month. Haul ashes to the metal can. |

📚 **Go deeper:** [UW-Extension *Harvesting Firewood from Your Woods*](lib:harvesting-firewood-from-your-woods) — from standing tree to woodpile; [USFS 1943 summer-seasoning test](lib:summer-seasoned-fuelwood) — why early cutting matters; [Firewood](wiki:Firewood).

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Felling**
- What to check before felling — [🖼️ U. of Minnesota, p. 9](lib:heating-the-home-with-wood#page=9), [🖼️ boring for rot, EC 1124 p. 4](lib:safe-and-effective-use-of-chain-saws#page=4)
- Escape paths — [🖼️ EC 1124, p. 5](lib:safe-and-effective-use-of-chain-saws#page=5), [🖼️ *An Ax to Grind*, p. 47](lib:an-ax-to-grind#page=47)
- The three notches (conventional, Humboldt, open-face) — [🖼️ EC 1124, p. 7](lib:safe-and-effective-use-of-chain-saws#page=7); [Tree felling](wiki:Felling)
- Back cut and hinge — [🖼️ EC 1124, p. 8](lib:safe-and-effective-use-of-chain-saws#page=8)
- Felling and bucking wedges — [🖼️ *Saws That Sing*, p. 35](lib:saws-that-sing#page=35)
- Felling with an axe — [🖼️ *An Ax to Grind*, pp. 46–47](lib:an-ax-to-grind#page=46)
- How far a snag can reach — [🖼️ FS-1273, p. 36](lib:tree-risk-assessments#page=36); [Snag](wiki:Snag_(ecology)), [Sudden oak death](wiki:Phytophthora_ramorum)

**Bucking, limbing and saws**
- Tension and compression in a log — [🖼️ U. of Minnesota, p. 11](lib:heating-the-home-with-wood#page=11)
- Uphill stance; springpoles; kickback — [🖼️ EC 1124, p. 9](lib:safe-and-effective-use-of-chain-saws#page=9), [🖼️ p. 10](lib:safe-and-effective-use-of-chain-saws#page=10), [🖼️ p. 11](lib:safe-and-effective-use-of-chain-saws#page=11); [Chainsaw](wiki:Chainsaw)
- Limbing and bucking with an axe — [🖼️ *An Ax to Grind*, p. 48](lib:an-ax-to-grind#page=48), [🖼️ p. 50](lib:an-ax-to-grind#page=50)
- Crosscut saw teeth, jointing and filing — [🖼️ *Saws That Sing*, p. 14](lib:saws-that-sing#page=14), [🖼️ p. 25](lib:saws-that-sing#page=25); [Crosscut saw](wiki:Crosscut_saw)
- Filing a handsaw — [🖼️ Disston, p. 38](lib:disston-saw-tool-and-file-book-1929#page=38)

**Splitting, stacking and storing**
- Safe splitting, and the twist that throws the piece apart — [🖼️ *An Ax to Grind*, pp. 51–52](lib:an-ax-to-grind#page=51); [Splitting maul](wiki:Splitting_maul)
- A standard cord — [🖼️ U. of Minnesota, p. 3](lib:heating-the-home-with-wood#page=3); [Cord](wiki:Cord_(unit))
- Stacks drying in sun and wind — [🖼️ U. of Minnesota, p. 13](lib:heating-the-home-with-wood#page=13); [Firewood](wiki:Firewood)
- Racks and a 1-cord shed — [🖼️ EPA racks, p. 1](lib:4-easy-to-build-structures#page=1), [🖼️ EPA shed, p. 3](lib:build-a-firewood-storage-shed#page=3)

**Stoves, chimneys and ashes**
- Stove clearances and a wall shield — [🖼️ CMHC, p. 32](lib:guide-to-residential-wood-heating#page=32); [Wood-burning stove](wiki:Wood-burning_stove)
- Chimney height above the roof — [🖼️ U. of Minnesota, p. 25](lib:heating-the-home-with-wood#page=25)
- Chimney brushes — [🖼️ E-1388, p. 4](lib:the-creosote-problem#page=4); [Chimney sweep](wiki:Chimney_sweep)

**Growing firewood**
- Tanoak sprouting from the root crown — [🖼️ PSW-GTR-185, p. 12](lib:seeds-seedlings-and-sprouts#page=12); [Coppicing](wiki:Coppicing)
- Ladder fuels, and a stand before and after thinning — [🖼️ EC 1573, p. 2](lib:reducing-hazardous-fuels-on-woodland-property-thinning#page=2), [🖼️ p. 3](lib:reducing-hazardous-fuels-on-woodland-property-thinning#page=3)
- Local firewood trees — [Oregon white oak](wiki:Quercus_garryana), [Pacific madrone](wiki:Arbutus_menziesii), [Tanoak](wiki:Notholithocarpus), [California black oak](wiki:Quercus_kelloggii)

---

## 🔗 Related guides

- [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — masonry heaters, hay-boxes and holding a fire's heat
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — chainsaw care and filing
- [Blacksmithing and Hand Tools](guide:BLACKSMITHING-GUIDE) — axes, mauls, wedges, saw filing
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — lye soap from ashes, fire starting, heat
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — wildfire and defensible space
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — skidding and hauling logs
- [Wildfire: defending your place with no grid](guide:WILDFIRE-GUIDE) — clearing, hardening, water with no power, stay or go, and after the fire.
