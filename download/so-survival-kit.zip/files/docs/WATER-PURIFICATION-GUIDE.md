# 🚰 Water Purification — With What You Have

How to make creek, spring, rain or well water safe to drink when there's no store and no power: settling
and straining, homemade sand, biosand and clay-pot filters, charcoal (what it does and doesn't do),
boiling, bleach and pool shock, sunlight, solar stills, simple tests, and safe storage. The manuals are in
`Water-Purification\` (`Filters-Sand-Charcoal-Ceramic`, `Disinfection`, `Settling-Coagulation`,
`Overviews-Testing`), `Water\` and `Homestead-Skills\Sanitation-Water`. Getting the water out of the ground
is in the [Wells & Pumps guide](guide:WATER-WELLS-GUIDE).

> ### The four rules of safe water
> 1. **Clear it, then kill the germs.** Settle or filter muddy water first; then **boil or disinfect**.
> 2. **Charcoal and sand filters alone do NOT make water safe.** They clear water and improve taste;
>    charcoal beds even grow bacteria and shield them from chlorine. **Charcoal goes last, after
>    disinfection** ([WHO, pp. 51–52](lib:managing-water-in-the-home#page=51);
>    [Wilderness Medical Society, p. 6](lib:wilderness-medical-society-water-disinfection-guidelines#page=6)).
> 3. **Boiling kills germs but removes no chemicals** — not fuel, metals, salt or fire-retardant runoff.
> 4. **Keep treated water clean:** covered container with a spout, never dip a cup into it.

---

## 🧭 Which method does what

From CAWST's comparison of household methods ([CAWST *Fact Sheets*](lib:household-water-treatment-and-safe-storage-fact-sheets)):

| Method | Germs (bacteria / viruses / Giardia-Crypto) | Muddy water | Chemicals | Notes |
|---|---|---|---|---|
| Settling, three-pot storage | some | **very good** | no | First step for muddy water |
| Cloth straining | larger organisms only | some | no | Quick first step |
| [Alum](wiki:Alum), wood ash, Moringa seed | some (lab good, field ~50%) | **very good** | no | Clears water fast |
| **Biosand / slow sand filter** | **good / fair / very good** | very good | no (some iron) | Needs a living top layer |
| **Ceramic pot filter** | **very good / fair / very good** | very good | no | Needs silver coating for best results |
| **Boiling** | **kills all** | no | no | Uses fuel |
| **Chlorine (bleach, pool shock)** | **kills bacteria & viruses**; weak on Crypto | no | no | Cheap, protects stored water |
| **Sunlight (SODIS)** | **good** | needs clear water | no | Free; sunny months only |
| **Solar still / distilling** | **kills all** | yes | **removes salts & metals** | Slow, ~1 gallon/day per 12 sq ft |
| Charcoal / "activated" carbon | **poor — not a germ barrier** | some | **taste, odor, many organic chemicals** | Use last |

WHO's bar for a "protective" method is removing about 99% of bacteria and protozoa and 99.9% of viruses; most
homemade methods reach that only **in combination** ([WHO *Evaluating Household Water Treatment*, p. 11](lib:evaluating-household-water-treatment#page=11)).
**Best simple combination:** settle or filter → boil or chlorinate → (optional) charcoal for taste
([🖼️ the household methods drawn, WHO/WEDC pp. 19–21](lib:who-wedc-technical-notes#page=19); [overview with photos](wiki:Portable_water_purification)).

📚 **Go deeper:** [CAWST *Household Water Treatment Fact Sheets*](lib:household-water-treatment-and-safe-storage-fact-sheets) — every method with removal data; [WHO *Managing Water in the Home*](lib:managing-water-in-the-home); [Practical Action *Household Water Treatment*](lib:practical-action-household-water-treatment).

## 🫙 Step 1 — Clear the water

- **Let it settle.** **Three-pot method:** fill pot 1 from the source; each day pour pot 1 gently into pot 2, and
  pot 2 into pot 3 (your drinking pot) — water sits at least 2 days and much of the dirt and some germs settle out.
  Still disinfect it ([CAWST, p. 4](lib:household-water-treatment-and-safe-storage-fact-sheets#page=4)).
- **Strain through cloth:** old, soft cotton folded **7–8 times** catches particles bigger than about 20 microns —
  silt, worms, the plankton cholera rides on — but **not** bacteria or viruses. Wash the cloth after each use
  ([CAWST, pp. 14–15](lib:household-water-treatment-and-safe-storage-fact-sheets#page=14); [🖼️ photo of a folded-cloth filter, p. 14](lib:household-water-treatment-and-safe-storage-fact-sheets#page=14)).
- **Make the mud drop (coagulants):**
  - **[Alum](wiki:Alum)** (pickling alum): about ⅛ tsp per gallon; stir fast 1 minute, slowly 5 minutes, settle at least 30
    minutes, pour off through cloth ([WMS, p. 7](lib:wilderness-medical-society-water-disinfection-guidelines#page=7); [how the mud clumps](wiki:Flocculation)).
  - **Wood ash, lime, crushed beans** also work as rough coagulants (same source).
  - **[Moringa](wiki:Moringa_oleifera) seed:** about 1 crushed kernel per liter of muddy water — shake the paste in a
    cup of water, strain it in, stir 1 minute fast and 5–10 minutes slow, settle 1–2 hours
    ([ECHO note](lib:moringa-water-treatment); [WEDC, p. 3](lib:water-clarification-using-moringa#page=3)).
    **Moringa won't grow here** (frost) — stockpile seed if you want it.
  - **Coagulants clear water; they don't make it safe.** Always disinfect afterward.
- **Is it clear enough?** Look down through a clear 2-liter bottle of the water at large print — if you can read it,
  it's under about 50 [NTU](wiki:Turbidity), clear enough for filters. For chlorine, clearer is better: if the
  water is still cloudy, use **double** the bleach dose
  ([CAWST *Testing*, p. 81](lib:introduction-to-drinking-water-quality-testing#page=81)). **SODIS needs
  clearer water — under 30 NTU** ([EAWAG SODIS manual, p. 26](lib:sodis-solar-water-disinfection-manual#page=26)),
  so settle or filter it first unless it is truly clear.

📚 **Go deeper:** [CAWST — settling, coagulants and cloth, pp. 4–15](lib:household-water-treatment-and-safe-storage-fact-sheets#page=4); [WEDC *Moringa seed coagulant*](lib:water-clarification-using-moringa).

## 🏺 Step 2 — Homemade filters

### Biosand filter (best household filter you can build)
A concrete or plastic box of sand with a **living layer on top** (the "[schmutzdecke](wiki:Schmutzdecke)") that eats germs
([CAWST *Biosand Construction Manual*](lib:cawst-biosand-filter-construction-manual); [🖼️ labeled cut-away, p. 17](lib:cawst-biosand-filter-construction-manual#page=17)):
- **Layers, bottom to top:** 2 in of drainage gravel (¼–½ in), 2 in of small gravel, then **fine washed sand (0.7 mm
  or finer)** filled with water already in the box so no air gets trapped
  ([pp. 59, 92](lib:cawst-biosand-filter-construction-manual#page=59); [🖼️ filling it, step by step, p. 92](lib:cawst-biosand-filter-construction-manual#page=92)).
- **About 2 in of water must stand above the sand when it stops flowing** — more starves the living layer of air; letting
  it dry out kills it. A **diffuser plate** keeps poured water from digging up the top
  ([pp. 18–19](lib:cawst-biosand-filter-construction-manual#page=18); [🖼️ the standing-water level drawn, p. 24](lib:cawst-biosand-filter-construction-manual#page=24)).
- **Use it every day**, one bucket (12–18 L) at a time, 6–12 hours apart. The living layer takes **up to 30 days** to
  grow — **disinfect the output** until then and always for babies and the sick. When flow gets slow, stir the top inch
  and scoop off the dirty water ("swirl and dump")
  ([CAWST *Fact Sheets*, pp. 18–19](lib:household-water-treatment-and-safe-storage-fact-sheets#page=18); [🖼️ swirl-and-dump drawings](lib:cawst-biosand-filter-construction-manual#page=104)).
- **Results** once mature: bacteria about 88–98% removed in the field, Giardia-type parasites over 99.9%, viruses
  less reliable ([p. 19](lib:household-water-treatment-and-safe-storage-fact-sheets#page=19)).
- **Cold winter water** slows the living layer — filter slower and disinfect
  ([EPA slow sand, p. 9](lib:optimization-of-slow-sand-filtration#page=9)).

### Slow sand filter (for a group or homestead)
The same idea, bigger: water trickles down through about **3 ft of fine sand** at 0.1–0.2 m per hour; build **two beds**
so one can be cleaned (scrape off the top inch). A mature filter removes 95–100% of fecal bacteria and nearly all
viruses and cysts. Takes about **3 weeks** to "ripen" when new
([IRC *Slow Sand Filtration*, pp. 38, 48](lib:slow-sand-filtration-for-community#page=38); [🖼️ parts of a slow sand filter, p. 32](lib:slow-sand-filtration-for-community#page=32)).

### The bucket "layer filter" — gravel, sand, charcoal
A bucket of gravel, sand and charcoal **clears and improves water but is not a germ barrier**. The right way to use
charcoal is the three-stage system: **gravel roughing filter → slow sand biofilter (germs) → crushed charcoal (chemicals and
taste) → covered storage**; replace the charcoal yearly
([Aqueous Solutions *Biochar Water Filter*, pp. 2–9](lib:biochar-water-filter-system#page=2); [🖼️ the three-drum layout, p. 2](lib:biochar-water-filter-system#page=2); [🖼️ what goes in each drum, p. 9](lib:biochar-water-filter-system#page=9)).

### Clay pot (ceramic) filter
Clay mixed with **sawdust or rice husk** (about 50:50 by volume to start) is pressed into a pot and fired to about
**900 °C (1,650 °F)** — the sawdust burns out and leaves tiny pores
([CMWG *Ceramic Pot Filters*, p. 62](lib:best-practice-recommendations-for-local#page=62);
[RDIC handbook](lib:rdic-ceramic-water-filter-handbook)). It sits in a covered bucket with a tap ([🖼️ drawing](lib:rdic-ceramic-water-filter-handbook#page=5); [🖼️ Potters for Peace filter](lib:best-practice-recommendations-for-local#page=15)) and gives 1–3 liters an
hour. **Test local clay first** ([clay testing](lib:clay-testing-protocol)); **flow-test** each pot (at least 1 liter in
the first hour, not too fast — too fast means cracks) ([CMWG, p. 114](lib:best-practice-recommendations-for-local#page=114)).
They work best with a **[colloidal silver](wiki:Silver_nanoparticle)** coating, which you can't make from raw materials — without it, still disinfect.
Replace every 1–2 years or when cracked. Kiln plans: [Mani kiln](lib:mani-kiln) ([🖼️ cut-away drawing, p. 3](lib:mani-kiln#page=3)).

📚 **Go deeper:** [CAWST *Biosand Filter Construction Manual*](lib:cawst-biosand-filter-construction-manual); [IRC *Slow Sand Filtration*](lib:slow-sand-filtration-for-community); [CMWG ceramic filter manual](lib:best-practice-recommendations-for-local); [Wikipedia: biosand filter](wiki:Biosand_filter) · [slow sand filter](wiki:Slow_sand_filter) · [ceramic water filter](wiki:Ceramic_water_filter).

## ⚫ Charcoal: making it and using it right

- **What it does:** soaks up **taste, odor and many organic chemicals** (pesticides, some fuel residues). **What it
  doesn't:** reliably remove germs — WHO doesn't recommend it for germs, and bacteria grow in the bed
  ([WHO, pp. 51–52](lib:managing-water-in-the-home#page=51)).
- **Plain vs. activated:** ordinary [charcoal](wiki:Charcoal) has its pores clogged with tar, so it adsorbs poorly. Factories
  **"activate"** it by heating to about 800 °C in steam, which opens the pores
  ([FAO *Industrial Charcoal Making*, p. 28](lib:industrial-charcoal-making#page=28)).
- **Homemade water-treatment charcoal** ([Aqueous Solutions *Char Drum Oven*](lib:adsorption-char-drum-oven)):
  1. Pack dry wood pieces (1–2 in thick) tightly in a steel drum, set a chimney drum on top, and **light it from the
     top** ([🖼️ the stacked drums](lib:adsorption-char-drum-oven#page=6)). It burns about 2 hours down to faint blue flames ([🖼️ flame colors](lib:adsorption-char-drum-oven#page=7)).
  2. **Quench with plenty of water** ([🖼️ photo](lib:adsorption-char-drum-oven#page=8)) — the steam partly opens the pores (crude activation, not true activated carbon).
  3. Crush and sieve to **1–5 mm** pieces; wash out the dust.
- **Use it as the LAST step** after the water is filtered and disinfected, or in a column after a sand filter; replace
  it yearly. Hardwood (oak, madrone) makes good charcoal. Chemical activation (acids, zinc chloride) isn't a safe home
  method *(rule of thumb)*.
- Charcoal-making in bulk: [Practical Action brief](lib:practical-action-charcoal-production) ([🖼️ a portable metal kiln, p. 3](lib:practical-action-charcoal-production#page=3)) and the
  [Peace Corps charcoal manual](lib:small-scale-charcoal-making).

📚 **Go deeper:** [FAO — what activated charcoal is, p. 28](lib:industrial-charcoal-making#page=28); [Aqueous Solutions — charcoal oven](lib:adsorption-char-drum-oven); [Wikipedia: activated carbon](wiki:Activated_carbon).

## 🔥 Step 3 — Kill the germs

**[Boiling](wiki:Boiling)** — the surest method. **A rolling boil for 1 minute** (3 minutes above 6,500 ft — we're far below that)
kills bacteria, viruses and parasites even in cloudy water. Let it cool covered; don't add ice
([WHO *Boil Water*, p. 1](lib:boil-water-technical-brief#page=1); [OSU, p. 5](lib:survival-basics-water#page=5)).
**Fuel cost:** about **0.2 kg (½ lb) of wood per liter** — a family's 4 gallons a day is about 7 lb of wood a day
([WHO Bulletin, p. 4](lib:boiling-of-drinking-water-can#page=4)) — see the [Firewood guide](guide:FIREWOOD-GUIDE).

**Bleach** (plain unscented, 6–8.25% [sodium hypochlorite](wiki:Sodium_hypochlorite)) — [EPA, p. 1](lib:emergency-disinfection-of-drinking-water#page=1):

| Water | 6% bleach | 8.25% bleach |
|---|---|---|
| 1 quart, clear | 2 drops | 2 drops |
| 1 gallon, clear | **8 drops** | **6 drops** |
| 1 gallon, cloudy or very cold | 16 drops | 12 drops |

Stir, wait **30 minutes**. It should smell faintly of chlorine; if not, dose again and wait 15 more minutes. **Cold water
needs longer: 1 hour at 50–65 °F, 2+ hours below 50 °F** — winter creek water
([CAWST, p. 59](lib:household-water-treatment-and-safe-storage-fact-sheets#page=59)). Bleach loses strength — use it within a
year. Chlorine is **weak against [Cryptosporidium](wiki:Cryptosporidium)**: settle or filter first.

**Pool shock ([calcium hypochlorite](wiki:Calcium_hypochlorite)) — stores for years as dry granules.** Dissolve **1 heaping teaspoon in 2 gallons** of
water to make a stock solution; then use **1 part stock to 100 parts water** (1 pint per 12½ gallons), wait 30 minutes
([EPA, p. 2](lib:emergency-disinfection-of-drinking-water#page=2)). Use plain granules (no algaecide or stabilizer), mix
outdoors with eye protection, and make stock in small batches — it lasts about a month in heat, longer cool and dark
([CDC *Safe Water Systems*, p. 62](lib:safe-water-systems-for-the-developing-world#page=62)).

**Iodine:** 5 drops of 2% [tincture](wiki:Tincture_of_iodine) per quart (10 if cloudy), wait 30 minutes ([EPA, p. 2](lib:emergency-disinfection-of-drinking-water#page=2)) — fine short-term
(a month at most), never for pregnant women or anyone with thyroid disease or an iodine allergy
([WMS, p. 14](lib:wilderness-medical-society-water-disinfection-guidelines#page=14)).

**Sunlight (SODIS):** clear plastic ([PET](wiki:Polyethylene_terephthalate)) bottles of clear water, lying flat in full sun **6 hours** (2 days if more than half
cloudy). Works well here **March–September**, poorly in the winter rains
([EAWAG SODIS manual, p. 23](lib:sodis-solar-water-disinfection-manual#page=23); [🖼️ how-to drawings, p. 26](lib:sodis-solar-water-disinfection-manual#page=26); [🖼️ the home poster, p. 76](lib:sodis-solar-water-disinfection-manual#page=76)).

**Solar pasteurizing:** water held at **65 °C (150 °F)** is [pasteurized](wiki:Pasteurization) — a [solar box cooker](wiki:Solar_cooker) can do several gallons on a
summer day ([Ciochetti & Metcalf](lib:pasteurization-of-naturally-contaminated-water)). A lump of **beeswax** in a sealed
tube melts at about 62 °C — just under the target, so melted wax means "nearly there": keep it hot a
while longer, or boil it, to be sure ([CAWST, p. 75](lib:household-water-treatment-and-safe-storage-fact-sheets#page=75)).

📚 **Go deeper:** [EPA *Emergency Disinfection of Drinking Water*](lib:emergency-disinfection-of-drinking-water); [CDC *Safe Water Systems* handbook](lib:safe-water-systems-for-the-developing-world) — making and storing chlorine; [Wilderness Medical Society guidelines](lib:wilderness-medical-society-water-disinfection-guidelines); [Wikipedia: SODIS](wiki:Solar_water_disinfection).

## ☀️ Salty or chemical water: the solar still

A shallow black basin under sloped glass or clear plastic: the sun evaporates the water, it condenses on the cover
and runs into a gutter ([🖼️ photos of stills, CAWST p. 71](lib:household-water-treatment-and-safe-storage-fact-sheets#page=71)) — leaving salt, metals and germs behind. Expect about **1 gallon a day per 10–12 sq ft** of glass
([CAWST, p. 71](lib:household-water-treatment-and-safe-storage-fact-sheets#page=71);
[Aprovecho, p. 43](lib:capturing-heat-three#page=43)). Some fuel-type chemicals can carry over *(rule of thumb)*.

📚 **Go deeper:** [CAWST — solar distillation](lib:household-water-treatment-and-safe-storage-fact-sheets#page=71); [Wikipedia: solar still](wiki:Solar_still).

## 🔬 Simple tests

- **Turbidity tube:** a clear tube with a black-and-white disk at the bottom — pour water in until the disk disappears;
  the depth tells cloudiness (disk gone at 18 cm ≈ 50 NTU; at 85 cm ≈ 5 NTU)
  ([Myre & Shaw, pp. 11–16](lib:turbidity-tube#page=11); [🖼️ the parts, p. 7](lib:turbidity-tube#page=7); [🖼️ finished tubes, p. 10](lib:turbidity-tube#page=10); [Secchi disk](wiki:Secchi_disk) — the same idea in a lake).
- **H₂S bacteria test:** a paper strip with a special medium in a bottle of water turns **black** in 1–2 days if fecal
  bacteria are present — keep it warm (above 77 °F). Agreed with lab tests about 90% of the time; sulfur well water can
  give false alarms ([WHO, pp. 16, 33](lib:evaluation-of-the-h2s-method#page=16); [🖼️ a test vial, CAWST](lib:introduction-to-drinking-water-quality-testing#page=180); [coliform bacteria](wiki:Coliform_bacteria)). The test bottles must be bought ahead.
- **Chlorine check:** a faint chlorine smell 30 minutes after dosing means enough was added ([🖼️ checking it with a color comparator](lib:who-wedc-technical-notes#page=45)).
- **Sanitary check:** look at the source — animals, outhouses, runoff upstream? Fix the source first
  ([CAWST *Testing*](lib:introduction-to-drinking-water-quality-testing); [🖼️ how springs and wells get polluted](lib:farmstead-water-supply#page=7)).

📚 **Go deeper:** [CAWST *Introduction to Drinking Water Quality Testing*](lib:introduction-to-drinking-water-quality-testing); [Turbidity tube](lib:turbidity-tube).

## 🪣 Storing water safely

- **Covered container with a tap or narrow spout**, opaque, easy to clean; **never put untreated water in it**; clean it
  with soap or chlorine; keep it off the ground in shade; **pour, don't dip**
  ([CAWST, pp. 83–84](lib:household-water-treatment-and-safe-storage-fact-sheets#page=83); [🖼️ safe storage containers](lib:cawst-biosand-filter-construction-manual#page=105); [🖼️ a tap fitted to a bucket](lib:who-wedc-technical-notes#page=21); [jerrycan](wiki:Jerrycan)).
- Don't reuse milk jugs — they can't be cleaned well ([OSU, p. 2](lib:survival-basics-water#page=2)).
- Chlorinated water keeps best; boiled water can be recontaminated — drink it within a day or two.

📚 **Go deeper:** [CAWST — safe storage and handling, p. 83](lib:household-water-treatment-and-safe-storage-fact-sheets#page=83); [CDC *Safe Water Systems* — choosing a storage vessel, p. 69](lib:safe-water-systems-for-the-developing-world#page=69); [CAWST *Biosand Manual* — cleaning a storage container, p. 106](lib:cawst-biosand-filter-construction-manual#page=106).

## 🔥 After a wildfire

Burned slopes send ash, metals, nitrate and organic chemicals into creeks after storms — levels jumped 10 to 10,000 times
after a Colorado fire ([USGS, p. 1](lib:wildfire-effects-on-source-water-quality#page=1)). **Boiling, chlorine, sunlight and
sand or clay filters do not remove these.** Fire-damaged plastic pipes can leach benzene, and **boiling doesn't remove it**
([WQA](lib:water-quality-after-wildfires)). After a fire, prefer **springs or wells outside the burn, or rainwater**;
distilling and charcoal are the only partial chemical barriers here.

📚 **Go deeper:** [USGS *Wildfire Effects on Source-Water Quality*](lib:wildfire-effects-on-source-water-quality); [OWRD — your well after wildfire](lib:maintaining-your-well-after-wildfire).

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Clearing muddy water**
- Household methods at a glance (shaking, sand and candle filters, chlorine, SODIS) — [🖼️ WHO/WEDC, pp. 19–21](lib:who-wedc-technical-notes#page=19); [Portable water purification](wiki:Portable_water_purification)
- Straining through folded cloth — [🖼️ CAWST, p. 14](lib:household-water-treatment-and-safe-storage-fact-sheets#page=14)
- Alum and Moringa seed — [Alum](wiki:Alum); [Moringa](wiki:Moringa_oleifera); [Flocculation](wiki:Flocculation)

**Sand, clay and charcoal filters**
- Biosand filter, every part labeled — [🖼️ CAWST manual, p. 17](lib:cawst-biosand-filter-construction-manual#page=17); [🖼️ CAWST fact sheet, p. 17](lib:household-water-treatment-and-safe-storage-fact-sheets#page=17); [Biosand filter](wiki:Biosand_filter)
- The 2-inch standing-water level — [🖼️ CAWST, p. 24](lib:cawst-biosand-filter-construction-manual#page=24); [Schmutzdecke](wiki:Schmutzdecke)
- Putting in the gravel and sand — [🖼️ CAWST, p. 92](lib:cawst-biosand-filter-construction-manual#page=92)
- Swirl-and-dump cleaning — [🖼️ CAWST, p. 104](lib:cawst-biosand-filter-construction-manual#page=104)
- Slow sand filter, outlet- and inlet-controlled — [🖼️ IRC, p. 32](lib:slow-sand-filtration-for-community#page=32); [🖼️ IRC, p. 33](lib:slow-sand-filtration-for-community#page=33); [Slow sand filter](wiki:Slow_sand_filter)
- Gravel → sand → charcoal drum system — [🖼️ Aqueous Solutions, p. 2](lib:biochar-water-filter-system#page=2); [🖼️ the roughing filter, p. 6](lib:biochar-water-filter-system#page=6); [Biochar](wiki:Biochar)
- Clay pot filter in its bucket — [🖼️ RDIC, p. 5](lib:rdic-ceramic-water-filter-handbook#page=5); [🖼️ CMWG, p. 15](lib:best-practice-recommendations-for-local#page=15); [Ceramic water filter](wiki:Ceramic_water_filter)
- Ceramic candle filter — [🖼️ WHO/WEDC, p. 20](lib:who-wedc-technical-notes#page=20)
- Kiln for firing filters — [🖼️ Mani kiln, p. 3](lib:mani-kiln#page=3)
- Char drum oven, step by step — [🖼️ Aqueous Solutions, p. 6](lib:adsorption-char-drum-oven#page=6); [🖼️ flames, p. 7](lib:adsorption-char-drum-oven#page=7); [🖼️ quenching, p. 8](lib:adsorption-char-drum-oven#page=8); [Activated carbon](wiki:Activated_carbon)
- Charcoal kilns — [🖼️ Practical Action, p. 3](lib:practical-action-charcoal-production#page=3); [Charcoal](wiki:Charcoal)

**Killing the germs**
- Chlorine tablets, SODIS and a tapped bucket — [🖼️ WHO/WEDC, p. 21](lib:who-wedc-technical-notes#page=21); [Water chlorination](wiki:Water_chlorination)
- Bleach and pool shock — [Sodium hypochlorite](wiki:Sodium_hypochlorite); [Calcium hypochlorite](wiki:Calcium_hypochlorite)
- SODIS: right and wrong bottles, how to lay them out — [🖼️ EAWAG, pp. 26–27](lib:sodis-solar-water-disinfection-manual#page=26); [🖼️ home poster, p. 76](lib:sodis-solar-water-disinfection-manual#page=76); [Solar water disinfection](wiki:Solar_water_disinfection)
- Solar box cooker for pasteurizing — [Solar cooker](wiki:Solar_cooker)
- Solar stills — [🖼️ CAWST, pp. 71–72](lib:household-water-treatment-and-safe-storage-fact-sheets#page=71); [Solar still](wiki:Solar_still)

**Testing and storing**
- Turbidity tube — [🖼️ parts, p. 7](lib:turbidity-tube#page=7); [🖼️ finished tubes, p. 10](lib:turbidity-tube#page=10); [Turbidity](wiki:Turbidity)
- H₂S bacteria test — [🖼️ CAWST, p. 180](lib:introduction-to-drinking-water-quality-testing#page=180); [Coliform bacteria](wiki:Coliform_bacteria)
- Chlorine color comparator — [🖼️ WHO/WEDC, p. 45](lib:who-wedc-technical-notes#page=45)
- Safe storage containers and cleaning them — [🖼️ CAWST, p. 105](lib:cawst-biosand-filter-construction-manual#page=105); [🖼️ CAWST, p. 106](lib:cawst-biosand-filter-construction-manual#page=106); [Jerrycan](wiki:Jerrycan)
- Covered water pots — [🖼️ WHO/WEDC, p. 39](lib:who-wedc-technical-notes#page=39)

---

## 🔗 Related guides

- [Water Wells, Pumps, Springs & Cisterns](guide:WATER-WELLS-GUIDE)
- [Firewood](guide:FIREWOOD-GUIDE) — fuel for boiling; charcoal from hardwood
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — sanitation, SODIS, containers
- [Medical](guide:Medical-READ-ME-FIRST) — diarrhea and rehydration
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local water facts
