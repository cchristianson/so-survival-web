# 📐 Practical Math, Measuring & Geometry

Homestead math with no stores: measuring with your body and a string, mixing by ratio, squaring a
foundation, areas, tanks, woodpiles and loads, slopes and heights you can't reach, and the numbers behind
water, power and medicine — each with a worked Illinois Valley example.
The books are in `Math-Measuring\Arithmetic-Geometry` (Navy *Mathematics* courses),
`Math-Measuring\Measuring-Surveying` (USDA surveying, quantities, timber measuring) and
`Math-Measuring\Units-Tables` (NIST unit tables, Army *Engineer Field Data*); Ray's arithmetic is in
`Children-Learning\Arithmetic`, and FM 5-426 *Carpentry* and FM 5-125 *Rigging* in
`Manuals\ArmyFieldManuals`. The interactive **🔢 Unit converter & calculators** page
([Unit converter](guide:UNIT-CONVERTER)) does the arithmetic; this guide shows how to do it with a pencil.

> ### ⚠️ Rules that prevent the worst mistakes
> - **Same units before you multiply.** Turn everything into feet (or inches) first. Mixing inches and
>   feet is the commonest error — off by 12, 144 or 1,728 times.
> - **A British or Canadian "gallon" is about 20% bigger** than a US gallon
>   ([NIST HB 44, p. 8](lib:nist-handbook-44#page=8)). Check where a recipe or manual came from.
> - **Medicine: only doses printed in the medical books,** in mg and mL, never drops. A second person
>   redoes the arithmetic before anyone swallows it.
> - **Loads are heavier than they look.** A cubic yard of damp packed earth weighs about 2,600 lb
>   ([FM 5-34, p. 292](lib:fm-5-34-engineer#page=292)). Never stand under a lift.
> - **Measure twice, check a second way, and round the safe way:** more posts, a bigger pipe, a smaller dose.

---

## 📏 Measuring with no tools

**Your body is a ruler — measure yours once** *(rule of thumb)*:

| Measure | What it is | Typical adult |
|---|---|---|
| Thumb width | Across the knuckle | about 1 in |
| Span | Thumb tip to little-finger tip, spread | 8–9 in |
| Cubit | Elbow to fingertip | 17–19 in |
| Arm spread | Fingertip to fingertip | about your height |
| Pace | One step | 2–2½ ft |

**Pace count** ([NRCS *Surveying*, p. 33](lib:nrcs-engineering-field-handbook-ch-1#page=33)): walk a
measured 500 ft until the count varies by no more than 2–3 paces. **Pace factor = distance ÷
paces**; pacing is good to about 2%. *Example:* 500 ft in 200 paces = 2.5 ft per pace, so 340 paces along a
fence is 850 ft. The Army counts every step, the Forest Service every second step — pick one
([FM 3-25.26, p. 52](lib:fm-3-25-26-map#page=52); [Navigation guide](guide:NAVIGATION-WEATHER-GUIDE)).
Hills and brush add steps; count with [pace count beads](wiki:Pace_count_beads).

**Known sizes** *(standard sizes)*: a dollar bill is 6.14 in long; a "2×4" is 1½ × 3½ in; letter paper
8½ × 11 in. A string knotted every foot is a tape.

**Level, plumb and straight:**
- **[Water level](wiki:Water_level_(device)):** clear tubing full of water; both ends settle at the same
  height however long the tube *(rule of thumb: get every bubble out)*. With a measuring rod it also
  measures a creek's drop ([NRCan, p. 42](lib:nrcan-micro-hydropower-systems-a-buyers#page=42)).
- **[Plumb bob](wiki:Plumb_bob):** any weight on a string — "use a rock, half-brick, or small piece of
  metal" ([FM 5-426, p. 88](lib:fm-5-426-carpentry#page=88)).
- **Straight:** a tight string or a snapped [chalk line](wiki:Chalk_line) ([FM 5-426, p. 44](lib:fm-5-426-carpentry#page=44)).

**Equal parts** ([🖼️ Navy *Mathematics* Vol. 1, p. 197](lib:navpers-10069#page=197)): for 5 equal strips,
slant a ruler so 0 and 10 in touch the board's edges and mark at 2, 4, 6 and 8.

📚 **Go deeper:** [NRCS *Surveying*, pp. 32–34](lib:nrcs-engineering-field-handbook-ch-1#page=32) — pacing and taping on slopes; [Navy Vol. 1, ch. 6](lib:navpers-10069#page=62) — percentage and measurement; [Tape measure](wiki:Tape_measure).

## ➗ Fractions, percents, ratios and mixing

**Percent = part ÷ whole × 100:** 15 sick hens of 60 is 25% ([Navy Vol. 1, pp. 62–64](lib:navpers-10069#page=62)).

**Scaling a recipe:** factor = amount wanted ÷ amount the recipe makes. Bread for 6 loaves, wanted 10:
10 ÷ 6 = 1⅔, so 3 cups of water becomes 5. Scale **every** ingredient
([ratio and proportion, p. 148](lib:navpers-10069#page=148)).

**Mixing by parts** — add the parts; each part is the batch ÷ that total. All by volume, same bucket:

| Mix | Parts | Source |
|---|---|---|
| 2-stroke fuel | Ratio on the engine; most modern saws 50:1 = **2.6 oz oil per gallon** (40:1 = 3.2 oz; 32:1 = 4 oz) | [MAVCC, p. 186](lib:small-engine-repair-two-stroke#page=186); *(rule of thumb)* |
| Concrete toilet slab | **1 cement : 2 gravel : 3 sand** + water till it holds together | [🖼️ Hesperian ch. 7, p. 20](lib:hesperian-community-guide-to-environmental-health-ch-7#page=20) |
| Chimney mortar | **1 portland cement : 1 lime : 6 sand** | [FB 1751, p. 24](lib:roof-coverings-for-farm-buildings#page=24) |

*Example:* 3 cu ft of that concrete is 6 parts: ½ cu ft cement, 1 gravel, 1½ sand.

**Dilution: C1 × V1 = C2 × V2** (strength × amount before = strength × amount after). **1 gallon of 0.2%
chlorine from 6% bleach:** V1 = 0.2 × 1 ÷ 6 = 1/30 gallon = **8½ Tbsp, about ½ cup**, topped up to 1
gallon with water — the same as the [Sanitation guide](guide:SANITATION-GUIDE)'s table and the MSF rule
**parts of water = (bleach % ÷ % wanted) − 1** ([MSF *Cholera*, p. 226](lib:management-of-a-cholera#page=226)).
Never mix bleach with ammonia or vinegar.

📚 **Go deeper:** [Ray's *Practical Arithmetic*](lib:rays-new-practical-arithmetic) — fractions to percentage, with hundreds of problems; [Answers for parents](lib:key-to-rays-new-arithmetics); [Navy Vol. 1, chs. 4–6](lib:navpers-10069#page=35).

## 📐 Right angles and layout

**The 3-4-5 triangle** ([Pythagorean theorem](wiki:Pythagorean_theorem)): from the corner, mark 3 ft
along one string and 4 ft along the other; when the marks are exactly 5 ft apart, the corner is square
([🖼️ Navy Vol. 1, p. 199](lib:navpers-10069#page=199)). Multiples work — **6-8-10, 9-12-15, 12-16-20** —
and bigger is more accurate: never start under 6 ft; use 12-16-20 for a 50 × 100 ft layout
([FM 5-426, p. 48](lib:fm-5-426-carpentry#page=48)).

**Check the diagonals:** a rectangle is square only when both diagonals are **equal** (same page). For a
20 × 30 ft shed, √(400 + 900) = **36.06 ft (36 ft ⅝ in)** each. Hang the lines on **batter boards** set back from
the corners so they survive digging ([FM 5-426, p. 46](lib:fm-5-426-carpentry#page=46)).

**With a string and stakes** (a rope compass):
- **Bisect a line:** swing equal arcs from each end; the line through the crossings halves it at a
  right angle ([🖼️ Navy Vol. 1, p. 198](lib:navpers-10069#page=198)). **Bisect an angle** the same way
  from its arms ([🖼️ p. 199](lib:navpers-10069#page=199)).
- **Center of a round thing** (tank, millstone): bisect two chords; the lines cross at the center
  ([🖼️ p. 200](lib:navpers-10069#page=200)).
- **Circle:** string on a center stake; 10 ft of string gives 62.8 ft around (C = 2πr).
- **Oval ([ellipse](wiki:Ellipse)) bed or pond, 20 × 12 ft** *(geometry)*: two stakes 16 ft apart on the
  long center line (√(10² − 6²) = 8 ft each side of center), a **loop of string 36 ft around** (20 + 16)
  over both, pulled taut with a marking stick and walked around. A straightedge method is on
  [🖼️ p. 200](lib:navpers-10069#page=200).

📚 **Go deeper:** [Navy Vol. 1, ch. 18](lib:navpers-10069#page=197) — constructions; [FM 5-426, pp. 44–48](lib:fm-5-426-carpentry#page=44) — layout tools, batter boards, squaring; [Steel square](wiki:Steel_square).

## 🟩 Area: plots, fences, roofs and walls

| Shape | Area | Example |
|---|---|---|
| Rectangle | length × width | 60 × 40 ft garden = 2,400 sq ft |
| Triangle | ½ × base × height | base 30, height 20 ft = 300 sq ft |
| Circle | π × r² (π ≈ 3.14) | 10-ft radius = 314 sq ft |
| [Trapezoid](wiki:Trapezoid) | ½ × (a + b) × height | parallel sides 120 and 80 ft, 60 ft apart = 6,000 sq ft |
| Triangle, three sides known | √(s(s−a)(s−b)(s−c)), s = half the perimeter | below |

([Navy Vol. 1, pp. 191–196](lib:navpers-10069#page=191); [🖼️ NRCS *Quantity Computations*, p. 15](lib:quantity-computations#page=15); [Heron's formula](wiki:Heron's_formula))

**Irregular plot:** split it into triangles and **measure all three sides of each** — no angles needed.
A pasture with sides 210, 180, 160 and 190 ft and a 250-ft diagonal gives triangles (210, 180, 250) and
(250, 160, 190): 18,573 + 15,199 = **33,772 sq ft = 0.78 acre**. Measure **level** distance; a tape laid
on a hillside reads long ([NRCS *Quantity Computations*, p. 14](lib:quantity-computations#page=14)).

**Acres:** 1 [acre](wiki:Acre) = **43,560 sq ft** ([NIST HB 44, p. 25](lib:nist-handbook-44#page=25)), a
square **208.7 ft** on a side ([p. 13](lib:nist-handbook-44#page=13)). Old deeds use the **rod (16½ ft)**
and **chain (66 ft)** ([pp. 24–25](lib:nist-handbook-44#page=24)); 10 square chains = 1 acre.

**Fences:** posts on a **straight run = length ÷ spacing + 1**; on a **closed loop = perimeter ÷
spacing**. A 1-acre square is 835 ft around: posts every 10 ft = **84**.

**Roofs:** roof area = flat (plan) area × the **slope factor** (table in the slope section). Roofing is
sold by the **square = 100 sq ft** ([Ray's, p. 330](lib:rays-new-practical#page=330)). A 30 × 20 ft
cabin with 1-ft overhangs is 32 × 22 = 704 sq ft flat × 1.118 (6-in-12) = **787 sq ft, 7.9 squares**;
add about 10% for waste *(rule of thumb)* → 9 squares.

**Paint and plaster:** wall area (perimeter × height, minus openings) ÷ what one batch **actually
covered** on a test patch. **Plaster volume = area × thickness:** 400 sq ft at ½ in = **16.7 cu ft**.

📚 **Go deeper:** [NRCS *Quantity Computations*, pp. 14–16](lib:quantity-computations#page=14) — areas by triangles and coordinates; [Ray's, pp. 318–331](lib:rays-new-practical#page=318) — mensuration for the old trades.

## 🛢️ Volume: tanks, wells, piles, bins and woodpiles

**Key numbers:** 1 cu ft = 1,728 cu in = **7.48 gallons**; 1 gallon = 231 cu in; 1 cu yd = 27 cu ft
([Navy Vol. 1, p. 227](lib:navpers-10069#page=227); [NIST HB 44, p. 27](lib:nist-handbook-44#page=27)).
Water weighs **62.4 lb per cu ft** ([DOE *Microhydropower*, p. 113](lib:doe-microhydropower-handbook-vol-1-part-1#page=113)),
so 62.4 ÷ 7.48 = **8.34 lb per gallon**: a 5-gallon bucket is 42 lb, a full 55-gallon drum about 460 lb.

| Shape | Volume | Example |
|---|---|---|
| Box | length × width × depth | slab 10 × 12 ft × 4 in = 40 cu ft = 1.48 cu yd |
| [Cylinder](wiki:Cylinder) (tank, well, barrel) | π × r² × height | tank 8 ft across, 6 ft of water: π × 16 × 6 = 301.6 cu ft × 7.48 = **2,256 gal** |
| [Cone](wiki:Cone) (gravel, grain, sawdust pile) | π × r² × height ÷ 3 | sawdust pile 10 ft across, 4 ft high = 105 cu ft ≈ 3.9 cu yd |

([🖼️ NRCS *Quantity Computations*, p. 17](lib:quantity-computations#page=17); [🖼️ cone, Navy Vol. 1, p. 203](lib:navpers-10069#page=203); [🖼️ all shapes, FM 5-34, p. 300](lib:fm-5-34-engineer#page=300))

**Well casing:** gallons per foot of water = **0.0408 × (inside diameter in inches)²**: 4-in 0.65, 6-in
1.5, 8-in 2.6 ([OHA bulletin, p. 2](lib:oha-well-disinfection#page=2)). A 6-in well with 120 ft of water
(well depth − static water level, same page) holds about 180 gallons ([Wells guide](guide:WATER-WELLS-GUIDE)).

**Horizontal tank, partly full** *(computed)*: depth ÷ diameter → percent of full capacity:

| Depth ÷ diameter | 0.1 | 0.2 | 0.25 | 0.3 | 0.4 | 0.5 | 0.6 | 0.7 | 0.75 | 0.8 | 0.9 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| % full | 5 | 14 | 20 | 25 | 37 | 50 | 63 | 75 | 80 | 86 | 95 |

**Grain:** 1 [bushel](wiki:Bushel) = 2,150.42 cu in = 1.244 cu ft ([HB 44, p. 17](lib:nist-handbook-44#page=17)),
so **bushels ≈ cu ft × 0.8** (Ray's: cubic inches ÷ 2,150.4, [p. 332](lib:rays-new-practical#page=332)). A
bin 10 ft across, filled 8 ft deep: 3.14 × 25 × 8 = 628 cu ft → about **505 bushels**.

**Firewood and lumber:**
- **[Cord](wiki:Cord_(unit))** = 4 × 4 × 8 ft = **128 cu ft** ([FB 1210, p. 5](lib:farm-timber#page=5)).
  A pile of 16-in wood 20 ft long and 5 ft high: 20 × 5 × 1.33 = 133 cu ft ≈ 1 cord
  ([Firewood guide](guide:FIREWOOD-GUIDE)).
- **[Board foot](wiki:Board_foot)** = 1 in × 12 in × 12 in (same page): **thickness (in) × width (in) ×
  length (ft) ÷ 12**. A 12-ft 2×6 = 12 board feet.
- **Logs, Doyle rule:** (small-end diameter in inches − 4)² = board feet in a 16-ft log
  ([FB 1210, p. 7](lib:farm-timber#page=7)). A 20-in log: 16² = **256**. Doyle short-changes small logs
  ([p. 6](lib:farm-timber#page=6)).

**Concrete, cob and earth:**
- **Weight per cu ft:** concrete 144 lb, damp packed earth 96, loose dry earth 76, dry loose sand and
  gravel 90–105 ([FM 5-34, p. 292](lib:fm-5-34-engineer#page=292)). That 40-cu-ft slab is about 5,760 lb.
- **Dug earth swells:** 1 cu ft in the ground becomes 1.11 loose for sand, **1.25 for loam, 1.43 for
  clay** ([FM 5-34, p. 296](lib:fm-5-34-engineer#page=296)). A 4 × 4 × 6 ft loam pit (96 cu ft) makes a
  120-cu-ft pile.
- Dry mix shrinks when wetted: have half again more than the finished volume *(rule of thumb)*.

**Rain catchment:** **0.62 gallons per sq ft of roof per inch of rain**
([Texas *Rainwater*, p. 34](lib:texas-manual-on-rainwater#page=34)); real systems catch about 85%
([p. 43](lib:texas-manual-on-rainwater#page=43)). Only **5–7 in** falls April–September here
([Josephine County Soil Survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)):
a 1,500-sq-ft roof catches 6 × 1,500 × 0.62 × 0.85 ≈ **4,700 gallons all summer** — store winter water.
Cave Junction's record day, 8.12 in (same page), sheds about 7,500 gallons off it — size the overflow.
**Watering:** 1 inch on 1,000 sq ft = 623 gallons.

📚 **Go deeper:** [NRCS *Quantity Computations*, pp. 17–20](lib:quantity-computations#page=17) — prisms, cones, cut and fill; [FB 1210](lib:farm-timber) — log rules and cord tables; [Rainwater harvesting](wiki:Rainwater_harvesting).

## ⛰️ Slope, grade, pitch and stairs

**Three ways to say "how steep":**
- **Percent grade** = rise ÷ run × 100 ([🖼️ FM 3-25.26, p. 112](lib:fm-3-25-26-map#page=112); [Grade](wiki:Grade_(slope))).
- **Degrees** ≈ rise × 57.3 ÷ run, good below 20° ([🖼️ p. 114](lib:fm-3-25-26-map#page=114)).
- **Roof [pitch](wiki:Roof_pitch) "x in 12"** = inches of rise per foot of run. Old books say "1/6 pitch"
  for 4 in 12, "¼" for 6 in 12, "½" for 12 in 12 ([FM 5-426, p. 110](lib:fm-5-426-carpentry#page=110)).

| Roof pitch | 3 in 12 | 4 in 12 | 6 in 12 | 8 in 12 | 9 in 12 | 12 in 12 |
|---|---|---|---|---|---|---|
| Percent | 25% | 33% | 50% | 67% | 75% | 100% |
| Degrees | 14° | 18.4° | 26.6° | 33.7° | 36.9° | 45° |
| Slope factor (rafter ÷ run) | 1.031 | 1.054 | 1.118 | 1.202 | 1.250 | 1.414 |

*(computed: factor = √(144 + rise²) ÷ 12)*

**Rafter length** (Pythagoras): run = half the building's width. A 20-ft-wide cabin at 6 in 12: run 10 ft,
rise 5 ft, rafter = √(100 + 25) = 11.18 ft = **11 ft 2⅛ in**, plus overhang. A square's
[rafter](wiki:Rafter) table agrees ([FM 5-426, pp. 107–110](lib:fm-5-426-carpentry#page=107)).

**Stairs:** riser + tread = **17–19 in** and riser × tread = **70–75**; one fewer tread than risers
([FM 5-426, p. 102](lib:fm-5-426-carpentry#page=102)). A porch 36 in high: 5 risers of 7.2 in and 4 treads
of 10 in (sum 17.2, product 72) → 40 in of run.

**Fall on pipes and ditches** (inches per foot × 8.33 = percent):

| Use | Slope | Source |
|---|---|---|
| Gutter | 1 in per 10 ft (0.8%) | [Wood-Frame House, p. 169](lib:wood-frame-house-construction#page=169) |
| Creek intake channel or pipe | about 1% | [*Hydrams*, p. 209](lib:hydrams-design-construction#page=209) |
| House drain | ¼ in per ft (2%) | *(rule of thumb)* |
| Shelter trench floor | ½ in per ft (4%) or more | [ORNL *Expedient Shelter*, p. 81](lib:expedient-shelter-handbook#page=81) |

A 60-ft drain at ¼ in per ft drops 15 in — check the outlet first.

**Measuring a slope:**
- **Board and level:** one end of a straight 4-ft board on the uphill ground; lift the other until a
  [spirit level](wiki:Spirit_level) reads level and measure the gap: 6 in ÷ 48 in = 12.5%. Step it downhill
  to add up a creek's drop ([🖼️ NRCan, p. 42](lib:nrcan-micro-hydropower-systems-a-buyers#page=42)).
- **Eye height and pace:** sight level from the bottom to the spot at your eye height and pace to it:
  eye 5½ ft ÷ (10 paces × 2½ ft) = 22% ([🖼️ FM 5-34, p. 148](lib:fm-5-34-engineer#page=148)).
- **Hand level or [Abney level](wiki:Topographic_Abney_level):** a hand level carries rough levels 400–500 ft with
  sights under 50 ft; an Abney reads percent ([🖼️ NRCS *Surveying*, p. 47](lib:nrcs-engineering-field-handbook-ch-1#page=47);
  [🖼️ p. 51](lib:nrcs-engineering-field-handbook-ch-1#page=51)).
- **Slope distance exceeds level distance:** 175.6 ft taped on a 30% slope = 168.2 ft level
  ([🖼️ p. 32](lib:nrcs-engineering-field-handbook-ch-1#page=32)).
- **A-frame level for contours** *(rule of thumb)*: two 6-ft poles in an "A" with a crossbar and a plumb
  line from the top. Mark where the string crosses the bar, flip it, mark again; halfway is level. Walk it
  across a hillside to stake a swale or terrace.
- **Angles at arm's length** *(rule of thumb — check yours)*: a finger about 2°, a fist about 10°, a spread
  hand about 20°.

📚 **Go deeper:** [FM 3-25.26, pp. 112–115](lib:fm-3-25-26-map#page=112) — percent, degrees, gradient; [FM 5-426, pp. 106–110](lib:fm-5-426-carpentry#page=106) — laying out rafters; [NRCS *Surveying*, p. 40](lib:nrcs-engineering-field-handbook-ch-1#page=40) — height from percent slope; [Stairs](wiki:Stairs).

## 🌲 Heights and distances you can't reach

**Shadows ([similar triangles](wiki:Similarity_(geometry))):** height = your height × tree's shadow ÷ your
shadow, at the same moment ([🖼️ Navy Vol. 1, p. 207](lib:navpers-10069#page=207)). You: 6 ft, 4½-ft
shadow; the fir's shadow 48 ft → 6 × 48 ÷ 4.5 = **64 ft**.

**Stick (45°) method** *(similar triangles)*: hold a stick upright at arm's length with as much above your
fist as from your eye to your fist. Back up until the fist lines up with the base and the stick top with
the treetop: your distance from the trunk ≈ the height. A cruiser's stick does the same with printed
marks ([🖼️ FB 1210, p. 14](lib:farm-timber#page=14); [Biltmore stick](wiki:Biltmore_stick)).

**Abney or clinometer (percent):** height = level distance × (top % − base %) ÷ 100, base negative if
below your eye. At 66 ft, top +110%, base −8%: 66 × 1.18 = **78 ft**. Felling: see the
[Firewood guide](guide:FIREWOOD-GUIDE).

**Width of a river:**
- **Compass:** at A, opposite tree B, read B's bearing; walk along the bank until it has changed by 45°.
  The distance walked = the width ([🖼️ FM 5-34, p. 162](lib:fm-5-34-engineer#page=162)).
- **No compass** *(geometry)*: from A pace 50 steps along the bank and plant a stick (C), 50 more to D;
  from D walk straight away from the river until C lines up with B. Those paces = the width.

**Thumb jump** *(rule of thumb)*: thumb at arm's length, close one eye then the other; it "jumps" along
the far hillside. Judge the jump from a known width (a 60-ft barn) and multiply by **10** — arm's length is
about ten times the space between your eyes. Check yours on a paced distance.

**Maps:** ground distance = map distance × the scale's bottom number ([FM 3-25.26, p. 44](lib:fm-3-25-26-map#page=44)):
on a 1:24,000 map, 1 in = 2,000 ft. The contour interval is in the margin ([p. 17](lib:fm-3-25-26-map#page=17)):
with a 40-ft interval, lines ¼ in apart = 40 ÷ 500 = **8%** (p. 113). More in the
[Navigation guide](guide:NAVIGATION-WEATHER-GUIDE).

📚 **Go deeper:** [Navy Vol. 1, ch. 19](lib:navpers-10069#page=206) — right triangles, with sine and tangent tables at [p. 220](lib:navpers-10069#page=220); [Navy Vol. 2, ch. 5](lib:navpers-10071#page=62) — solving any triangle; [FB 1210, pp. 8–14](lib:farm-timber#page=8) — measuring standing trees.

## 🏋️ Levers, pulleys and loads

**[Lever](wiki:Lever):** push × your side of the pivot = load × load side. The **mechanical advantage**
is how many times it multiplies your push — 10 lb lifting 100 lb is 10 ([FM 5-125, p. 105](lib:fm-5-125#page=105)).
A 6-ft bar with the pivot 6 in from the load: 5½ ÷ ½ = 11, so a 100-lb push lifts about 1,100 lb.

**[Block and tackle](wiki:Block_and_tackle):** count the rope lines holding the moving block — that's the
advantage ([FM 5-125, p. 110](lib:fm-5-125#page=110); [🖼️ p. 112](lib:fm-5-125#page=112)). Each sheave
adds friction of about **10% of the load** ([p. 114](lib:fm-5-125#page=114)); **pull = (load + friction) ÷
advantage** ([p. 115](lib:fm-5-125#page=115)). A 600-lb engine on 4 lines over 4 sheaves: (600 + 240) ÷ 4 =
**210 lb**. A person pulls about 100 lb straight down, 60 lb along the ground (same page): put three on it.

**Ramps** *(physics; friction adds more)*: push ≈ weight × height ÷ ramp length: a 500-lb log up a 12-ft
skid onto a 3-ft wagon bed takes 125 lb plus friction ([Bicycles & Carts guide](guide:BICYCLES-CARTS-GUIDE)).

**Rope:** safe load = breaking strength ÷ at least **4**; knots, sharp bends and age cut strength up to
50%. Fiber rope rule: **safe tons = diameter in inches squared** — ½-in rope = ¼ ton
([FM 5-125, p. 20](lib:fm-5-125#page=20)).

**Weights for guessing loads** (lb per cu ft, [FM 5-34, pp. 291–292](lib:fm-5-34-engineer#page=291)):

| Material | lb/cu ft | Material | lb/cu ft |
|---|---|---|---|
| Water / ice | 62.4 / 56 | Seasoned softwood / medium / hardwood | 25 / 40 / 55 |
| Earth, dry loose / damp packed | 76 / 96 | Hay and straw bales | 20 |
| Sand and gravel, wet | 118–120 | Common brick | 120 |
| Concrete | 144 | Gasoline / diesel | 42 / 53 |

Green wood is far heavier ([Firewood guide](guide:FIREWOOD-GUIDE)). Diesel is heavier than gasoline: about
7.1 lb per gallon × 7.48 = 53 lb per cu ft *(computed)*, so a full 55-gallon drum of diesel is about 390 lb.

📚 **Go deeper:** [FM 5-125, pp. 105–120](lib:fm-5-125#page=105) — blocks, tackle, hoists, winches; [Navy Vol. 2, ch. 7](lib:navpers-10071#page=99) — forces in balance; [Mechanical advantage](wiki:Mechanical_advantage).

## ⚡ Electricity by the numbers

- **Watts = volts × amps** ([NEETS 1, p. 120](lib:neets-module-01#page=120)): a 12-V pump drawing 5 A uses 60 W.
- **[Ohm's law](wiki:Ohm's_law): volts = amps × ohms** — cover the one you want on the circle
  ([🖼️ NEETS 1, p. 116](lib:neets-module-01#page=116)). A 12-ohm heater on 120 V draws 10 A = 1,200 W.
- **Watt-hours = watts × hours**; 1,000 Wh = 1 kWh ([p. 126](lib:neets-module-01#page=126)). The pump 2
  hours a day = 120 Wh.
- **Battery energy = volts × amp-hours.** A 12-V, 100-Ah battery is 1,200 Wh on the label, but size a
  lead-acid bank on only 40% of that ([IEA, p. 17](lib:iea-pvps-lead-acid#page=17)): 480 Wh → the pump
  for 4 days.
- **Long wires waste power:** volts lost = 2 × one-way feet × amps × ohms per 1,000 ft ÷ 1,000. Use the
  [Off-Grid guide](guide:OFF-GRID-POWER-GUIDE)'s wire table ([Voltage drop](wiki:Voltage_drop)).
- **1 horsepower = 746 W** ([NIST SP 811, p. 62](lib:nist-sp-811#page=62)).

📚 **Go deeper:** [NEETS Module 1, ch. 3](lib:neets-module-01#page=109) — Ohm's law, power and energy with practice questions; [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE) — load lists and battery sizing.

## 💧 Water flow and pressure

- **Flow by bucket and stopwatch:** a 5-gallon bucket in 20 seconds = 5 ÷ 20 × 60 = **15 gpm**; a
  55-gallon drum in 40 seconds = 82.5 gpm ([NCAT, p. 3](lib:ncat-attra-micro-hydro#page=3)).
- **Pressure from height ([head](wiki:Hydraulic_head)):** each foot of water = **0.433 psi**
  ([DOE, p. 113](lib:doe-microhydropower-handbook-vol-1-part-1#page=113)); each psi = **2.31 ft**
  ([NRCan, p. 41](lib:nrcan-micro-hydropower-systems-a-buyers#page=41)). A tank 40 ft above the house gives
  17 psi before pipe friction; 60 psi on a gauge at the bottom of a full hose = 139 ft of drop
  ([🖼️ DOE, p. 114](lib:doe-microhydropower-handbook-vol-1-part-1#page=114)).
- **Suction lift has a hard limit:** **21.2 ft at 1,000 ft elevation, 20.4 ft at 2,000 ft**
  ([USDA FB 1448, p. 28](lib:farmstead-water-supply#page=28)). At our ~1,300 ft keep a suction pump within
  about 20 ft of the water; deeper, the pump goes down the well. A [siphon](wiki:Siphon) has the same limit.
- **Creek power:** watts ≈ gpm × feet of head ÷ 10, about what NCAT's table of typical outputs shows
  ([NCAT, p. 9](lib:ncat-attra-micro-hydro#page=9)): 30 gpm falling 50 ft ≈ 150 W, day and night. Pipes, summer flow, water law: [Off-Grid guide](guide:OFF-GRID-POWER-GUIDE).

📚 **Go deeper:** [USDA FB 1448, pp. 27–28](lib:farmstead-water-supply#page=27) — pressure and suction tables; [NRCan, pp. 41–44](lib:nrcan-micro-hydropower-systems-a-buyers#page=41) — measuring head and flow; [Micro hydro](wiki:Micro_hydro).

## 💊 Food, medicine and time math

**A year's food:** people × calories a day × days, at **2,100 kcal per person a day** and about **1,500
kcal per pound of dry grain** ([Food Security guide](guide:FOOD-SECURITY-GUIDE)): 4 × 2,100 × 365 =
3,066,000 kcal ≈ 2,000 lb of grain-equivalent for a family of 4. **Days of supply = stock ÷ daily use:**
50 lb of flour at 1½ lb a day = 33 days.

> ### ⚠️ Medicine arithmetic — read this first
> - **Use only doses printed in the medical books** ([Medical guide](guide:Medical-READ-ME-FIRST);
>   [WTND green pages](lib:where-there-is-no-doctor-24-green-pages)). This is arithmetic only.
> - **Write the unit on every number** — mg, mL, kg. Mixing mg and mL, or lb and kg, kills.
> - **A second person redoes it** without seeing yours. If the answers differ, stop.
> - **Never measure medicine in drops** or with unchecked kitchen spoons.

**Dose by weight (mg/kg):** kg = lb ÷ 2.2 ([WTND ch. 8, p. 4](lib:where-there-is-no-doctor-08#page=4));
mg = mg per kg × kg. *Made-up numbers, not a real dose for any medicine:* 10 mg/kg for a 44-lb child:
44 ÷ 2.2 = 20 kg; 20 × 10 = **200 mg**; from a liquid with 100 mg in 5 mL: 200 ÷ 100 × 5 = **10 mL**.
Dosing an overweight child by actual weight can give far too much
([WHO Formulary, p. 15](lib:who-model-formulary-2008#page=15)).

**Spoons:** 1 tsp = 5 mL, 1 Tbsp = 15 mL. Household spoons vary — mark one at exactly 5 mL of water from
a syringe ([🖼️ WTND ch. 8, p. 3](lib:where-there-is-no-doctor-08#page=3)). **Drops are unreliable:** two
books here put 64 ([USU, p. 20](lib:food-storage-for-emergencies#page=20)) and 75
([Henley's, p. 706](lib:henleys#page=706)) drops in a teaspoon, before the dropper or liquid changes.

**Time:** "every 8 hours" = 3 times a day; "every 6 hours" = 4.

📚 **Go deeper:** [WTND ch. 8](lib:where-there-is-no-doctor-08#page=1) — grams, milligrams, spoons, child doses; [*Food and Nutrition Needs in Emergencies*](lib:food-and-nutrition-needs-in-emergencies#page=11) — adjusting calories; [Field Care guide](guide:FIELD-CARE-GUIDE).

## 🧾 Quick-reference tables (print these)

From [NIST HB 44, pp. 17–28](lib:nist-handbook-44#page=17) (US units), [NIST SP 811, pp. 57–68](lib:nist-sp-811#page=57)
(metric factors) and [Navy Vol. 1, p. 227](lib:navpers-10069#page=227).

| Length | | Area | |
|---|---|---|---|
| 1 in | 2.54 cm (exact) | 1 sq ft | 144 sq in |
| 1 ft | 12 in = 0.3048 m | 1 sq yd | 9 sq ft |
| 1 rod | 16½ ft | 1 acre | 43,560 sq ft = 0.405 ha |
| 1 chain | 66 ft = 4 rods | 1 hectare | 2.471 acres |
| 1 mile | 5,280 ft = 1.609 km | 1 sq mile | 640 acres |
| 1 m | 3.281 ft = 39.37 in | | |

| Volume | | Kitchen | |
|---|---|---|---|
| 1 cu ft | 1,728 cu in = 7.48 gal | 3 tsp | 1 Tbsp (15 mL) |
| 1 cu yd | 27 cu ft | 16 Tbsp | 1 cup (8 fl oz, 237 mL) |
| 1 US gallon | 4 qt = 128 fl oz = 3.785 L | 2 cups | 1 pint |
| 1 liter | 1.057 qt | 1 tsp | 5 mL |
| 1 bushel | 4 pecks = 1.244 cu ft | 1 Imperial gallon | 1.2 US gallons |
| 1 cord | 128 cu ft | 1 acre-foot | 43,560 cu ft |

| Weight | | Pressure and energy | |
|---|---|---|---|
| 1 lb | 16 oz = 0.4536 kg | 1 ft of water | 0.433 psi |
| 1 kg | 2.205 lb | 1 psi | 2.31 ft water = 6.895 kPa |
| 1 oz | 28.35 g | Air at sea level | 33.9 ft water = 14.7 psi |
| 1 short ton | 2,000 lb | 1 kWh | 3,412 BTU |
| 1 g | 1,000 mg | 1 horsepower | 746 W |
| 1 gal water | 8.34 lb | 1 food Calorie | 4.184 kJ |

**Temperature** ([HB 44, p. 23](lib:nist-handbook-44#page=23)): **°F = °C × 1.8 + 32**; **°C = (°F − 32) ÷ 1.8**.

| °F | 0 | 32 | 40 | 50 | 70 | 98.6 | 140 | 165 | 212 | 250 |
|---|---|---|---|---|---|---|---|---|---|---|
| °C | −17.8 | 0 | 4.4 | 10 | 21.1 | 37 | 60 | 73.9 | 100 | 121.1 |

(Air pressure: [FB 1448, p. 28](lib:farmstead-water-supply#page=28), [USBR, p. 276](lib:usbr-water-measurement-manual#page=276).)

📚 **Go deeper:** [NIST HB 44 Appendix C](lib:nist-handbook-44) — every US unit, down to pecks and apothecary measures; [FM 5-34, pp. 296–308](lib:fm-5-34-engineer#page=296) — nail sizes, soil, trig and metric tables; [United States customary units](wiki:United_States_customary_units).

## ⚠️ Old advice in the library to ignore

- **A child's aspirin dose by formula** ([Hospital Corpsman, p. 240](lib:hospital-corpsman#page=240)):
  no aspirin for children with fever, flu or chickenpox (Reye's syndrome,
  [WHO children's formulary, p. 39](lib:who-model-formulary-for-children#page=39)); use the books'
  weight-based doses, not formulas.
- **White-lead and red-lead paint and their spreading rates** ([Household Discoveries, p. 344](lib:household-discoveries#page=344);
  [Wood-Frame House, p. 194](lib:wood-frame-house-construction#page=194)): lead is poison. Don't mix it;
  wet-scrape, don't sand, old paint.
- **Drop tables** ([Henley's, p. 706](lib:henleys#page=706)) are for flavoring syrup, not medicine.
- **The Doyle log rule and 1950s prices** ([FB 1210, pp. 6–7](lib:farm-timber#page=6)): the bulletin
  itself says Doyle undercounts logs under 28 in.
- **Slide rules and log tables** ([Navy Vol. 1, ch. 8](lib:navpers-10069#page=87)): not wrong, just slow.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Measuring and marking**
- Pacing; the measuring wheel — [🖼️ NRCS *Surveying*, p. 33](lib:nrcs-engineering-field-handbook-ch-1#page=33)
- Equal parts on a line — [🖼️ Navy Vol. 1, p. 197](lib:navpers-10069#page=197)
- Hand level, Abney level, clinometer — [🖼️ NRCS *Surveying*, p. 47](lib:nrcs-engineering-field-handbook-ch-1#page=47), [🖼️ p. 51](lib:nrcs-engineering-field-handbook-ch-1#page=51); [Inclinometer](wiki:Inclinometer)

**Layout and geometry**
- 3-4-5 corner with strings; bisecting an angle — [🖼️ Navy Vol. 1, p. 199](lib:navpers-10069#page=199)
- Bisecting a line; a square corner at any point — [🖼️ p. 198](lib:navpers-10069#page=198)
- Center of a circle; an ellipse — [🖼️ p. 200](lib:navpers-10069#page=200)

**Areas and volumes**
- Rectangle, circle, triangles — [🖼️ NRCS *Quantity Computations*, p. 15](lib:quantity-computations#page=15)
- Trapezoid — [🖼️ Navy Vol. 1, p. 194](lib:navpers-10069#page=194)
- Prism, cylinder, cone — [🖼️ NRCS, p. 17](lib:quantity-computations#page=17), [🖼️ Navy Vol. 1, p. 203](lib:navpers-10069#page=203); [Cylinder](wiki:Cylinder)
- Every formula on one page — [🖼️ FM 5-34, p. 300](lib:fm-5-34-engineer#page=300)
- Cord of wood; log-scale stick — [🖼️ FB 1210, p. 17](lib:farm-timber#page=17), [🖼️ p. 18](lib:farm-timber#page=18); [Board foot](wiki:Board_foot)
- Concrete slab step by step — [🖼️ Hesperian ch. 7, p. 20](lib:hesperian-community-guide-to-environmental-health-ch-7#page=20); [Concrete](wiki:Concrete)

**Slope, heights and distances**
- Slope diagram; percent and degrees — [🖼️ FM 3-25.26, p. 112](lib:fm-3-25-26-map#page=112), [🖼️ p. 114](lib:fm-3-25-26-map#page=114)
- Slope by eye height and pace — [🖼️ FM 5-34, p. 148](lib:fm-5-34-engineer#page=148)
- Plank-and-level and Abney methods — [🖼️ NRCan, p. 42](lib:nrcan-micro-hydropower-systems-a-buyers#page=42)
- Slope versus level distance — [🖼️ NRCS *Surveying*, p. 32](lib:nrcs-engineering-field-handbook-ch-1#page=32)
- Tree height by shadows — [🖼️ Navy Vol. 1, p. 207](lib:navpers-10069#page=207)
- Cruiser's stick; homemade calipers — [🖼️ FB 1210, p. 14](lib:farm-timber#page=14), [🖼️ p. 12](lib:farm-timber#page=12), [🖼️ p. 13](lib:farm-timber#page=13); [Hypsometer](wiki:Hypsometer)
- River width by compass; stream speed by float — [🖼️ FM 5-34, p. 162](lib:fm-5-34-engineer#page=162)

**Loads, power, water and doses**
- Tackle systems — [🖼️ FM 5-125, p. 112](lib:fm-5-125#page=112), [🖼️ p. 107](lib:fm-5-125#page=107); [Block and tackle](wiki:Block_and_tackle)
- Ohm's law circle — [🖼️ NEETS 1, p. 116](lib:neets-module-01#page=116)
- Head by pressure gauge — [🖼️ DOE, p. 114](lib:doe-microhydropower-handbook-vol-1-part-1#page=114)
- A spoon marked at 5 mL — [🖼️ WTND ch. 8, p. 3](lib:where-there-is-no-doctor-08#page=3); [Teaspoon](wiki:Teaspoon)

---

## 🔗 Related guides

- [Unit converter & calculators](guide:UNIT-CONVERTER) — does these sums for you
- [Navigation & Weather](guide:NAVIGATION-WEATHER-GUIDE) — pace count, maps, compass
- [Shelter & Building](guide:SHELTER-BUILDING-GUIDE) — carpentry, roofs, chimneys
- [Water Wells](guide:WATER-WELLS-GUIDE) — casing, pumps, cisterns
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) — batteries, wire sizes, creek hydro
- [Firewood](guide:FIREWOOD-GUIDE) — cords, felling distances
- [Food Security](guide:FOOD-SECURITY-GUIDE) — calories and rationing
