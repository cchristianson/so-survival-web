# 🫙 Preserving Food Without a Freezer

How to keep a garden, a deer or a run of salmon through the year with no power: canning, jars and lids
when the stores are gone, jam, pickles and sauerkraut, drying, jerky and pemmican, smoking and salting
fish, curing meat, and keeping lard, eggs and vinegar. The books are in `Food-Storage\` (`Canning`,
`Curing-Smoking`, `Drying`, `Fermenting-Eggs-Vinegar`), the USDA canning guides in `Gardening-Food\`,
game and fish canning in `Hunting\` and `Fishing\`, and vinegar, lard and pork in
`Homestead-Skills\Food-Crafts-Tools`. Cellar storage is in the [Root Cellar guide](guide:ROOT-CELLAR-GUIDE);
how much to put up is in the [Food Security guide](guide:FOOD-SECURITY-GUIDE).

> ### ⚠️ Rules that prevent botulism and poisoning
> - **You can't see, smell or taste botulism.** Meat, fish, poultry, milk, beans and every vegetable
>   except most tomatoes are **low-acid**. They go in jars **only in a pressure canner**. There is **no
>   tested way** to can them without one, so dry, ferment, salt or cellar them instead.
> - **Use a tested recipe, set for our elevation (about 1,300 ft):** the **15-lb weight** or **11 lb on a
>   dial** for pressure canning; water-bath times **plus 5 minutes**.
> - **Boil home-canned meat and vegetables 11 minutes** before anyone tastes them.
> - **Never taste a suspect jar.** Bulging lid, leaks, spurting, bad smell or mold: detoxify it and throw it
>   out. Low-acid jars can be deadly **with no signs at all**.
> - **Weigh curing nitrite exactly.** Too much is poison.
> - **Smoke and drying don't cook food.** Cold-smoked fish is raw. Jerky must reach **160 °F**.

---

## ☠️ Botulism: why low-acid food needs a pressure canner

*[Clostridium botulinum](wiki:Clostridium_botulinum)* spores are on most fresh food. Sealed in a jar of moist, low-acid food at 40–120 °F
with no air, they can make a deadly toxin in **3–4 days**
([USDA Guide 1, p. 6](lib:home-canning-2015-guide-1#page=6)). The food can look, smell and taste normal
([PNW 361, p. 2](lib:pnw361#page=2)).

| Acid foods (pH 4.6 or lower) | Low-acid foods |
|---|---|
| Fruit, jam, pickles, sauerkraut, tomatoes **with acid added** | Meat, fish, poultry, milk, beans, every fresh vegetable, most soups and stews |
| Boiling-water or steam canner | **Pressure canner only** |

The spores die only at 240–250 °F, which takes a pressure canner ([🖼️ what one looks like](lib:caring-for-your-pressure-canner#page=4)). A boiling-water canner would need 7–11
hours, and no such times have been tested ([USDA Guide 1, p. 8](lib:home-canning-2015-guide-1#page=8)).

**Signs of [botulism](wiki:Botulism)**, usually 18–36 hours after eating: double or blurred vision, drooping
eyelids, slurred speech, trouble swallowing, dry mouth and weakness, then paralysis spreading down to the
breathing muscles ([FDA *Bad Bug Book*, p. 110](lib:fda-bad-bug-book#page=110)). Bad cases need weeks on a
breathing machine, so **prevention is everything**. No honey for babies under 12 months
([p. 111](lib:fda-bad-bug-book#page=111)).

**Boil before eating:** 10 minutes plus 1 minute per 1,000 ft above 1,000 ft, so **11 minutes here**, timed from
a full boil. This destroys the toxin, not the spores ([PNW 361, p. 2](lib:pnw361#page=2)).

**No pressure canner? Don't can low-acid food at all.** Keep beans, corn and grain dry and roots in the cellar;
ferment or salt vegetables; jerk, cure or salt meat; salt, dry, or smoke-and-can fish; and keep animals alive
until you need them *(general practice)*.

Canned fruit, tomatoes, vegetables and meat need no sugar or salt for safety, only flavor
([USDA Guide 1, p. 31](lib:home-canning-2015-guide-1#page=31)). Jam, pickles and ferments do.

📚 **Go deeper:** [USDA Guide 1, p. 8](lib:home-canning-2015-guide-1#page=8) — acid, heat and why the pressure canner; [FDA *Bad Bug Book*, p. 110](lib:fda-bad-bug-book#page=110) — botulism symptoms; [Wikipedia: Home canning](wiki:Home_canning).

## 🏔️ Settings for the Illinois Valley (about 1,300 ft)

| What | Setting here | Source |
|---|---|---|
| Weighted-gauge pressure canner ([🖼️ dial vs. weighted](lib:pnw361#page=3)) | **15-lb weight** (above 1,000 ft) | [PNW 421, p. 12](lib:caring-for-your-pressure-canner#page=12) |
| Dial-gauge pressure canner | **11 lb** up to 2,000 ft; **12 lb** at 2,001–4,000 ft | [PNW 421, p. 12](lib:caring-for-your-pressure-canner#page=12) |
| Boiling-water canner | Sea-level time **+ 5 minutes** | [PNW 652, p. 15](lib:boiling-water-canning-project-manual#page=15) |
| Sterilizing empty jars | Boil **11 minutes** | [USDA Guide 1, p. 15](lib:home-canning-2015-guide-1#page=15) |
| Jelly point, no added pectin | **About 217–218 °F** | [USDA Guide 7, p. 5](lib:home-canning-2015-guide-7#page=5) |

**Example pressure times here** (15-lb weight or 11-lb dial):

| Food | Pints | Quarts |
|---|---|---|
| Snap beans | 20 min | 25 min |
| Beets | 30 min | 35 min |
| Meat or venison chunks | 75 min | 90 min |
| Meat stock | 20 min | 25 min |
| [Salmon](wiki:Salmon) or [steelhead](wiki:Rainbow_trout) (**no liquid added**) | 100 min | 160 min, **only with Guide 5's special quart steps** (3 quarts water, 20-min heat-up, 10-min vent) ([Guide 5, pp. 11–12](lib:home-canning-2015-guide-5#page=11)) |
| Lightly smoked fish | 110 min | not tested |

([USDA Guide 4, p. 9](lib:home-canning-2015-guide-4#page=9); [Guide 5, p. 7](lib:home-canning-2015-guide-5#page=7);
[PNW 194, p. 5](lib:pnw194#page=5); [PNW 450, p. 3](lib:canning-smoked-fish#page=3).)

**Tomatoes need added acid, even in a pressure canner:** per quart, 2 Tbsp bottled lemon juice or ½ tsp citric
acid (half that per pint). **Never can tomatoes from frost-killed vines**, which matters after our October frosts
([USDA Guide 3, p. 5](lib:home-canning-2015-guide-3#page=5)). Stockpile [citric acid](wiki:Citric_acid); it keeps for years dry. When
it's gone, **[sun-dry tomatoes](wiki:Sun-dried_tomato) in August** *(general practice)*.

📚 **Go deeper:** [USDA Guide 4](lib:home-canning-2015-guide-4#page=9) — every vegetable, with altitude columns; [Guide 5](lib:home-canning-2015-guide-5#page=7) — meat, game and fish; [PNW 361](lib:pnw361) — canning venison and game.

## ♨️ Running a pressure canner off-grid

**Choose a weighted-gauge canner.** It never needs testing. A dial gauge must be tested yearly; one reading
high gives unsafe food ([PNW 421, p. 5](lib:caring-for-your-pressure-canner#page=5)). The canner must hold
at least **4 quart jars**.

**Every batch** ([USDA Guide 1, pp. 20–22](lib:home-canning-2015-guide-1#page=20); [PNW 421, p. 9](lib:caring-for-your-pressure-canner#page=9); [🖼️ step-by-step drawing](lib:caring-for-your-pressure-canner#page=10)):
1. 2–3 inches of hot water, or **4–5 inches for fish and other long processes**. Jars on the rack ([🖼️ photo](lib:pnw361#page=4)).
2. Lock the lid, weight off. Heat until steam pours out, then **vent a full 10 minutes**. Put the weight on.
3. Start timing when the weight jiggles. **If pressure ever drops below the target, bring it back up and
   start the whole time over.**
4. Turn off the heat and let it cool by itself. **Never cool it with water.** At zero pressure, take off the
   weight, **wait 10 minutes**, and open the lid away from your face.

**On a wood stove, campfire or outdoor burner there is no tested method.** Canner makers forbid outdoor LP
burners and any burner over 12,000 BTU. In Utah State tests, canners **boiled dry within minutes and warped**,
and cold outdoor air breaks jars and spoils seals
([WSU flyer, p. 1](lib:pressure-canning-and-camp-stoves#page=1)). Never "can" in any oven
([PNW 361, p. 2](lib:pnw361#page=2)).

If a wood range is your only heat *(general practice: untested, so the risk is yours)*:
- Water-bath canning works if you hold a full rolling boil and restart the timer whenever it stops
  ([USDA Guide 1, p. 18](lib:home-canning-2015-guide-1#page=18)).
- For pressure canning, **practice first with jars of plain water**. Use 4–5 inches of water. Control heat by
  **sliding the canner** between hotter and cooler parts of the stovetop, not by adding wood. Restart the
  timer every time pressure dips. Never walk away.
- If you can't hold steady pressure, don't can low-acid food.

**Care** ([PNW 421, pp. 6–8, 12](lib:caring-for-your-pressure-canner#page=6)): stock **spare gaskets and safety
(overpressure) plugs** now ([🖼️ where they sit](lib:caring-for-your-pressure-canner#page=4)). Replace a gasket that's worn, stretched or hardened. Small steam leaks are fine if
pressure holds; add extra water. Clean the vent with a string. Store it dry, lid upside down, not locked.

| If this goes wrong | Do this |
|---|---|
| Steam pouring out at the lid | Replace the gasket |
| Jars under-processed (boiled dry, lost the time) | Reprocess within 24 hours with new lids for the full time, or throw them out ([PNW 450, p. 4](lib:canning-smoked-fish#page=4)) |
| A jar didn't seal | New lid and reprocess within 24 hours, or keep it cold and eat it within days ([USDA Guide 1, p. 26](lib:home-canning-2015-guide-1#page=26)) |

📚 **Go deeper:** [PNW 421 *Using and Caring for Your Pressure Canner*](lib:caring-for-your-pressure-canner#page=5) — gauges, gaskets and plugs; [PNW 653 *Pressure Canning Project Manual*](lib:pressure-canning-project-manual) — step-by-step lessons; [Wikipedia: Pressure cooking](wiki:Pressure_cooker).

## 🥫 Jars, lids, storage and spoilage

- **[Mason jars](wiki:Mason_jar) last for years; only the flat lid must be new** ([🖼️ jar, lid, sealing compound and band](lib:put-a-lid-on-it#page=1)). Throw out chipped jars
  ([PNW 361, p. 3](lib:pnw361#page=3)). Mayonnaise-type jars are for acid foods in a water bath only, never a
  pressure canner ([USDA Guide 1, p. 13](lib:home-canning-2015-guide-1#page=13)).
- **One-time metal lids shouldn't be reused.** Opening warps them and the sealing compound is spent. Unused lids
  keep about **5 years**, so stockpile them. Buy from the maker; many other sellers' lids were poor in 2021
  ([FN2028, p. 1](lib:put-a-lid-on-it#page=1)).
- **Reusable plastic lids with rubber rings** (the Tattler type) sealed safely in tests reported by NDSU
  Extension. Follow the maker's directions exactly, which may include tightening the band as soon as the jar
  comes out ([FN2028, p. 1](lib:put-a-lid-on-it#page=1)).
- **If you must reuse a one-time lid** *(general practice, not tested)*: **only on high-acid jars** (jam, fruit,
  pickles, kraut), where failure shows as mold or fizzing, not hidden toxin. **Never on low-acid food.**

**Test seals after 12–24 hours**, bands off. Press the middle: if it springs back, it's not sealed. Tap with a
teaspoon: a ringing note means sealed; a dull one means not ([USDA Guide 1, p. 25](lib:home-canning-2015-guide-1#page=25); [🖼️ photo](lib:pnw361#page=5)).

**Store** cool, dark and dry, **50–70 °F, never above 95 °F**; best quality within a year, though sealed jars
stored this way stay safe longer ([pp. 6, 12, 26](lib:home-canning-2015-guide-1#page=26); [FN2028, p. 1](lib:put-a-lid-on-it#page=1)). Attics, sheds and garages here pass 95 °F in summer, so use the
cellar or under the house *(general practice)*.

**Throw it out** if the lid is loose or bulging, food has streaked down the jar, bubbles rise, the liquid is cloudy
or spurts, it smells bad, or there's mold ([USDA Guide 1, pp. 26–27](lib:home-canning-2015-guide-1#page=26)). Also
badly dented, bulging, rusty or leaking store cans
([USU, p. 40](lib:food-storage-for-emergencies#page=40)).

**Getting rid of a suspect jar** ([USDA Guide 1, p. 27](lib:home-canning-2015-guide-1#page=27)):
1. Gloves on. Lay jars and lids on their sides in a big pot, cover with water, and **boil 30 minutes**. Then discard.
2. Wipe every surface with **1 part bleach to 5 parts water**, leave 30 minutes, and do it again.

📚 **Go deeper:** [FN2028 *Put a Lid On It*](lib:put-a-lid-on-it#page=1) — one-time and reusable lids; [USDA Guide 1, p. 26](lib:home-canning-2015-guide-1#page=26) — storage and spoilage.

## 🍑 Water-bath and steam canning; jam without pectin

**Water bath** ([USDA Guide 1, p. 18](lib:home-canning-2015-guide-1#page=18); [🖼️ illustrated steps](lib:steam-canning-how-to-guide#page=1)): keep 1–2 inches of water over the
jars. Start timing at a hard boil; if the boil stops, start over. At the end, take the lid off, wait 5 minutes,
lift the jars out, and leave them alone 12–24 hours.

**Steam canner (saves fuel and water):** approved **for acid foods only**, using a tested boiling-water recipe.
The total time must be **45 minutes or less**. Vent until a full column of steam shows, and **never open it to
add water** ([K-State MF3241, p. 2](lib:steam-canning-how-to-guide#page=2)).

**[Jam and jelly](wiki:Fruit_preserves) without bought [pectin](wiki:Pectin):**
- Apples, crab apples, [gooseberries](wiki:Ribes_uva-crispa), some plums and grapes have their own pectin; strawberries, cherries and
  blueberries don't. For jelly, use **¾ ripe and ¼ under-ripe** fruit
  ([USDA Guide 1, p. 29](lib:home-canning-2015-guide-1#page=29)).
- **Berry jam:** 4 cups crushed berries and 4 cups sugar makes 3–4 half-pints. Boil hard to **217–218 °F**, or
  until two drops run together off a cool spoon. Process **10 minutes** here
  ([USDA Guide 7, p. 6](lib:home-canning-2015-guide-7#page=6); [PNW 652, p. 26](lib:boiling-water-canning-project-manual#page=26)).
  [Feral blackberries](wiki:Rubus_armeniacus) ripen by the bucketful in July and August *(general practice)*.
- **Don't cut the sugar.** Too little gives a weak gel, mold and yeast ([USDA Guide 1, p. 30](lib:home-canning-2015-guide-1#page=30)).

📚 **Go deeper:** [PNW 652 *Boiling Water Canning Project Manual*](lib:boiling-water-canning-project-manual#page=15) — fruit, tomatoes, jam and jelly step by step; [USDA Guide 7](lib:home-canning-2015-guide-7#page=5) — tested jams and jellies; [Wikipedia: Fruit preserves](wiki:Fruit_preserves).

## 🥒 Pickles, sauerkraut and other ferments

| | Vinegar pickles | Fermented pickles and kraut |
|---|---|---|
| Needs | Store **5% vinegar**, tested recipe | **Salt** only |
| Homemade vinegar? | **No.** Its strength is unknown | Not needed |
| Long term | Ends when vinegar runs out | **The way to go** *(general practice)* |

Never change a tested recipe's amounts, and never cut the salt in a ferment
([USDA Guide 1, p. 28](lib:home-canning-2015-guide-1#page=28)).

**[Sauerkraut](wiki:Sauerkraut)** ([USDA Guide 6, pp. 6–8](lib:home-canning-2015-guide-6#page=6)):
- **25 lb cabbage to ¾ cup canning salt** (3 Tbsp per 5 lb), within 24–48 hours of harvest. A 1-gallon [crock](wiki:Crock_(dishware)) per 5 lb ([🖼️ crocks and jars](lib:making-fermented-pickles-and-sauerkraut#page=5)).
- Weight it with a sealed bag of brine (3 quarts water + 4½ Tbsp salt), so a leak won't weaken the brine. Keep it
  under brine; top up with 1½ Tbsp salt per quart of water.
- **3–4 weeks at 70–75 °F, or 5–6 weeks at 60–65 °F.** Below 60 °F it may not ferment; above 75 °F it goes soft.
  October–November rooms here sit near 60–65 °F *(general practice)*.
- To can it: hot pack, **15 minutes** for pints, 20 for quarts here.

**[Fermented dill pickles](wiki:Pickled_cucumber)**, per gallon: 4 lb of 4-inch cucumbers, ½ cup salt, ¼ cup 5% vinegar, 8 cups water,
dill. 3–4 weeks at 70–75 °F; skim scum often. **Soft, slimy or bad-smelling: throw them out**
([USDA Guide 6, p. 7](lib:home-canning-2015-guide-6#page=7)).

**Any vegetable** ([K-State MF3491, p. 2](lib:taking-a-new-look-at-fermented-foods#page=2)): dry-salt shredded
vegetables with **1 Tbsp non-iodized salt per 2 lb**, or brine chunks in **1 tsp salt per cup of water** (2 tsp for
cucumbers or peppers). Keep them weighted under brine at 60–70 °F.

**Heavy salting, no fermenting (1918):** 15–25% brine keeps beans, beets, corn, chard and cabbage until spring.
Soak in fresh water to remove the salt, then cook ([1918 bulletin, p. 7](lib:preserving-vegetables-by-salting#page=7)).

📚 **Go deeper:** [USDA Guide 6](lib:home-canning-2015-guide-6#page=6) — tested kraut and pickle recipes; [K-State MF3491](lib:taking-a-new-look-at-fermented-foods#page=2) — salt for any vegetable; [Wikipedia: Lactic acid fermentation](wiki:Lactic_acid_fermentation).

## ☀️ Drying in our dry summers

Trays and solar dryers are in the [Root Cellar guide](guide:ROOT-CELLAR-GUIDE).
- **Sun drying** needs about 90 °F, low humidity and clean air. A **solar dryer** ([🖼️ USDA solar drier](lib:farm-and-home-drying#page=16); [🖼️ brick-and-plastic dryer plan](lib:a-simple-solar-dryer#page=2)) is dependable with 3–5 days in
  a row near 95 °F, which is an ordinary July to September here ([PNW 651, p. 16](lib:drying-project-manual#page=16)).
- **Not in wildfire smoke.** Bring trays in when smoke settles in the valley *(general practice)*.
- **Dries well** ([photos](wiki:Dried_fruit)): apples, pears, plums, cherries, peaches, grapes, [huckleberries](wiki:Vaccinium_ovatum). Not blackberries.
- **No [sulfite](wiki:Sulfite) dips** for anyone with asthma ([p. 18](lib:drying-project-manual#page=18)).
- **[Fruit leather](wiki:Dried_fruit)** from windfalls: heat the purée to 160 °F first ([p. 20](lib:drying-project-manual#page=20)).
- **Done?** Pack it loosely in covered jars 2–4 days, shaking daily. Moisture on the lid means dry it more
  ([p. 18](lib:drying-project-manual#page=18)).
- **Kill insect eggs** before storing: 160 °F for 30 minutes *(general practice)*.

📚 **Go deeper:** [PNW 651 *Drying Project Manual*](lib:drying-project-manual#page=16) — fruit by fruit; [Wikipedia: Food drying](wiki:Food_drying).

## 🥩 Jerky and pemmican

**Safe [jerky](wiki:Jerky)** ([PNW 632](lib:pnw632#page=8)):
1. Slice lean meat into strips.
2. **Bring it to 160 °F** (poultry 165 °F): dip strips 1½–2 minutes in simmering brine before drying
   ([p. 17](lib:pnw632#page=17)), or heat dried strips 10 minutes at 275 °F ([p. 9](lib:pnw632#page=9); [🖼️ photo](lib:pnw632#page=14)).
3. **Dry at 145–155 °F**, checked with a thermometer ([🖼️ which kind](lib:pnw632#page=11)), until a cooled strip cracks but doesn't snap
   ([p. 18](lib:pnw632#page=18); [🖼️ photo](lib:pnw632#page=18)).
4. Keep it sealed; it's best within **1–2 months** ([p. 21](lib:pnw632#page=21)).

Don't sun-dry meat ([USU, p. 59](lib:food-storage-for-emergencies#page=59)). **Bear and cougar carry
[trichinosis](wiki:Trichinosis)**; ten people caught it from cougar jerky ([PNW 632, p. 8](lib:pnw632#page=8)).

**[Pemmican](wiki:Pemmican):** lean meat dried by sun, wind or smoke (not salt-cured), pounded, and mixed with hot
rendered fat. About **6 lb of meat makes 1 lb**, and it keeps for years, depending on the fat
([Special Forces handbook, p. 174](lib:special-forces-medical-handbook#page=174)). There's no modern tested
recipe, so *(general practice)*: do the 160 °F step, then dry the meat brittle; render the fat until it stops
bubbling; use about equal weights of meat and fat; firm [tallow](wiki:Tallow) (deer, elk, beef) keeps better than lard; fully dry
any berries. Store it cool, dark and airtight; throw it out if rancid or sour.

📚 **Go deeper:** [PNW 632 *Making Jerky at Home Safely*](lib:pnw632#page=8) — tested methods and the hot-brine dip; [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — jerky basics.

## 🐟 Fish: smoking, canning and salting

| | Cold smoke | Hot smoke |
|---|---|---|
| Heat | [Smokehouse](wiki:Smokehouse) under 80–90 °F | **150 °F inside the fish (160 °F better) for 30+ minutes** |
| Cooked? | **No. It's raw** | Yes |
| Keeps | Only if heavily salted and long-smoked | About **2 weeks, refrigerated** |

**Hot smoking** ([PNW 238, pp. 1–3](lib:pnw238#page=1)): brine 2–3 lb of fish in **1 cup salt to 7 cups water** for
about an hour; let a tacky skin (pellicle) form; smoke with hardwood, **never fir, pine or cedar** ([🖼️ smoker layout](lib:pnw238#page=3)). Here, use [red
alder](wiki:Alnus_rubra), [bigleaf maple](wiki:Acer_macrophyllum), [oak](wiki:Oak) or fruitwood *(general practice)*.

**[Smoke](wiki:Smoking_(cooking)) alone doesn't preserve.** With no refrigerator, **can it**
([PNW 450, pp. 1–3](lib:canning-smoked-fish#page=1)):
1. Smoke lightly, up to 2 hours, to about **10% weight loss** (weigh a piece before and after). **Don't eat it
   yet.**
2. Can it **the same day**: pints, no liquid. This recipe uses **4 quarts of cool water** in the canner; don't
   heat it or use less ([p. 3](lib:canning-smoked-fish#page=3)). Vent 10 minutes, then **110 minutes** at the
   15-lb weight or 11-lb dial.

**The old way, no canner** ([🖼️ a small fish smokehouse](lib:a-practical-small-smokehouse#page=5); [🖼️ its plan](lib:a-practical-small-smokehouse#page=11)): 24 hours of cold smoke keeps fish about 2 weeks; longer keeping takes 5+ days of
smoke at or below 90 °F ([Fishery Leaflet 18, p. 15](lib:home-preservation-of-fishery-products#page=15)). Our
summers are too hot, so cold-smoke October to April, when fall [Chinook](wiki:Chinook_salmon) and winter steelhead run. In fire season,
smoke only on bare ground with water at hand *(general practice)*.

**[Salting fish](wiki:Salted_fish)** ([Fishery Leaflet 18, pp. 2–7](lib:home-preservation-of-fishery-products#page=2)):
- Bleed, gut and clean the fish well. To hold it a day with no ice, rub in about 1 Tbsp salt per ¾ lb and keep
  it under wet burlap in the shade. Rolled in salt, it keeps about 10 days; soak it 10 hours before cooking.
- **Dry salting keeps longer than brine** and suits warm weather. Brined fish keeps up to 9 months if you change
  the brine at 3 months. Dried salt fish ([what it looks like](wiki:Dried_and_salted_cod)) is done when a thumb leaves no dent in the thick part.
- No modern guide tests long-term salting of fatty salmon. Treat it as an old-time method and cook it well.

📚 **Go deeper:** [PNW 238 *Smoking Fish at Home Safely*](lib:pnw238#page=1) — brines and temperatures; [PNW 450 *Canning Smoked Fish*](lib:canning-smoked-fish#page=1) — shelf-stable smoked fish.

## 🥓 Curing pork and venison

**Cold is the key:** **36–40 °F for the whole cure.** Warmer risks spoilage; colder slows the salt
([USDA Leaflet 273, p. 5](lib:curing-pork-country-style#page=5)), and curing stops below 34 °F
([NDSU, p. 4](lib:wild-side-of-the-menu-3#page=4)). Cure **December to early February**, when nights here fall to
the low 30s *(general practice)*. A ham is in trouble only if its inside stays above 40–45 °F for 3–4 days running
([Kentucky, p. 3](lib:how-to-make-a-country-ham#page=3); [🖼️ parts of a ham](lib:dry-curing-virginia-style-ham#page=1); [🖼️ cuts of pork](lib:farmers-bulletin-1186#page=17)).

| Cure (weigh it) | Amounts | Time | Source |
|---|---|---|---|
| [Country ham](wiki:Country_ham) ([🖼️ rubbing in the cure](lib:how-to-make-a-country-ham#page=3)) | 8 lb salt + 2 lb sugar per 100 lb. **Never more sugar than salt** | 2 days per lb | [Kentucky, p. 2](lib:how-to-make-a-country-ham#page=2) |
| [Nitrite](wiki:Sodium_nitrite) dry cure | 8 lb salt, 3 lb sugar, 2 oz sodium nitrate, ½ oz sodium nitrite. 1 oz mix per lb of meat (1½ oz over 20 lb). Bacon: half the nitrite, and leave out the nitrate (USDA doesn't allow nitrate in bacon) | 7 days per inch | [MSU P2648, p. 1](lib:curing-pork-products-at-home#page=1) |
| Venison dry cure | Per 100 lb: 6 lb salt, 3 lb sugar, and 3 oz nitrate **or** 1 oz nitrite, rubbed on in thirds (days 1, 7, 14) | 2 days per lb at 38 °F (4–6 weeks). A sweet-pickle brine instead: 3 days per lb | [NDSU, p. 4](lib:wild-side-of-the-menu-3#page=4) |
| Plain salt | 1 part salt to 3 parts meat, strips 1 inch thick or less, weighted in a tub | Cook it thoroughly | [CVM, p. 90](lib:slaughter-and-preservation-of-meat#page=90) |

- "Too much nitrate and nitrite can be toxic" ([MSU P2648, p. 1](lib:curing-pork-products-at-home#page=1)). Pink
  premixes ([curing salt](wiki:Curing_salt)): **Cure #1** (6.25% nitrite) for short cures, **Cure #2** (with nitrate) for long dry cures. Follow the
  label, commonly 1 level tsp Cure #1 per 5 lb of meat, and store it away from table salt and children
  *(general practice)*.
- A sweet-pickle brine should just float an egg. If it turns ropy, take the meat out and boil or replace the brine
  ([NDSU, p. 4](lib:wild-side-of-the-menu-3#page=4)).
- Barrel-salted meat (12–18% salt) keeps 3–4 months at room temperature
  ([Practical Action, p. 4](lib:practical-action-cured-meat-products#page=4)). Salt doesn't kill all germs or
  parasites ([CVM, p. 91](lib:slaughter-and-preservation-of-meat#page=91)).

**Smoke and store:**
- Smoke cured pork with hardwood (never pine) at **100–120 °F** ([Leaflet 273, p. 8](lib:curing-pork-country-style#page=8); [🖼️ farm smokehouse plans](lib:smokehouses-and-hog-slaughtering#page=8)).
  Cold smoke stays **under 100 °F** (70–80 °F best) for 1–5 days; spoilage bacteria grow fast at 80–110 °F
  ([MSU P2648, p. 2](lib:curing-pork-products-at-home#page=2)).
- In spring, hold hams at 50–60 °F so the salt evens out ([Kentucky, p. 5](lib:how-to-make-a-country-ham#page=5)).
- Smoked country hams keep a year or more in a dry, dark, airy place; trim off surface mold ([🖼️ what it looks like](lib:how-to-make-a-country-ham#page=6)). Eat bacon by early
  summer ([USDA FB 1186, p. 31](lib:farmers-bulletin-1186#page=31)).
- **Throw it out** if it smells sour at the bone or has wet patches and holes through the meat
  ([Special Forces handbook, p. 173](lib:special-forces-medical-handbook#page=173)).

📚 **Go deeper:** [Kentucky *How to Make a Country Ham*](lib:how-to-make-a-country-ham#page=2) — modern step by step; [MSU P2648](lib:curing-pork-products-at-home#page=1) — the nitrite cure and smoking; [NDSU](lib:wild-side-of-the-menu-3#page=4) — venison cures; [Wikipedia: Curing](wiki:Curing_(food_preservation)).

## 🥚 Lard, confit, eggs and vinegar

- **[Lard](wiki:Lard):** render slowly at 235–245 °F and don't let it scorch. The fuller the rendering, the less water and the better it keeps
  ([Minnesota, p. 3](lib:making-lard-at-home#page=3)). Steps are in [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE).
- ⚠️ **[Confit](wiki:Confit) and potted meat** (meat sealed under lard) are airless and low-acid, exactly what
  botulism needs. No method is tested. Use them only short-term in a cold winter cellar, and boil before eating
  *(general practice)*.
- **Eggs:** fresh, clean, uncracked spring eggs, wiped not washed, in **1 quart water glass
  ([sodium silicate](wiki:Sodium_silicate)) to 9 quarts boiled, cooled water**, 2 inches over them, or in clear
  [limewater](wiki:Calcium_hydroxide) (2 lb lime in 5 gallons boiled water). Prick the shell before boiling
  ([USDA 1935, pp. 3–4](lib:home-methods-of-preserving-eggs#page=3)). USDA says 6–9 months, FAO only 1–6
  ([FAO, p. 83](lib:small-scale-poultry-production-technical-guide-fao#page=83)); plan on the shorter.
- **[Vinegar](wiki:Vinegar):** yeast turns fruit juice to alcohol in 4–6 days. Then add 1 part unpasteurized vinegar to 4 parts
  juice, leave it open under cheesecloth at 70 °F or warmer, and don't disturb the
  "[mother](wiki:Mother_of_vinegar)." It takes 3–6 months ([USDA FB 1424, pp. 9–12](lib:farmers-bulletin-1424#page=9); [🖼️ barrel "converter"](lib:farmers-bulletin-1424#page=12)).
  Only a [titration](wiki:Titration) test proves its strength ([p. 30](lib:farmers-bulletin-1424#page=30)), so use it for cooking,
  **never for canned pickles**.

📚 **Go deeper:** [USDA *Home Methods of Preserving Eggs*](lib:home-methods-of-preserving-eggs#page=3) — water glass and lime; [USDA FB 1424 *Making Vinegar*](lib:farmers-bulletin-1424#page=9).

## ⚠️ Old advice in the library to ignore

- **Open-kettle canning:** jars "filled to overflowing," turned upside down, never processed, even vegetables
  ([Henley, p. 605](lib:henleys-twentieth-century#page=605); [Household Discoveries, p. 542](lib:household-discoveries#page=542),
  [p. 544](lib:household-discoveries#page=544)), and **cotton batting or mutton suet** "as if hermetically sealed"
  ([p. 549](lib:household-discoveries#page=549)). **Instead:** process every jar
  ([USDA Guide 1, p. 10](lib:home-canning-2015-guide-1#page=10)).
- **Oven canning:** jars can seal and explode, and the food never gets hot enough
  ([FB 1186, p. 37](lib:farmers-bulletin-1186#page=37)). **Instead:** a pressure canner.
- **Paraffin seals** on jam (mold toxins; [USDA Guide 1, p. 30](lib:home-canning-2015-guide-1#page=30)), on kraut
  fermented at 86 °F ([FB 1438, p. 14](lib:making-fermented-pickles-and-sauerkraut#page=14)) and on smoked fish
  ([Fishery Leaflet 18, p. 2](lib:home-preservation-of-fishery-products#page=2)). **Instead:** process jam; ferment
  at 60–75 °F under brine.
- **Borax, boric acid, salicylic acid** (the folk "aspirin in the jar" trick) and salts up to 40% saltpeter
  ([Henley, p. 363](lib:henleys-twentieth-century#page=363)). Poisons. **Instead:** heat, acid and salt by a tested recipe.
- **"10:1 table salt and saltpeter,"** about ten times modern levels
  ([Special Forces handbook, p. 174](lib:special-forces-medical-handbook#page=174)). **Instead:** the MSU amounts or a premix label.
- **Hot-smoking fish in 130–150 °F air for 2–3 hours**
  ([Fishery Leaflet 18, p. 14](lib:home-preservation-of-fishery-products#page=14)). **Instead:** 150–160 °F *inside*
  the fish for 30 minutes ([PNW 238, p. 2](lib:pnw238#page=2)).
- **Jerky dried at 120 °F with no heat step**, "almost indefinitely" keeping
  ([NDSU, p. 5](lib:wild-side-of-the-menu-3#page=5)), and **sun-dried jerky**
  ([Special Forces handbook, p. 174](lib:special-forces-medical-handbook#page=174)). **Instead:** the 160 °F step.
- **Half-fried chops sealed under lard** "until required" ([Household Discoveries, p. 589](lib:household-discoveries#page=589)).
  **Instead:** cold-cellar winter use only, boiled, or pressure-can the meat.
- **"Steam canners are not currently recommended"** ([USDA Guide 1, p. 10](lib:home-canning-2015-guide-1#page=10))
  is **out of date**. They're approved for acid foods ([K-State MF3241, p. 2](lib:steam-canning-how-to-guide#page=2)).

📚 **Go deeper:** [USDA Guide 1, p. 10](lib:home-canning-2015-guide-1#page=10) — the methods USDA rejects, and why; [K-State MF3241, p. 2](lib:steam-canning-how-to-guide#page=2) — the current rules for steam canners.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Canners, jars and lids**
- Parts of a pressure canner (gauge, vent, safety plug, gasket) — [🖼️ PNW 421, p. 4](lib:caring-for-your-pressure-canner#page=4); [Pressure cooking](wiki:Pressure_cooker)
- Pressure canning step by step — [🖼️ PNW 421, p. 10](lib:caring-for-your-pressure-canner#page=10)
- Dial-gauge and weighted-gauge canners — [🖼️ PNW 361, p. 3](lib:pnw361#page=3)
- Jars on the rack in the canner — [🖼️ PNW 361, p. 4](lib:pnw361#page=4)
- Two-piece lid: jar, flat lid, sealing compound, band — [🖼️ FN2028, p. 1](lib:put-a-lid-on-it#page=1); [Mason jar](wiki:Mason_jar)
- Testing jars for a seal — [🖼️ PNW 361, p. 5](lib:pnw361#page=5)
- Water-bath canning, illustrated — [🖼️ K-State MF3241, p. 1](lib:steam-canning-how-to-guide#page=1); [Home canning](wiki:Home_canning)
- The botulism germ — [Clostridium botulinum](wiki:Clostridium_botulinum)

**Jam, pickles and kraut**
- Jam and jelly — [Fruit preserves](wiki:Fruit_preserves); [Pectin](wiki:Pectin)
- Wild fruit for jam — [Himalayan blackberry](wiki:Rubus_armeniacus); [Gooseberry](wiki:Ribes_uva-crispa)
- Stoneware crocks and jars for brining — [🖼️ USDA FB 1438, p. 5](lib:making-fermented-pickles-and-sauerkraut#page=5); [Crock](wiki:Crock_(dishware))
- Sauerkraut and fermented dill pickles — [Sauerkraut](wiki:Sauerkraut); [Pickled cucumber](wiki:Pickled_cucumber)

**Drying, jerky and pemmican**
- Solar drier with screened trays — [🖼️ USDA FB 984, p. 16](lib:farm-and-home-drying#page=16)
- Cookstove drier for rainy days — [🖼️ USDA FB 984, p. 19](lib:farm-and-home-drying#page=19)
- Brick-and-plastic solar dryer plan — [🖼️ Practical Action, p. 2](lib:a-simple-solar-dryer#page=2)
- Solar cabinet and tent dryers — [🖼️ Practical Action *Solar Drying*, p. 2](lib:solar-drying-cabinet-tent-and-tunnel-dryers#page=2)
- Dried fruit and fruit leather — [Dried fruit](wiki:Dried_fruit); [Fruit leather](wiki:Dried_fruit); [Sun-dried tomato](wiki:Sun-dried_tomato)
- Thermometers for jerky — [🖼️ PNW 632, p. 11](lib:pnw632#page=11)
- Jerky that cracks but doesn't snap — [🖼️ PNW 632, p. 18](lib:pnw632#page=18); [Jerky](wiki:Jerky)
- Pemmican — [Pemmican](wiki:Pemmican); [Tallow](wiki:Tallow)

**Fish**
- Hot smoker layout — [🖼️ PNW 238, p. 3](lib:pnw238#page=3)
- Small fish smokehouse and its plan — [🖼️ Bureau of Fisheries, p. 5](lib:a-practical-small-smokehouse#page=5); [🖼️ p. 11](lib:a-practical-small-smokehouse#page=11); [Smokehouse](wiki:Smokehouse)
- Smoking woods: red alder and bigleaf maple — [Alnus rubra](wiki:Alnus_rubra); [Acer macrophyllum](wiki:Acer_macrophyllum)
- Chinook salmon and steelhead — [Chinook salmon](wiki:Chinook_salmon); [Rainbow trout](wiki:Rainbow_trout)
- Salted and dried fish — [Salted fish](wiki:Salted_fish); [Dried and salted cod](wiki:Dried_and_salted_cod)

**Ham, bacon and the smokehouse**
- Parts of a ham — [🖼️ Virginia Tech 458-223, p. 1](lib:dry-curing-virginia-style-ham#page=1)
- Cuts of pork — [🖼️ USDA FB 1186, p. 17](lib:farmers-bulletin-1186#page=17)
- Rubbing in the cure, wrapping and bagging — [🖼️ Kentucky, p. 3](lib:how-to-make-a-country-ham#page=3); [🖼️ p. 4](lib:how-to-make-a-country-ham#page=4); [Country ham](wiki:Country_ham)
- Mold on an aging ham — [🖼️ Kentucky, p. 6](lib:how-to-make-a-country-ham#page=6)
- Farm smokehouse firebox plan — [🖼️ USDA AWI-68, p. 8](lib:smokehouses-and-hog-slaughtering#page=8)
- Brine gauge (salometer) — [🖼️ Practical Action, p. 6](lib:practical-action-cured-meat-products#page=6)

**Lard, eggs and vinegar**
- Lard — [Lard](wiki:Lard)
- Water glass and limewater for eggs — [Sodium silicate](wiki:Sodium_silicate); [Limewater](wiki:Calcium_hydroxide)
- Vinegar barrel "converter" and quick generator — [🖼️ USDA FB 1424, p. 12](lib:farmers-bulletin-1424#page=12); [🖼️ p. 14](lib:farmers-bulletin-1424#page=14); [Mother of vinegar](wiki:Mother_of_vinegar)

---

## 🔗 Related guides

- [Root Cellar guide](guide:ROOT-CELLAR-GUIDE) — cool storage, solar dryers and smokehouses
- [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — rendering lard, salt from seawater, jerky
- [Food Security guide](guide:FOOD-SECURITY-GUIDE) — how much to put up, and rationing it
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — getting game and fish home cold
- [Rabbits & Chickens](guide:RABBITS-CHICKENS-GUIDE) — spring eggs and meat to preserve
- [Field Care guide](guide:FIELD-CARE-GUIDE) — food poisoning with no hospital
