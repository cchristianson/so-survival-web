# 🐐 Milk Goats, Home Dairy & Bees

How to keep dairy goats healthy with no vet or feed store, get clean milk and keep it without a fridge,
turn it into butter, ghee, yogurt, kefir and cheese, and keep honey bees for honey and wax. The books are
in `Animals\Goats-Sheep`, `Animals\Dairy-Cheese`, `Animals\Bees` and `Animals\Veterinary`, with the old farm
butter and cheese bulletins in `Homestead-Skills\Food-Crafts-Tools` and milk cooling in
`Food-Storage\Cooling-Without-Power`.

> ### ⚠️ Rules that prevent the worst outcomes
> - **Raw milk can carry brucellosis, tuberculosis and Listeria** (which causes miscarriage). Pasteurize
>   milk for children, pregnant women, the old and the sick: **145 °F for 30 minutes, or 161 °F for
>   15 seconds**, then cool it fast ([UMN, p. 1](lib:pasteurization-of-milk-at-home#page=1)).
> - **Never give honey to a baby under 1 year** — infant botulism
>   ([FDA *Bad Bug Book*, p. 108](lib:fda-bad-bug-book-2nd-edition-foodborne-pathogens-and-natural-toxins-incl-mushroom-toxins-2012#page=108)).
> - **Never feed hedge or garden trimmings.** Yew kills before any sign shows; rhododendron, azalea and
>   oleander poison goats ([WSU, p. 2](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=2)).
> - **Oregon is short of selenium.** Keep a covered selenium goat mineral out all year, and **never let
>   sheep eat goat mineral** — its copper poisons them.
> - **Shut goats in every night** (cougars) and **put an electric fence around the hives** (black bears).
> - **Anyone who has had a whole-body reaction to a sting** must not work bees without epinephrine at hand.

---

## 🐐 Choosing and feeding milk goats

**What to expect:** a doe giving about **1,000 lb (about 500 quarts) in a 10-month lactation is a fair
milker**; 1,600 lb or more is excellent ([USDA FB 920, p. 5](lib:milk-goats-usda-farmers-bulletin-920#page=5)).
That is about **1½ quarts a day** *(our arithmetic)*. Two does bred a few months apart keep milk coming
all year *(rule of thumb)*.

**Breeds** ([FB 920, p. 10](lib:milk-goats-usda-farmers-bulletin-920#page=10)): [Saanen](wiki:Saanen_goat),
[Toggenburg](wiki:Toggenburger), [Nubian](wiki:Anglo-Nubian) and [Alpine](wiki:Alpine_goat)
([🖼️ Saanen](lib:milk-goats-usda-farmers-bulletin-920#page=12), [🖼️ Toggenburg](lib:milk-goats-usda-farmers-bulletin-920#page=14),
[🖼️ Nubian](lib:milk-goats-usda-farmers-bulletin-920#page=15), [🖼️ Alpine](lib:milk-goats-usda-farmers-bulletin-920#page=17)). Nubians give
the richest milk, best for butter and cheese. [LaMancha](wiki:American_Lamancha) and the small
[Nigerian Dwarf](wiki:Nigerian_Dwarf) are newer *(rule of thumb)*.

**Feeding** ([FB 920, pp. 25–26](lib:milk-goats-usda-farmers-bulletin-920#page=26)):
- Goats **browse**: they prefer leaves, twigs and weeds to grass.
- **Grain: about 1 lb for every 3–4 lb of milk.**
- **One doe for a year:** about 500 lb of hay and 450 lb of grain with 6 months of pasture; about twice
  the hay with none. One acre of good pasture carries 2–3 goats for a 5–6-month season.
- **House the buck away from milking does** — his smell gets into the milk.

**Here** *(rule of thumb)*: pasture browns from June to the October rains and winter is mud, so plan hay
for **both**. Browse: blackberry, willow, maple and oak leaves. Goats eat [poison oak](wiki:Toxicodendron_diversilobum); its oil rubs off
their coats onto your hands. Change feed slowly, over 7–10 days.

**Plants that kill goats** — mostly hungry goats in unfamiliar brush (the "where" column is local
knowledge, *rule of thumb*):

| Plant | Where | What happens |
|---|---|---|
| [Western azalea](wiki:Rhododendron_occidentale), rhododendron, laurel | Along valley creeks and serpentine meadows; gardens | Drooling, vomiting (rare in goats — a red flag), bloat, tremors, collapse; activated charcoal may help ([WSU, p. 15](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=15)) |
| [Pacific yew](wiki:Taxus_brevifolia), garden yew | Shady creek forest; hedges | Often fatal before any sign ([AIB 415, p. 113](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=113)) |
| [Oleander](wiki:Nerium) | SW Oregon yards | All parts very poisonous ([OSU, p. 12](lib:osu-fire-resistant-shrubs-and-trees-for-privacy-in-sw-oregon#page=12)) |
| [Chokecherry](wiki:Prunus_virginiana), cherry | Wilted or frosted leaves | Cyanide ([AIB 415, p. 26](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=26)) |

📚 **Go deeper:** [USDA FB 920 *Milk Goats*](lib:milk-goats-usda-farmers-bulletin-920#page=25) — breeds, rations, housing; [USDA AIB 415](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=113) — western poisonous plants in color.

## 🏠 Fences, shelter and minerals

- **Fences:** no barbed wire. Field fence traps horned heads. Electric works once goats are trained: two hot
  wires held mature does but not kids ([OSU EC1646, pp. 1–2](lib:getting-started-with-sheep-and-goats-osu-ec1646#page=1)).
- **Shelter:** a dry three-sided shed with fresh air but no drafts, and something to climb
  ([🖼️ shelter](lib:getting-started-with-sheep-and-goats-osu-ec1646#page=1), [🖼️ climbing structure](lib:getting-started-with-sheep-and-goats-osu-ec1646#page=2)). Keep goats dry
  and out of cold wind ([FB 920, p. 35](lib:milk-goats-usda-farmers-bulletin-920#page=35)).
- **[Cougars](wiki:Cougar):** shut goats in a shed or barn every night ([ODFW, p. 2](lib:oregon-is-cougar-country-odfw#page=2)).

**Selenium** ([OSU EM 9094, pp. 1–6](lib:selenium-supplementation-strategies#page=2)):
- Most Oregon livestock are low in selenium ([🖼️ map](lib:selenium-supplementation-strategies#page=2)). [White muscle disease](wiki:Nutritional_muscular_dystrophy)
  was first described here, in 1958. It strikes **kids 3–8 weeks old**: stiffness, trembling, weak hind
  legs, can't stand or suckle, heart failure. Low selenium also causes abortion, stillbirth and more mastitis.
- **Free-choice selenium mineral salt** is simplest. **Keep the feeder covered** — rain leaches selenium out.
- Injections (such as Bo-Se) need a vet, last under a month, and **an overdose kills**.
- **Stock a year or more of selenium goat mineral now** *(rule of thumb)*.

**Copper:** copper oxide wire particles help control [barber pole worm](wiki:Haemonchus_contortus) in goats, but **copper poisons
sheep**. Never feed goat mineral to sheep, and don't use low-copper sheep mineral for goats
([UF VM271, p. 2](lib:sheep-and-goat-parasite-management-uf-vm271#page=2)).

📚 **Go deeper:** [OSU EM 9094](lib:selenium-supplementation-strategies#page=4) — selenium salt vs injections; [OSU EC1646](lib:getting-started-with-sheep-and-goats-osu-ec1646#page=2) — fences and sheds.

## 🍼 Breeding, kidding and kids

| | What to know |
|---|---|
| Heat | Fall and early winter; every 18–21 days; lasts 24–36 hours. Bleating, tail wagging, swollen vulva, less milk ([Peace Corps Vol 4, p. 419](lib:peace-corps-livestock-training-manual-vol-4-1982#page=419)) |
| First breeding | Doelings at **7–8 months**, not earlier (same page) |
| Gestation | **146–152 days**; twins usual, triplets common ([FB 920, p. 24](lib:milk-goats-usda-farmers-bulletin-920#page=24)). Fall breeding = kids February–April *(rule of thumb)* |

**The first hour** ([KSU MF3689, pp. 11, 13](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=11)):
1. **"Clip, dip, strip, sip":** cut the navel cord under 2 inches and dip it in iodine; strip the wax plugs
   from the doe's teats; make sure the kid nurses.
2. **[Colostrum](wiki:Colostrum) within 30–60 minutes**, at least 10% of body weight: a 10-lb kid needs about 7 oz in the
   first hour and 16 oz over 24 hours, in 2–4-oz feeds ([🖼️ tube-feeding photos](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=12)).
3. **Kid under 99 °F? Warm it first** — a chilled kid can't absorb colostrum.
4. **Never pull on the afterbirth.** For a stuck kid see the [Langston guide](lib:lambing-and-kidding-assistance-langston)
   ([🖼️ normal and wrong positions](lib:lambing-and-kidding-assistance-langston#page=6); [🖼️ KSU drawings](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=6)).

**Bottle kids** ([FB 920, pp. 28, 31](lib:milk-goats-usda-farmers-bulletin-920#page=31)): warm (90–98 °F)
milk, as much as they drink readily — at least 1½–2 pints a day, often 2–3 — in 3 feeds, until 6 weeks; after 10 weeks hay and grain replace most of it;
wean at 3–4 months. Use the doe's milk for people only from the 4th–5th day after kidding.

**Disbudding** ([FB 920, p. 34](lib:milk-goats-usda-farmers-bulletin-920#page=34)):
1. In the first days of life, always before 3 weeks. On a naturally hornless kid the skin slides over the spot.
2. Heat a disbudding iron (or a ¾-inch steel pipe on a handle) cherry-red ([🖼️ where to burn](lib:peace-corps-livestock-training-manual-vol-4-1982#page=415)). Hold it on each bud 5–10 seconds,
   rotating, until a copper-colored ring shows. Keep it as short as you can: newer studies found brain injury
   in kids even at 5 seconds, so have someone experienced show you first.
3. Give tetanus antitoxin. Meloxicam (prescription) eases the pain
   ([KSU, p. 15](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=15)).

📚 **Go deeper:** [KSU MF3689](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=11) — kidding and newborn care; [Peace Corps Vol 4, p. 412](lib:peace-corps-livestock-training-manual-vol-4-1982#page=412) — disbudding and goat management. Pictures: [Livestock dehorning](wiki:Livestock_dehorning).

## 🩺 Goat health with no vet

| Problem | Signs | What to do |
|---|---|---|
| **[CAE](wiki:Caprine_arthritis_encephalitis)** | Swollen knees, wasting; a fatal brain form in kids. Spread by colostrum and milk | **No cure.** Buy test-negative goats. Take kids from infected does at birth; feed heat-treated colostrum and pasteurized milk ([Idaho, p. 1](lib:cae-caprine-arthritis-encephalitis#page=1)) — heat colostrum 1 hour at 135 °F *(rule of thumb)* |
| **[CL](wiki:Caseous_lymphadenitis)** | Lumps behind the ear, under the jaw, on neck, shoulder, flank or udder ([🖼️ abscess, in a sheep](lib:raising-healthy-sheep-cvm#page=109)). **The pus infects people too** | Isolate; lance and drain away from the herd; disinfect tools ([Idaho, p. 1](lib:cl-caseous-lymphadenitis#page=1)). Gloves; burn the bedding *(rule of thumb)* |
| **[Mastitis](wiki:Mastitis)** | Hot, hard, lopsided udder; watery, clotted or bloody milk | Milk that half out **4+ times a day**; warm wet cloths; antibiotics if you have them, then don't drink her milk for several days — at least the milk withdrawal time on the drug's label ([p. 176](lib:where-there-is-no-animal-doctor-cvm-2024#page=176)). **Never push straw or sticks up a teat** ([*No Animal Doctor*, p. 175](lib:where-there-is-no-animal-doctor-cvm-2024#page=175)) |
| **[Milk fever](wiki:Milk_fever)** | Around kidding: weak, cold to the touch, can't stand | Calcium gluconate under the skin in several places; into a vein only slowly, listening to the heart. No alfalfa-heavy feed late in pregnancy ([p. 289](lib:where-there-is-no-animal-doctor-cvm-2024#page=289)) |
| **Pregnancy toxemia** | Doe with twins or triplets, last weeks: stops eating, stands alone, presses head into walls | Propylene glycol by mouth, about 60 mL (2 oz) twice a day *(Merck Veterinary Manual)*. Prevent: no fat does, more grain late in pregnancy, exercise ([p. 291](lib:where-there-is-no-animal-doctor-cvm-2024#page=291)) |
| **Enterotoxemia** | Found dead after a sudden change to grain, lush grass or lots of milk | Treatment rarely works. **Vaccinate (CD&T)** pregnant does, and kids at 1 month with a booster ([pp. 213–214](lib:where-there-is-no-animal-doctor-cvm-2024#page=213)) |
| **[Bloat](wiki:Ruminal_tympany)** | Belly swollen, worst on the **left**; pain, after a feast of fresh green feed | Raise the front feet on a block; drench a cup of vegetable oil ([Peace Corps, p. 417](lib:peace-corps-livestock-training-manual-vol-4-1982#page=417); [🖼️ drench bottle](lib:peace-corps-livestock-training-manual-vol-4-1982#page=418)) |

**Worms and [FAMACHA](wiki:FAMACHA)** ([UF VM271, pp. 2–3](lib:sheep-and-goat-parasite-management-uf-vm271#page=2)):
1. Every 2–4 weeks, score the inner eyelid against the FAMACHA card (1 = red, 5 = white), and check back
   (body condition), rear (scours), jaw (bottle jaw) and nose ([🖼️ pale eyelid and bottle jaw, in sheep](lib:raising-healthy-sheep-cvm#page=119)).
2. **Deworm only the goats that need it.** 20% of goats carry 80% of the worms; treating all of them breeds
   resistant worms.
3. 80% of larvae live in the bottom 2 inches of forage: **don't graze short**. Rest pastures at least 30 days (it helps, but barber pole worm larvae can survive
   3–6 months on pasture, so resting alone won't clear them).
4. Goats browsing brush at head height pick up far fewer worms *(rule of thumb)*.

**Hooves:** trim every 4–6 weeks, wall level with the sole ([🖼️ hoof parts](lib:sheep-and-goat-hoof-trimming-msu-m2487#page=1);
[🖼️ trimming](lib:raising-healthy-sheep-cvm#page=77)). Wet winters bring **hoof rot** ([🖼️ photo](lib:raising-healthy-sheep-cvm#page=115); smelly,
contagious): dry pens, a 15–18% zinc sulfate foot bath, clean trimmers
([MSU M2487, p. 1](lib:sheep-and-goat-hoof-trimming-msu-m2487#page=1)).

📚 **Go deeper:** [*Where There Is No Animal Doctor*](lib:where-there-is-no-animal-doctor-cvm-2024#page=174) — no-vet livestock care; [*Raising Healthy Goats*](lib:raising-healthy-goats-cvm) — illustrated care (pictures only).

## 🥛 Clean milk: milking, cooling, pasteurizing

**Milking** ([Lincoln Univ, pp. 1–2](lib:dairy-goats-milking-the-sanitary-way-lincoln-univ#page=2); [🖼️ milking stand](lib:milk-goats-usda-farmers-bulletin-920#page=28)):
1. Clip the udder hair. Squirt the first milk into a strip cup and **look for clots every milking**.
2. Dip the teats; wipe each goat with **her own towel**. Milk without wringing the teats; dip again after.
3. Filter, and **chill to 38 °F within an hour**. Cold raw milk keeps 12–14 days.

**Cooling without power** ([USDA FB 976, pp. 6, 15](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=6);
[🖼️ cooling tank](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=7)):
a can of 85 °F milk set in **3 times its volume of 37 °F water** only gets to about 50 °F — use more water
and stir. Spring water is often as warm as 65 °F; check it with a thermometer. In our 95 °F summers, milk
you can't chill should become yogurt, cheese or ghee **the same day** *(rule of thumb)*.

**Why pasteurize:** raw milk and soft raw-milk cheeses spread [brucellosis](wiki:Brucellosis), TB and [Listeria](wiki:Listeriosis); hard, aged
cheeses are safer ([*Zoonoses*, p. 92](lib:zoonoses-diseases-animals-give-people-cvm#page=92)).
Young children should not get raw milk; yogurt resists contamination better
([WHO, p. 16](lib:guiding-principles-for-feeding-non-breastfed-children-6-24-months-who-2005#page=16)).
Plant poisons pass into milk too — lupine can cause birth defects in people
([WSU, p. 15](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=15)).

**[Pasteurizing](wiki:Pasteurization) at home** ([UMN, p. 1](lib:pasteurization-of-milk-at-home#page=1)):
1. Use a double boiler, or a pot set in a pan of water, so the milk doesn't scorch.
2. Heat to **145 °F and hold 30 minutes**, stirring, **or** to **161 °F for 15 seconds**. If it drops below
   145 °F, restart the 30 minutes *(rule of thumb)*. UMN's own home method has a safety margin: stir until an
   accurate thermometer reads **165 °F**, then cool at once.
3. **Cool it at once** in cold running water or ice water. Kept cold, it lasts 7–10 days.
4. No thermometer? Bring it just to a boil *(rule of thumb)*.

📚 **Go deeper:** [Lincoln *Milking the Sanitary Way*](lib:dairy-goats-milking-the-sanitary-way-lincoln-univ#page=1) — clean milking and the mastitis test; [USDA FB 976](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=6) — spring-water cooling tanks.

## 🧈 Cream, butter and ghee

**Goat cream barely rises**, and goat butter is pure white
([FB 920, p. 7](lib:milk-goats-usda-farmers-bulletin-920#page=7)), so **sour the whole milk and [churn](wiki:Butter_churn) it**.
Cow milk can be skimmed from a shallow pan 4 inches deep after 36 hours ([ILCA, p. 38](lib:rural-dairy-technology#page=38);
[🖼️ drawing](lib:rural-dairy-technology#page=38)).

**Butter from soured whole milk** ([ILCA, p. 60](lib:rural-dairy-technology#page=60)):
1. Let the milk sour until it tastes **pleasantly sour**. Fresh milk churns slowly and loses fat.
2. At **59–79 °F**, rock or shake it in a closed vessel until butter grains form
   ([🖼️ small churns](lib:butter-and-ghee-practical-action#page=3)). Colder can take 5 hours.

**Butter from cream** ([USDA FB 876, p. 23](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=23)):
ripen it at 65–75 °F until mildly sour, then churn at **52–66 °F** for 30–40 minutes until the grains are
wheat-sized. Drain the buttermilk ([🖼️ photo](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13)) and wash the butter twice. **Salted to 3%** (about ½ oz per pound *(our
arithmetic)*), butter keeps up to 4 months sealed, cool and dark ([ILCA, p. 49](lib:rural-dairy-technology#page=49)).

**[Ghee](wiki:Ghee) keeps a year without a fridge** ([Practical Action, p. 4](lib:butter-and-ghee-practical-action#page=4)):
1. Boil butter gently until the water is gone and the milk solids turn **golden brown**.
2. Let it settle; strain through boiled cheesecloth.
3. Store airtight, dark and cool — **not in iron or copper**, which speed rancidity. It keeps **more than
   12 months** at room temperature.

📚 **Go deeper:** [ILCA *Rural Dairy Technology*](lib:rural-dairy-technology#page=38) — village dairying with no power; [Practical Action *Butter and Ghee*](lib:butter-and-ghee-practical-action#page=4) — step by step.

## 🧀 Yogurt, kefir and cheese

**[Yogurt](wiki:Yogurt)** ([Practical Action, pp. 1–3](lib:soured-milk-and-yoghurt#page=1)):
1. Heat milk to **176–185 °F** and hold 15–20 minutes, stirring. Cool fast to **104–113 °F**.
2. Stir in **20–50 g of live yogurt per liter** (about 1½–3 tablespoons per quart *(our conversion)*).
3. Keep warm 4–6 hours — a [haybox](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5)
   or a cooler with jars of hot water works — then chill.
4. Keep a "mother culture" going; replace it if flavors go off.

**[Kefir](wiki:Kefir) needs no warm box** ([ILCA, p. 59](lib:rural-dairy-technology#page=59)): heat milk to
185 °F for 30 minutes and cool it, add kefir grains, and leave about 12 hours at room temperature (72 °F).
Reuse the grains; they multiply *(rule of thumb)*.

**Lemon or vinegar cheese** ([queso blanco](wiki:White_cheese), [paneer](wiki:Paneer)) ([ILCA, p. 50](lib:rural-dairy-technology#page=50);
[🖼️ step chart](lib:rural-dairy-technology#page=51)):
1. Heat milk to **180 °F**, or a simmer.
2. Stir in lemon juice, about **3 mL per 100 mL of milk** (about 2 tablespoons per quart *(our
   conversion)*), diluted with equal water — or vinegar. Curds form at once. Settle 15 minutes.
3. Drain in a cloth, salt, press overnight. Keeps about 3 days cold, 5 in brine
   ([Practical Action, p. 1](lib:cheese-making-practical-action#page=1)).

**[Cottage cheese](wiki:Cottage_cheese) with no bought culture** ([USDA FB 1451, pp. 6–7](lib:making-and-using-cottage-cheese#page=6)):
1. Let skim milk clabber at about 75 °F (about 30 hours) until clean and pleasantly sour.
2. Cut it in 2-inch pieces; set the pan in hot water to bring it to **100 °F**; hold about 30 minutes,
   stirring gently. Drain in a cloth, rinse cold, salt. A gallon makes about 1½ lb.
3. **Homemade starter:** set several boiled pint jars of fresh milk at 75 °F
   ([🖼️ starter jars](lib:making-and-using-cottage-cheese#page=7)). Keep the one that curdles in
   about 30 hours with a smooth curd and a clean, sharp sour taste, and carry it on daily.

**A simple rennet cheese** ([FB 920, p. 8](lib:milk-goats-usda-farmers-bulletin-920#page=8)): stir a junket
tablet dissolved in cold water into 1 gallon of milk at 88 °F. Cut the curd after 30 minutes, warm it to
98 °F, bag and press it ([🖼️ homemade lever press](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)), and rub with salt for several days. Ready at 10 days.

**Making your own [rennet](wiki:Rennet)** ([*Book of Cheese*, pp. 55–56](lib:the-book-of-cheese#page=56)):
1. Take the stomach of a young kid, lamb or calf that has had **nothing but milk**. Clean it, blow it up, dry it.
2. Cut it open and soak it in 3–5% salt water (about 4–7 oz salt per gallon *(our arithmetic)*) for days to weeks.
3. Filter, add more salt, and keep it **cool and dark** (stone jugs, colored glass) — light destroys it.
4. Strength varies and it can spoil: **test it on a small batch.**

**Aging** ([FB 1191, p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)):
a cellar at 50–60 °F is ideal. Turn cheeses daily and wipe off mold; coat them at 2 weeks (beeswax works);
eat from 6 weeks. **Cover cellar windows with cheesecloth** — the [cheese-skipper fly](wiki:Cheese_fly) gets through screen.

**Whey** ([*Book of Cheese*, p. 319](lib:the-book-of-cheese#page=319)): heat it to about 200 °F and skim the
curds that float — [ricotta](wiki:Ricotta). Boil the rest down to sweet brown [mysost](wiki:Brunost). Whey also feeds hens
and pigs *(rule of thumb)*, but **never feed raw milk to pigs** — it spreads TB
([*Zoonoses*, p. 27](lib:zoonoses-diseases-animals-give-people-cvm#page=27)).

📚 **Go deeper:** [Practical Action *Cheese Making*](lib:cheese-making-practical-action#page=2) — soft cheeses and plant coagulants; [USDA FB 1451](lib:making-and-using-cottage-cheese#page=7) — cottage cheese and starters; [*The Book of Cheese*](lib:the-book-of-cheese#page=55) — rennet, hard cheeses, curing rooms (old book: raw-milk methods).

## 🐝 Bees: hives, forage, swarms, feeding

| | [Top-bar hive](wiki:Horizontal_top-bar_hive) | [Langstroth hive](wiki:Langstroth_hive) |
|---|---|---|
| Building | From scrap; only the bar width must be exact; a strip of beeswax on each bar guides the comb | Precise carpentry and bought foundation |
| Harvest | Cut comb: honey and wax with **no extractor**; combs are fragile | Pays off with an extractor — empty combs go back in. A full deep frame holds about 5 lb |
| Source | [FAO, pp. 44–45](lib:bees-and-their-role-in-forest-livelihoods#page=44) | [AH 335, pp. 72–73](lib:beekeeping-in-the-united-states#page=73); [🖼️ plans](lib:beekeeping-in-the-united-states#page=53); [🖼️ cutaway](lib:beekeeping-in-the-united-states#page=54) |

**Forage and the summer dearth** ([AH 335, p. 21](lib:beekeeping-in-the-united-states#page=21) lists
western bee plants). Here *(rule of thumb)*: [manzanita](wiki:Arctostaphylos) and willow bloom
February–March, [bigleaf maple](wiki:Acer_macrophyllum) in April, and **blackberry in June–July is the main flow**. A **dearth** follows from late July to the fall rains, when robbing and
[yellowjackets](wiki:Yellowjacket) peak: **reduce entrances** ([🖼️ entrance reducer](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)), **never spill syrup or leave comb out** ([OSU EM 9186, p. 4](lib:osu-residential-beekeeping-best-practices-em-9186#page=4)),
and keep water within half a mile *(rule of thumb)*.

**[Swarms](wiki:Swarming_(honey_bee)) are free bees:**
- They come mostly **March–June**: the old queen and half the bees hang in a cluster for an hour or so
  ([AH 335, p. 38](lib:beekeeping-in-the-united-states#page=38); [🖼️ resting swarm](lib:osu-residential-beekeeping-best-practices-em-9186#page=4)). Swarming bees are full of honey and gentle ([Langstroth, p. 41](lib:langstroth-on-the-hive#page=41)).
- Shake the cluster into a box of old comb ([🖼️ hiving a swarm](lib:beekeeping-in-the-united-states#page=38)); close it at dusk. A bait hive of old dark comb catches swarms
  by itself *(rule of thumb)*.
- Your own colony swarms when it has **more than 6 frames of bees** and is crowded: **split it when swarm
  cells appear** ([OSU EM 9186, p. 11](lib:osu-residential-beekeeping-best-practices-em-9186#page=11); [🖼️ swarm cells](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)).
- Package bees from California will stop after a collapse, so swarms will be the only new bees
  ([p. 14](lib:osu-residential-beekeeping-best-practices-em-9186#page=14)).

**Feeding** ([AH 335, pp. 49–51](lib:beekeeping-in-the-united-states#page=51)): 1:1 sugar syrup in spring;
thick 2:1 for new colonies and fall stores; dry sugar on the inner cover in a late-winter emergency. Feed
late in the day with narrowed entrances. **Never feed honey from unknown hives** — it spreads disease.
A broodless colony eats about 4 lb of honey a month ([p. 72](lib:beekeeping-in-the-united-states#page=72));
the book's 90-lb winter store is for cold climates, and here plan on about **60 lb**: an average colony eats about that between the fall
and spring flows (p. 72), and our long summer dearth eats into stores too *(rule of thumb)*.

📚 **Go deeper:** [FAO *Bees and Forest Livelihoods*](lib:bees-and-their-role-in-forest-livelihoods#page=44) — building top-bar hives; [USDA AH 335](lib:beekeeping-in-the-united-states#page=38) — swarming, feeding, wintering.

## 🦠 Bee health: varroa and foulbrood

**[Varroa mites](wiki:Varroa_destructor) are the main killer**; unchecked they double every month
([HBHC, p. 5](lib:tools-for-varroa-management#page=5); [🖼️ mites on bees and larvae](lib:honey-bee-diseases-and-pests#page=20)). Here they peak in August–September, as the winter
bees are raised *(rule of thumb)*.

**Counting mites** ([HBHC, pp. 9–10](lib:tools-for-varroa-management#page=10)):
1. Shake bees from 1–3 brood frames (**not the one with the queen**) into a tub.
2. Scoop **½ cup (about 300 bees)** into a jar of rubbing alcohol or soapy water, shake, and count the mites.
3. Mites ÷ 300 × 100 = mites per 100 bees. **Treat at 1+ in winter and spring, 2+ in summer and fall.**

**Controls with nothing bought** ([pp. 39–40](lib:tools-for-varroa-management#page=39)): cut out capped
[drone](wiki:Drone_(bee)) brood 2–3 times in spring, or force a **brood break** by caging the queen 1–2 weeks or making a split.

**[Oxalic acid](wiki:Oxalic_acid) dribble** ([p. 29](lib:tools-for-varroa-management#page=29)): **35 g, weighed** (roughly 2⅓ level tablespoons if you have no scale *(rule of thumb)*) in
1 liter of 1:1 syrup; **5 mL on the bees in each occupied gap** between combs, **50 mL at most per
colony**, best with no capped brood (late fall, winter). **Corrosive: gloves and goggles. Vaporizing it is
extremely dangerous.** Stockpile pure oxalic acid dihydrate now *(rule of thumb)*.

**[American foulbrood](wiki:American_foulbrood) (AFB)** — the disease that means burning:
- **Signs:** spotty brood; sunken, darker, pierced cappings; foul smell ([FAO 2006, p. 10](lib:honey-bee-diseases-and-pests#page=10);
  [🖼️ dead larvae in cells](lib:beekeeping-in-the-united-states#page=126)).
- **Matchstick test:** push a matchstick into a dead larva and draw it out slowly. About **an inch of ropy
  brown goo** means AFB ([FAO Forest, p. 150](lib:bees-and-their-role-in-forest-livelihoods#page=150); [🖼️ photo](lib:honey-bee-diseases-and-pests#page=11)).
- **Then:** burn combs, frames, honey and dead bees in a pit about 3 ft deep and fill it in; scorch the inside
  of the boxes until slightly brown. Shaking the bees onto clean new combs can save them
  ([FAO 2006, p. 11](lib:honey-bee-diseases-and-pests#page=11)).

📚 **Go deeper:** [HBHC *Tools for Varroa Management*](lib:tools-for-varroa-management#page=9) — mite counts and every treatment; [FAO *Honey Bee Diseases and Pests*](lib:honey-bee-diseases-and-pests#page=10) — photos of brood diseases, mites and wax moth.

## 🍯 Honey, wax, bears and stings

**Honey with no extractor** ([FAO Forest, p. 91](lib:bees-and-their-role-in-forest-livelihoods#page=91);
[Practical Action, p. 3](lib:honey-processing-practical-action#page=3)): take **only sealed comb** and
leave winter stores. Cut it as comb honey, or crush it and strain through coarse, then fine, cloth.
Keep everything **bone-dry** — honey over 19–20% water ferments. Don't heat it; crystallized honey is fine.

**[Beeswax](wiki:Beeswax)** ([FAO Forest, pp. 112–113](lib:bees-and-their-role-in-forest-livelihoods#page=112)):
melt comb **in water**, strain through sacking, and let the wax cake float and set; repeat through finer
cloth. A solar melter (a black box with a glass lid) also works. **Wax is highly flammable — never heat it
dry over a flame** ([🖼️ double boiler](lib:practical-action-candlemaking-technical-brief#page=3)). Beeswax candles need a thicker wick than tallow
([Practical Action, p. 2](lib:practical-action-candlemaking-technical-brief#page=2)).

**Bear fence** ([UF ENY-2060, pp. 1–5](lib:building-bear-fences#page=3)): bears come for the brood,
and come back. Run three electric wires at **8, 20 and 32 inches** on heavy T-posts every 8 ft,
at least **3 ft from the hives**, with a **6-ft ground rod** ([🖼️ step photos](lib:building-bear-fences#page=4);
[🖼️ finished fence](lib:building-bear-fences#page=5)). Test for **6,000–8,000 volts** and keep plants
cut back 2–3 ft. Bait the wire with foil smeared with bacon grease so a bear's nose gets the first shock
*(rule of thumb)*.

**Stings:** pain and swelling at the spot are normal; scrape the stinger out at once *(rule of thumb)*. A
**whole-body reaction** ([anaphylaxis](wiki:Anaphylaxis): throat swelling, trouble breathing, faintness) follows 0.3–7.5% of stings
([OSU EM 9186, p. 4](lib:osu-residential-beekeeping-best-practices-em-9186#page=4)).
- **Give epinephrine (adrenaline) into the thigh muscle:** adults 50 kg+ 0.5 mg (0.5 mL of 1:1000), repeated
  every 5 minutes as needed; children 0.15 mg
  ([WHO, p. 235](lib:who-icrc-basic-emergency-care-approach-to-the-acutely-ill-and-injured-who-2018#page=235)).
  See the [Field Care guide](guide:FIELD-CARE-GUIDE).

📚 **Go deeper:** [FAO *Bees and Forest Livelihoods*](lib:bees-and-their-role-in-forest-livelihoods#page=112) — straining honey, rendering wax, solar melter; [ODFW *Living with Black Bears*](lib:living-with-black-bears-odfw#page=2) — bears and attractants.

## 🧯 If this goes wrong

| Problem | Likely cause and fix |
|---|---|
| Kid 3–8 weeks old stiff, trembling, can't stand | White muscle disease — selenium shortage ([OSU EM 9094, p. 2](lib:selenium-supplementation-strategies#page=2)) |
| Milk tastes "goaty" | Buck kept near the does ([FB 920, p. 25](lib:milk-goats-usda-farmers-bulletin-920#page=25)), or slow cooling |
| Butter won't come | Milk too fresh or too cold — sour it, warm it to 59–79 °F ([ILCA, p. 60](lib:rural-dairy-technology#page=60)) |
| Bees fighting at the entrance in August | Robbing — narrow the entrance ([🖼️ entrance reducer](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)); clean up syrup ([OSU EM 9186, p. 5](lib:osu-residential-beekeeping-best-practices-em-9186#page=5)) |

📚 **Go deeper:** [*Where There Is No Animal Doctor*](lib:where-there-is-no-animal-doctor-cvm-2024#page=289) — sick goats with no vet; [ILCA *Rural Dairy Technology*](lib:rural-dairy-technology#page=60) — butter-making troubles; [OSU EM 9186](lib:osu-residential-beekeeping-best-practices-em-9186#page=5) — robbing, swarms and other bee-yard problems.

## ⚠️ Old advice in the library to ignore

- **Phenothiazine mixed into salt as a constant dewormer** — [FB 920, p. 26](lib:milk-goats-usda-farmers-bulletin-920#page=26).
  Breeds resistant worms. **Instead:** FAMACHA-targeted deworming.
- **Iodoform in mineral oil put into the uterus** — [FB 920, p. 30](lib:milk-goats-usda-farmers-bulletin-920#page=30).
  Outdated. **Instead:** never pull the afterbirth ([KSU, p. 13](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=13)).
- **Caustic-stick disbudding** — [FB 920, p. 34](lib:milk-goats-usda-farmers-bulletin-920#page=34). It runs
  into eyes and burns other kids or the doe. **Instead:** a hot iron.
- **Pasteurizing at 140 °F (60 °C) for 30 minutes** — [*Zoonoses*, p. 31](lib:zoonoses-diseases-animals-give-people-cvm#page=31).
  Too low. **Instead:** 145 °F for 30 minutes or 161 °F for 15 seconds.
- **Paraffin heated to 240 °F for dipping cheese** — [FB 1191, p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)
  (220 °F in [*Book of Cheese*, p. 287](lib:the-book-of-cheese#page=287)). Fire and burn hazard. **Instead:** melt
  wax in a pot set in water, never unattended.
- **Soft cheese from raw milk** — [*Book of Cheese*, p. 167](lib:the-book-of-cheese#page=167); [FB 920, p. 8](lib:milk-goats-usda-farmers-bulletin-920#page=8).
  It carries Listeria and brucellosis. **Instead:** pasteurize milk for soft cheese.
- **Bee drugs** — [AH 335, p. 132](lib:beekeeping-in-the-united-states#page=132). The 1980 book predates
  varroa in the US (1987). **Instead:** the HBHC varroa guide.
- **Killing colonies over burning sulfur to take the honey** — [Langstroth, p. 264](lib:langstroth-on-the-hive#page=264).
  **Instead:** take only surplus honey. Burn a colony only for AFB.
- **Butter coloring and old dairy "preservatives"** — [FB 876, p. 13](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13).
  **Instead:** salt to 3%, or make ghee.

📚 **Go deeper:** [HBHC varroa guide](lib:tools-for-varroa-management#page=10) — current mite control; [UMN](lib:pasteurization-of-milk-at-home#page=1) — today's pasteurizing standard.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Goats, housing and plants**
- Dairy breeds — [🖼️ FB 920, p. 12 (Saanen)](lib:milk-goats-usda-farmers-bulletin-920#page=12); [🖼️ p. 14 (Toggenburg)](lib:milk-goats-usda-farmers-bulletin-920#page=14); [🖼️ p. 15 (Nubian)](lib:milk-goats-usda-farmers-bulletin-920#page=15); [🖼️ p. 17 (Alpine)](lib:milk-goats-usda-farmers-bulletin-920#page=17); [Saanen goat](wiki:Saanen_goat); [LaMancha](wiki:American_Lamancha); [Nigerian Dwarf](wiki:Nigerian_Dwarf)
- Plan of a small goat dairy — [🖼️ FB 920, p. 9](lib:milk-goats-usda-farmers-bulletin-920#page=9)
- Shelter, guardian animals, climbing — [🖼️ OSU EC1646, p. 1](lib:getting-started-with-sheep-and-goats-osu-ec1646#page=1); [🖼️ p. 2](lib:getting-started-with-sheep-and-goats-osu-ec1646#page=2); [🖼️ guard dog, llama and donkey](lib:raising-healthy-sheep-cvm#page=133)
- Low-selenium Oregon — [🖼️ OSU EM 9094, p. 2](lib:selenium-supplementation-strategies#page=2); [White muscle disease](wiki:Nutritional_muscular_dystrophy)
- Plants that kill goats — [Pacific yew](wiki:Taxus_brevifolia); [Western azalea](wiki:Rhododendron_occidentale); [Oleander](wiki:Nerium); [Chokecherry](wiki:Prunus_virginiana)

**Kidding and kids**
- Normal and wrong birth positions — [🖼️ Langston, p. 6](lib:lambing-and-kidding-assistance-langston#page=6); [🖼️ p. 7](lib:lambing-and-kidding-assistance-langston#page=7); [🖼️ p. 8](lib:lambing-and-kidding-assistance-langston#page=8); [🖼️ KSU, p. 6](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=6)
- Kidding kit and tube-feeding a weak kid — [🖼️ KSU, p. 14](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=14); [🖼️ KSU, p. 12](lib:kidding-resources-for-beginning-goat-producers-ksu-mf3689#page=12)
- Disbudding iron and where to burn — [🖼️ Peace Corps Vol 4, p. 415](lib:peace-corps-livestock-training-manual-vol-4-1982#page=415); [Livestock dehorning](wiki:Livestock_dehorning)

**Goat health** (sheep photos show the same signs)
- Hoof parts, trimming, hoof rot — [🖼️ MSU M2487, p. 1](lib:sheep-and-goat-hoof-trimming-msu-m2487#page=1); [🖼️ Raising Healthy Sheep, p. 77](lib:raising-healthy-sheep-cvm#page=77); [🖼️ p. 115](lib:raising-healthy-sheep-cvm#page=115)
- Worms: pale eyelid, bottle jaw, life cycle — [🖼️ Raising Healthy Sheep, p. 119](lib:raising-healthy-sheep-cvm#page=119); [FAMACHA](wiki:FAMACHA); [Barber pole worm](wiki:Haemonchus_contortus)
- CL abscess — [🖼️ Raising Healthy Sheep, p. 109](lib:raising-healthy-sheep-cvm#page=109); [Caseous lymphadenitis](wiki:Caseous_lymphadenitis)
- Mastitis, milk fever, pregnancy toxemia — [🖼️ p. 113](lib:raising-healthy-sheep-cvm#page=113); [🖼️ p. 92](lib:raising-healthy-sheep-cvm#page=92); [🖼️ p. 91](lib:raising-healthy-sheep-cvm#page=91)
- Drench bottle and injection sites — [🖼️ Peace Corps Vol 4, p. 418](lib:peace-corps-livestock-training-manual-vol-4-1982#page=418); [🖼️ p. 413](lib:peace-corps-livestock-training-manual-vol-4-1982#page=413)

**Milk, butter and cheese**
- Milking stand — [🖼️ FB 920, p. 28](lib:milk-goats-usda-farmers-bulletin-920#page=28)
- Spring-water cooling tank — [🖼️ FB 976, p. 7](lib:cooling-milk-and-cream-on-the-farm-well-and-spring-water-tanks-usda-fb-976-1918#page=7)
- Skimming cream by gravity — [🖼️ ILCA, p. 38](lib:rural-dairy-technology#page=38)
- Churns, draining and working butter — [🖼️ Practical Action, p. 3](lib:butter-and-ghee-practical-action#page=3); [🖼️ FB 876, p. 10](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=10); [🖼️ p. 13](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13); [🖼️ p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16); [Butter churn](wiki:Butter_churn)
- Queso blanco, step by step — [🖼️ ILCA, p. 51](lib:rural-dairy-technology#page=51); [Paneer](wiki:Paneer)
- Cottage-cheese starter jars — [🖼️ FB 1451, p. 7](lib:making-and-using-cottage-cheese#page=7)
- Curd knives, draining box, hoop and lever press — [🖼️ FB 1191, p. 8](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=8); [🖼️ p. 12](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=12); [🖼️ p. 13](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=13); [🖼️ p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15); [🖼️ Practical Action, p. 5](lib:cheese-making-practical-action#page=5)

**Bees**
- Worker, queen and drone — [🖼️ AH 335, p. 36](lib:beekeeping-in-the-united-states#page=36); [Western honey bee](wiki:Western_honey_bee)
- Hives — [🖼️ Langstroth plans, AH 335 p. 53](lib:beekeeping-in-the-united-states#page=53); [🖼️ cutaway, p. 54](lib:beekeeping-in-the-united-states#page=54); [Langstroth hive](wiki:Langstroth_hive); [Top-bar hive](wiki:Horizontal_top-bar_hive)
- Swarms and swarm cells — [🖼️ OSU EM 9186, p. 4](lib:osu-residential-beekeeping-best-practices-em-9186#page=4); [🖼️ p. 10](lib:osu-residential-beekeeping-best-practices-em-9186#page=10); [🖼️ hiving a swarm, AH 335 p. 38](lib:beekeeping-in-the-united-states#page=38); [Swarming](wiki:Swarming_(honey_bee))
- Healthy vs. spotty brood — [🖼️ AH 335, p. 77](lib:beekeeping-in-the-united-states#page=77)
- Varroa — [🖼️ FAO 2006, p. 19](lib:honey-bee-diseases-and-pests#page=19); [🖼️ p. 20](lib:honey-bee-diseases-and-pests#page=20); [🖼️ HBHC seasons chart, p. 5](lib:tools-for-varroa-management#page=5); [Varroa destructor](wiki:Varroa_destructor)
- American foulbrood and the rope test — [🖼️ FAO 2006, p. 10](lib:honey-bee-diseases-and-pests#page=10); [🖼️ p. 11](lib:honey-bee-diseases-and-pests#page=11); [🖼️ AH 335, p. 126](lib:beekeeping-in-the-united-states#page=126); [American foulbrood](wiki:American_foulbrood)
- Wax moth — [🖼️ AH 335, p. 133](lib:beekeeping-in-the-united-states#page=133); [Galleria mellonella](wiki:Galleria_mellonella)
- Bear fence — [🖼️ UF ENY-2060, p. 3](lib:building-bear-fences#page=3); [🖼️ p. 5](lib:building-bear-fences#page=5)
- Melting wax safely — [🖼️ Practical Action, p. 3](lib:practical-action-candlemaking-technical-brief#page=3); [Beeswax](wiki:Beeswax)

## 🔗 Related guides

- [Rabbits & Chickens](guide:RABBITS-CHICKENS-GUIDE) — skim milk and whey for hens; predators
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — hay, toxic plants, wildfire plans
- [Preserving Food](guide:PRESERVING-FOOD-GUIDE) — storing honey and dairy foods
- [Root Cellar guide](guide:ROOT-CELLAR-GUIDE) — cool storage for milk, butter and cheese
- [Childbirth & Children](guide:CHILDBIRTH-CHILDREN-GUIDE) — feeding babies safely
- [Field Care guide](guide:FIELD-CARE-GUIDE) — anaphylaxis with no help coming
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — goat vital signs, kidding help
