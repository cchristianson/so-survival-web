# 🌱 Your Seed Bank: Grow, Harvest and Save Seed

How to keep a heirloom seed bank alive for good in the Illinois Valley: store it so it lasts, test
it, plant each variety at the right time here, keep varieties from crossing, and save your own seed
every year — including seed from the fruits (tomatoes, cucumbers, melons, squash, peppers). It ends
with the calorie crops the kit is missing and how to propagate fruit trees and berries, whose seeds
don't grow true. The manuals are in `Gardening-Food\Seed-Saving`, `Gardening-Food\Fruit-Propagation`
and the rest of `Gardening-Food\`.

Written for the **Heaven's Harvest "10 Year" seed bank**. The company's list has 39 varieties (they
note some may be swapped when seed is short), so **check your own packets** — the rules below are by
crop, so they still apply.

> ### The five rules of a seed bank
> 1. **Don't plant it all.** Plant part of each packet; keep the rest sealed as a backup.
> 2. **Start saving seed in year one** — the short-lived ones first: onions, leeks, sweet corn,
>    peppers and okra keep only 1–2 years.
> 3. **Test germination every winter** so you know what still sprouts before you need it.
> 4. **Know which varieties cross.** Several in this kit cross with each other; save seed from
>    only one of each group per year (or hand-pollinate).
> 5. **Vegetables aren't enough calories.** Add potatoes, dry beans, a flour corn and grains.

Every variety in this kit is **[open-pollinated](wiki:Open_pollination) (heirloom)**: seed you save grows the same plant as
long as it didn't cross with a relative. Hybrids ("[F1](wiki:F1_hybrid)" on a packet) don't come true — don't save from
those. ([OSA Seed Saving Guide, p. 5](lib:osa-a-seed-saving-guide#page=5))

---

## 📦 What's in the kit, by family

Family matters twice: relatives **cross-pollinate**, and they share **pests and diseases**, so [rotate](wiki:Crop_rotation)
families around your beds (don't grow the same family in the same bed more than one year in three
*(rule of thumb)*).

| Family | Kit varieties |
|---|---|
| **Cabbage family** (all one species, *[Brassica oleracea](wiki:Brassica_oleracea)*) | [Brussels sprouts](wiki:Brussels_sprout) Long Island Improved · [Broccoli](wiki:Broccoli) Green Sprouting Calabrese · [Cabbage](wiki:Cabbage) Early Jersey Wakefield · [Cauliflower](wiki:Cauliflower) Snowball · [Collards](wiki:Collard_(plant)) Georgia Southern · [Kale](wiki:Kale) Vates |
| **Turnip family** (*B. rapa*) and rutabaga (*B. napus*) | [Turnip](wiki:Turnip) Purple Top White Globe · Tendergreen mustard ([komatsuna](wiki:Komatsuna) type) · [Rutabaga](wiki:Rutabaga) American Purple Top |
| **Radish** | [Radish](wiki:Radish) Early Scarlet Globe |
| **Squash family** | [Zucchini](wiki:Zucchini) Black Beauty · [Crookneck](wiki:Crookneck_squash) Golden Summer · [Pumpkin](wiki:Pumpkin) Jack O'Lantern (these three cross; [🖼️ one species, many shapes](lib:cucurbit-seed-production#page=5)) · [Butternut](wiki:Butternut_squash) Waltham · [Cucumber](wiki:Cucumber) Poinsett 76 and National Pickling · [Cantaloupe](wiki:Cantaloupe) Hales Best Jumbo · [Watermelon](wiki:Watermelon) Sugar Baby |
| **Tomato family** | [Tomato](wiki:Tomato) Beefsteak, Roma, Large Red Cherry · [Bell pepper](wiki:Bell_pepper) California Wonder · [Jalapeño](wiki:Jalapeño) Early · [Eggplant](wiki:Eggplant) Black Beauty |
| **Beans and peas** | [Green bean](wiki:Green_bean) Blue Lake 274 and Provider (bush) · [Lima bean](wiki:Lima_bean) Henderson · [Snap pea](wiki:Snap_pea) Sugar Ann |
| **Onion family** | [Onion](wiki:Onion) Sweet Spanish Yellow · [Bunching onion](wiki:Allium_fistulosum) White · [Leek](wiki:Leek) American Flag |
| **Carrot family** | [Carrot](wiki:Carrot) Danvers · [Celery](wiki:Celery) Tall Utah |
| **Beet family** | [Beet](wiki:Beetroot) Detroit Dark Red · [Spinach](wiki:Spinach) Nobel Giant / Bloomsdale |
| **Others** | [Sweet corn](wiki:Sweet_corn) Golden Bantam · [Lettuce](wiki:Lettuce) Buttercrunch · [Okra](wiki:Okra) Clemson Spineless · [Asparagus](wiki:Asparagus) Mary Washington (perennial) |

📚 **Go deeper:** [OSA crop chart, pp. 25–27](lib:osa-a-seed-saving-guide#page=25) — every crop's family, pollination and life cycle; [Brassica Seed Production, p. 8](lib:brassica-seed-production#page=8) — which cabbage-family crops are which species.

## 🗄️ Keeping the seed bank alive

**Seed dies from heat and damp.** Two rules from seed-storage research
([Seed Processing and Storage, p. 9](lib:seed-processing-and-storage#page=9)):
- **Every 10 °F cooler roughly doubles seed life.**
- **Every 1% less moisture in the seed roughly doubles it too** ([🖼️ chart: moisture, humidity and storage life](lib:seed-processing-and-storage#page=13)).
- Quick test for a storage spot: **temperature (°F) + relative humidity (%) should add up to less than
  100.** ([OSA, p. 17](lib:osa-a-seed-saving-guide#page=17))

**Where to keep it here:**
- **Not** in a shed, garage, attic or vehicle — Illinois Valley summers top 100 °F.
- Best: the coolest, driest room of the house, a closet on a north wall, or a dry root cellar.
- **Fridge or freezer only for very dry seed in an airtight jar.** Let the jar warm to room
  temperature before opening, or moisture condenses on the cold seed. Very dry seed (about 5%
  moisture) held below 20 °F still sprouted well after 20 years.
  ([Seed Processing and Storage, p. 9](lib:seed-processing-and-storage#page=9))
- **Once you open a Mylar packet,** reseal it, or move the seed into a glass jar with a [desiccant](wiki:Desiccant) packet
  ([silica gel](wiki:Silica_gel); [🖼️ chart: how the container affects sprouting](lib:seed-processing-and-storage#page=15)). Label every jar with the variety and year.

**How long seed stays good** in ordinary cool, dry storage
([Univ. of Illinois seed life table, p. 2](lib:seed-viability-and-germination#page=2);
[McCormack, p. 17](lib:seed-processing-and-storage#page=17)):

| Years of good sprouting | Kit crops | What to do |
|---|---|---|
| **1–2** | Onion (1), leek, okra, pepper, sweet corn (2) | **Grow these out and save fresh seed the first year.** Store spare seed in the freezer. |
| **3** | Asparagus, beans, broccoli, carrot, celery, pea, spinach | Grow out and replace by year 3. |
| **4** | Beet, Brussels sprouts, cabbage, cauliflower, eggplant, kale, mustard, pumpkin, rutabaga, squash, tomato, turnip, watermelon | Replace by year 4. |
| **5–6** | Cantaloupe, collards, cucumber, radish (5), lettuce (6) | The long keepers. |

The "10 year" label is possible only with very cool, dry storage — **in ordinary storage most of
these last 3–5 years**, so a seed bank survives by being **grown and re-saved**, not by sitting.

📚 **Go deeper:** [OSA — where and how to store seed, p. 17](lib:osa-a-seed-saving-guide#page=17); [Seed Processing and Storage — drying with silica gel, p. 9](lib:seed-processing-and-storage#page=9); [Seed Ambassadors zine — drying and freezing, p. 7](lib:seed-stewardship#page=7).

## 🧪 Germination test ("rag doll")

Do this every winter, and before planting any packet more than a year old ([what germination looks like](wiki:Germination)).
([OSA, p. 18](lib:osa-a-seed-saving-guide#page=18); [Univ. of Illinois, p. 1](lib:seed-viability-and-germination#page=1))

1. Dampen a paper towel — damp, not dripping.
2. Lay out **10 seeds** (more is more accurate) spaced apart, roll the towel up, and put it in a
   plastic bag with a little air. Label it.
3. Keep it warm: about 70 °F for most crops; **75–80 °F for peppers, eggplant, melons**. Lettuce and
   celery sprout better with some light.
4. Check from day 3; remove sprouted and moldy seeds and count them. Slow crops (peppers, parsley-type
   seeds) can take up to 3 weeks.
5. **Read the result:** 10 of 10 — plant normally. **7–9 — sow thicker.** **6 or fewer — this packet is
   failing: plant it now and save fresh seed this year.**

Fresh spinach, lettuce and pepper seed can be dormant for a few months — retest before giving up on it.

📚 **Go deeper:** [OSA germination test, p. 18](lib:osa-a-seed-saving-guide#page=18); [McCormack — germination testing, p. 20](lib:seed-processing-and-storage#page=20).

## 📅 Planting calendar for the Illinois Valley

Dates are Oregon State's **western valleys** dates ([*Growing Your Own*, p. 9](lib:growing-your-own#page=9));
Medford-area gardens can go 7–10 days earlier and later. At Cave Junction the **last spring frost
averages May 1 but is after May 23 one year in ten**, and the first fall frost averages Oct 12 — so in
**valley-floor frost pockets wait until late May or June for tomatoes, peppers, squash, melons, beans
and corn.** Winter-crop dates are from [PNW 548, pp. 48–50](lib:winter-vegetable-production#page=48).

| Crop (kit variety) | Start indoors ([transplants](wiki:Transplanting)) | Plant out / sow | Fall & winter crop | In-row spacing | Days to harvest* |
|---|---|---|---|---|---|
| Asparagus (Mary Washington) | 1 year ahead (grow crowns) | Feb–Mar | perennial | 12" | first picking year 3 |
| Bush beans (Blue Lake 274, Provider) | — | May–July | — | 2–6" | 50–60 |
| Lima (Henderson) | — | May–June, warm soil | — | 4–6" | 65–75 |
| Beet (Detroit Dark Red) | — | Mar–June | sow June–Aug, harvest Oct–Mar | 1–2" | 60 |
| Broccoli (Calabrese) | 6 weeks | Mar–Aug | transplant July for fall | 12–24" | 60–70 from transplant |
| Brussels sprouts (Long Island) | 6 weeks | May–July | transplant late May–June, harvest Oct–Mar | 24" | 90–100 |
| Cabbage (Early Jersey Wakefield) | 6 weeks | Apr–June | transplant mid-July–early Aug | 24" | 60–70 |
| Cantaloupe (Hales Best) | 4 weeks | May (late May in frost pockets) | — | 48" | 80–85 |
| Carrot (Danvers) | — | Mar–July 15 | sow May–July, harvest Oct–Mar | 2" | 70–75 |
| Cauliflower (Snowball) | 6 weeks | Apr–July 15 | transplant mid-July–early Aug | 24" | 55–70 |
| Celery (Tall Utah) | 9 weeks | Mar–July | — | 5" | 100–120 |
| Collards (Georgia Southern) | — | spring, or sow July | transplant June–Sept, harvest Sept–Apr | 24" | 75 |
| Cucumbers (Poinsett, Nat'l Pickling) | 4 weeks | May–June | — | 24" / 6–12" | 55–65 |
| Eggplant (Black Beauty) | 9 weeks | May–June, warm nights | — | 24" | 75–80 |
| Kale (Vates) | — | May–July | transplant June–Aug, harvest Sept–Apr | 24" | 55–65 |
| Leek (American Flag) | sow late Feb–Mar | transplant May–early Aug | harvest Nov–Apr | 2–6" | 120–130 |
| Lettuce (Buttercrunch) | 5 weeks | Apr–early June; **avoid midsummer heat** | transplant July–Aug | 12" | 55–65 |
| Mustard (Tendergreen) | — | Mar–Apr | transplant July–Aug, harvest Sept–Apr | 6" | 35–45 |
| Okra (Clemson Spineless) | 8 weeks | June, warmest spot (OSU lists it "not suitable" for western valleys; try it in a hot spot) | — | 18" | 55–60 in heat |
| Onion (Sweet Spanish Yellow) | 10 weeks (Jan) | Mar–May | — | 3" | 110–120 |
| Bunching onion (White) | — | Mar–May | sow Aug for May–June scallions | 1–2" | 60–70 |
| Pea (Sugar Ann) | — | Feb–May | — | 2" | 55–60 |
| Peppers (California Wonder, Jalapeño) | 10 weeks (late Feb) | May–June, warm nights | — | 12–18" | 65–75 from transplant |
| Pumpkin (Jack O'Lantern) | 4 weeks | May | — | 48" | 100–110 |
| Radish (Early Scarlet Globe) | — | Mar–Sept | sow Aug–Sept, harvest Nov–Feb | 1" | 25 |
| Rutabaga (American Purple Top) | — | June–July | harvest fall–March | 3–6" | 90–100 |
| Spinach (Nobel Giant / Bloomsdale) | — | Apr (Feb–Mar under cover) | sow Aug–Sept, harvest Nov–Feb | 3" | 45–50 |
| Summer squash (Crookneck, Zucchini) | 4 weeks | May–June | — | 24" | 50–60 |
| Winter squash (Waltham Butternut) | 4 weeks | May | — | 48" | 100–110 |
| Sweet corn (Golden Bantam) | — | May–June, in a block of 4+ rows | — | 15" | 75–85 |
| Tomatoes (Beefsteak, Roma, Cherry) | 8 weeks (early Mar) | May (late May in frost pockets) | — | 24–36" | 70–90 from transplant |
| Turnip (Purple Top White Globe) | — | Apr–Sept | sow Aug, harvest through Mar | 2" | 50–55 |
| Watermelon (Sugar Baby) | 4 weeks | May | — | 60" | 75–80 |

\* *Days to harvest are typical seed-catalog figures (rule of thumb); for transplants count from
transplanting.* The same OSU table gives **how much to plant for a family of four** — e.g. 10–15
tomato plants, 15–25 ft of bush beans, 30–40 ft of onions.

📚 **Go deeper:** [*Growing Your Own* planting table, p. 9](lib:growing-your-own#page=9); [PNW 548 winter crop table, p. 48](lib:winter-vegetable-production#page=48); [OSU *Vegetable Gardening in Oregon*](lib:vegetable-gardening-in-oregon) — varieties, fertilizing, watering.

## 🏡 Growing it here

- **[Raised beds](wiki:Raised-bed_gardening) with good soil** ([🖼️ how they drain wet ground](lib:winter-vegetable-production#page=4)). Many valley soils are [serpentine](wiki:Serpentine_soil) (high magnesium, low calcium) or
  slow-draining clay. Build raised beds, **get a soil test before adding amendments**, and add lots of
  compost. ([OSU Soil Test Guide](lib:soil-test-interpretation); [Improving Garden Soils](lib:improving-garden-soils))
- **Water is the summer limit.** Only 5–7 in of rain falls April–September. Rogue Valley gardens can
  lose **½ inch of water a day** in hot wind ([*Growing Your Own*, p. 21](lib:growing-your-own#page=21)).
  Apply 1–1.5 in per watering ([EC 871, p. 9](lib:vegetable-gardening-in-oregon#page=9)), use [drip lines](wiki:Drip_irrigation), and
  [mulch](wiki:Mulch) thickly.
- **Frost pockets:** cold air drains to low ground. Plant warm crops on the warmest, sunniest ground you
  have, and keep [row cover](wiki:Row_cover) or old sheets ready for late-May frosts ([🖼️ row cover on hoops](lib:winter-vegetable-production#page=10)).
- **Heat:** lettuce, spinach and cabbage-family crops bolt or go bitter in July heat. Grow them in spring
  and fall, or under shade cloth on the north side of taller crops.
- **[Deer](wiki:Black-tailed_deer) and [gophers](wiki:Gopher):** a 7–8 ft fence for deer; hardware-cloth bottoms on raised beds or wire baskets
  around roots for gophers *(rule of thumb)*.
- **Bugs:** encourage [beneficial insects](wiki:Beneficial_insect) rather than spraying
  ([PNW 550](lib:encouraging-beneficial-insects)).

📚 **Go deeper:** [*Growing Your Own* — Rogue Valley section, p. 21](lib:growing-your-own#page=21); [Drip Irrigation in the Food Garden](lib:drip-irrigation-in-the-food-garden); [Food Gardening with Less Water](lib:food-gardening-with-less-water); [Josephine County soil survey](lib:soil-survey-of-josephine-county-oregon-1983-text).

## ❌ Which of your seeds cross — and what to do

Plants that are [pollinated](wiki:Pollination) by insects or wind **cross with relatives of the same species** flowering
nearby ([🖼️ a bumblebee working a tomato flower](lib:isolation-distances-for-seed-crops#page=10)). The seed looks fine; the next generation is a mix. [Self-pollinating](wiki:Self-pollination) crops rarely cross.
([OSA, pp. 6–8](lib:osa-a-seed-saving-guide#page=6))

| Crossing group | Kit varieties | Solution |
|---|---|---|
| **Cabbage family** | Brussels sprouts, broccoli, cabbage, cauliflower, collards, Vates kale | **Let only one flower each year** (rotate which one), or cage them ([Brassica Seed Production, p. 8](lib:brassica-seed-production#page=8)) |
| **Turnip family** | Purple Top turnip × Tendergreen mustard | One per year. Rutabaga crosses with them only rarely, but separate it anyway ([zine, p. 16](lib:seed-stewardship#page=16)) |
| **Squash (*[C. pepo](wiki:Cucurbita_pepo)*)** | Zucchini × crookneck × Jack O'Lantern pumpkin | One per year, or **hand-pollinate** (below). Butternut is a different species and usually doesn't cross with them ([Cucurbit Seed Production, p. 10](lib:cucurbit-seed-production#page=10)) |
| **Cucumbers** | Poinsett 76 × National Pickling | One per year, or hand-pollinate. Cucumbers do **not** cross with melons or watermelon. |
| **Peppers** | California Wonder × Early Jalapeño | Separate widely or bag flowers — otherwise **your bell peppers may come up hot** ([Pepper Seed Production, p. 7](lib:pepper-seed-production#page=7)) |
| **Carrot** | Danvers × wild [Queen Anne's lace](wiki:Daucus_carota) | The wild carrot on every roadside here is the **same species**. Cage seed carrots and release flies inside, or remove wild carrot nearby ([OSA, p. 7](lib:osa-a-seed-saving-guide#page=7)) |
| **Beet** | Detroit Dark Red × any [chard](wiki:Chard) or beet | Pollen travels miles on the wind — grow one beet/chard for seed per year |
| **Corn** | Golden Bantam × **any neighbor's corn** | Distance, or plant so it tassels at a different time from nearby corn |
| **Spinach** | Two spinach varieties | Wind-pollinated — one per year |
| Rarely cross | Tomatoes ([🖼️ old vs. modern flower](lib:isolation-distances-for-seed-crops#page=9)), beans, peas, lettuce, lima | 10–40 ft apart is plenty |
| Don't cross each other | Sweet Spanish onion vs. White Bunching (usually *A. fistulosum*) vs. leek | Different species — check the packets |

**How far apart and how many plants** (home-use figures from [OSA's chart, pp. 25–27](lib:osa-a-seed-saving-guide#page=25); [🖼️ graph: crossing falls off with distance](lib:brassica-seed-production#page=9)):

| Crop | Pollinated by | Life cycle | Isolation for home use | Plants to save from (minimum) |
|---|---|---|---|---|
| Tomato, bean, pea, lettuce | self | annual | 10 ft (heirloom tomatoes 40 ft) | 10–20 |
| Lima bean, okra | self + insects | annual | 40 ft / 800 ft | 40 |
| Sweet pepper / hot pepper | self + insects | annual | 160 ft / 800 ft | 10–20 / 40 |
| Eggplant | insects | annual | 1,600 ft (others say 75 ft) | 80 |
| Squash, pumpkin, cucumber, melon, watermelon | insects | annual | 1,600 ft | 10–20 |
| Radish | insects | annual | 1,600 ft | 80 |
| Cabbage family, turnip, rutabaga, mustard | insects | biennial (broccoli annual) | 1,600 ft | 80 |
| Carrot, onion | insects | biennial | 1,600 ft | 200 |
| Leek, celery | insects | biennial | 1,600 ft | 80 |
| Beet, spinach | wind | biennial / annual | 3,200 ft | 80 |
| Sweet corn | wind | annual | 1,600 ft (often more) | 200 |

The big numbers are what keeps a variety vigorous over many generations. **Fewer plants still gives you
seed** — but save from as many good plants as you can, and pull out weak or odd-looking plants
("roguing") before they flower. ([OSA, p. 9](lib:osa-a-seed-saving-guide#page=9))

📚 **Go deeper:** [Isolation Distances for Seed Crops, p. 18](lib:isolation-distances-for-seed-crops#page=18) — chart, barriers and timing; [How to Save Seeds — isolation chart](lib:how-to-save-seeds-isolation) ; [UGA Seed Saving starter guide](lib:seed-saving-in-home-gardens).

## ✋ Hand-pollinating and caging

**Squash, pumpkin and cucumber** — save pure seed even when relatives grow nearby
([Cucurbit Seed Production, p. 12](lib:cucurbit-seed-production#page=12); [🖼️ male and female squash flowers](lib:cucurbit-seed-production#page=7); [hand pollination](wiki:Hand-pollination)):
1. In the evening, find male and female flowers that will open tomorrow (yellow showing at the tips; the
   female has a tiny fruit behind the flower). **Tape or tie them shut** ([🖼️ taped flowers](lib:cucurbit-seed-production#page=13)).
2. Next morning, once the dew is off, pick a male flower, peel back its petals, and **rub its pollen onto
   the center of the opened female** — use 2–3 males.
3. **Tape the female shut again** and tie a tag or yarn on its stem. Save seed only from tagged fruit.

**Corn:** cover young ear shoots with paper bags before [silks](wiki:Corn_silk) appear; when silks show, bag a tassel
that's shedding pollen, shake the pollen into the bag the next morning, pour it onto the silks and
re-bag ([OSA sweet corn guide, p. 6](lib:how-to-breed-sweet-corn#page=6); [🖼️ bags and tools](lib:how-to-breed-sweet-corn#page=6)).

**Cabbage family, carrots, peppers:** cover them with a **cage of row cover** on hoops ([🖼️ row cover on hoops](lib:winter-vegetable-production#page=10)). Cabbage-family
plants need insects to set seed (they can't pollinate themselves), so put flies or bees in the cage —
or **alternate-day caging**: uncover only one variety each day and cover them all at night
([Isolation Distances, p. 17](lib:isolation-distances-for-seed-crops#page=17)).

📚 **Go deeper:** [Cucurbit Seed Production, pp. 12–17](lib:cucurbit-seed-production#page=12); [OSA sweet corn hand pollination, pp. 5–8](lib:how-to-breed-sweet-corn#page=5); [Isolation Distances — caging, p. 17](lib:isolation-distances-for-seed-crops#page=17).

## 🍅 Saving seed from the fruits

Fruit crops have **wet seed** ([seed saving](wiki:Seed_saving)): let the fruit get **riper than you'd eat it**, scoop out the seeds, clean
them, and dry them. ([OSA, pp. 15–16, 21–24](lib:osa-a-seed-saving-guide#page=15))

**Tomatoes — ferment them:**
1. Pick fully ripe fruit from several healthy plants of the variety.
2. Squeeze the seeds and juice into a jar; add a little water if thick. Label it.
3. Leave it at about **70–80 °F for 2–3 days**, stirring 2–3 times a day. A thin white mold on top is normal (keep stirring so it doesn't take over) —
   it eats the gel coat that keeps seed from sprouting. **Stop before any seed sprouts**, and keep it out of
   high heat (liquid in the high 80s °F can kill half the seed).
   ([Tomato Seed Production, p. 11](lib:tomato-seed-production#page=11))
4. Add water and stir: **good seed sinks**; pour off the mold, pulp and floaters. Rinse in a strainer.
5. Spread thin on a plate or screen to dry (paper towels stick).

**Cucumbers:** leave the fruit on the vine **4–5 weeks past eating stage**, until it's big, yellow to
orange-brown and slightly soft. Scrape the seeds and pulp into a jar and ferment **about 3 days at
70–75 °F** like tomatoes; good seed sinks.
([Cucurbit Seed Production, p. 18](lib:cucurbit-seed-production#page=18))

**Melons and watermelon:** seed is ripe when the fruit is ripe to eat. Scoop the seeds, rinse them in a
strainer (watermelon can ferment 2–3 days), and dry. ([OSA, pp. 22, 24](lib:osa-a-seed-saving-guide#page=22))

**Squash and pumpkins:** leave on the vine until **hard — a thumbnail won't dent it** — and the stem dries.
Summer squash for seed gets "about the size of your leg." Then **store winter squash and pumpkins about 2
months** (summer squash a few weeks) before cutting them open: the seed keeps filling out. Scoop, rinse,
dry. Ferment no more than a day, if at all. ([OSA, p. 24](lib:osa-a-seed-saving-guide#page=24);
[Cucurbit Seed Production, p. 15](lib:cucurbit-seed-production#page=15))

**Peppers:** pick at **full color** (red for both kit peppers), hold them 7–10 days at room temperature,
then cut them open and scrape out the seeds. Good seed is **ivory, not brown**. Seed from green peppers
often won't sprout. **Wear gloves for jalapeños.** ([OSA, p. 23](lib:osa-a-seed-saving-guide#page=23);
[Pepper Seed Production, p. 9](lib:pepper-seed-production#page=9); [🖼️ ways to get the seed out](lib:pepper-seed-production#page=12))

**Eggplant:** leave the fruit until it turns **dull brown** and hard, 2–3 weeks past eating. Grate or
blend the seedy end with water; good seed sinks. ([OSA, p. 21](lib:osa-a-seed-saving-guide#page=21))

**Drying all of them:** a thin layer out of direct sun, below **95 °F** (dark seeds in sun can overheat at
80 °F), stirred daily. Small seeds are dry when they **snap instead of bend**.
([OSA, p. 16](lib:osa-a-seed-saving-guide#page=16))

📚 **Go deeper:** [OSA — wet seed processing and fermentation, p. 15](lib:osa-a-seed-saving-guide#page=15); [Cucurbit Seed Production — fruit maturity and washing, p. 17](lib:cucurbit-seed-production#page=17); [Seed Processing and Storage — wet processing, p. 5](lib:seed-processing-and-storage#page=5).

## 🫘 Saving seed from dry crops

These dry on the plant; harvest, [thresh](wiki:Threshing) (beat or stomp the seed out), and [winnow](wiki:Winnowing) (pour in a breeze to
blow off chaff). ([OSA, pp. 19–24](lib:osa-a-seed-saving-guide#page=19); [🖼️ threshing box](lib:seed-processing-and-storage#page=4); [🖼️ winnowing in front of a fan](lib:osa-a-seed-saving-guide#page=13))

- **Beans and peas:** let pods dry on the plant; pull plants when 70–80% of pods have turned color and
  finish drying under cover. **Freeze shelled seed 3 days to kill [bean weevils](wiki:Acanthoscelides_obtectus).**
  ([zine, p. 6](lib:seed-stewardship#page=6))
- **Lettuce:** let a few of the best plants [bolt](wiki:Bolting_(horticulture)) (don't save from the first to bolt). When heads look
  fluffy ("feathered"), shake them into a paper bag; repeat a week or two later. In our hot summers,
  lettuce must **flower by May or early June** or seed set suffers.
  ([OSA, p. 21](lib:osa-a-seed-saving-guide#page=21); [Climatic Considerations — Rogue Valley, p. 21](lib:climatic-considerations#page=21))
- **Radish:** dig the best roots, replant them, and let them flower; harvest when 60–70% of pods are
  brown and papery. ([OSA, p. 23](lib:osa-a-seed-saving-guide#page=23))
- **Spinach:** sow early (it bolts as days lengthen); harvest when most seed is brown.
  ([OSA, p. 23](lib:osa-a-seed-saving-guide#page=23))
- **Onions and leeks:** cut the seed head ([umbel](wiki:Umbel)) when about a **half-dollar-sized patch of black seeds shows**; dry
  10–14 days on paper. ([OSA, p. 22](lib:osa-a-seed-saving-guide#page=22))
- **Sweet corn:** let ears dry on the stalk, rub the kernels off, finish drying below 95 °F. Grow it in a block
  of 100+ plants and save from as many as you can (200 is OSA's minimum, table above) — corn weakens fast when
  inbred. ([zine, p. 9](lib:seed-stewardship#page=9))
- **Okra:** let a few pods dry on the plant until they rattle.
- **Asparagus:** female plants make red berries in fall; mash, rinse and dry the black seeds.

📚 **Go deeper:** [OSA crop-by-crop tips, pp. 19–24](lib:osa-a-seed-saving-guide#page=19); [OSA Bean Seed Production](lib:organic-bean-seed-production); [OSA Lettuce Seed Production](lib:organic-lettuce-seed-production); [OSA Spinach Seed Production](lib:organic-spinach-seed-production).

## 🥕 Biennials: seed in the second year

Carrots, beets, onions, leeks, celery, cabbage, cauliflower, Brussels sprouts, collards, kale, turnips
and rutabagas **flower only after a winter** ([biennials](wiki:Biennial_plant); [vernalization](wiki:Vernalization)) — they need **8–12 weeks below 50 °F**.
([OSA, p. 4](lib:osa-a-seed-saving-guide#page=4))

- **Leave them in the ground** where winters rarely drop below about 14 °F — true for most of the valley,
  but use **well-drained raised beds** so roots don't rot, and watch for [voles](wiki:Vole). December–January
  cold snaps of 5–10 °F still happen some years and kill most biennials: hill soil over them or cover them
  with row cover ([Climatic Considerations, p. 21](lib:climatic-considerations#page=21)).
- **Or dig and store** the best roots ("stecklings") at 35–38 °F and high humidity — in moist sand in a
  root cellar — and **replant them in early spring**. This lets you choose the best-looking roots.
  ([OSA, p. 4](lib:osa-a-seed-saving-guide#page=4); [OSA Carrot Seed Production, p. 7](lib:organic-carrot-seed-production#page=7); [🖼️ carrot stecklings trimmed for storage](lib:organic-carrot-seed-production#page=8))
- **Carrots for seed:** sow in June, not April, so roots are small going into winter (small roots
  survive cold better). ([zine, p. 15](lib:seed-stewardship#page=15))
- **Cabbage:** overwinter a loose, full-size head; in spring cut an X in the top so the flower stalk can
  get out. **Kale and collards:** sow June 20–July 15 and overwinter them in place.
  ([OSA, pp. 20–21](lib:osa-a-seed-saving-guide#page=20))
- **Beets:** small roots (1–1.5 in) overwinter best. ([OSA Beet Seed Production](lib:organic-beet-seed-production); [🖼️ trimming beet tops](lib:organic-beet-seed-production#page=7))

📚 **Go deeper:** [OSA Carrot Seed Production](lib:organic-carrot-seed-production); [OSA Beet Seed Production](lib:organic-beet-seed-production); [Climatic Considerations — Rogue Valley, pp. 20–21](lib:climatic-considerations#page=20).

## 🌾 Filling the calorie gap

This kit is mostly vegetables — vitamins and variety, but not many calories. To live from a garden you
also need:
- **[Potatoes](wiki:Potato)** — the most food per square foot in this climate. Save your own "[seed potatoes](wiki:Potato)": keep
  healthy, egg-sized tubers cool and dark over winter *(rule of thumb)*.
- **[Dry beans](wiki:Phaseolus_vulgaris)** — protein that stores for years. Your **Provider and Blue Lake** beans can be left to dry
  and eaten as dry beans. ([OSU Preserving Dry Beans](lib:preserving-dry-beans))
- **Winter squash** — your **butternut and pumpkin** store for months.
- **Flour or [flint corn](wiki:Flint_corn)** — Golden Bantam is a *sweet* corn; it dries for parched corn but makes poor meal.
- **Grains** ([wheat](wiki:Wheat), [oats](wiki:Oat), [barley](wiki:Barley)) and **[garlic](wiki:Garlic)** — see the [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE)
  guide for growing, threshing and milling.

📚 **Go deeper:** [OSU Survival Basics — Food](lib:survival-basics-food); [*Growing Your Own* — amounts for a family of four, p. 9](lib:growing-your-own#page=9).

## 🍎 Fruit trees and berries: seeds don't come true

**An apple seed grows a new, different apple tree** — usually a poor one. Fruit trees are kept true by
**grafting** a twig ("scion") of the variety you want onto a [rootstock](wiki:Rootstock) ([🖼️ whip-and-tongue graft, step by step](lib:basic-grafting-techniques#page=3)).
([Univ. of Minnesota *Grafting and Budding*](lib:grafting-and-budding-fruit-trees-eb-437#page=2); [Univ. of Kentucky, p. 1](lib:graftage#page=1))

- **Grow rootstocks from seed:** apple and pear seeds need **70–90 days [cold and moist](wiki:Stratification_(seeds))** (in damp sand or a
  damp paper towel in a sealed bag in the fridge); peach 90–120 days. Then plant them; graft when the
  seedling is about pencil-thick. ([Mississippi State *Basic Grafting*, p. 3](lib:basic-grafting-techniques#page=3))
- **Collect scionwood** while trees are dormant (here, **January–February**, before buds swell): last year's
  growth, pencil-thick, a foot or more long. Wrap in **damp (not wet)** paper towel or sawdust in a sealed
  bag, label it, and keep it at 34–38 °F. **Never store scions with apples or pears** — the gas they give
  off ruins them. ([Mississippi State, p. 3](lib:basic-grafting-techniques#page=3); [Kentucky, p. 4](lib:graftage#page=4); [🖼️ scion wood ready for storage](lib:basic-grafting-techniques#page=2))
- **When to graft:** [whip-and-tongue](wiki:Grafting) Feb–early March while dormant; **cleft**
  graft late Feb–March ([🖼️ cleft graft](lib:basic-grafting-techniques#page=5)); **bark** graft in spring once the bark slips ([🖼️ bark graft](lib:basic-grafting-techniques#page=6)). **Budding** (a single bud under the bark)
  in **July–September**. ([Mississippi State, pp. 3–4](lib:basic-grafting-techniques#page=3);
  [USDA FB 1567, p. 43](lib:propagation-of-trees-and-shrubs#page=43); [🖼️ T-budding](lib:basic-grafting-techniques#page=7))
- **Peaches and apricots** from seed often give usable fruit, but not the same as the parent *(rule of thumb)*.
- **Berries and grapes are easier:**
  - **Raspberries and blackberries:** bury a cane tip in late summer — it roots ("tip layering") — or dig
    suckers. ([Virginia Tech, p. 4](lib:propagation-by-cuttings#page=4); [🖼️ tip layering](lib:propagation-by-cuttings#page=4); [Layering](wiki:Layering))
  - **Strawberries:** root the [runners](wiki:Stolon). ([Virginia Tech, p. 5](lib:propagation-by-cuttings#page=5))
  - **Grapes:** dormant hardwood cuttings. ([USDA Grape Propagation](lib:grape-propagation); [🖼️ heeling in cuttings](lib:grape-propagation#page=5))
  - **Currants, gooseberries, apple rootstocks:** mound or stool layering. ([Virginia Tech, p. 5](lib:propagation-by-cuttings#page=5); [🖼️ mound layering](lib:propagation-by-cuttings#page=5))

📚 **Go deeper:** [Mississippi State *Basic Grafting Techniques*](lib:basic-grafting-techniques) — illustrated step by step; [Univ. of Kentucky *Budding and Grafting*](lib:graftage); [USDA *Propagation of Trees and Shrubs*](lib:propagation-of-trees-and-shrubs); [OSU *Growing Tree Fruits and Nuts*](lib:growing-tree-fruits-and-nuts); [PNW *Training and Pruning*](lib:training-and-pruning).

## 🍽️ Using the harvest

- **Can, freeze, pickle and dry** with the USDA and PNW guides in `Gardening-Food\`
  ([USDA canning — vegetables](lib:guide-4-vegetables); [pickling vegetables](lib:pickling-vegetables)):
  National Pickling cucumbers for [pickles](wiki:Pickled_cucumber), Early Jersey Wakefield cabbage for [sauerkraut](wiki:Sauerkraut)
  ([fermented foods](lib:guide-6-fermented)), Romas for sauce and drying, jalapeños for salsa
  ([salsa recipes](lib:salsa-recipes)).
- **Store roots, cabbages, squash and onions** without power — see the
  [Root Cellars & Food Storage](guide:ROOT-CELLAR-GUIDE) guide and
  [WSU *Storing Vegetables and Fruits*](lib:storing-vegetables-and-fruits-at-home).
- **Eat the whole plant:** beet, turnip and radish greens; pumpkin and squash seeds roasted; kale and
  collards through the winter.

📚 **Go deeper:** [USDA *Complete Guide to Home Canning*](lib:guide-1-principles); [PNW *Freezing Fruits and Vegetables*](lib:freezing-fruits-and-vegetables).

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Storing and testing seed**
- Seed moisture, humidity and storage life — [🖼️ Seed Processing and Storage, p. 13](lib:seed-processing-and-storage#page=13)
- How the container affects sprouting — [🖼️ Seed Processing and Storage, p. 15](lib:seed-processing-and-storage#page=15)
- Desiccant for seed jars — [Silica gel](wiki:Silica_gel)
- Sprouting seed — [Germination](wiki:Germination)

**Flowers and crossing**
- Male and female squash flowers, and their parts — [🖼️ Cucurbit Seed Production, p. 7](lib:cucurbit-seed-production#page=7)
- One squash species, many shapes — [🖼️ Cucurbit Seed Production, p. 5](lib:cucurbit-seed-production#page=5); [Cucurbita pepo](wiki:Cucurbita_pepo)
- Male and female cucumber flowers — [🖼️ Cucurbit Seed Production, p. 17](lib:cucurbit-seed-production#page=17)
- Cabbage-family crops, all one species — [Brassica oleracea](wiki:Brassica_oleracea)
- Old and modern tomato flowers — [🖼️ Isolation Distances, p. 9](lib:isolation-distances-for-seed-crops#page=9)
- Bees that cross-pollinate — [🖼️ Isolation Distances, p. 10](lib:isolation-distances-for-seed-crops#page=10); [Pollination](wiki:Pollination)
- Crossing falls off with distance — [🖼️ Brassica Seed Production, p. 9](lib:brassica-seed-production#page=9)
- Wild carrot (Queen Anne's lace) — [Daucus carota](wiki:Daucus_carota)

**Hand-pollinating and caging**
- Taping squash flowers shut — [🖼️ Cucurbit Seed Production, p. 13](lib:cucurbit-seed-production#page=13); [Hand pollination](wiki:Hand-pollination)
- Bagging corn ears and tassels — [🖼️ OSA sweet corn guide, p. 6](lib:how-to-breed-sweet-corn#page=6); [Corn silk](wiki:Corn_silk)
- Row cover on hoops (for cages and frost) — [🖼️ PNW 548, p. 10](lib:winter-vegetable-production#page=10); [Row cover](wiki:Row_cover)

**Cleaning seed**
- Threshing box — [🖼️ Seed Processing and Storage, p. 4](lib:seed-processing-and-storage#page=4); [Threshing](wiki:Threshing)
- Winnowing in front of a fan — [🖼️ OSA, p. 13](lib:osa-a-seed-saving-guide#page=13); [Winnowing](wiki:Winnowing)
- Getting pepper seed out — [🖼️ Pepper Seed Production, p. 12](lib:pepper-seed-production#page=12)
- Bean weevil — [Acanthoscelides obtectus](wiki:Acanthoscelides_obtectus)

**Biennials**
- Carrot stecklings ready for storage — [🖼️ OSA Carrot Seed Production, p. 8](lib:organic-carrot-seed-production#page=8)
- Trimming beet stecklings — [🖼️ OSA Beet Seed Production, p. 7](lib:organic-beet-seed-production#page=7)
- Raised beds on wet ground — [🖼️ PNW 548, p. 4](lib:winter-vegetable-production#page=4); [Raised-bed gardening](wiki:Raised-bed_gardening)

**Fruit trees and berries**
- Whip-and-tongue graft — [🖼️ Mississippi State, p. 3](lib:basic-grafting-techniques#page=3); [🖼️ Minnesota EB 437, p. 6](lib:grafting-and-budding-fruit-trees-eb-437#page=6); [Grafting](wiki:Grafting)
- Cleft graft — [🖼️ Mississippi State, p. 5](lib:basic-grafting-techniques#page=5); [🖼️ Minnesota EB 437, p. 7](lib:grafting-and-budding-fruit-trees-eb-437#page=7)
- Bark graft — [🖼️ Mississippi State, p. 6](lib:basic-grafting-techniques#page=6)
- T-budding — [🖼️ Mississippi State, p. 7](lib:basic-grafting-techniques#page=7); [🖼️ Minnesota EB 437, p. 11](lib:grafting-and-budding-fruit-trees-eb-437#page=11)
- Scion wood wrapped for cold storage — [🖼️ Mississippi State, p. 2](lib:basic-grafting-techniques#page=2); [Rootstock](wiki:Rootstock)
- Tip layering and mound layering — [🖼️ Virginia Tech, p. 4](lib:propagation-by-cuttings#page=4); [🖼️ p. 5](lib:propagation-by-cuttings#page=5); [Layering](wiki:Layering)
- Grape cuttings heeled in — [🖼️ USDA FB 471, p. 5](lib:grape-propagation#page=5)
- Strawberry runners — [Stolon](wiki:Stolon)

---

## 🔗 Related guides

- [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — grain, flour, bread and staples
- [Root Cellars & Food Storage](guide:ROOT-CELLAR-GUIDE) — keeping the harvest without power
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — frost dates, soils, local help
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — animal power for bigger gardens
