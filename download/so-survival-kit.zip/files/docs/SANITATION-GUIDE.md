# 🧼 Sanitation, Hygiene & Stopping Disease

When sewers, pumps and power fail, cholera, dysentery, typhoid and hepatitis follow, and they all travel
from human waste to someone's mouth. This guide covers toilets for every season in our clay soils, septic
systems with no power, greywater, handwashing, keeping clean with little water, lice and scabies,
stopping an outbreak, flies and mice, garbage, sickroom waste, and caring for the dead. The books are in
`Sanitation-Hygiene\` (`Latrines-Toilets`, `Septic-Greywater`, `Hygiene-Washing`, `Disease-Outbreaks`,
`Pests-Vectors`, `Waste-Burial`) and `Homestead-Skills\Sanitation-Water`. The twin-bucket toilet, soap
and cleaners are in the [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE); nursing the sick is in
the [Field Care guide](guide:FIELD-CARE-GUIDE).

> ### ⚠️ Rules that prevent the worst outcomes
> - **Keep every latrine, garbage pit and grave at least 100 ft (30 m) from wells, springs and creeks,
>   and downhill of them**, with the pit bottom 5 ft (1.5 m) above groundwater
>   ([Sphere, p. 140](lib:sphere-handbook-2018#page=140)). Some books say 65 ft (20 m). Use 100.
> - **Wash hands with soap or ash** after the toilet and before food. It cuts diarrhea by **42–47%**
>   ([Tippy-Tap, p. 1](lib:tippy-tap#page=1)).
> - **Diarrhea kills by drying people out.** Start the rehydration drink at the first watery stool
>   ([WTND ch. 13, p. 2](lib:where-there-is-no-doctor-13-some#page=2)).
> - **Never climb down into a septic tank, pit or vault.** The gases can kill in minutes *(rule of thumb)*.
> - **Never mix bleach with urine, ammonia or vinegar.** It makes poison gas
>   ([Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)).
> - **Never sweep or vacuum mouse droppings** (hantavirus), and **never burn plastic**.

---

## 🗺️ Choosing and siting a toilet in our soils

**Siting:** 100 ft (30 m) from any well, spring or creek, downhill of it, with the pit bottom 5 ft (1.5 m)
above the water table; more in cracked rock ([Sphere, p. 140](lib:sphere-handbook-2018#page=140)). Keep
latrines downwind and well away from the kitchen ([FM 21-10, p. 77](lib:us-army-fm-21-10#page=77)). On
gravelly Illinois River terraces sewage travels fast toward shallow wells, so add distance *(rule of thumb)*.

**Our clay is waterlogged in winter.** Valley-floor soils such as Brockman clay loam have a **perched winter water
table only 24–36 in down** and very slow drainage; septic drainfields "function poorly" on them
([Soil Survey, p. 33](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=33)). A pit
dug there in winter fills with water. So:
- **Dig pits in the dry season**, on higher, well-drained ground.
- **November to April, on the valley floor,** use a bucket toilet or a compost toilet built on top of the
  ground. The Army switches to a pail latrine whenever the water table is too high
  ([FM 21-10, p. 134](lib:us-army-fm-21-10#page=134); [🖼️ pail latrine, p. 135](lib:us-army-fm-21-10#page=135)).

| Situation | Use |
|---|---|
| One use, away from home | Cat hole ([🖼️ FM 21-10, p. 131](lib:us-army-fm-21-10#page=131)) |
| First 1–3 days, a few people | Straddle trench ([🖼️ FM 21-10, p. 133](lib:us-army-fm-21-10#page=133)) |
| Indoors, any season; winter on clay | [Twin-bucket toilet](guide:MAKE-DO-HOUSEHOLD-GUIDE) ([🖼️ photo, OSU p. 2](lib:osu-extension-survival-basics-sanitation#page=2)) or a [container toilet](wiki:Container-based_sanitation) |
| Months to years, one household, dry ground | Pit or VIP latrine ([🖼️ deep pit, FM 21-10 p. 134](lib:us-army-fm-21-10#page=134)) |
| A neighborhood or camp | Trench latrine ([🖼️ WHO/WEDC, p. 57](lib:who-wedc-technical-notes#page=57)) |
| Years, and you want fertilizer | Composting toilet, stored 2 years ([🖼️ EPA, p. 4](lib:epa-composting-toilets#page=4)) |

📚 **Go deeper:** [*Compendium of Sanitation Technologies in Emergencies*](lib:compendium-of-sanitation#page=38) — every emergency toilet, illustrated; [Hesperian Ch 7, p. 18](lib:building-toilets#page=18) — choosing a toilet site.

## ⛏️ Latrines step by step

- **[Cat hole](wiki:Cathole):** 6–12 in deep, used once and covered at once ([🖼️ FM 21-10, p. 131](lib:us-army-fm-21-10#page=131)).
- **Straddle trench:** **1 ft wide, 2½ ft deep, 4 ft long**, parallel trenches at least 2 ft apart. Cover
  each use with the dug earth ([Special Forces Handbook, p. 162](lib:special-forces-medical-handbook#page=162);
  [🖼️ FM 21-10, p. 133](lib:us-army-fm-21-10#page=133)),
  and cover well: a thin layer of soil can **increase** fly breeding
  ([Rozendaal, p. 321](lib:vector-control-methods#page=321)).
- **Simple pit:** a bit under 3 ft (1 m) across and 3–6½ ft (1–2 m) deep, under a slab whose hole has a
  lid that stays on ([WTND ch. 12, p. 9](lib:where-there-is-no-doctor-12-prevention#page=9)). Hesperian
  says at least 6½ ft deep, with the top lined so the edge can't collapse
  ([Ch 7, p. 19](lib:building-toilets#page=19)).
- **VIP latrine** ([pit latrine](wiki:Pit_latrine)): add a vent pipe that rises **at least 20 in (50 cm) above the roof, with fly
  screen on top** ([Hesperian Ch 7, p. 22](lib:building-toilets#page=22)), and keep the shelter **dark**, door shut. Smells go up the pipe; flies head for the
  light at its top and die there ([Practical Action *VIP Latrine*, p. 1](lib:practical-action-ventilated#page=1);
  [🖼️ how the air flows, Rozendaal p. 163](lib:vector-control-methods#page=163); [🖼️ Hesperian Ch 7, p. 22](lib:building-toilets#page=22)).
- **Neighborhood trench latrine:** about 3 ft wide, 5–10 ft deep, no more than 20 ft long, one stall per
  3 ft ([🖼️ WHO/WEDC, p. 57](lib:who-wedc-technical-notes#page=57)). Line the top 20 in so the edges don't cave in. Solids build up at **3–5 litres (about a gallon)
  per person per month** ([Compendium, p. 44](lib:compendium-of-sanitation#page=44)): a family of 5 fills
  about a cubic yard every 3 years *(arithmetic)*.
- **Closing a full pit:** when the waste is **1 ft below the surface**, fill the rest in packed 3-in
  layers and mound at least 1 ft of earth on top so fly pupae can't dig out
  ([Special Forces Handbook, p. 162](lib:special-forces-medical-handbook#page=162)). Or let it settle,
  top up, and **plant a tree** on it ([Hesperian Ch 7, p. 19](lib:building-toilets#page=19); [🖼️ a toilet for tree planting, p. 26](lib:building-toilets#page=26);
  [Arborloo](wiki:Arborloo)).

**Indoor vented bucket:** a lidded 5-gallon can lined with a heavy bag, with a hose taped into a hole near
the top and run outdoors to 6 in above the ground. A full bag lifts out tied
([Kearny, p. 108](lib:nuclear-war-survival-skills-1979-original#page=108)). **Bury or compost the bags**;
piled outside, they breed flies.

📚 **Go deeper:** [WHO/WEDC *Technical Notes*, p. 55](lib:who-wedc-technical-notes#page=55) — trench and family latrines; [Practical Action *VIP Latrine*](lib:practical-action-ventilated#page=1) — vent and slab.

## ♻️ Composting toilets, humanure and urine

**After every use**, cover the deposit with **1–2 cups (200–500 mL) of wood ash or lime**. It dries it,
raises the pH to kill germs over time, and cuts flies and smell
([SEI EcoSanRes, p. 39](lib:ecological-sanitation#page=39); [Humanure](wiki:Compost)). Lime burns skin and eyes: wear gloves and goggles.

**How long to store it before it touches a garden** ([SEI, pp. 39–40](lib:ecological-sanitation#page=39)),
with nothing fresh added:

| Treatment | Store at least |
|---|---|
| Average temperature 36–68 °F (2–20 °C) — **our climate** | **1½–2 years** |
| Average temperature 68–95 °F (20–35 °C) | More than 1 year |
| Kept alkaline, pH above 9 (plenty of ash or lime) | More than 6 months |
| Hot compost: **all** of it above 122 °F (50 °C) for a week | Hard to do at home |

Then wait **1 month between spreading and harvest** (p. 40). Our mean annual air temperature is 48–54 °F
([Soil Survey, p. 32](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=32)), so
**use the 2-year rule**: in home [composting toilets](wiki:Composting_toilet), temperatures "typically
never become high enough to rapidly destroy pathogens" ([EPA, p. 4](lib:epa-composting-toilets#page=4)).
**Build two chambers** on top of the ground, not in it, so they work in waterlogged soil, and use them in
turn ([Practical Action, p. 2](lib:practical-action-compost-toilets#page=2); [🖼️ a 2-chamber dry toilet, Hesperian Ch 7, p. 28](lib:building-toilets#page=28);
[🖼️ double-vault toilet, Compendium p. 60](lib:compendium-of-sanitation#page=60)). Make each big enough to
take a year or more to fill *(rule of thumb)*.

**Urine** carries few germs ([Kearny, p. 108](lib:nuclear-war-survival-skills-1979-original#page=108)),
and keeping it apart ([urine-diverting toilet](wiki:Urine-diverting_dry_toilet); [🖼️ urine-separating seats, SEI p. 35](lib:ecological-sanitation#page=35)) stops the smell
([OSU, p. 3](lib:osu-extension-survival-basics-sanitation#page=3)). On your own garden, dilute it with water and pour it on, but **stop on food crops a month before harvest**.
For crops others will eat, store it sealed 1 month, or 6 months to be safe
([SEI, pp. 21, 39](lib:ecological-sanitation#page=21)).

**Using the finished product:** worm eggs survive in soil for years ([SEI, p. 23](lib:ecological-sanitation#page=23)).
Use aged humanure around fruit trees, berries, and crops whose edible parts don't touch soil, never on
greens or root crops *(rule of thumb)*.

📚 **Go deeper:** [SEI *Safe Use of Urine and Faeces*](lib:ecological-sanitation#page=39) — the storage tables; [Practical Action *Compost Toilets*](lib:practical-action-compost-toilets#page=2) — building a two-chamber toilet.

## 🏠 Septic systems with no power, and greywater

**Find out now which kind of [septic system](wiki:Septic_tank) you have** ([🖼️ tank cross-section, Compendium p. 68](lib:compendium-of-sanitation#page=68);
[Drain field](wiki:Septic_drain_field)).
- **Gravity** (pipes slope down to the tank and drainfield) keeps working with no power
  ([Texas AgriLife, p. 2](lib:power-outages-and-floods#page=2)). Flush with a bucket of used wash water
  *(rule of thumb)*.
- **Pump tanks, sand filters, aerobic units, pressure or drip lines stop.** The reserve may be only
  **80 gallons** for a 3-bedroom house. Use water only to flush and wash hands, stop if drains slow, and
  **stop all use in a long outage** ([Texas AgriLife, p. 3](lib:power-outages-and-floods#page=3)); switch
  to a bucket toilet. Many Josephine County homes on clay or serpentine have these *(rule of thumb)*.

**With no pump trucks:** a tank needs pumping when scum is within 6 in of the outlet or sludge within 12 in,
normally every 3–5 years. Additives do nothing. Never pour grease, oil, solvents or paint down a drain
([EPA SepticSmart, pp. 3, 4, 7](lib:septicsmart#page=3)); keep food scraps and wipes out too *(rule of thumb)*.

**After a flood:** don't use it until water has left every part, and **don't pump a tank empty while the
ground is soaked**: it can float out of the ground ([Texas, p. 4](lib:power-outages-and-floods#page=4)).

**[Greywater](wiki:Greywater)**, following Oregon's rules
([DEQ, pp. 3–4](lib:oregon-deq-reusing-graywater#page=3)):
- Store it **no more than 24 hours**.
- Release it **at least 2 in under soil or mulch**, 4 ft above groundwater, 100 ft from wells, and never
  onto edible parts of crops or root vegetables ([🖼️ a simple system, DEQ p. 15](lib:oregon-deq-reusing-graywater#page=15)).
- A **soak pit** ([🖼️ FM 21-10, p. 130](lib:us-army-fm-21-10#page=130)) is 5–13 ft deep, filled with rocks, 6½ ft above the highest groundwater. **Clay won't take
  it** ([Compendium, p. 150](lib:compendium-of-sanitation#page=150)). On valley clay in winter, carry
  greywater to higher ground or use it to flush *(rule of thumb)*.
- **Kitchen water:** a barrel grease trap (gravel, then ashes or sand, burlap on top), cleaned every 2
  days ([Special Forces Handbook, p. 164](lib:special-forces-medical-handbook#page=164); [🖼️ FM 21-10, p. 131](lib:us-army-fm-21-10#page=131);
  [Grease trap](wiki:Grease_trap)).

📚 **Go deeper:** [Texas AgriLife *Septic Systems in Outages and Floods*](lib:power-outages-and-floods#page=2) — which systems stop; [EPA *Homeowner's Guide to Septic Systems*](lib:septicsmart#page=3); [Oregon DEQ *Reusing Graywater*](lib:oregon-deq-reusing-graywater#page=3).

## 🧼 Handwashing and water for hygiene

**Build a [tippy tap](wiki:Hand_washing)** ([USAID, pp. 1–2](lib:tippy-tap#page=1)):
1. Take a 1½-gallon (5 L) plastic jug **with a handle**. Warm the base of the handle over a candle, pinch
   it shut with pliers, and let it cool watertight.
2. With a candle-heated nail, make a **small hole** in the handle just above the seal, and two bigger holes
   in the back, halfway up, for the hanging string.
3. Hang it from a stick so the full jug tilts at 45°. Hang **soap on a string under an upside-down tin
   can**. Pull a string tied to the cap to tip water onto your hands.
4. Scrub the outside daily; clean the inside weekly.

Put one **within 16 ft (5 m) of every toilet** and wherever food is made. No water? Rub hands with ash or
alcohol hand rub ([Compendium, p. 40](lib:compendium-of-sanitation#page=40)). Sanitizer needs **60%+
alcohol** and fails on visibly dirty hands ([OSU, p. 4](lib:osu-extension-survival-basics-sanitation#page=4)).
See [hand washing](wiki:Hand_washing) ([🖼️ the steps, WHO/WEDC p. 40](lib:who-wedc-technical-notes#page=40);
[🖼️ WHO handwashing steps, MCPC pp. 51–53](lib:managing-complications-in-pregnancy#page=51); [🖼️ field handwashing devices, FM 21-10 p. 139](lib:us-army-fm-21-10#page=139))
and [hand sanitizer](wiki:Hand_sanitizer).

**Wash hands** **before** cooking, eating or feeding anyone, and **after** the toilet, caring for someone
with diarrhea, cleaning a child's bottom, cleaning up feces or vomit, or touching a body
([MSF Cholera, p. 46](lib:management-of-a-cholera#page=46)).

**How much water** ([WHO/WEDC, pp. 36–37](lib:who-wedc-technical-notes#page=36)):

| Use | Per person per day |
|---|---|
| Drinking | 2.5–3 L (about ¾ gal) |
| Hygiene | 2–6 L |
| Cooking | 3–6 L |
| **Bare survival, total** | **7.5–15 L (2–4 gal)** |
| **Minimum for real hygiene** | **20 L (5 gal)** |
| A cholera patient | 60 L, plus 15 L for the carer |

**Enough water matters as much as safe water** ([Hesperian Ch 5, p. 3](lib:unsafe-water#page=3)).

📚 **Go deeper:** [*Tippy-Tap*](lib:tippy-tap#page=1) — the picture guide; [WHO/WEDC, p. 36](lib:who-wedc-technical-notes#page=36) — water quantities; [Army FM 21-10](lib:us-army-fm-21-10#page=10) — field hygiene for a group.

## 🧺 Dishes, laundry and periods

**Dishes:** scrape scraps into a bucket for the chickens. Wash in hot soapy water (120–140 °F) and rinse.
Then **dip in boiling water for 10 seconds**, or in **1 Tbsp unscented bleach per gallon**, and
**air-dry** ([FM 21-10, p. 114](lib:us-army-fm-21-10#page=114); [OSU EM9273, p. 3](lib:open-air-poultry-slaughter#page=3)).

**Laundry:** soap and cold water **don't** get rid of lice. Wash clothes and bedding **above 140 °F
(60 °C)**, then iron or dry in full sun ([Rozendaal, p. 274](lib:vector-control-methods#page=274)). No hot
water? **Seal them in a plastic bag for 72 hours** for scabies, or 2 weeks for head-lice items
([MSF Clinical Guidelines, pp. 133, 136](lib:msf-clinical-guidelines#page=133)). **Never wash a sick
person's clothes in a creek** or any drinking source ([MSF Cholera, p. 46](lib:management-of-a-cholera#page=46)).

**Periods:** a year's supply per woman is **6 reusable pads** (or 4 m² of absorbent cotton), **6 pairs
of underwear**, and an extra 250 g (½ lb) of soap a month ([Sphere, p. 129](lib:sphere-handbook-2018#page=129)).
Change cloth [pads](wiki:Menstrual_pad) ([🖼️ pattern, WASHplus](lib:making-reusable-menstrual-pads#page=1)) several times a day, wash with soap and dry in the sun. Change a
tampon **at least 3 times a day**, or it can cause serious infection
([WWHND ch. 5, p. 4](lib:where-women-have-no-doctor-05#page=4)). Plan a private place to wash and dry pads
by the latrine ([Compendium, p. 44](lib:compendium-of-sanitation#page=44)).

📚 **Go deeper:** [WASHplus pad pattern](lib:making-reusable-menstrual-pads#page=1) — sew your own; [FM 21-10, p. 114](lib:us-army-fm-21-10#page=114) — dishwashing setup; [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — laundry soap and hand washing.

## 🦠 How germs spread, and stopping an outbreak

**The "F-diagram"** ([fecal–oral route](wiki:Fecal–oral_route)): germs from feces reach the mouth by
**fingers, flies, fields, fluids (water) and food**. Every barrier counts: latrines, handwashing, safe
water, covered food, animals kept out of the house ([Hesperian Ch 5, p. 6](lib:unsafe-water#page=6);
[WTND ch. 12, p. 3](lib:where-there-is-no-doctor-12-prevention#page=3); [🖼️ the barriers drawn, WHO/WEDC p. 39](lib:who-wedc-technical-notes#page=39);
[🖼️ SEI p. 12](lib:ecological-sanitation#page=12)).

**An outbreak is starting** when you see bloody diarrhea, watery diarrhea in anyone over 5, suspected
cholera, or yellow eyes or skin in several people. Start isolation and hygiene measures neighborhood-wide
([WHO, p. 115](lib:communicable-disease-control#page=115)).

**"Enteric isolation"** ([cholera](wiki:Cholera), [shigella dysentery](wiki:Shigellosis), [typhoid](wiki:Typhoid_fever), E. coli, [hepatitis A](wiki:Hepatitis_A)) means handwashing, the
sick person's own dishes, and safe disposal of their feces and soiled things
([WHO, p. 133](lib:communicable-disease-control#page=133)).
- **Typhoid:** a separate room; stools buried deep. People who recover can carry it for a long time and
  **must not cook for others** ([WTND ch. 14, p. 12](lib:where-there-is-no-doctor-14-serious#page=12)).
- **Hepatitis A and E:** antibiotics don't help, and **acetaminophen (Tylenol) further damages the liver**
  ([WTND ch. 13, p. 22](lib:where-there-is-no-doctor-13-some#page=22)).

**Isolate kindly** ([WHO, p. 132](lib:communicable-disease-control#page=132)): let **one family member**
care for each sick person, with gloves and an apron and a lesson in using them. Explain isolation to
everyone. **Shame and fear make people hide sick relatives**, and hidden cases spread the outbreak.

**Rehydration drink** ([WTND ch. 13, p. 2](lib:where-there-is-no-doctor-13-some#page=2);
[oral rehydration](wiki:Oral_rehydration_therapy); [🖼️ drawn, Hesperian Ch 5, p. 10](lib:unsafe-water#page=10)): 1 litre (about 1 quart) of clean water and **½ level
teaspoon salt**. Taste it: it must be **less salty than tears**. Then add **8 level teaspoons sugar**.
Keep giving food and breast milk.

**Cholera or bloody diarrhea in the house** ([MSF Cholera, pp. 46–48](lib:management-of-a-cholera#page=46)):
1. Wipe up vomit or feces first, put it in the latrine or bury it, then wash the spot with soap.
2. Wash the sick person's clothes and bedding with soap and dry them in the sun. Sun the mattress too: the
   cholera germ dies when dried.
3. **Don't spray whole houses with chlorine.** No study shows it helps, and it makes families hide cases.
   A kit of bucket, soap, detergent and cloths does more.

📚 **Go deeper:** [WHO *Communicable Disease Control in Emergencies*](lib:communicable-disease-control#page=132) — isolation and disease pages; [MSF *Management of a Cholera Epidemic*](lib:management-of-a-cholera#page=46) — household rules.

## 🧪 Chlorine strengths from household bleach

**These are for cleaning — never for drinking.** Even the weakest (0.05%) is far too strong to drink.
To make **drinking water** safe, use **8 drops of 6% bleach (6 drops of 8.25%) per gallon** and wait 30
minutes ([Water Purification guide](guide:WATER-PURIFICATION-GUIDE);
[EPA, p. 2](lib:epa-emergency-disinfection-of-drinking-water#page=2)).

| Strength | Use it for ([Compendium, p. 174](lib:compendium-of-sanitation#page=174)) | From **6%** bleach | From **8.25%** bleach |
|---|---|---|---|
| **0.05%** | Skin and hands (if no soap), laundry, latrines, kitchen | About **2 Tbsp per gallon** | About **1½ Tbsp per gallon** |
| **0.2%** | Floors, beds, clothes, objects | About **½ cup per gallon** | About **6 Tbsp per gallon** |
| **2%** | Feces, vomit, washing bodies | **1 part bleach + 2 parts water** | **1 part bleach + 3 parts water** |

The rule is **parts of water = (bleach % ÷ % wanted) − 1** ([MSF Cholera, p. 226](lib:management-of-a-cholera#page=226));
the amounts above are that arithmetic.
- Read the strength on the label; use plain, unscented bleach.
- **Mix fresh every day**, and clean first: bleach doesn't work through dirt.
- **Never** pour it into a urine bucket or mix it with ammonia or vinegar.
- Drinking water needs a far weaker dose: see the [Water Purification guide](guide:WATER-PURIFICATION-GUIDE).

📚 **Go deeper:** [MSF Cholera, p. 226](lib:management-of-a-cholera#page=226) — dilution tables; [Compendium, p. 174](lib:compendium-of-sanitation#page=174) — cholera disinfection.

## 🪰 Flies, mosquitoes, lice and scabies

**Flies** ([housefly](wiki:Housefly)) go from egg to adult in **6–42 days**, faster in heat
([Rozendaal, p. 314](lib:vector-control-methods#page=314); [🖼️ the fly and its life cycle, p. 315](lib:vector-control-methods#page=315)). In hot weather **empty and bury garbage at
least twice a week**: maggots leave closed bins after 3–4 days. Cover a garbage pit with fresh soil at
least weekly; fit latrines with tight lids or screened vents (p. 321; [🖼️ tight-lidded bins, p. 321](lib:vector-control-methods#page=321);
[🖼️ a fly- and mosquito-proof latrine lid, p. 160](lib:vector-control-methods#page=160)). June–September is peak fly season
here *(rule of thumb)*.

**Mosquitoes** take about 7–13 days from egg to adult, so **empty and scrub small water containers
weekly**, and cover barrels with tight lids or netting ([Rozendaal, pp. 23, 156](lib:vector-control-methods#page=156);
[🖼️ mosquito life cycle, p. 22](lib:vector-control-methods#page=22); [🖼️ lids and netting, p. 156](lib:vector-control-methods#page=156); [Mosquito](wiki:Mosquito)).
Ditches, stock tanks, old tires and open rain barrels breed them here, and West Nile virus has been found
in southern Oregon *(rule of thumb)* ([West Nile virus](wiki:West_Nile_virus); [Culex tarsalis](wiki:Culex_tarsalis)).

**Body lice** ([body louse](wiki:Body_louse)) live and lay eggs **in clothing seams**, and spread typhus,
relapsing fever and trench fever. Hot washing and ironing fix it; in an outbreak, dust **0.5% permethrin
powder** inside clothes ([Rozendaal, p. 274](lib:vector-control-methods#page=274); [🖼️ how to dust clothing, p. 275](lib:vector-control-methods#page=275);
[MSF Clinical, p. 136](lib:msf-clinical-guidelines#page=136)). **[Head lice](wiki:Head_louse)** ([🖼️ the three kinds of lice, Rozendaal p. 266](lib:vector-control-methods#page=266); [🖼️ checking hair and combing, pp. 268–271](lib:vector-control-methods#page=268)): **dimeticone (from age 6 months) or 1% permethrin
(from 2 months) lotion, repeated after 7 days**; treat only contacts with live lice or nits (same page).

**[Scabies](wiki:Scabies)** ([🖼️ the mite and an infested wrist, Rozendaal pp. 291–292](lib:vector-control-methods#page=291); [Sarcoptes scabiei](wiki:Sarcoptes_scabiei)): itching worse at night, with fine wavy burrows between the fingers and on the
wrists. **Treat everyone in close contact at the same time, even if they don't itch**: **permethrin 5%
cream** (age 2 months and up) left on 8 hours, repeated after 7 days. Wash bedding hot or bag it 72 hours
([MSF Clinical, pp. 133–134](lib:msf-clinical-guidelines#page=133)). A first-time rash can take 4–6 weeks
to show, so one case means others are probably infested already
([Rozendaal, p. 292](lib:vector-control-methods#page=292)). Stock permethrin and dimeticone now *(rule of
thumb)*. Ticks ([western black-legged tick](wiki:Ixodes_pacificus)) are in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE).

📚 **Go deeper:** [WHO *Vector Control* (Rozendaal)](lib:vector-control-methods#page=314) — flies, mosquitoes, lice, fleas and mites; [MSF Clinical Guidelines, p. 133](lib:msf-clinical-guidelines#page=133) — scabies and lice treatment.

## 🐭 Mice, hantavirus, fleas and plague

**Hantavirus:** in the West the [deer mouse](wiki:Western_deer_mouse) carries it, and people usually catch
it by breathing dust from droppings. Illness starts **1–8 weeks** later with fever, aches and vomiting;
4–10 days after that comes [shortness of breath](wiki:Hantavirus_pulmonary_syndrome). There is no specific
treatment ([NPS, p. 1](lib:hantavirus-fact-sheet#page=1)). Woodsheds, cabins, root cellars and
barns here all hold deer mice *(rule of thumb)*.

**Keep them out:** seal every gap **wider than ¼ in** ([🖼️ gaps around pipes, USDA p. 18](lib:rat-proofing-buildings#page=18)), keep food and trash sealed, and keep plants 18 in from
walls ([NPS, p. 1](lib:hantavirus-fact-sheet#page=1)). Use snap traps ([Mousetrap](wiki:Mousetrap)) or cats, not poison, which kills pets
and children ([WTND ch. 14, p. 12](lib:where-there-is-no-doctor-14-serious#page=12)).

**Cleaning up droppings** ([NPS, p. 2](lib:hantavirus-fact-sheet#page=2)):
1. Open the windows and **leave for 30 minutes**. **Never sweep or vacuum.**
2. With gloves on, soak droppings, nests and dead mice with **1:10 bleach (about 1½ cups per gallon of
   water), mixed fresh that day**. Spray 2 ft around, and wait **at least 10 minutes**.
3. Wipe up with paper towels. Pick up dead mice with a bag turned inside out over your gloved hand.
   Double-bag everything.
4. Spray the gloves before taking them off, then wash your hands with soap.

**Fleas and [plague](wiki:Plague_(disease)):** flea cocoons can wait **up to a year** in an empty house and hatch all at once when
people move in ([Rozendaal, p. 256](lib:vector-control-methods#page=256); [🖼️ rat, human and cat fleas, p. 255](lib:vector-control-methods#page=255);
[Oriental rat flea](wiki:Oriental_rat_flea)). **Don't handle dead rats or
squirrels**: their fleas jump to people. Drown dead rats, then burn them
([WTND ch. 14, p. 12](lib:where-there-is-no-doctor-14-serious#page=12)), or bury them deep in fire season.
Plague lives in wild ground squirrels ([California ground squirrel](wiki:California_ground_squirrel)), chipmunks and their fleas in parts of Oregon. Keep cats from hunting,
and treat a cat with a swollen neck or fever as dangerous *(rule of thumb)*.

📚 **Go deeper:** [NPS *Hantavirus Fact Sheet*](lib:hantavirus-fact-sheet#page=2) — cleanup steps; [USDA *Rat Proofing Buildings*, p. 27](lib:rat-proofing-buildings#page=27) — keeping rodents out.

## 🗑️ Garbage, sickroom and birth waste

**Garbage:**
- Compost food scraps or feed them to animals. Burn only clean paper and cardboard, in the cooking fire.
- **Never burn plastic or rubber**: even a little releases dioxins ([Hesperian Ch 18, p. 24](lib:ch-18-solid-waste#page=24)).
- **June to October, burn nothing in the open; bury it.** Trash fires start wildfires *(rule of thumb)*.
- A **garbage pit** is 4 ft square and 4 ft deep, filled to 1 ft below ground and mounded over with earth,
  **never within 100 ft of drinking water** ([Special Forces Handbook, p. 164](lib:special-forces-medical-handbook#page=164);
  [🖼️ FM 21-10, p. 129](lib:us-army-fm-21-10#page=129); [🖼️ WHO/WEDC, p. 29](lib:who-wedc-technical-notes#page=29)).
  Cover each layer with about 4 in of soil or ash, and a full pit with at least 20 in
  ([WHO/WEDC, p. 29](lib:who-wedc-technical-notes#page=29)).

**Sickroom and birth waste** ([Hesperian Ch 19, pp. 21–22](lib:ch-19-health-care-waste#page=21)):
- Needles and blades go in a **hard, sealed container** ([🖼️ Hesperian Ch 19, p. 17](lib:ch-19-health-care-waste#page=17); [Sharps waste](wiki:Sharps_waste)).
- Dig a waste pit **165 ft (50 m) from water and buildings**, downhill from wells, its bottom 5 ft above
  the water table.
- After each load, cover with **4 in of soil**, or soil mixed with lime.
- When it's 20 in from the top, cover with 20 in of soil and seal with **4–12 in (10–30 cm) of concrete**
  ([🖼️ the finished pit, p. 22](lib:ch-19-health-care-waste#page=22)).
- A placenta can go into the latrine or a deep burial ([p. 12](lib:ch-19-health-care-waste#page=12)).

📚 **Go deeper:** [Hesperian Ch 18 *Solid Waste*](lib:ch-18-solid-waste#page=24) — reducing and burying trash; [Hesperian Ch 19 *Health Care Waste*](lib:ch-19-health-care-waste#page=21) — building the waste pit.

## ⚰️ Caring for the dead

**Bodies don't cause epidemics** when people died of injury, fire, cold or hunger. The exceptions are
deaths from cholera, Ebola-type fevers and similar infections
([PAHO, p. 17](lib:management-of-dead-bodies#page=17)). Handlers need **waterproof gloves, an apron and
boots**, and must wash with soap before eating; masks aren't essential (p. 18; [🖼️ photo of the gear, p. 18](lib:management-of-dead-bodies#page=18)).

**Burial** ([PAHO, p. 38](lib:management-of-dead-bodies#page=38); [WHO/WEDC, p. 33](lib:who-wedc-technical-notes#page=33)):
- An **individual, marked grave 5–10 ft (1.5–3 m) deep**, **no lime or chemicals** on the body
  ([🖼️ wrapping a body for burial, WHO/WEDC p. 32](lib:who-wedc-technical-notes#page=32)).
- At least **100 ft (30 m) from springs or streams** and **650 ft (200 m) from any well**.
- At least 4 ft between the grave bottom and the water table (5 ft in sand). With our valley clay wet 2–3
  ft down in winter, choose higher, well-drained ground, and choose it now *(rule of thumb)*.
- Record who is buried where, on a map and with a durable marker.

**After a cholera death** ([MSF Cholera, pp. 47–48](lib:management-of-a-cholera#page=47)): bury **within
24 hours**, near the place of death, **more than 165 ft (50 m) from water**, under at least 3 ft of soil.
Wash hands after touching the body. **Funeral meals cooked by people who handled the body spread
cholera.** Let families keep their customs with these hygiene rules; banning funerals makes people hide
deaths (p. 48). *While laws are enforced,* ask the county about private burial.

📚 **Go deeper:** [PAHO *Management of Dead Bodies after Disasters*](lib:management-of-dead-bodies#page=17) — myths, handling and graves; [WHO/WEDC, p. 33](lib:who-wedc-technical-notes#page=33) — disposal of the dead.

## ⚠️ Old advice in the library to ignore

- **The "burn-out latrine"**, burned daily with **1 qt gasoline to 5 qt diesel**
  ([Special Forces Handbook, p. 162](lib:special-forces-medical-handbook#page=162)). It wastes fuel and
  risks burns and wildfire; the same page admits burning and lime don't stop flies or smell. Use a lidded
  pit, VIP or bucket toilet, with ash.
- **Spraying latrine pits with insecticide twice a week** (same page). Use tight lids, screened vents and ash.
- **DDT and lindane** for lice, scabies and spraying ([Rozendaal, pp. 274, 293](lib:vector-control-methods#page=274)).
  Obsolete and toxic. Use permethrin or dimeticone.
- **Tossing each day's waste bag outside** ([Kearny, p. 108](lib:nuclear-war-survival-skills-1979-original#page=108)).
  Fine for two weeks in a fallout shelter; for long-term living, bury or compost the bags.
- **Boiling laundry "with soap and kerosene"**
  ([*Household Discoveries*, p. 191](lib:household-discoveries-encyclopaedia#page=191)). Fire and fume
  hazard. Use hot soapy water and sun.
- **Concrete "at least 90 centimeters thick"** over a waste pit
  ([*A Book for Midwives*, p. 22](lib:a-book-for-midwives-05-preventing-infection#page=22)). Almost
  certainly a misprint: Hesperian says **10–30 cm** ([Ch 19, p. 22](lib:ch-19-health-care-waste#page=22)).
- **Lime on dead bodies.** PAHO says don't ([p. 38](lib:management-of-dead-bodies#page=38)). Lime *does*
  help dry and disinfect waste in compost toilets and sickroom-waste pits.
- **Latrines only 65 ft (20 m) from water** ([WTND ch. 12, p. 9](lib:where-there-is-no-doctor-12-prevention#page=9);
  [Hesperian Ch 7, p. 18](lib:building-toilets#page=18)). Sphere, the Army and Oregon use 100 ft. Use 100.

📚 **Go deeper:** [Sphere, p. 140](lib:sphere-handbook-2018#page=140) — the 30 m rule; [MSF Clinical Guidelines, p. 133](lib:msf-clinical-guidelines#page=133) — modern scabies and lice treatment.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Toilets**
- Cat hole, straddle trench, deep pit and pail latrine — [🖼️ FM 21-10, pp. 131–135](lib:us-army-fm-21-10#page=131); [Cat hole](wiki:Cathole)
- Trench latrines for a neighborhood — [🖼️ WHO/WEDC, p. 57](lib:who-wedc-technical-notes#page=57); [🖼️ Compendium, p. 44](lib:compendium-of-sanitation#page=44)
- VIP latrine and how its vent works — [🖼️ Rozendaal, p. 163](lib:vector-control-methods#page=163); [🖼️ Hesperian Ch 7, p. 22](lib:building-toilets#page=22); [🖼️ Compendium, p. 50](lib:compendium-of-sanitation#page=50)
- Raised latrine for wet ground — [🖼️ WHO/WEDC, p. 58](lib:who-wedc-technical-notes#page=58); [🖼️ Compendium, p. 56](lib:compendium-of-sanitation#page=56)
- Twin-bucket and hose-vented bucket toilets — [🖼️ OSU, p. 2](lib:osu-extension-survival-basics-sanitation#page=2); [🖼️ Kearny, p. 108](lib:nuclear-war-survival-skills-1979-original#page=108); [Container toilet](wiki:Container-based_sanitation)
- Filling a shallow pit and planting a tree on it — [🖼️ Hesperian Ch 7, p. 26](lib:building-toilets#page=26); [🖼️ Compendium, p. 140](lib:compendium-of-sanitation#page=140); [Arborloo](wiki:Arborloo)

**Compost, urine, septic and greywater**
- Composting toilet cross-section — [🖼️ EPA, p. 4](lib:epa-composting-toilets#page=4); [Composting toilet](wiki:Composting_toilet)
- Two-chamber dry toilets — [🖼️ Hesperian Ch 7, p. 28](lib:building-toilets#page=28); [🖼️ Compendium, p. 60](lib:compendium-of-sanitation#page=60); [Humanure](wiki:Compost)
- Urine-separating seats — [🖼️ SEI, pp. 33–35](lib:ecological-sanitation#page=33); [Urine-diverting dry toilet](wiki:Urine-diverting_dry_toilet)
- Septic tank — [🖼️ Compendium, p. 68](lib:compendium-of-sanitation#page=68); [Septic tank](wiki:Septic_tank); [Drain field](wiki:Septic_drain_field)
- Greywater, soak pit, grease trap — [🖼️ DEQ, p. 15](lib:oregon-deq-reusing-graywater#page=15); [🖼️ FM 21-10, pp. 130–131](lib:us-army-fm-21-10#page=130); [🖼️ Compendium soak pit, p. 150](lib:compendium-of-sanitation#page=150); [Grease trap](wiki:Grease_trap)

**Handwashing and hygiene**
- Tippy tap — [🖼️ USAID, pp. 1–2](lib:tippy-tap#page=1); [🖼️ Hesperian Ch 5, p. 15](lib:unsafe-water#page=15); [Tippy tap](wiki:Hand_washing)
- How to wash hands — [🖼️ WHO/WEDC, p. 40](lib:who-wedc-technical-notes#page=40); [🖼️ MCPC, p. 51](lib:managing-complications-in-pregnancy#page=51); [Hand washing](wiki:Hand_washing)
- Field handwashing and shower stands — [🖼️ FM 21-10, pp. 139–140](lib:us-army-fm-21-10#page=139)
- Sewing reusable pads — [🖼️ WASHplus pattern](lib:making-reusable-menstrual-pads#page=1); [Menstrual pad](wiki:Menstrual_pad)

**Germs and outbreaks**
- The F-diagram: barriers between feces and mouths — [🖼️ WHO/WEDC, p. 39](lib:who-wedc-technical-notes#page=39); [🖼️ Hesperian Ch 5, p. 6](lib:unsafe-water#page=6); [Fecal–oral route](wiki:Fecal–oral_route)
- Mixing the rehydration drink — [🖼️ Hesperian Ch 5, p. 10](lib:unsafe-water#page=10); [Oral rehydration](wiki:Oral_rehydration_therapy)

**Flies, mosquitoes, lice, fleas, mice**
- Housefly and its life cycle — [🖼️ Rozendaal, p. 315](lib:vector-control-methods#page=315); [Housefly](wiki:Housefly)
- Tight-lidded bins and latrine lids — [🖼️ Rozendaal, p. 321](lib:vector-control-methods#page=321); [🖼️ p. 160](lib:vector-control-methods#page=160)
- Mosquito life cycle; covering water containers — [🖼️ Rozendaal, p. 22](lib:vector-control-methods#page=22); [🖼️ p. 156](lib:vector-control-methods#page=156); [Culex tarsalis](wiki:Culex_tarsalis)
- Head, body and crab lice — [🖼️ Rozendaal, pp. 266–267](lib:vector-control-methods#page=266); [Head louse](wiki:Head_louse); [Body louse](wiki:Body_louse)
- Scabies mite and burrows — [🖼️ Rozendaal, pp. 291–292](lib:vector-control-methods#page=291); [Scabies](wiki:Scabies)
- Rat, human and cat fleas — [🖼️ Rozendaal, pp. 255–256](lib:vector-control-methods#page=255); [Oriental rat flea](wiki:Oriental_rat_flea)
- Deer mice; closing gaps rats use — [Western deer mouse](wiki:Western_deer_mouse); [🖼️ USDA, pp. 17–18](lib:rat-proofing-buildings#page=17)

**Waste and the dead**
- Garbage pits — [🖼️ FM 21-10, p. 129](lib:us-army-fm-21-10#page=129); [🖼️ WHO/WEDC, p. 29](lib:who-wedc-technical-notes#page=29)
- Sharps and the sickroom-waste pit — [🖼️ Hesperian Ch 19, p. 17](lib:ch-19-health-care-waste#page=17); [🖼️ p. 22](lib:ch-19-health-care-waste#page=22); [Sharps waste](wiki:Sharps_waste)
- Gear for handling bodies; wrapping for burial — [🖼️ PAHO, p. 18](lib:management-of-dead-bodies#page=18); [🖼️ WHO/WEDC, p. 32](lib:who-wedc-technical-notes#page=32)

---

## 🔗 Related guides

- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — the twin-bucket toilet, soap, cleaners, laundry, ticks
- [Water Purification](guide:WATER-PURIFICATION-GUIDE) — making drinking water safe
- [Water Wells, Pumps, Springs & Cisterns](guide:WATER-WELLS-GUIDE) — protecting wells and springs
- [Field Care](guide:FIELD-CARE-GUIDE) — treating diarrhea and dehydration, nursing the sick
- [Childbirth & Children](guide:CHILDBIRTH-CHILDREN-GUIDE) — clean birth and diapers
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local soils, burn permits, fire season
