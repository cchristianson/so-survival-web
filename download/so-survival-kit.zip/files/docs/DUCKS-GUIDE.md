# 🦆 Ducks: Eggs, Meat and Slug Control

How to keep ducks that feed a household and renew themselves with no feed store, vet, hatchery or electricity: choosing breeds, turning ducks loose on the slugs
of our wet winters without losing the garden, a dry house, feeding on forage and home-grown grain, niacin, eggs, hatching under hens or Muscovies, brooding with
no power, predators, sickness, plucking with a beeswax dip, down, and how many ducks a family needs. Where duck-keeping is the same as chicken-keeping, this
guide sends you to the [Chickens guide](guide:CHICKENS-GUIDE) instead of repeating it. The duck books are in `Animals\Poultry` (USDA *Duck Raising*, *Raising
Healthy Poultry*, *Practical Poultry Raising*), with more in `Small-Livestock\Chickens`, `Small-Livestock\Slaughter-Processing`,
`Animals\Planning-Predators-Toxic-Plants` and `Gardening-Food` (all under `Southern-Oregon\`; the download list is local/illinois-valley-files.txt). *Raising a
Few Ducks* (MSU) is on the drive but has no readable text, so nothing here comes from it. Where this guide works a number out itself it says *(arithmetic)*;
check it with the [Calculator](guide:CALCULATOR).

> ### The short version
> - **Lock ducks in every night and keep them in until mid-morning.** Great horned owls take ducks
>   ([Kentucky ID-245, p. 4](lib:predator-management-for-small-scale-poultry#page=4)), and ducks lay early, so the eggs end up in the house, not the pond
>   ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)).
> - **Ducks clean slugs out of a garden that isn't growing.** They "keep a mature garden free of snails and slugs. Don't let them in a growing garden — they
>   will devour it" ([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)). Their big months are **September–October, before
>   slugs lay their eggs** ([OSU EM 9027, p. 15](lib:osu-growing-your-own-practical-guide-to-gardening-in-oregon-em-9027#page=15)).
> - **Water outside, bedding dry.** Duck droppings are **over 90% water**; put waterers as far from the house as you can
>   ([Raising Healthy Poultry, p. 103](lib:raising-healthy-poultry-cvm#page=103)). Moldy straw causes a fungal pneumonia.
> - **Never feed moldy grain:** **0.75 ppm of aflatoxin can kill a duckling** ([FAO, p. 51](lib:small-scale-poultry-production-technical-guide#page=51)). Sour
>   mash causes convulsions and death ([FB 697, p. 23](lib:duck-raising-usda-farmers-bulletin-697#page=23)).
> - **Khaki Campbells and Runners lay 230–300+ eggs a year** ([Raising Healthy Poultry, p. 97](lib:raising-healthy-poultry-cvm#page=97)), but Runners and Pekins
>   "rarely sit" ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)): a **Muscovy** or a broody hen hatches for you. Duck eggs take **28
>   days**, Muscovy eggs about **35** ([Raising Healthy Poultry, p. 109](lib:raising-healthy-poultry-cvm#page=109)).
> - **Ducklings: warm and dry.** About **90 °F the first week, 5 °F less each week**
>   ([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)), and **no swimming until feathered at 6–8 weeks**
>   ([FB 697, p. 15](lib:duck-raising-usda-farmers-bulletin-697#page=15)).
> - **Keep ducks away from wild waterfowl and stagnant ponds:** bird flu, duck plague and botulism
>   ([Raising Healthy Poultry, pp. 78, 116–118](lib:raising-healthy-poultry-cvm#page=116)).
> - **Dry-pluck right after bleeding to save the down**; a beeswax dip takes the last of it, and the wax is melted down and used again
>   ([Slaughter and Preservation of Meat, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84);
>   [Practical Poultry Raising, p. 194](lib:practical-poultry-raising-peace-corps#page=194)).

---

## 🦆 Choosing ducks: layers, meat breeds and Muscovies

The common breeds all come from the wild [Mallard](wiki:Mallard) and cross freely; the [Muscovy](wiki:Muscovy_duck) is a different species
([Raising Healthy Poultry, p. 95](lib:raising-healthy-poultry-cvm#page=95)). Ducks are "hardy, disease-resistant foragers", often easier to care for than
chickens ([Practical Poultry Raising, p. 191](lib:practical-poultry-raising-peace-corps#page=191)).

| Breed | Kept for | Size (drake / duck) | Eggs a year | Sits on eggs? |
|---|---|---|---|---|
| **[Khaki Campbell](wiki:Khaki_Campbell)** | **Eggs** | about 4.4 / 4 lb ([FAO, p. 14](lib:small-scale-poultry-production-technical-guide#page=14)) | **230–300+** ([Raising Healthy Poultry, p. 97](lib:raising-healthy-poultry-cvm#page=97)); 300–350 for 3–4 years "under good management" ([Practical Poultry Raising, p. 191](lib:practical-poultry-raising-peace-corps#page=191)) | Bred for eggs; don't count on her *(rule of thumb)* |
| **[Indian Runner](wiki:Indian_Runner_duck)** | **Eggs** | 4½ / 4 lb ([FB 697, p. 10](lib:duck-raising-usda-farmers-bulletin-697#page=10)) | Same class as the Khaki | "Nonsitters" ([p. 11](lib:duck-raising-usda-farmers-bulletin-697#page=11)) |
| **[Pekin](wiki:American_Pekin)** | **Meat** | 9 / 8 lb ([FB 697, p. 6](lib:duck-raising-usda-farmers-bulletin-697#page=6)) | "Fair layers" | "Practically nonsitters" |
| [Rouen](wiki:Rouen_duck), [Cayuga](wiki:Cayuga_duck), [Aylesbury](wiki:Aylesbury_duck), Buff, Swedish | Meat; Buff for both | Rouen as big as a Pekin; the others about 1 lb lighter ([FB 697, pp. 8–9](lib:duck-raising-usda-farmers-bulletin-697#page=9)) | Cayuga fair; Buff "a good producer" | — |
| **Muscovy** | **Meat and mothering** | 10 / 7 lb ([FB 697, p. 7](lib:duck-raising-usda-farmers-bulletin-697#page=7)) | Only **30–40** on free range ([FAO, p. 14](lib:small-scale-poultry-production-technical-guide#page=14)) to 60–90 ([Practical Poultry Raising, p. 191](lib:practical-poultry-raising-peace-corps#page=191)) | **"Very good setters"** ([Raising Healthy Poultry, p. 110](lib:raising-healthy-poultry-cvm#page=110)) |

![Three old photographs of drakes: a white Pekin, heavy and deep-bodied; a Penciled Runner standing almost upright like a penguin, with a white neck and dark head; and a White Muscovy, long and low, with bare, rough skin around the eye](img:DUCKS-GUIDE/pekin-runner-muscovy.png)
*Meat, eggs and mothering: a Pekin, a Runner (note the upright stance) and a Muscovy (note the bare, rough skin on the face) ([FB 697, pp. 5, 7, 11](lib:duck-raising-usda-farmers-bulletin-697#page=5)).*

- **Egg ducks.** The Runner holds "the same relative position in the duck family that the Leghorn does among the breeds of chickens": active, a good forager,
  hardy, with a white egg "considerably larger than a chicken egg" ([FB 697, p. 11](lib:duck-raising-usda-farmers-bulletin-697#page=11)). It stands upright like
  a penguin ([p. 10](lib:duck-raising-usda-farmers-bulletin-697#page=10)) and needs only a basin deep enough to dip its beak to the nostrils; the Khaki Campbell
  was bred from Mallard, Rouen and Runner ([FAO, p. 13](lib:small-scale-poultry-production-technical-guide#page=13)). Both "produce well for three or four
  years, and the record the second year is often as high as the first" ([FB 697, p. 11](lib:duck-raising-usda-farmers-bulletin-697#page=11)).
- **Meat ducks.** A well-fed Pekin reaches about **90% of adult weight, up to 7 lb, at 7 weeks**
  ([Raising Healthy Poultry, p. 96](lib:raising-healthy-poultry-cvm#page=96)). It is timid, docile and "easily confined by low fences"
  ([FB 697, p. 6](lib:duck-raising-usda-farmers-bulletin-697#page=6)). Rouen and Cayuga mature more slowly and have **dark pinfeathers** that leave a less
  clean-looking carcass ([pp. 8–9](lib:duck-raising-usda-farmers-bulletin-697#page=8)).
- **Muscovies** are "a wide forager", need "very little care" and are quieter than Pekins, but "can readily fly over ordinary poultry fences"
  ([FB 697, p. 7](lib:duck-raising-usda-farmers-bulletin-697#page=7)). They graze grass like geese, need no swimming water
  ([FAO, p. 14](lib:small-scale-poultry-production-technical-guide#page=14)), take heat much better than common ducks, and the drake, **30–50% heavier** than
  the duck, carries a big breast ([Raising Healthy Poultry, pp. 95, 97](lib:raising-healthy-poultry-cvm#page=97)). **A Muscovy duck is the best incubator you
  can own,** and an "excellent brooding mother" for ducks, chickens and guinea fowl too
  ([FAO, p. 14](lib:small-scale-poultry-production-technical-guide#page=14)).
- **Muscovy × common duck = "mule" ducks:** good lean meat, but **sterile** ([Raising Healthy Poultry, pp. 96–97](lib:raising-healthy-poultry-cvm#page=96);
  [FAO, p. 14](lib:small-scale-poultry-production-technical-guide#page=14)).
- **Handling:** catch ducks by the wings or neck, **never by the legs**, which "break easily"
  ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19);
  [Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)). A **V-shaped trap of fence panels** to drive them into saves chasing
  ([FB 697, p. 24](lib:duck-raising-usda-farmers-bulletin-697#page=24)).

📚 **Go deeper:** [USDA FB 697, pp. 4–12](lib:duck-raising-usda-farmers-bulletin-697#page=4) — every standard breed, with photos; [*Raising Healthy Poultry*, pp. 95–99](lib:raising-healthy-poultry-cvm#page=95) — choosing a breed, Muscovies, mule ducks and growth tables; [FAO, pp. 13–14](lib:small-scale-poultry-production-technical-guide#page=13) — breeds for family flocks.

## 🐌 Why ducks suit our wet winters: slugs, snails and the garden

**Slugs are our worst garden pest.** "Slugs thrive west of the Cascades." They feed when it is **warmer than 50 °F**, "love mild winters, wet springs, moist
summers and irrigation", and many go dormant in hot, dry summers. They **lay their eggs in the fall after the rains start, typically in late September and early
October**, and "if you reduce the population before they lay eggs, you have won half the battle"
([OSU EM 9027, p. 15](lib:osu-growing-your-own-practical-guide-to-gardening-in-oregon-em-9027#page=15)).

**Ducks eat slugs.** Foraging ducks eat "insects, insect larvae, earthworms, snails ... mollusks"
([Raising Healthy Poultry, p. 111](lib:raising-healthy-poultry-cvm#page=111)), and outside they "do well on grasses and insects, and will keep a mature garden
free of snails and slugs" ([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)). They stand the wet better than chickens
too: they resist coccidiosis ([p. 191](lib:practical-poultry-raising-peace-corps#page=191)), and once fully feathered they hold their body heat "even when the
outside temperature is low" ([Raising Healthy Poultry, p. 101](lib:raising-healthy-poultry-cvm#page=101)).

**The catch:** the same ducks "will devour" a growing garden ([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)):
seedlings, lettuce and greens, and they trample soft beds. Timing is everything:

1. **September–November, the main duck season:** turn the ducks onto each bed as it is harvested. Each slug eaten before it lays is a clutch that never hatches
   (OSU, p. 15).
2. **December–February:** bare beds, paths and the orchard on mild, damp days; fence off winter greens you mean to eat *(rule of thumb)*.
3. **Two to three weeks before you plant a bed in spring**, give it a last going-over, then **shut the ducks out** *(rule of thumb)*.
4. **Spring and summer:** pasture, orchard and field edges, not the garden, while plants are small. Big, tough plants (tall corn, squash) can take short,
   watched visits later; in July–August the slugs are quiet anyway (OSU, p. 15) *(rule of thumb)*.

**Help them find slugs:** slugs shelter under flat **trap boards** laid between rows by day (OSU, p. 15); flip the boards in the morning with the ducks behind
you, and feed them the slugs you hand-pick **about two hours after sunset** *(rule of thumb, using OSU's methods)*. Earthworms and snails can carry poultry
tapeworms ([FAO, p. 24](lib:small-scale-poultry-production-technical-guide#page=24)), so keep moving the flock to fresh ground. **No slug bait, rat poison or
insect spray where ducks forage** *(rule of thumb)*: some sprays are "highly toxic to ducks", and warfarin rat bait makes them bleed to death
([Raising Healthy Poultry, p. 118](lib:raising-healthy-poultry-cvm#page=118)).

![A year chart with three rows: slugs, the garden and the ducks. Slugs feed on mild nights all winter, peak in the wet spring, go dormant in the hot dry summer and lay eggs in late September to early October. Ducks work the harvested and bare beds from September to February, are shut out from planting time until the plants are big, and have little to do in summer.](img:DUCKS-GUIDE/slug-season-and-ducks.svg)
*When ducks help the garden and when they eat it: in on harvested and bare beds around the slugs' fall egg-laying, out while plants are small (a diagram drawn for this guide).*

📚 **Go deeper:** [OSU EM 9027, p. 15](lib:osu-growing-your-own-practical-guide-to-gardening-in-oregon-em-9027#page=15) — slug habits, trap boards, barriers and hand-picking; [Seed Bank guide](guide:SEED-BANK-GUIDE) — what to plant and when.

## 🏠 Housing, water and keeping bedding dry

Ducks need shelter from predators and weather, and "a clean dry sheltered area where they can retreat, rest, clean and preen their feathers" to keep their
plumage waterproof ([Raising Healthy Poultry, p. 98](lib:raising-healthy-poultry-cvm#page=98)). A simple shed, cheap fencing, a wooden trough and a waterer are
enough for a small flock ([p. 99](lib:raising-healthy-poultry-cvm#page=99)). Ducks don't roost; they sleep on the floor *(rule of thumb)* and lay "at ground
level" ([p. 107](lib:raising-healthy-poultry-cvm#page=107)), so **the floor must stay dry** — and ducks "drink and excrete more water than chickens", with
droppings **over 90% water** ([p. 103](lib:raising-healthy-poultry-cvm#page=103)). In our rainy season plan for it:

1. **Site:** high, well-drained ground so rain runs away; **sandy soil** is best ([Raising Healthy Poultry, p. 99](lib:raising-healthy-poultry-cvm#page=99)), on
   a gentle south slope ([FB 697, p. 14](lib:duck-raising-usda-farmers-bulletin-697#page=14)).
2. **Raise the floor:** dirt **4–6 inches above the ground**, or boards raised **6–8 inches** under **4 inches of sand or dry earth**
   ([FB 697, p. 16](lib:duck-raising-usda-farmers-bulletin-697#page=16)).
3. **Bed it** with straw or shavings and **add fresh bedding on top whenever it gets wet**; clean it out when soaked
   ([Raising Healthy Poultry, p. 103](lib:raising-healthy-poultry-cvm#page=103)). Litter may build up for warmth in cold weather, but then ventilation is
   "absolutely necessary" ([FB 697, p. 16](lib:duck-raising-usda-farmers-bulletin-697#page=16)). **Never moldy straw** (aspergillosis, under health).
4. **Water outside, as far from the house as possible**, once ducklings are about 3 weeks old; indoors only when it freezes, and then on a **wire-mesh screen**
   so spills drain away from the litter ([Raising Healthy Poultry, pp. 103–104](lib:raising-healthy-poultry-cvm#page=104)). A screen over a gravel-filled pit
   does the job of the book's cement drain *(rule of thumb)*.
5. **No feed or water in the house at night** for ducks over 3 weeks: it keeps litter dry and "is not harmful", if they get water **8–12 hours a day**
   ([Raising Healthy Poultry, p. 115](lib:raising-healthy-poultry-cvm#page=115)).
6. **Air:** "the comfort and health of the ducks depend on an abundant supply of pure, dry air"; open up wide on mild days to dry the bedding
   ([FB 697, p. 16](lib:duck-raising-usda-farmers-bulletin-697#page=16)). Window openings and a ridge vent are enough for a small shed
   ([Raising Healthy Poultry, p. 105](lib:raising-healthy-poultry-cvm#page=105)).
7. **Yards:** gently sloping; scrape off the fouled top few inches and replace with clean soil or sand ([p. 103](lib:raising-healthy-poultry-cvm#page=103)).
   Better, **two yards used turn about**, the resting one sown to oats, wheat or rye ([FB 697, p. 15](lib:duck-raising-usda-farmers-bulletin-697#page=15)).

| Space and size | Amount | Source |
|---|---|---|
| Floor inside, laying ducks | **3 sq ft** each, and at least twice that outdoors | [Raising Healthy Poultry, p. 102](lib:raising-healthy-poultry-cvm#page=102) |
| Floor inside, breeding ducks (farm practice) | **4–6 sq ft** each | [FB 697, p. 15](lib:duck-raising-usda-farmers-bulletin-697#page=15) |
| Ducklings | about **⅓ sq ft** at 1 week, **1 sq ft** at 3 weeks, **2½ sq ft** at 7 weeks | [Raising Healthy Poultry, p. 102](lib:raising-healthy-poultry-cvm#page=102) |
| Nests, on the floor along the wall | **1 per 3–4 ducks**; stalls **12 in wide, 18 in deep**, boards 12 in high | [p. 107](lib:raising-healthy-poultry-cvm#page=107); [FB 697, p. 16](lib:duck-raising-usda-farmers-bulletin-697#page=16) |
| Fence that holds them in | **2 ft** for grown ducks, **18 in** for ducklings; not Muscovies, which fly | [FB 697, p. 16](lib:duck-raising-usda-farmers-bulletin-697#page=16); [Raising Healthy Poultry, p. 99](lib:raising-healthy-poultry-cvm#page=99) |

That fence keeps nothing out (see "Predators"). **Feet:** duck skin is softer than a chicken's; rough slats, wire and stony yards injure feet and hocks, while
litter floors and sandy yards are kindest ([Raising Healthy Poultry, pp. 102–103](lib:raising-healthy-poultry-cvm#page=102)).

![Side view of a small duck shed on a rise: a sloping shed roof with vents under the eaves, an earth floor raised 4 to 6 inches above the ground and bedded with dry straw, floor-level nest stalls 12 inches wide and 18 inches deep along the back wall, and the waterer outside, downhill, on a wire screen over a gravel pit, inside a 2-foot fence](img:DUCKS-GUIDE/dry-duck-house.svg)
*Keep the water out and the floor up: raised, bedded floor, nests on the floor, vents high, water outside on a screen (a diagram drawn for this guide).*

**Drinking water** must be deep enough for a duck to dip its whole bill and **wash grit out of its nostrils**, and **near the feed** so they eat and drink
together ([FB 697, p. 23](lib:duck-raising-usda-farmers-bulletin-697#page=23)); the opening at least **4 cm (1½ in)** wide
([Raising Healthy Poultry, p. 104](lib:raising-healthy-poultry-cvm#page=104)). **Swimming water** is not needed, but helps in hot weather
([p. 115](lib:raising-healthy-poultry-cvm#page=115)), and breeders with water to swim in lay more fertile eggs
([FB 697, p. 14](lib:duck-raising-usda-farmers-bulletin-697#page=14)). A pond is also a risk: **cholera** goes with "standing water in duck pens", **botulism**
with stagnant ponds and rotting carcasses ([Raising Healthy Poultry, pp. 117–118](lib:raising-healthy-poultry-cvm#page=117)). A tub dumped on the garden and
refilled every day or two is safer than a still pond, and keep ducks out of the spring or creek the household drinks from *(rule of thumb)*.

📚 **Go deeper:** [*Raising Healthy Poultry*, pp. 98–105](lib:raising-healthy-poultry-cvm#page=98) — housing, floors, litter, feeders, waterers and space; [USDA FB 697, pp. 14–16](lib:duck-raising-usda-farmers-bulletin-697#page=14) — sites, houses, yards and nests; [Chickens guide](guide:CHICKENS-GUIDE) — hardware cloth and composting litter.

## 🌾 Feeding with no feed store

**What forage can do.** **Fewer than about 15 ducks** with room to forage can live on that plus "unused garden vegetables, table scraps (bones must be ground),
and other food leftovers", but "will likely grow very slowly and produce a small number of eggs"; above **10–15 ducks**, feed at least some grain
([Raising Healthy Poultry, p. 111](lib:raising-healthy-poultry-cvm#page=111)). "A few handfuls of grain scattered or placed in a trough in the evening will keep
them nearer the house" ([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)) and brings them in to be shut up.

### Home-grown rations
The old duck farms fed a **wet mash** of ground grain and mill feeds, a little meat or fish meal, and plenty of chopped greens
([FB 697, p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21)). Use their mixes as patterns for what you can grow or mill:

| Ration (FB 697) | Grain part | Protein part | Greens and minerals |
|---|---|---|---|
| Ducklings, first 5 days ([p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21)) | 35% yellow cornmeal, 31% bran, 10% flour or middlings, 5% rolled oats | 5% dried milk, 5% meat scrap | 5% alfalfa-leaf meal, 3% sand, 1% salt |
| Breeders resting, summer ([p. 22](lib:duck-raising-usda-farmers-bulletin-697#page=22)) | 40% bran, 30% cornmeal, 25% middlings or flour | 5% meat scrap or fish meal | ⅓ of the bulk in green feed |
| Breeders laying, from mid-October ([pp. 22–23](lib:duck-raising-usda-farmers-bulletin-697#page=23)) | 50% cornmeal, 25% bran, 13% middlings or flour | 12% meat scrap or fish meal | with green feed |
| Egg breeds, all year ([p. 23](lib:duck-raising-usda-farmers-bulletin-697#page=23)) | 40% cornmeal, 25% flour or middlings, 15% bran, 10% ground oats | 10–15% meat or fish meal | 10% alfalfa-leaf meal if no greens |

- **Bran and middlings** are what's left when you mill your own flour ([Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE)). **Protein** after the collapse means
  slugs, worms, **cooked** fish scraps ("trash fish (cooked and not putrefied)"), meat scraps, skim milk and whey
  ([Raising Healthy Poultry, p. 111](lib:raising-healthy-poultry-cvm#page=111)).
- **Greens**, chopped about **½ inch** long: **rye** first in spring, then alfalfa and oats, then fodder corn; **rape sown in August** lasts until hard frost.
  No greens? **Cooked vegetables as one-fifth of the mash** ([FB 697, p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21)).
- **Calcium:** about **3%** of a laying duck's diet ([Raising Healthy Poultry, p. 114](lib:raising-healthy-poultry-cvm#page=114)); keep **oyster shell and sand
  always in front of laying ducks** ([FB 697, p. 23](lib:duck-raising-usda-farmers-bulletin-697#page=23)). Baked, crushed eggshell and grit are in the Chickens
  guide ("Calcium, grit and salt").
- **Chicken feed will do:** "chicken rations will serve as a satisfactory substitute"
  ([Raising Healthy Poultry, p. 111](lib:raising-healthy-poultry-cvm#page=111)); for ducklings, read the niacin section.
- **Feed it wet.** Dry mash turns to paste in a duck's bill and sends it to the water to wash, wasting feed. Mix in water just before feeding, to "a thick mush
  without making it watery", only what they clean up in a few hours ([p. 115](lib:raising-healthy-poultry-cvm#page=115)). Grown ducks get all they will eat
  **morning and evening**, with water close by, and the mash must never sour: "sour feed is likely to cause convulsions and death, especially among the young
  ducklings" ([FB 697, p. 23](lib:duck-raising-usda-farmers-bulletin-697#page=23)).
- **Ducks waste feed** with their shovel-shaped bills ([FAO, p. 13](lib:small-scale-poultry-production-technical-guide#page=13)): use a trough with an **apron**
  in front to catch what they bill out ([Raising Healthy Poultry, p. 103](lib:raising-healthy-poultry-cvm#page=103)), about **1 inch of trough per duckling**,
  and **4 inches per duck** when you ration grown birds so all eat at once ([p. 104](lib:raising-healthy-poultry-cvm#page=104)).

### Moldy grain and other poisons
- **Aflatoxin from moldy grain is the big one.** Ducks are "highly susceptible", tiny amounts kill, and "wet harvest conditions encourage the growth of this
  mold" ([Raising Healthy Poultry, p. 118](lib:raising-healthy-poultry-cvm#page=118)). Store grain at **no more than 10–12% moisture**; never feed rancid fat or
  bran or putrid fish ([p. 115](lib:raising-healthy-poultry-cvm#page=115)). After a wet harvest, dry grain hard before storing it *(rule of thumb)*.
- **Peanut meal** often carries aflatoxin and **rapeseed meal** is "very harmful to ducks" ([p. 114](lib:raising-healthy-poultry-cvm#page=114)); rape *greens*
  are the old green feed above, the pressed seed meal is not.
- **Botulism** (limp neck, death in 1–2 days) comes from stagnant ponds and carcasses; **castor beans**, many insect sprays and rat baits also poison ducks
  ([p. 118](lib:raising-healthy-poultry-cvm#page=118)). Never feed maggots from carcasses (Chickens guide).
- **Poisonous plants:** the same as for chickens (foxglove, Scotch broom and the rest; Chickens guide). **Dry season:** forage dries up about July–October, so
  store feed for summer as well as winter *(rule of thumb)*.

📚 **Go deeper:** [*Raising Healthy Poultry*, pp. 110–122](lib:raising-healthy-poultry-cvm#page=110) — duck nutrition, nutrient tables and sample rations; [USDA FB 697, pp. 21–23](lib:duck-raising-usda-farmers-bulletin-697#page=21) — mashes and green feed through the year.

## 💊 Niacin and leg trouble in ducklings

[Niacin](wiki:Nicotinic_acid) is a B vitamin. In poultry, too little shows as a **slipped tendon (perosis)**, **swollen hocks** and **poor feathering**, and its feed
sources are **wheat middlings, corn gluten meal and alfalfa** ([Raising Healthy Poultry, p. 44](lib:raising-healthy-poultry-cvm#page=44)). The book's duck
starter has about **44–50 mg of niacin per kg** of feed for the first two weeks ([p. 119](lib:raising-healthy-poultry-cvm#page=119)).

- **The library does not say outright that ducklings need more niacin than chicks.** Duck keepers widely say so and add brewer's yeast or niacin to chick feed
  for ducklings *(rule of thumb)*. The book itself accepts chicken rations for ducks ([p. 111](lib:raising-healthy-poultry-cvm#page=111)), so treat it as cheap
  insurance, not an emergency.
- **Without a store:** B vitamins come in **yeasts**, fermented feeds and fresh cut greens ([p. 44](lib:raising-healthy-poultry-cvm#page=44)), and **brewer's
  yeast** is on the book's list of duck feeds ([p. 111](lib:raising-healthy-poultry-cvm#page=111)). Give ducklings greens, middlings, skim milk or whey,
  hard-boiled egg and any spent brewing yeast from the first days, and get them onto grass and bugs early *(rule of thumb)*.
- **A duckling going lame or bow-legged:** check the floor first (rough wire and stony ground injure duck legs,
  [p. 102](lib:raising-healthy-poultry-cvm#page=102)), then add yeast, greens and middlings *(rule of thumb)*. The library gives no niacin dose, so neither does
  this guide.

## 🥚 Duck eggs: when and how many

- **Ducks lay early:** mostly **before 7 a.m.** ([Raising Healthy Poultry, p. 108](lib:raising-healthy-poultry-cvm#page=108)), within **3 hours after sunrise**
  ([FAO, p. 13](lib:small-scale-poultry-production-technical-guide#page=13)). Keep them in until about **9:30 a.m.**, or they may lay in the pond and the eggs
  are lost ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)). Collect about 7 and again about 10, and **dig down in the nest bedding**:
  ducks bury their eggs ([Raising Healthy Poultry, p. 108](lib:raising-healthy-poultry-cvm#page=108)).
- **Season:** with no lamp, laying follows day length ([p. 105](lib:raising-healthy-poultry-cvm#page=105)): most eggs from late winter to early summer, few in
  late fall and early winter *(rule of thumb, as for chickens)*. Lighting to **14 hours** gives **7–12 months** of laying (p. 105) but burns lamp fuel every
  day; most households will do better **storing spring eggs**.
- **How many:** egg breeds lay **230–300+** fully fed ([p. 97](lib:raising-healthy-poultry-cvm#page=97)); a Khaki Campbell lays about **90 eggs per 100
  duck-days**, about **73 g** each ([FAO, p. 13](lib:small-scale-poultry-production-technical-guide#page=13)). On forage and scraps alone, "a small number of
  eggs" ([Raising Healthy Poultry, p. 111](lib:raising-healthy-poultry-cvm#page=111)).
- **By age:** egg breeds lay well **3–4 years**, the second year often as well as the first
  ([FB 697, p. 11](lib:duck-raising-usda-farmers-bulletin-697#page=11)) — longer than hens.
- **The molt:** after **7–12 months** of laying, numbers fall and the duck molts; it takes **8–12 weeks** to start again
  ([Raising Healthy Poultry, p. 108](lib:raising-healthy-poultry-cvm#page=108)). Let it come on its own ("Old advice").
- **Size and taste:** about **one-fourth larger** than hens' eggs ([FB 697, p. 25](lib:duck-raising-usda-farmers-bulletin-697#page=25)), with a stronger taste
  ([Practical Poultry Raising, p. 191](lib:practical-poultry-raising-peace-corps#page=191)); in baking, 4 duck eggs ≈ 5 hens' eggs *(arithmetic)*.
- **They spoil faster:** "in about a week" ([Practical Poultry Raising, p. 191](lib:practical-poultry-raising-peace-corps#page=191)), faster in hot weather
  ([FB 697, p. 25](lib:duck-raising-usda-farmers-bulletin-697#page=25)). Yard or mud eggs: don't set them; eat them soon, **thoroughly cooked**
  ([Raising Healthy Poultry, p. 108](lib:raising-healthy-poultry-cvm#page=108)). The water-glass crocks for the spring surplus (Chickens guide;
  [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE)) were written for hens' eggs: use only clean, fresh, uncracked duck eggs and check them often
  *(rule of thumb)*.

## 🐣 Hatching under hens, Muscovies or ducks

**Who will sit?** Pekin and Runner ducks "rarely sit", so their eggs usually go under hens
([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)). **Muscovy ducks are very good setters, "capable of hatching 12–15 duck eggs"**; any
broody duck needs a clean, dry nest box with feed and water close by ([Raising Healthy Poultry, p. 110](lib:raising-healthy-poultry-cvm#page=110)). Setting a
broody chicken hen is in the Chickens guide ("Broody hens and hatching without power").

**Hatching eggs:**
- **Clean nest eggs only.** Most hatching trouble comes from eggs "soiled with duck manure under wet conditions", which lets germs in and makes sick ducklings
  ([Raising Healthy Poultry, pp. 107–108](lib:raising-healthy-poultry-cvm#page=107)). Don't set cracked, misshapen, very big or very small eggs
  ([p. 109](lib:raising-healthy-poultry-cvm#page=109)).
- **Fresh:** set within **1–3 days** if you can; hatching drops about 3% after a week's storage and 10% after two. Store them **small end down** at about
  **55 °F**, in a cellar ([pp. 109–110](lib:raising-healthy-poultry-cvm#page=110)).
- **Timing:** **28 days**; **33–35 days** for Muscovies ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)). Don't set eggs with different
  hatching times under one bird ([FB 767, p. 18](lib:goose-raising-usda-farmers-bulletin-767#page=18)).
- **Under a chicken hen:** a big hen covers about **7–10** duck eggs *(rule of thumb: chicken hens cover 7–10 of the similar-sized turkey eggs,
  [FB 1409, p. 33](lib:turkey-raising-usda-farmers-bulletin-1409#page=33))*. Slip them under her **at dusk**, **1–4 days** after she starts sitting
  ([FAO, p. 40](lib:small-scale-poultry-production-technical-guide#page=40)).

**Through the sitting:**
1. **A hen sits a week longer than for her own eggs**, so she "must be well cared for" ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)):
   feed and water by the nest, and treat her for lice before she starts ([FB 767, p. 18](lib:goose-raising-usda-farmers-bulletin-767#page=18);
   [FAO, p. 40](lib:small-scale-poultry-production-technical-guide#page=40)).
2. **Candle** about **day 5–7** and again about **day 24**. A living embryo shows a dark spot with veins; a dead one leaves a **blood ring**, and dead duck eggs
   **rot fast** and smell ([FB 697, p. 20](lib:duck-raising-usda-farmers-bulletin-697#page=20);
   [Raising Healthy Poultry, p. 109](lib:raising-healthy-poultry-cvm#page=109)). Hard-boil the clear ones for the ducklings
   ([FB 697, p. 20](lib:duck-raising-usda-farmers-bulletin-697#page=20)). At day 25 the air cell fills about **one-third** of the egg
   ([Raising Healthy Poultry, p. 110](lib:raising-healthy-poultry-cvm#page=110)).
3. **Moisture:** duck eggs "need more moisture at hatching time than do chicken eggs": **sprinkle them with warm water just before they pip**
   ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)). A nest on slightly damp earth helps
   ([FAO, p. 40](lib:small-scale-poultry-production-technical-guide#page=40)).
4. **The hatch is slow:** **24–48 hours** from pipping to out. When the first ones pip, let the hen off to eat and drink, then **keep her on the nest until the
   hatch is over** ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)). First feed comes **24–36 hours** after hatching
   ([p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21)).

![A timeline of 28 days for duck eggs under a hen, compared with 21 days for her own eggs: set the eggs on day 0, candle on days 5 to 7 and again about day 24, sprinkle with warm water just before pipping, let her off to eat when the first egg pips, keep her on the nest through the 24 to 48 hour hatch on days 26 to 28; Muscovy eggs run to day 35](img:DUCKS-GUIDE/duck-eggs-under-a-hen.svg)
*Duck eggs under a hen: a week longer than her own, two candlings, water before pipping, and a slow hatch (a diagram drawn for this guide).*

**Without a sitting bird:** the **parched-rice method** was developed for duck eggs in China (bundles of **40 duck eggs** in warm rice) and hatches up to
**80%** with practice ([FAO, p. 41](lib:small-scale-poultry-production-technical-guide#page=41)); the steps are in the Chickens guide, "Incubating without
electricity". With steady power: **99.5 °F**, about **55% humidity**, eggs turned at least **4 times a day**
([Raising Healthy Poultry, p. 109](lib:raising-healthy-poultry-cvm#page=109)).

📚 **Go deeper:** [USDA FB 697, pp. 19–20](lib:duck-raising-usda-farmers-bulletin-697#page=19) — hatching under hens, candling and moisture; [*Raising Healthy Poultry*, pp. 107–110](lib:raising-healthy-poultry-cvm#page=107) — nests, egg care and natural incubation.

## 🐥 Raising ducklings with no power

**With a mother** there is nothing to heat. A Muscovy broods and leads her own ducklings; shut her and the brood in a dry, predator-proof coop at night
*(rule of thumb)*. With a **chicken hen**, "confine the hens and allow the ducklings free range, as the hens are apt to wander too far with their broods"
([FB 697, p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21)), and keep water near her
([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)).

**Warm and dry:** "During their first four weeks, ducklings should be kept warm and dry"
([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)). Ducks are **easier to brood than chickens**
([FB 697, p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21)) and need heat for a shorter time:

| Age | [Raising Healthy Poultry, p. 101](lib:raising-healthy-poultry-cvm#page=101) | [FB 697, p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21) |
|---|---|---|
| First week | **86 °F** at hatching, 81 °F at 7 days | **90–95 °F** |
| Second week | 73 °F at 14 days | **80–85 °F** |
| Third week | 66 °F at 21 days | **about 75 °F** |
| Fourth week on | 59 °F at 28 days, then 55 °F | 65–70 °F until about 6 weeks |

The books differ by up to 10 °F, so watch the ducklings as you would chicks: crowding to the heat = too cold; spread far off and panting = too hot. With no hen,
the hot-water-jug box and the fire and carbon-monoxide warnings in the Chickens guide ("Raising chicks with no heat lamp") apply to ducklings too. **Hatch in
warm weather** so heat is needed only briefly: in warm spells ducklings go outdoors part of the day from about **2 weeks**
([Raising Healthy Poultry, p. 101](lib:raising-healthy-poultry-cvm#page=101); [FB 697, p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21)), and once
**the feathers on their backs are partly grown** (about 6 weeks) they need only shade by day
([FB 697, p. 18](lib:duck-raising-usda-farmers-bulletin-697#page=18)) — still shut in at night.

- **Water:** on a **wire screen** so the bedding stays dry ([FB 697, p. 23](lib:duck-raising-usda-farmers-bulletin-697#page=23)), in a waterer they can dip
  their bills in but **not climb into**, such as a jar waterer or a shallow pan filled with pebbles *(rule of thumb)*. If they don't drink within a few hours,
  **dip their bills** in it ([Raising Healthy Poultry, p. 101](lib:raising-healthy-poultry-cvm#page=101)).
- **No swimming** until **6–7 weeks** in mild weather, **about 8 weeks** in cold ([FB 697, p. 15](lib:duck-raising-usda-farmers-bulletin-697#page=15)).
  Ducklings raised by a hen or in a box have no mother duck to keep their down dry, and wet ducklings chill fast *(rule of thumb)*.
- **Feed:** moist mash (the first-5-day ration above) **4 times a day** to 2–3 weeks old, then 3 times, with **sand or grit always**
  ([FB 697, pp. 21–22](lib:duck-raising-usda-farmers-bulletin-697#page=22)). Starter pellets are ideal, "although moistened mash, whole grain and/or fresh
  greens will do" ([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)); add hard-boiled egg, greens, milk, worms and slugs
  ("Niacin").

📚 **Go deeper:** [*Raising Healthy Poultry*, pp. 100–101](lib:raising-healthy-poultry-cvm#page=100) — brooding ducklings and temperatures; [USDA FB 697, pp. 21–23](lib:duck-raising-usda-farmers-bulletin-697#page=21) — brooding and feeding young ducks.

## 🦉 Predators: lock them in every night

Ducks are slow on land and sleep on the ground, so a duck left out at night is easy prey *(rule of thumb)*. Every predator in the Chickens guide's "Predators of
the Illinois Valley" takes ducks; that section has the who-did-it table, hardware cloth and the electric fence. For ducks:

- **Owls and hawks:** the great horned owl hunts at night, even in forest, and eats "chickens, ducks and other poultry"; hawks carry off small birds by day. All
  birds of prey are federally protected — **don't shoot them** ([Kentucky ID-245, p. 4](lib:predator-management-for-small-scale-poultry#page=4)). Raise
  ducklings in a covered pen.
- **Mink and raccoons** hunt along creeks and ponds *(rule of thumb)*; the weasel family, mink included, "often kill just for sport"
  ([Kentucky ID-245, p. 3](lib:predator-management-for-small-scale-poultry#page=3)). **A pond is not a safe bed:** ducks on water at night are still within
  reach *(rule of thumb)*.
- **Shut them in every night.** Ducks are "easy to herd" ([FAO, p. 13](lib:small-scale-poultry-production-technical-guide#page=13)): put the evening grain
  inside and walk them in slowly behind a long stick *(rule of thumb)*. A 2-ft fence holds ducks in, not predators out.
- **Bears:** feed in a bear-resistant container or locked building, and an electric fence powered day and night
  ([ODFW, pp. 1–2](lib:raising-chickens-in-bear-country-odfw#page=2)). **Cougars:** "Move them to sheds or barns at night"; Oregon law lets a landowner kill one
  damaging livestock ([ODFW cougar, p. 2](lib:oregon-is-cougar-country-odfw#page=2)). See also the [Dogs guide](guide:DOGS-GUIDE).

## 🩺 Duck health with no vet

Ducks are "less subject to disease than chickens" ([FB 697, p. 13](lib:duck-raising-usda-farmers-bulletin-697#page=13)) and shrug off most chicken diseases, but
they **carry Newcastle disease and cholera** to chickens and fall easily to their own diseases
([FAO, p. 51](lib:small-scale-poultry-production-technical-guide#page=51);
[Practical Poultry Raising, p. 191](lib:practical-poultry-raising-peace-corps#page=191)). The books' duck vaccines won't exist after the collapse, so
**prevention is everything**:

- **Keep wild ducks and geese away** from your flock, its water and its feed. Bird flu reaches poultry "through contact with wild birds (or their excrement),
  particularly waterfowl" ([Raising Healthy Poultry, p. 78](lib:raising-healthy-poultry-cvm#page=78)), which may show no signs; hunters should dress wild birds
  away from poultry and change clothes and boots first ([ODFW game bird regulations, p. 40](lib:odfw-2026-2027-game-bird-hunting-regulations#page=40)).
- **Keep age groups apart and don't bring in outside birds** ([Raising Healthy Poultry, p. 116](lib:raising-healthy-poultry-cvm#page=116)); if you must, keep
  newcomers apart a month, and **house ducks and chickens separately** *(rule of thumb)*.
- **Dry litter, clean nests, no moldy straw or feed, no standing water or stagnant pond, no carcasses lying about.**

| Signs | Likely cause | What you can do |
|---|---|---|
| Ducklings **1–28 days old** jerk their legs and die **within an hour**, heads **arched backward**; up to 90% die | **Duck virus hepatitis** ([Raising Healthy Poultry, p. 116](lib:raising-healthy-poultry-cvm#page=116)) | No cure. Keep age groups apart; burn or bury the dead |
| Grown ducks sluggish, ruffled, **green-yellow diarrhea**, sometimes bloody; **blood from the nostrils** at death | **[Duck plague](wiki:Duck_plague)**, up to 100% deaths ([pp. 116–117](lib:raising-healthy-poultry-cvm#page=117); [FAO, p. 51](lib:small-scale-poultry-production-technical-guide#page=51)) | No cure. Destroy and bury the sick group; keep wild waterfowl away |
| Eye discharge, **head shaking, twisted neck**, ducks on their backs paddling | **Riemerella** ("new duck disease") ([p. 117](lib:raising-healthy-poultry-cvm#page=117)) | Cull; clean up |
| Off feed, mucus from the mouth, diarrhea, sudden deaths | **Cholera**, with poor sanitation and standing water ([p. 117](lib:raising-healthy-poultry-cvm#page=117)) | Drain and clean the pens. The book lists sulfa drugs and chlortetracycline in feed: only if stocked, by the label |
| Weak ducklings, infected navels, poor hatches | **E. coli** from dirty eggs and nests ([p. 117](lib:raising-healthy-poultry-cvm#page=117)) | Clean, dry nests; set only clean eggs |
| Gasping, listless, **no rattle** | **[Aspergillosis](wiki:Aspergillosis)** from moldy straw or damp feed ([pp. 117–118](lib:raising-healthy-poultry-cvm#page=118)) | Burn the moldy bedding; keep feed dry |
| **Limp neck**, legs and wings; dead in 24–48 hours | **Botulism** from stagnant water or carcasses ([p. 118](lib:raising-healthy-poultry-cvm#page=118)) | Move them off that water; remove carcasses; fence or drain the pond |
| Ducklings dying after new grain | **Aflatoxin** (moldy feed) ([p. 118](lib:raising-healthy-poultry-cvm#page=118)) | Throw the feed out |
| Lame, swollen hocks, legs turned out | Rough floor ([p. 102](lib:raising-healthy-poultry-cvm#page=102)), niacin ([p. 44](lib:raising-healthy-poultry-cvm#page=44)), a leg broken by lifting | Niacin section; never lift by the legs |
| Feathers pulled out, bleeding | **Feather pulling** ([p. 105](lib:raising-healthy-poultry-cvm#page=105)) | More room and forage; take the victim out at first blood *(rule of thumb)* |

**Bird flu**, lice, mites, egg binding and prolapse are handled as for hens (Chickens guide, "Health with no vet"); treat any sudden die-off as possible bird
flu: gloves, don't eat them, **burn or bury deep**. Beyond the feed levels on p. 117, the library gives no duck medicine doses; see the
[Medical guide](guide:Medical-READ-ME-FIRST). A bird sick for days is best killed quickly, and not eaten if the cause is unknown.

📚 **Go deeper:** [*Raising Healthy Poultry*, pp. 116–118](lib:raising-healthy-poultry-cvm#page=116) — duck diseases and toxins; [FAO, p. 51](lib:small-scale-poultry-production-technical-guide#page=51) — what ducks catch and carry.

## 🔥 Heat, smoke and fire season

- Ducks shed heat through their **bills and feet** in water cooler than their 107 °F body; **50–70 °F** water is ideal
  ([Raising Healthy Poultry, p. 115](lib:raising-healthy-poultry-cvm#page=115)). In July–August give **shade**
  ([FB 697, p. 15](lib:duck-raising-usda-farmers-bulletin-697#page=15)) and a shallow tub of cool water, refilled daily. **Muscovies** handle heat best
  ([Raising Healthy Poultry, p. 95](lib:raising-healthy-poultry-cvm#page=95)).
- **Smoke:** watch for coughing, open-mouth breathing and watery eyes; keep water clean and fresh and put off stressful jobs
  ([PNW 783, p. 10](lib:wildfires-smoke-and-livestock-pnw783#page=10)). Keep crates for the whole flock to walk them into at dusk if you must leave
  *(rule of thumb)*; see the [Wildfire guide](guide:WILDFIRE-GUIDE).

## 🔪 Butchering and plucking

**When:** young ducks are best at **8–11 weeks**, once the long wing feathers are full length; held longer, "the market quality of their flesh depreciates,
their weight decreases", and it takes **several weeks** to bring them back ([FB 697, pp. 5, 24](lib:duck-raising-usda-farmers-bulletin-697#page=24)) while the
next feathers grow in, full of pinfeathers *(rule of thumb)*. Well grown, they weigh about **5½ lb at 11 weeks**
([p. 24](lib:duck-raising-usda-farmers-bulletin-697#page=24)). A **Muscovy** drake reaches about **9½ lb at 12 weeks** on full feed
([Raising Healthy Poultry, p. 99](lib:raising-healthy-poultry-cvm#page=99)) *(arithmetic, from 4,300 g)*. Old layers and spare drakes are stew.

**Before and killing:** no feed for 8–12 hours, water available, a clean area for gutting (Chickens guide, "Humane slaughter and butchering"). Hang the duck by
its feet or head-down in a cone and cut the **jugular vein and carotid artery on one side of the neck, next to the jaw**
([Raising Healthy Poultry, p. 116](lib:raising-healthy-poultry-cvm#page=116)); FB 697 first stuns it with a hard blow on the head
([p. 24](lib:duck-raising-usda-farmers-bulletin-697#page=24)).

### Plucking: dry, scalded or waxed
Duck feathers shed water, and ducks are "difficult to pluck" ([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)). The
books use three ways:

| Method | How | Good and bad |
|---|---|---|
| **Dry picking** (best for down) | Start **right after bleeding** ([UMN EB 385, p. 2](lib:home-processing-of-poultry#page=2)). Pull feathers **downward, the way they grow**; pulling up tears the skin. On the breast, pick close to the skin and **roll** the feathers outward, **row after row** ([Slaughter and Preservation of Meat, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84)) | "Dry picking works best with ducks and geese"; the down comes off **clean and dry**; slow |
| **Scalding** | **135–145 °F for 2–3 minutes** ([Raising Healthy Poultry, p. 116](lib:raising-healthy-poultry-cvm#page=116)), or **160–180 °F for 30–60 seconds** with a little detergent to wet the feathers ([UMN EB 385, p. 2](lib:home-processing-of-poultry#page=2)). The goose bulletin dips **just under boiling for 2–3 minutes**, then wraps the bird tightly in burlap **5 minutes** to steam ([FB 767, p. 28](lib:goose-raising-usda-farmers-bulletin-767#page=28)) | Faster. Water too hot **discolors the flesh** ([FB 697, p. 24](lib:duck-raising-usda-farmers-bulletin-697#page=24)) and tears skin; wet feathers must be washed and dried |
| **Wax dip** (after rough plucking) | Below | Takes the down and pinfeathers fingers miss; the wax is used again |

Scrape long pinfeathers out with a dull knife and **rub the down off with a wet hand**, or shave it with a very sharp knife
([FB 697, p. 24](lib:duck-raising-usda-farmers-bulletin-697#page=24)); singe the last hairs (Chickens guide).

### Waxing with beeswax
The farms dipped ducks in melted wax (paraffin), let it set and peeled it off, "bringing with it hard to remove pinfeathers"
([Raising Healthy Poultry, p. 116](lib:raising-healthy-poultry-cvm#page=116)). **Beeswax** does the same job. It is precious, so dip only after dry-plucking and
**save every scrap to melt down again** ([Practical Poultry Raising, p. 194](lib:practical-poultry-raising-peace-corps#page=194)). Rendering and storing beeswax
are in the [Bees guide](guide:BEES-GUIDE) ("Beeswax: rendering and uses").

1. **The pot:** big enough to dunk the whole bird; **enamel or stainless** (aluminum, copper, brass, zinc, tin and iron stain the wax); **soft rainwater** (hard
   water turns wax soapy). Put the beeswax in the water and heat it; it melts and floats on top
   ([FAO Forest, p. 111](lib:bees-and-their-role-in-forest-livelihoods#page=111)).
2. **Heat:** beeswax melts at **62–64 °C (144–147 °F)**, darkens above **85 °C (185 °F)**, and **boiling ruins it**. "Beeswax must never be heated with a direct
   flame: always heat it in a container of water" (same page). Keep the water just hot enough that all the wax stays liquid.
3. **Fire:** if wax catches, take it off the heat and smother it with a metal lid or damp cloth; **never throw water on burning wax**
   ([Practical Action, p. 3](lib:practical-action-candlemaking-technical-brief#page=3)). Work outdoors, never on a red-flag day *(rule of thumb)*.
4. **Dip:** pluck the big feathers, **chill the bird**, then dip it through the wax **5–10 seconds**
   ([Slaughter and Preservation of Meat, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84)), holding it by the feet and head as the goose bulletin does
   for scalding ([FB 767, p. 28](lib:goose-raising-usda-farmers-bulletin-767#page=28)). A second dip builds a thicker coat *(rule of thumb)*.
5. **Set:** plunge it in **cold water** to harden the wax ([Raising Healthy Poultry, p. 116](lib:raising-healthy-poultry-cvm#page=116)), or hang it **2
   minutes** ([Slaughter and Preservation of Meat, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84)).
6. **Peel** the wax off in sheets; the down and pinfeathers come with it. Wash the bird in cool water to finish chilling it (same page).
7. **Reclaim the wax:** melt the peelings in water, strain through cotton cloth stretched over a can with both ends cut out, and let it **cool slowly**; the
   clean wax sets in a cake on top and you **scrape the dirt off its underside** ([FAO Forest, p. 111](lib:bees-and-their-role-in-forest-livelihoods#page=111)).
   Keep this wax for plucking, not candles or salves *(rule of thumb)*.

![Four panels: 1, pull the feathers down the way they grow, right after bleeding; 2, dip the chilled bird for 5 to 10 seconds through beeswax floating on hot water in an enamel pot, kept between 147 and 185 degrees F, never on a direct flame; 3, plunge it in cold water so the wax sets; 4, peel off the wax with the down and pinfeathers, then remelt the peelings in water and strain them to use again](img:DUCKS-GUIDE/waxing-a-duck-with-beeswax.svg)
*Dry-pick, dip, set, peel, and melt the wax down again (a diagram drawn for this guide).*

**Gutting:** as for a chicken, cutting out the oil gland above the tail (Chickens guide); then chill in cold water
([FB 697, p. 25](lib:duck-raising-usda-farmers-bulletin-697#page=25)). Render **duck fat** slowly like lard ([Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE))
*(rule of thumb)*, and pressure-can the meat as for chicken ([Preserving Food guide](guide:PRESERVING-FOOD-GUIDE)).

📚 **Go deeper:** [*Slaughter and Preservation of Meat*, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84) — dry-picking and waxing ducks and geese; [UMN EB 385, p. 2](lib:home-processing-of-poultry#page=2) — tools, killing and scalding waterfowl; [USDA FB 697, pp. 24–25](lib:duck-raising-usda-farmers-bulletin-697#page=24) — killing, picking and cooling.

## 🪶 Down and feathers

Ducks give down for "bedding and warm jackets" ([Raising Healthy Poultry, p. 95](lib:raising-healthy-poultry-cvm#page=95)): "pillows, comforters and down-filled
jackets" ([p. 116](lib:raising-healthy-poultry-cvm#page=116)).

- **How much:** about **2½ ounces** of usable feathers a duck ([FB 697, p. 25](lib:duck-raising-usda-farmers-bulletin-697#page=25)), so a pound of feathers and
  down takes **6–7 ducks** *(arithmetic)*.
- **Sort as you pluck:** big wing and tail feathers apart from body feathers and down, and duck feathers apart from chicken feathers
  ([FB 767, p. 28](lib:goose-raising-usda-farmers-bulletin-767#page=28)). Dry-picked down is the cleanest
  ([UMN EB 385, p. 2](lib:home-processing-of-poultry#page=2)). Don't pluck live birds: farmers "consider it harmful to the birds"
  ([FB 767, p. 28](lib:goose-raising-usda-farmers-bulletin-767#page=28)).
- **Wash** in water with detergent or soap, or **borax and washing soda**
  ([Practical Poultry Raising, p. 194](lib:practical-poultry-raising-peace-corps#page=194)); rinse well and squeeze out in a cloth bag *(rule of thumb)*.
- **Dry thoroughly:** in **thin layers in a loft, turned several times** ([FB 697, p. 25](lib:duck-raising-usda-farmers-bulletin-697#page=25)), or in burlap
  sacks hung in a loft, or spread in a dry, airy room and stirred now and then ([FB 767, p. 28](lib:goose-raising-usda-farmers-bulletin-767#page=28)). Damp
  feathers mold and stink; our dry summer is the time to do a year's worth *(rule of thumb)*.
- **Sew** down into closely woven cloth so quill tips don't poke through, in small stitched pockets so it can't all slide to one end *(rule of thumb)*. Wet down
  loses its warmth ([Clothing & Leather guide](guide:CLOTHING-LEATHER-GUIDE)).
- **Manure:** duck litter composts like chicken litter (Chickens guide, "Manure, litter and feathers"); duck manure in fish ponds feeds the plankton the fish
  eat ([Raising Healthy Poultry, p. 100](lib:raising-healthy-poultry-cvm#page=100)), and fouled tub water is good on the garden *(rule of thumb)*.

## 👪 How many ducks for a family

| Goal | What it takes | Source |
|---|---|---|
| **About 2 eggs a day** (730 a year) | **5–6 egg-breed ducks** laying half the books' best on home feed with no lamp; 3 if fully fed | [Raising Healthy Poultry, p. 97](lib:raising-healthy-poultry-cvm#page=97) *(arithmetic; "half" is a rule of thumb)* |
| Fertile eggs | **1 drake to 6–7** egg-breed ducks; **1 to 5** with Pekins | [p. 107](lib:raising-healthy-poultry-cvm#page=107) |
| Hatching | **1–2 Muscovy ducks**, each hatching **12–15** eggs a sitting | [p. 110](lib:raising-healthy-poultry-cvm#page=110) |
| Meat | Two Muscovy sittings may give about **20 ducklings**, half drakes, eaten at 8–12 weeks | *(rule of thumb)* |
| Feed for meat ducks | **4–4½ lb of feed per lb of dressed duck**: a dozen ducks dressing 4 lb each eat about **200 lb** fully fed, less on good forage | [FB 697, p. 24](lib:duck-raising-usda-farmers-bulletin-697#page=24) *(arithmetic; 4 lb dressed is a rule of thumb)* |
| A flock that can live mostly on forage | **Under 10–15 ducks** | [Raising Healthy Poultry, p. 111](lib:raising-healthy-poultry-cvm#page=111) |
| House for 6 ducks and a drake | **21–42 sq ft** (3–6 per duck): about **5 × 5 ft to 6 × 7 ft**, plus a yard at least twice the floor | [p. 102](lib:raising-healthy-poultry-cvm#page=102); [FB 697, p. 15](lib:duck-raising-usda-farmers-bulletin-697#page=15) *(arithmetic)* |
| Down | 20 ducks give about **3 lb** of feathers and down | [FB 697, p. 25](lib:duck-raising-usda-farmers-bulletin-697#page=25) *(arithmetic)* |

A family that already keeps chickens might add **6 Khaki Campbells or Runners and a drake** for eggs and slug work, and a **Muscovy trio** (a drake and two
ducks) to hatch and raise meat *(rule of thumb)*. Grain fed to ducks is grain people don't eat: size the flock to your scraps and range.

## 🗓️ The duck year in the Illinois Valley

| Months | The ducks | Work |
|---|---|---|
| **Jan–Feb** | Laying starts as days lengthen; mud and rain | Fresh bedding on top, vents open on dry days. Eggs collected by 7–10 a.m. Ducks on bare beds on mild days, off beds you'll plant within 2–3 weeks. Drakes in with the breeders. |
| **Mar–Apr** | **Laying peak**; Muscovies go broody | **Set eggs** (28 days; Muscovy 33–35), clean nest eggs only. Ducks out of the planted garden. Fill egg crocks. |
| **May–Jun** | Ducklings growing; garden growing | Ducklings out on warm days after 2 weeks; no swimming before 6–8 weeks. Ducks to pasture and orchard. **Eat the first young ducks at 8–11 weeks.** Choose next year's breeders (FB 697 picked drakes in June, ducks in early July, [p. 18](lib:duck-raising-usda-farmers-bulletin-697#page=18)). |
| **Jul–Aug** | Heat, smoke, fire season; slugs dormant; forage dries | Shade; cool water daily; dump tubs often (botulism). Stored grain and greens. Wash and dry feathers. Crates and fire plan ready. |
| **Sep–Oct** | First rains; **slugs lay their eggs late Sept–early Oct** | **Ducks onto every harvested bed.** Butcher surplus ducks. Dry grain hard before storing. Layers may molt (8–12 weeks). |
| **Nov–Dec** | Short days, few eggs; wet; wild waterfowl about | Deep, dry litter and good air. Keep ducks off ponds wild ducks use. Ducks on bare beds on mild, damp days. Flock cut to winter size. |

The dates come from the books cited in each section; fitting them to the valley's seasons is a *rule of thumb*.

## 🧬 Keeping the flock going

- **Breed from your best:** for meat, "large, vigorous breeding ducks that have broad, deep bodies"
  ([FB 697, p. 18](lib:duck-raising-usda-farmers-bulletin-697#page=18)); for eggs, the ducks still laying well in their second and third years *(rule of thumb,
  since egg breeds lay well 3–4 years, [p. 11](lib:duck-raising-usda-farmers-bulletin-697#page=11))*; for mothers, Muscovies that sit tight.
- **Drakes a month older than the ducks** give fertile eggs sooner; too many drakes injure ducks: **1 to 5–7**
  ([Raising Healthy Poultry, p. 107](lib:raising-healthy-poultry-cvm#page=107); FB 697 used about 1 to 6–7,
  [p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)).
- **Drake or duck?** A common drake is coarser and has **a curl in his tail feathers** ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)); a
  Muscovy drake is far bigger than the duck ([p. 7](lib:duck-raising-usda-farmers-bulletin-697#page=7)). Ducks quack loudly; drakes have a hoarse, quiet voice
  *(rule of thumb)*.
- **Don't let breeders get fat:** growing breeders kept a little hungry start laying later but lay more, bigger and more fertile eggs; feel the belly for fat
  ([Raising Healthy Poultry, pp. 106, 114](lib:raising-healthy-poultry-cvm#page=106)). On forage and scraps this mostly takes care of itself *(rule of thumb)*.
- **Keep Muscovy blood separate** if you breed both kinds, since the crosses are sterile
  ([Raising Healthy Poultry, p. 96](lib:raising-healthy-poultry-cvm#page=96)): pen the Muscovy drake away from the layers in the hatching months, and eat any
  mule ducklings *(rule of thumb)*.
- **Fresh blood:** trade drakes with neighbors every few years, quarantining newcomers a month *(rule of thumb)*. **Never hatch from** yard eggs or dirty eggs
  ([Raising Healthy Poultry, pp. 107–108](lib:raising-healthy-poultry-cvm#page=108)), or from a flock that has had a die-off *(rule of thumb)*. Keep a card in
  the duck house with hatches, sittings, deaths and daily eggs.

## 🧯 If this goes wrong

| Problem | Likely cause and fix |
|---|---|
| Few eggs found, or eggs in the pond | Let out too early — keep them in until about 9:30 a.m. ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)); dig in the nest bedding ([Raising Healthy Poultry, p. 108](lib:raising-healthy-poultry-cvm#page=108)) |
| Bedding soaked and stinking | Water in the house — move it out or onto a screen ([pp. 103–104](lib:raising-healthy-poultry-cvm#page=104)); raise the floor; open up on dry days ([FB 697, p. 16](lib:duck-raising-usda-farmers-bulletin-697#page=16)) |
| Seedlings eaten, beds trampled | Ducks in a growing garden ([Practical Poultry Raising, p. 192](lib:practical-poultry-raising-peace-corps#page=192)): fence them out until the plants are big |
| Duck eggs under a hen don't hatch | Too dry — sprinkle with warm water before pipping; hen off the nest during the hatch ([FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19)); dirty eggs ([Raising Healthy Poultry, p. 107](lib:raising-healthy-poultry-cvm#page=107)) |
| Ducklings chilled or drowned | Swimming before feathered ([FB 697, p. 15](lib:duck-raising-usda-farmers-bulletin-697#page=15)); a waterer they could climb into |
| Few fertile eggs | Drakes younger than the ducks ([Raising Healthy Poultry, p. 107](lib:raising-healthy-poultry-cvm#page=107)); too few drakes; no water to swim in ([FB 697, p. 14](lib:duck-raising-usda-farmers-bulletin-697#page=14)) |
| Muscovies gone over the fence | They fly ([FB 697, p. 7](lib:duck-raising-usda-farmers-bulletin-697#page=7)): clip the flight feathers of one wing; they grow back after the molt *(rule of thumb)* |
| Carcass full of pinfeather stubs | Killed between feather crops: kill at full wing feathers ([FB 697, p. 24](lib:duck-raising-usda-farmers-bulletin-697#page=24)) or wait weeks for the next |

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| **Starve laying ducks 3 days**, water only and no light, to force a molt — [Raising Healthy Poultry, p. 108](lib:raising-healthy-poultry-cvm#page=108) | A factory practice. Let the molt come on its own, with good feed, as for hens |
| **Wash dirty duck eggs and set them**; washing "does not appear to injure their hatching" — [FB 697, p. 19](lib:duck-raising-usda-farmers-bulletin-697#page=19) | Set **only clean nest eggs**; dirty and yard eggs carry the germs that kill embryos and ducklings ([Raising Healthy Poultry, pp. 107–109](lib:raising-healthy-poultry-cvm#page=107)). Eat the dirty ones, well cooked |
| Muscovy × common hybrids are "sometimes fertile" — [FB 697, p. 7](lib:duck-raising-usda-farmers-bulletin-697#page=7) | They are **sterile** mule ducks ([Raising Healthy Poultry, p. 96](lib:raising-healthy-poultry-cvm#page=96); [FAO, p. 14](lib:small-scale-poultry-production-technical-guide#page=14)) |
| Keep breeding ducks **one laying season**, then sell them — [FB 697, p. 18](lib:duck-raising-usda-farmers-bulletin-697#page=18) | That was for market-duck farms. Egg breeds lay well **3–4 years** ([p. 11](lib:duck-raising-usda-farmers-bulletin-697#page=11)) |
| **Lights all night** in brooders and yards so ducks eat more — [FB 697, p. 21](lib:duck-raising-usda-farmers-bulletin-697#page=21) | No power to spare, and a lamp in straw is a fire risk *(rule of thumb)*. Light matters mainly the first few days, to find feed and water ([Raising Healthy Poultry, p. 105](lib:raising-healthy-poultry-cvm#page=105)) |
| **Paraffin** wax dips — [Slaughter and Preservation of Meat, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84) | Fine if you have it; beeswax works the same way. No wax: dry-pluck and singe |
| The old poultry bulletins' louse and mite poisons (sodium fluoride, nicotine sulfate, DDT) | See the Chickens guide's old-advice table; clean bedding and clean bathing water |

---

## 🖼️ Pictures & diagrams

🖼️ = pictures in the books on this drive (open the page); 📷 = photos in the offline Wikipedia.

**Breeds**
- Aylesbury, Rouen and White Runner photos — [🖼️ FB 697, p. 6](lib:duck-raising-usda-farmers-bulletin-697#page=6);
  [🖼️ p. 8](lib:duck-raising-usda-farmers-bulletin-697#page=8); [🖼️ p. 10](lib:duck-raising-usda-farmers-bulletin-697#page=10)
- Mallard, Pekin and Rouen drawings; a Muscovy drake, mule ducks, a Khaki Campbell —
  [🖼️ Raising Healthy Poultry, p. 94](lib:raising-healthy-poultry-cvm#page=94); [🖼️ p. 95](lib:raising-healthy-poultry-cvm#page=95);
  [🖼️ p. 96](lib:raising-healthy-poultry-cvm#page=96); [🖼️ p. 97](lib:raising-healthy-poultry-cvm#page=97)
- 📷 the breed links in the table at the top; [Mulard](wiki:Mulard) (mule duck)

**Housing and equipment**
- Duck yards running into a stream; a breeding house; an open-shed shelter — [🖼️ FB 697, p. 14](lib:duck-raising-usda-farmers-bulletin-697#page=14);
  [🖼️ p. 15](lib:duck-raising-usda-farmers-bulletin-697#page=15); [🖼️ p. 24](lib:duck-raising-usda-farmers-bulletin-697#page=24)
- Herded ducks; a duck and fish pond — [🖼️ Raising Healthy Poultry, p. 98](lib:raising-healthy-poultry-cvm#page=98);
  [🖼️ p. 100](lib:raising-healthy-poultry-cvm#page=100)
- Wire floor frame, feed hopper with apron, waterers, a floor nest — [🖼️ p. 102](lib:raising-healthy-poultry-cvm#page=102);
  [🖼️ p. 103](lib:raising-healthy-poultry-cvm#page=103); [🖼️ p. 104](lib:raising-healthy-poultry-cvm#page=104);
  [🖼️ p. 107](lib:raising-healthy-poultry-cvm#page=107)

**Hatching and slaughter**
- Candled duck eggs, [🖼️ Raising Healthy Poultry, p. 110](lib:raising-healthy-poultry-cvm#page=110); a duckling brooder house,
  [🖼️ FB 697, p. 17](lib:duck-raising-usda-farmers-bulletin-697#page=17); stripping wax,
  [🖼️ Raising Healthy Poultry, p. 116](lib:raising-healthy-poultry-cvm#page=116); plucking tools, [🖼️ UMN EB 385, p. 2](lib:home-processing-of-poultry#page=2)
- 📷 [Down feather](wiki:Down_feather); [Great horned owl](wiki:Great_horned_owl)

## 🔗 Related guides

- [Chickens guide](guide:CHICKENS-GUIDE) — predators and fences, broody hens, brooding without power, bird flu, lice, slaughter step by step
- [Bees guide](guide:BEES-GUIDE) — rendering and storing the beeswax for plucking
- [Seed Bank guide](guide:SEED-BANK-GUIDE) — the garden the ducks patrol, and growing feed grain and greens
- [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — milling (bran and middlings for the mash) and rendering fat
- [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE) — pressure-canning duck, storing eggs
- [Clothing & Leather guide](guide:CLOTHING-LEATHER-GUIDE) — bedding and staying warm in the wet
- [Wildfire guide](guide:WILDFIRE-GUIDE) — smoke, evacuation and fire-safe outdoor work
- [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE) — a solar charger for an electric fence
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — trapping the raccoon that gets in, fish scraps for feed
- The [Geese](guide:GEESE-GUIDE), [Turkeys](guide:TURKEYS-GUIDE) and [Dogs](guide:DOGS-GUIDE) guides — other poultry, and guardian dogs
