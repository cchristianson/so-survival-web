# ⏳ What to Expect: Disaster Scenarios & Timelines

What really happens, hour by hour and month by month, in the disasters most likely to hit the
Illinois Valley, and what to do at each stage. The timelines come from official plans and
after-action reports: the Oregon Resilience Plan, the Josephine County hazard plan, the state's
review of the 2020 Labor Day fires, federal and state power-outage and fuel plans, and fifty years
of disaster research. The books are in `Disaster-Scenarios\` (`Cascadia-Earthquake`,
`Local-Hazards`, `Fire-Heat-Drought`, `Grid-Supply-Pandemic`, `How-People-Respond`), with more in
`Wildfire\`, `Earthquake-Tsunami\`, `Nuclear-Radiation\` and `EMP-Solar-Storms\`.

> ### ⚠️ Five rules that hold in every scenario
> 1. **Plan to be on your own for at least two weeks.** The state's own Cascadia exercise said
>    so ([Cascadia Rising, p. 12](lib:cascadia-rising-2016#page=12)). At the end of one highway, plan longer.
> 2. **Leave early.** Alerts fail when cell towers burn or lose power
>    ([2020 fire review, p. 9](lib:september-2020-wildland-fire#page=9)). A Level 2 "Be Set" notice may be the only warning you get.
> 3. **Check on people who live alone.** Most who died in the 2021 heat dome lived alone
>    ([heat report, p. 10](lib:excessive-heat-events#page=10)).
> 4. **Generators, grills and camp stoves stay outdoors.** Carbon monoxide kills in every
>    outage ([CPSC](lib:cpsc-carbon-monoxide-the-invisible-killer)).
> 5. **Expect neighbors to help, and be one.** Panic and looting are rare; survivors do most of
>    the rescuing ([Quarantelli, p. 16](lib:conventional-beliefs#page=16)).

---

## 🧭 How to use this guide

1. **Find your scenario** in the table below, or the one closest to what is happening.
2. **Read its timeline** for the stage you are in: what is happening around you, and what to do.
3. **Do its "Get ready now" list** while things are normal. Most items point to another guide.
4. Read **What every scenario has in common** once. It applies to all of them.

**How likely** and **how bad** use Josephine County's own ratings where it has them. The county
counts a hazard as *high* probability if one is expected in the next 10–35 years, *moderate* for
35–75 years and *low* for 75–100 years; *high* vulnerability means more than 10% of people or
property could be hit, *moderate* 1–10%, *low* under 1%
([county plan, p. 39](lib:josephine-county-multi-jurisdictional#page=39);
[p. 64](lib:josephine-county-multi-jurisdictional#page=64); [p. 68](lib:josephine-county-multi-jurisdictional#page=68)).
Ratings the county didn't make are marked *(estimate)*. The "signs it's getting worse or better"
lists are rules of thumb.

| # | Scenario | How likely here | How bad here | Source |
|---|---|---|---|---|
| 1 | 🔥 Wildfire and smoke | **High** — 1,175 fires in the county 2010–2019 | **High** — the county's #1 hazard | [County plan, pp. 28–29](lib:josephine-county-multi-jurisdictional#page=28) |
| 2 | ❄️ Winter storm, ice, flood, landslide | **High** — storms "a couple times every year, to every other year" | **High** for storms; moderate for floods; low for landslides | [County plan, p. 64](lib:josephine-county-multi-jurisdictional#page=64) |
| 3 | 🌡️ Extreme heat and drought | **High** | **Moderate** — deadly for people alone without cooling | [County plan, p. 28](lib:josephine-county-multi-jurisdictional#page=28); [heat report, p. 2](lib:excessive-heat-events#page=2) |
| 4 | 🔌 Power out for weeks | **High** for days-long outages; weeks-long less often *(estimate)* | **Moderate**; worse in winter or a heat wave | [County plan, p. 140](lib:josephine-county-multi-jurisdictional#page=140) |
| 5 | 🦠 Pandemic | **Moderate** — flu pandemics in 1918, 1957, 1968 and 2009, then COVID-19 in 2020 | **Low to very high**, depending on the germ | [WHO, p. 52](lib:pandemic-influenza-risk-management#page=52) |
| 6 | ⛽ Economic crisis, fuel and supply breakdown | **Moderate** for short shortages; a long breakdown is less likely *(estimate)* | **Moderate**; stations hold 2–3 days of fuel | [Fuel plan, p. 11](lib:oregon-fuel-action-plan#page=11) |
| 7 | 🌎 Cascadia M9 earthquake | **Moderate** — 37–43% chance of a Cascadia quake in 50 years; 7–12% for the full M9 | **Very high** — the worst disaster we are likely to see | [County plan, p. 39](lib:josephine-county-multi-jurisdictional#page=39) |
| 8 | 🚨 Riots, law and order breaking down | **Low** on its own; higher during a long breakdown *(estimate)* | **Moderate to high** where it happens | [Quarantelli, pp. 12–14](lib:conventional-beliefs#page=12) |
| 9 | ☀️ Solar storm or EMP | **Low** for one that wrecks the grid *(estimate)* | **Very high** — grid down for months or more | [EMP Commission, p. 27](lib:emp-commission-executive-report#page=27) |
| 10 | ☢️ Nuclear attack and fallout | **Low**; no one can give honest odds *(estimate)* | **Very high** if we are downwind | [FEMA *Planning Guidance*, p. 54](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=54) |
| 11 | 🌋 Volcanic ash | **Low** — about 1 in 10,000 a year for 0.4 in of ash | **Low** | [County plan, p. 68](lib:josephine-county-multi-jurisdictional#page=68) |

**About the Cascadia numbers:** the Oregon Resilience Plan gives restoration times by zone. The
county plan puts most of Josephine County in its **Valley zone**, with parts in the **Coastal
zone** ([p. 39](lib:josephine-county-multi-jurisdictional#page=39)), so the valley numbers below
are a best case for us.

📚 **Go deeper:** [County hazard plan, p. 29](lib:josephine-county-multi-jurisdictional#page=29) — how the county ranked every hazard; [Cave Junction's own ratings, p. 118](lib:josephine-county-multi-jurisdictional#page=118); [Oregon Resilience Plan, p. 22](lib:oregon-resilience-plan-full-report#page=22) — the restoration-time table.

## 🔥 1. Wildfire and smoke

**What it is and how likely here.** Fires start here every summer: 1,175 in 2010–2019, about 80%
started by people ([county plan, pp. 72–73](lib:josephine-county-multi-jurisdictional#page=72)).
Burn probability is "considerably higher along highway 199 between Grants Pass and Cave
Junction," so a fire could cut the valley off ([p. 71](lib:josephine-county-multi-jurisdictional#page=71)).
In September 2020 the [Slater and Devil fires](wiki:Slater_and_Devil_fires) burned over 166,000 acres and closed
highways around the county ([p. 73](lib:josephine-county-multi-jurisdictional#page=73)), while
east winds spread fires statewide: over 500,000 Oregonians were under some level of evacuation
notice ([state review, p. 20](lib:september-2020-wildland-fire#page=20)).

**Warning you'll get:** days for the weather (the Weather Service warned of the Labor Day winds
ahead of time); **minutes to hours** for a fire near you.

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | Fire runs with the wind; embers start new fires ahead of it. Levels 1–2–3 go out, but some cell towers burned in 2020 and alerts failed ([p. 9](lib:september-2020-wildland-fire#page=9)). Power cut or lines down. Roads jam. | Go at Level 2 if you can; at Level 3 go now. Two routes out. N95 masks. Move livestock early, in daylight. |
| First 3 days | Shelters open (in 2020 the Red Cross ran 15, with almost 2,000 people — [p. 20](lib:september-2020-wildland-fire#page=20)). US-199 may close. Thick smoke. No power means no well water. | Stay out until allowed back. Keep the sick, old and young in a cleaner-air room. Check in with family by radio or text. |
| 1–2 weeks | Big fires can burn for weeks *(estimate)*; smoke comes and goes. Re-entry begins; burned poles and lines are replaced; weakened trees fall. | Shock-chlorinate and test the well before drinking ([OWRD](lib:owrd-maintaining-your-well-after-wildfire)). N95, gloves and boots in ash. |
| 1–3 months | Fall rains usually end the season *(rule of thumb)*. Burned slopes can let go as debris flows in the first big storms ([FEMA, p. 107](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=107)). | Watch burned slopes above houses and roads when it pours. Help neighbors clear debris. Plan winter shelter if a house is lost. |
| 3–12 months | Debris removal and rebuilding; housing is scarce. | Rebuild with a fire-resistant roof, ember-proof vents and a 5-ft clear zone. |
| 1 year+ | "Recovery efforts will be on-going for many years" ([p. 14](lib:september-2020-wildland-fire#page=14)). | Redo defensible space every spring. |

**Signs it's getting worse:** dry east wind, humidity in the teens, a red flag warning, a smoke
column building in the afternoon ([Pyrocumulonimbus](wiki:Cumulonimbus_flammagenitus)), ash falling,
power shut off ahead of wind. **Getting better:** wind turns back from the west, humidity rises,
rain, containment numbers climb.

**Get ready now**
- [ ] Clear 5 ft and 30 ft around the house; 1/8-in metal mesh on vents — [Illinois Valley guide](guide:ILLINOIS-VALLEY-START-HERE), [Shelter & repair](guide:SHELTER-BUILDING-GUIDE)
- [ ] Sign up for Citizen Alert; write down your evacuation zone — [Illinois Valley guide](guide:ILLINOIS-VALLEY-START-HERE)
- [ ] A battery radio and the local stations — [Radio guide](guide:RADIO-GUIDE)
- [ ] Go-kit with N95s, medicines, papers and water; a plan for animals — [Horses](guide:HORSE-GUIDE), [Goats, Dairy & Bees](guide:GOATS-DAIRY-BEES-GUIDE)
- [ ] Water that doesn't need the well pump — [Water wells](guide:WATER-WELLS-GUIDE)
- [ ] Burn care supplies — [Field care](guide:FIELD-CARE-GUIDE)

📚 **Go deeper:** [2020 fire review, p. 20](lib:september-2020-wildland-fire#page=20) — the Labor Day fires as they happened; [County plan, p. 71](lib:josephine-county-multi-jurisdictional#page=71) — the burn-probability map; [*Ready, Set, Go!*](lib:ready-set-go-wildland-fire-action-guide-iafc-10th-edition) — evacuating; [EPA smoke guide, p. 61](lib:epa-wildfire-smoke-guide-2026#page=61) — the cleaner-air room.

## ❄️ 2. Winter storm, ice, flood and landslides

**What it is and how likely here.** The county rates winter storms #2 of all hazards: high
probability, high vulnerability. Recent ones: in February 2019 fallen trees closed US-199 at the
California line and 2,500 customers lost power around Grants Pass, Cave Junction and O'Brien; in
January 2021 snow left **45,000 customers** in the area without power
([county plan, p. 64](lib:josephine-county-multi-jurisdictional#page=64)). The valley is "one way
in, one way out": a storm on US-199 can strand Cave Junction and cut the whole valley's power
"for an extended period" ([p. 140](lib:josephine-county-multi-jurisdictional#page=140)). Floods
are rated high probability, moderate damage. The benchmark is the
[Christmas flood of 1964](wiki:Christmas_flood_of_1964): 10 inches of rain in six days, the Rogue
and Illinois Valleys cut off and I-5 closed ([p. 45](lib:josephine-county-multi-jurisdictional#page=45)).
In 2015, water covered US-199 near Selma and closed roads near O'Brien ([p. 46](lib:josephine-county-multi-jurisdictional#page=46)).

**Warning you'll get:** usually **days** (forecasts of snow, ice or an
[atmospheric river](wiki:Atmospheric_river)); **minutes** for a flash flood or landslide.

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | Trees and lines come down; roads blocked; creeks rise fast. | Stay off the roads. Never drive into flooded roads ([FEMA, p. 54](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=54)). Get water stored before the pump stops. |
| First 3 days | Power out across the valley; phones fade as tower batteries run down ([outage annex, p. 107](lib:power-outage-incident-annex#page=107)). Stores and stations closed or empty. | Heat one room. Generator outdoors only. Check on neighbors, especially older people alone. |
| 1–2 weeks | Most past big-storm outages were fixed within about two weeks ([outage annex, p. 10](lib:power-outage-incident-annex#page=10)); far-out rural lines come last *(estimate)*. Slides close roads. | Ration fuel and firewood. Watch slopes for warning signs (below). |
| 1–3 months | Landslide and washout repairs; some roads one lane or closed. | Plan longer trips around closures; keep a spare week of supplies. |
| 3–12 months | Bigger slides on highways can take many months *(estimate)*. | Fix drainage above the house before next winter. |
| 1 year+ | Back to normal for most. | Restock. |

**Signs it's getting worse:** freezing rain (ice on lines and trees), a second storm forecast
behind the first, rising creeks at night. **Landslide warning signs:** doors or windows that
suddenly stick, new cracks in walls or ground, tilting trees or poles, water bursting from new
places, a rumble that gets louder ([FEMA, p. 108](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=108);
[Landslide](wiki:Landslide)). **Getting better:** temperatures above freezing, rivers falling,
crews working on the main lines.

**Get ready now**
- [ ] Dry firewood for a whole winter and a safe stove — [Firewood](guide:FIREWOOD-GUIDE)
- [ ] Backup power, wired safely — [Off-grid power](guide:OFF-GRID-POWER-GUIDE); chainsaw running — [Engines](guide:ENGINES-AND-MOTORS-GUIDE)
- [ ] Water for when the pump stops — [Water wells](guide:WATER-WELLS-GUIDE)
- [ ] Warm clothes, dry boots — [Clothing](guide:CLOTHING-LEATHER-GUIDE); hypothermia care — [Field care](guide:FIELD-CARE-GUIDE)
- [ ] Gutters, culverts and ditches clear before November *(rule of thumb)* — [Shelter & repair](guide:SHELTER-BUILDING-GUIDE)

📚 **Go deeper:** [County plan, pp. 45–46](lib:josephine-county-multi-jurisdictional#page=45) — local flood history; [p. 52](lib:josephine-county-multi-jurisdictional#page=52) — landslide history; [FEMA *Are You Ready?*, p. 81](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=81) — winter storms and extreme cold.

## 🌡️ 3. Extreme heat and drought

**What it is and how likely here.** The county rates heat waves high probability, moderate
damage. Days with a heat index over 90 °F are expected to rise from about 13 a year to about 40
by the 2050s ([county plan, p. 57](lib:josephine-county-multi-jurisdictional#page=57)). In the
[June 2021 heat dome](wiki:2021_Western_North_America_heat_wave) Josephine County saw 92–108 °F,
with two more heat waves later that summer ([p. 58](lib:josephine-county-multi-jurisdictional#page=58)).
In Portland it killed **72 people**; in a normal year, none. Most were 60 or older and lived
alone, and half had only a fan ([heat report, pp. 2, 8–12](lib:excessive-heat-events#page=2)).
Drought is also rated high probability: extreme drought years 1924, 1977 and 2001, severe ones as
recently as 2014 and 2020 ([p. 33](lib:josephine-county-multi-jurisdictional#page=33)).

**Warning you'll get:** **days** for heat; **months** for drought (a dry winter and low snow).

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | Afternoons over 100 °F; houses don't cool at night. Fire danger jumps; power may be shut off for fire risk. | Cool one room (shade, wet cloths, a basement). Above the upper 90s a fan only moves hot air ([heat report, p. 12](lib:excessive-heat-events#page=12)). |
| First 3 days | Deaths peak after the hottest day — in Portland the worst day was the day after 116 °F ([heat report, p. 7](lib:excessive-heat-events#page=7)). | Visit or call anyone living alone twice a day. Do outdoor work at dawn *(rule of thumb)*. |
| 1–2 weeks | Heat breaks, then can return; Josephine had three heat waves in summer 2021. Creeks and shallow wells drop. | Cut water use; shade gardens and animals. |
| 1–3 months | Drought: wells yield less in late summer ([OWRD](lib:water-wells-and-drought-owrd-2026#page=1)); pastures brown early; fire season long. | Water the garden at the roots; save seed from survivors. |
| 3–12 months | Short harvests; hay expensive or gone *(estimate)*. | Plan feed and food for winter early. |
| 1 year+ | Droughts can run for years: severe or extreme in 1924, 1926, 1931 and 1934 ([p. 33](lib:josephine-county-multi-jurisdictional#page=33)). | Store rainwater; plant drought-tough crops. |

**Signs it's getting worse:** night lows staying in the 70s, a forecast of more days over 100 °F,
confusion or no sweating in someone hot ([Heat stroke](wiki:Heat_stroke) — an emergency).
**Getting better:** marine air and cooler nights; fall rains.

**Get ready now**
- [ ] Know heat exhaustion from heat stroke and how to cool someone fast — [Field care](guide:FIELD-CARE-GUIDE)
- [ ] A cool room that works with no power: shade cloth, a basement, wet sheets — [Shelter & repair](guide:SHELTER-BUILDING-GUIDE)
- [ ] Water storage, and a plan for a weak well — [Water wells](guide:WATER-WELLS-GUIDE)
- [ ] Drought-hardy seed — [Seed bank](guide:SEED-BANK-GUIDE)
- [ ] Shade and water for animals — [Rabbits & chickens](guide:RABBITS-CHICKENS-GUIDE)

📚 **Go deeper:** [Heat report](lib:excessive-heat-events#page=2) — who died and why; [County plan, p. 32](lib:josephine-county-multi-jurisdictional#page=32) — drought here; [FEMA *Are You Ready?*, p. 87](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=87) — extreme heat.

## 🔌 4. Long power outage, including fire-season shutoffs

**What it is and how likely here.** Storms knock out power almost every winter (scenario 2).
Pacific Power has mapped areas near Cave Junction where it may cut power on purpose in dangerous
fire weather, called a **public safety power shutoff** ([county plan, p. 140](lib:josephine-county-multi-jurisdictional#page=140);
[state fire review, p. 10](lib:september-2020-wildland-fire#page=10)). Longer outages come with
bigger disasters: about two weeks after Hurricane Sandy and Katrina in most places, 11 days in
Connecticut in 2011 ([outage annex, p. 10](lib:power-outage-incident-annex#page=10)), **1–3
months** after a Cascadia quake ([Resilience Plan, p. 22](lib:oregon-resilience-plan-full-report#page=22)),
months to years after a grid-wrecking solar storm or EMP (scenario 9).

**Warning you'll get:** shutoffs are usually announced ahead by the utility *(verify with
Pacific Power)*; storm outages give hours; quake or EMP none.

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | Well pumps, furnaces, fridges stop. Phones and towers run on batteries or generators for "hours to a few days" ([outage annex, p. 107](lib:power-outage-incident-annex#page=107)). | Fill containers if any pressure is left. Keep fridge and freezer shut. |
| First 3 days | Gas stations can't pump without power, as after Hurricane Sandy ([NASEO, p. 72](lib:guidance-for-states-on-petroleum-shortage-response-planning-naseo-2018#page=72)); stores close. Septic pumps stop ([Texas AgriLife](lib:septic-systems-responding-to-electrical-power-outages-and-floods-texas-agrilife-extension-er-001)). Cell service fades. | Cook the thawing food first. Generator outdoors, through a transfer switch only. AM radio for news. |
| 1–2 weeks | Most storm outages end here. Fuel for generators runs short. | Run the generator a few hours a day. Bucket toilet if the septic pump is out. |
| 1–3 months | Cascadia-scale outage. Water systems, clinics and stations with no fuel shut down *(estimate)*. | Off-grid power for the essentials; preserve food without a freezer. |
| 3–12 months | A big transformer takes about a year to replace ([Meta-R-319, p. 149](lib:meta-r-319-geomagnetic-storms#page=149)). | Shift to wood heat, hand pumps, root cellar, daylight hours. |
| 1 year+ | Only after EMP or a huge solar storm *(estimate)*. | Long-term off-grid living — this library. |

**Signs it's getting worse:** no restoration estimate from the utility, damage to big lines or
substations, fuel shortages. **Getting better:** crews in the area, power back in town first.

**Get ready now**
- [ ] Safe backup power and fuel — [Off-grid power](guide:OFF-GRID-POWER-GUIDE), [Fuel](guide:FUEL-GUIDE)
- [ ] A hand pump or other well water with no power — [Water wells](guide:WATER-WELLS-GUIDE)
- [ ] Food that needs no freezer — [Preserving food](guide:PRESERVING-FOOD-GUIDE), [Root cellar](guide:ROOT-CELLAR-GUIDE)
- [ ] A toilet plan for a dead septic pump — [Sanitation](guide:SANITATION-GUIDE)
- [ ] A battery CO alarm near the bedrooms ([CPSC](lib:cpsc-portable-generator-hazards-co-backfeed-and-fuel-safety))

📚 **Go deeper:** [Power outage annex, p. 10](lib:power-outage-incident-annex#page=10) — how long big outages lasted; [p. 17](lib:power-outage-incident-annex#page=17) — how much fuel generators burn; [County plan, p. 140](lib:josephine-county-multi-jurisdictional#page=140) — the Cave Junction shutoff map.

## 🦠 5. Pandemic

**What it is and how likely here.** A new germ spreads around the world, usually "within several
weeks or months." The last century had flu pandemics in 1918, 1957, 1968 and 2009
([WHO, pp. 51–52](lib:pandemic-influenza-risk-management#page=51)), and then
[COVID-19](wiki:COVID-19_pandemic) — so expect one or two in a lifetime *(estimate)*. A pandemic
comes in **waves of several weeks to a few months**, and a later wave can be worse: the mild
spring wave of 1918 came before the deadly autumn one ([p. 52](lib:pandemic-influenza-risk-management#page=52);
[Spanish flu](wiki:Spanish_flu)).

**Warning you'll get:** **weeks to months** from the first news to cases here.

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | (Weeks of news first.) Panic buying can empty shelves even when supply is fine, as after Japan's 2011 quake ([CNA, p. 41](lib:role-of-groceries#page=41)). | Buy steadily, not in a panic; fill gaps in medicines and soap. |
| First 3 days | Cases appear locally; schools may close; rumors spread. | Plan a sickroom; decide how the household will isolate a sick person. |
| 1–2 weeks | The first wave builds. More people miss work than are sick ([WHO, p. 51](lib:pandemic-influenza-risk-management#page=51)); school closures alone may keep about 16% home ([p. 52](lib:pandemic-influenza-risk-management#page=52)). Clinics are crowded. | Keep sick people apart; wash hands; nurse at home with fluids. |
| 1–3 months | A wave peaks and falls; early waves use up masks and medicines ([p. 51](lib:pandemic-influenza-risk-management#page=51)). | Restock between waves. Teach children at home. |
| 3–12 months | More waves, of different sizes. | Don't let your guard down after the first wave. |
| 1 year+ | The "transition" phase: the risk falls and emergency measures wind down ([WHO, p. 14](lib:pandemic-influenza-risk-management#page=14)). | Repair what was put off. |

**Signs it's getting worse:** sick people in more than one household nearby, health workers
falling ill, shortages of medicines. **Getting better:** fewer new cases week after week, schools
reopening.

**Get ready now**
- [ ] Handwashing, safe toilets, isolating the sick — [Sanitation](guide:SANITATION-GUIDE)
- [ ] Nursing a bedridden person for weeks — [Field care](guide:FIELD-CARE-GUIDE), [Medical guide](guide:Medical-READ-ME-FIRST)
- [ ] Three months of food so you can stay home *(rule of thumb)* — [Food security](guide:FOOD-SECURITY-GUIDE)
- [ ] Schooling at home — [Childbirth & children](guide:CHILDBIRTH-CHILDREN-GUIDE)
- [ ] Who checks on whom in the neighborhood — [Community & barter](guide:COMMUNITY-BARTER-GUIDE)

📚 **Go deeper:** [WHO pandemic guide, p. 51](lib:pandemic-influenza-risk-management#page=51) — waves, absenteeism and past pandemics; [WHO field manual](lib:communicable-disease-control-in-emergencies-a-field-manual-who-2005) — isolating cases in an outbreak.

## ⛽ 6. Economic crisis, fuel and supply-chain breakdown

**What it is and how likely here.** Oregon has no refineries; more than 90% of its fuel comes from
four refineries near Seattle, mostly through one pipeline to the Portland fuel hub
([fuel plan, p. 9](lib:oregon-fuel-action-plan#page=9)). Gas stations hold **about two to three
days** of fuel ([p. 11](lib:oregon-fuel-action-plan#page=11)). Groceries hold more shelf-stable
food than most people think; the real problem in a catastrophe is **delivery**, not supply
([CNA, p. 9](lib:role-of-groceries#page=9)). In the 1970s oil shortages states used odd-even days
to cut gas lines ([NASEO, p. 45](lib:guidance-for-states-on-petroleum-shortage-response-planning-naseo-2018#page=45);
[1973 oil crisis](wiki:1973_oil_crisis)). In the [Great Depression](wiki:Great_Depression)
people formed barter associations to trade work and goods ([Braun 1933, p. 5](lib:organization-and-operation-of-barter-associations-in-california-braun-uc-extension-1933#page=5)).

**Warning you'll get:** **days to months** — prices rise, then shortages begin.

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | News of a shortage starts a run on fuel and food ([panic buying](wiki:Panic_buying)); even a "don't top off your tank" message does ([fuel plan, p. 87](lib:oregon-fuel-action-plan#page=87)). | Don't join the run if you're stocked; top up slowly beforehand. |
| First 3 days | Stations run dry; shelves empty of staples; cash only if card systems fail *(estimate)*. | Keep some cash in small bills. Stay home; save fuel. |
| 1–2 weeks | Rationing: odd/even days, purchase limits ([fuel plan, p. 54](lib:oregon-fuel-action-plan#page=54)). | Combine trips; carpool; bike. |
| 1–3 months | Jobs and wages hit; neighbors start trading *(estimate)*. | Trade skills and surplus fairly; start a garden bed. |
| 3–12 months | A real depression: barter groups and local scrip appear, as in 1932–33 ([Braun, p. 17](lib:organization-and-operation-of-barter-associations-in-california-braun-uc-extension-1933#page=17)). | Organize a skills list and a barter day. |
| 1 year+ | A depression can last years *(estimate)*. | Grow, preserve and repair locally. |

**Signs it's getting worse:** stations limiting gallons, stores limiting items, delivery trucks
skipping the valley. **Getting better:** limits lifted, prices steady.

**Get ready now**
- [ ] A year of staple food, stored right — [Food security](guide:FOOD-SECURITY-GUIDE)
- [ ] Stored fuel kept fresh — [Fuel](guide:FUEL-GUIDE)
- [ ] Bike or cart for errands — [Bicycles & carts](guide:BICYCLES-CARTS-GUIDE)
- [ ] Seed and a garden that already works — [Seed bank](guide:SEED-BANK-GUIDE)
- [ ] Neighbors who know each other's skills — [Community & barter](guide:COMMUNITY-BARTER-GUIDE)

📚 **Go deeper:** [Fuel plan, p. 5](lib:oregon-fuel-action-plan#page=5) — the worst case; [CNA groceries report, p. 9](lib:role-of-groceries#page=9) — why the problem is delivery; [Private money and LETS](lib:private-money-local-currencies-and-lets-federal-reserve-bank-of-cleveland-1998) — local currencies.

## 🌎 7. Cascadia M9 earthquake (and the coast tsunami)

**What it is and how likely here.** The [Cascadia subduction zone](wiki:Cascadia_subduction_zone)
last broke on January 26, 1700 ([1700 Cascadia earthquake](wiki:1700_Cascadia_earthquake)). About
half of past quakes were centered off the southern Oregon coast; the odds of one hitting southern
Oregon in the next 50 years are about **37%** ([Resilience Plan, p. 31](lib:oregon-resilience-plan-full-report#page=31)).
The county puts it at 37–43% for any Cascadia quake and 7–12% for the full M9, and rates our
vulnerability **high** ([county plan, p. 39](lib:josephine-county-multi-jurisdictional#page=39)).
Studies estimate 650–5,000 deaths from the quake and another 600–5,000 from the tsunami ([Resilience Plan, p. 40](lib:oregon-resilience-plan-full-report#page=40)).

**Warning you'll get:** **none.** The shaking is the warning. It lasts **4–6 minutes**
([CREW, p. 10](lib:crew-cascadia-m9-earthquake-scenario#page=10)).

| When | What's happening (Valley zone unless noted) | What you do |
|---|---|---|
| First minutes–hours | Shaking 4–6 minutes; landslides on mountain roads; chimneys and older houses damaged *(estimate)*. The [tsunami](wiki:Tsunami) reaches parts of the coast within 15 minutes ([fuel plan, p. 5](lib:oregon-fuel-action-plan#page=5)). Phones jammed or dead. | Drop, cover, hold on. Then injuries and fires. Smell gas or propane? Get out first, then shut it off ([Be 2 Weeks Ready, p. 80](lib:oregon-be-2-weeks-ready-complete-toolkit#page=80)). Don't drive. |
| First 3 days | Aftershocks, a few possibly over M7 ([CREW, p. 13](lib:crew-cascadia-m9-earthquake-scenario#page=13)). No outside help. US-199 likely blocked. Stations' 2–3 days of fuel goes. | Check every neighbor. Set up water, toilet and a cooking spot outdoors. Listen to AM radio and the ham nets. |
| 1–2 weeks | Oregon's fuel terminals hold only 3–5 days of fuel and sit on shaky ground ([Resilience Plan, p. 318](lib:oregon-resilience-plan-full-report#page=318)); fuel rationing. Coast towns are cut off and need shelter and food ([p. 33](lib:oregon-resilience-plan-full-report#page=33)); some people may come inland over US-199 when it opens *(estimate)*. | Organize the neighborhood: water, food sharing, a first-aid post. Plan how to take in or help coast refugees. |
| 1–3 months | **Electricity back in 1–3 months** in the valley zone (3–6 on the coast); police and fire stations 2–4 months ([Resilience Plan, p. 22](lib:oregon-resilience-plan-full-report#page=22)). | Off-grid power, wood heat. Repair the house before winter. |
| 3–12 months | **Water and sewer: 1 month to 1 year** (coast 1–3 years). **Top highways partly open: 6–12 months.** Fuel system: months or longer ([fuel plan, p. 5](lib:oregon-fuel-action-plan#page=5)). A strong aftershock months later can do more damage ([CREW, p. 13](lib:crew-cascadia-m9-earthquake-scenario#page=13)). | Garden, preserve, barter. Expect hauling by bike, cart or horse. |
| 1 year+ | **Hospitals: 18 months** (coast 3 years or more). The plan warns of a possible "lost generation" of economic decline ([p. 22](lib:oregon-resilience-plan-full-report#page=22)). | Long-term local living. Help rebuild. |

**Signs it's getting worse:** fires spreading in town, a dam or bridge reported out, strong
aftershocks, fuel gone. **Getting better:** a Grants Pass route open, radio reports of supply
points, power back in town.

**Get ready now**
- [ ] Bolt the house to its foundation, strap the water heater — [Shelter & repair](guide:SHELTER-BUILDING-GUIDE)
- [ ] Two weeks of water at least; a way to treat more — [Water purification](guide:WATER-PURIFICATION-GUIDE)
- [ ] Months of food, not days — [Food security](guide:FOOD-SECURITY-GUIDE)
- [ ] Trauma and broken-bone care — [Field care](guide:FIELD-CARE-GUIDE)
- [ ] Toilets with no sewer — [Sanitation](guide:SANITATION-GUIDE)
- [ ] A radio plan and a neighborhood meeting spot — [Radio](guide:RADIO-GUIDE), [Community & barter](guide:COMMUNITY-BARTER-GUIDE)

📚 **Go deeper:** [Resilience Plan, p. 40](lib:oregon-resilience-plan-full-report#page=40) — expected damage and restoration times; [Cascadia Rising report, p. 11](lib:cascadia-rising-2016#page=11) — what the state learned in its exercise; [CREW scenario](lib:crew-cascadia-m9-earthquake-scenario) — the quake explained; [*Living on Shaky Ground*](lib:living-on-shaky-ground-oregon-earthquake-and-tsunami-guide) — Oregon's quake guide.

## 🚨 8. Riots and law and order breaking down

**What it is and how likely here.** Fifty years of disaster research found panic flight so rare that fire researchers stopped
using the idea, and looting "unusual in the typical natural and technological disasters" of
countries like ours ([Quarantelli, pp. 6–7, 11–12](lib:conventional-beliefs#page=6)).
Mass looting did happen after Hurricane Hugo on St. Croix and after
[Hurricane Katrina](wiki:Hurricane_Katrina), where three things came together: many poor people
living beside obvious wealth, organized youth gangs, and a police force that was ineffective or
corrupt ([pp. 13–14](lib:conventional-beliefs#page=13)). Even there, help between people "swamped"
the theft, and after the first emergency days reported crime usually **drops**
([p. 14](lib:conventional-beliefs#page=14)). The EMP Commission warns that disorder becomes more
likely when shortages cause conflict and police are absent for a long time
([EMP Commission 2008, p. 167](lib:emp-commission-critical-national-infrastructures#page=167)).

**Warning you'll get:** usually **days to weeks** of growing shortages or anger first.

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | Rumors travel faster than facts. | Check rumors with someone who saw it. Stay home and calm. |
| First 3 days | In most disasters crime falls; neighbors help. | Be visible helping; know who on your road is alone. |
| 1–2 weeks | If supply and police fail together: theft of fuel, food and tools *(estimate)*. | Lock up fuel and tools; keep a low profile with supplies. |
| 1–3 months | Neighborhood watch, shared patrols, local agreements *(estimate)*. | Join or start a watch group; settle disputes early and fairly. |
| 3–12 months | Communities that organized recover order first *(estimate)*. | Support a fair local council and rules. |
| 1 year+ | Order rebuilds from local groups up *(estimate)*. | Keep records of agreements and trades. |

**Signs it's getting worse:** police no longer answering, groups moving road to road, threats over
fuel or water. **Getting better:** regular patrols, markets reopening, people out in daylight.

**Get ready now**
- [ ] Meet the neighbors now; agree on a meeting place and signals — [Community & barter](guide:COMMUNITY-BARTER-GUIDE), [Signals](guide:SIGNALS-MORSE-GUIDE)
- [ ] Learn to calm an angry person — [Community & barter](guide:COMMUNITY-BARTER-GUIDE)
- [ ] Protect the house and supplies — [Home protection](guide:HOME-DEFENSE-GUIDE)
- [ ] Radios for the neighborhood watch — [Radio](guide:RADIO-GUIDE)

📚 **Go deeper:** [Quarantelli, p. 11](lib:conventional-beliefs#page=11) — what really happens about looting; [Neighborhood Watch manual](lib:neighborhood-watch-manual-bja-and-national-sheriffs-association-2009); [Verbal de-escalation](lib:using-verbal-de-escalation-kentucky-employee-assistance-program).

## ☀️ 9. Solar storm or EMP

**What it is and how likely here.** A severe [geomagnetic storm](wiki:Geomagnetic_storm) or a
nuclear burst high above the country (EMP) mainly threatens the **power grid**. NOAA counts about
four extreme (G5) storms per 11-year solar cycle ([NOAA scales, p. 1](lib:noaa-space-weather-scales#page=1)),
but most do not wreck grids; a [Carrington Event](wiki:Carrington_Event)-size storm is rare
*(estimate)*. Details, tests and protecting gear: [EMP guide](guide:EMP-GUIDE).

**Warning you'll get:** solar storm **18–72 hours**, with a 20–45 minute final warning
([CISA, p. 21](lib:emp-protection-and-resilience-guidelines#page=21)); EMP **none**.

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | Grid may collapse (Quebec's went down in 90 seconds in 1989 — [Meta-R-319, p. 149](lib:meta-r-319-geomagnetic-storms#page=149)); GPS and HF radio unreliable. After an EMP some running cars stall and restart; parked cars were not affected in tests ([EMP Commission 2008, p. 131](lib:emp-commission-critical-national-infrastructures#page=131)). | Unplug electronics; disconnect antennas; get the shielded spares out afterward. |
| First 3 days | Like any long outage (scenario 4), across a whole region. | Water, food, heat; don't waste fuel. |
| 1–2 weeks | No outside help coming from cities also in the dark. | Organize the neighborhood. |
| 1–3 months | Big transformers damaged; each takes about a year to replace ([Meta-R-319, p. 149](lib:meta-r-319-geomagnetic-storms#page=149)). | Off-grid power and hand tools. |
| 3–12 months | The EMP Commission expected **months to years** for recovery ([EMP Commission, p. 27](lib:emp-commission-executive-report#page=27)). | Full local self-reliance. |
| 1 year+ | Slow rebuilding of the grid. | Same. |

**Signs it's getting worse:** auroras over Oregon ([Aurora](wiki:Aurora)), a G4–G5 watch,
widespread outage with no restoration estimate. **Getting better:** power back in Grants Pass.

**Get ready now**
- [ ] Spare radio, charge controller and this library in a sealed metal can — [EMP guide](guide:EMP-GUIDE)
- [ ] Solar power you can run alone — [Off-grid power](guide:OFF-GRID-POWER-GUIDE)
- [ ] Non-electric ways to get water — [Water wells](guide:WATER-WELLS-GUIDE)
- [ ] Paper maps — [Navigation & weather](guide:NAVIGATION-WEATHER-GUIDE)

📚 **Go deeper:** [EMP Commission executive report](lib:emp-commission-executive-report) — the plain overview; [CISA guidelines, p. 44](lib:emp-protection-and-resilience-guidelines#page=44) — simple protection steps.

## ☢️ 10. Nuclear attack and fallout

**What it is and how likely here.** A nuclear detonation somewhere upwind could drop fallout on the
valley. No source on this drive gives honest odds; treat it as low but not zero *(estimate)*.
Everything about sheltering is in the [Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE).

**Warning you'll get:** **minutes or none.** A 3–5 minute wavering siren tone is the attack
warning ([FEMA H-20, p. 12](lib:protection-in-the-nuclear-age#page=12)). Fallout near a blast can
arrive in 15–30 minutes; 100–200 miles downwind, often 5–10 hours or more
([H-20, p. 7](lib:protection-in-the-nuclear-age#page=7)).

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | Officials tell everyone within about 50 miles to shelter ([*Planning Guidance*, p. 54](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=54)). Fallout dust may begin to fall. | **Get inside, stay inside, stay tuned.** Best shelter you can reach before fallout arrives. |
| First 3 days | Radiation drops 90% in 7 hours and 99% in 2 days ([H-20, p. 8](lib:protection-in-the-nuclear-age#page=8)). | Stay sheltered at least 12–24 hours unless told otherwise ([*Planning Guidance*, p. 53](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=53)). |
| 1–2 weeks | In heavy fallout, shelter "several days to two weeks," with short trips out later ([H-20, p. 9](lib:protection-in-the-nuclear-age#page=9)). | Decontaminate on entry; stored and canned food is fine. |
| 1–3 months | Fresh milk unsafe while radioactive iodine decays (USDA says 30–60 days — [PA-515, p. 8](lib:fallout-and-your-farm-food#page=8)). | Wash and peel garden produce; use stored milk for babies. |
| 3–12 months | Recovery depends on how many cities were hit; supply chains may be broken nationwide *(estimate)*. | See scenarios 4 and 6. |
| 1 year+ | Long-term living with shortages *(estimate)*. | This library. |

**Signs it's getting worse:** a meter reading that is rising, fallout dust visible on cars.
**Getting better:** readings falling by the 7-10 rule; officials saying it's clear.

**Get ready now**
- [ ] Pick your shelter now — most local houses need extra shielding — [Nuclear guide](guide:NUCLEAR-FALLOUT-GUIDE)
- [ ] Two weeks of shelter water, food and a toilet bucket — [Sanitation](guide:SANITATION-GUIDE)
- [ ] Potassium iodide for the family, and the dose table — [Nuclear guide](guide:NUCLEAR-FALLOUT-GUIDE)
- [ ] A battery radio — [Radio](guide:RADIO-GUIDE)

📚 **Go deeper:** [FEMA H-20](lib:protection-in-the-nuclear-age#page=7) — warning, fallout timing and shelter; [CDC: where to go](lib:where-to-go-in-a-radiation-emergency#page=1) — on one page.

## 🌋 11. Volcanic ash

**What it is and how likely here.** The nearest potentially active volcanoes are Crater Lake,
Medicine Lake, [Mount Shasta](wiki:Mount_Shasta), Newberry and the Three Sisters. The chance of
0.4 inch or more of [ash](wiki:Volcanic_ash) here is about **1 in 10,000 a year**; the risks are
ashfall, bad air and disruption ([county plan, p. 68](lib:josephine-county-multi-jurisdictional#page=68)).
Winds usually carry ash east of the Cascades, away from us ([p. 68](lib:josephine-county-multi-jurisdictional#page=68)).

**Warning you'll get:** usually **days to weeks** of earthquakes and steam before a big eruption
*(rule of thumb)*; hours as an ash cloud drifts.

| When | What's happening | What you do |
|---|---|---|
| First minutes–hours | Sky darkens; gritty ash falls. | Inside; windows shut. Goggles and a dust mask outside ([FEMA, p. 104](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=104)). |
| First 3 days | Ash on roofs, roads and gardens; engines clog. | Clear heavy ash from roofs and gutters ([FEMA, p. 104](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=104)); cover the well and water tanks. |
| 1–2 weeks | Cleanup; air filters and engines need changing. | Wash produce; keep animals off ashy pasture if you can *(rule of thumb)*. |
| 1–3 months | Mostly back to normal unless eruptions continue *(estimate)*. | Watch the radio for new eruptions. |
| 3–12 months | Ash washes into creeks and gardens with the rains *(estimate)*. | Settle and filter creek water before treating it. |
| 1 year+ | No lasting change expected from a thin ashfall *(estimate)*. | Restock masks and filters. |

**Signs it's getting worse / better:** more ash forecasts, or skies clearing and rain washing it
down.

**Get ready now**
- [ ] Goggles and N95 masks for everyone — [Field care](guide:FIELD-CARE-GUIDE)
- [ ] Covers for the cistern and rain barrels — [Water purification](guide:WATER-PURIFICATION-GUIDE)
- [ ] Spare air filters for engines — [Engines](guide:ENGINES-AND-MOTORS-GUIDE)

📚 **Go deeper:** [County plan, p. 66](lib:josephine-county-multi-jurisdictional#page=66) — volcano hazard here; [FEMA *Are You Ready?*, p. 104](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=104) — during and after an eruption.

## 🤝 What every scenario has in common

**The first 72 hours.** No outside help, so neighbors are the first responders. In the first half
hour after a disaster, about a third of survivors search for missing people and about one in ten
actively rescue them ([Quarantelli, p. 16](lib:conventional-beliefs#page=16)). Your jobs: injuries,
fires, water, a toilet, warmth or cooling, and checking the people next door.

**The 2-week mark.** Oregon tells everyone to be ready for at least two weeks
([Be 2 Weeks Ready, p. 2](lib:oregon-be-2-weeks-ready-complete-toolkit#page=2)). The old 2004 FEMA
book's "at least three days" ([p. 33](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=33))
is too short for here. Two weeks is also about when most big storm outages have ended, and the longest disruption most
businesses can stand ([Resilience Plan, p. 22](lib:oregon-resilience-plan-full-report#page=22)).

**When things usually improve.** Most storm, fire and heat emergencies ease within days to weeks.
A Cascadia quake, EMP or national crisis takes **months to years** (see the tables). Plan for the
long tail, not just the first days.

**Why most neighbors help.** After disasters, help and sharing far outweigh theft, even in the
worst cases ([Quarantelli, p. 14](lib:conventional-beliefs#page=14)); citizen groups spring up to
clear debris, move supplies and pass messages
([EMP Commission 2008, p. 167](lib:emp-commission-critical-national-infrastructures#page=167)).
Plan on cooperating, and organize early.

**Rumor control.** Rumors make things worse. Pick one trusted source (a radio station, the ham
net, a neighborhood runner) and write down news with the time and who said it *(rule of thumb)*;
help correct misinformation ([Psychological First Aid, p. 35](lib:psychological-first-aid-field-operations-guide-2nd-edition-nctsn-and-ncptsd-2006#page=35)).

**Mental health.** Feeling overwhelmed, confused, afraid or numb is a normal reaction
([WHO Psychological First Aid, p. 9](lib:psychological-first-aid-guide-for-field-workers-who-2011#page=9)).
Keep routines, give everyone a job, keep children close and talking, and watch for anyone who
stops eating or caring for themselves *(rule of thumb)*. How-to: [Community & barter](guide:COMMUNITY-BARTER-GUIDE)
and [Psychological first aid](wiki:Psychological_first_aid).

📚 **Go deeper:** [Quarantelli](lib:conventional-beliefs#page=16) — how people really behave; [Skills for Psychological Recovery](lib:skills-for-psychological-recovery-field-operations-guide-ncptsd-and-nctsn-2010#page=9) — the weeks after; [CERT manual](lib:cert-basic-training-participant-manual-fema-2019) — neighborhood search, first aid and organizing.

## 🔁 When disasters stack

Disasters often come together. Plan for the pairs most likely here *(estimates, from the
scenarios above)*:

| Combination | Why it is worse | What to add |
|---|---|---|
| **Cascadia quake + winter** | Power out 1–3 months with no heat; roads blocked by snow and slides. | Firewood stacked for the whole winter; a warm room you can heat without power. |
| **Wildfire + heat + power shutoff** | No fans or pump in 100 °F heat while you wait to evacuate; smoke keeps windows shut. | Stored water, a cool room, a car ready to leave early. |
| **Pandemic + fire or flood** | Crowded shelters spread illness — the 2020 fires had to shelter people during COVID-19 ([state review, p. 29](lib:september-2020-wildland-fire#page=29)). | Evacuate to friends or family instead of a shelter; carry masks and soap. |
| **Pandemic + economic crisis** | Jobs lost while people are sick; supplies short. | Deep food storage and barter skills. |
| **Drought + wildfire** | Dry wells and dry forest in the same summer. | Water storage and defensible space together. |
| **Solar storm or EMP + winter** | Grid down for months in the cold. | Wood heat, hand water pump, food that doesn't need a freezer. |

📚 **Go deeper:** [Resilience Plan, p. 40](lib:oregon-resilience-plan-full-report#page=40) — how one failure spreads to others; [Power outage annex, p. 14](lib:power-outage-incident-annex#page=14) — how power, fuel, water and phones depend on each other.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Local hazards and risk maps**
- Wildfire burn probability around the county and US-199 — [🖼️ county plan, p. 71](lib:josephine-county-multi-jurisdictional#page=71)
- Where big fires burned, 2000–2022 — [🖼️ county plan, p. 73](lib:josephine-county-multi-jurisdictional#page=73); [Biscuit Fire](wiki:Biscuit_Fire); [Slater Fire](wiki:Slater_and_Devil_fires)
- Flood hazard areas — [🖼️ county plan, p. 45](lib:josephine-county-multi-jurisdictional#page=45); [Christmas flood of 1964](wiki:Christmas_flood_of_1964)
- Landslide-prone ground — [🖼️ county plan, p. 51](lib:josephine-county-multi-jurisdictional#page=51); [🖼️ FEMA 232, p. 26](lib:fema-232-homebuilders-guide-to-earthquake-resistant-design-and-construction-fema-2006#page=26); [Landslide](wiki:Landslide)
- Drought years since 1896 — [🖼️ county plan, p. 33](lib:josephine-county-multi-jurisdictional#page=33); [Drought](wiki:Drought)
- Cave Junction power-shutoff areas — [🖼️ county plan, p. 140](lib:josephine-county-multi-jurisdictional#page=140)

**Fire, smoke and heat**
- Defensible-space zones — [🖼️ FEMA P-737, p. 23](lib:fema-p-737-home-builders-guide-to-construction-in-wildfire-zones-fema-2008#page=23)
- How smoke travels hundreds of miles — [🖼️ EPA smoke guide, p. 25](lib:epa-wildfire-smoke-guide-2026#page=25); [N95 respirator](wiki:N95_respirator)
- Fire clouds — [Pyrocumulonimbus](wiki:Cumulonimbus_flammagenitus); [2020 Oregon wildfires](wiki:2020_Oregon_wildfires)
- Heat deaths by day in the 2021 heat dome — [🖼️ heat report, p. 7](lib:excessive-heat-events#page=7); [2021 heat wave](wiki:2021_Western_North_America_heat_wave)

**Cascadia earthquake**
- 10,000 years of Cascadia quakes — [🖼️ Resilience Plan, p. 32](lib:oregon-resilience-plan-full-report#page=32); [1700 Cascadia earthquake](wiki:1700_Cascadia_earthquake)
- Shaking map for an M9 — [🖼️ Resilience Plan, p. 34](lib:oregon-resilience-plan-full-report#page=34); [Cascadia subduction zone](wiki:Cascadia_subduction_zone)
- Impact zones: tsunami, coast, valley, east — [🖼️ Resilience Plan, p. 35](lib:oregon-resilience-plan-full-report#page=35)
- Where landslides and liquefaction are expected — [🖼️ Resilience Plan, p. 36](lib:oregon-resilience-plan-full-report#page=36); [Soil liquefaction](wiki:Soil_liquefaction)
- Strapping the water heater — [🖼️ FEMA 232, p. 155](lib:fema-232-homebuilders-guide-to-earthquake-resistant-design-and-construction-fema-2006#page=155)
- Tsunami — [Tsunami](wiki:Tsunami)

**Grid, fuel, food and sickness**
- Where Oregon's fuel comes from — [🖼️ fuel plan, p. 9](lib:oregon-fuel-action-plan#page=9); [🖼️ Portland fuel tank farms, Resilience Plan p. 190](lib:oregon-resilience-plan-full-report#page=190)
- The power grid's regions — [🖼️ outage annex, p. 60](lib:power-outage-incident-annex#page=60); [Northeast blackout of 2003](wiki:Northeast_blackout_of_2003)
- Grocery supply after Japan's 2011 quake — [🖼️ CNA, p. 40](lib:role-of-groceries#page=40); [Panic buying](wiki:Panic_buying)
- How a pandemic rises and falls — [🖼️ WHO, p. 13](lib:pandemic-influenza-risk-management#page=13); [Spanish flu](wiki:Spanish_flu); [COVID-19 pandemic](wiki:COVID-19_pandemic)

**Fallout, solar storms and ash**
- How fallout comes down — [🖼️ *Fallout Protection*, p. 14](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=14); [Nuclear fallout](wiki:Nuclear_fallout)
- The 7-10 rule chart — [🖼️ FEMA H-20, p. 8](lib:protection-in-the-nuclear-age#page=8)
- How far the 1989 solar storm reached — [🖼️ EMP Commission, p. 25](lib:emp-commission-executive-report#page=25); [🖼️ damaged transformer](lib:emp-commission-critical-national-infrastructures#page=47); [Carrington Event](wiki:Carrington_Event)
- Volcanic ash maps — [🖼️ county plan, p. 67](lib:josephine-county-multi-jurisdictional#page=67); [Volcanic ash](wiki:Volcanic_ash); [Mount Shasta](wiki:Mount_Shasta)

## 🔗 Related guides

- [Emergency finder](guide:EMERGENCY-FINDER) — something is happening right now: where to look
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — alerts, contacts, evacuation, local maps
- [Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE) and [EMP & solar storms](guide:EMP-GUIDE) — the details for scenarios 9 and 10
- [Water purification](guide:WATER-PURIFICATION-GUIDE) and [Water wells](guide:WATER-WELLS-GUIDE) — water in every scenario
- [Food when it's scarce](guide:FOOD-SECURITY-GUIDE) — storing and rationing for months
- [Injuries & illness, no help coming](guide:FIELD-CARE-GUIDE) — first aid when the hospital is cut off
- [Shelter, building & repair](guide:SHELTER-BUILDING-GUIDE) — quake bolting, fire hardening, repairs
- [Community & barter](guide:COMMUNITY-BARTER-GUIDE) — organizing neighbors, watch, trade, grief
- [Home protection](guide:HOME-DEFENSE-GUIDE) — securing the house and supplies
- [Off-grid power](guide:OFF-GRID-POWER-GUIDE) and [Fuel](guide:FUEL-GUIDE) — when the grid is down
- [Signals & Morse](guide:SIGNALS-MORSE-GUIDE) and [Radio](guide:RADIO-GUIDE) — when phones are gone
