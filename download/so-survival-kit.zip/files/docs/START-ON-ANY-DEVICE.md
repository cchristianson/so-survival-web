# 📱💻 Start the Library on Any Device

The library works on almost any computer, tablet or phone, with no internet. Nothing you search
for leaves your device. (No library drive yet? See [Get the whole library](guide:GET-THE-LIBRARY).)

There are **two ways** to use it:

1. **Open `START-HERE.html`** in any web browser, on any device, for every guide and book.
2. **Start the Library Assistant (recommended):** one search box for *everything* on the drive,
   plus an **offline AI** that writes a short answer with links to the exact pages.

> ### ⚠️ Please remember
> - The AI can be wrong. **Always check the pages it links to**, especially for medicine,
>   electricity, chemicals or food.
> - Keep the black window (or Termux) open while you use the assistant. Closing it stops it.

---

## 🚀 Pick your device

Open the drive. If you see a folder called **OfflineLibrary**, open it. The start files are in
there, next to `START-HERE.html`.

| Your device | What to do |
|---|---|
| **Windows** laptop, desktop or Surface tablet | Double-click **START-Windows** |
| **Mac** | Double-click **START-Mac** |
| **Linux** PC, **Raspberry Pi 4/5** (64-bit), or **Chromebook** with Linux turned on | Run **START-Linux.sh** |
| **Android** tablet or phone | Set up the free **Termux** app once, then type `library` |
| **iPhone / iPad**, or any phone with a web browser | Open a library **shared over Wi-Fi** from another device |
| **Very old computer** (Windows 7, 32-bit) | Open **START-HERE.html** (guides and books only), or use a shared library |

---

## 🪟 Windows

1. Plug in the drive and open it (open **OfflineLibrary** if you see it).
2. Double-click **START-Windows**.
3. If a blue box says **Windows protected your PC**, click **More info**, then **Run anyway**.
4. A black window opens, then your web browser. Type your question and click **Ask**.
5. When you're done, close the black window.

## 🍎 Mac

1. Plug in the drive and open it in **Finder** (open **OfflineLibrary** if you see it).
2. Double-click **START-Mac**.
3. A Terminal window opens, then your web browser. Keep Terminal open while you use the library.

**The first time,** the Mac will probably say it **can't open** the file instead:

1. Click **Done** (or **OK**).
2. Open the **Apple menu → System Settings → Privacy & Security**.
3. Scroll down, click **Open Anyway**, and confirm.

(Older Macs: right-click **START-Mac** → **Open** → **Open**.) After that, a normal double-click
works.

## 🐧 Linux, Raspberry Pi, Chromebook

1. Open the drive in the file manager (open **OfflineLibrary** if you see it).
2. Right-click **START-Linux.sh** → **Run as a Program** (or **Run in Terminal**).
3. Your web browser opens. If it doesn't, type the address shown in the window (like
   `http://127.0.0.1:8095/`) into the browser.

**If the file only opens as text:** right-click an empty spot in the folder → **Open in
Terminal** (a window where you type commands). Type this and press Enter:

```
bash START-Linux.sh
```

- **Raspberry Pi:** needs the 64-bit system. Works best on a Pi 5 with 8 GB of memory.
- **Chromebook:** turn on Linux first (open **Settings** and search for **Linux**). In the
  **Files** app, right-click the drive → **Share with Linux**. Then open the **Terminal** app,
  click **penguin**, type this and press Enter:

  ```
  bash /mnt/chromeos/removable/*/OfflineLibrary/START-Linux.sh
  ```

## 🤖 Android tablet or phone

This takes about 10 minutes, **once**. You'll use **Termux**, a free app (a black screen where you
type short commands) that lets Android run the library.

**Before you start:** copy the whole **OfflineLibrary** folder onto the tablet's **SD card** (or
the tablet itself, if it has room), using a computer with a card reader or a USB cable.

1. **Install Termux.** In the tablet's **Files** app, open the library folder, then **Phone-Apps →
   Android-Termux**, and tap **Termux-….apk** (the app file). If Android asks, allow installing
   from this source, then tap **Install**.
2. **Copy START-Android.sh** (next to `START-HERE.html`) into the tablet's **Download** folder.
3. **Open Termux**, type this and press Enter. Tap **Allow** when Android asks.

   ```
   termux-setup-storage
   ```

4. Type this exactly and press Enter:

   ```
   bash /sdcard/Download/START-Android.sh
   ```

   It finds the library (this can take a minute), sets up the AI and Wikipedia search from the
   drive, and opens the library in your browser.
5. **Every time after that:** open Termux, type this and press Enter:

   ```
   library
   ```

Keep Termux open while you use the library; to stop, close it. **Tip:** in the browser, tap
**⋮ → Add to Home screen** for an icon. Devices with **4 GB of memory or more** also get an AI
that writes answers.

## 🍏 iPhone and iPad

Apple doesn't let iPhones run the Library Assistant, but an iPhone (6s or newer) can still use the
library:

**1. Use a library shared over Wi-Fi: everything, including the AI.** See
[Share one library with every phone nearby](#share-one-library-with-every-phone-nearby) below.

**2. Load the iPhone itself.** Do this **now, while you have internet** (the App Store won't work
later):

1. **Update** it: **Settings → General → Software Update**.
2. **Install** the free **Kiwix** (offline Wikipedia, medical and survival archives) and
   **OsmAnd** (offline maps) apps. *Optional:* **PocketPal AI**, an offline chat that can load the
   library's small AI (`AI-Offline/models/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf`). It chats, but
   doesn't search the books.
3. **Save the library website:** open it in Safari, tap **⚙️ Offline → Save library & guides**
   (and **Also save walking routes**), then **Share → Add to Home Screen**. Open it now and then
   so the iPhone keeps it.
4. **Copy files on** in the **Files** app, with the drive plugged in through a USB adapter (newer
   iPhones take USB-C). Or copy from a Mac (**Finder** → your iPhone → **Files**) or a Windows PC
   (**Apple Devices** app → **File Sharing**).
   - `.zim` files → **Kiwix** (the medical and survival ones are small)
   - maps from the `OsmAnd` folder → **OsmAnd** (tap a `.zip` in Files to unzip it first)
   - PDF books → **Files** (the whole `Southern-Oregon` folder is about 7 GB)

No room? Keep a small USB stick and adapter with the iPhone instead.

---

## 📡 Share one library with every phone nearby

One device runs the library, and **every phone, tablet and laptop nearby uses it in its web
browser**, iPhones included. No internet is needed, and the AI runs on the sharing device, so even
an old phone gets written answers.

**On the device with the library** (a laptop, Android tablet or Raspberry Pi):

1. Start the library as usual.
2. Click the **⚙️ Settings** tab. Under **📡 Share with phones nearby**, click **Turn on sharing**.
3. If Windows or the Mac asks whether to allow network access, click **Allow**.
4. Settings shows an address like **`http://192.168.43.1:8096`**. Write it down or tape it up.

**On each phone or tablet:**

1. Connect to the **same Wi-Fi** as the sharing device.
2. Open the web browser and type the address exactly.
3. For an icon, tap **Share → Add to Home Screen** (iPhone) or **⋮ → Add to Home screen** (Android).

**No Wi-Fi network?** Use an **Android phone's hotspot** (mobile data can stay off; iPhone
hotspots usually need a phone plan) or a **small USB-powered travel router**, the most reliable
choice for an emergency kit. A Raspberry Pi or Linux laptop can make its own Wi-Fi.

**Good to know:** anyone on that Wi-Fi can read the library, so put a password on the hotspot or
router. Only the sharing device can change settings, and the AI answers one person at a time. To
stop, click **Stop sharing** or close the library.

---

## 🗄️ Put old devices to work — set them up now

The best emergency computer is the one already in a drawer. Set it up while you have internet:

| Old device | What it can do |
|---|---|
| Windows laptop (Windows 10/11, 4 GB+ memory), or Chromebook with Linux turned on | Runs the library, or serves the household as a **sharing hub** |
| Mac (about 2017 or newer, macOS 11+) | Runs the library. **Intel Macs** need macOS 13.3+ for the AI's answers; on macOS 12 Monterey, search and Wikipedia still work |
| Android tablet or phone (Android 7+), Amazon Fire tablet | Runs the library with Termux (Fire tablets: usually) |
| Raspberry Pi 4/5 (64-bit) | A low-power, always-on **sharing hub** |
| iPhone, iPad, or any phone with a browser | Uses a **shared library** over Wi-Fi (iPhones: also Kiwix, OsmAnd and the saved website) |

Charge it, update it, copy the library on, and **try it once** with Wi-Fi off. Store spares in a
metal can (see the [EMP guide](guide:EMP-GUIDE)) at about half charge; top them up every few months.

---

## 🧠 Which AI will I get?

You don't have to choose. The assistant checks the device's memory, picks an AI size, **times a
test answer**, and steps down if it's too slow. To change it, open **⚙️ Settings**.

| Setting | Good for | How it answers |
|---|---|---|
| **Automatic** (recommended) | Any device | Picks the best one below for you |
| **Off — search only** | Any device, even very old ones | Lists the matching pages instantly |
| **Quick** | Phones, tablets, older laptops (4 GB+ memory) | Short, simple answers in about 30–60 seconds |
| **Standard** | Most laptops and good tablets (8 GB+) | Good answers in about a minute |
| **Smart** | Computers with 16 GB+ | Better answers, about 3 times slower |
| **Graphics card** | Gaming-type computers (6 GB+ graphics card) | Fast, good answers |

Times are rough; **search is always instant**. **Smart** and **Graphics card** need the large AI
models (on drives of about 64 GB or more).

---

## 🔧 If something goes wrong

| What you see | What to do |
|---|---|
| Windows: **Windows protected your PC** | Click **More info**, then **Run anyway** |
| Mac: **can't be opened**, or **unidentified developer** | **Apple menu → System Settings → Privacy & Security → Open Anyway** (older Macs: right-click → **Open** → **Open**) |
| The browser didn't open | Type the address shown in the black (or Terminal) window, like `http://127.0.0.1:8095/` |
| **The AI stopped on this device**, or answers take minutes | In **⚙️ Settings**, pick a smaller AI (**Quick**) or **Off** |
| Android: **Couldn't find the library** | Copy the *whole* library folder to the SD card or tablet, then try again |
| Android: Termux closes or the page stops | Keep Termux open; don't swipe it away |
| Wikipedia isn't searched | That device lacks the Wikipedia search program. Books and guides are still searched |
| A Mac or Android tablet won't open the drive | The drive should be **exFAT**. See [Get the whole library](guide:GET-THE-LIBRARY) |

---

## 🤝 Sharing it with your community

The more households that have this, the calmer things stay when the power and phones are out.

- **Copy it.** Copy the whole **OfflineLibrary** folder onto another USB stick, drive or SD card;
  the copy works just like the original. Use a drive formatted **exFAT** so every kind of device
  can open it (see [Get the whole library](guide:GET-THE-LIBRARY) to check or change it).
- **Or run the installer** ([Get the whole library](guide:GET-THE-LIBRARY)). It fills whatever
  drive you pick. On a **16 GB** stick it fits all the guides, the Illinois Valley books, the
  Library Assistant with a small AI for every kind of device, the medical encyclopedia and maps of
  Oregon. The full library (about 170 GB) needs a **256 GB** drive.
- **Hold a "library night."** Bring a laptop and blank USB sticks, copy the library for neighbors,
  and help each one try it on their own device.
- **Keep one copy safe** in a metal can with a charger and a small solar panel (see the
  [EMP guide](guide:EMP-GUIDE)).
- **Please don't sell it or post the books online.** It's free to share with family and
  neighbors, but some publishers ask that their free books not be re-posted.

*For helpers:* `community-kit.bat` (Windows) and `./get-offline-library.sh --community`
(Mac/Linux) make the smaller community kit (about 11 GB: guides, local books and the small AI)
with no questions.

---

## 🔗 Related guides

- [Get the whole library](guide:GET-THE-LIBRARY) — putting it on a USB drive
- [Start Here (Illinois Valley)](guide:ILLINOIS-VALLEY-START-HERE) — the one-page local quick reference
- [Use the Library on a Phone](guide:USE-ON-PHONE) — Kiwix and OsmAnd on phones and iPads
- [How to Run the Offline AI](guide:HOW-TO-RUN-OFFLINE-AI) — more about the AI models
- [EMP Guide](guide:EMP-GUIDE) — protecting a spare device in a Faraday cage
- [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) — organizing your neighbors
