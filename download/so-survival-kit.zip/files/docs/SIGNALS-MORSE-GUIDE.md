# 📡 Signals, Morse Code & Messages

How to get a message across with no phones and no working radio: learning Morse by ear, sending
it by lamp, whistle, flag or smoke, calling for help from the ground to an aircraft, mirrors and
signal fires (and their danger in fire season), semaphore, alarm codes, runners, message forms, a
neighborhood OK/HELP card plan, and what to listen to. The books are in `Comms-Signals\Morse-Code`,
`Comms-Signals\Visual-Sound-Signals` and `Comms-Signals\Messaging-Plans`. Radios: the
[Radio guide](guide:RADIO-GUIDE) and the `Radio-Weather` folder.

> ### ⚠️ Rules that prevent the worst outcomes
> - **Three of anything means "help"** — three fires, three blasts, three shots. Use threes for
>   nothing else ([FM 3-05.70, p. 318](lib:fm-3-05-70-survival-2002#page=318)).
> - **No signal fires or "tree torches" in fire season (roughly June–October).** In our dry
>   summers they can start a wildfire that kills the people signaling. Use a mirror, cloth panels,
>   ground symbols and sound instead.
> - **Learn only today's 5-symbol ground code:** **V** = need help, **X** = need *medical* help
>   ([Pub 102, p. 144](lib:pub-102#page=144); [🖼️ the five symbols drawn](lib:fm-3-05-70-survival-2002#page=329)).
>   An old Army code in the library uses X for "unable to proceed".
> - **Never hold a mirror flash on a pilot's cockpit** for more than a few seconds — it can blind
>   them ([FM 3-05.70, p. 324](lib:fm-3-05-70-survival-2002#page=324)).
> - **Learn Morse from the International table only.** The 1911 Scout handbook prints old
>   *American* Morse, different for many letters.
> - **Agree every alarm signal in advance**, and use the alarm bell or horn for nothing else
>   ([FM 24-5, p. 129](lib:fm-24-5-signal#page=129)).

---

## 👂 Learning Morse by ear

**Morse is sounds, not dots on paper.** Think of each letter as a sound ("di-dah" is A), never
count dots and dashes, and practice by whistling or saying the sounds aloud
([TM 11-459, pp. 3–5](lib:army-tm-11-459#page=3)).

**Two proven methods** ([Pierpont, pp. 159–161](lib:pierpont#page=159); [pp. 171–172](lib:pierpont#page=171)):
- **Koch method:** start with **two letters** sent fast (12 words per minute or more). Add **one new
  letter at a time**, and only when you copy **90%** correctly. Don't look at a chart.
- **Farnsworth method:** each letter is always sent at full speed (18–25 wpm), with **wide gaps
  between letters** that you close up as you improve.
- Both avoid the "10 wpm plateau" of learning slowly ([p. 161](lib:pierpont#page=161)).
- **Short sessions work best:** Koch recommended **two half-hour sessions a day**, spread apart;
  even 45 minutes gave less ([p. 160](lib:pierpont#page=160)).

**A 30-day plan** *(rule of thumb, built on Koch's rules)*. A partner sends from the table below by
whistle or flashlight while you write what you hear. If you fall behind, stretch the plan —
accuracy matters more than the calendar.

| Days | What to do (two half-hour sessions a day) |
|---|---|
| 1–2 | Two letters that sound very different, such as **K** and **M**, in random mixes, until you get 9 in 10. |
| 3–20 | Add **one letter** each time you reach 90% on a 5-minute mix. A common Koch order: K M R S U A P T L O W I N J E F Y V G Q Z H B C D X *(general practice)*. |
| 21–25 | Numbers, then period, comma, question mark and slash. Keep mixing in all the letters. |
| 26–28 | Procedure signals (AR, K, SK, BT, AS) and the calling routine below. Short real messages. |
| 29–30 | Whole messages with your partner, by lamp and by whistle, across a field. |

- **Send each letter at full speed, even as a beginner** — slow down only by leaving longer gaps
  between letters ([TM 11-459, p. 4](lib:army-tm-11-459#page=4)).
- **Look-alikes** (S/H, U/V, and mirror pairs like B/V, D/U) cause most errors — give the ones
  *you* miss extra practice ([Pierpont, p. 159](lib:pierpont#page=159)).
- **Copy behind:** at higher speeds, let a letter or two go by before writing
  ([TM 11-459, p. 5](lib:army-tm-11-459#page=5)).
- **After day 30**, ten minutes a day keeps the skill *(rule of thumb)*.

If you also learn to send on a hand key: [🖼️ the key and how to hold it](lib:army-tm-11-459#page=21);
[Telegraph key](wiki:Telegraph_key).

📚 **Go deeper:** [Pierpont](lib:pierpont#page=159) — the whole learning method; [TM 11-459](lib:army-tm-11-459#page=3) — the Army's sound-method lessons.

## 🔤 Morse quick reference (print this)

International Morse, from [Pub 102, p. 21](lib:pub-102#page=21) and
[ITU-R M.1677-1, pp. 4–5](lib:itu-r-m-1677#page=4). Read `.` as "di" (short) and `-` as "dah"
(long). Pictures and sound files: [Morse code](wiki:Morse_code). Printed charts:
[🖼️ Pub 102 Morse chart](lib:pub-102#page=21), [🖼️ Navy NEETS chart](lib:neets-module-12-modulation#page=48).

| Letter | Code | Letter | Code | Letter | Code | Letter | Code |
|---|---|---|---|---|---|---|---|
| A | `.-` | H | `....` | O | `---` | V | `...-` |
| B | `-...` | I | `..` | P | `.--.` | W | `.--` |
| C | `-.-.` | J | `.---` | Q | `--.-` | X | `-..-` |
| D | `-..` | K | `-.-` | R | `.-.` | Y | `-.--` |
| E | `.` | L | `.-..` | S | `...` | Z | `--..` |
| F | `..-.` | M | `--` | T | `-` | | |
| G | `--.` | N | `-.` | U | `..-` | | |

| Number | Code | Number | Code | Mark | Code |
|---|---|---|---|---|---|
| 1 | `.----` | 6 | `-....` | Period | `.-.-.-` |
| 2 | `..---` | 7 | `--...` | Comma | `--..--` |
| 3 | `...--` | 8 | `---..` | Question | `..--..` |
| 4 | `....-` | 9 | `----.` | Slash | `-..-.` |
| 5 | `.....` | 0 | `-----` | | |

**Procedure signals** — each is sent as **one run-together sound** with no gap
([ITU, p. 5](lib:itu-r-m-1677#page=5); [Pub 102, pp. 24–25, 140](lib:pub-102#page=24);
[Prosigns for Morse code](wiki:Prosigns_for_Morse_code)):

| Signal | Code | Means |
|---|---|---|
| **SOS** ([SOS](wiki:SOS)) | `...---...` | Distress |
| **AR** | `.-.-.` | End of message |
| **K** | `-.-` | Over — your turn to send |
| **BT** | `-...-` | Break between message parts |
| **SK** | `...-.-` | End of contact |
| **AS** | `.-...` | Wait |
| 8 dots | `........` | Error, I'll resend |
| **R** / **DE** / **CQ** | | Received / "this is" / calling all stations |

**Timing is everything** ([ITU, p. 5](lib:itu-r-m-1677#page=5); [Pub 102, p. 9](lib:pub-102#page=9)):
a dash is 3 dots long; the gap inside a letter is 1 dot, between letters 3 dots, between words 7
dots. With a lamp or horn, make dots a little *shorter* so they can't be mistaken for dashes. The
standard lamp speed is about 40 letters a minute.

![Timing diagram of the words AT ME in Morse as black bars on a ruler of dot lengths: dots 1 long, dashes 3, gaps of 1 inside a letter, 3 between letters and 7 between words](img:SIGNALS-MORSE-GUIDE/morse-timing.svg)
*AT ME as on-and-off time: a dash is 3 dots; the gaps are 1, 3 and 7 dots long (a diagram drawn for this guide).*

**How to call** ([ITU, p. 7](lib:itu-r-m-1677#page=7)): their call sign (no more than twice),
**DE**, your call sign, **K**. They answer the same way. End each message with **AR**; whoever sent
the last message ends the contact with **SK**. Without radio licenses, give each household a short
call sign — two letters is enough *(rule of thumb)*.

📚 **Go deeper:** [ITU-R M.1677-1](lib:itu-r-m-1677#page=4) — the official standard; [Pub 102](lib:pub-102#page=21) — tables and procedure; [NEETS 12, p. 48](lib:neets-module-12-modulation#page=48) — another Morse chart.

## 🔦 Morse without a radio: light, sound, flags and smoke

- **Light:** flashlight, lantern or car headlights, with a hat or board as a shutter. Short flash =
  dot, longer flash = dash ([Bluejackets, p. 442](lib:bluejackets#page=442)). Best at dusk and
  night. See [Signal lamp](wiki:Signal_lamp); aiming a lamp's beam at a far station:
  [🖼️ FM 24-5 drawing](lib:fm-24-5-signal#page=107).
- **Sound:** whistle, horn or bugle ([Whistle](wiki:Whistle), [Bugle](wiki:Bugle)) — short blast = dot, long blast = dash. On a drum, one tap = dot,
  two quick taps = dash. Sound works in fog and at night
  ([Signal Book 1916, p. 34](lib:signal-book-united-states-army#page=34)) but is **slow and easily
  confused** — keep to short, pre-agreed messages ([Pub 102, p. 17](lib:pub-102#page=17)).
- **Flags or arms:** call with **"AA AA AA"** and end with **AR**
  ([Pub 102, pp. 19–20](lib:pub-102#page=19)). The Army rule: flag swung to your **left for a
  dash**, to your **right for a dot** ([FM 3-05.70, p. 328](lib:fm-3-05-70-survival-2002#page=328)).
- **Smoke:** spread a blanket over a smoky fire and lift it off to send short and long puffs
  ([Seton, p. 270](lib:seton-the-book-of-woodcraft-1913#page=270)). **Not in fire season** — see the
  fire section below. See [Smoke signal](wiki:Smoke_signal).
- **Knocking through a wall:** Morse, or the 5×5-grid [tap code](wiki:Tap_code) *(general practice)*.

| If this goes wrong | Try this *(rule of thumb)* |
|---|---|
| Dots and dashes blur together | Very short dots, long dashes, clear gaps |
| They keep missing words | Lengthen the gaps, not the letters; send each word twice |
| Lamp can't be seen by day | Use a mirror or a flag |

📚 **Go deeper:** [Pub 102, pp. 17–20](lib:pub-102#page=17) — sound, flag and arm signaling; [Signal Book 1916, p. 34](lib:signal-book-united-states-army#page=34) — whistle and drum codes.

## 🆘 Distress signals and talking to aircraft

- **Threes:** three fires, three columns of smoke, three shots or three whistle blasts mean distress,
  because nature rarely makes things in threes
  ([FM 3-05.70, p. 318](lib:fm-3-05-70-survival-2002#page=318);
  [AFH 10-644, p. 509](lib:afh-10-644#page=509)).
- **SOS** by light, sound or flag: three short, three long, three short, sent as one sound and
  repeated ([FM 3-05.70, p. 328](lib:fm-3-05-70-survival-2002#page=328)).
- **A flag flown upside down** signals distress ([Signal Book 1916, p. 41](lib:signal-book-united-states-army#page=41)).

**Body signals to aircraft** — stand in the open, move slowly and repeat until understood
([FM 21-60, p. 59](lib:fm-21-60#page=59); [🖼️ the signals drawn](lib:fm-3-05-70-survival-2002#page=330)):

| Signal | Means |
|---|---|
| Both arms straight up | "Pick us up" |
| One arm up | "All OK, do not wait" — easy to confuse with the one above, so be deliberate |
| Lying on your back, arms stretched overhead | "Need medical assistance" |
| Arms waving, crossed overhead | "Do not land here" |
| Cloth waved up and down / side to side | Yes / No |
| Arms out to the sides, slowly raised and lowered again and again | Official distress signal ([Pub 102, p. 140](lib:pub-102#page=140)) |

![Eleven small drawings of a person signaling to an aircraft with arms and body, each labeled with its meaning, such as Pick us up, All OK do not wait, and Need medical assistance urgently](img:SIGNALS-MORSE-GUIDE/body-signals-to-aircraft.png)
*Body signals to a pilot, each with its meaning; face the aircraft in the open and move slowly ([FM 3-05.70, p. 330](lib:fm-3-05-70-survival-2002#page=330)).*

**How a plane says "understood"** ([Pub 102, p. 144](lib:pub-102#page=144);
[AFH 10-644, p. 518](lib:afh-10-644#page=518)): it **rocks its wings** by day, or **flashes its
landing or navigation lights twice** at night (or flashes Morse T or R). **Not understood:** it flies
straight and level without rocking, or flashes RPT
([🖼️ aircraft replies drawn](lib:afh-10-644#page=518); [Search and rescue](wiki:Search_and_rescue)).

📚 **Go deeper:** [FM 21-60, p. 59](lib:fm-21-60#page=59) — body signals drawn; [Pub 102, p. 140](lib:pub-102#page=140) — official distress signals; [Distress signal](wiki:Distress_signal).

## ✖️ Ground-to-air symbols (print this)

The code in use worldwide today has **five symbols** (ICAO)
([Pub 102, p. 144](lib:pub-102#page=144); [AFH 10-644, p. 516](lib:afh-10-644#page=516);
[FM 3-05.70, p. 329](lib:fm-3-05-70-survival-2002#page=329)). See them laid out:
[🖼️ FM 3-05.70 drawing](lib:fm-3-05-70-survival-2002#page=329), [🖼️ Pub 102 chart](lib:pub-102#page=144):

| Symbol | Means |
|---|---|
| **V** | Require assistance |
| **X** | Require **medical** assistance |
| **N** | No |
| **Y** | Yes |
| **↑** (arrow) | Proceeding in this direction |

**Making them seen** ([AFH 10-644, pp. 514–517](lib:afh-10-644#page=514)):
1. **Big:** lines at least **3 ft wide and 18 ft long**, bigger if you can, about a 2:3 shape
   ([🖼️ size drawing](lib:afh-10-644#page=515)). The
   Army manuals disagree (4 m × 6 m in
   [FM 3-05.70, p. 329](lib:fm-3-05-70-survival-2002#page=329); 1 m × 6 m in
   [FM 21-76, p. 243](lib:fm-21-76-army-survival-manual#page=243)) — **bigger is always better**.
2. **Straight lines and square corners** — nature has none.
3. **Contrast:** outline it with green boughs, rocks or brush so it casts shadows. Orange cloth
   vanishes against green or brown ([🖼️ contrast example](lib:afh-10-644#page=516)).
4. **One path in and out**, so you don't scuff it.
5. **High, open ground** seen from every side — a field, a river gravel bar, a logged ridge
   *(local examples: rule of thumb)*.
6. **A cloth banner on a pole** catches the eye and shows a pilot the wind
   ([🖼️ pennants and banners](lib:afh-10-644#page=518)).

![Diagram of an L-shaped ground symbol with sizes: each line 3 ft wide and 18 ft long, the symbol 27 ft tall, ratio 1 to 6](img:SIGNALS-MORSE-GUIDE/ground-symbol-sizes.png)
*Sizes for a ground symbol: each line 3 ft wide and 18 ft long (1 to 6), the whole symbol about 18 by 27 ft ([AFH 10-644, p. 515](lib:afh-10-644#page=515)).*

⚠️ **Don't mix codes.** The older 18-symbol Army code
([FM 21-60, p. 60](lib:fm-21-60#page=60)) gives X a different meaning. Teach only the five above.

📚 **Go deeper:** [AFH 10-644, ch. 21](lib:afh-10-644#page=514) — size, contrast and placement with photos; [FM 3-05.70, p. 329](lib:fm-3-05-70-survival-2002#page=329) — the five symbols drawn.

## 🪞 Signal mirrors

**The best daytime signal.** A mirror flash has been seen up to **100 miles** away and it works even
on hazy or overcast days ([AFH 10-644, p. 509](lib:afh-10-644#page=509)). See
[Signal mirror](wiki:Signalling_mirror).

**Aiming without a sighting hole** ([AFH 10-644, pp. 510–511](lib:afh-10-644#page=510)):
1. Hold one arm out and make a **V with two fingers**, with the plane or distant hill in the V
   ([🖼️ drawing](lib:afh-10-644#page=510); [🖼️ FM 3-05.70 drawing](lib:fm-3-05-70-survival-2002#page=324)).
2. Tilt the mirror so the bright spot of light lands on your fingers, then work it **through the V**
   onto the target.
3. Or line the target up with the top of a **4–5 ft stake**, and sight along the mirror's top edge
   onto the stake top ([🖼️ drawing](lib:afh-10-644#page=511)).
4. **Keep sweeping the horizon** even when nothing is in sight — a pilot may see you first.

![Drawing of a person flashing a mirror at a helicopter, sighting over the top of a stake that lines up with the aircraft](img:SIGNALS-MORSE-GUIDE/mirror-aiming-stake.png)
*Aiming with a stake (step 3): line the stake top up with the aircraft, then tilt the mirror until the flash lands on the stake top ([AFH 10-644, p. 511](lib:afh-10-644#page=511)).*

- **No mirror?** A can lid, polished metal, foil or a shiny card will do
  ([p. 510](lib:afh-10-644#page=510)). The military mirror with a sighting hole, for comparison:
  [🖼️ the MK-3 signal mirror](lib:fm-3-05-70-survival-2002#page=323).
- **Don't flash rapidly**, and don't hold the beam on the cockpit for more than a few seconds — it
  can blind the pilot ([FM 3-05.70, p. 324](lib:fm-3-05-70-survival-2002#page=324)).
- **Talking with mirrors:** the old Army [heliograph](wiki:Heliograph) flashed Morse by mirror
  between hilltops; two people on sunny ridges can do the same *(general practice)*.

📚 **Go deeper:** [AFH 10-644, pp. 509–511](lib:afh-10-644#page=509) — mirror aiming with pictures; [Signal Book 1916](lib:signal-book-united-states-army) — the heliograph and lantern.

## 🔥 Signal fires and smoke — and the wildfire danger

**What the manuals teach** ([AFH 10-644, pp. 511–512](lib:afh-10-644#page=511)):
- **Three fires** in a triangle or a line. AFH 10-644 says about **100 ft apart**; FM 3-05.70 says
  25 m (83 ft) ([p. 318](lib:fm-3-05-70-survival-2002#page=318)). Bright flames at night, lots of
  smoke by day.
- **Smoke** works best on calm, clear days and has been seen up to **50 miles** away.
- **White smoke** (green leaves, moss, wet plants) shows against dark forest. **Black smoke**
  (rubber, oily rags, plastic) shows against snow or sky — stay upwind of it *(general practice)*.
- **Lay the fires before aircraft come**, ready to light in seconds.

> **⚠️ Illinois Valley: June to October, do NOT build signal fires.**
> - Only about 15% of our yearly rain falls April to September, and summer afternoon humidity runs
>   25–30% ([NRCS soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)).
>   A tree torch or a spark can start a wildfire that **kills the people signaling**
>   ([Wildfire](wiki:Wildfire)).
> - Clearing to bare earth under a tree torch, as the manuals say, is not enough in our brush and
>   grass ([AFH 10-644, p. 513](lib:afh-10-644#page=513); [FM 3-05.70, p. 319](lib:fm-3-05-70-survival-2002#page=319)).
> - **A gasoline smoke pot can explode** when lit ([AFH 10-644, p. 514](lib:afh-10-644#page=514)).
>   Pen flares and tracer rounds start fires too ([FM 3-05.70, p. 321](lib:fm-3-05-70-survival-2002#page=321)).
> - **In fire season use:** mirror, cloth panels and ground symbols, a banner on a pole, whistles
>   and horns.
> - **If you must burn** (wet season, or truly no choice): a small fire on a cleared, wetted patch,
>   with water, a shovel and a person watching it, put dead out afterward *(general practice)*.

📚 **Go deeper:** [AFH 10-644, pp. 511–514](lib:afh-10-644#page=511) — fire and smoke signals; [Firewood guide](guide:FIREWOOD-GUIDE) — ashes and fire-season burning rules.

## 🚩 Flags, semaphore and signal stations

**Simple flag colors** ([FM 21-60, p. 37](lib:fm-21-60#page=37); [🖼️ Army flag signals drawn](lib:fm-21-60#page=38)): **red** = danger; **green** = all
clear / understood; **yellow** = disregard. At night use colored flashlights. Good for a gate or a
lookout.

**Semaphore** spells words with two flags (or bare arms) held at clock positions — by day and in
sight only. Pictures:
[Bluejackets Manual, pp. 444–447](lib:bluejackets#page=444) and [Flag semaphore](wiki:Flag_semaphore);
full charts: [🖼️ Bluejackets alphabet](lib:bluejackets#page=445),
[🖼️ Signal Book 1916 hand-flag chart](lib:signal-book-united-states-army#page=26),
[🖼️ FM 24-5 semaphore code](lib:fm-24-5-signal#page=115).
- Letters **A to G** use one arm stepping around a circle
  ([Scout Handbook 1911, p. 234](lib:boy-scouts-handbook#page=234)).
- After the **numeral sign**, A–I mean 1–9 and K means 0.
- **Always face the receiving station.** The receiver stops the sender by holding both arms
  straight out sideways ([Signal Book 1916, pp. 22–23](lib:signal-book-united-states-army#page=22)).

**Siting a flag or lamp station** ([Signal Book 1916, pp. 43–44](lib:signal-book-united-states-army#page=43)):
- Stand where the background behind you, as the other station sees it, is **one plain color**. Use a
  **white flag** against green or dark hillsides.
- Record the **compass bearing** to each partner station and drive two aiming stakes in line with it
  ([Compass](wiki:Compass)).
- **How far you can see** to a ground-level object: eye 10 ft up, about 4 miles; 30 ft, about 7;
  100 ft, about 13. Ridges around the valley make good relay points ([Horizon](wiki:Horizon)).

📚 **Go deeper:** [Bluejackets, p. 444](lib:bluejackets#page=444) — semaphore drawn; [Signal Book 1916](lib:signal-book-united-states-army#page=22) — semaphore and station siting; [FM 21-60](lib:fm-21-60) — arm-and-hand signals.

## 📣 Whistles, bells and alarm codes

- **Range:** most whistle or shout contacts happen **within 200 yards**, a few at about a mile.
  A pole banged on a hollow log also carries ([AFH 10-644, p. 509](lib:afh-10-644#page=509)).
- **Rapid strokes** of a bell, horn or whistle = **"general alarm — act now"**, no answer needed
  ([Signal Book 1916, p. 38](lib:signal-book-united-states-army#page=38)).
- **Every alarm must be agreed in advance, known to everyone, and used only with good cause**
  (same page). A bell, siren or air horn kept for alarms is **never used for anything else**
  ([FM 24-5, p. 129](lib:fm-24-5-signal#page=129); [Air horn](wiki:Air_horn), [Siren](wiki:Siren_(alarm))). Visual signals get misunderstood — standardize
  and practice them ([FM 21-60, p. 5](lib:fm-21-60#page=5)).
- **The 1911 Scout whistle code** is a good start: one long blast = "attention, look out for my next
  signal"; two short = "all right"; a string of short, sharp blasts = "rally, danger, alarm"
  ([Scout Handbook 1911, p. 236](lib:boy-scouts-handbook#page=236)).

**Make a household/neighborhood signal card** *(rule of thumb — fill in your own and post it)*:

| Signal | Means | Answer |
|---|---|---|
| 3 blasts, repeated | I need help — come to me | 2 short blasts: "heard you, coming" |
| String of short, sharp blasts / rapid bell | General alarm (fire, intruders) — act on the plan | None needed |
| Red cloth on the gate | Danger, don't come in | |
| Green cloth on the gate | All clear | |

📚 **Go deeper:** [Signal Book 1916, pp. 38–41](lib:signal-book-united-states-army#page=38) — alarm and distress signals; [FM 24-5, p. 129](lib:fm-24-5-signal#page=129) — alarm devices.

## 🏃 Runners, relays and written messages

**Briefing a runner** ([FM 24-5 (1939), pp. 68, 70](lib:fm-24-5-signal#page=68)) — tell them:
- who the message is for and where to find them;
- which route, and which danger spots to avoid;
- how fast to go, and whether to wait for a reply;
- where to report back, and what to do if it can't be delivered.

**Spoken messages must be short.** The runner repeats it back to you and memorizes it
([p. 70](lib:fm-24-5-signal#page=70)). **Write it down whenever you can.**

**Speeds and relays** ([FM 24-5, pp. 69, 71–72](lib:fm-24-5-signal#page=69)): a runner covers about
**3 mph** routine and **5 mph** priority (urgent: as fast as they can and still arrive); a rider
6 and 8 mph. On dangerous routes send **two runners**
in sight of each other, each with a copy, or use two routes. Mark routes with arrows at forks. For
long, frequent runs, set up **relay posts** — say, a house halfway to O'Brien *(rule of thumb)*.

**Use a standard form.** The **ICS 213** has To, From, Subject, Date, Time (24-hour clock), Message,
Approved by, Reply and Replied by. The sender keeps a copy; the reply comes back on the bottom
([ICS Forms Booklet, pp. 65–66](lib:nims-ics-forms#page=65); [🖼️ the blank form](lib:nims-ics-forms#page=65);
[Incident Command System](wiki:Incident_Command_System)). Log every message and
event with date and time on an **ICS 214** activity log ([p. 68](lib:nims-ics-forms#page=68)).

**The ham "radiogram" works on paper too** ([ARRL manual, p. 34](lib:arrl-ares-field-resources-manual#page=34)):
**number and precedence**, **address**, **text of 25 words or fewer** (X for a period), and
**signature**. The "check" is the word count, so the receiver knows nothing was lost
([🖼️ a filled-in example, part by part](lib:arrl-ares-field-resources-manual#page=35)).

**Precedence** ([ARRL, p. 36](lib:arrl-ares-field-resources-manual#page=36)): **EMERGENCY** (life or
death — when in doubt, don't) → **PRIORITY** → **WELFARE** → **ROUTINE**.

**Short codes save time:**
- "ARL ONE" = "Everyone safe here. Please don't worry." "ARL TWO" = "Coming home as soon as possible."
  ([ARRL, p. 39](lib:arrl-ares-field-resources-manual#page=39)).
- One-letter signals you can flash or sound: **V** = I need assistance; **W** = I need medical
  assistance; **K** = I wish to communicate; **N** = no; **C** = yes
  ([Pub 102, p. 26](lib:pub-102#page=26)). Note: at sea **W** means medical help; on the ground the
  symbol is **X**. See [International Code of Signals](wiki:International_Code_of_Signals); the same
  letters as ship flags: [International maritime signal flags](wiki:International_maritime_signal_flags).

📚 **Go deeper:** [FM 24-5 (1939)](lib:fm-24-5-signal#page=68) — messengers, relay posts and a message center; [ICS Forms Booklet](lib:nims-ics-forms#page=65) — print blank 213 and 214 forms now; [ARRL manual, pp. 33–39](lib:arrl-ares-field-resources-manual#page=34) — radiogram form and numbered texts.

## 🏘️ The neighborhood OK/HELP plan

From the rural edition of **Map Your Neighborhood**
([MYN Rural, pp. 1–2](lib:map-your-neighborhood-in-rural#page=1)):
1. **Pick a Neighborhood Communication Site** everyone knows: a mailbox cluster, a crossroads, or a
   central home or barn.
2. After a disaster, each household takes its **OK/HELP card** there with **name, date and time**,
   plus the kind of help needed, and tapes it up.
3. Anyone who can help writes on the card **what they'll do and when**, then reports back.
4. Someone **checks every home**.

**Who to check first** ([MYN Discussion Guide, p. 8](lib:map-your-neighborhood-discussion#page=8)):
**HELP** homes, then homes with **no card** — people there may be hurt. Then recheck the OK homes.
Print the [HELP/OK window card](lib:map-your-neighborhood-help-ok) now
([🖼️ what it looks like](lib:map-your-neighborhood-help-ok#page=1)).

**Your household plan:** a meeting place, a way to find each other if separated, and an out-of-area
contact, posted at home ([Oregon 2 Weeks Ready, p. 6](lib:oregon-be-2-weeks-ready-complete-toolkit#page=6);
[FEMA, p. 18](lib:fema-are-you-ready-citizen-preparedness-guide-2020#page=18)). Add the
neighborhood site, your signal card and a check-in time *(rule of thumb)*.

**Locally:** the county plan counts on door-to-door notice, broadcast stations and amateur radio, and
the RVCOG Disaster Registry lists residents needing special help
([County EOP, p. 71](lib:josephine-county-emergency-operations-plan-2025#page=71)). Know who they
are on your road.

📚 **Go deeper:** [MYN Discussion Guide](lib:map-your-neighborhood-discussion#page=8) — the first meeting, 9 steps after a disaster, neighbor map; [MYN Rural](lib:map-your-neighborhood-in-rural#page=1) — rural sites, wells and propane.

## 📻 Listening when you can't transmit

- **NOAA Weather Radio** repeats its message every 4–6 minutes; a **SAME** radio wakes up only for
  your county ([NOAA brochure, p. 2](lib:noaa-weather-radio-all-hazards-brochure#page=2);
  [NOAA Weather Radio](wiki:NOAA_Weather_Radio); [Specific Area Message Encoding](wiki:Specific_Area_Message_Encoding);
  [Emergency Alert System](wiki:Emergency_Alert_System)). For Josephine County program **SAME 041033** and
  try **WXL85, 162.400 MHz** (Medford). It officially covers *eastern* Josephine County, and
  **mountain valleys may get poor reception** — also try 162.475 and 162.550 and note which
  works at home ([NOAA brochure, p. 3](lib:noaa-weather-radio-all-hazards-brochure#page=3);
  [Illinois Valley guide](guide:ILLINOIS-VALLEY-START-HERE)).
- **AM reaches farther at night:** the layer of the sky that soaks up AM signals by day fades after
  dark ([Navy *Basic Electronics*, p. 328](lib:navy-basic-electronics-navpers-10087-a-1962#page=328);
  [🖼️ layers of the ionosphere](lib:neets-module-10-wave-propagation-transmission-lines-and-antennas#page=100);
  [Skywave](wiki:Skywave)).
  Listen for outside news after sunset.
- **Keep every battery radio in the shelter.** Small AM sets with built-in antennas are the most
  likely to survive an EMP ([*Nuclear War Survival Skills*, p. 35](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=35)).
- **Log what you hear** (time, station, message) and post news at the Neighborhood Communication
  Site, so one radio serves the whole road *(rule of thumb)*.

📚 **Go deeper:** [NOAA Weather Radio brochure](lib:noaa-weather-radio-all-hazards-brochure#page=2) — how SAME alerts work; [Radio guide](guide:RADIO-GUIDE) — shortwave, crystal sets and local frequencies.

## ⚠️ Old advice in the library to ignore

| Book and page | What it says | Do this instead |
|---|---|---|
| [Scout Handbook 1911, p. 230](lib:boy-scouts-handbook#page=230) | Morse chart | It is **American (railroad) Morse**, different for many letters. Use the International table above. |
| [Scout Handbook 1911, p. 232](lib:boy-scouts-handbook#page=232); [Seton, p. 132](lib:seton-the-book-of-woodcraft-1913#page=132) | Myer "wigwag" flag code | Obsolete. Use Morse by flag (left = dash, right = dot) or semaphore. |
| [Signal Book 1916, p. 37](lib:signal-book-united-states-army#page=37) | Phonetic alphabet "Able, Boy…" | Use the NATO alphabet (Alpha, Bravo…) in the [Radio guide](guide:RADIO-GUIDE). |
| [Seton, p. 271](lib:seton-the-book-of-woodcraft-1913#page=271) | Two smokes = "I am lost"; **three smokes = "good news"**; a two-shot/one-shot hunters' code | Today **three of anything = distress**. |
| [FM 21-60, p. 60](lib:fm-21-60#page=60) | 18-symbol ground code; **X = "unable to proceed"** | Use the 5-symbol code: **X = need medical help**. |
| [FM 3-05.70, p. 328](lib:fm-3-05-70-survival-2002#page=328) | Whistle heard "1.6 km (3/4 mile)" | 1.6 km is 1 mile, not 3/4. Plan on 200 yards. |
| [AFH 10-644, pp. 513–514](lib:afh-10-644#page=513); [FM 3-05.70, pp. 319, 321](lib:fm-3-05-70-survival-2002#page=319) | Tree torches, gasoline smoke pots, pen flares, tracer rounds | Fire and explosion hazards. Never in fire season. |

📚 **Go deeper:** [Pub 102](lib:pub-102#page=140) — today's international distress signals; [AFH 10-644](lib:afh-10-644#page=509) — the modern survival-signaling chapter.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Morse code**
- International Morse charts — [🖼️ Pub 102, p. 21](lib:pub-102#page=21); [🖼️ NEETS 12, p. 48](lib:neets-module-12-modulation#page=48); [Morse code](wiki:Morse_code)
- Procedure signals and SOS — [Prosigns for Morse code](wiki:Prosigns_for_Morse_code); [SOS](wiki:SOS)
- A hand key and how to hold it — [🖼️ TM 11-459, p. 21](lib:army-tm-11-459#page=21); [Telegraph key](wiki:Telegraph_key)

**Light, sound and smoke**
- Signal lamps and aiming the beam — [🖼️ FM 24-5, p. 107](lib:fm-24-5-signal#page=107); [Signal lamp](wiki:Signal_lamp)
- Whistles, bugles and horns — [Whistle](wiki:Whistle); [Bugle](wiki:Bugle); [Air horn](wiki:Air_horn)
- Smoke and tap codes — [Smoke signal](wiki:Smoke_signal); [Tap code](wiki:Tap_code)

**Talking to aircraft**
- Body signals — [🖼️ FM 3-05.70, p. 330](lib:fm-3-05-70-survival-2002#page=330); [🖼️ FM 21-60, p. 59](lib:fm-21-60#page=59)
- How a plane answers — [🖼️ AFH 10-644, p. 518](lib:afh-10-644#page=518); [🖼️ FM 3-05.70, p. 333](lib:fm-3-05-70-survival-2002#page=333)
- The five ground-to-air symbols — [🖼️ FM 3-05.70, p. 329](lib:fm-3-05-70-survival-2002#page=329); [🖼️ Pub 102, p. 144](lib:pub-102#page=144); [🖼️ AFH 10-644, p. 516](lib:afh-10-644#page=516)
- Making symbols big and easy to see — [🖼️ sizes, AFH 10-644, p. 515](lib:afh-10-644#page=515); [🖼️ contrast, p. 516](lib:afh-10-644#page=516); [🖼️ banners, p. 518](lib:afh-10-644#page=518)
- Distress signals and rescue — [Distress signal](wiki:Distress_signal); [Search and rescue](wiki:Search_and_rescue)

**Signal mirrors**
- Aiming through a V of fingers — [🖼️ AFH 10-644, p. 510](lib:afh-10-644#page=510); [🖼️ FM 3-05.70, p. 324](lib:fm-3-05-70-survival-2002#page=324)
- Aiming with a stake — [🖼️ AFH 10-644, p. 511](lib:afh-10-644#page=511)
- The MK-3 sighting mirror — [🖼️ FM 3-05.70, p. 323](lib:fm-3-05-70-survival-2002#page=323); [Signal mirror](wiki:Signalling_mirror)
- Mirror Morse between hilltops — [Heliograph](wiki:Heliograph)

**Flags and semaphore**
- Army flag signals — [🖼️ FM 21-60, p. 38](lib:fm-21-60#page=38)
- Semaphore alphabet charts — [🖼️ Bluejackets, p. 445](lib:bluejackets#page=445); [🖼️ Signal Book 1916, p. 26](lib:signal-book-united-states-army#page=26); [🖼️ FM 24-5, p. 115](lib:fm-24-5-signal#page=115); [Flag semaphore](wiki:Flag_semaphore)
- Ship letter flags — [International maritime signal flags](wiki:International_maritime_signal_flags)

**Messages and neighbors**
- ICS 213 message form — [🖼️ ICS Forms Booklet, p. 65](lib:nims-ics-forms#page=65); [Incident Command System](wiki:Incident_Command_System)
- Radiogram, filled in — [🖼️ ARRL manual, p. 35](lib:arrl-ares-field-resources-manual#page=35)
- HELP/OK window card — [🖼️ Map Your Neighborhood card](lib:map-your-neighborhood-help-ok#page=1)
- Weather-radio alerts — [NOAA Weather Radio](wiki:NOAA_Weather_Radio); [Specific Area Message Encoding](wiki:Specific_Area_Message_Encoding)

## 🔗 Related guides

- [Radio guide](guide:RADIO-GUIDE) — ham, GMRS, CB and shortwave; voice distress calls and the NATO alphabet
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local weather-radio stations, repeaters, nets and evacuation levels
- [Navigation and weather guide](guide:NAVIGATION-WEATHER-GUIDE) — compass bearings to signal stations, reading the weather before a trip
- [Community and barter guide](guide:COMMUNITY-BARTER-GUIDE) — organizing the neighbors who share your signal plan
- [Field care guide](guide:FIELD-CARE-GUIDE) — what to do while help is on the way
- [EMP guide](guide:EMP-GUIDE) — keeping radios and lights working
- [Firewood guide](guide:FIREWOOD-GUIDE) — fire-season burning and ash rules
- [On Foot: backpacking and travel](guide:ON-FOOT-GUIDE) — how much to carry, packs, feet and blisters, water and food on the move, camps, river crossings and safety on the road.
