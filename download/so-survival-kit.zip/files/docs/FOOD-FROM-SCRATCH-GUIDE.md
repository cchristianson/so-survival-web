# 🌾 Food From Scratch

How to make staple ingredients — flour, masa, leavening, salt, sweetener, fat — from what grows
or can be raised around the Illinois Valley, and how to turn them into bread, tortillas, pasta,
crackers and other everyday food. Details and more recipes are in `Food-From-Scratch\`
(grain, wild and local staples, breads and staples) and `Gardening-Food\`. The links open each
book on the drive at the right page.

> ⚠️ **Two foods here can kill if you get them wrong:** **camas** has a deadly look-alike
> (death camas), and **acorns and lye/ash-cooked corn** must be processed properly. Follow the
> steps exactly, and never eat a wild plant you can't identify with certainty.

---

## 🗓️ The year at a glance

| When | What to gather or make | Source |
|---|---|---|
| Spring | Cattail shoots, 4–16 inches long | [Cattail guide, p. 1](lib:broadleaf-cattail-plant-guide-usda-nrcs#page=1) |
| April–May | Death camas blooms ([🖼️ what it looks like](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2)) — watch and mark your camas bed now | [PNW 104, p. 1](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=1) |
| Mid-April | Plant corn and potatoes (Rogue Valley advice — our valley floor frosts later; see the Start Here frost table) | [OSU EM 9027, p. 22](lib:osu-growing-your-own-practical-guide-to-gardening-in-oregon-em-9027#page=22) |
| June–July | [Hazelnuts](wiki:Corylus_cornuta) — pick before the bears do | [Hupa, p. 39](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=39) |
| Summer | Grain harvest; dig camas after it flowers | [SARE](lib:home-grain-harvest-threshing-and-winnowing-sare#page=1); [Camas, p. 1](lib:great-camas-plant-guide-usda-nrcs#page=1) |
| Late Sept–Nov | Acorns (the second fall); sugar pine nuts; bay nuts | [UCCE, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2); [Hupa, p. 40](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=40) |
| Cool months | Butcher and render (raw fat keeps only 5–7 days even chilled) | [Minnesota, p. 2](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=2) |
| Leaf drop → bud break | Tap bigleaf maples on freeze–thaw days ([🖼️ how to tap](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=4)) | [OSU EM 9163, p. 3](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=3) |

📚 **Go deeper:** [OSU *Growing Your Own*, p. 21](lib:osu-growing-your-own-practical-guide-to-gardening-in-oregon-em-9027#page=21) — gardening in southern Oregon; [*Food Plants of the North American Indians*](lib:food-plants-of-the-north-american-indians-usda-misc-pub-237-1936#page=6) — 1,112 native food plants and how each was prepared.

## 🌾 Flour from grain

- **Grow hulless varieties** of oats and barley if you can — hulled types need dehulling.
  Wheat and corn are the easiest staples to grow and grind. Winter grains are sown in fall and cut
  the next summer: ¼–½ inch deep, about 1 foot apart each way
  ([SARE, p. 2](lib:home-grain-harvest-threshing-and-winnowing-sare#page=2)).
- **Harvest** when the heads are fully tan and nodding and the kernels are too hard to dent
  with a fingernail. Cut about 10 inches below the heads.
- **[Thresh](wiki:Threshing)** by stomping the heads in a clean bin or on a tarp ([🖼️ a threshing box](lib:seed-processing-and-storage-principles-and-practices-mccormack-2010#page=4)); **[winnow](wiki:Winnowing)** by
  pouring the grain slowly in front of a fan (or in a breeze) so the chaff blows away. Repeat.
  ([SARE handout, p. 1](lib:home-grain-harvest-threshing-and-winnowing-sare#page=1))
- **Dry to 12–13% moisture before storing** — wetter grain heats, molds and draws insects. Field
  test: a dry kernel resists your thumbnail and **cracks sharply between your teeth**.
  ([Peace Corps *Small Farm Grain Storage*, p. 55](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=55))
  If you dry it with heat, keep eating grain below **140 °F** and seed grain below **113 °F**
  ([p. 53](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=53)).
- **Store whole grain, grind as needed.** Whole grain keeps for years; flour goes rancid within
  months once milled. A hand grain mill ([🖼️ drawing](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=17); [🖼️ a homemade pipe grinder](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=83)) is worth owning; otherwise grind between two stones (a
  [quern](wiki:Quern-stone): a turning top stone on a fixed bottom one) and sift out the bran
  ([*Shifts and Expedients*, p. 519](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=519)).
- **Kill pests in stored grain:** freeze small bags 2–3 days, or heat a ½-inch layer at
  140–150 °F for 30 minutes (may weaken bread rise). Store airtight, and only when dry.
  ([USU *Food Storage in the Home*, p. 14](lib:food-storage-in-the-home-grain-insect-control-usu#page=14); [🖼️ the common grain pests, FAO p. 78](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=78); [rice weevil](wiki:Rice_weevil))
- **A sealed, full container kills bugs on its own** — they use up the oxygen. Keep the grain you
  dip into daily in a separate small container ([Peace Corps, p. 279](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=279)).

**Best-quality rotation times** (sealed, about 70 °F; a 90 °F shed roughly halves them —
[USU, pp. 11, 17–19](lib:food-storage-in-the-home-grain-insect-control-usu#page=17)): whole wheat
kernels 25 years · white flour 1 year · cornmeal 1 year · dry beans 1 year · **whole-wheat flour
only 2 weeks**. USU says these are for rotating stock, not how long food stays usable; dry beans and rice
packed with oxygen absorbers keep for decades ([Food Security guide](guide:FOOD-SECURITY-GUIDE)).

| If this goes wrong | Fix |
|---|---|
| Grain feels warm or smells musty | Too wet — spread it and dry it now; by the time you feel heat you're late ([Peace Corps, p. 54](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=54)) |
| Bugs after freezing | Thaw a sample on a tray; if anything crawls, freeze again ([USU, p. 14](lib:food-storage-in-the-home-grain-insect-control-usu#page=14)) |
| "Bay leaves didn't work" | They don't — only clean, dry grain in tight containers stays bug-free ([USU, p. 15](lib:food-storage-in-the-home-grain-insect-control-usu#page=15)) |

📚 **Go deeper:** [Peace Corps *Small Farm Grain Storage*, p. 278](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=278) — drying, airtight storage and insects in depth; [USU *Food Storage in the Home*, p. 13](lib:food-storage-in-the-home-grain-insect-control-usu#page=13) — pest treatments and storage times; [FAO *Barley*, p. 63](lib:barley-post-harvest-operations-and-recipes-fao#page=63) — barley breads and dishes.

## 🌰 Acorn flour

Our oaks — **[tanoak](wiki:Notholithocarpus)** (the traditional favorite), **[California black
oak](wiki:Quercus_kelloggii)**, **[Oregon white oak](wiki:Quercus_garryana)** and [canyon live
oak](wiki:Quercus_chrysolepis) ([🖼️ tanoak photo](lib:tanoak-plant-guide-usda-nrcs#page=1); [🖼️ oak and acorn drawing](lib:fm-3-05-70-survival-2002#page=449)) — all make good flour, but **every [acorn](wiki:Acorn) must be leached** to remove
bitter tannins. A tanoak can drop over 200 pounds in a good year and bears some crop every year
([NRCS Tanoak, p. 1](lib:tanoak-plant-guide-usda-nrcs#page=1)).

1. **Gather the second fall** (late September–October); the first acorns down are mostly wormy.
   Dry them 2–5 days in the sun or 20 minutes in a 175 °F oven, door ajar. Whole, dry acorns
   keep **several years** — in sacks or jars, not plastic.
   ([UCCE, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2))
2. Crack and shell them, and remove any moldy or wormy ones. Grind the nutmeats to a coarse meal
   or flour.
3. **Leach** — any one of these:
   - **Hot:** soak in hot water for an hour, drain, repeat several times (fastest).
   - **Running water:** a cloth bag of meal in cold running water for several hours.
   - **Daily change:** 3 parts water to 1 part meal in jars, kept cool; pour off the dark water
     and refill every day for about a week.
   - Traditional: pour nearly scalding water over fine flour in a hollow scooped in clean sand
     ([Hupa, p. 38](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=38)).
4. **It's done when it tastes sweet, not bitter or puckery.** Cold leaching keeps more of the
   starch's binding power (better for bread); hot is faster.
5. Use it wet as **mush/porridge**, pat it into **flatbread** on a hot stone or pan, or dry it and
   replace **¼ to ½ of the wheat flour** in bread (acorn flour has no gluten on its own).
6. **Ground meal goes rancid** in a warm room — grind only a few weeks' worth and keep it cold
   ([UCCE, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2)).

**Other local nuts** need no leaching: hazelnuts (June–July, dry and eat raw; [🖼️ photo](lib:beaked-and-california-hazelnut#page=1)) and [sugar
pine](wiki:Pinus_lambertiana) nuts (October; pound the cones to free the seeds) —
[Hupa, pp. 39–40](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=39). **Bay
nuts** ([Oregon myrtle](wiki:Umbellularia); [🖼️ peeled bay fruit](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=3)) must be **roasted** at 350 °F for 30–45 minutes until
dark-chocolate brown; they taste of coffee and contain a caffeine-like stimulant
([UCCE, pp. 2–3](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=3)).

📚 **Go deeper:** [UCCE *Foods from the Tanoak Forest*, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2) — modern acorn and bay-nut processing step by step; [Goddard, *Life and Culture of the Hupa*, p. 37](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=37) — how acorns were gathered, ground, leached and cooked just south of us; [NRCS Tanoak guide, p. 2](lib:tanoak-plant-guide-usda-nrcs#page=2) — storage, leaching and acorn bread.

## 🌿 Camas, cattail and other local starches

- **Camas bulbs** ([*Camassia quamash*](wiki:Camassia_quamash) — meadows, blue flowers in spring; [🖼️ photo](lib:great-camas-plant-guide-usda-nrcs#page=1))
  were a major food here. They must be **[pit-roasted](wiki:Earth_oven) or slow-baked 24–36 hours** — long cooking
  turns the indigestible starch sweet. Dry cooked bulbs or cakes for storage.
  ⚠️ **Death camas grows in the same meadows and its bulbs look the same.** Flower color is
  *not* a safe test. Only harvest from a bed you have watched bloom and learned plant by plant;
  if there's any doubt, leave it. ([USDA *Great Camas* guide, pp. 1–2](lib:great-camas-plant-guide-usda-nrcs#page=1); `Wild-Plants\` [death camas guide](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=1); [🖼️ death camas flowers and leaves](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2))
- **Dig after flowering**, take only the big bulbs, replant the small ones, and rest each patch a
  few years. Fresh bulbs don't keep; dried camas cakes are soaked overnight before eating
  ([Camas guide, pp. 1–2](lib:great-camas-plant-guide-usda-nrcs#page=2)).

| | Camas (edible) | [Death camas](wiki:Toxicoscordion_venenosum) (deadly) |
|---|---|---|
| Flowers | Blue-violet to **creamy white**, on a tall leafless stalk | Greenish to yellowish-white, in a pointed cluster |
| Height | 24–48 inches | 6–18 inch stem |
| Leaves | Long, narrow, grass-like | Grass-like, V-shaped, **edged with stiff hairs** |
| Bulb | Edible only after long cooking | Blackish scales, no onion smell — every part poisonous |

Sources: [Camas guide, p. 2](lib:great-camas-plant-guide-usda-nrcs#page=2); [PNW 104, pp. 1–2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2).
Death camas drawn: [🖼️ Army survival manual](lib:fm-3-05-70-survival-2002#page=507); [🖼️ Air Force survival handbook](lib:afh-10-644#page=347).
Some Oregon camas ([great camas](wiki:Camassia_leichtlinii)) is white-flowered — which is why color can't be trusted. Death camas symptoms
start **1–8 hours** after eating (drooling, vomiting, weakness, irregular heartbeat): get help at once.

- **Cattail** ([*Typha latifolia*](wiki:Typha_latifolia); [🖼️ drawing](lib:fm-3-05-70-survival-2002#page=416); [🖼️ photo](lib:broadleaf-cattail-plant-guide-usda-nrcs#page=1)): young shoots and stem bases (boiled or
  roasted), green flower spikes (boiled like corn), **pollen** to stretch flour, and **rhizome
  flour** (the root core is 30–46% starch — pound, soak, let the starch settle, dry it). Harvest
  only from **clean** water; cattails take up pollutants.
  ([Cattail guide, p. 1](lib:broadleaf-cattail-plant-guide-usda-nrcs#page=1))
- ⚠️ **[Western waterhemlock](wiki:Cicuta_douglasii) grows in the same wet ground** — the most
  poisonous plant in North America; a walnut-sized piece of root can kill a cow. Its stem base and
  roots are **hollow with cross-walls** and ooze yellow, oily juice. Never dig roots in wet ground
  unless you're sure. ([PNW 109, p. 1](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ photos of the chambered root](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ look-alikes compared, pp. 3–4](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3); [🖼️ Army drawing](lib:fm-3-05-70-survival-2002#page=519))
- More: USDA *Food Plants of the North American Indians* lists about 1,100 native food plants
  and how each was prepared ([p. 6](lib:food-plants-of-the-north-american-indians-usda-misc-pub-237-1936#page=6)).

📚 **Go deeper:** [USDA *Great Camas* guide](lib:great-camas-plant-guide-usda-nrcs#page=1) — harvest, cooking, drying; [PNW 104 *Meadow Deathcamas*](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=1) — identification photos; [PNW 109 *Western Waterhemlock*, p. 3](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3) — photo comparison with look-alikes.

## 🌽 Corn: masa, tortillas and hominy

**Always cook dried corn with lime or wood ash ("[nixtamal](wiki:Nixtamalization)")** before
making it a staple — it unlocks the corn's niacin. People living mostly on untreated cornmeal get
**pellagra** ([FAO *Maize*, p. 13](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=13)).

- **[Masa](wiki:Masa) with lime** (food-grade slaked lime, *cal*): use lime **1% of the dry corn's weight**
  (5 g of lime per 500 g of corn — weigh it if you can) and water **1½ times the corn's volume**. Heat to just below
  a simmer (200–210 °F) until the skins slip off but the center is still firm (often under 30
  minutes). **Rest 8–12 hours** in the liquid, then rub and rinse off the skins. Grind while cold
  (a [metate](wiki:Metate) or stone mill, with a little cold water; [🖼️ metate and hand mill](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=17)); use the masa within a day.
  ([Smithsonian method, pp. 1–3](lib:nixtamalization-and-corn-tortillas-smithsonian#page=2))
  Fresh corn needs less lime and cooking; old, hard corn more
  ([FAO, p. 66](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=66)).
- **With wood ash instead:** boil shelled corn 15–30 minutes in weak lye water made from
  **hardwood** ashes until the hulls loosen, then rinse very thoroughly in running water until no
  lye remains. **Lye is caustic** — gloves and eye protection; never taste it.
- **Lye hominy with store [lye](wiki:Lye)** (USDA) — use **pure** lye (100% sodium hydroxide, sold for
  soap-making), never a drain cleaner with other chemicals: 5 oz lye in 6 quarts cold water; stir in 5 quarts whole
  corn and let stand 15 hours. Wash and rub the corn in a cloth bag until hulls and black tips are
  gone, then boil 3–4 hours in salted water, changing the water once or twice to remove the lye
  taste. Makes 15–20 quarts.
  ([FB 1236, pp. 20–21](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=20))
- **[Corn tortillas](wiki:Corn_tortilla):** knead masa with a little water to a soft, play-dough feel, press balls flat
  between plastic or cloth, and cook on a hot dry griddle about a minute a side. Keep the masa under
  a damp cloth — dry masa cracks ([Smithsonian, p. 3](lib:nixtamalization-and-corn-tortillas-smithsonian#page=3)).
- **[Hominy](wiki:Hominy)** (whole kernels; [🖼️ an old hominy block](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=9); [🖼️ stone mortar and muller](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=68)) and **cornbread, mush, polenta and corn pone** recipes: USDA
  *Corn and Its Uses as Food* (FB 1236, [p. 11](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=11)).
  To stretch wheat, use a scant cup of cornmeal per cup of flour in quick breads and bake longer.
- **If the kernels go mushy all the way through,** they're overcooked and won't make masa — stop
  sooner next time ([Smithsonian, p. 2](lib:nixtamalization-and-corn-tortillas-smithsonian#page=2)).

📚 **Go deeper:** [Smithsonian *Nixtamalization*](lib:nixtamalization-and-corn-tortillas-smithsonian#page=1) — the full masa method; [USDA FB 1236 *Corn and Its Uses*, p. 11](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=11) — mush, pone, cornbreads and hominy; [FAO *Maize*, p. 96](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=96) — tortillas and other corn recipes; [Parker, *Iroquois Uses of Maize*, p. 115](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=115) — hominy, samp and old corn dishes.

## 🍞 Leavening without store yeast or baking powder

- **Wild [sourdough](wiki:Sourdough) starter:** mix equal weights of flour (whole-grain or rye
  starts fastest) and unchlorinated water in a jar. **Every day, discard all but a little and feed it
  equal weights of flour and water** (twice a day from day 4). Keep it at 70–82 °F. Usable around
  **day 7**, strong in 2–4 weeks — it's ready when it **doubles within 4–6 hours** of feeding
  and smells yeasty and pleasant. Throw it out if mold appears.
  (Illinois *Sourdough 101*, [pp. 1–3](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=2))
- **Keep it going:** save ½ cup each time you bake; the night before, feed it equal parts flour
  and water and leave it warm 6–8 hours. Store in glass, not metal, with the lid loose. (Alaska's
  guide warns against all metal; Illinois allows stainless steel but never copper, iron or
  galvanized.) ([UAF *Sourdough*, p. 2](lib:sourdough-alaska-starter-and-recipes-uaf-fnh-00061#page=2))
- **Back-up:** spread some starter thin, dry it until brittle, and store it airtight. Revive by
  crumbling into warm water overnight, then feeding.
- **Sourdough pancakes and muffins** get ½ tsp baking soda dissolved in 1 Tbsp water, stirred in
  **last**. Never put soda in the starter itself — it can kill the yeast
  ([UAF, pp. 2–3](lib:sourdough-alaska-starter-and-recipes-uaf-fnh-00061#page=2)).
- **Potato yeast** and "saving a piece of dough" for next time: USDA *Bread and Bread Making*
  (FB 807, [p. 10](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=10)) — liquid
  yeast keeps about two weeks in a cool, dark place.
- **Quick breads:** **sour milk or [buttermilk](wiki:Buttermilk) + ½ tsp baking soda per cup** replaces sweet milk
  and baking powder ([FB 1136, p. 22](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=22)).
  Homemade baking powder = 1 part baking soda : 2 parts cream of tartar
  ([Fannie Farmer, p. 92](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=92)).

| Starter trouble | Fix |
|---|---|
| Not rising after a week | Somewhere warmer; switch to rye or whole-grain flour; avoid very hard or chlorinated water ([Illinois, pp. 1–2](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=2)) |
| Dark liquid on top ("hooch") | It's hungry — pour it off or stir it in, then feed ([Illinois, p. 3](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=3)) |
| Any mold | Throw it out; restart from your dried back-up ([Illinois, p. 3](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=3)) |

📚 **Go deeper:** [Illinois *Sourdough Bread 101*, p. 4](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=4) — step-by-step loaf and schedules; [UAF *Sourdough*, p. 3](lib:sourdough-alaska-starter-and-recipes-uaf-fnh-00061#page=3) — hotcakes, muffins and bread; [USDA FB 807, p. 10](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=10) — potato yeast and saved dough.

## 🧂 Salt, 🍯 sweeteners and 🥓 fat

- **Salt from seawater** ([sea salt](wiki:Sea_salt)): seawater is about 3.5% salt — **roughly 4–5 gallons per pound** of salt
  in practice. Collect it away from harbors and outfalls, filter through cloth, boil down to a
  slush, then finish drying slowly; pour off the last bitter liquid for better taste.
- **[Bigleaf maple](wiki:Acer_macrophyllum) syrup** (OSU 2025 guide): tap after leaf drop and a hard freeze, through
  winter freeze–thaw days, until buds break. 5/16-inch spile in a 2-inch hole ([🖼️ tapping, step by step](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=4)); collect sap daily
  and boil it within 24 hours. Bigleaf sap is thin — **about 80 gallons of sap per gallon of
  syrup** (20 gallons ≈ 1 quart after ~8 hours of boiling). Syrup is done at **7 °F above the
  boiling point of water** where you are — about **216 °F around Cave Junction's elevation**
  (219 °F at sea level). ([OSU EM 9163, pp. 2–8](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=8))
  Keep buckets lidded — "ropey" (stringy) sap is spoiled ([🖼️ photos](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=6)). Let syrup settle and pour it off the
  gritty "sugar sand"; to keep it on a shelf, bottle it at **180–190 °F** into just-boiled jars
  ([pp. 6, 8–9](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=9)).
- **Honey:** strain through progressively finer cloth, keep it sealed (wet honey ferments);
  render the wax for candles and salves (`Practical Action` brief, [p. 1](lib:honey-processing-practical-action#page=1)).
  **Never heat honey to dry it** — blow air over a pan instead. Solid ("granulated") honey is fine.
  ([pp. 3–4](lib:honey-processing-practical-action#page=3)) Honey replaces sugar cup for cup in
  baking ([FB 1136, p. 23](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=23)).
- **[Lard](wiki:Lard) and [tallow](wiki:Tallow):** chill fat and render it within about a week. Melt slowly with a little
  water, stirring, at 235–245 °F (no copper pots), until bubbling stops and the cracklings float
  and turn chestnut-brown ([cracklings](wiki:Cracklings)); strain into clean jars, fill full, store cool and dark.
  ([Minnesota, pp. 2–3](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=3))
  Leaf (kidney) fat makes the best lard; strong-tasting gut fat is for soap. *Slightly* rancid lard
  can be rescued by heating it with sliced potatoes until they're dark brown, then straining
  ([pp. 2, 4](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=4)).
- **Nut oil** (hazelnuts, acorns): grind, boil with water, and skim the oil as it rises; clarify
  and store cool (`Practical Action` brief, [p. 2](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=2)).
  Discard moldy nuts first; store oil dark and airtight, never in copper
  ([pp. 1, 6](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=6); [🖼️ hand oil presses, p. 3](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=3)).
- **Butter:** sour the cream mildly at 65–75 °F, churn at 52–66 °F until grains the size of wheat
  form, drain, wash twice in cold water, and work in ¾ oz salt per pound
  ([USDA FB 876, pp. 23–24](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=23); [🖼️ the churn, p. 10](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=10); [🖼️ working the butter, p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16); [🖼️ a small churn](lib:butter-and-ghee-practical-action-2008#page=3); [butter churn](wiki:Butter_churn)).
- ⚠️ **Homemade vinegar** ([FB 1424](lib:usda-farmers-bulletin-1424-making-vinegar-1924#page=4)) is
  fine for cooking, but **never for canned pickles** — its acid strength is unknown, and canning
  recipes need tested 5% vinegar ([USDA Canning Guide 1, p. 28](lib:usda-complete-guide-to-home-canning-2015-guide-1-principles#page=28)).

📚 **Go deeper:** [OSU *Making Bigleaf Maple Syrup*, p. 3](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=3) — tapping, sanitation and bottling, with photos; [Minnesota *Making Lard at Home*](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=2) — rendering and what spoils lard; [Practical Action *Honey Processing*](lib:honey-processing-practical-action#page=1) — straining, moisture and wax; [USDA FB 876 *Making Butter*](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=3) — cream, churning and storage.

## 🥩 Jerky

- **Heat the meat to 160 °F** (poultry 165 °F) before or right after drying — drying alone doesn't
  kill *E. coli*, *Salmonella* or [trichinosis](wiki:Trichinosis). Ten people caught trichinosis from **cougar** jerky
  in 1995 ([PNW 632, p. 8](lib:pnw632-making-jerky-at-home-safely#page=8)); cougar and bear are
  hunted in our units ([ODFW, pp. 67–68](lib:odfw-2026-big-game-hunting-regulations#page=67)).
  Either dip strips 1½–2 minutes in simmering brine before drying, or heat the dried strips 10
  minutes in a 275 °F oven ([pp. 9, 17](lib:pnw632-making-jerky-at-home-safely#page=9); [🖼️ oven-heated jerky, p. 14](lib:pnw632-making-jerky-at-home-safely#page=14)).
- **Dry at 145–155 °F** (check with a thermometer; an oven with the door propped open works). Sun
  drying isn't recommended. **Done** when a cooled strip cracks but doesn't snap
  ([pp. 9, 18](lib:pnw632-making-jerky-at-home-safely#page=18); [photos](wiki:Jerky)). It keeps 1–2 months.

📚 **Go deeper:** [PNW 632 *Making Jerky at Home Safely*](lib:pnw632-making-jerky-at-home-safely#page=8) — tested methods and the hot-brine recipe; [NDSU *Preservation of Game Meats and Fish*, p. 5](lib:ndsu-wild-side-of-the-menu-3-preservation-of-game-meats-and-fish#page=5) — game jerky, smoking and curing.

## 🥖 Staples

- **No oven thermometer?** Put a scrap of white paper or ½ tsp flour on a tin plate in the oven; if
  it turns **light golden brown in 5 minutes**, it's right to start bread
  ([FB 807, p. 15](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=15)).
  Over a fire, cook on **coals**, not flames ([OSU EM 9331, p. 4](lib:osu-survival-basics-food-em-9331#page=4)).
- **Danger zone:** cooked food left between 40 °F and 140 °F for over 2 hours can make you sick
  ([OSU EM 9331, p. 5](lib:osu-survival-basics-food-em-9331#page=5)).

**Basic yeast bread — per loaf** (USDA FB 807, [pp. 13–17](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=16)): 1 cup lukewarm liquid, about **3 cups flour**,
1 tsp salt, 1 Tbsp sugar or honey, up to 1 Tbsp fat, and yeast (or ½ cup active sourdough
starter in place of yeast and part of the liquid). [Knead](wiki:Kneading) until smooth and springy, let it double,
shape, let it rise again, and bake at about 400 °F for 40–50 minutes, until it sounds hollow when
tapped. **Stop adding flour** once the dough doesn't stick to unfloured hands — too much flour
makes heavy bread. Rise it covered, at about 80 °F; it's ready for the oven when a light touch
leaves a slight dent.

**Simple sourdough loaf:** 1 cup active starter + 1 cup water + about 3 cups flour + 1½ tsp
salt. Knead, let rise 4–8 hours (longer when cool), shape, rise 2–4 hours more, bake at about
425 °F for 35–45 minutes. **Poke test:** a floured finger-dent that springs back halfway means
bake now; one that stays means over-risen — bake at once. A preheated **[Dutch oven](wiki:Dutch_oven)** (lid on 30
minutes, then off) gives a good crust without a real oven
([Illinois, pp. 5–6](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=5)).

**Flour tortillas / [flatbread](wiki:Flatbread):** 2 cups flour, ¼ cup lard, 1 tsp salt, about ¾ cup warm water.
Knead, rest 20 minutes, roll thin, cook on a hot dry pan 30–60 seconds a side. Works with part
acorn or barley flour. **Barley flatbread** with no yeast: [FAO *Barley*, p. 63](lib:barley-post-harvest-operations-and-recipes-fao#page=63).

**Biscuits** (USDA FB 1136, [p. 23](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=23)): 2 cups flour, 1 tsp salt, 2 tsp baking powder (or the soda and sour
milk swap above), 2 Tbsp fat, ⅔–¾ cup liquid. Bake hot (about 450 °F) 12–15 minutes. Keep it all
cold and handle it lightly. Too much soda makes them yellow and bad-tasting
([p. 22](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=22)).

**Crackling bread:** for each cup of cornmeal, ¾ tsp salt and ½ cup cracklings left from rendering
lard; pour on boiling water until you can mash it by hand, shape into cakes and bake
([FB 1236, p. 12](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=12)).

**Pasta / egg noodles:** 2 cups flour, 1 egg + 2 yolks, ½ tsp salt, about ⅓ cup water (or the old
way: one egg, a pinch of salt and enough flour for a very stiff dough). Knead 8–10 minutes,
rest 10–20, roll paper-thin, cut ⅛–¼ inch strips. Cook fresh 2–4 minutes, dried 10–12. To store,
dry until the noodles **snap**; keep airtight about a month (longer frozen). (Illinois Extension,
[p. 2](lib:homemade-egg-noodles-univ-illinois-extension#page=2);
Fannie Farmer 1896, [p. 167](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=167))
Because of the raw egg, Illinois says don't air-dry over 2 hours — finish them at about 135 °F.

**[Hardtack](wiki:Hardtack) (keeps for years):** 3 parts flour to 1 part water (no salt — salt draws moisture and
mold), stiff dough, ½ inch thick, prick with holes, bake 1 hour at 375 °F, then dry 3 more days.
Soak or crumble into soup to eat. ([City of Alexandria](lib:ship-biscuits-hardtack-how-to-make-city-of-alexandria#page=1))

**Beans:** soak overnight (6 cups water + 2 tsp salt per pound) or quick-soak (boil 2 minutes,
stand 1 hour), then simmer 2–4 hours. Old beans take longer; lentils and split peas need no soak.
**Beans + corn (or wheat) together make complete protein.** Add tomatoes or vinegar only after
they're tender — acid stops beans softening
([USU, pp. 2–4](lib:dry-beans-and-peas-soaking-and-cooking-usu#page=3)). Canning beans needs a
**pressure canner**: at Cave Junction's elevation a weighted-gauge canner runs at **15 lb**
([OSU EM 9435, p. 3](lib:osu-preserving-dry-beans-em-9435#page=3)).

**Porridge and mush:** cracked wheat, oats, barley, cornmeal or leached acorn meal simmered in
about 3–4 times their volume of water with a pinch of salt. Hominy grits can finish overnight
in a [hay box](wiki:Haybox) ([🖼️ how to build one](lib:usda-homemade-fireless-cookers-fb771-1919#page=8); [🖼️ its parts](lib:practical-action-fireless-cookers-haybox-technical-brief#page=2)) after a 10-minute boil; coarse hominy needs longer on the fire first
([FB 1236, p. 19](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=19)).

📚 **Go deeper:** [USDA FB 807 *Bread and Bread Making*, p. 12](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=12) — kneading, rising and baking; [USDA FB 1136 *Quick Breads and Biscuits*, p. 22](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=22) — biscuits, muffins and griddle cakes; [Fannie Farmer 1896, p. 92](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=92) — hundreds of everyday recipes; [Practical Action *Fireless Cookers*, p. 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5) — hay-box cooking times.

---

*Old recipes in these books are fine for **methods**; for food safety (canning, curing,
storing) follow the modern USDA guides in `Gardening-Food\`.*

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Grain: threshing, grinding, pests**
- Threshing box for small lots — [🖼️ McCormack, p. 4](lib:seed-processing-and-storage-principles-and-practices-mccormack-2010#page=4); [Threshing](wiki:Threshing); [Winnowing](wiki:Winnowing)
- Hand grain mill and metate — [🖼️ FAO, p. 17](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=17); [Quern-stone](wiki:Quern-stone)
- Homemade pipe-and-can grinder — [🖼️ Kearny, p. 83](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=83)
- Stone mill, how it is built — [🖼️ FAO, p. 72](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=72)
- Weevils and moths in stored grain — [🖼️ FAO, p. 78](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=78); [Rice weevil](wiki:Rice_weevil)

**Acorns and nuts**
- Tanoak and its acorns — [🖼️ NRCS, p. 1](lib:tanoak-plant-guide-usda-nrcs#page=1); [Notholithocarpus](wiki:Notholithocarpus); [Acorn](wiki:Acorn)
- Oaks and acorns — [🖼️ Army survival manual, p. 449](lib:fm-3-05-70-survival-2002#page=449); [Quercus kelloggii](wiki:Quercus_kelloggii); [Quercus garryana](wiki:Quercus_garryana)
- Hazelnut — [🖼️ NRCS, p. 1](lib:beaked-and-california-hazelnut#page=1); [Corylus cornuta](wiki:Corylus_cornuta)
- Bay nut inside its fruit — [🖼️ UCCE, p. 3](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=3); [Umbellularia](wiki:Umbellularia)
- Sugar pine — [Pinus lambertiana](wiki:Pinus_lambertiana)

**Camas, cattail and their deadly look-alikes**
- Camas in bloom — [🖼️ NRCS, p. 1](lib:great-camas-plant-guide-usda-nrcs#page=1); [Camassia quamash](wiki:Camassia_quamash); [Camassia leichtlinii](wiki:Camassia_leichtlinii)
- Death camas: leaves, flowers, bulbs — [🖼️ PNW 104, p. 2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2); [🖼️ Army, p. 507](lib:fm-3-05-70-survival-2002#page=507); [🖼️ Air Force, p. 347](lib:afh-10-644#page=347); [Toxicoscordion venenosum](wiki:Toxicoscordion_venenosum)
- Pit roasting — [Earth oven](wiki:Earth_oven)
- Cattail — [🖼️ Army, p. 416](lib:fm-3-05-70-survival-2002#page=416); [🖼️ NRCS photo](lib:broadleaf-cattail-plant-guide-usda-nrcs#page=1); [🖼️ Air Force, p. 362](lib:afh-10-644#page=362); [Typha latifolia](wiki:Typha_latifolia)
- Western water hemlock: chambered root, look-alikes — [🖼️ PNW 109, p. 1](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ pp. 3–4](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3); [🖼️ Army, p. 519](lib:fm-3-05-70-survival-2002#page=519); [Cicuta douglasii](wiki:Cicuta_douglasii)

**Corn**
- Hominy block and stone mortar — [🖼️ USDA FB 1236, p. 9](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=9); [🖼️ Parker, p. 68](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=68); [🖼️ pounding corn, Parker, p. 107](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=107)
- Inside a corn kernel (skin, germ, starch) — [🖼️ USDA FB 1236, p. 6](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=6)
- Nixtamal, masa and tortillas — [Nixtamalization](wiki:Nixtamalization); [Masa](wiki:Masa); [Corn tortilla](wiki:Corn_tortilla); [Hominy](wiki:Hominy)

**Syrup, oil, lard and butter**
- Tapping a bigleaf maple — [🖼️ OSU, p. 4](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=4); [🖼️ spoiled sap and dirty spiles, p. 6](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=6); [Acer macrophyllum](wiki:Acer_macrophyllum)
- Hand oil presses — [🖼️ Practical Action, p. 3](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=3)
- Rendered lard and cracklings — [Lard](wiki:Lard); [Cracklings](wiki:Cracklings)
- Churning, washing and working butter — [🖼️ USDA FB 876, p. 10](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=10); [🖼️ p. 13](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13); [🖼️ p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16); [🖼️ small churn, Practical Action, p. 3](lib:butter-and-ghee-practical-action-2008#page=3); [Butter churn](wiki:Butter_churn)

**Jerky, bread and slow cooking**
- Oven-heating jerky — [🖼️ PNW 632, p. 14](lib:pnw632-making-jerky-at-home-safely#page=14); [Jerky](wiki:Jerky)
- What good rolls look like — [🖼️ USDA FB 1136, p. 17](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=17); [Kneading](wiki:Kneading)
- Dutch-oven bread, flatbread, hardtack — [Dutch oven](wiki:Dutch_oven); [Flatbread](wiki:Flatbread); [Hardtack](wiki:Hardtack)
- Hay-box cooker — [🖼️ USDA FB 771, pp. 8–9](lib:usda-homemade-fireless-cookers-fb771-1919#page=8); [🖼️ Practical Action, p. 2](lib:practical-action-fireless-cookers-haybox-technical-brief#page=2); [Haybox](wiki:Haybox)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — frost dates, soils and the deadly wild-plant look-alikes.
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — hay-box cooker, soap from fat and ashes, food containers, pests.
- [Root Cellar Guide](guide:ROOT-CELLAR-GUIDE) — root cellars, drying, curing, fermenting and keeping eggs.
- [Seed Bank Guide](guide:SEED-BANK-GUIDE) — planting calendar, saving grain and bean seed, grafting.
- [Mushroom Guide](guide:MUSHROOM-GUIDE) — safe local edibles, drying and growing mushrooms.
- [Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE) — keeping food and water clean after fallout.
- [Medical — Read Me First](guide:Medical-READ-ME-FIRST) — food poisoning and where the medical books are.
