param([Parameter(Mandatory=$true)][string]$Root)
# Scans $Root and writes README.html - a full clickable index of every guide, document,
# manual, archive, app and data file in every folder. (ASCII-only source; emoji via entities.)

$css = @'
<style>:root{--bg:#0f1420;--card:#171f2e;--ink:#e7ecf3;--muted:#9fb0c3;--accent:#4fd1c5;--accent2:#f6ad55;--line:#273246;--code:#0b0f17}@media(prefers-color-scheme:light){:root:not([data-theme=dark]){--bg:#f4f6fb;--card:#fff;--ink:#15202b;--muted:#56657a;--accent:#0d9488;--accent2:#b45309;--line:#e2e8f0;--code:#f1f5f9}}:root[data-theme=light]{--bg:#f4f6fb;--card:#fff;--ink:#15202b;--muted:#56657a;--accent:#0d9488;--accent2:#b45309;--line:#e2e8f0;--code:#f1f5f9}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.65 -apple-system,Segoe UI,Roboto,Arial,sans-serif}.wrap{max-width:1000px;margin:0 auto;padding:28px 20px 80px}h1{font-size:30px;background:linear-gradient(135deg,var(--accent),var(--accent2));-webkit-background-clip:text;background-clip:text;color:transparent}h2{font-size:21px;border-bottom:2px solid var(--line);padding-bottom:6px;margin-top:32px}a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}code{background:var(--code);padding:2px 6px;border-radius:6px;font-family:Consolas,monospace;font-size:13px}table{border-collapse:collapse;width:100%;margin:10px 0;font-size:14.5px}th,td{border:1px solid var(--line);padding:8px 11px;text-align:left;vertical-align:top}th{background:rgba(127,127,127,.12)}.muted{color:var(--muted);font-size:13px}.hero{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px;margin:14px 0}details.sec{background:var(--card);border:1px solid var(--line);border-radius:14px;margin:12px 0;padding:0 14px}details.sec>summary{cursor:pointer;font-weight:700;font-size:20px;padding:12px 0}details.sec .n{font-size:12px;font-weight:600;padding:0 8px;border-radius:999px;background:rgba(127,127,127,.16);color:var(--muted);margin-left:8px;vertical-align:middle}</style><script>document.addEventListener('DOMContentLoaded',function(){[].slice.call(document.querySelectorAll('.wrap > h2')).forEach(function(h,i){var d=document.createElement('details'),s=document.createElement('summary');d.className='sec';if(i===0)d.open=true;s.innerHTML=h.innerHTML;h.parentNode.insertBefore(d,h);d.appendChild(s);var n=h.nextSibling;h.parentNode.removeChild(h);while(n&&!(n.nodeType===1&&n.tagName==='H2')){var x=n.nextSibling;d.appendChild(n);n=x}var c=d.querySelectorAll('tr').length-d.querySelectorAll('table').length;if(c>0){var b=document.createElement('span');b.className='n';b.textContent=c;s.appendChild(b)}})});</script><style>:root{color-scheme:dark}@media(prefers-color-scheme:light){:root:not([data-theme=dark]){color-scheme:light}}:root[data-theme=light]{color-scheme:light}.themebtn{font:inherit;font-size:14px;line-height:1.3;background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:999px;padding:3px 11px;cursor:pointer;white-space:nowrap;text-decoration:none}.themefloat{position:absolute;top:10px;right:12px;z-index:9}@media print{.themebtn{display:none}}</style><script>/* so-theme: light or dark screen */(function(){var K="so-theme",d=document.documentElement,L={auto:"\uD83C\uDF13 Auto",dark:"\uD83C\uDF19 Dark",light:"\u2600\uFE0F Light"},N={auto:"dark",dark:"light",light:"auto"},cur="auto";try{cur=localStorage.getItem(K)||"auto"}catch(e){}function a(){if(cur==="dark"||cur==="light")d.setAttribute("data-theme",cur);else d.removeAttribute("data-theme");var b=document.querySelectorAll(".themebtn");for(var i=0;i<b.length;i++){b[i].textContent=L[cur]||L.auto;b[i].title="Screen: "+cur+" - tap to change (Auto follows this device)"}}a();window.soTheme=function(){cur=N[cur]||"dark";try{localStorage.setItem(K,cur)}catch(e){}a()};function btn(){var b=document.createElement("button");b.type="button";b.className="themebtn";return b}document.addEventListener("DOMContentLoaded",function(){if(!document.querySelector(".themebtn")){var n=document.querySelector(".topnav"),b=btn();if(n){n.appendChild(document.createTextNode(" \u00B7 "));n.appendChild(b)}else{b.className+=" themefloat";document.body.appendChild(b)}}var all=document.querySelectorAll(".themebtn");for(var i=0;i<all.length;i++)all[i].onclick=window.soTheme;a()})})();</script>
'@
function Esc($s){ $s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;' }
function Rel($full){ ($full.Substring($Root.Length)).TrimStart('\','/') -replace '\\','/' }
function Nice($name){ ($name -replace '\.[A-Za-z0-9]+$','') -replace '[-_]',' ' }
function Human($bytes){ if($bytes -ge 1GB){"{0:N2} GB" -f ($bytes/1GB)}elseif($bytes -ge 1MB){"{0:N0} MB" -f ($bytes/1MB)}else{"{0:N0} KB" -f ($bytes/1KB)} }

$all = Get-ChildItem $Root -Recurse -File -ErrorAction SilentlyContinue
function ByExt($exts){ $all | Where-Object { $exts -contains $_.Extension.ToLower() } | Sort-Object { Rel $_.FullName } }

$htmlDocs = ByExt @('.html') | Where-Object { $_.Name -ne 'README.html' }
$mdDocs   = ByExt @('.md')
$pdfs     = ByExt @('.pdf')
$epubs    = ByExt @('.epub')
$zims     = ByExt @('.zim')
$apks     = ByExt @('.apk')
$progs    = $all | Where-Object { $e=$_.Extension.ToLower(); ($e -in @('.bat','.sh','.command','.appimage','.run','.dmg')) -or ($e -eq '.exe' -and $_.Name -match 'installer|kiwix-desktop') } | Sort-Object { Rel $_.FullName }
$data     = $all | Where-Object { $_.Name -like '*.bz2' -or $_.Name -like '*.obf.zip' } | Sort-Object { Rel $_.FullName }

$navCss = '<style>.topnav{font-size:14.5px;margin:-28px -20px 8px;padding:10px 20px 8px;color:var(--muted);position:sticky;top:0;z-index:4;background:var(--bg);border-bottom:1px solid var(--line)}.topnav a{text-decoration:none;white-space:nowrap}</style><style>.backbtn{font-weight:700;text-decoration:none;white-space:nowrap}@media print{.backbtn{display:none}}@media(max-width:600px){.topnav{white-space:nowrap;overflow-x:auto;scrollbar-width:none;font-size:14px}.topnav::-webkit-scrollbar{display:none}.topnav .lbl{display:none}.topnav .themebtn{font-size:13px;padding:2px 9px}}</style><script>/* so-back: a Back button on every page after the first */(function(){function add(){var n=document.querySelector(".topnav");if(!n||n.querySelector(".backbtn"))return;var f=n.querySelector("a"),a=document.createElement("a");a.className="backbtn";a.href=f?f.href:"#";a.textContent="\u2190 Back";a.title="Back to the page you came from";a.onclick=function(e){if(history.length>1&&document.referrer){e.preventDefault();history.back()}};n.insertBefore(document.createTextNode(" \u00B7 "),n.firstChild);n.insertBefore(a,n.firstChild)}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",add);else add();document.addEventListener("click",function(e){var a=e.target&&e.target.closest?e.target.closest("a[href^=\"#\"]"):null;if(!a||e.defaultPrevented)return;var id=decodeURIComponent(a.getAttribute("href").slice(1)),t=id?document.getElementById(id):null;if(!t)return;e.preventDefault();t.scrollIntoView();try{history.replaceState(history.state,"","#"+id)}catch(x){}})})();</script>'
$sb = New-Object System.Text.StringBuilder
[void]$sb.Append("<!DOCTYPE html><html lang=`"en`"><head><meta charset=`"utf-8`"><meta name=`"viewport`" content=`"width=device-width,initial-scale=1`"><title>Offline Emergency Library - Full Index</title>$css$navCss</head><body><div class=`"wrap`"><p class='topnav'><a href='START-HERE.html#guides-by-subject'>&#x1F4D8; Guides</a> &middot; <a href='EMERGENCY-FINDER.html'>&#x1F198;<span class='lbl'> Emergency</span></a> &middot; <a href='SUBJECT-INDEX.html'>&#x1F4C7;<span class='lbl'> Index A&ndash;Z</span></a> &middot; <a href='Southern-Oregon/LOCAL-FILES.html'>&#x1F3D4;&#xFE0F; Local books</a></p>")
[void]$sb.Append("<h1>&#128703; Offline Emergency Library &mdash; Full Index</h1>")
[void]$sb.Append("<div class='hero'>This page lists <b>every guide, document, manual, archive, app and data file</b> on this drive, with links. Generated by scanning the folders.<br><span class='muted'>Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm')</span></div>")
if(Test-Path (Join-Path $Root 'START-HERE.html')){ [void]$sb.Append("<p>&#128073; New here? Start with <a href='START-HERE.html'><b>START-HERE.html</b></a>.</p>") }

[void]$sb.Append("<h2>&#128214; Guides &amp; Documentation</h2><table><tr><th>Guide</th><th>Folder</th><th>Open</th></tr>")
foreach($h in $htmlDocs){
  $rel = Rel $h.FullName; $dir = Split-Path $rel -Parent; if(-not $dir){$dir='(root)'}
  $mdRel = $rel -replace '\.html$','.md'
  $mdLink = if(Test-Path (Join-Path $Root $mdRel)){" &middot; <a href='$mdRel'>md</a>"}else{''}
  [void]$sb.Append("<tr><td>$(Esc (Nice $h.Name))</td><td class='muted'>$dir</td><td><a href='$rel'>HTML</a>$mdLink</td></tr>")
}
foreach($m in $mdDocs){ $rel=Rel $m.FullName; $twin=$rel -replace '\.md$','.html'; if(-not (Test-Path (Join-Path $Root $twin))){ $dir=Split-Path $rel -Parent; if(-not $dir){$dir='(root)'}; [void]$sb.Append("<tr><td>$(Esc (Nice $m.Name))</td><td class='muted'>$dir</td><td><a href='$rel'>md</a></td></tr>") } }
[void]$sb.Append("</table>")

if($pdfs){ [void]$sb.Append("<h2>&#128218; Manuals &amp; Books (PDF)</h2><p class='muted'>Open in any web browser - no software needed.</p><table><tr><th>Document</th><th>Folder</th><th>Size</th><th>Open</th></tr>")
  foreach($p in $pdfs){ $rel=Rel $p.FullName; $dir=Split-Path $rel -Parent; [void]$sb.Append("<tr><td>$(Esc (Nice $p.Name))</td><td class='muted'>$dir</td><td>$(Human $p.Length)</td><td><a href='$rel'>PDF</a></td></tr>") }
  [void]$sb.Append("</table>") }
if($epubs){ [void]$sb.Append("<h2>&#128214; Stories &amp; Classics (e-books)</h2><p class='muted'>Read them in the library: open it and choose Books &rarr; Stories &amp; fun (they open as web pages). Or open a file in an e-book app.</p><table><tr><th>Book</th><th>Folder</th><th>Size</th><th>Open</th></tr>")
  foreach($p in $epubs){ $rel=Rel $p.FullName; $dir=Split-Path $rel -Parent; [void]$sb.Append("<tr><td>$(Esc (Nice $p.Name))</td><td class='muted'>$dir</td><td>$(Human $p.Length)</td><td><a href='$rel'>e-book</a></td></tr>") }
  [void]$sb.Append("</table>") }

if($zims){ [void]$sb.Append("<h2>&#127760; Offline Encyclopedias &amp; Archives (ZIM)</h2><p class='muted'>Open these with the Kiwix reader (see <code>Kiwix-Reader</code>).</p><table><tr><th>Archive</th><th>Folder</th><th>Size</th><th>File</th></tr>")
  foreach($z in $zims){ $rel=Rel $z.FullName; $dir=Split-Path $rel -Parent; [void]$sb.Append("<tr><td>$(Esc (Nice $z.Name))</td><td class='muted'>$dir</td><td>$(Human $z.Length)</td><td><a href='$rel'>open</a></td></tr>") }
  [void]$sb.Append("</table>") }

if($progs){ [void]$sb.Append("<h2>&#9881; Programs &amp; Launchers</h2><table><tr><th>Item</th><th>Folder</th><th>Type</th></tr>")
  foreach($x in $progs){ $rel=Rel $x.FullName; $dir=Split-Path $rel -Parent; if(-not $dir){$dir='(root)'}; [void]$sb.Append("<tr><td><a href='$rel'>$(Esc $x.Name)</a></td><td class='muted'>$dir</td><td class='muted'>$($x.Extension.TrimStart('.'))</td></tr>") }
  [void]$sb.Append("</table>") }

if($apks){ [void]$sb.Append("<h2>&#128241; Phone Apps (Android APK)</h2><p class='muted'>Copy to an Android device and install. See <code>Phone-Apps/USE-ON-PHONE.html</code>.</p><table><tr><th>App</th><th>Folder</th><th>Size</th></tr>")
  foreach($a in $apks){ $rel=Rel $a.FullName; $dir=Split-Path $rel -Parent; [void]$sb.Append("<tr><td><a href='$rel'>$(Esc $a.Name)</a></td><td class='muted'>$dir</td><td>$(Human $a.Length)</td></tr>") }
  [void]$sb.Append("</table>") }

if($data){ [void]$sb.Append("<h2>&#128451; Data</h2><table><tr><th>Item</th><th>Folder</th><th>Size</th></tr>")
  $wiki = $data | Where-Object { $_.Name -like '*.bz2' }
  foreach($d in $wiki){ $rel=Rel $d.FullName; $dir=Split-Path $rel -Parent; [void]$sb.Append("<tr><td>$(Esc $d.Name) <span class='muted'>(Wikipedia - read via Kiwix/processing)</span></td><td class='muted'>$dir</td><td>$(Human $d.Length)</td></tr>") }
  $maps = $data | Where-Object { $_.Name -like '*.obf.zip' }
  if($maps){ $sum=($maps|Measure-Object Length -Sum).Sum; [void]$sb.Append("<tr><td>Offline US maps - $($maps.Count) files <span class='muted'>(see OsmAnd/HOW-TO-VIEW-MAPS.html)</span></td><td class='muted'>OsmAnd</td><td>$(Human $sum)</td></tr>") }
  [void]$sb.Append("</table>") }

[void]$sb.Append("</div></body></html>")
[System.IO.File]::WriteAllText((Join-Path $Root 'README.html'), $sb.ToString(), [System.Text.UTF8Encoding]::new($false))
"README.html written to $Root  (indexed: $($htmlDocs.Count) guides, $($pdfs.Count) PDFs, $($zims.Count) ZIMs, $($apks.Count) APKs, $($progs.Count) programs)"
