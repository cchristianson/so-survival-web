#!/usr/bin/env bash
# Put the SO Survival Library on a drive: run this file (double-click and choose "Run", or: bash INSTALL-Linux.sh)
cd "$(dirname "$0")" || exit 1
DIR="$(pwd)"
case "$(uname -m)" in aarch64|arm64) B=library-assistant-linux-arm64;; *) B=library-assistant-linux-x64;; esac
LA="$DIR/local/library-assistant/$B"
chmod +x "$LA" 2>/dev/null
echo ""
echo "  The installer is opening in your web browser."
echo "  Keep THIS window open until the download has finished."
echo ""
"$LA" -setup || { echo "The point-and-click installer could not start - using the text installer instead."; bash "$DIR/get-offline-library.sh"; }
