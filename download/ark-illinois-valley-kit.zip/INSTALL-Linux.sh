#!/usr/bin/env bash
# Put the library on a drive: in a terminal in this folder type  bash INSTALL-Linux.sh
# (some file managers can also run it: right-click > Run as a Program)
cd "$(dirname "$0")" || exit 1
DIR="$(pwd)"
K="$DIR"; [ -f "$DIR/files/get-offline-library.sh" ] && K="$DIR/files"   # the kit keeps its parts in "files"
if [ ! -f "$K/get-offline-library.sh" ]; then
  echo ""; echo "  This file needs the rest of the kit next to it. Unzip the downloaded kit first,"
  echo "  then run INSTALL-Linux.sh inside the folder it makes."; echo ""; exit 1
fi
case "$(uname -m)" in aarch64|arm64) B=library-assistant-linux-arm64;; *) B=library-assistant-linux-x64;; esac
LA="$K/local/library-assistant/$B"
chmod +x "$LA" 2>/dev/null
echo ""; echo "  Starting the installer - it opens in your web browser in a moment..."
"$LA" -setup || { echo ""; echo "  The browser page could not start, so the installer will ask its questions here instead."; echo ""; bash "$K/get-offline-library.sh"; }
