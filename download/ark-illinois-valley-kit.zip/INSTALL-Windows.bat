@echo off
cd /d "%~dp0"
rem The kit keeps the installer's parts in a "files" folder next to this file (in the repo they sit beside it).
set "K=%~dp0"
if exist "%~dp0files\Get-OfflineLibrary.ps1" set "K=%~dp0files\"
rem the library's name and the area's folder (local\region.env, written by tools/region.py)
set "LIBNAME=Offline Library" & set "AREA=Local" & set "LOCALDIR=Local" & set "LOCALGUIDE=START-HERE"
if exist "%K%local\region.env" for /f "usebackq tokens=1,* delims==" %%a in ("%K%local\region.env") do (
  if "%%a"=="LIBRARY_NAME" set "LIBNAME=%%b"
  if "%%a"=="AREA_NAME" set "AREA=%%b"
  if "%%a"=="LOCAL_DIR" set "LOCALDIR=%%b"
  if "%%a"=="LOCAL_GUIDE" set "LOCALGUIDE=%%b"
)
title %LIBNAME% - Installer (keep this window open)
if not exist "%K%Get-OfflineLibrary.ps1" (
  echo.
  echo   This file needs the rest of the kit next to it.
  echo   Right-click the downloaded zip, choose "Extract All...", click Extract,
  echo   then double-click INSTALL-Windows inside the folder that opens.
  echo.
  pause
  exit /b 1
)
rem Files that came from the internet are marked "from the web". Clear that mark on this kit's own
rem files so Windows lets the installer program start without extra warnings. (The folder is handed over
rem by name: written into the command, a folder like C:\Users\O'Brien would break its quotes.)
set "KITDIR=%~dp0."
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath $env:KITDIR -Recurse -File | Unblock-File" >nul 2>&1
set "LA=%K%local\library-assistant\library-assistant.exe"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" if exist "%K%local\library-assistant\library-assistant-arm64.exe" set "LA=%K%local\library-assistant\library-assistant-arm64.exe"
if /i "%PROCESSOR_ARCHITEW6432%"=="ARM64" if exist "%K%local\library-assistant\library-assistant-arm64.exe" set "LA=%K%local\library-assistant\library-assistant-arm64.exe"
echo.
echo   Starting the installer - it opens in your web browser in a moment...
"%LA%" -setup
if errorlevel 1 (
  echo.
  echo   The browser page could not start, so the installer will ask its questions here instead.
  echo.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%K%Get-OfflineLibrary.ps1"
)
pause
