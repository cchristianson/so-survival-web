@echo off
rem The same as INSTALL-Windows.bat (kept so older instructions still work).
cd /d "%~dp0"
if exist "%~dp0INSTALL-Windows.bat" ( call "%~dp0INSTALL-Windows.bat" & exit /b )
if exist "%~dp0..\INSTALL-Windows.bat" ( call "%~dp0..\INSTALL-Windows.bat" & exit /b )
echo Unzip the whole kit first, then double-click INSTALL-Windows inside it.
pause
