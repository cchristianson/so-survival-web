<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="brand/ark-logo-dark.svg">
    <img src="brand/ark-logo-light.svg" alt="ARK, the Apocalypse Reference Kit" width="360">
  </picture>
</p>

# ARK: the Apocalypse Reference Kit

[![Stars](https://img.shields.io/github/stars/cchristianson/so-survival?style=flat)](https://github.com/cchristianson/so-survival/stargazers)
[![Forks](https://img.shields.io/github/forks/cchristianson/so-survival?style=flat)](https://github.com/cchristianson/so-survival/network/members)
[![License: MIT](https://img.shields.io/badge/license-MIT-informational)](LICENSE)
![Platforms](https://img.shields.io/badge/platforms-Windows%20%7C%20macOS%20%7C%20Linux-informational)

**A free survival library you keep on a USB drive. It works with no internet.**

It holds over 1,000 books, 54 plain-English guides, all of Wikipedia, offline maps, and an AI that
answers your questions from the books. This copy is made for the **Illinois Valley / Josephine
County, southern Oregon**, with local maps, rules and guides.

▶️ **[Watch the 3-minute video](https://cchristianson.github.io/so-survival-web/pages/AMMO-CAN-COMPUTER-GUIDE.html#video)**:
the whole library in a steel ammo can, the ARK Vault.

🌐 **[Try the website](https://cchristianson.github.io/so-survival-web/)**: the guides and a
searchable library that also works offline on your phone.

---

## 🚀 Get it

1. **Download the installer kit** from the website (**⚙️ Offline** tab → **Get the whole library**).
2. **Unzip it** and double-click **`INSTALL-Windows`** (or **`INSTALL-Mac`** / **`INSTALL-Linux.sh`**).
3. **Pick your USB drive and press Start.** It fills the drive with whatever fits. You can stop and
   carry on later.

Step by step, with pictures of each warning you might see:
[Get the whole library](https://cchristianson.github.io/so-survival-web/pages/GET-THE-LIBRARY.html).

---

## 📦 What you get

| | |
|---|---|
| **Library Assistant** | One search box for everything, plus an **offline AI** that answers with links to the exact page. Runs on Windows, Mac, Linux, Raspberry Pi and Android |
| **54 guides** | Plain-English guides on health, water, food, animals, building, power, repair, radio and disasters, linked to the exact book pages |
| **Books** | Over 1,000 free books and manuals: Army field manuals, medical books, farming, food preservation, repair |
| **Encyclopedias** | All of Wikipedia (with pictures), a medical encyclopedia, and repair, DIY and survival encyclopedias |
| **Maps** | A topo map in any web browser, with property lines and layers to switch on (springs and wells, good growing ground, wild food sightings, mines, past wildfires, flood zones, useful places), tools to measure, drop pins and print, and a dot for where you are; bigger maps for the OsmAnd phone app, and walking routes to nearby towns |
| **Local pack** | Maps, hunting and fishing rules, wildfire and quake plans, and local radio for the Illinois Valley |
| **Tools** | A plant and mushroom identifier from a photo, a pill identifier, a calculator and unit converter, Morse code |
| **Sharing** | One device can share the whole library over Wi-Fi with every phone nearby, iPhones too |

Everything is **free and legal to share**: open AI models, openly licensed encyclopedias, and
public-domain government manuals.

---

## 📏 What size drive?

| Drive | What fits |
|---|---|
| **16 GB** | All the guides and local books, a small AI, the medical encyclopedia, maps of Oregon |
| **64 GB** | Adds the repair encyclopedias, a bigger AI, maps of the whole USA |
| **128 GB** | Adds all of Wikipedia (words only) |
| **256 GB+** | Everything, including Wikipedia with pictures (about 170 GB) |

Any size works: the installer picks what fits. A small external SSD is fastest.

---

## 💻 Using it

Plug in the drive and double-click **`START-Windows`** (or **`START-Mac`** / **`START-Linux.sh`**).
Your web browser opens with the library. No internet needed.

- **Android:** works with the free Termux app.
- **iPhone:** use a library shared over Wi-Fi from another device.
- **Locked-down computer?** Open **`OPEN-IN-BROWSER.html`** in any browser.

Details for every device: [Start on any device](https://cchristianson.github.io/so-survival-web/pages/START-ON-ANY-DEVICE.html).

---

## 🧰 The ARK Vault

The whole library in a sealed steel ammo can: a Raspberry Pi, a battery, a printer, a radio and an
old phone. Sealed, it's protected from an EMP. Open the lid, flip the switch on, and every phone
nearby uses the library and the AI over its own Wi-Fi.
[The ARK Vault guide](https://cchristianson.github.io/so-survival-web/pages/AMMO-CAN-COMPUTER-GUIDE.html)
has the parts list, the 3D model, the wiring and the setup.

---

## 🗺️ Make a version for your own area

The guides work anywhere. Everything local (maps, county plans, local rules, radio frequencies)
lives in one small folder per area under [`regions/`](regions/). Copy `regions/_template/`, fill it
in, and run the build. [`regions/README.md`](regions/README.md) walks through it step by step.
Each area version is called **ARK** plus the area's name (*ARK Illinois Valley*, *ARK
Eugene-Springfield* ...); [`brand/`](brand/) has the logo tools.

---

## 🛠️ For technical users

<details>
<summary><b>Command-line install and options</b></summary>

Clone and run (resumable: run it again to continue):

```bash
git clone https://github.com/cchristianson/so-survival.git
cd so-survival
./get-offline-library.sh -d /path/to/drive        # macOS / Linux
./Get-OfflineLibrary.ps1 -Destination "E:\"       # Windows (PowerShell)
```

| Option (Windows / macOS-Linux) | Effect |
|---|---|
| `-DriveSize 116` / `--drive-size 116` | Fill that many GB with the most useful parts |
| `-Choose` / `--choose` | Show the "what goes on this drive" list even with a destination |
| `-PlanOnly` / `--plan-only` | Show what would fit, download nothing |
| `-Region <name>` / `--region <name>` | Map region (default `US`): a country, continent, sub-region (`US_texas`) or `world` |
| `-ListRegions` / `--list-regions [filter]` | List map regions |
| `-WikipediaSize maxi\|nopic\|mini` / `--wikipedia-size …` | Wikipedia with pictures (~120 GB), text only (~50 GB), or intros (~13 GB) |
| `-SkipWikipedia`, `-SkipMaps`, `-SkipModels`, `-SkipLocal` | Leave that part out (`--skip-…` on macOS/Linux) |
| `-SkipOtherDevices` / `--skip-other-devices` | Only this computer's programs |
| `-LocalOnly` / `--local-only` | Only the local pack and guides (same as `local-pack-only.bat`) |
| `-Community` / `--community` | The ~11 GB shareable kit (same as `community-kit.bat`) |

Afterwards, `README.html` at the top of the drive lists every file (rebuild it with
`build-readme-index.ps1 -Root "<folder>"`).

</details>

<details>
<summary><b>Where the downloads come from, and verifying the installer</b></summary>

This project hosts nothing large: it downloads from the official sources and runs offline after.

| What | From |
|---|---|
| AI models (GGUF) | huggingface.co (bartowski) |
| AI engine | github.com/ggml-org/llama.cpp |
| GPT4All | github.com/nomic-ai/gpt4all |
| Kiwix reader + encyclopedias | download.kiwix.org |
| Maps + desktop viewer | download.osmand.net |
| Portable Java | api.adoptium.net (Eclipse Temurin) |
| Manuals (PDF) | archive.org and the publishers |
| Phone apps | github.com/kiwix/kiwix-android, f-droid.org |

Each installer script's SHA-256 is in [`SHA256SUMS.txt`](SHA256SUMS.txt). The scripts are plain
Bash and PowerShell, so you can read them first. (A `git clone` on Windows changes line endings, so
local hashes differ there.)

```bash
sha256sum get-offline-library.sh                       # macOS / Linux
Get-FileHash Get-OfflineLibrary.ps1 -Algorithm SHA256  # Windows
```

</details>

<details>
<summary><b>Project layout</b></summary>

- `Get-OfflineLibrary.ps1` / `get-offline-library.sh`: the installers (keep them in step)
- `guides/`: the guides (edit these, then run `bash tools/build-html-docs.sh`)
- `regions/`: one folder per area; `lists/`: the download lists
- `local/library-assistant/src`: the Library Assistant (Go, standard library only)
- `tools/`: the build tools; `tools/maintenance/README.md` covers rebuilding everything
- `hardware/ammo-can/`: the ARK Vault's print and laser files

</details>

---

## ⚠️ Please remember

- The offline AI and older manuals **can be wrong or out of date**. Double-check anything about
  medicine, electricity or building. This is reference material, **not** professional advice.
- Copyrighted code books (electrical, plumbing) and brand car manuals are **not** included; the free
  repair encyclopedias and Army manuals cover the same ground.
- Follow your local laws for radio. Listening is always fine (see the radio guide).

## ⭐ Star history
[![Star History Chart](https://api.star-history.com/svg?repos=cchristianson/so-survival&type=Date)](https://star-history.com/#cchristianson/so-survival&Date)

## Contributing
Issues and pull requests are welcome. See [CONTRIBUTING](.github/CONTRIBUTING.md) and the
[ROADMAP](ROADMAP.md). Testers for the Mac and Linux installers are especially wanted.

## Credits
This library started from [elhajahmadj/offline-emergency-library](https://github.com/elhajahmadj/offline-emergency-library)
(MIT), the original one-command offline kit, and has been heavily changed and expanded since:
the guides, the local packs, the Library Assistant, the website and the region template are new.

## License
Code and documentation in this repo: **MIT** (see `LICENSE`). Downloaded content keeps its own
license (open-weight model licenses, Creative Commons for the Kiwix encyclopedias, public domain for
US-government works).
