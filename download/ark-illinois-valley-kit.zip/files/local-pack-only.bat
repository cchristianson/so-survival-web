@echo off
cd /d "%~dp0"
rem the library's name and the area's folder (local\region.env, written by tools/region.py)
set "LIBNAME=Offline Library" & set "AREA=Local" & set "LOCALDIR=Local" & set "LOCALGUIDE=START-HERE"
if exist "%~dp0local\region.env" for /f "usebackq tokens=1,* delims==" %%a in ("%~dp0local\region.env") do (
  if "%%a"=="LIBRARY_NAME" set "LIBNAME=%%b"
  if "%%a"=="AREA_NAME" set "AREA=%%b"
  if "%%a"=="LOCAL_DIR" set "LOCALDIR=%%b"
  if "%%a"=="LOCAL_GUIDE" set "LOCALGUIDE=%%b"
)
title %LIBNAME% - %AREA% local pack only
echo ================================================================
echo   LOCAL PACK ONLY: %AREA%
echo.
echo   Downloads just the local pack (the area's books, topo maps,
echo   local rules and regulations, gardening, wildfire, radio/weather
echo   guides) plus the how-to guides. A few GB - minutes, not hours.
echo.
echo   Use it to:
echo    - try things out before the big download, or
echo    - refresh the local pack later (e.g. new regulations).
echo.
echo   When asked where to save, give the SAME place you use for the
echo   full library (e.g. E:\) so everything stays in one folder.
echo ================================================================
echo.
if not exist "%~dp0Get-OfflineLibrary.ps1" (
  echo ERROR: Get-OfflineLibrary.ps1 was not found next to this file.
  echo Unzip the whole folder first, then run this file from inside it.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Get-OfflineLibrary.ps1" -LocalOnly
echo.
echo Done. In the place you chose, open OfflineLibrary\%LOCALDIR%\%LOCALGUIDE%.html
pause
