@echo off
cd /d "%~dp0"
rem the library's name and the area's folder (local\region.env, written by tools/region.py)
set "LIBNAME=Offline Library" & set "AREA=Local" & set "LOCALDIR=Local" & set "LOCALGUIDE=START-HERE"
if exist "%~dp0local\region.env" for /f "usebackq tokens=1,* delims==" %%a in ("%~dp0local\region.env") do (
  if "%%a"=="LIBRARY_NAME" set "LIBNAME=%%b"
  if "%%a"=="AREA_NAME" set "AREA=%%b"
  if "%%a"=="LOCAL_DIR" set "LOCALDIR=%%b"
  if "%%a"=="LOCAL_GUIDE" set "LOCALGUIDE=%%b"
)
title %LIBNAME% - Community kit
echo ================================================================
echo   COMMUNITY KIT - the version to share with neighbors
echo.
echo   About 10 GB: all the plain-English guides and the Illinois
echo   Valley books, plus the Library Assistant with a small offline
echo   AI that runs on almost anything - Windows, Mac, Linux,
echo   Raspberry Pi, and Android tablets and phones.
echo.
echo   Fits on a 16 GB or larger USB stick or SD card.
echo   (No full Wikipedia or US maps - use INSTALL-Windows for those.)
echo.
echo   When it is done, open START-ON-ANY-DEVICE.html on the drive.
echo ================================================================
echo.
if not exist "%~dp0Get-OfflineLibrary.ps1" (
  echo ERROR: Get-OfflineLibrary.ps1 was not found next to this file.
  echo Unzip the whole folder first, then run this file from inside it.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Get-OfflineLibrary.ps1" -Community
echo.
echo Done. In the place you chose, open the OfflineLibrary folder, then START-ON-ANY-DEVICE.html
pause
