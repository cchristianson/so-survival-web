// The library's map (MAP.html): streets, topo lines, property lines and a stack of layers to switch on and off,
// drawn by MapLibre GL from the map files next to it (see README.md). Works on a phone and on a wide screen:
// one panel does everything (layers, what's here, measuring, pins, printing), a sheet from the bottom on a phone
// and a column on the left on a wide screen.
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var http = location.protocol.indexOf('http') === 0;
  // through the Library Assistant (on this device, or shared over Wi-Fi) the page is under /lib/; otherwise it's the website
  var drive = http && location.pathname.indexOf('/lib/') === 0;
  var hash0 = location.hash;   // where the map was looking when the page was opened (#zoom/lat/lng), before the map writes its own
  if (drive) document.querySelectorAll('a[data-app]').forEach(function (a) { a.href = a.getAttribute('data-app'); });
  var DATA = new URL(drive ? 'data/' : '../../maps/', location.href).href;
  var say = function (html) { $('msg').innerHTML = html; $('msg').hidden = !html; };
  var store = { get: function (k, d) { try { var v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} } };

  if (!http) {
    say('<b>The map needs the library to be running.</b><br>Start the library first (the <b>START</b> file for your device), then open <b>Tools → Map</b>. A page opened straight from the drive can\'t read the map files.');
    $('tools').hidden = true; return;
  }
  if (!window.maplibregl || !window.WebGLRenderingContext) { say('This browser can\'t draw the map. Try a newer browser (Chrome, Safari, Firefox or Edge).'); return; }

  // Who manages the land (BLM's own codes), in the colours BLM's maps use
  var OWN = { BLM: ['BLM (Bureau of Land Management)', '#fee679'], USFS: ['National Forest', '#a9d18e'], NPS: ['National Park Service', '#b9a3d8'],
    FWS: ['Fish & Wildlife Service', '#7fd1b9'], BIA: ['Tribal / Bureau of Indian Affairs', '#fdb46c'], DOD: ['Military', '#f4b6c2'], COE: ['Army Corps of Engineers', '#f4b6c2'],
    BR: ['Bureau of Reclamation', '#ffd9a0'], ST: ['State of Oregon', '#9fd0ff'], STF: ['State forest', '#9fd0ff'], STP: ['State park', '#9fd0ff'], STL: ['State lands', '#9fd0ff'],
    STW: ['State wildlife area', '#9fd0ff'], LG: ['County or city', '#d7b5e8'], PV: ['Private', ''], PVI: ['Private (timber company)', ''], PVN: ['Private', ''], PVU: ['Private', ''],
    UND: ['Not recorded', ''], WATER: ['Water', ''] };
  var ownName = function (c) { return OWN[c] ? OWN[c][0] : c; };

  // ---- the little round signs for places (drawn from the device's own emoji, so they need no picture files)
  var BADGE = { spring: '💧', fall: '🌊', dam: '🧱', med: '🏥', vet: '🐾', fuel: '⛽', food: '🛒', supply: '🔧', fire: '🚒', police: '🚓', school: '🏫', hall: '🏛️',
    camp: '⛺', trailhead: '🥾', air: '✈️', tap: '🚰', wc: '🚻', evac: '🚩', bridge: '🌉', pin: '📌', shared: '📍', gate: '🚧', block: '⛔', tower: '📡', lookout: '🔭' };
  var PLACE = { med: 'Medical', vet: 'Vet', fuel: 'Fuel', food: 'Food store', supply: 'Hardware, feed or repair', fire: 'Fire station', police: 'Police or ranger', school: 'School',
    hall: 'Hall, church, library or post office', camp: 'Camp or recreation site', air: 'Airstrip', tap: 'Drinking water', wc: 'Toilets', evac: 'Evacuation point', bridge: 'Bridge' };
  function addBadge(m, id) {
    var em = BADGE[id.replace(/^b-/, '')]; if (!em || m.hasImage(id)) return;
    var c = document.createElement('canvas'); c.width = c.height = 56; var g = c.getContext('2d');
    g.beginPath(); g.arc(28, 28, 25, 0, 7); g.fillStyle = '#fff'; g.fill(); g.lineWidth = 2.5; g.strokeStyle = '#4a5565'; g.stroke();
    g.font = '30px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(em, 28, 30);
    m.addImage(id, g.getImageData(0, 0, 56, 56), { pixelRatio: 2 });
  }

  // ---- the layers: what the panel lists, in this order. "src" is the layer in the map files it needs (left out of
  // the panel when the area's files don't have it), "layers" the drawn layers it switches, "legend" [colour, words, shape].
  var WF = { nut: ['#8d6e63', 'Nuts and acorns'], berry: ['#7b1fa2', 'Berries'], fruit: ['#d81b60', 'Fruit'], root: ['#ef6c00', 'Roots and bulbs'], green: ['#2e7d32', 'Greens'], mushroom: ['#b08d57', 'Mushrooms'] };
  var MINE = { gold: ['#f5b301', 'Gold'], chrome: ['#607d8b', 'Chromite'], copper: ['#bf5b17', 'Copper'], lime: ['#e0e0e0', 'Limestone (lime)'], clay: ['#a1543f', 'Clay'],
    stone: ['#9e9e9e', 'Stone, sand, gravel'], coal: ['#212121', 'Coal'], metal: ['#455a64', 'Other metals'], mineral: ['#ec407a', 'Other minerals'] };
  var ROAD = { car: ['#2b8a3e', 'open: an ordinary car can drive it'], high: ['#f08c00', 'open, but rough: high clearance'], season: ['#1c7ed6', 'closed part of the year'],
    closed: ['#c92a2a', 'gated or closed to vehicles'], unk: ['#868e96', 'not recorded'] };
  // trails, by who may use them (the widest use decides the colour)
  var TRAIL = { f: ['#8f5b2e', 'on foot only'], h: ['#c2410c', 'horses too'], b: ['#0b7285', 'bicycles too'], m: ['#be185d', 'motorbikes too'], x: ['#868e96', 'not recorded'] };
  var TRAILCLASS = { 1: 'Faint and rough: easy to lose in places', 2: 'Narrow and rough, but you can follow it', 3: 'A clear, regular trail',
    4: 'A wide, smooth trail', 5: 'Wide and even: paved or gravel' };
  // one town's routes on the map: [words, colour]
  var ROUTEWAY = { back: ['Back roads', '#7b2cbf'], hwy: ['Highway', '#e8590c'], bike: ['Bicycle route', '#1971c2'] };
  var TRAILUSE = { f: 'on foot', h: 'on horseback', b: 'by bicycle', m: 'on motorbikes', v: 'on ATVs' };
  var HAB = { winter: ['#1d4ed8', 'winter gathering ground'], summer: ['#f59e0b', 'summer gathering ground'], major: ['#65a30d', 'here all year, in good numbers'],
    edge: ['#bfe37a', 'here all year, fewer'], town: ['#9ca3af', 'around farms and towns'] };
  var GAME = { deer: ['#a16207', 'Deer'], elk: ['#7c2d12', 'Elk'], bear: ['#111827', 'Black bear'], bird: ['#0e7490', 'Game birds'], small: ['#9333ea', 'Rabbits, hares, squirrels'] };
  var ROCK = { serp: ['#2a9d8f', 'Serpentine and peridotite', 'Thin red soil where little grows. Chromite and nickel are found in it. Dust from some of it holds asbestos: don\'t crush or grind it.'],
    lime: ['#4ea8de', 'Limestone or marble', 'Burned in a kiln it makes lime for mortar, plaster and sweetening soil. Caves and sinkholes form in it.'],
    gravel: ['#f4d35e', 'River sand, gravel and clay', 'Loose ground laid down by rivers: building sand and gravel, clay for bricks and pots, the best ground for wells and gardens, and where placer gold settles.'],
    granite: ['#e56b6f', 'Granite-like rock', 'Hard, even stone for building and millstones. It weathers to coarse sand that drains fast.'],
    volcanic: ['#8e44ad', 'Lava rock (basalt, andesite)', 'Hard, dark rock: good crushed rock for roads, and tough building stone.'],
    sand: ['#d4a373', 'Sandstone', 'Easy to cut for building, and good for sharpening stones. Often carries springs.'],
    mud: ['#8d99ae', 'Mudstone, shale or slate', 'Soft rock that breaks down into clay. Slopes on it slide when wet, and springs are few.'],
    meta: ['#b5838d', 'Schist and mixed hard rock', 'Hard, folded rock of mixed kinds. Quartz veins in rock like this are where lode gold was mined.'], other: ['#cccccc', 'Other rock', ''] };
  var VEG = { fir: ['Fir, Douglas-fir, hemlock', 'Straight softwood for building; fair firewood.'], mixed: ['Douglas-fir with tanoak and madrone', 'Douglas-fir for building; tanoak and madrone for acorns and hot-burning firewood.'],
    pine: ['Pine', 'Easy-to-work building wood, pitch for starting fires, and pine nuts from some kinds.'], oak: ['Oak', 'Acorns for food, and the best firewood.'],
    cedar: ['Cedar or redwood', 'Wood that resists rot: posts, shakes, boats.'], hard: ['Alder, maple, other broadleaf trees', 'Firewood, smoking wood, tool handles.'],
    wet: ['Streamside woods and marsh', 'Water is near. Willow and cattail for weaving; good ground for wildlife.'], brush: ['Brush', 'Thick brush: hard to walk through, and it burns fiercely.'],
    grass: ['Grass and meadow', 'Open ground: grazing, hay, easy walking.'], farm: ['Fields and pasture', 'Cleared, worked ground.'], rock: ['Bare rock', 'Bare rock or scree.'] };
  var LAYERS = [
    ['Base map', [
      // the photos cover the map's own colours; the buildings and lakes drawn over them would hide what the photos show
      { id: 'sat', title: 'Satellite photo', note: 'Photos taken from the air', layers: ['sat'], need: 'satellite', hides: ['buildings', 'water'] },
      { id: 'contours', title: 'Topo lines', note: 'Lines of equal height, in feet', layers: ['contour-lines', 'contour-labels'], on: true, need: 'terrain' },
      { id: 'shade', title: 'Shaded hills', layers: ['hillshade'], on: true, need: 'terrain' },
      { id: 'steep', title: 'Steep ground', note: 'The darker, the steeper', layers: ['steep'], need: 'terrain',
        legend: [['#fff3b0', 'gentle'], ['#ffc65c', 'moderate'], ['#f58b3c', 'steep'], ['#d9480f', 'very steep'], ['#7b2cbf', 'cliffs']] },
      { id: 'sunny', title: 'Sunny slopes', note: 'Ground that faces south: warmest, best for gardens and solar', layers: ['sunny'], need: 'terrain', legend: [['#ffcc33', 'faces south']] }]],
    ['Land', [
      { id: 'parcels', title: 'Property lines', note: 'Tap a lot for its number, acres and owner', layers: ['parcel-lines', 'parcel-hit'], on: true, need: 'parcels', legend: [['#d9480f', 'tax lot', 'ln']] },
      { id: 'own', title: 'Who manages the land', note: 'Public land in color; private land has none', layers: ['own-fill', 'own-line'], on: true, need: 'ownership' },
      { id: 'sections', title: 'Section grid', note: 'Township, range and section, as on deeds and old maps', layers: ['sections', 'townships', 'section-labels'], src: 'sections' }]],
    ['Water', [
      { id: 'streams', title: 'Creeks: year-round or seasonal', layers: ['streams-y', 'streams-s', 'streams-d'], src: 'streams',
        legend: [['#1565c0', 'runs all year', 'ln'], ['#5aa9e6', 'dry part of the year', 'ln'], ['#00897b', 'ditch or canal', 'ln']] },
      { id: 'springs', title: 'Springs and waterfalls', layers: ['springs'], src: 'springs', legend: [['', '💧 spring'], ['', '🌊 waterfall']] },
      { id: 'wells', title: 'Wells', note: 'From the state\'s well reports: how deep people had to drill', layers: ['wells'], src: 'wells',
        legend: [['#2b8a3e', 'under 75 ft', 'dot'], ['#f08c00', '75 to 200 ft', 'dot'], ['#c92a2a', 'over 200 ft', 'dot']] },
      { id: 'dams', title: 'Dams and ponds behind them', layers: ['dams'], src: 'dams' }]],
    ['Food and growing', [
      { id: 'soils', title: 'Good growing ground', note: 'The Soil Survey\'s rating without irrigation', layers: ['soils'], src: 'soils',
        legend: [['#1b7f3b', 'best cropland'], ['#7cb342', 'good, with care'], ['#c0ca33', 'fair: limited crops']] },
      { id: 'wildfood', title: 'Wild food sightings', note: 'Where people have recorded edible plants and mushrooms. A sighting is not a promise, and never eat anything on a map\'s word: check it in the guides', layers: ['wildfood'], src: 'wildfood',
        legend: Object.keys(WF).map(function (k) { return [WF[k][0], WF[k][1], 'dot']; }) },
      { id: 'fish', title: 'Salmon and trout streams', layers: ['fish-trout', 'fish-salmon'], src: 'fish', legend: [['#e8590c', 'salmon, steelhead', 'ln'], ['#845ef7', 'trout', 'ln']] },
      { id: 'frost', title: 'Frost pockets', note: 'Low, flat ground where cold air settles on still nights: frost comes earlier in fall and stays later in spring. Worked out from the shape of the ground, so take it as a guide',
        layers: ['frost'], need: 'terrain', legend: [['#5b7cfa', 'coldest hollows'], ['#a9c1ff', 'cool flats']] }]],
    ['Hunting', [
      { id: 'deer_elk', title: 'Deer and elk country', note: 'Where the state\'s wildlife staff say deer and elk live, and where they gather by season', layers: ['deer-elk'], src: 'deer_elk',
        legend: Object.keys(HAB).map(function (k) { return [HAB[k][0], HAB[k][1]]; }) },
      { id: 'game', title: 'Game sightings', note: 'Where people have recorded game animals and birds. A sighting is not a promise', layers: ['game'], src: 'game',
        legend: Object.keys(GAME).map(function (k) { return [GAME[k][0], GAME[k][1], 'dot']; }) },
      { id: 'hunt_units', title: 'Hunting units', note: 'The state\'s units, as the hunting rules name them', layers: ['hunt-units', 'hunt-unit-names'], src: 'hunt_units', legend: [['#3f6212', 'unit edge', 'ln']] }]],
    ['Materials', [
      { id: 'timber', title: 'Timber: what grows where', note: 'The main trees or cover, from the national vegetation map. Good to about a city block', layers: ['timber'], src: 'timber', raster: true },
      { id: 'rocks', title: 'Rock types', note: 'The rock under the ground. Tap for what it is good for', layers: ['rocks'], src: 'rocks',
        legend: Object.keys(ROCK).filter(function (k) { return k !== 'other'; }).map(function (k) { return [ROCK[k][0], ROCK[k][1]]; }) },
      { id: 'mines', title: 'Mines, quarries and mineral sites', note: 'Old workings are dangerous: stay out of shafts and tunnels', layers: ['mines'], src: 'mines',
        legend: Object.keys(MINE).map(function (k) { return [MINE[k][0], MINE[k][1], 'dot']; }) }]],
    ['Hazards', [
      { id: 'fires', title: 'Past wildfires', note: 'Burned areas, by when they burned', layers: ['fires', 'fires-line'], src: 'fires',
        legend: [['#c92a2a', '2020 on'], ['#e8590c', '2010s'], ['#d9a02b', '2000s'], ['#8d7b68', 'before 2000']] },
      { id: 'flood', title: 'Flood zones', note: 'Ground a big flood covers (FEMA\'s 1-in-100-year flood)', layers: ['flood'], src: 'flood', legend: [['#3b82f6', 'flood zone']] },
      { id: 'landslides', title: 'Old landslides', note: 'Ground that has slid before can slide again', layers: ['landslides'], src: 'landslides', legend: [['#8d5524', 'slide deposit']] }]],
    ['Places and getting around', [
      { id: 'places', title: 'Useful places', note: 'Medical, fuel, food, fire stations, bridges, camps, halls', layers: ['poi'], src: 'places',
        legend: ['med', 'fuel', 'food', 'supply', 'fire', 'bridge', 'camp', 'hall', 'school', 'evac'].map(function (k) { return ['', BADGE[k] + ' ' + PLACE[k].toLowerCase()]; }) },
      { id: 'backroads', title: 'Forest and BLM roads', note: 'The number on the road sign, and whether you can drive it. A closed road is still a way on foot', layers: ['backroads', 'backroad-nums'], src: 'backroads',
        legend: Object.keys(ROAD).map(function (k) { return [ROAD[k][0], ROAD[k][1], 'ln']; }) },
      { id: 'trails', title: 'Trails', note: 'Forest Service, BLM and park trails: the number on the sign, who may use them and how rough they are. Smaller paths from the street map show as dots',
        layers: ['trails-case', 'trails', 'trail-names', 'trailheads'], src: 'trails',
        legend: ['f', 'h', 'b', 'm'].map(function (k) { return [TRAIL[k][0], TRAIL[k][1], 'ln']; }).concat([['', '🥾 trailhead']]) },
      { id: 'gates', title: 'Gates and road blocks', note: 'On BLM roads. A gate may be locked: know another way round', layers: ['gates'], src: 'gates', legend: [['', '🚧 gate'], ['', '⛔ road blocked']] },
      { id: 'towers', title: 'Radio towers and fire lookouts', note: 'High ground with a road to it. Lookouts have the widest views', layers: ['towers'], src: 'towers', legend: [['', '📡 radio site'], ['', '🔭 fire lookout']] },
      { id: 'escape', title: 'Escape routes', note: 'The county\'s back ways out when the main road is cut', layers: ['escape'], src: 'escape', legend: [['#2f9e44', 'escape route', 'ln']] },
      { id: 'routes', title: 'Walking routes to other towns', note: 'The back-road routes near home. To see one town\'s routes all the way, search for the town, or pick it under Routes', layers: ['routes'], src: 'routes', legend: [['#7b2cbf', 'route', 'ln']] },
      { id: 'pins', title: 'Pins', note: 'Your own marks, and the ones shared on this library', layers: ['pins', 'shared-pins'], on: true },
      { id: 'people', title: 'People on the mesh', note: 'Where each mesh radio was last heard from, and where it has been. Only radios that know where they are', layers: ['mesh-vague', 'mesh-track', 'mesh-dot', 'mesh-name'], on: true, mesh: true,
        legend: [['#e8590c', 'where they are', 'pt'], ['#e8590c', 'where they have been', 'ln']] }]]
  ];

  // is a mesh radio plugged into this library? asked once, before the layer panel is built, so the
  // People group is offered only where there is something to hear
  var meshStatus = drive ? fetch('/api/mesh/status', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; })
    : Promise.resolve(null);
  var haveMesh = false;

  fetch(DATA + 'index.json').then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (cfg) {
    return meshStatus.then(function (m) { haveMesh = !!(m && m.state && m.state !== 'off'); return cfg; });
  }).then(function (cfg) {
    if (!drive) return farMap(cfg);
    // on a drive there may be a bigger map too (Settings > A bigger map): its streets and heights take the local ones' place
    var sat = fetch(DATA + 'satellite.json').then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; });
    return fetch(DATA + 'wide.json').then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }).then(function (w) {
      return sat.then(function (d) { if (d && d.file && cfg.satellite) cfg.satDetail = d; return w; });
    }).then(function (w) {
      cfg.home = cfg.bbox;
      if (w && w.streets) { cfg.streets = w.streets; cfg.streetsV = w.v; cfg.bbox = w.bbox; if (w.terrain) cfg.terrain = w.terrain; cfg.wideLabel = w.label; cfg.widePlaces = w.places; cfg.streets_maxzoom = w.streets_maxzoom || 15; }
      return cfg;
    });
  }).then(start).catch(function (e) {
    if (e && e.stack && window.console) console.error(e);
    say('<b>The map files aren\'t here yet.</b><br>' + (drive ? 'Run the installer again: it fetches the map with everything else.' : 'They may still be on their way: try again later.'));
  });

  // On the website the library may keep a bigger map online ("online" in index.json: the address of a folder with the
  // same wide.json and street file a drive's bigger map has, and where heights can be had tile by tile). It is used
  // only for what the map on this device does not have, and only while there is a signal: the local map is never
  // waited for it. What the folder holds is remembered, so the next visit does not wait to ask.
  function farMap(cfg) {
    var on = cfg.online; cfg.home = cfg.bbox;
    if (!on || !on.url) return cfg;
    var base = on.url.replace(/\/?$/, '/'), kept = store.get('arkFar', null);
    var use = function (w) {
      if (w && w.streets && w.bbox) cfg.far = { label: w.label || 'a wider area', bbox: w.bbox, streets: base + w.streets + (w.v ? '?v=' + w.v : ''), streets_maxzoom: w.streets_maxzoom || 15,
        places: w.places ? base + w.places : '', terrain: on.terrain || '', terrain_maxzoom: on.terrain_maxzoom || 12 };
      return cfg;
    };
    var ask = function () {
      var ac = window.AbortController ? new AbortController() : null, t = setTimeout(function () { if (ac) ac.abort(); }, 2500);
      return fetch(base + 'wide.json', ac ? { signal: ac.signal } : {}).then(function (r) { clearTimeout(t); if (!r.ok) throw 0; return r.json(); })
        .then(function (w) { store.set('arkFar', { url: base, w: w }); return w; });
    };
    if (kept && kept.url === base && kept.w) { if (navigator.onLine) ask().catch(function () {}); return use(kept.w); }
    if (!navigator.onLine) return cfg;
    return ask().then(use, function () { return cfg; });
  }

  // Heights from two places as one: the tiles on this device (the map's own area) and, for the rest, a far source read
  // over the internet. The map and the tools ask this for a tile and never know which it came from. Topo lines need a
  // tile's neighbours too, so along the edge of the local area they come from the far source while there is a signal.
  function heights(near, far, cfg) {
    var hb = cfg.home || cfg.bbox, top = cfg.terrain.maxzoom;
    var span = function (z) {
      var n = Math.pow(2, z), tx = function (lon) { return Math.floor((lon + 180) / 360 * n); };
      var ty = function (lat) { var sn = Math.sin(lat * Math.PI / 180); return Math.floor((0.5 - Math.log((1 + sn) / (1 - sn)) / (4 * Math.PI)) * n); };
      return [tx(hb[0]), ty(hb[3]), tx(hb[2]), ty(hb[1])];
    };
    var local = function (z, x, y, ring) { var r = span(z), k = ring ? 1 : 0; return x >= r[0] + k && x <= r[2] - k && y >= r[1] + k && y <= r[3] - k; };
    var pick = function (z, x, y, ring) { return !far || !navigator.onLine || local(z, x, y, ring) ? near : far; };
    var zxy = function (url) { var m = /:\/\/(\d+)\/(\d+)\/(\d+)/.exec(url); return [+m[1], +m[2], +m[3]]; };
    var at = function (pattern, t) { return pattern.replace('{z}', t[0]).replace('{x}', t[1]).replace('{y}', t[2]); };
    return {
      sharedDemProtocolUrl: 'ark-dem://{z}/{x}/{y}',
      contourProtocolUrl: function (o) { return 'ark-contour://{z}/{x}/{y}?' + near.contourProtocolUrl(o).split('?')[1]; },
      getDemTile: function (z, x, y) {
        var s = pick(z, x, y);
        return s.getDemTile(z, x, y).catch(function (e) { if (s === far && local(z, x, y)) return near.getDemTile(z, x, y); throw e; });
      },
      demTile: function (params, abort) {
        var t = zxy(params.url), s = pick(t[0], t[1], t[2]), go = function (src) { return src.sharedDemProtocolV4({ url: at(src.sharedDemProtocolUrl, t) }, abort); };
        return go(s).catch(function (e) { if (s === far && local(t[0], t[1], t[2])) return go(near); throw e; });
      },
      contourTile: function (params, abort) {   // a tile of topo lines is worked out from the height tile one zoom coarser (never finer than the finest there is)
        var t = zxy(params.url), q = params.url.split('?')[1] || '', dz = Math.min(Math.max(t[0] - 1, 0), top), sh = t[0] - dz;
        var s = pick(dz, t[1] >> sh, t[2] >> sh, true), go = function (src) { return src.contourProtocolV4({ url: at(src.contourProtocolUrlBase, t) + '?' + q }, abort); };
        return go(s).catch(function (e) { if (s === far && local(dz, t[1] >> sh, t[2] >> sh)) return go(near); throw e; });
      }
    };
  }

  function start(cfg) {
    // A bigger map is fine near home and coarser far away, so many fine tiles are simply not in its files. For those
    // the reader reports an error (not an empty tile, and not "404", which the map would also take for an empty tile),
    // and the map then draws the coarser tile above, larger.
    var protocol = new pmtiles.Protocol({ errorOnMissingTile: true });
    maplibregl.addProtocol('pmtiles', protocol.tile);
    // The street map is asked for tile by tile: from the file on this device, and for a tile that is not in it, from
    // the bigger map kept online (the website, with a signal). No signal, or no such map: the tile is "not found".
    var streetsV = cfg.streetsV ? '?v=' + cfg.streetsV : (cfg.v ? '?v=' + cfg.v : '');
    var homePM = new pmtiles.PMTiles(DATA + cfg.streets + streetsV), farPM = cfg.far ? new pmtiles.PMTiles(cfg.far.streets) : null, farRest = 0;
    maplibregl.addProtocol('ark-streets', function (params, abort) {
      var m = /:\/\/(\d+)\/(\d+)\/(\d+)/.exec(params.url), z = +m[1], x = +m[2], y = +m[3], sig = abort && abort.signal;
      var gone = function () { throw new Error('Tile not found.'); };
      var from = function (pm) { return pm.getZxy(z, x, y, sig).then(function (r) { return r && r.data ? { data: new Uint8Array(r.data) } : gone(); }); };
      return from(homePM).catch(function () {
        if (!farPM || !navigator.onLine || Date.now() < farRest) return gone();
        return from(farPM).catch(function (e) {
          if (!/not found/i.test(String(e && e.message)) && !(sig && sig.aborted)) farRest = Date.now() + 20000;   // it did not answer: leave it be for a while
          return gone();
        });
      });
    });
    var terrainUrl = cfg.terrain ? (drive ? location.origin + '/maptiles/' + cfg.terrain.file.replace(/\.pmtiles$/, '') + '/{z}/{x}/{y}.webp' : DATA + 'terrain/{z}/{x}/{y}.webp') : '';
    var dem = null;
    cfg.reach = cfg.far ? cfg.far.bbox : cfg.bbox;   // how far the roads and the heights go
    if (terrainUrl) {
      var demSource = function (url, id, maxzoom, keep) { return new mlcontour.DemSource({ url: url, id: id, encoding: 'terrarium', maxzoom: maxzoom, worker: true, cacheSize: keep, timeoutMs: 20000 }); };
      dem = heights(demSource(terrainUrl, 'dem', cfg.terrain.maxzoom, 80), cfg.far && cfg.far.terrain ? demSource(cfg.far.terrain, 'far', Math.min(cfg.far.terrain_maxzoom, cfg.terrain.maxzoom), 60) : null, cfg);
      maplibregl.addProtocol('ark-dem', dem.demTile);
      maplibregl.addProtocol('ark-contour', dem.contourTile);
      maplibregl.addProtocol('ark-slope', slopeTiles(dem));
    }
    // which of the layers this area's files have
    var have = { terrain: !!cfg.terrain, parcels: !!(cfg.property && cfg.property.parcels), ownership: !!(cfg.property && cfg.property.ownership) };
    (cfg.overlays || []).forEach(function (o) { o.layers.forEach(function (l) { have[l] = true; }); });
    var V = cfg.v ? '?v=' + cfg.v : '';
    // Satellite photos, asked for picture by picture: from the files on this device first (on a drive, the full-detail
    // download if there is one, then the area's own file, which is less sharp close up), and for a picture they do not
    // have, from the photo server while there is a signal. None of them: "not found", and the map draws the less sharp
    // picture above it, larger.
    var satC = cfg.satellite, satRest = 0;
    if (satC) {
      var satPMs = [new pmtiles.PMTiles(DATA + satC.file + V)];
      if (cfg.satDetail) satPMs.unshift(new pmtiles.PMTiles(DATA + cfg.satDetail.file + (cfg.satDetail.v ? '?v=' + cfg.satDetail.v : '')));
      have.satellite = true;
      maplibregl.addProtocol('ark-sat', function (params, abort) {
        var m = /:\/\/(\d+)\/(\d+)\/(\d+)/.exec(params.url), z = +m[1], x = +m[2], y = +m[3], sig = abort && abort.signal, i = 0;
        var gone = function () { throw new Error('Tile not found.'); };
        var next = function () {
          if (i < satPMs.length) return satPMs[i++].getZxy(z, x, y, sig).then(function (r) { return r && r.data ? { data: new Uint8Array(r.data) } : next(); }, next);
          if (!satC.online || z > satC.online_maxzoom || !navigator.onLine || Date.now() < satRest) return gone();
          return fetch(satC.online.replace('{z}', z).replace('{x}', x).replace('{y}', y), sig ? { signal: sig } : {}).then(function (r) {
            if (!r.ok) gone();
            return r.arrayBuffer().then(function (b) { return { data: b }; });
          }).catch(function (e) {
            if (!/not found/i.test(String(e && e.message)) && !(sig && sig.aborted)) satRest = Date.now() + 20000;   // it did not answer: leave it be for a while
            return gone();
          });
        };
        return next();
      });
    }
    var vegOv = (cfg.overlays || []).filter(function (o) { return o.raster && o.group === 'timber'; })[0] || {}, vegPM = null;
    var ITEMS = [], GROUPS = {};
    LAYERS.forEach(function (g) { g[1].forEach(function (it) { if (it.id === 'pins' || (it.mesh ? haveMesh : have[it.need || it.src])) { ITEMS.push(it); GROUPS[it.id] = it.layers; } }); });
    ITEMS.forEach(function (it) {   // how sharp the photos are here, in the words under the switch
      if (it.id === 'sat') it.note = 'Photos taken from the air. ' + (cfg.satDetail ? 'Sharp enough to see houses, with no internet.'
        : drive ? 'Sharp close up while this computer has internet. For sharp ones without: More › Offline & downloads.' : 'Sharp close up while there is a signal; less so without.');
    });

    var b = cfg.reach;
    var S0 = style(cfg, dem), BASE = {};   // the layers as designed, to work each one's opacity out from
    JSON.parse(JSON.stringify(S0.layers)).forEach(function (l) { BASE[l.id] = l; });
    // Which layers are on, and how solid each is drawn: remembered on this device. The map starts out with only those.
    // (Every layer used to start out drawn and be hidden once the map had finished loading, so each opening fetched
    // and drew all of them, the heavy ones too: slow to open on a phone, and worse on a weak signal.)
    var saved = store.get('arkMapLayers', {});
    var isOn = function (it) { return it.id in saved ? !!saved[it.id] : !!it.on; };
    var OPROPS = { fill: ['fill-opacity'], line: ['line-opacity'], raster: ['raster-opacity'], circle: ['circle-opacity', 'circle-stroke-opacity'], symbol: ['icon-opacity', 'text-opacity'], hillshade: ['hillshade-exaggeration'] };
    var opac = store.get('arkMapOpacity', {});
    ITEMS.forEach(function (it) {
      var off = isOn(it) ? it.hides || [] : it.layers;
      S0.layers.forEach(function (l) { if (off.indexOf(l.id) >= 0) { l.layout = l.layout || {}; l.layout.visibility = 'none'; } });
      if (isOn(it) && opac[it.id] > 0) setOpacity(it, opac[it.id], S0);
    });
    var map = new maplibregl.Map({
      container: 'map', style: S0, center: [cfg.center[0], cfg.center[1]], zoom: cfg.center[2], minZoom: 2, maxZoom: 18,
      attributionControl: false, dragRotate: false, pitchWithRotate: false, hash: true,
      // The map's files do not change while the page is open. Left on, every tile on the screen is fetched and worked
      // out again each time its "keep until" time runs out (ten minutes, on the website).
      refreshExpiredTiles: false
    });
    // MapLibre 4.7 leaves a height tile marked "reloading" for good when its source is loaded again (as when Shaded hills
    // is switched off and on): the map then never counts as finished. Mark it loaded once the reload is done.
    map.once('style.load', function () {
      var src = map.getSource('dem'), load = src && src.loadTile;
      if (load) src.loadTile = function (tile) {
        return Promise.resolve(load.call(src, tile)).then(function (r) { if (tile.state === 'reloading' && tile.dem) tile.state = 'loaded'; return r; });
      };
    });
    // How far out it zooms: far enough to see the whole map at once on this screen, and a bit more for the country round
    // it. (The view used to be fenced to the map's own area, and on a tall phone the fence stopped the zoom before the
    // whole area showed.) Beyond the map's edge the coarser tiles that reach past it are drawn.
    function farthest() {
      var cam = map.cameraForBounds([[b[0], b[1]], [b[2], b[3]]], { padding: 10 });
      if (cam && isFinite(cam.zoom)) map.setMinZoom(Math.max(1.5, cam.zoom - 1.3));
    }
    farthest(); map.on('resize', farthest);
    // The middle of the screen stays on the map: let go of it beyond the edge, and the view slides back.
    map.on('moveend', function () {
      if (geo && /ACTIVE_LOCK|WAITING_ACTIVE/.test(geo._watchState || '')) return;   // following the blue dot, wherever it goes
      var c = map.getCenter(), lng = Math.max(b[0], Math.min(b[2], c.lng)), lat = Math.max(b[1], Math.min(b[3], c.lat));
      if (Math.abs(lng - c.lng) > 1e-6 || Math.abs(lat - c.lat) > 1e-6) map.easeTo({ center: [lng, lat], duration: 350 });
    });
    map.touchZoomRotate.disableRotation();
    map.on('styleimagemissing', function (e) { addBadge(map, e.id); });
    // A tile the files don't have (a bigger map is coarser far from home) is no fault: the map is asked to look again,
    // and on that look it fetches the coarser tile above the missing one. (Left alone it waits for the map to be moved.)
    var again = 0;
    map.on('error', function (e) {
      var m = String(e && e.error && e.error.message || '');
      if (/not found|404|bad response|no heights/i.test(m)) { if (!again) again = requestAnimationFrame(function () { again = 0; if (map._update) map._update(); else map.triggerRepaint(); }); }
      else if (!/abort/i.test(m) && window.console) console.warn('map:', m);
    });
    // A phone can take the map's drawing surface away (when it runs short of memory, or while the page is in the
    // background). Whether or not it gives it back, the map is left blank: MapLibre 4.7 does not draw again what it had
    // drawn before. So the page starts the map again where it was (the address holds the position; the layers and
    // pins are remembered). By itself at most once a minute, and never in the middle of measuring or typing: then it
    // says so and waits to be told.
    (function () {
      var dead = function () { try { return map.painter.context.gl.isContextLost(); } catch (e) { return false; } };
      var broken = false, asked = false, timer = 0;
      var restart = function () { try { sessionStorage.setItem('arkMapRestart', String(Date.now())); } catch (e) {} location.reload(); };
      var check = function () {
        timer = 0;
        if (document.hidden || !(broken || dead())) return;
        var last = 0; try { last = +sessionStorage.getItem('arkMapRestart') || 0; } catch (e) {}
        // "typing" is words in a box that would be lost (a pin's name or note): not the search box, and not a switch or slider
        var el = document.activeElement || {}, box = el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && !/^(checkbox|radio|range|file|button)$/.test(el.type || ''));
        var busy = measuring || (box && el.id !== 'q' && !!el.value);
        if (!busy && Date.now() - last > 60000) { restart(); return; }
        if (!asked) {
          asked = true;
          say('<b>The map stopped drawing.</b> <button class="btn" type="button" id="maprestart">Start the map again</button>');
          $('maprestart').onclick = restart;
        }
      };
      var soon = function (ms) { if (!timer) timer = setTimeout(check, ms); };
      map.on('webglcontextlost', function () { broken = true; soon(2500); });
      map.on('webglcontextrestored', function () { if (timer) { clearTimeout(timer); timer = 0; } soon(150); });
      document.addEventListener('visibilitychange', function () { if (!document.hidden) soon(1200); });
      addEventListener('pageshow', function () { soon(1200); });
    })();
    // Full screen: the top row and the app's buttons step aside so the map has the whole screen. One press brings them
    // back. It is remembered while this tab stays open, so a restart of the map (above) comes back the same way.
    (function () {
      var b = $('t-full'), on = false; if (!b) return;
      var set = function (v) {
        on = v; document.body.classList.toggle('full', on); b.classList.toggle('on', on);
        b.lastChild.nodeValue = on ? 'Exit' : 'Full'; b.setAttribute('aria-label', on ? 'Leave full screen' : 'Full screen map');
        try { sessionStorage.setItem('arkMapFull', on ? '1' : ''); } catch (e) {}
        setTimeout(function () { map.resize(); }, 60);
      };
      b.onclick = function () { set(!on); };
      try { if (sessionStorage.getItem('arkMapFull')) set(true); } catch (e) {}
    })();
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-left');
    map.addControl(new maplibregl.ScaleControl({ unit: 'imperial', maxWidth: 120 }), 'bottom-left');
    map.addControl(new maplibregl.AttributionControl({ compact: true }), 'bottom-right');
    window.arkMap = map;   // for testing

    // ---- the one panel
    var SHEETS = { layers: ['Layers', 't-layers', true], info: ['What\'s here', null, false], route: ['Walking route', null, false], measure: ['Measure', 't-measure', false], pins: ['My pins', 't-pins', true], print: ['Print this part of the map', 't-print', true] };
    var sheet = '';
    function openSheet(name, title) {
      if (sheet === 'measure' && name !== 'measure') endMeasure();
      sheet = name;
      Object.keys(SHEETS).forEach(function (k) { $('s-' + k).hidden = k !== name; if (SHEETS[k][1]) $(SHEETS[k][1]).classList.toggle('on', k === name); });
      $('sheettitle').textContent = title || SHEETS[name][0]; $('sheet').classList.toggle('tall', SHEETS[name][2]);
      $('sheet').hidden = false; document.body.classList.add('sheet-open'); $('results').hidden = true; $('sheetbody').scrollTop = 0;
      fitSheet();
    }
    function closeSheet() {
      if (sheet === 'measure') endMeasure();
      if (sheet === 'print') pr.seq++;
      sheet = ''; $('sheet').hidden = true; document.body.classList.remove('sheet-open');
      Object.keys(SHEETS).forEach(function (k) { if (SHEETS[k][1]) $(SHEETS[k][1]).classList.remove('on'); });
      if (pin && !pinKept) { pin.remove(); pin = null; }
    }
    $('sheetclose').onclick = closeSheet;
    // On a phone the panel is dragged taller or shorter by the handle at its top; each kind of panel (layers, what's
    // here, measure ...) keeps the height it was given, as a share of the screen. Pulled right down, it closes.
    var sheetSize = store.get('arkMapSheetSize', {});
    function fitSheet() {
      var el = $('sheet'), f = innerWidth < 820 && el.offsetParent ? sheetSize[sheet] : 0;
      el.style.height = f ? Math.round(Math.max(96, f * el.offsetParent.clientHeight)) + 'px' : ''; el.style.maxHeight = f ? 'none' : '';
    }
    (function () {
      var el = $('sheet'), y0 = 0, h0 = 0, h = 0, on = false;
      var move = function (e) {
        if (!on) return;
        h = Math.max(40, Math.min(el.offsetParent.clientHeight - 6, h0 + y0 - e.clientY)); el.style.maxHeight = 'none'; el.style.height = h + 'px'; e.preventDefault();
      };
      var end = function () {
        if (!on) return; on = false; el.classList.remove('drag');
        if (h < 84) { closeSheet(); return; }
        if (Math.abs(h - h0) > 4) { sheetSize[sheet] = Math.round(h / el.offsetParent.clientHeight * 1000) / 1000; store.set('arkMapSheetSize', sheetSize); }
        fitSheet();
      };
      [$('sheetgrip'), $('sheethead')].forEach(function (g) {
        g.addEventListener('pointerdown', function (e) {
          if (innerWidth >= 820 || (e.target.closest && e.target.closest('button'))) return;
          on = true; y0 = e.clientY; h0 = h = el.getBoundingClientRect().height; el.classList.add('drag');
          try { g.setPointerCapture(e.pointerId); } catch (err) {}
          e.preventDefault();
        });
        g.addEventListener('pointermove', move); g.addEventListener('pointerup', end); g.addEventListener('pointercancel', end);
      });
      addEventListener('resize', function () { if (sheet) fitSheet(); });
    })();
    var toggleSheet = function (name, then) { return function () { if (sheet === name) closeSheet(); else { openSheet(name); if (then) then(); } }; };

    // ---- layers: a switch for each, in groups that fold; what is on is remembered on this device
    var has = function (id) { return !!map.getLayer(id); };
    var show = function (ids, on) { ids.forEach(function (id) { if (has(id)) map.setLayoutProperty(id, 'visibility', on ? 'visible' : 'none'); }); };
    function legendHtml(it) {
      var lg = it.legend;
      if (it.id === 'own') lg = (cfg.property.owners || ['BLM', 'USFS', 'ST', 'LG']).filter(function (c) { return OWN[c] && OWN[c][1]; })
        .map(function (c) { return [OWN[c][1], c.indexOf('ST') === 0 ? 'State of Oregon' : OWN[c][0]]; }).filter(function (v, i, a) { return a.map(function (x) { return x[1]; }).indexOf(v[1]) === i; });
      if (it.id === 'timber') lg = (vegOv.classes || []).filter(function (c) { return VEG[c[0]]; }).map(function (c) { return [c[1], VEG[c[0]][0]]; });
      if (!lg) return '';
      return '<div class="legend" id="lg-' + it.id + '">' + lg.map(function (l) {
        return '<span>' + (l[0] ? '<i class="' + (l[2] || '') + '" style="' + (l[2] === 'ln' ? 'border-color:' : 'background:') + l[0] + '"></i>' : '') + esc(l[1]) + '</span>'; }).join('') + '</div>';
    }
    // ---- how solid each layer is drawn: a slider under its switch, remembered on this device
    function outs(e, fn) {   // an opacity can change with the zoom or with the thing drawn: fn on each value it can take
      if (typeof e === 'number') return fn(e);
      if (!Array.isArray(e)) return e;
      var o = e.slice(), i, n = e.length;
      if (e[0] === 'interpolate') for (i = 4; i < n; i += 2) o[i] = outs(e[i], fn);
      else if (e[0] === 'step') { o[2] = outs(e[2], fn); for (i = 4; i < n; i += 2) o[i] = outs(e[i], fn); }
      else if (e[0] === 'match') { for (i = 3; i < n - 1; i += 2) o[i] = outs(e[i], fn); o[n - 1] = outs(e[n - 1], fn); }
      else if (e[0] === 'case') { for (i = 2; i < n - 1; i += 2) o[i] = outs(e[i], fn); o[n - 1] = outs(e[n - 1], fn); }
      return o;
    }
    function baseOf(id, prop) { var l = BASE[id], v = l && l.paint ? l.paint[prop] : null; return v == null ? (prop === 'hillshade-exaggeration' ? 0.5 : 1) : v; }
    function designed(it) {   // how solid the layer is as it comes: its first drawn part, at its most solid
      for (var i = 0; i < it.layers.length; i++) {
        var l = BASE[it.layers[i]], props = l && OPROPS[l.type], mx = 0;
        if (!props) continue;
        outs(baseOf(l.id, props[0]), function (n) { mx = Math.max(mx, n); return n; });
        if (mx > 0) return mx;
      }
      return 1;
    }
    function setOpacity(it, t, st) {   // st: a style being put together for printing; without it, the map on the screen
      var k = t / designed(it);
      it.layers.forEach(function (id) {
        var l = BASE[id]; if (!l) return;
        (OPROPS[l.type] || []).forEach(function (prop) {
          var v = outs(baseOf(id, prop), function (n) { return Math.max(0, Math.min(1, Math.round(n * k * 1000) / 1000)); });
          if (st) st.layers.forEach(function (x) { if (x.id === id) { x.paint = x.paint || {}; x.paint[prop] = v; } });
          else if (map.getLayer(id)) map.setPaintProperty(id, prop, v);
        });
      });
    }
    var pct = function (it) { return Math.round((opac[it.id] > 0 ? opac[it.id] : designed(it)) * 100); };
    function opHtml(it) {
      if (it.id === 'pins') return '';
      return '<div class="op" id="op-' + it.id + '"><span>Opacity</span><input type="range" min="10" max="100" step="5" value="' + pct(it) + '" aria-label="Opacity of ' + esc(it.title) + '"><b>' + pct(it) + '%</b>' +
        '<button type="button" title="Back to normal" aria-label="Back to normal"' + (opac[it.id] > 0 ? '' : ' hidden') + '>↺</button></div>';
    }
    function renderLayers() {
      var open = store.get('arkMapOpen', { 'Base map': true, Land: true });
      $('layerlist').innerHTML = LAYERS.map(function (g) {
        var its = g[1].filter(function (it) { return GROUPS[it.id]; }); if (!its.length) return '';
        var n = its.filter(isOn).length;
        return '<details class="grp" data-g="' + esc(g[0]) + '"' + (open[g[0]] ? ' open' : '') + '><summary>' + esc(g[0]) + ' <span class="n">' + (n ? n + ' on' : '') + '</span></summary>' + its.map(function (it) {
          return '<label class="lay"><span class="sw"><input type="checkbox" id="l-' + it.id + '"' + (isOn(it) ? ' checked' : '') + '><span></span></span><span class="tx">' + esc(it.title) +
            (it.note ? '<small>' + esc(it.note) + '</small>' : '') + '</span></label>' + legendHtml(it) + opHtml(it);
        }).join('') + '</details>';
      }).join('');
      ITEMS.forEach(function (it) {
        var box = $('l-' + it.id), lg = $('lg-' + it.id), op = $('op-' + it.id);
        if (lg) lg.hidden = !box.checked;
        if (op) {
          op.hidden = !box.checked;
          var sl = op.querySelector('input'), lab = op.querySelector('b'), back = op.querySelector('button');
          sl.oninput = function () { setOpacity(it, sl.value / 100); lab.textContent = sl.value + '%'; };
          sl.onchange = function () { opac[it.id] = sl.value / 100; store.set('arkMapOpacity', opac); back.hidden = false; };
          back.onclick = function () { delete opac[it.id]; store.set('arkMapOpacity', opac); sl.value = pct(it); lab.textContent = sl.value + '%'; setOpacity(it, designed(it)); back.hidden = true; };
        }
        box.onchange = function () {
          show(it.layers, box.checked); if (it.hides) show(it.hides, !box.checked); saved[it.id] = box.checked; store.set('arkMapLayers', saved); if (lg) lg.hidden = !box.checked; if (op) op.hidden = !box.checked;
          var d = box.closest('details'), n = d.querySelectorAll('input:checked').length; d.querySelector('.n').textContent = n ? n + ' on' : '';
        };
      });
      $('layerlist').querySelectorAll('details').forEach(function (d) { d.ontoggle = function () { var o = store.get('arkMapOpen', { 'Base map': true, Land: true }); o[d.dataset.g] = d.open; store.set('arkMapOpen', o); }; });
    }
    renderLayers();
    // Pins go on as soon as the map's design is in, not when the last tile has arrived (on a weak signal that can be long).
    var pinsOn = false, putPins = function () { if (pinsOn) return; pinsOn = true; drawPins(); drawShared(); };
    map.once('style.load', putPins); map.once('load', putPins);
    $('propnote').hidden = !have.parcels;
    if (cfg.far) $('propnote').insertAdjacentHTML('afterend', '<p class="small">While this device has a signal, roads and topo lines also cover ' + esc(cfg.far.label) +
      ', in less detail the further from home. With no signal, and for the other layers, the map covers ' + esc(cfg.name) + '.</p>');
    if (cfg.wideLabel) $('propnote').insertAdjacentHTML('afterend', '<p class="small">Roads and topo lines cover ' + esc(cfg.wideLabel) + ', in less detail the further from home. The other layers cover ' + esc(cfg.name) + '.</p>');
    $('credits').innerHTML = 'Map data: ' + (cfg.credits || []).map(esc).join(' · ') + (cfg.built ? '. Made ' + esc(cfg.built) + '.' : '');
    $('t-layers').onclick = toggleSheet('layers');

    // ---- tap: what's here
    var pin = null, pinKept = false;
    var demGone = {};   // height tiles the files turned out not to have (a bigger map is coarser far from home)
    function elevationAt(lngLat) {
      if (!dem) return Promise.resolve(null);
      var top = cfg.terrain.maxzoom, low = cfg.far ? Math.max(0, top - 4) : Math.max(0, Math.min(top, cfg.terrain.coarsest || top));
      var sn = Math.sin(lngLat.lat * Math.PI / 180), wx = (lngLat.lng + 180) / 360, wy = 0.5 - Math.log((1 + sn) / (1 - sn)) / (4 * Math.PI);
      var at = function (z) {   // the finest tile first, then the coarser ones above it
        var n = Math.pow(2, z), fx = wx * n, fy = wy * n, tx = Math.floor(fx), ty = Math.floor(fy), key = z + '/' + tx + '/' + ty;
        var up = function () { demGone[key] = 1; return z > low ? at(z - 1) : null; };
        if (demGone[key]) return Promise.resolve(z > low ? at(z - 1) : null);
        return dem.getDemTile(z, tx, ty).then(function (t) {
          var px = Math.min(t.width - 1, Math.floor((fx - tx) * t.width)), py = Math.min(t.height - 1, Math.floor((fy - ty) * t.height));
          var m = t.data[py * t.width + px]; return isFinite(m) ? m : null;
        }, up);
      };
      return Promise.resolve(at(top)).catch(function () { return null; });
    }
    // the county writes owners in capitals ("SMITH JOHN & MARY"): easier to read with small letters, short words like LLC kept
    function ownerName(n) {
      return String(n).toLowerCase().replace(/[a-z][a-z']*/g, function (w) {
        return /^(llc|inc|co|usa|blm|ii|iii|iv|lp|llp|pc|na|dba|hoa|odot|odf|us)$/.test(w) ? w.toUpperCase() : /^(of|and|the|for|et|al)$/.test(w) ? w : w.charAt(0).toUpperCase() + w.slice(1);
      }).replace(/^[a-z]/, function (c) { return c.toUpperCase(); });
    }
    function lotName(lot) {   // Oregon map and tax lot: township, range, section, quarter, then the lot number
      var m = /^(\d\d)(\d\d)(\d\d)(\w\w)0*(\w+)$/.exec(lot || '');
      return m ? 'Tax lot ' + m[5] + ' <span class="small">(map ' + m[1] + '-' + m[2] + '-' + m[3] + (m[4] !== '00' ? '-' + m[4] : '') + ')</span>' : 'Tax lot ' + esc(lot);
    }
    // what a thing in one of the layers is, in words: -> [kind, title, [lines]]
    var CLASS = { 1: 'best cropland: few limits', 2: 'very good cropland: some care needed', 3: 'good cropland with care: fewer crops, or erosion to watch', 4: 'fair: only some crops, and careful handling' };
    function describe(f) {
      var p = f.properties, L = f.layer.id, out = [];
      var add = function (v) { if (v != null && v !== '') out.push(esc(v)); };
      if (L === 'springs') return [p.k === 'fall' ? 'Waterfall' : 'Spring', p.n || '', out];
      if (L.indexOf('streams') === 0) return ['Creek', p.n || '', [p.k === 'y' ? 'Runs all year' : p.k === 's' ? 'Seasonal: dry part of the year' : p.k === 'd' ? 'A ditch or canal' : '']];
      if (L === 'wells') { add(p.d + ' ft deep'); if (p.s) add('water stood ' + p.s + ' ft down when it was drilled'); if (p.f) add('first water at ' + p.f + ' ft'); if (p.y) add('drilled ' + p.y); return ['Well', '', out]; }
      if (L === 'dams') { if (p.h) add(p.h + ' ft high'); if (p.r) add('on ' + p.r); if (p.af) add('holds about ' + Math.round(p.af).toLocaleString() + ' acre-feet'); return ['Dam', p.n || '', out]; }
      if (L === 'soils') { add('Class ' + p.c + ': ' + (CLASS[p.c] || '')); add(p.n); if (p.d) add('Drainage: ' + String(p.d).toLowerCase()); return ['Growing ground', '', out]; }
      if (L === 'wildfood') { if (p.y) add('seen ' + p.y); add('A sighting, not a promise. Check any plant or mushroom in the guides before eating it.'); return ['Wild food', p.n || '', out]; }
      if (L.indexOf('fish') === 0) { add(p.n); if (p.u) add(String(p.u).replace(/([a-z])([A-Z])/g, '$1, $2').toLowerCase()); return ['Fish stream', p.sp || '', out]; }
      if (L === 'mines') { add(p.c); add(p.w); if (p.p) add('Produced: ' + p.p); add('Old workings are dangerous: stay out.'); return [(MINE[p.k] || ['', 'Mineral site'])[1] + ' site', p.n || '', out]; }
      if (L === 'fires') { if (p.a) add(Number(p.a).toLocaleString() + ' acres'); return ['Wildfire' + (p.y ? ', ' + p.y : ''), p.n || '', out]; }
      if (L === 'flood') return ['Flood zone', '', ['A big flood covers this ground' + (p.z ? ' (FEMA zone ' + esc(p.z) + ')' : '')]];
      if (L === 'landslides') { add(p.t); return ['Old landslide', p.n || '', out]; }
      if (L === 'poi') { add(p.d); return [(p.k === 'bridge' && p.r ? 'Bridge with a weight limit' : PLACE[p.k] || 'Place'), p.n || '', out]; }
      if (L === 'escape') { add(p.s); add(p.se); add(p.su); add(p.d); return ['Escape route', p.n || '', out]; }
      if (L === 'routes') return ['Walking route', 'One of the routes to other towns', ['<a href="' + esc(routesPage()) + '">Open the list of routes</a>']];
      if (L === 'backroads') { add(p.nm); add((ROAD[p.k] || ROAD.unk)[1].replace(/^./, function (c) { return c.toUpperCase(); })); if (p.s) add('Surface: ' + p.s); add(p.d);
        return [p.a === 'fs' ? 'Forest Service road' : 'BLM road', p.n ? 'Road ' + p.n : (p.nm || ''), out]; }
      if (L === 'trails' || L === 'trails-case') {
        out.push('Who may use it: ' + (p.u ? String(p.u).split('').map(function (c) { return TRAILUSE[c]; }).filter(Boolean).join(', ') : 'not recorded'));
        if (TRAILCLASS[p.c]) add(TRAILCLASS[p.c]); if (p.s) add('Surface: ' + p.s); if (p.mi) add('About ' + p.mi + ' miles of it on this map'); add(p.nt); add(p.o);
        return [{ fs: 'Forest Service trail', blm: 'BLM trail', nps: 'Park trail' }[p.a] || 'Trail', (p.n || 'Trail') + (p.no ? ' (trail ' + p.no + ')' : ''), out];
      }
      if (L === 'trailheads') return ['Trailhead', p.n || '', ['Where a trail starts: usually a sign, and room to park.']];
      if (L === 'gates') { add(p.k === 'gate' ? 'It may be locked. Know another way round.' : 'Blocked to vehicles with rocks, a berm or a barrier. Still a way on foot.'); return [p.k === 'gate' ? 'Gate' : 'Road block', '', out]; }
      if (L === 'towers') { if (p.k === 'lookout') { add('A high point with a wide view.'); return ['Fire lookout', p.n || '', out]; }
        add('Transmitters here: ' + (p.d || 'radio')); add('High ground with a road to it, and often its own power.'); return ['Radio site', '', out]; }
      if (L === 'hunt-units') return ['Hunting unit', (p.n || '') + (p.u ? ' (unit ' + p.u + ')' : ''), ['Seasons and tags go by unit: see the hunting rules in the local guides.']];
      if (L === 'deer-elk') return ['Deer and elk', '', [esc({ winter: 'Winter gathering ground: deer and elk crowd here from about November to April.', summer: 'Summer gathering ground.',
        major: 'They live here all year, in good numbers.', edge: 'They live here all year, but fewer of them.', town: 'Around farms and towns: deer and elk are here, and clash with people.' }[p.k] || '')]];
      if (L === 'game') { if (p.y) add('seen ' + p.y); add('A sighting, not a promise.'); return ['Game sighting', p.n || '', out]; }
      if (L === 'rocks') { var rk = ROCK[p.k] || ROCK.other; add(p.n); if (p.r) add('Mostly ' + p.r); add(rk[2]); return ['Rock', rk[1], out]; }
      if (L === 'sections') return ['Section grid', 'Section ' + (p.s || '?') + (p.t ? ', ' + p.t : ''), out];
      return null;
    }
    function routesPage() { var r = document.body.getAttribute('data-routes') || ''; return drive ? '/lib/' + r : '../walking-routes/WALKING-ROUTES.html'; }
    if ($('toroutes')) $('toroutes').href = routesPage();

    // ---- one town's walking routes, all the way there: from the routes page ("Show on the map")
    // or the search; ?route=<town> in the address. The lines are in the routes' own folder (tracks/<town>.json, made by build_routes_page.py).
    var RB = routesPage().replace(/[^\/]*$/, ''), towns = null, townsAsked = false, route = null, routeData = null, opened = false;
    map.once('load', function () { opened = true; });   // a move asked for before then is lost
    function loadTowns() {
      if (townsAsked) return; townsAsked = true;
      fetch(RB + 'towns.json').then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (t) { towns = t; if ($('q').value.trim()) search(); }).catch(function () {});
    }
    function unline(s) {   // Google's polyline code -> [[lon, lat], ...]
      var i = 0, la = 0, lo = 0, out = [];
      while (i < s.length) {
        for (var k = 0; k < 2; k++) {
          var sh = 0, r = 0, b;
          do { b = s.charCodeAt(i++) - 63; r |= (b & 31) << sh; sh += 5; } while (b >= 32);
          var d = (r & 1) ? ~(r >> 1) : (r >> 1); if (k) lo += d; else la += d;
        }
        out.push([lo / 1e5, la / 1e5]);
      }
      return out;
    }
    var footTime = function (mi) { if (mi < 15) { var h = Math.max(1, Math.round(mi / 3)); return 'about ' + h + ' hour' + (h > 1 ? 's' : '') + ' on foot'; } var d = Math.max(1, Math.round(mi / 15)); return 'about ' + d + ' day' + (d > 1 ? 's' : '') + ' on foot'; };
    function routeOn() {
      var on = {}; $('s-route').querySelectorAll('input[data-k]').forEach(function (c) { on[c.dataset.k] = c.checked; });
      ['back', 'hwy', 'bike'].forEach(function (k) { if (has('route-' + k)) map.setLayoutProperty('route-' + k, 'visibility', on[k] ? 'visible' : 'none'); });
      if (has('route-case')) map.setFilter('route-case', ['all', ['==', ['geometry-type'], 'LineString'], ['in', ['get', 'k'], ['literal', Object.keys(on).filter(function (k) { return on[k]; })]]]);
    }
    function showRoute(slug, fit) {
      fetch(RB + 'tracks/' + encodeURIComponent(slug) + '.json').then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (t) {
        route = slug; var feats = [], bb = new maplibregl.LngLatBounds(), out = false, rows = '';
        ['bike', 'hwy', 'back'].forEach(function (k) {
          if (!t[k]) return;
          var line = unline(t[k].line); feats.push({ type: 'Feature', geometry: { type: 'LineString', coordinates: line }, properties: { k: k } });
          line.forEach(function (p) { bb.extend(p); if (p[0] < cfg0[0] || p[0] > cfg0[2] || p[1] < cfg0[1] || p[1] > cfg0[3]) out = true; });
        });
        feats.push({ type: 'Feature', geometry: { type: 'Point', coordinates: t.start }, properties: { k: 'start', n: t.from } });
        feats.push({ type: 'Feature', geometry: { type: 'Point', coordinates: t.end }, properties: { k: 'end', n: t.n } });
        var go = function () {
          var src = map.getSource('route-pick'); if (!src) return;
          routeData = { type: 'FeatureCollection', features: feats }; src.setData(routeData);
          // the view may go as far as the route does (it is otherwise kept over the map's own area)
          b = [Math.min(cfg.reach[0], bb.getWest() - 0.2), Math.min(cfg.reach[1], bb.getSouth() - 0.2), Math.max(cfg.reach[2], bb.getEast() + 0.2), Math.max(cfg.reach[3], bb.getNorth() + 0.2)];
          farthest();
          ['back', 'hwy', 'bike'].forEach(function (k) {
            if (!t[k]) return;
            rows += '<label class="rway"><input type="checkbox" data-k="' + k + '" checked><i class="' + (k === 'bike' ? 'dash' : '') + '" style="background:' + ROUTEWAY[k][1] + ';color:' + ROUTEWAY[k][1] + '"></i><span><b>' + ROUTEWAY[k][0] + '</b> · ' +
              Math.round(t[k].mi) + ' miles<small>' + (k === 'bike' ? 'about ' + Math.max(1, Math.round(t[k].mi / 6.2)) + ' hours of riding with a load' : footTime(t[k].mi)) + '</small></span></label>';
          });
          var far = !out ? '' : drive ? (cfg.wideLabel ? '' : 'Past the edge of this map, the line shows with no roads under it. A drive can hold a bigger map for that: Settings, A bigger map.') :
            cfg.far ? 'Past the edge of this map, the roads under the line show while there is a signal.' : 'Past the edge of this map, the line shows with no roads under it.';
          $('s-route').innerHTML = '<p class="small">From ' + esc(t.from) + '. Switch each way on or off.</p>' + rows +
            '<div class="row"><a class="btn sm go" href="' + esc(RB + 'directions/' + slug + '.html') + '">Turn-by-turn directions</a><a class="btn sm" href="' + esc(RB + 'WALKING-ROUTES.html#' + slug) + '">Another town</a>' +
            '<button class="btn sm" type="button" id="r-clear">Take it off the map</button></div>' + (far ? '<p class="small">' + esc(far) + '</p>' : '');
          $('s-route').querySelectorAll('input[data-k]').forEach(function (c) { c.onchange = routeOn; });
          $('r-clear').onclick = clearRoute;
          routeOn(); openSheet('route', 'To ' + t.n + ', ' + t.st);
          if ($('toroutes')) $('toroutes').href = routesPage() + '#' + slug;
          if (wantRoute() !== slug) history.replaceState(null, '', location.pathname + '?route=' + encodeURIComponent(slug) + location.hash);
          if (fit !== false) {
            var r = $('sheet').getBoundingClientRect(), box = map.getContainer().getBoundingClientRect(), pad = { top: 50, bottom: 30, left: 30, right: 84 };   // right: clear of the buttons
            if (r.width < box.width * 0.6) pad.left = Math.max(30, r.right - box.left + 20); else pad.bottom = Math.max(30, box.bottom - r.top + 20);
            var fitNow = function () { map.fitBounds(bb, { padding: pad, maxZoom: 13, duration: opened ? 900 : 0 }); };
            if (opened) fitNow(); else map.once('load', fitNow);
          }
        };
        if (map.getSource('route-pick')) go(); else map.once('style.load', go);
      }).catch(function () { say('That route could not be found in this library.'); });
    }
    function clearRoute() {
      route = null; routeData = null; var src = map.getSource('route-pick'); if (src) src.setData({ type: 'FeatureCollection', features: [] });
      b = cfg.reach; farthest();
      if ($('toroutes')) $('toroutes').href = routesPage();
      if (wantRoute()) history.replaceState(null, '', location.pathname + location.hash);
      closeSheet();
    }
    // ?route=<town> (not after the #, which holds where the map is looking)
    function wantRoute() { var m = /[?&]route=([\w.-]+)/.exec(location.search); return m ? m[1] : null; }
    if (wantRoute()) showRoute(wantRoute(), !/^#[\d.]+\//.test(hash0));   // opened again where it was: stay there
    map.on('click', function (e) {
      $('results').hidden = true; say('');
      if (measuring) { addMeasure(e.lngLat); return; }
      var ll = e.lngLat, rows = [], facts = [], seen = {};
      var base = map.queryRenderedFeatures(e.point, { layers: ['parcel-hit', 'own-fill', 'own-hit'].filter(has) });
      var lot = base.filter(function (f) { return f.layer.id === 'parcel-hit'; })[0], own = base.filter(function (f) { return f.layer.id !== 'parcel-hit'; })[0];
      if (own) rows.push(['Land', esc(ownName(own.properties.own))]);
      if (lot) rows.push(['Property', lotName(lot.properties.lot) + (lot.properties.acres ? ', about ' + lot.properties.acres + ' acres' : '')]);
      if (lot && lot.properties.owner) rows.push(['Owner', esc(ownerName(lot.properties.owner)) + ' <span class="small">(county records' + (cfg.built ? ', ' + esc(cfg.built) + ')' : ')') + '</span>']);
      rows.push(['Position', ll.lat.toFixed(5) + ', ' + ll.lng.toFixed(5)]);
      // everything in the switched-on layers within a finger's width of the tap
      var ids = []; ITEMS.forEach(function (it) { if (it.src && !it.raster && $('l-' + it.id).checked) it.layers.forEach(function (l) { if (has(l)) ids.push(l); }); });
      var box = [[e.point.x - 12, e.point.y - 12], [e.point.x + 12, e.point.y + 12]];
      (ids.length ? map.queryRenderedFeatures(box, { layers: ids }) : []).forEach(function (f) {
        var d = describe(f); if (!d) return;
        var key = d[0] + '|' + d[1] + '|' + d[2].join('|'); if (seen[key] || facts.length >= 12) return; seen[key] = 1; facts.push(d);
      });
      var mine = has('pins') ? map.queryRenderedFeatures(box, { layers: ['pins', 'shared-pins'].filter(has) })[0] : null;
      // someone heard over the mesh: say when they were last heard, and how exact the position is
      var who = has('mesh-dot') ? map.queryRenderedFeatures(box, { layers: ['mesh-dot'] })[0] : null;
      var wp = has('mesh-wp') ? map.queryRenderedFeatures(box, { layers: ['mesh-wp'] })[0] : null;
      if (wp) {
        var wq = wp.properties, wb = [];
        if (wq.note) wb.push(esc(wq.note));
        wb.push('Put on the mesh ' + (wq.by ? 'by ' + esc(wq.by) + ' ' : '') + agoWords(wq.age) + '. Everyone on the mesh sees it.');
        if (wq.expire > 0) wb.push('It goes away by itself later.');
        facts.unshift(['Mesh waypoint', (wq.icon ? wq.icon + ' ' : '') + wq.name, wb]);
      }
      if (who) {
        var pp = who.properties, bits = [];
        bits.push('Last heard ' + agoWords(pp.age));
        if (pp.vague > 0) bits.push('<b>The position is rounded</b> to about ' + roundWords(pp.vague) + ', so they are somewhere in the circle. A private channel with full precision gives an exact spot.');
        else bits.push('Full precision.');
        if (pp.heard > pp.age + 120) bits.push('Anything at all heard from this radio: ' + agoWords(pp.heard) + '.');
        facts.unshift(['Person on the mesh', pp.name, bits]);
      }
      var draw = function () {
        $('s-info').innerHTML = (mine ? '<div class="fact"><span class="k">' + (mine.properties.shared ? 'Shared pin' : 'My pin') + '</span><b>' + (mine.properties.shared ? '📍 ' : '📌 ') + esc(mine.properties.name) + '</b>' + (mine.properties.note ? esc(mine.properties.note) : '') +
            '<div class="row"><button class="btn sm" type="button" id="i-del">Remove this pin</button></div></div>' : '') +
          facts.map(function (d) { return '<div class="fact"><span class="k">' + esc(d[0]) + '</span>' + (d[1] ? '<b>' + esc(d[1]) + '</b>' : '') + d[2].filter(Boolean).join('<br>') + '</div>'; }).join('') +
          '<div class="fact"><table class="kv">' + rows.map(function (r) { return '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>'; }).join('') + '</table>' +
          '<div class="row"><button class="btn sm" type="button" id="i-pin">Save as a pin</button><button class="btn sm" type="button" id="i-meas">Measure from here</button>' +
          (meshOn ? '<button class="btn sm" type="button" id="i-wp">Send to the mesh</button>' : '') + '</div>' +
          (meshOn ? '<div id="i-wpform" hidden><input class="t" id="i-wpname" placeholder="What is here (seen by everyone on the mesh)" maxlength="30">' +
            '<input class="t" id="i-wpnote" placeholder="A note (optional)" maxlength="100">' +
            '<div class="row">' + ['\u{1F4CD}', '\u{1F6B0}', '\u26A0\uFE0F', '\u{1F3E0}', '\u{1F525}', '\u{1F6D1}'].map(function (e, i) {
              return '<button class="btn sm wpicon' + (i ? '' : ' on') + '" type="button" data-icon="' + e + '">' + e + '</button>'; }).join('') + '</div>' +
            '<div class="row"><button class="btn sm go" type="button" id="i-wpsend">Send it</button></div>' +
            '<p class="small">It goes out on the radio\u2019s main channel, to every radio in range. It cannot be sent to one person.</p></div>' : '') +
          '<div id="i-form" hidden><input class="t" id="i-name" placeholder="A name for this pin" maxlength="60"><textarea class="t" id="i-note" rows="2" placeholder="A note (optional)" maxlength="300"></textarea>' +
          (sharing ? '<label class="chk"><input type="checkbox" id="i-share"> Share it with everyone using this library</label>' : '') +
          '<div class="row"><button class="btn sm go" type="button" id="i-save">Save pin</button></div></div></div>';
        $('i-pin').onclick = function () { $('i-form').hidden = false; $('i-name').focus(); };
        $('i-save').onclick = function () {
          var nm = $('i-name').value.trim() || 'Pin', nt = $('i-note').value.trim();
          if ($('i-share') && $('i-share').checked) sharePin('add', { pin: { name: nm, note: nt, lng: ll.lng, lat: ll.lat } }); else addPin(ll, nm, nt);
          closeSheet();
        };
        $('i-meas').onclick = function () { startMeasure(); addMeasure(ll); };
        if ($('i-wp')) {
          var icon = '\u{1F4CD}';
          $('i-wp').onclick = function () { $('i-wpform').hidden = false; $('i-wpname').focus(); };
          $('i-wpform').addEventListener('click', function (ev) {
            var b = ev.target.closest('.wpicon'); if (!b) return;
            icon = b.dataset.icon;
            [].forEach.call($('i-wpform').querySelectorAll('.wpicon'), function (x) { x.classList.toggle('on', x === b); });
          });
          $('i-wpsend').onclick = function () {
            var nm = $('i-wpname').value.trim();
            if (!nm) { $('i-wpname').focus(); return; }
            $('i-wpsend').disabled = true;
            fetch('/api/mesh/waypoint', { method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ lat: ll.lat, lon: ll.lng, name: nm, note: $('i-wpnote').value.trim(), icon: icon }) })
              .then(function (r) { return r.ok ? r.json() : r.text().then(function (t) { throw new Error(t); }); })
              .then(function (j) {
                if (!j.ok) throw new Error(j.error || 'the radio did not take it');
                loadMesh(); closeSheet();
              })
              .catch(function (e) {
                $('i-wpsend').disabled = false;
                say('<b>It could not be sent to the mesh.</b> ' + esc(String(e && e.message || '').slice(0, 160)) +
                  ' <button class="btn" type="button" onclick="this.parentNode.hidden=true">OK</button>');
              });
          };
        }
        if (mine) $('i-del').onclick = function () { if (mine.properties.shared) sharePin('remove', { id: mine.properties.id }); else removePin(mine.properties.id); closeSheet(); };
      };
      draw(); openSheet('info', facts.length ? facts[0][1] || facts[0][0] : lot ? 'Tax lot' : 'What\'s here');
      if (pin) pin.remove();
      pin = new maplibregl.Marker({ color: '#d9480f' }).setLngLat(ll).addTo(map); pinKept = false;
      vegAt(ll).then(function (k) { if (k && VEG[k] && sheet === 'info') { facts.push(['What grows here', VEG[k][0], [esc(VEG[k][1])]]); draw(); } });
      elevationAt(ll).then(function (m) { if (m != null && sheet === 'info') { rows.splice(rows.length - 1, 0, ['Height', Math.round(m * 3.28084).toLocaleString() + ' ft <span class="small">(' + Math.round(m) + ' m)</span>']); draw(); } });
    });

    // the timber layer is pictures, not shapes: what is at a point is read from the colour of its dot
    function vegAt(ll) {
      if (!vegOv.file || !$('l-timber') || !$('l-timber').checked) return Promise.resolve(null);
      vegPM = vegPM || new pmtiles.PMTiles(DATA + vegOv.file + V);
      var z = vegOv.maxzoom, n = Math.pow(2, z), fx = (ll.lng + 180) / 360 * n, sn = Math.sin(ll.lat * Math.PI / 180), fy = (0.5 - Math.log((1 + sn) / (1 - sn)) / (4 * Math.PI)) * n;
      var tx = Math.floor(fx), ty = Math.floor(fy);
      return vegPM.getZxy(z, tx, ty).then(function (t) {
        if (!t || !t.data) return null;
        return createImageBitmap(new Blob([t.data], { type: 'image/png' })).then(function (bm) {
          var c = document.createElement('canvas'); c.width = bm.width; c.height = bm.height; var g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(bm, 0, 0);
          var d = g.getImageData(Math.min(bm.width - 1, Math.floor((fx - tx) * bm.width)), Math.min(bm.height - 1, Math.floor((fy - ty) * bm.height)), 1, 1).data, best = null, bd = 1e9;
          if (d[3] < 128) return null;
          (vegOv.classes || []).forEach(function (cl) {
            var r = parseInt(cl[1].slice(1, 3), 16), gg = parseInt(cl[1].slice(3, 5), 16), b = parseInt(cl[1].slice(5, 7), 16), dd = Math.abs(r - d[0]) + Math.abs(gg - d[1]) + Math.abs(b - d[2]);
            if (dd < bd) { bd = dd; best = cl[0]; }
          });
          return bd < 24 ? best : null;
        });
      }).catch(function () { return null; });
    }

    // ---- shared pins: kept by the library itself (on a drive or an ARK Vault), so every phone on its Wi-Fi sees them
    var sharing = false, shared = [];
    function drawShared() {
      var src = map.getSource('shared-pins'); if (!src) return;
      src.setData({ type: 'FeatureCollection', features: shared.map(function (p) { return { type: 'Feature', geometry: { type: 'Point', coordinates: [p.lng, p.lat] }, properties: { id: p.id, name: p.name, note: p.note || '', shared: 1 } }; }) });
    }
    function gotShared(j) { if (j && j.pins) { sharing = true; shared = j.pins; drawShared(); if (sheet === 'pins') renderPins(); } }
    function sharePin(what, body) {
      body.do = what;
      return fetch('/api/pins', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
        .then(function (r) { return r.ok ? r.json() : r.text().then(function (t) { throw new Error(t); }); }).then(gotShared)
        .catch(function (e) { say('<b>The pin could not be shared.</b> ' + esc(String(e && e.message || '').slice(0, 160)) + ' <button class="btn" type="button" onclick="this.parentNode.hidden=true">OK</button>'); });
    }
    function loadShared() { if (!document.hidden) fetch('/api/pins').then(function (r) { return r.ok ? r.json() : null; }).then(gotShared).catch(function () {}); }
    if (drive) { loadShared(); setInterval(loadShared, 30000); document.addEventListener('visibilitychange', loadShared); }

    // agoWords and roundWords: plain words for how long ago, and how far out a position may be
    function agoWords(secs) {
      if (!(secs >= 0) || secs < 90) return 'just now';
      if (secs < 3600) return Math.round(secs / 60) + ' minutes ago';
      if (secs < 86400) { var h = Math.round(secs / 3600); return h + (h === 1 ? ' hour ago' : ' hours ago'); }
      var d = Math.round(secs / 86400); return d + (d === 1 ? ' day ago' : ' days ago');
    }
    function roundWords(m) {
      if (m >= 900) return (m / 1609).toFixed(m >= 8045 ? 0 : 1) + ' miles';
      if (m >= 80) return Math.round(m / 0.9144 / 10) * 10 + ' yards';   // 0.9144 m to a yard
      return Math.round(m * 3.28) + ' feet';
    }

    // ---- people on the mesh: where each radio was last heard from, and where it has been
    var meshOn = false;
    function loadMesh() {
      if (document.hidden || !has('mesh-dot') || !meshOn) return;
      fetch('/api/mesh/map', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
        var src = map.getSource('mesh'); if (!src || !j) return;
        src.setData(j);
      }).catch(function () {});
    }
    if (haveMesh) {
      meshOn = true;
      // the layers only exist once the map's style is up, so ask again then rather than waiting
      // out the first ten seconds with an empty layer
      if (map.loaded()) loadMesh(); else map.once('load', loadMesh);
      setInterval(loadMesh, 10000);
      document.addEventListener('visibilitychange', loadMesh);
    }

    // ---- where am I: the phone only tells a secure page (https, or the device the library runs on)
    var geo = null, canLocate = window.isSecureContext && !!navigator.geolocation;
    var ok = ' <button class="btn" type="button" onclick="this.parentNode.hidden=true">OK</button>';
    if (canLocate) {   // made now, so it is ready by the time the button is tapped
      geo = new maplibregl.GeolocateControl({ positionOptions: { enableHighAccuracy: true, timeout: 60000 }, trackUserLocation: true, showUserHeading: true, showAccuracyCircle: true });
      geo.on('error', function (err) {
        $('locate').classList.remove('on');
        say((err && err.code === 1 ? '<b>The phone didn\'t allow its position.</b> Allow location for this page (and for the browser, in the phone\'s Settings), then tap <b>Me</b> again.'
          : '<b>No position yet.</b> Outdoors with a clear view of the sky it can take a minute or two with no cell signal. Tap <b>Me</b> to try again.') + ok);
      });
      geo.on('geolocate', function () { say(''); });
      geo.on('trackuserlocationend', function () { if (geo._watchState === 'OFF') $('locate').classList.remove('on'); });
      map.addControl(geo, 'top-left');
      if (geo._container) geo._container.style.display = 'none';   // its own button stays out of sight: ours (📍) drives it
    }
    $('locate').onclick = function () {
      if (!canLocate) {
        if (!drive || !navigator.geolocation) { say('<b>This phone won\'t share its position with this page.</b><br>Phones only do that for a secure page. Open the map from the library website (https).' + ok); return; }
        // the library shared over Wi-Fi: it has a secure address too, with a certificate it makes itself, which the phone has to be told to accept
        say('<b>To show where you are, this phone needs the library\'s secure address.</b>' +
          '<ol style="margin:6px 0 8px;padding-left:20px"><li>Tap <b>Open the secure map</b>.</li>' +
          '<li>The phone warns that the connection is <i>not private</i>. That is expected: the library makes its own security certificate, and nothing leaves this Wi-Fi. ' +
          'On an iPhone tap <b>Show Details</b>, then <b>visit this website</b>. On Android tap <b>Advanced</b>, then <b>Proceed</b>.</li>' +
          '<li>Tap <b>Me</b> again and allow location.</li></ol>' +
          '<button class="btn go" type="button" id="gosecure">Open the secure map</button> <button class="btn" type="button" onclick="this.parentNode.hidden=true">Not now</button>');
        $('gosecure').onclick = function () {
          fetch('/api/secure?now=' + Date.now()).then(function (r) { return r.json(); }).then(function (j) {
            if (!j.ok) throw new Error(j.why || '');
            location.href = 'https://' + location.hostname + ':' + j.port + location.pathname + location.search + location.hash;
          }).catch(function (e) {
            say('<b>The secure address isn\'t there.</b> ' + esc(e && e.message ? e.message : 'The library on the other device may need updating.') +
              ' You can still read your position from the phone\'s compass app and find it on the map.' + ok);
          });
        };
        return;
      }
      var go = function (tries) { if (!geo.trigger() && tries > 0) setTimeout(function () { go(tries - 1); }, 400); };
      go(8); $('locate').classList.add('on');
    };

    // ---- find a place by name
    var places = null, cfg0 = cfg.home || cfg.bbox;
    // The towns of a bigger map join the local names. On a drive they are a file beside the others. On the website they
    // are a couple of MB over the air, so they are fetched only when someone goes to search.
    var farPlaces = cfg.far ? cfg.far.places : cfg.widePlaces ? DATA + cfg.widePlaces : '', farAsked = false;
    function moreNames() {
      if (farAsked || !farPlaces || !places) return; farAsked = true;
      fetch(farPlaces).then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (far) {
        var have = {}; places.forEach(function (x) { if (x[1] === 'locality') have[x[0]] = 1; });
        places = places.concat(far.filter(function (x) { return !have[x[0]] || x[2] < cfg0[0] || x[2] > cfg0[2] || x[3] < cfg0[1] || x[3] > cfg0[3]; }));
        if ($('q').value.trim()) search();
      }).catch(function () { farAsked = false; });
    }
    // The names are for the search only (a few hundred KB), so they wait until the map itself is in, or until someone
    // goes to search: on a weak signal they used to be fetched ahead of the roads.
    var namesAsked = false;
    function loadNames() {
      if (namesAsked || !cfg.places) return; namesAsked = true;
      fetch(DATA + cfg.places).then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (p) {
        places = p; if (!cfg.far || document.activeElement === $('q')) moreNames(); if ($('q').value.trim()) search();
      }).catch(function () { namesAsked = false; });
    }
    if (cfg.places) map.once('load', loadNames);
    else if (!cfg.addresses) $('q').hidden = true;
    if (cfg.addresses) $('q').placeholder = 'Find a place or address…';
    var ICON = { locality: '🏘️', peak: '⛰️', lake: '💧', river: '🌊', stream: '💧', park: '🌲', road: '🛣️', poi: '📌' };
    var KIND = { locality: 'town or place', peak: 'peak', lake: 'lake or pond', river: 'river', stream: 'creek', park: 'park or forest', road: 'road', poi: 'place' };
    var ZOOM = { locality: 13, peak: 14, lake: 14, river: 12, stream: 14, park: 12, road: 14, poi: 15 };
    // house numbers (from the county's tax lots): fetched the first time a search starts with a number
    var addrs = null, addrAsked = false;
    var SHORT = { HIGHWAY: 'HWY', ROAD: 'RD', STREET: 'ST', AVENUE: 'AVE', DRIVE: 'DR', LANE: 'LN', COURT: 'CT', PLACE: 'PL', CIRCLE: 'CIR', BOULEVARD: 'BLVD', TRAIL: 'TRL', TERRACE: 'TER',
      HEIGHTS: 'HTS', NORTH: 'N', SOUTH: 'S', EAST: 'E', WEST: 'W', NORTHWEST: 'NW', NORTHEAST: 'NE', SOUTHWEST: 'SW', SOUTHEAST: 'SE' };
    var streetWords = function (t) { return String(t).toUpperCase().replace(/[.,#]/g, ' ').split(/\s+/).filter(Boolean).map(function (w) { return SHORT[w] || w; }); };
    var nice = function (t) { return String(t).toLowerCase().replace(/[a-z][a-z']*/g, function (w) { return /^(nw|ne|sw|se|n|s|e|w)$/.test(w) ? w.toUpperCase() : w.charAt(0).toUpperCase() + w.slice(1); }); };
    function loadAddrs() {
      if (addrAsked || !cfg.addresses) return; addrAsked = true;
      fetch(DATA + cfg.addresses).then(function (r) { return r.json(); }).then(function (a) { addrs = a.map(function (r) { return [r[0], r[1], r[2], streetWords(r[0] + ' ' + r[1])]; }); search(); }).catch(function () { addrAsked = false; });
    }
    function findAddress(num, rest) {   // -> hits: the number on every street that fits the words, or the nearest number on it
      var want = streetWords(rest).filter(function (w) { return !/^(OR|OREGON|\d{5}(-\d{4})?)$/.test(w); }), exact = [], near = [], n0 = parseInt(num, 10);
      if (!want.length) return null;
      addrs.forEach(function (st) {
        if (!want.every(function (w) { return st[3].some(function (x) { return x.indexOf(w) === 0; }); })) return;
        var best = null, bd = 1e9;
        st[2].forEach(function (a) {
          if (String(a[0]).toUpperCase() === num.toUpperCase()) exact.push({ icon: '🏠', t: a[0] + ' ' + nice(st[0]), k: nice(st[1]), ll: [a[1], a[2]], z: 16 });
          var d = Math.abs(parseInt(a[0], 10) - n0); if (d < bd) { bd = d; best = a; }
        });
        if (best) near.push({ icon: '🏠', t: best[0] + ' ' + nice(st[0]), k: nice(st[1]) + ' · nearest number on that street', ll: [best[1], best[2]], z: 16, d: bd });
      });
      if (exact.length) return exact.slice(0, 12);
      near.sort(function (a, c) { return a.d - c.d; });
      return near.slice(0, 6);
    }
    // a place beyond the local map: how far it is from the middle of the screen and which way, to tell towns of one name apart
    function away(p) {
      if (p[2] >= cfg0[0] && p[2] <= cfg0[2] && p[3] >= cfg0[1] && p[3] <= cfg0[3]) return '';
      var c = map.getCenter(), mi = dist(c, { lng: p[2], lat: p[3] }) / 1609.34, r = Math.PI / 180;
      var y = Math.sin((p[2] - c.lng) * r) * Math.cos(p[3] * r), x = Math.cos(c.lat * r) * Math.sin(p[3] * r) - Math.sin(c.lat * r) * Math.cos(p[3] * r) * Math.cos((p[2] - c.lng) * r);
      var way = ['north', 'northeast', 'east', 'southeast', 'south', 'southwest', 'west', 'northwest'][Math.round(((Math.atan2(y, x) / r + 360) % 360) / 45) % 8];
      return ' · ' + Math.round(mi).toLocaleString() + ' mi ' + way;
    }
    function search() {
      var text = $('q').value.trim(), words = text.toLowerCase().split(/\s+/).filter(Boolean), box = $('results'), hit = [], note = '', m, i, p, n;
      if (!words.length) { box.hidden = true; return; }
      if ((m = /^(-?\d{1,2}(?:\.\d+)?)\s*[,\s]\s*(-?\d{1,3}(?:\.\d+)?)$/.exec(text)) && Math.abs(+m[1]) <= 90 && Math.abs(+m[2]) <= 180 && /\./.test(text)) {   // a position: latitude, longitude
        var la = +m[1], lo = +m[2]; if (lo > 0 && cfg.bbox[2] < 0) lo = -lo;    // west of Greenwich the minus sign is often left off
        hit.push({ icon: '📍', t: la.toFixed(5) + ', ' + lo.toFixed(5), k: 'go to this position', ll: [lo, la], z: 15 });
      } else if (cfg.addresses && (m = /^(\d+[a-z]?)(?:\s+(.*))?$/i.exec(text))) {            // a house number, then the street
        if (!addrs) { loadAddrs(); note = 'Looking up addresses…'; }
        else if (!m[2]) note = 'Now type the street name, such as <b>' + esc(m[1]) + ' Redwood Hwy</b>.';
        else { hit = findAddress(m[1], m[2]) || []; if (!hit.length) note = 'No street by that name with house numbers on this map. Try just part of the street name, without the town.'; }
      }
      if (!hit.length && !note && !places && cfg.places) { loadNames(); note = 'Looking up names…'; }
      if (!hit.length && !note && towns && text.length >= 3) {   // a town the walking routes go to
        towns.forEach(function (t) {
          var nm = (t[0] + ' ' + t[1]).toLowerCase();
          if (hit.length < 3 && words.every(function (w) { return nm.indexOf(w) >= 0; }) && (t[0].toLowerCase().indexOf(words[0]) === 0 || words.length > 1))
            hit.push({ icon: '🥾', t: 'Walking route to ' + t[0] + ', ' + t[1], k: t[5] ? Math.round(t[5]) + ' mi · ' + footTime(t[5]) : '', route: t[2] });
        });
      }
      var routeHits = hit.length, ph = [];
      if (hit.length === routeHits && !note && places) {
        for (i = 0; i < places.length && ph.length < 400; i++) {
          p = places[i]; n = p[0].toLowerCase();
          if (words.every(function (w) { return n.indexOf(w) >= 0; })) ph.push({ icon: ICON[p[1]] || '📌', t: p[0], k: (KIND[p[1]] || '') + away(p), ll: [p[2], p[3]], z: ZOOM[p[1]] || 14 });
        }
        var first = words[0];   // names that start with what was typed come first; the list is already in order of importance
        ph.sort(function (a, c) { return (a.t.toLowerCase().indexOf(first) === 0 ? 0 : 1) - (c.t.toLowerCase().indexOf(first) === 0 ? 0 : 1); });
        hit = hit.concat(ph).slice(0, 12);
        if (!hit.length) note = 'Nothing by that name on this map. Try part of the name' + (cfg.addresses ? ', or a house number and street.' : '.');
      }
      box.innerHTML = hit.map(function (h, i) { return '<button type="button" data-i="' + i + '">' + h.icon + ' ' + esc(h.t) + ' <small>' + esc(h.k) + '</small></button>'; }).join('') +
        (note ? '<p class="small" style="margin:8px 10px">' + note + '</p>' : '');
      box.hidden = false;
      box.querySelectorAll('button').forEach(function (bt) {
        bt.onclick = function () {
          var h = hit[+bt.dataset.i]; box.hidden = true; $('q').blur();
          if (h.route) { showRoute(h.route); return; }
          map.flyTo({ center: h.ll, zoom: Math.max(map.getZoom(), h.z), speed: 1.6 });
          if (pin) pin.remove();
          pin = new maplibregl.Marker({ color: '#d9480f' }).setLngLat(h.ll).addTo(map); pinKept = true;
        };
      });
    }
    // ---- my pins: kept on this device (and in a file, to carry them to another)
    var pins = store.get('arkPins', []);
    function drawPins() {
      var src = map.getSource('pins'); if (!src) return;
      src.setData({ type: 'FeatureCollection', features: pins.map(function (p) { return { type: 'Feature', geometry: { type: 'Point', coordinates: [p.lng, p.lat] }, properties: { id: p.id, name: p.name, note: p.note || '' } }; }) });
    }
    function addPin(ll, name, note) { pins.push({ id: Date.now() + '-' + Math.round(Math.random() * 1e6), name: name, note: note, lng: +ll.lng.toFixed(6), lat: +ll.lat.toFixed(6), t: Date.now() }); store.set('arkPins', pins); drawPins(); }
    function removePin(id) { pins = pins.filter(function (p) { return p.id !== id; }); store.set('arkPins', pins); drawPins(); renderPins(); }
    function renderPins() {
      $('pinlist').innerHTML = pins.length ? pins.map(function (p, i) {
        return '<div class="pinrow"><span>📌</span><span class="tx" data-i="' + i + '">' + esc(p.name) + '<small>' + (p.note ? esc(p.note) + ' · ' : '') + p.lat.toFixed(5) + ', ' + p.lng.toFixed(5) + '</small></span><button class="btn sm" type="button" data-d="' + esc(p.id) + '">Remove</button></div>';
      }).join('') : '<p class="small">No pins yet.</p>';
      if (sharing) $('pinlist').innerHTML += '<h4 class="sub">Shared on this library</h4>' + (shared.length ? shared.map(function (p, i) {
        return '<div class="pinrow"><span>📍</span><span class="tx" data-s="' + i + '">' + esc(p.name) + '<small>' + (p.note ? esc(p.note) + ' · ' : '') + p.lat.toFixed(5) + ', ' + p.lng.toFixed(5) + '</small></span><button class="btn sm" type="button" data-r="' + esc(p.id) + '">Remove</button></div>';
      }).join('') : '<p class="small">None yet. Everyone using this library sees these. To share one, tap the map, then <b>Save as a pin</b>, and tick <b>Share it</b>.</p>');
      $('pinlist').querySelectorAll('.tx').forEach(function (el) { el.onclick = function () { var p = el.dataset.s != null ? shared[+el.dataset.s] : pins[+el.dataset.i]; map.flyTo({ center: [p.lng, p.lat], zoom: Math.max(map.getZoom(), 14) }); if (innerWidth < 820) closeSheet(); }; });
      $('pinlist').querySelectorAll('[data-d]').forEach(function (el) { el.onclick = function () { removePin(el.dataset.d); }; });
      $('pinlist').querySelectorAll('[data-r]').forEach(function (el) { el.onclick = function () { sharePin('remove', { id: el.dataset.r }); }; });
    }
    $('t-pins').onclick = toggleSheet('pins', renderPins);
    $('p-export').onclick = function () {
      var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify({ arkPins: pins }, null, 1)], { type: 'application/json' })); a.download = 'my-map-pins.json'; a.click();
    };
    $('p-import').onchange = function () {
      var f = this.files[0]; if (!f) return; var fr = new FileReader();
      fr.onload = function () {
        try {
          var got = JSON.parse(fr.result).arkPins, ids = {}; pins.forEach(function (p) { ids[p.id] = 1; });
          got.forEach(function (p) { if (p && isFinite(p.lng) && isFinite(p.lat) && !ids[p.id]) pins.push({ id: String(p.id || Date.now() + Math.random()), name: String(p.name || 'Pin').slice(0, 60), note: String(p.note || '').slice(0, 300), lng: +p.lng, lat: +p.lat, t: p.t || Date.now() }); });
          store.set('arkPins', pins); drawPins(); renderPins();
        } catch (e) { say('<b>That file doesn\'t hold map pins.</b> <button class="btn" type="button" onclick="this.parentNode.hidden=true">OK</button>'); }
      };
      fr.readAsText(f); this.value = '';
    };

    // ---- measure: distance along a path, the ups and downs, and whether the two ends can see each other
    var measuring = false, mpts = [];
    function dist(a, c) { var R = 6371000, r = Math.PI / 180, dLat = (c.lat - a.lat) * r, dLng = (c.lng - a.lng) * r, h = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(a.lat * r) * Math.cos(c.lat * r) * Math.sin(dLng / 2) * Math.sin(dLng / 2); return 2 * R * Math.asin(Math.sqrt(h)); }
    function far(m) { var ft = m * 3.28084; return ft < 1500 ? Math.round(ft).toLocaleString() + ' ft' : (ft / 5280).toFixed(ft < 52800 ? 2 : 1) + ' miles'; }
    function startMeasure() { measuring = true; mpts = []; openSheet('measure'); $('hint').textContent = 'Tap the map to mark points'; $('hint').hidden = false; map.getCanvas().style.cursor = 'crosshair'; drawMeasure(); }
    function endMeasure() { measuring = false; mpts = []; $('hint').hidden = true; map.getCanvas().style.cursor = ''; var s = map.getSource('measure'); if (s) s.setData({ type: 'FeatureCollection', features: [] }); }
    function addMeasure(ll) { mpts.push(ll); drawMeasure(); }
    var mseq = 0;
    function drawMeasure() {
      var s = map.getSource('measure'), fs = mpts.map(function (p, i) { return { type: 'Feature', geometry: { type: 'Point', coordinates: [p.lng, p.lat] }, properties: { n: i + 1 } }; });
      if (mpts.length > 1) fs.push({ type: 'Feature', geometry: { type: 'LineString', coordinates: mpts.map(function (p) { return [p.lng, p.lat]; }) }, properties: {} });
      if (s) s.setData({ type: 'FeatureCollection', features: fs });
      var total = 0, i; for (i = 1; i < mpts.length; i++) total += dist(mpts[i - 1], mpts[i]);
      $('m-hint').hidden = mpts.length > 1; $('hint').hidden = mpts.length > 1;
      var stretches = (mpts.length - 1) + ' stretch' + (mpts.length > 2 ? 'es' : '') + ', straight from point to point';
      var clock = function (min) { min = Math.max(1, Math.round(min)); if (min < 60) return min + ' minutes'; min = Math.round(min / 5) * 5; return Math.floor(min / 60) + ' hr' + (min % 60 ? ' ' + (min % 60) + ' min' : ''); };
      // first the distance flat on the map; the heights along the way (below) then give the distance over the ground
      $('m-out').innerHTML = mpts.length < 2 ? (mpts.length ? '<p>First point marked. Tap the next one.</p>' : '') : '<p style="font-size:20px;font-weight:700;margin:2px 0">' + far(total) + '</p>' +
        '<p class="small">' + stretches + (total > 800 ? ' · about ' + clock(total / 1609.34 / 2.5 * 60) + ' on foot on level ground' : '') + '</p>';
      $('profile').hidden = true; $('m-prof').innerHTML = '';
      if (mpts.length < 2 || !dem) return;
      // heights along the way
      var seq = ++mseq, N = Math.max(100, Math.min(600, Math.round(total / 40))), pts = [], acc = 0, segs = [];   // a height about every 130 ft
      for (i = 1; i < mpts.length; i++) { var d = dist(mpts[i - 1], mpts[i]); segs.push([acc, d, mpts[i - 1], mpts[i]]); acc += d; }
      for (i = 0; i <= N; i++) {
        var at = total * i / N, sg = segs[0]; segs.forEach(function (g) { if (at >= g[0]) sg = g; });
        var t = sg[1] ? Math.min(1, (at - sg[0]) / sg[1]) : 0;
        pts.push({ d: at, ll: { lng: sg[2].lng + (sg[3].lng - sg[2].lng) * t, lat: sg[2].lat + (sg[3].lat - sg[2].lat) * t } });
      }
      Promise.all(pts.map(function (p) { return elevationAt(p.ll); })).then(function (els) {
        if (seq !== mseq || !measuring) return;
        var ok = els.filter(function (v) { return v != null; }); if (ok.length < els.length * 0.8) return;
        els = els.map(function (v, k) { return v == null ? (els[k - 1] != null ? els[k - 1] : ok[0]) : v; });
        var lo = Math.min.apply(null, els), hi = Math.max.apply(null, els), up = 0, down = 0;
        for (i = 1; i < els.length; i++) { var dv = els[i] - els[i - 1]; if (dv > 0) up += dv; else down -= dv; }
        // Over the ground: each short piece is the long side of its rise and its run. And the time on foot with the climbs
        // counted, there and back (Tobler's hiking rule: quickest on a slight downhill, slower the steeper it gets either
        // way), set so that level ground is the same 2.5 miles an hour as above.
        var sm = els.map(function (v, k) { return (els[Math.max(k - 1, 0)] + v + els[Math.min(k + 1, N)]) / 3; }), run = total / N, ground = 0, there = 0, back = 0;
        var pace = function (slope) { return 6 * Math.exp(-3.5 * Math.abs(slope + 0.05)) * 0.798 / 3.6; };   // metres a second
        for (i = 1; i <= N; i++) { var rise = sm[i] - sm[i - 1]; ground += Math.sqrt(run * run + rise * rise); there += run / pace(rise / run); back += run / pace(-rise / run); }
        $('m-out').innerHTML = '<p style="font-size:20px;font-weight:700;margin:2px 0">' + far(ground) + ' <span class="small" style="font-weight:400">over the ground</span></p>' +
          '<p class="small">' + far(total) + ' flat on the map · ' + stretches + '</p>' +
          (total > 400 ? '<p style="margin:6px 0">About <b>' + clock(there / 60) + '</b> on foot' + (Math.abs(there - back) > 120 ? ', <b>' + clock(back / 60) + '</b> coming back' : '') +
            '. <span class="small">The climbs are counted. This is a steady walker on a road or trail: off trail, or with a heavy load, allow half as much again.</span></p>' : '');
        var cv = $('profile'); cv.hidden = false; var W = cv.width = cv.clientWidth * 2, H = cv.height = 240, g = cv.getContext('2d'), padL = 8, padB = 8, span = Math.max(hi - lo, 10);
        var X = function (k) { return padL + (W - 2 * padL) * k / N; }, Y = function (v) { return H - padB - (H - 2 * padB - 22) * (v - lo) / span; };
        g.clearRect(0, 0, W, H); g.beginPath(); g.moveTo(X(0), H - padB); els.forEach(function (v, k) { g.lineTo(X(k), Y(v)); }); g.lineTo(X(N), H - padB); g.closePath();
        g.fillStyle = 'rgba(79,209,197,.35)'; g.fill(); g.beginPath(); els.forEach(function (v, k) { if (k) g.lineTo(X(k), Y(v)); else g.moveTo(X(k), Y(v)); }); g.strokeStyle = '#0d9488'; g.lineWidth = 3; g.stroke();
        var txt = '<p class="small">Lowest ' + Math.round(lo * 3.28084).toLocaleString() + ' ft, highest ' + Math.round(hi * 3.28084).toLocaleString() + ' ft · up ' + Math.round(up * 3.28084).toLocaleString() + ' ft, down ' + Math.round(down * 3.28084).toLocaleString() + ' ft along the way</p>';
        if (mpts.length === 2) {   // line of sight between the two ends, each 6 ft above the ground, with the earth's curve (as radio sees it)
          var h0 = els[0] + 1.8, h1 = els[N] + 1.8, worst = 0, where = 0;
          for (i = 1; i < N; i++) { var dd = pts[i].d, line = h0 + (h1 - h0) * dd / total, bulge = dd * (total - dd) / (2 * 6371000 * 4 / 3), over = els[i] + bulge - line; if (over > worst) { worst = over; where = dd; } }
          g.beginPath(); g.moveTo(X(0), Y(h0)); g.lineTo(X(N), Y(h1)); g.setLineDash([8, 6]); g.strokeStyle = worst > 0 ? '#d9480f' : '#2b8a3e'; g.lineWidth = 2.5; g.stroke(); g.setLineDash([]);
          txt += worst > 0 ? '<p>🚫 <b>The two ends can\'t see each other.</b> The ground ' + far(where) + ' from the first point is in the way by about ' + Math.round(worst * 3.28084).toLocaleString() + ' ft. A radio would need a higher spot or a relay.</p>'
            : '<p>✅ <b>The two ends can see each other</b> (each 6 ft above the ground; trees and buildings not counted). Good for a radio link.</p>';
        }
        $('m-prof').innerHTML = txt;
      });
    }
    $('t-measure').onclick = function () { if (sheet === 'measure') closeSheet(); else startMeasure(); };
    $('m-undo').onclick = function () { mpts.pop(); drawMeasure(); };
    $('m-clear').onclick = function () { mpts = []; drawMeasure(); $('hint').hidden = false; };

    // ---- print the part of the map on the screen
    // On the receipt printer (through the Library Assistant): black and white, 384 dots a strip, 1 to 4 strips side by side.
    // On an ordinary printer: one colour page. Either way a second, unseen map is drawn at the size the paper needs.
    var places0 = function () { return places || []; };
    function drawMap(st, w, h, zoom, ratio) {       // -> Promise of {canvas, map}: a map w x h (CSS px) drawn off screen
      return new Promise(function (ok, bad) {
        var box = document.createElement('div'); box.style.cssText = 'width:' + w + 'px;height:' + h + 'px';
        $('printwork').appendChild(box);
        var m = new maplibregl.Map({ container: box, style: st, center: map.getCenter(), zoom: zoom, interactive: false, attributionControl: false,
          preserveDrawingBuffer: true, pixelRatio: ratio, fadeDuration: 0, maxZoom: 22 });
        m.on('styleimagemissing', function (e) { addBadge(m, e.id); });
        var done = false, quiet = 0, t0 = Date.now();
        var finish = function () { if (done) return; done = true; clearInterval(iv); setTimeout(function () { ok({ canvas: m.getCanvas(), map: m, box: box }); }, 250); };
        m.once('idle', finish);
        m.on('error', function () { if (m._update) m._update(); });   // a tile the files don't have: look again, for the coarser one above it
        var iv = setInterval(function () {             // the hill shading can keep "idle" from ever coming: settle for all tiles in and still
          quiet = m.areTilesLoaded() ? quiet + 1 : 0;
          if (quiet >= 4 || Date.now() - t0 > 25000) finish();
        }, 400);
      });
    }
    function niceBar(maxFeet) {                        // a round length for the scale bar, and its words
      var steps = [50, 100, 200, 500, 1000, 2000, 2640, 5280, 10560, 26400, 52800, 105600, 264000, 528000], f = steps[0];
      steps.forEach(function (v) { if (v <= maxFeet) f = v; });
      return { feet: f, text: f < 2640 ? f.toLocaleString() + ' ft' : (f / 5280) + (f === 5280 ? ' mile' : ' miles') };
    }
    function decorate(g, w, h, m, colour) {            // the frame, north arrow, scale bar and the tapped spot, drawn on the picture
      var c = m.getCenter(), ftPerPx = 40075016.686 * Math.cos(c.lat * Math.PI / 180) / Math.pow(2, m.getZoom()) / 512 * 3.28084;
      var bar = niceBar(ftPerPx * Math.min(w * 0.45, 300)), bw = Math.round(bar.feet / ftPerPx), k = w / 384 > 2.5 ? 1.5 : 1;
      g.lineWidth = 3; g.strokeStyle = '#000'; g.strokeRect(1.5, 1.5, w - 3, h - 3);
      g.font = 'bold ' + Math.round(15 * k) + 'px sans-serif'; g.textBaseline = 'alphabetic';
      var tw = Math.max(bw, g.measureText(bar.text).width) + 20, x = 10, y = h - 12;
      g.fillStyle = '#fff'; g.fillRect(x - 4, y - 34 * k, tw + 8, 40 * k); g.strokeStyle = '#000'; g.lineWidth = 1; g.strokeRect(x - 3.5, y - 33.5 * k, tw + 7, 39 * k);
      g.fillStyle = '#000'; g.fillText(bar.text, x + 4, y - 14 * k);
      g.fillRect(x + 4, y - 8 * k, bw, 4 * k); g.fillRect(x + 4, y - 12 * k, 2, 10 * k); g.fillRect(x + 2 + bw, y - 12 * k, 2, 10 * k);
      var nx = w - 26 * k, ny = 16 * k;                 // north arrow
      g.fillStyle = '#fff'; g.fillRect(nx - 16 * k, ny - 10 * k, 32 * k, 62 * k); g.strokeRect(nx - 15.5 * k, ny - 9.5 * k, 31 * k, 61 * k);
      g.fillStyle = '#000'; g.beginPath(); g.moveTo(nx, ny - 4 * k); g.lineTo(nx + 9 * k, ny + 22 * k); g.lineTo(nx, ny + 15 * k); g.lineTo(nx - 9 * k, ny + 22 * k); g.closePath(); g.fill();
      g.font = 'bold ' + Math.round(18 * k) + 'px sans-serif'; g.textAlign = 'center'; g.fillText('N', nx, ny + 44 * k); g.textAlign = 'left';
      if (pin) {                                        // the spot that was tapped or found
        var p = m.project(pin.getLngLat());
        if (p.x > 8 && p.y > 8 && p.x < w - 8 && p.y < h - 8) {
          g.lineWidth = 5; g.strokeStyle = '#fff'; g.beginPath(); g.arc(p.x, p.y, 9 * k, 0, 7); g.moveTo(p.x - 15 * k, p.y); g.lineTo(p.x + 15 * k, p.y); g.moveTo(p.x, p.y - 15 * k); g.lineTo(p.x, p.y + 15 * k); g.stroke();
          g.lineWidth = 2.2; g.strokeStyle = colour ? '#d9480f' : '#000'; g.stroke();
        }
      }
      return { widthFeet: ftPerPx * w, bar: bar };
    }
    function blackAndWhite(g, w, h) {                  // crisp black lines; the grey of water becomes a pattern of dots
      var im = g.getImageData(0, 0, w, h), d = im.data, i, v, x, y;
      for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
        i = (y * w + x) * 4; v = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
        v = v > 186 && v < 214 ? ((x + y * 2) % 4 === 0 ? 0 : 255) : v < 168 ? 0 : 255;
        d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255;
      }
      g.putImageData(im, 0, 0);
    }
    function nearName() {                               // "near Cave Junction": the closest town to the middle of the picture
      var c = map.getCenter(), best = null, bd = 1e9;
      places0().forEach(function (p) { if (p[1] !== 'locality') return; var dx = (p[2] - c.lng) * Math.cos(c.lat * Math.PI / 180), dy = p[3] - c.lat, dd = dx * dx + dy * dy; if (dd < bd) { bd = dd; best = p[0]; } });
      return best && bd < 0.03 ? 'near ' + best : cfg.name;
    }
    function widthWords(feet) { return feet < 5280 ? Math.round(feet / 100) * 100 + ' feet' : (Math.round(feet / 528) / 10) + ' miles'; }
    var pr = { cols: 2, job: null, seq: 0 };
    function shown() { var o = {}; ['contours', 'parcels', 'own'].forEach(function (k) { o[k] = !!($('l-' + k) && $('l-' + k).checked); }); return o; }
    function receiptPreview() {
      var seq = ++pr.seq, cols = pr.cols, box = $('map').getBoundingClientRect();
      var W = 384 * cols, H = Math.min(Math.round(W * box.height / box.width), 4200, 384 * cols * 3);
      $('pr-info').textContent = 'Drawing the map…'; $('pr-go').disabled = true; pr.job = null;
      drawMap(printStyle(cfg, dem, shown()), W, H, map.getZoom() + Math.log(W / box.width) / Math.LN2, 2).then(function (r) {
        var cv = document.createElement('canvas'); cv.width = W; cv.height = H; var g = cv.getContext('2d');
        g.fillStyle = '#fff'; g.fillRect(0, 0, W, H); g.drawImage(r.canvas, 0, 0, W, H);
        blackAndWhite(g, W, H);
        var info = decorate(g, W, H, r.map, false);
        r.map.remove(); r.box.remove();
        if (seq !== pr.seq) return;
        var c = map.getCenter(), blocks = [{ t: 'h3', x: 'Map ' + nearName() }];
        blocks.push({ t: 'p', x: 'North is up. The map is about ' + widthWords(info.widthFeet) + ' wide; the bar on it is ' + info.bar.text + '. Middle: ' + c.lat.toFixed(5) + ', ' + c.lng.toFixed(5) + '.' +
          (pin ? ' The cross marks ' + pin.getLngLat().lat.toFixed(5) + ', ' + pin.getLngLat().lng.toFixed(5) + '.' : '') });
        if (cols > 1) blocks.push({ t: 'p', x: 'Tape the ' + cols + ' strips side by side: A on the left, then ' + 'BCD'.slice(0, cols - 1).split('').join(', ') + '.' });
        for (var i = 0; i < cols; i++) {
          var s = document.createElement('canvas'); s.width = 384; s.height = H;
          s.getContext('2d').drawImage(cv, i * 384, 0, 384, H, 0, 0, 384, H);
          if (cols > 1) blocks.push({ t: 'h4', x: 'strip ' + 'ABCD'[i] });
          blocks.push({ t: 'img', data: s.toDataURL('image/png') });
        }
        var whole = cv.toDataURL('image/png');
        $('pr-prev').querySelector('img').src = whole; $('pr-save').href = whole; $('pr-save').hidden = false;
        if (!drive) { $('pr-info').textContent = 'This is how it prints on the library\'s receipt printer (on the ARK Vault). Here you can save the picture.'; return; }
        pr.job = { size: 'small', title: '', pictures: true, blocks: blocks };
        return fetch('/api/print', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(pr.job) }).then(function (res) { return res.ok ? res.json() : res.text().then(function (t) { throw new Error(t); }); }).then(function (p) {
          if (seq !== pr.seq) return;
          var inch = p.mm / 25.4, found = p.printer && p.printer.found;
          $('pr-info').textContent = 'About ' + (inch < 12 ? Math.round(inch) + ' in' : (Math.round(inch / 1.2) / 10) + ' ft') + ' of paper. ' + (found ? '' : 'No printer found: plug it into the computer running the library (on the ARK Vault, the Pi).');
          $('pr-go').disabled = !found;
        });
      }).catch(function (e) { if (seq === pr.seq) $('pr-info').textContent = 'Could not make the picture' + (e && e.message ? ' (' + String(e.message).slice(0, 120) + ')' : '') + '.'; });
    }
    $('pr-cols').querySelectorAll('button').forEach(function (bt) {
      bt.onclick = function () { pr.cols = +bt.dataset.v; $('pr-cols').querySelectorAll('button').forEach(function (o) { o.classList.toggle('on', o === bt); }); receiptPreview(); };
    });
    $('pr-go').onclick = function () {
      if (!pr.job) return;
      $('pr-go').disabled = true; $('pr-info').textContent = 'Printing…';
      fetch('/api/print?go=1', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(pr.job) }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (p) { if (!r.ok) throw new Error(p.error || 'the printer did not answer'); }); })
        .then(function () { $('pr-info').textContent = 'Sent to the printer. Tear each strip off when it stops.'; $('pr-go').disabled = false; })
        .catch(function (e) { $('pr-info').textContent = String(e.message || e); $('pr-go').disabled = false; });
    };
    $('pr-color').onclick = function () {               // one colour page: 8 x 10.35 in at 150 dots an inch, the screen's middle and width
      var box = $('map').getBoundingClientRect(), W = 1200, H = 1552;
      $('pr-colorinfo').textContent = 'Drawing the map…'; $('pr-color').disabled = true;
      var st = style(cfg, dem);                         // with the layers that are switched off left out
      Object.keys(GROUPS).forEach(function (k) { if (!$('l-' + k).checked) st.layers.forEach(function (l) { if (GROUPS[k].indexOf(l.id) >= 0) { l.layout = l.layout || {}; l.layout.visibility = 'none'; } }); });
      ITEMS.forEach(function (it) { if (opac[it.id] > 0) setOpacity(it, opac[it.id], st); });   // as solid as on the screen
      if (routeData) {   // a town's walking route on the screen goes on the page too, its ways as switched
        st.sources['route-pick'] = { type: 'geojson', data: routeData };
        st.layers.forEach(function (l) { if (/^route-(back|hwy|bike)$/.test(l.id) && has(l.id) && map.getLayoutProperty(l.id, 'visibility') === 'none') { l.layout = l.layout || {}; l.layout.visibility = 'none'; } });
        if (has('route-case')) st.layers.forEach(function (l) { if (l.id === 'route-case') l.filter = map.getFilter('route-case'); });
      }
      drawMap(st, W, H, map.getZoom() + Math.log(W / box.width) / Math.LN2, 1.5).then(function (r) {
        var cv = document.createElement('canvas'); cv.width = W; cv.height = H; var g = cv.getContext('2d');
        g.fillStyle = '#fff'; g.fillRect(0, 0, W, H); g.drawImage(r.canvas, 0, 0, W, H);
        decorate(g, W, H, r.map, true); r.map.remove(); r.box.remove();
        g.font = '14px sans-serif'; g.fillStyle = '#000'; var c = map.getCenter();
        var cap = 'Map ' + nearName() + '  ·  middle ' + c.lat.toFixed(5) + ', ' + c.lng.toFixed(5) + '  ·  © OpenStreetMap contributors, Mapterhorn' + (cfg.property ? ', county tax lots (not a survey)' : '');
        g.fillStyle = 'rgba(255,255,255,.85)'; g.fillRect(4, 4, g.measureText(cap).width + 14, 22); g.fillStyle = '#000'; g.fillText(cap, 10, 20);
        var url = cv.toDataURL('image/jpeg', 0.92), img = new Image();
        img.onload = function () { $('printsheet').innerHTML = ''; $('printsheet').appendChild(img); $('pr-colorinfo').textContent = ''; $('pr-color').disabled = false; setTimeout(function () { window.print(); }, 150); };
        img.src = url;
      }).catch(function () { $('pr-colorinfo').textContent = 'Could not draw the page.'; $('pr-color').disabled = false; });
    };
    $('t-print').onclick = toggleSheet('print', function () { receiptPreview(); });
    $('q').addEventListener('input', search);
    $('q').addEventListener('focus', function () { loadNames(); moreNames(); loadTowns(); search(); });
    $('q').addEventListener('keydown', function (e) { if (e.key === 'Enter') { var f = $('results').querySelector('button'); if (f) f.click(); } });
  }

  // "Steep ground" and "Sunny slopes": pictures worked out here from the height tiles, one for each tile the map asks for
  function slopeTiles(dem) {
    return function (params) {
      var m = /^ark-slope:\/\/(\w+)\/(\d+)\/(\d+)\/(\d+)/.exec(params.url), what = m[1], z = +m[2], x = +m[3], y = +m[4];
      if (what === 'frost') return frostTile(dem, z, x, y);
      return dem.getDemTile(z, x, y).then(function (t) {
        var w = t.width, h = t.height, d = t.data, c = document.createElement('canvas'); c.width = w; c.height = h;
        var g = c.getContext('2d'), im = g.createImageData(w, h), o = im.data;
        var lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * (y + 0.5) / Math.pow(2, z)))), px = 40075016.686 * Math.cos(lat) / Math.pow(2, z) / w;
        for (var j = 0; j < h; j++) for (var i = 0; i < w; i++) {
          var l = d[j * w + Math.max(i - 1, 0)], r = d[j * w + Math.min(i + 1, w - 1)], u = d[Math.max(j - 1, 0) * w + i], dn = d[Math.min(j + 1, h - 1) * w + i];
          var dx = (r - l) / (2 * px), dy = (dn - u) / (2 * px), deg = Math.atan(Math.sqrt(dx * dx + dy * dy)) * 57.2958, k = (j * w + i) * 4, col = null;
          if (what === 'sunny') { var asp = Math.atan2(-dx, -dy) * 57.2958; if (deg >= 4 && Math.abs(asp) <= 50) col = [255, 204, 51, 105]; }   // downhill points south, within 50 degrees
          else col = deg < 8 ? null : deg < 15 ? [255, 243, 176, 90] : deg < 25 ? [255, 198, 92, 110] : deg < 35 ? [245, 139, 60, 125] : deg < 45 ? [217, 72, 15, 135] : [123, 44, 191, 140];
          if (col) { o[k] = col[0]; o[k + 1] = col[1]; o[k + 2] = col[2]; o[k + 3] = col[3]; }
        }
        g.putImageData(im, 0, 0);
        return new Promise(function (ok) { c.toBlob(function (bl) { bl.arrayBuffer().then(function (ab) { ok({ data: ab }); }); }, 'image/png'); });
      });
    };
  }

  // "Frost pockets": cold air is heavy and runs downhill on a still, clear night, pooling on low, flat ground. A spot is
  // marked when it is nearly level and well below the average height of the ground for a mile and a half around (so:
  // valley floors and hollows, not benches or ridges). It needs the eight tiles around the one asked for.
  function frostTile(dem, z, x, y) {
    var jobs = [], dx, dy;
    for (dy = -1; dy <= 1; dy++) for (dx = -1; dx <= 1; dx++) jobs.push(dem.getDemTile(z, x + dx, y + dy).catch(function () { return null; }));
    return Promise.all(jobs).then(function (ts) {
      if (!ts[4]) throw new Error('no heights here');
      var Q = 256, G = 3 * Q, el = new Float32Array(G * G), ok = new Uint8Array(G * G), i, j, k;
      ts.forEach(function (t, n) {
        if (!t) return;
        var ox = (n % 3) * Q, oy = Math.floor(n / 3) * Q, st = t.width / Q, v;
        for (j = 0; j < Q; j++) for (i = 0; i < Q; i++) { v = t.data[Math.floor(j * st) * t.width + Math.floor(i * st)]; if (isFinite(v)) { el[(oy + j) * G + ox + i] = v; ok[(oy + j) * G + ox + i] = 1; } }
      });
      var W1 = G + 1, S = new Float64Array(W1 * W1), N = new Int32Array(W1 * W1), rs, rn;   // running sums: the average of any box in four look-ups
      for (j = 0; j < G; j++) { rs = 0; rn = 0; for (i = 0; i < G; i++) { k = j * G + i; if (ok[k]) { rs += el[k]; rn++; } S[(j + 1) * W1 + i + 1] = S[j * W1 + i + 1] + rs; N[(j + 1) * W1 + i + 1] = N[j * W1 + i + 1] + rn; } }
      var lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * (y + 0.5) / Math.pow(2, z)))), cell = 40075016.686 * Math.cos(lat) / Math.pow(2, z) / Q, r = Math.max(2, Math.min(Q - 1, Math.round(2500 / cell)));
      var c = document.createElement('canvas'); c.width = c.height = Q; var g = c.getContext('2d'), im = g.createImageData(Q, Q), o = im.data;
      for (j = 0; j < Q; j++) for (i = 0; i < Q; i++) {
        var gi = Q + i, gj = Q + j, e = el[gj * G + gi]; if (!ok[gj * G + gi]) continue;
        var x0 = gi - r, x1 = gi + r + 1, y0 = gj - r, y1 = gj + r + 1;
        var cnt = N[y1 * W1 + x1] - N[y0 * W1 + x1] - N[y1 * W1 + x0] + N[y0 * W1 + x0]; if (cnt < 9) continue;
        var low = e - (S[y1 * W1 + x1] - S[y0 * W1 + x1] - S[y1 * W1 + x0] + S[y0 * W1 + x0]) / cnt;
        var sx = (el[gj * G + gi + 1] - el[gj * G + gi - 1]) / (2 * cell), sy = (el[(gj + 1) * G + gi] - el[(gj - 1) * G + gi]) / (2 * cell), deg = Math.atan(Math.sqrt(sx * sx + sy * sy)) * 57.2958;
        var col = deg < 4 && low < -60 ? [91, 124, 250, 125] : (deg < 6 && low < -20) || (deg < 2 && low < -6) ? [169, 193, 255, 115] : null;
        if (col) { k = (j * Q + i) * 4; o[k] = col[0]; o[k + 1] = col[1]; o[k + 2] = col[2]; o[k + 3] = col[3]; }
      }
      g.putImageData(im, 0, 0);
      return new Promise(function (done) { c.toBlob(function (bl) { bl.arrayBuffer().then(function (ab) { done({ data: ab }); }); }, 'image/png'); });
    });
  }

  // The layers that are switched on and off, put into the style where they belong: areas under the roads, lines over
  // them, signs and dots on top.
  function addOverlays(S, cfg, dem, V) {
    var L = S.layers, at = function (id) { for (var i = 0; i < L.length; i++) if (L[i].id === id) return i; return -1; };
    var src = {}, zw = function (stops) { var o = ['interpolate', ['exponential', 1.6], ['zoom']]; stops.forEach(function (s) { o.push(s[0], s[1]); }); return o; };
    (cfg.overlays || []).forEach(function (o) {
      S.sources['ov-' + o.group] = o.raster ? { type: 'raster', url: 'pmtiles://' + DATA + o.file + V, tileSize: 256 } : { type: 'vector', url: 'pmtiles://' + DATA + o.file + V };
      o.layers.forEach(function (l) { src[l] = 'ov-' + o.group; });
    });
    var mk = function (id, type, layer, paint, extra) { var l = { id: id, type: type, source: src[layer], 'source-layer': layer, paint: paint }; if (extra) Object.keys(extra).forEach(function (k) { l[k] = extra[k]; }); return l; };
    var match = function (prop, table, other) { var m = ['match', ['get', prop]]; Object.keys(table).forEach(function (k) { m.push(k, table[k][0]); }); m.push(other); return m; };
    var fills = [], lines = [], tops = [];
    if (src.timber) fills.push({ id: 'timber', type: 'raster', source: src.timber, paint: { 'raster-opacity': 0.6, 'raster-fade-duration': 0, 'raster-resampling': 'nearest' } });
    if (src.rocks) fills.push(mk('rocks', 'fill', 'rocks', { 'fill-color': match('k', ROCK, '#cccccc'), 'fill-opacity': 0.5, 'fill-outline-color': 'rgba(60,60,60,.45)' }));
    if (src.deer_elk) fills.push(mk('deer-elk', 'fill', 'deer_elk', { 'fill-color': match('k', HAB, '#cccccc'), 'fill-opacity': 0.38 }));
    if (src.soils) fills.push(mk('soils', 'fill', 'soils', { 'fill-color': ['match', ['get', 'c'], 1, '#1b7f3b', 2, '#1b7f3b', 3, '#7cb342', '#c0ca33'], 'fill-opacity': 0.45 }));
    if (src.landslides) fills.push(mk('landslides', 'fill', 'landslides', { 'fill-color': '#8d5524', 'fill-opacity': 0.4, 'fill-outline-color': '#5d3310' }));
    if (src.flood) fills.push(mk('flood', 'fill', 'flood', { 'fill-color': '#3b82f6', 'fill-opacity': 0.32 }));
    if (src.fires) {
      fills.push(mk('fires', 'fill', 'fires', { 'fill-color': ['step', ['to-number', ['get', 'y'], 0], '#8d7b68', 2000, '#d9a02b', 2010, '#e8590c', 2020, '#c92a2a'], 'fill-opacity': 0.42 }));
      fills.push(mk('fires-line', 'line', 'fires', { 'line-color': ['step', ['to-number', ['get', 'y'], 0], '#5c4f42', 2000, '#8a5a00', 2010, '#a33a00', 2020, '#8f1d1d'], 'line-width': 1.6, 'line-opacity': 0.85 }));
    }
    if (dem) {
      ['steep', 'sunny', 'frost'].forEach(function (w) {
        S.sources[w] = { type: 'raster', tiles: ['ark-slope://' + w + '/{z}/{x}/{y}'], tileSize: 512, minzoom: 9, maxzoom: cfg.terrain.maxzoom, bounds: cfg.reach || cfg.bbox };
        fills.push({ id: w, type: 'raster', source: w, minzoom: 9, paint: { 'raster-opacity': 1, 'raster-fade-duration': 0, 'raster-resampling': 'linear' } });
      });
    }
    if (src.fish) {
      lines.push(mk('fish-trout', 'line', 'fish', { 'line-color': '#845ef7', 'line-width': zw([[9, 3], [14, 7]]), 'line-opacity': 0.4 }, { filter: ['==', ['get', 'k'], 'trout'], layout: { 'line-cap': 'round' } }));
      lines.push(mk('fish-salmon', 'line', 'fish', { 'line-color': '#e8590c', 'line-width': zw([[9, 3], [14, 7]]), 'line-opacity': 0.45 }, { filter: ['==', ['get', 'k'], 'salmon'], layout: { 'line-cap': 'round' } }));
    }
    if (src.streams) {
      lines.push(mk('streams-s', 'line', 'streams', { 'line-color': '#5aa9e6', 'line-width': zw([[12, 1], [15, 1.8]]), 'line-dasharray': [3, 2] }, { filter: ['in', ['get', 'k'], ['literal', ['s', 'u']]] }));
      lines.push(mk('streams-d', 'line', 'streams', { 'line-color': '#00897b', 'line-width': 1.4, 'line-dasharray': [1, 1.5] }, { filter: ['==', ['get', 'k'], 'd'] }));
      lines.push(mk('streams-y', 'line', 'streams', { 'line-color': '#1565c0', 'line-width': zw([[9, 1], [12, 1.8], [15, 3]]) }, { filter: ['==', ['get', 'k'], 'y'] }));
    }
    if (src.sections) {
      lines.push(mk('sections', 'line', 'sections', { 'line-color': '#555', 'line-width': 0.8, 'line-dasharray': [4, 3], 'line-opacity': 0.8 }, { minzoom: 11 }));
      if (src.townships) lines.push(mk('townships', 'line', 'townships', { 'line-color': '#333', 'line-width': 1.6, 'line-opacity': 0.7 }));
    }
    if (src.backroads) lines.push(mk('backroads', 'line', 'backroads', { 'line-color': match('k', ROAD, '#868e96'), 'line-width': zw([[11, 2.5], [14, 5.5], [17, 9]]), 'line-opacity': 0.6 },
      { minzoom: 11, layout: { 'line-cap': 'round', 'line-join': 'round' } }));
    if (src.trails) {   // a pale edge so a trail shows over the photos and the shading
      var tuse = ['case', ['in', 'm', ['coalesce', ['get', 'u'], '']], TRAIL.m[0], ['in', 'b', ['coalesce', ['get', 'u'], '']], TRAIL.b[0], ['in', 'h', ['coalesce', ['get', 'u'], '']], TRAIL.h[0],
        ['in', 'f', ['coalesce', ['get', 'u'], '']], TRAIL.f[0], TRAIL.x[0]];
      lines.push(mk('trails-case', 'line', 'trails', { 'line-color': 'rgba(255,255,255,.75)', 'line-width': zw([[9, 3], [12, 4.2], [15, 6.5]]) }, { layout: { 'line-cap': 'round', 'line-join': 'round' } }));
      lines.push(mk('trails', 'line', 'trails', { 'line-color': tuse, 'line-width': zw([[9, 1.4], [12, 2.2], [15, 3.6]]), 'line-dasharray': [3, 1.2] }, { layout: { 'line-join': 'round' } }));
    }
    if (src.hunt_units) lines.push(mk('hunt-units', 'line', 'hunt_units', { 'line-color': '#3f6212', 'line-width': zw([[7, 1.6], [13, 3]]), 'line-dasharray': [4, 2], 'line-opacity': 0.9 }));
    if (src.escape) lines.push(mk('escape', 'line', 'escape', { 'line-color': '#2f9e44', 'line-width': zw([[9, 2.5], [14, 5]]), 'line-opacity': 0.75 }, { layout: { 'line-cap': 'round', 'line-join': 'round' } }));
    if (src.routes) lines.push(mk('routes', 'line', 'routes', { 'line-color': '#7b2cbf', 'line-width': zw([[8, 2], [14, 4]]), 'line-dasharray': [2, 1.5], 'line-opacity': 0.85 }));
    var dot = function (id, layer, color, minzoom) { return mk(id, 'circle', layer, { 'circle-color': color, 'circle-radius': zw([[10, 3.2], [14, 5.5]]), 'circle-stroke-color': '#fff', 'circle-stroke-width': 1.2 }, minzoom ? { minzoom: minzoom } : null); };
    var sign = function (id, layer, icon, minzoom) {
      return mk(id, 'symbol', layer, { 'text-color': '#222', 'text-halo-color': 'rgba(255,255,255,.9)', 'text-halo-width': 1.4 }, { minzoom: minzoom || 9,
        layout: { 'icon-image': icon, 'icon-size': zw([[9, 0.6], [14, 0.95]]), 'icon-allow-overlap': true, 'text-field': ['step', ['zoom'], '', 13, ['coalesce', ['get', 'n'], '']], 'text-font': ['Noto Sans Regular'],
          'text-size': 11.5, 'text-offset': [0, 1.2], 'text-anchor': 'top', 'text-optional': true, 'text-max-width': 8 } });
    };
    if (src.backroad_labels) tops.push(mk('backroad-nums', 'symbol', 'backroad_labels', { 'text-color': '#1f1f1f', 'text-halo-color': 'rgba(255,255,255,.95)', 'text-halo-width': 2 }, { minzoom: 12,
      layout: { 'text-field': ['get', 'n'], 'text-font': ['Noto Sans Medium'], 'text-size': zw([[12, 10], [15, 12.5]]), 'text-padding': 3 } }));
    if (src.hunt_units) tops.push(mk('hunt-unit-names', 'symbol', 'hunt_units', { 'text-color': '#2f4a0d', 'text-halo-color': 'rgba(255,255,255,.9)', 'text-halo-width': 1.6 },
      { layout: { 'symbol-placement': 'line', 'text-field': ['concat', ['get', 'n'], ' unit'], 'text-font': ['Noto Sans Medium'], 'text-size': 12.5, 'symbol-spacing': 420, 'text-offset': [0, 0.9], 'text-max-angle': 30 } }));
    if (src.game) tops.push(dot('game', 'game', match('k', GAME, '#666')));
    if (src.wells) tops.push(dot('wells', 'wells', ['step', ['to-number', ['get', 'd'], 0], '#2b8a3e', 75, '#f08c00', 200, '#c92a2a'], 12));
    if (src.wildfood) tops.push(dot('wildfood', 'wildfood', match('k', { nut: ['#8d6e63'], berry: ['#7b1fa2'], fruit: ['#d81b60'], root: ['#ef6c00'], green: ['#2e7d32'], mushroom: ['#b08d57'] }, '#666')));
    if (src.mines) { var md = dot('mines', 'mines', match('k', { gold: ['#f5b301'], chrome: ['#607d8b'], copper: ['#bf5b17'], lime: ['#e0e0e0'], clay: ['#a1543f'], stone: ['#9e9e9e'], coal: ['#212121'], metal: ['#455a64'], mineral: ['#ec407a'] }, '#777')); md.paint['circle-stroke-color'] = '#222'; tops.push(md); }
    if (src.section_labels) tops.push(mk('section-labels', 'symbol', 'section_labels', { 'text-color': '#444', 'text-halo-color': 'rgba(255,255,255,.8)', 'text-halo-width': 1.2 }, { minzoom: 12, layout: { 'text-field': ['get', 's'], 'text-font': ['Noto Sans Medium'], 'text-size': 12 } }));
    if (src.springs) tops.push(sign('springs', 'springs', ['match', ['get', 'k'], 'fall', 'b-fall', 'b-spring'], 10));
    if (src.dams) tops.push(sign('dams', 'dams', 'b-dam', 9));
    if (src.places) tops.push(sign('poi', 'places', ['concat', 'b-', ['get', 'k']], 11));
    if (src.trails) tops.push(mk('trail-names', 'symbol', 'trails', { 'text-color': '#5b3a1a', 'text-halo-color': 'rgba(255,255,255,.92)', 'text-halo-width': 1.8 }, { minzoom: 12,
      layout: { 'symbol-placement': 'line', 'text-field': ['concat', ['coalesce', ['get', 'n'], ''], ['case', ['has', 'no'], ['concat', ' ', ['get', 'no']], '']], 'text-font': ['Noto Sans Medium'],
        'text-size': zw([[12, 10.5], [15, 12.5]]), 'symbol-spacing': 300, 'text-offset': [0, 0.85], 'text-max-angle': 70 } }));   // mountain trails bend: a tighter limit finds no room
    if (src.trailheads) tops.push(sign('trailheads', 'trailheads', 'b-trailhead', 11));
    if (src.gates) tops.push(sign('gates', 'gates', ['concat', 'b-', ['get', 'k']], 11));
    if (src.towers) tops.push(sign('towers', 'towers', ['concat', 'b-', ['get', 'k']], 9));
    // one town's walking routes, all the way (?route=<town> in the address; showRoute)
    S.sources['route-pick'] = { type: 'geojson', data: { type: 'FeatureCollection', features: [] } };
    var rline = function (k, color, dash) {
      var l = { id: 'route-' + k, type: 'line', source: 'route-pick', filter: ['==', ['get', 'k'], k], layout: { 'line-join': 'round', 'line-cap': dash ? 'butt' : 'round' },
        paint: { 'line-color': color, 'line-width': zw([[5, 2.5], [10, 4], [15, 6.5]]), 'line-opacity': 0.95 } };
      if (dash) l.paint['line-dasharray'] = [1.6, 1.1];
      return l;
    };
    tops.push({ id: 'route-case', type: 'line', source: 'route-pick', filter: ['==', ['geometry-type'], 'LineString'], layout: { 'line-join': 'round', 'line-cap': 'round' },
      paint: { 'line-color': 'rgba(255,255,255,.85)', 'line-width': zw([[5, 5], [10, 7], [15, 10.5]]) } });
    tops.push(rline('bike', ROUTEWAY.bike[1], true), rline('hwy', ROUTEWAY.hwy[1]), rline('back', ROUTEWAY.back[1]));
    tops.push({ id: 'route-ends', type: 'circle', source: 'route-pick', filter: ['==', ['geometry-type'], 'Point'],
      paint: { 'circle-radius': 7, 'circle-color': ['match', ['get', 'k'], 'start', '#2b8a3e', '#c92a2a'], 'circle-stroke-color': '#fff', 'circle-stroke-width': 2.5 } });
    tops.push({ id: 'route-names', type: 'symbol', source: 'route-pick', filter: ['==', ['geometry-type'], 'Point'],
      layout: { 'text-field': ['get', 'n'], 'text-font': ['Noto Sans Medium'], 'text-size': 13.5, 'text-offset': [0, 1.1], 'text-anchor': 'top' },
      paint: { 'text-color': '#1f1f1f', 'text-halo-color': 'rgba(255,255,255,.95)', 'text-halo-width': 2 } });
    S.sources.measure = { type: 'geojson', data: { type: 'FeatureCollection', features: [] } };
    S.sources.pins = { type: 'geojson', data: { type: 'FeatureCollection', features: [] } };
    S.sources['shared-pins'] = { type: 'geojson', data: { type: 'FeatureCollection', features: [] } };
    S.sources.mesh = { type: 'geojson', data: { type: 'FeatureCollection', features: [] } };
    tops.push({ id: 'measure-line', type: 'line', source: 'measure', filter: ['==', ['geometry-type'], 'LineString'], paint: { 'line-color': '#0b7285', 'line-width': 3.5, 'line-dasharray': [2, 1] } });
    tops.push({ id: 'measure-pts', type: 'circle', source: 'measure', filter: ['==', ['geometry-type'], 'Point'], paint: { 'circle-radius': 6, 'circle-color': '#fff', 'circle-stroke-color': '#0b7285', 'circle-stroke-width': 3 } });
    tops.push({ id: 'pins', type: 'symbol', source: 'pins', layout: { 'icon-image': 'b-pin', 'icon-size': 1, 'icon-allow-overlap': true, 'icon-anchor': 'bottom', 'text-field': ['get', 'name'], 'text-font': ['Noto Sans Medium'], 'text-size': 12.5,
      'text-offset': [0, 0.3], 'text-anchor': 'top', 'text-optional': true }, paint: { 'text-color': '#7a1f1f', 'text-halo-color': '#fff', 'text-halo-width': 1.6 } });
    tops.push({ id: 'shared-pins', type: 'symbol', source: 'shared-pins', layout: { 'icon-image': 'b-shared', 'icon-size': 1, 'icon-allow-overlap': true, 'icon-anchor': 'bottom', 'text-field': ['get', 'name'], 'text-font': ['Noto Sans Medium'], 'text-size': 12.5,
      'text-offset': [0, 0.3], 'text-anchor': 'top', 'text-optional': true }, paint: { 'text-color': '#0b4f6c', 'text-halo-color': '#fff', 'text-halo-width': 1.6 } });
    // people heard over the mesh: where they have been, how vague a position is, and where they are now
    tops.push({ id: 'mesh-vague', type: 'fill', source: 'mesh', filter: ['==', ['get', 'kind'], 'vague'],
      paint: { 'fill-color': '#e8590c', 'fill-opacity': 0.12, 'fill-outline-color': '#e8590c' } });
    tops.push({ id: 'mesh-track', type: 'line', source: 'mesh', filter: ['==', ['get', 'kind'], 'track'],
      layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': '#e8590c', 'line-width': 3, 'line-opacity': 0.75, 'line-dasharray': [1, 1.2] } });
    tops.push({ id: 'mesh-dot', type: 'circle', source: 'mesh', filter: ['==', ['get', 'kind'], 'person'],
      paint: { 'circle-radius': 7, 'circle-color': '#e8590c', 'circle-stroke-color': '#fff', 'circle-stroke-width': 2.5,
        // a position no one has heard for an hour fades, so an old dot never looks like a live one
        'circle-opacity': ['case', ['>', ['get', 'age'], 3600], 0.45, 1],
        'circle-stroke-opacity': ['case', ['>', ['get', 'age'], 3600], 0.45, 1] } });
    tops.push({ id: 'mesh-wp', type: 'symbol', source: 'mesh', filter: ['==', ['get', 'kind'], 'waypoint'],
      layout: { 'text-field': ['concat', ['case', ['!=', ['get', 'icon'], ''], ['concat', ['get', 'icon'], ' '], ''], ['get', 'name']],
        'text-font': ['Noto Sans Medium'], 'text-size': 13, 'text-allow-overlap': false, 'text-optional': false },
      paint: { 'text-color': '#7048e8', 'text-halo-color': '#fff', 'text-halo-width': 2 } });
    tops.push({ id: 'mesh-name', type: 'symbol', source: 'mesh', filter: ['==', ['get', 'kind'], 'person'],
      layout: { 'text-field': ['get', 'name'], 'text-font': ['Noto Sans Medium'], 'text-size': 12.5, 'text-offset': [0, 0.9], 'text-anchor': 'top', 'text-optional': true },
      paint: { 'text-color': '#9a3412', 'text-halo-color': '#fff', 'text-halo-width': 1.6 } });
    var i = at('hillshade'); if (i < 0) i = at('water'); L.splice.apply(L, [i, 0].concat(fills));
    i = at('rail'); L.splice.apply(L, [i + 1, 0].concat(lines));
    tops.forEach(function (l) { L.push(l); });
  }

  // The street map is asked for tile by tile, with no fence round it. Beyond the map's own area the fine tiles are
  // not in the file; the coarse ones that are (each reaches far past the area) are drawn instead, so the country round
  // the map shows when it is zoomed out.
  function streetsSource(cfg) {
    return { type: 'vector', tiles: ['ark-streets://{z}/{x}/{y}'], minzoom: 0, maxzoom: Math.max(cfg.streets_maxzoom || 15, cfg.far ? cfg.far.streets_maxzoom : 0),
      attribution: '© OpenStreetMap contributors' };
  }

  // The same map for the receipt printer: no colours, so everything is told apart by the kind of line. Roads are solid
  // (main roads a double line), forest tracks dashed, trails dotted, creeks dash-dot, contour lines thin, tax lots long
  // dashes, public-land edges short heavy dashes, water a pattern of dots (blackAndWhite makes it from the grey).
  function printStyle(cfg, dem, on) {
    var FONT = ['Noto Sans Regular'], BOLD = ['Noto Sans Medium'], ITAL = ['Noto Sans Italic'], V = cfg.v ? '?v=' + cfg.v : '';
    var kind = function (v) { return ['==', ['get', 'kind'], v]; }, kinds = function (a) { return ['in', ['get', 'kind'], ['literal', a]]; };
    var detail = function (a) { return ['in', ['get', 'kind_detail'], ['literal', a]]; };
    var S = { version: 8, glyphs: new URL('fonts/', location.href).href + '{fontstack}/{range}.pbf', sources: { streets: streetsSource(cfg) }, layers: [] };
    var L = S.layers, prop = cfg.property, K = '#000';
    var line = function (id, src, layer, filter, w, dash, minzoom, color) {
      var l = { id: id, type: 'line', source: src, 'source-layer': layer, layout: { 'line-join': 'round' }, paint: { 'line-color': color || K, 'line-width': w } };
      if (filter) l.filter = filter; if (dash) l.paint['line-dasharray'] = dash; if (minzoom) l.minzoom = minzoom; L.push(l);
    };
    L.push({ id: 'bg', type: 'background', paint: { 'background-color': '#fff' } });
    L.push({ id: 'water', type: 'fill', source: 'streets', 'source-layer': 'water', filter: ['==', ['geometry-type'], 'Polygon'], paint: { 'fill-color': '#c8c8c8', 'fill-antialias': false } });
    if (dem && on.contours) {
      S.sources.contours = { type: 'vector', maxzoom: 15, bounds: cfg.reach || cfg.bbox, tiles: [dem.contourProtocolUrl({ multiplier: 3.28084, overzoom: 1, elevationKey: 'ele', levelKey: 'level', contourLayer: 'contours',
        thresholds: { 10: [200, 1000], 12: [80, 400], 13: [40, 200] } })] };
      L.push({ id: 'contour-lines', type: 'line', source: 'contours', 'source-layer': 'contours', minzoom: 10, paint: { 'line-color': K, 'line-width': ['match', ['get', 'level'], 1, 1.3, 0.55] } });
    }
    line('streams', 'streets', 'water', ['all', ['==', ['geometry-type'], 'LineString'], kinds(['stream', 'canal', 'ditch', 'drain'])], 1.2, [5, 2, 1, 2], 11);
    line('rivers', 'streets', 'water', ['all', ['==', ['geometry-type'], 'LineString'], kind('river')], 1.8, [6, 2, 1, 2]);
    if (prop) S.sources.property = { type: 'vector', url: 'pmtiles://' + DATA + prop.file + V };
    if (prop && prop.ownership && on.own) {
      var pub = ['in', ['get', 'own'], ['literal', Object.keys(OWN).filter(function (c) { return OWN[c][1]; })]];
      line('own-line', 'property', 'ownership', pub, 2, [1, 1.6], 9);
    }
    if (prop && prop.parcels && on.parcels) line('parcel-lines', 'property', 'parcels', null, 0.9, [7, 4], 12);
    L.push({ id: 'buildings', type: 'fill', source: 'streets', 'source-layer': 'buildings', filter: ['==', ['geometry-type'], 'Polygon'], minzoom: 14, paint: { 'fill-color': K } });
    var minor = ['all', kind('minor_road'), ['!', detail(['service'])]], svc = ['all', kind('minor_road'), detail(['service'])];
    var big = ['any', kind('highway'), ['all', kind('major_road'), detail(['trunk', 'trunk_link', 'primary', 'primary_link'])]];
    var mid = ['all', kind('major_road'), detail(['secondary', 'secondary_link', 'tertiary', 'tertiary_link'])];
    line('trail', 'streets', 'roads', ['all', kind('path'), ['!', detail(['track', 'driveway', 'pier', 'steps'])]], 1.2, [1, 2], 12);
    line('track', 'streets', 'roads', ['all', kind('path'), detail(['track'])], 1.3, [4, 2], 11);
    line('svc', 'streets', 'roads', svc, 0.9, null, 13);
    line('minor', 'streets', 'roads', minor, 1.6, null, 11);
    line('mid', 'streets', 'roads', mid, 2.6);
    line('big-case', 'streets', 'roads', big, 4.6);
    line('big', 'streets', 'roads', big, 1.8, null, 0, '#fff');
    line('rail', 'streets', 'roads', kind('rail'), 1.4, [8, 3]);
    line('county', 'streets', 'boundaries', kinds(['county', 'region', 'country']), 1.4, [8, 3, 2, 3]);
    var label = function (id, src, layer, filter, layout, minzoom) {
      var l = { id: id, type: 'symbol', source: src, 'source-layer': layer, filter: filter,
        layout: Object.assign({ 'text-field': ['get', 'name'], 'text-font': FONT, 'text-size': 12, 'text-max-width': 8 }, layout), paint: { 'text-color': K, 'text-halo-color': '#fff', 'text-halo-width': 2 } };
      if (minzoom) l.minzoom = minzoom; L.push(l);
    };
    if (dem && on.contours) label('contour-labels', 'contours', 'contours', ['>', ['get', 'level'], 0], { 'symbol-placement': 'line', 'text-size': 11, 'text-field': ['number-format', ['get', 'ele'], {}], 'symbol-spacing': 300, 'text-max-angle': 28 }, 12);
    label('creek-names', 'streets', 'water', ['all', ['==', ['geometry-type'], 'LineString'], ['has', 'name']], { 'symbol-placement': 'line', 'text-font': ITAL, 'text-size': 12, 'symbol-spacing': 350 }, 11);
    label('lake-names', 'streets', 'water', ['all', ['==', ['geometry-type'], 'Polygon'], ['has', 'name']], { 'text-font': ITAL, 'text-size': 12 }, 11);
    label('road-names', 'streets', 'roads', ['has', 'name'], { 'symbol-placement': 'line', 'text-size': 11.5, 'symbol-spacing': 300 }, 12);
    label('shields', 'streets', 'roads', ['all', ['has', 'ref'], big], { 'symbol-placement': 'line', 'text-field': ['get', 'ref'], 'text-font': BOLD, 'text-size': 12, 'symbol-spacing': 420 }, 8);
    L.push({ id: 'peak-dots', type: 'circle', source: 'streets', 'source-layer': 'pois', filter: kind('peak'), minzoom: 11, paint: { 'circle-radius': 3, 'circle-color': K, 'circle-stroke-color': '#fff', 'circle-stroke-width': 1 } });
    label('peaks', 'streets', 'pois', ['all', kind('peak'), ['has', 'name']], { 'text-offset': [0, 0.5], 'text-anchor': 'top', 'text-size': 12,
      'text-field': ['case', ['has', 'elevation'], ['concat', ['get', 'name'], '\n', ['number-format', ['round', ['*', ['to-number', ['get', 'elevation']], 3.28084]], {}], ' ft'], ['get', 'name']] }, 11);
    label('places', 'streets', 'places', kind('locality'), { 'text-font': BOLD, 'text-size': 15, 'symbol-sort-key': ['get', 'min_zoom'] });
    return S;
  }

  function style(cfg, dem) {
    var FONT = ['Noto Sans Regular'], BOLD = ['Noto Sans Medium'], ITAL = ['Noto Sans Italic'];
    var V = cfg.v ? '?v=' + cfg.v : '';   // the files' version: a saved copy of an older map isn't used for a newer one
    var kind = function (v) { return ['==', ['get', 'kind'], v]; }, kinds = function (a) { return ['in', ['get', 'kind'], ['literal', a]]; };
    var detail = function (a) { return ['in', ['get', 'kind_detail'], ['literal', a]]; };
    var zw = function (stops) { var o = ['interpolate', ['exponential', 1.6], ['zoom']]; stops.forEach(function (s) { o.push(s[0], s[1]); }); return o; };
    var S = { version: 8, glyphs: new URL('fonts/', location.href).href + '{fontstack}/{range}.pbf',
      sources: { streets: streetsSource(cfg) }, layers: [] };
    var L = S.layers, prop = cfg.property;
    if (prop) S.sources.property = { type: 'vector', url: 'pmtiles://' + DATA + prop.file + V };
    if (dem) {
      S.sources.dem = { type: 'raster-dem', encoding: 'terrarium', tiles: [dem.sharedDemProtocolUrl], maxzoom: cfg.terrain.maxzoom, tileSize: 512, bounds: cfg.reach || cfg.bbox };
      // feet: 200 ft lines from far out, 40 ft lines (every 5th one heavy) close in, as on a USGS quad
      S.sources.contours = { type: 'vector', maxzoom: 15, bounds: cfg.reach || cfg.bbox, attribution: '© Mapterhorn', tiles: [dem.contourProtocolUrl({ multiplier: 3.28084, overzoom: 1, elevationKey: 'ele', levelKey: 'level', contourLayer: 'contours',
        thresholds: { 10: [200, 1000], 12: [80, 400], 13: [40, 200] } })] };
    }
    L.push({ id: 'bg', type: 'background', paint: { 'background-color': '#f6f3e9' } });
    L.push({ id: 'woods', type: 'fill', source: 'streets', 'source-layer': 'landuse', filter: kinds(['wood', 'forest', 'scrub']), paint: { 'fill-color': '#dcebcc', 'fill-opacity': 0.8 } });
    L.push({ id: 'open', type: 'fill', source: 'streets', 'source-layer': 'landuse', filter: kinds(['farmland', 'meadow', 'grass', 'grassland', 'park', 'golf_course', 'recreation_ground', 'cemetery', 'pitch']), paint: { 'fill-color': '#eef0d3', 'fill-opacity': 0.8 } });
    L.push({ id: 'town', type: 'fill', source: 'streets', 'source-layer': 'landuse', filter: kinds(['residential', 'commercial', 'industrial', 'school']), paint: { 'fill-color': '#ece6da', 'fill-opacity': 0.8 } });
    L.push({ id: 'wetland', type: 'fill', source: 'streets', 'source-layer': 'landuse', filter: kind('wetland'), paint: { 'fill-color': '#cfe6e0', 'fill-opacity': 0.8 } });
    if (cfg.satellite) {   // the photos: over the map's own colours, under the public land, the layers, the shading and everything drawn
      S.sources.sat = { type: 'raster', tiles: ['ark-sat://{z}/{x}/{y}'], tileSize: 256, minzoom: 0, maxzoom: cfg.satDetail ? Math.max(cfg.satDetail.maxzoom, cfg.satellite.maxzoom) : cfg.satellite.online_maxzoom || cfg.satellite.maxzoom,
        attribution: cfg.satellite.credit || 'USGS' };
      L.push({ id: 'sat', type: 'raster', source: 'sat', paint: { 'raster-opacity': 1, 'raster-fade-duration': 0 } });
    }
    if (prop && prop.ownership) {
      var col = ['match', ['get', 'own']]; Object.keys(OWN).forEach(function (c) { if (OWN[c][1]) col.push(c, OWN[c][1]); }); col.push('rgba(0,0,0,0)');
      var pub = ['in', ['get', 'own'], ['literal', Object.keys(OWN).filter(function (c) { return OWN[c][1]; })]];
      L.push({ id: 'own-fill', type: 'fill', source: 'property', 'source-layer': 'ownership', filter: pub, paint: { 'fill-color': col, 'fill-opacity': 0.5 } });
      L.push({ id: 'own-hit', type: 'fill', source: 'property', 'source-layer': 'ownership', filter: ['!', pub], paint: { 'fill-color': '#000', 'fill-opacity': 0 } });
    }
    if (dem) L.push({ id: 'hillshade', type: 'hillshade', source: 'dem', paint: { 'hillshade-exaggeration': 0.32, 'hillshade-shadow-color': '#4a3f2e', 'hillshade-highlight-color': '#ffffff', 'hillshade-accent-color': '#6b5d48' } });
    L.push({ id: 'water', type: 'fill', source: 'streets', 'source-layer': 'water', filter: ['==', ['geometry-type'], 'Polygon'], paint: { 'fill-color': '#b8d8f0' } });
    L.push({ id: 'streams', type: 'line', source: 'streets', 'source-layer': 'water', filter: ['all', ['==', ['geometry-type'], 'LineString'], kinds(['stream', 'canal', 'ditch', 'drain'])], minzoom: 11,
      paint: { 'line-color': '#4f93cf', 'line-width': zw([[11, 0.5], [14, 1.1], [17, 2.5]]) } });
    L.push({ id: 'rivers', type: 'line', source: 'streets', 'source-layer': 'water', filter: ['all', ['==', ['geometry-type'], 'LineString'], kind('river')],
      paint: { 'line-color': '#4f93cf', 'line-width': zw([[8, 0.8], [12, 1.8], [16, 4]]) } });
    if (dem) {
      L.push({ id: 'contour-lines', type: 'line', source: 'contours', 'source-layer': 'contours', minzoom: 10,
        paint: { 'line-color': '#9a5b22', 'line-opacity': ['match', ['get', 'level'], 1, 0.75, 0.42], 'line-width': ['match', ['get', 'level'], 1, 1.15, 0.6] } });
    }
    if (prop && prop.ownership) L.push({ id: 'own-line', type: 'line', source: 'property', 'source-layer': 'ownership', minzoom: 9, paint: { 'line-color': '#7a6a3a', 'line-opacity': 0.45, 'line-width': 0.8 } });
    L.push({ id: 'county', type: 'line', source: 'streets', 'source-layer': 'boundaries', filter: kinds(['county', 'region', 'country']), paint: { 'line-color': '#8a7fa8', 'line-dasharray': [5, 3], 'line-width': 1.2 } });
    L.push({ id: 'buildings', type: 'fill', source: 'streets', 'source-layer': 'buildings', filter: ['==', ['geometry-type'], 'Polygon'], minzoom: 14, paint: { 'fill-color': '#c9c2b2' } });
    if (prop && prop.parcels) {
      L.push({ id: 'parcel-hit', type: 'fill', source: 'property', 'source-layer': 'parcels', minzoom: 12, paint: { 'fill-color': '#000', 'fill-opacity': 0 } });
      L.push({ id: 'parcel-lines', type: 'line', source: 'property', 'source-layer': 'parcels', minzoom: 12,
        paint: { 'line-color': '#d9480f', 'line-opacity': zw([[12, 0.35], [14, 0.75]]), 'line-width': zw([[12, 0.4], [14, 0.9], [17, 1.8]]) } });
    }
    // roads: forest tracks dashed, trails dotted, as on a topo map
    var road = function (id, filter, color, w, extra) {
      var l = { id: id, type: 'line', source: 'streets', 'source-layer': 'roads', filter: filter, layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': color, 'line-width': zw(w) } };
      if (extra) Object.keys(extra).forEach(function (k) { if (k === 'minzoom') l.minzoom = extra[k]; else if (k === 'cap') l.layout['line-cap'] = extra[k]; else l.paint[k] = extra[k]; });
      L.push(l);
    };
    var minor = ['all', kind('minor_road'), ['!', detail(['service'])]], svc = ['all', kind('minor_road'), detail(['service'])];
    var big = ['any', kind('highway'), ['all', kind('major_road'), detail(['trunk', 'trunk_link', 'primary', 'primary_link'])]];
    var mid = ['all', kind('major_road'), detail(['secondary', 'secondary_link', 'tertiary', 'tertiary_link'])];
    var track = ['all', kind('path'), detail(['track'])], trail = ['all', kind('path'), ['!', detail(['track', 'driveway', 'pier', 'steps'])]];
    road('trail', trail, '#5b4636', [[12, 0.8], [15, 1.4], [18, 2.5]], { 'line-dasharray': [1, 2], minzoom: 12, cap: 'butt' });
    road('track', track, '#6b5540', [[11, 0.6], [14, 1.3], [18, 3]], { 'line-dasharray': [4, 2], minzoom: 11, cap: 'butt' });
    road('svc-case', svc, '#a59d8f', [[13, 1], [15, 2.4], [18, 6.4]], { minzoom: 13 });
    road('svc', svc, '#ffffff', [[13, 0.5], [15, 1.4], [18, 5]], { minzoom: 13 });
    road('minor-case', minor, '#9b9488', [[11, 0.9], [14, 3], [18, 13]], { minzoom: 11 });
    road('mid-case', mid, '#8f7d54', [[8, 1], [12, 3], [15, 6], [18, 17]]);
    road('big-case', big, '#8a4b3c', [[7, 1.4], [12, 4], [15, 8], [18, 20]]);
    road('minor', minor, '#ffffff', [[11, 0.5], [14, 2], [18, 11]], { minzoom: 11 });
    road('mid', mid, '#fbe9a6', [[8, 0.5], [12, 2], [15, 4.5], [18, 15]]);
    road('big', big, '#f3b3a0', [[7, 0.8], [12, 2.8], [15, 6.5], [18, 18]]);
    L.push({ id: 'rail', type: 'line', source: 'streets', 'source-layer': 'roads', filter: kind('rail'), paint: { 'line-color': '#555', 'line-dasharray': [6, 3], 'line-width': 1.2 } });
    // names
    var label = function (id, layer, filter, layout, paint, minzoom) {
      var l = { id: id, type: 'symbol', source: 'streets', 'source-layer': layer, filter: filter,
        layout: Object.assign({ 'text-field': ['get', 'name'], 'text-font': FONT, 'text-size': 12, 'text-max-width': 8 }, layout),
        paint: Object.assign({ 'text-color': '#333', 'text-halo-color': 'rgba(255,255,255,0.85)', 'text-halo-width': 1.4 }, paint || {}) };
      if (minzoom) l.minzoom = minzoom; L.push(l);
    };
    if (dem) L.push({ id: 'contour-labels', type: 'symbol', source: 'contours', 'source-layer': 'contours', minzoom: 12, filter: ['>', ['get', 'level'], 0],
      layout: { 'symbol-placement': 'line', 'text-size': 10.5, 'text-font': FONT, 'text-field': ['number-format', ['get', 'ele'], {}], 'symbol-spacing': 320, 'text-max-angle': 28 },
      paint: { 'text-color': '#7a4516', 'text-halo-color': 'rgba(246,243,233,0.9)', 'text-halo-width': 1.5 } });
    label('creek-names', 'water', ['all', ['==', ['geometry-type'], 'LineString'], ['has', 'name']], { 'symbol-placement': 'line', 'text-font': ITAL, 'text-size': 11.5, 'symbol-spacing': 350, 'text-letter-spacing': 0.05 }, { 'text-color': '#22639c' }, 11);
    label('lake-names', 'water', ['all', ['==', ['geometry-type'], 'Polygon'], ['has', 'name']], { 'text-font': ITAL, 'text-size': 11.5 }, { 'text-color': '#22639c' }, 11);
    label('road-names', 'roads', ['all', ['has', 'name'], ['!', kind('path')]], { 'symbol-placement': 'line', 'text-size': zw([[12, 10], [16, 13]]), 'symbol-spacing': 300 }, { 'text-color': '#4a4136' }, 12);
    label('track-names', 'roads', ['all', ['has', 'name'], kind('path')], { 'symbol-placement': 'line', 'text-size': 10.5, 'symbol-spacing': 300 }, { 'text-color': '#5b4636' }, 13);
    label('shields', 'roads', ['all', ['has', 'ref'], big], { 'symbol-placement': 'line', 'text-field': ['get', 'ref'], 'text-font': BOLD, 'text-size': 10.5, 'symbol-spacing': 420, 'text-rotation-alignment': 'viewport' },
      { 'text-color': '#7a2d1c', 'text-halo-width': 2 }, 8);
    L.push({ id: 'peak-dots', type: 'circle', source: 'streets', 'source-layer': 'pois', filter: kind('peak'), minzoom: 11, paint: { 'circle-radius': 2.6, 'circle-color': '#6b3e12', 'circle-stroke-color': '#fff', 'circle-stroke-width': 1 } });
    label('peaks', 'pois', ['all', kind('peak'), ['has', 'name']], { 'text-offset': [0, 0.5], 'text-anchor': 'top', 'text-size': 11.5,
      'text-field': ['case', ['has', 'elevation'], ['concat', ['get', 'name'], '\n', ['number-format', ['round', ['*', ['to-number', ['get', 'elevation']], 3.28084]], {}], ' ft'], ['get', 'name']] },
      { 'text-color': '#5a3410' }, 11);
    label('pois', 'pois', ['all', ['has', 'name'], ['!', kinds(['peak', 'residential', 'water', 'district', 'administrative', 'path'])]], { 'text-size': 11, 'text-offset': [0, 0.3], 'text-anchor': 'top' }, { 'text-color': '#3d5a3a' }, 13);
    label('places', 'places', kind('locality'), { 'text-font': BOLD, 'symbol-sort-key': ['get', 'min_zoom'],
      'text-size': ['interpolate', ['linear'], ['zoom'], 8, ['case', ['<=', ['to-number', ['get', 'min_zoom'], 12], 8], 13, 10.5], 14, ['case', ['<=', ['to-number', ['get', 'min_zoom'], 12], 8], 19, 14]] },
      { 'text-color': '#1f1f1f', 'text-halo-width': 1.8 });
    addOverlays(S, cfg, dem, V);
    return S;
  }
})();
