/* The library in any web browser, with no program and no internet: OPEN-IN-BROWSER.html at the top of
   the drive. A page opened straight from a drive may not read other files by itself, so the person opens
   the library folder once (the browser asks); after that this page reads, right here in the browser:
   - the Library Assistant's search index (AI-Offline/Library-Assistant/index) to search inside every book
   - the e-books (EPUB: a zip of web pages) with its own small reader
   - Wikipedia and the other encyclopedias (Kiwix .zim files) with its own small reader (zstd: fzstd.js)
   Before the folder is open, the titles of everything (docs.js) can be searched and guides and books open. */
(function () {
  'use strict';
  var INFO = window.LIB_INFO || {};
  var DOCS = (window.LIB_DOCS || []).map(function (d, i) { return { t: d[0], p: d[1], d: d[2], w: d[3] || 1, i: i }; });
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('so-browser-' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('so-browser-' + k, JSON.stringify(v)); } catch (e) {} }
  };
  function href(path, hash) { return path.split('/').map(encodeURIComponent).join('/') + (hash || ''); }

  // ================================================================ the library folder
  var lib = { kind: '', dir: null, files: null, prefix: '', cache: {} };
  function idb(op, val) { // remembers the chosen folder (Chrome and Edge) so next time is one click
    return new Promise(function (ok) {
      try {
        var rq = indexedDB.open('so-browser', 1);
        rq.onupgradeneeded = function () { rq.result.createObjectStore('kv'); };
        rq.onsuccess = function () {
          var tx = rq.result.transaction('kv', op === 'get' ? 'readonly' : 'readwrite'), st = tx.objectStore('kv');
          var r = op === 'get' ? st.get('dir') : st.put(val, 'dir');
          r.onsuccess = function () { ok(r.result); }; r.onerror = function () { ok(null); };
        };
        rq.onerror = function () { ok(null); };
      } catch (e) { ok(null); }
    });
  }
  async function hasEntry(dir, name, kind) {
    try { return await (kind === 'dir' ? dir.getDirectoryHandle(name) : dir.getFileHandle(name)); } catch (e) { return null; }
  }
  async function useHandle(h) {
    if (!(await hasEntry(h, 'START-HERE.html'))) { // they chose the drive itself: look one folder down
      for await (var e of h.values()) {
        if (e.kind === 'directory' && await hasEntry(e, 'START-HERE.html')) { h = e; break; }
      }
    }
    if (!(await hasEntry(h, 'START-HERE.html'))) { libState('That folder doesn\'t look like the library (no START-HERE.html in it). Try again and choose the folder this page is in.', true); return false; }
    lib.kind = 'handle'; lib.dir = h; lib.cache = {};
    idb('put', h);
    opened();
    return true;
  }
  function useFiles(list) {
    var all = Array.prototype.slice.call(list), start = all.filter(function (f) { return /(^|\/)START-HERE\.html$/.test(f.webkitRelativePath); })
      .sort(function (a, b) { return a.webkitRelativePath.length - b.webkitRelativePath.length; })[0];
    if (!start) { libState('That folder doesn\'t look like the library (no START-HERE.html in it). Try again and choose the folder this page is in.', true); return; }
    var prefix = start.webkitRelativePath.slice(0, -'START-HERE.html'.length);
    lib.kind = 'files'; lib.files = new Map(); lib.cache = {};
    all.forEach(function (f) { var p = f.webkitRelativePath; if (p.indexOf(prefix) === 0) lib.files.set(p.slice(prefix.length), f); });
    opened();
  }
  async function getFile(path) {
    if (lib.kind === 'files') { var f = lib.files.get(path); if (!f) throw new Error('not on the drive: ' + path); return f; }
    if (lib.kind !== 'handle') throw new Error('Open the library folder first (button at the top).');
    var parts = path.split('/'), d = lib.dir;
    for (var i = 0; i < parts.length - 1; i++) d = await d.getDirectoryHandle(parts[i]);
    return (await d.getFileHandle(parts[parts.length - 1])).getFile();
  }
  async function findFiles(re, skip) { // every file whose path matches re (skipping big program/map folders)
    if (lib.kind === 'files') return Array.from(lib.files.keys()).filter(function (p) { return re.test(p); });
    var out = [];
    async function walk(d, base, depth) {
      for await (var e of d.values()) {
        var p = base + e.name;
        if (e.kind === 'directory') { if (depth < 6 && !(skip && skip.test(e.name))) await walk(e, p + '/', depth + 1); }
        else if (re.test(p)) out.push(p);
      }
    }
    await walk(lib.dir, '', 0);
    return out;
  }
  function libState(msg, bad) { var s = $('#libstate'); s.textContent = msg; s.style.color = bad ? '#e5534b' : ''; }
  async function pickFolder() {
    if (window.showDirectoryPicker) {
      try { var h = await window.showDirectoryPicker({ id: 'library', mode: 'read' }); await useHandle(h); return; }
      catch (e) { if (e && e.name === 'AbortError') return; }
    }
    $('#dirpick').click();
  }
  async function openAgain() {
    var h = await idb('get');
    if (!h) return pickFolder();
    try { if ((await h.requestPermission({ mode: 'read' })) === 'granted') { await useHandle(h); return; } } catch (e) {}
    pickFolder();
  }
  function opened() {
    $('#pick').textContent = '📂 Open a different folder';
    $('#again').hidden = true;
    libState('Library folder open. You can read the e-books and encyclopedias, and search inside the books.');
    loadIndex();
    listZims();
    if (pendingOpen) { var f = pendingOpen; pendingOpen = null; f(); }
  }
  var pendingOpen = null;
  function needFolder(then) {
    if (lib.kind) return then();
    pendingOpen = then;
    $('#foldercard').scrollIntoView({ behavior: 'smooth' });
    libState('Open the library folder first (the button above); then it opens by itself.', true);
  }

  // ================================================================ search
  var STOP = {}; 'a an and are as at be by can do does for from how i if in into is it its me my of on or so than that the their them then there these this to was what when where which who why will with you your about after before should could would'.split(' ').forEach(function (w) { STOP[w] = 1; });
  function stem(w) { var s = ['ings', 'ing', 'edly', 'ed', 'es', 's']; for (var i = 0; i < s.length; i++) if (w.length > s[i].length + 3 && w.slice(-s[i].length) === s[i]) return w.slice(0, -s[i].length); return w; }
  function terms(q) {
    var seen = {}, out = [];
    q.toLowerCase().replace(/[^\p{L}\p{N}\s'-]/gu, ' ').split(/\s+/).forEach(function (w) { w = w.replace(/^['-]+|['-]+$/g, ''); if (w.length > 1 && !STOP[w]) { w = stem(w); if (!seen[w]) { seen[w] = 1; out.push(w); } } });
    return out.slice(0, 8);
  }
  function reFor(t) { return new RegExp('\\b' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); }
  function mark(s, ts) {
    var h = esc(s);
    ts.forEach(function (t) { h = h.replace(new RegExp('\\b(' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[\\p{L}]*)', 'giu'), '<mark>$1</mark>'); });
    return h;
  }
  function kindOf(p) { return /\.epub$/i.test(p) ? 'ebook' : /\.pdf$/i.test(p) ? 'pdf' : 'page'; }
  function where(p) { var parts = p.split('/'); parts.pop(); return parts.join(' / ') || 'top folder'; }

  function titleSearch(q) {
    var ts = terms(q), res = ts.map(reFor), out = [];
    if (!ts.length) return [];
    DOCS.forEach(function (d) {
      var h = 0, sc = 0;
      res.forEach(function (r) { if (r.test(d.t)) { h++; sc += 3; } else if (r.test(d.d) || r.test(d.p)) { h++; sc += 1; } });
      if (h === ts.length || (ts.length > 2 && h >= ts.length - 1)) out.push({ doc: d, score: (sc + h * 4) * (d.w || 1) });
    });
    out.sort(function (a, b) { return b.score - a.score; });
    return out.slice(0, 30).map(function (r) { return { doc: r.doc, snip: r.doc.d, page: 0, anchor: '' }; });
  }

  // the full-text search runs in its own thread, made from this function's source (a page opened from a
  // drive can't load a separate worker file, but it can make one from text)
  function searchWorker() {
    var docs = [], D = [], P = [], A = [], T = [];
    var STOP = {}; 'a an and are as at be by can do does for from how i if in into is it its me my of on or so than that the their them then there these this to was what when where which who why will with you your about after before should could would'.split(' ').forEach(function (w) { STOP[w] = 1; });
    function stem(w) { var s = ['ings', 'ing', 'edly', 'ed', 'es', 's']; for (var i = 0; i < s.length; i++) if (w.length > s[i].length + 3 && w.slice(-s[i].length) === s[i]) return w.slice(0, -s[i].length); return w; }
    function terms(q) { var seen = {}, out = []; q.toLowerCase().replace(/[^\p{L}\p{N}\s'-]/gu, ' ').split(/\s+/).forEach(function (w) { w = w.replace(/^['-]+|['-]+$/g, ''); if (w.length > 1 && !STOP[w]) { w = stem(w); if (!seen[w]) { seen[w] = 1; out.push(w); } } }); return out.slice(0, 8); }
    self.onmessage = async function (e) {
      var m = e.data;
      if (m.type === 'load') {
        try {
          docs = JSON.parse(await m.docs.text());
          var total = m.chunks.size, read = 0, last = 0, buf = '';
          var counter = new TransformStream({ transform: function (c, ctl) { read += c.byteLength; ctl.enqueue(c); } });
          var rd = m.chunks.stream().pipeThrough(counter).pipeThrough(new DecompressionStream('gzip')).pipeThrough(new TextDecoderStream()).getReader();
          for (;;) {
            var r = await rd.read();
            if (r.done) break;
            var lines = (buf + r.value).split('\n'); buf = lines.pop();
            for (var i = 0; i < lines.length; i++) { if (!lines[i]) continue; var c = JSON.parse(lines[i]); D.push(c.d); P.push(c.p || 0); A.push(c.a || ''); T.push(c.t); }
            if (Date.now() - last > 250) { last = Date.now(); postMessage({ type: 'progress', read: read, total: total }); }
          }
          postMessage({ type: 'ready', n: T.length, docs: docs.length });
        } catch (err) { postMessage({ type: 'error', msg: String(err && err.message || err) }); }
      }
      if (m.type === 'search') {
        var ts = terms(m.q);
        if (!ts.length) { postMessage({ type: 'results', id: m.id, results: [], terms: [] }); return; }
        var res = ts.map(function (t) { return new RegExp('\\b' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); });
        var need = ts.length > 2 ? ts.length - 1 : ts.length, hits = [];
        for (var k = 0; k < T.length; k++) {
          var h = 0;
          for (var j = 0; j < res.length; j++) if (res[j].test(T[k])) h++;
          if (h >= need) hits.push(k);
        }
        if (hits.length < 5 && ts.length > 1) { // nothing has them all: take passages with most of them
          hits = [];
          for (k = 0; k < T.length; k++) { h = 0; for (j = 0; j < res.length; j++) if (res[j].test(T[k])) h++; if (h >= Math.ceil(ts.length / 2)) hits.push(k); }
        }
        var scored = hits.map(function (k) {
          var t = T[k], sc = 0, d = docs[D[k]] || {}, title = (d.title || '').toLowerCase();
          ts.forEach(function (w) { var n = t.toLowerCase().split(w).length - 1; if (n) sc += 10 + Math.min(n, 4) * 2; if (title.indexOf(w) >= 0) sc += 6; });
          sc *= (d.w || 1);
          if (/\.html$/i.test(d.path || '') && (d.w || 1) >= 1) sc *= 1.4; // our guides first
          return { k: k, sc: sc };
        }).sort(function (a, b) { return b.sc - a.sc; });
        var perDoc = {}, out = [];
        for (var i = 0; i < scored.length && out.length < 40; i++) {
          var kk = scored[i].k, dd = D[kk];
          perDoc[dd] = (perDoc[dd] || 0) + 1;
          if (perDoc[dd] > 2) continue;
          var tx = T[kk], at = -1;
          for (j = 0; j < res.length && at < 0; j++) { var mm = res[j].exec(tx); if (mm) at = mm.index; }
          var from = Math.max(0, at - 90), snip = (from ? '… ' : '') + tx.slice(from, from + 260) + (from + 260 < tx.length ? ' …' : '');
          out.push({ d: dd, p: P[kk], a: A[kk], snip: snip });
        }
        postMessage({ type: 'results', id: m.id, results: out, terms: ts, docs: out.map(function (r) { return docs[r.d]; }) });
      }
    };
  }
  var worker = null, fullReady = false, searchId = 0;
  async function loadIndex() {
    if (worker) return;
    var base = 'AI-Offline/Library-Assistant/index/';
    var docs, chunks;
    try { docs = await getFile(base + 'docs.json'); chunks = await getFile(base + 'chunks.jsonl.gz'); }
    catch (e) { $('#qnote').textContent = 'Searching inside the books needs the Library Assistant\'s search index, which isn\'t in this folder. Titles can still be searched.'; return; }
    worker = new Worker(URL.createObjectURL(new Blob(['(' + searchWorker.toString() + ')()'], { type: 'text/javascript' })));
    $('#loadbar').hidden = false;
    $('#qnote').textContent = 'Getting ready to search inside the books (a few seconds)… Titles can be searched now.';
    worker.onmessage = function (e) {
      var m = e.data;
      if (m.type === 'progress') $('#loadbar i').style.width = Math.round(m.read / m.total * 100) + '%';
      if (m.type === 'ready') { fullReady = true; $('#loadbar').hidden = true; $('#qnote').textContent = 'Searching inside ' + m.docs.toLocaleString() + ' guides, books and routes (' + m.n.toLocaleString() + ' passages).'; if ($('#q').value.trim()) search(); }
      if (m.type === 'error') { $('#loadbar').hidden = true; $('#qnote').textContent = 'Could not load the search index (' + m.msg + '). Titles can still be searched.'; }
      if (m.type === 'results' && m.id === searchId) showResults(m.results.map(function (r, i) { var d = m.docs[i] || {}; return { doc: { t: d.title, p: d.path, d: d.desc }, snip: r.snip, page: r.p, anchor: r.a }; }), m.terms);
    };
    worker.postMessage({ type: 'load', docs: docs, chunks: chunks });
  }
  function search() {
    var q = $('#q').value.trim();
    store.set('q', q);
    if (!q) { $('#results').innerHTML = ''; return; }
    if (fullReady) { worker.postMessage({ type: 'search', q: q, id: ++searchId }); $('#results').innerHTML = '<p class="muted">Searching…</p>'; return; }
    showResults(titleSearch(q), terms(q), true);
  }
  function showResults(list, ts, titlesOnly) {
    var el = $('#results');
    if (!list.length) { el.innerHTML = '<p class="muted">Nothing found. Try fewer or different words.</p>'; return; }
    el.innerHTML = (titlesOnly ? '<p class="small muted">Matching titles' + (lib.kind ? '' : ' (open the library folder to search inside the books)') + ':</p>' : '') +
      list.map(function (r, i) {
        var d = r.doc, k = kindOf(d.p), icon = k === 'ebook' ? '📖' : k === 'pdf' ? '📄' : '📘';
        var link = k === 'ebook' ? '#' : href(d.p, k === 'pdf' && r.page ? '#page=' + r.page : r.anchor ? '#' + r.anchor : '');
        var pg = k === 'pdf' && r.page ? ' · page ' + r.page : '';
        return '<div class="res"><a href="' + esc(link) + '" data-i="' + i + '"' + (k === 'ebook' ? '' : ' target="_blank" rel="noopener"') + '>' + icon + ' ' + esc(d.t) + '</a>' +
          '<div class="w">' + esc(where(d.p)) + pg + '</div>' + (r.snip ? '<div class="s">' + mark(r.snip, ts) + '</div>' : '') + '</div>';
      }).join('');
    el.querySelectorAll('a[data-i]').forEach(function (a) {
      var d = list[+a.dataset.i].doc;
      if (kindOf(d.p) === 'ebook') a.onclick = function (e) { e.preventDefault(); needFolder(function () { openBook(d.p, d.t); }); };
    });
  }

  // ================================================================ zip files (for e-books)
  async function openZip(file) {
    var size = file.size, tail = Math.min(size, 66000);
    var buf = new DataView(await file.slice(size - tail).arrayBuffer());
    var eocd = -1;
    for (var i = tail - 22; i >= 0; i--) if (buf.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    if (eocd < 0) throw new Error('not a zip file');
    var n = buf.getUint16(eocd + 10, true), cdSize = buf.getUint32(eocd + 12, true), cdOff = buf.getUint32(eocd + 16, true);
    var cd = new DataView(await file.slice(cdOff, cdOff + cdSize).arrayBuffer()), entries = {}, p = 0, dec = new TextDecoder();
    for (var k = 0; k < n && p < cd.byteLength; k++) {
      var nameLen = cd.getUint16(p + 28, true), extra = cd.getUint16(p + 30, true), comment = cd.getUint16(p + 32, true);
      var name = dec.decode(new Uint8Array(cd.buffer, p + 46, nameLen));
      entries[name] = { method: cd.getUint16(p + 10, true), csize: cd.getUint32(p + 20, true), off: cd.getUint32(p + 42, true) };
      p += 46 + nameLen + extra + comment;
    }
    return {
      entries: entries,
      bytes: async function (name) {
        var e = entries[name] || entries[decodeURIComponent(name)];
        if (!e) throw new Error('missing in the book: ' + name);
        var lh = new DataView(await file.slice(e.off, e.off + 30).arrayBuffer());
        var start = e.off + 30 + lh.getUint16(26, true) + lh.getUint16(28, true);
        var data = file.slice(start, start + e.csize);
        if (e.method === 0) return new Uint8Array(await data.arrayBuffer());
        return new Uint8Array(await new Response(data.stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
      },
      text: async function (name) { return new TextDecoder().decode(await this.bytes(name)); }
    };
  }
  function resolve(base, rel) { // a path inside a book or archive, relative to base
    try { return decodeURIComponent(new URL(rel, 'http://x/' + base.split('/').map(encodeURIComponent).join('/')).pathname.slice(1)); } catch (e) { return rel; }
  }
  var MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp', css: 'text/css' };
  function mimeOf(p) { return MIME[(p.split('.').pop() || '').toLowerCase()] || 'application/octet-stream'; }

  // ================================================================ the reader (e-books and encyclopedias)
  var R = { kind: '', book: null, zim: null, hist: [], urls: [], size: store.get('size', 1) };
  var frame = $('#rframe');
  function readerOpen(title) {
    $('#reader').hidden = false; $('#rtitle').textContent = title; document.body.style.overflow = 'hidden';
    $('#rlist').hidden = true;
  }
  function readerClose() {
    $('#reader').hidden = true; document.body.style.overflow = '';
    R.urls.forEach(function (u) { URL.revokeObjectURL(u); }); R.urls = []; R.hist = []; frame.srcdoc = '';
  }
  function blobURL(bytes, type) { var u = URL.createObjectURL(new Blob([bytes], { type: type })); R.urls.push(u); return u; }
  var READ_CSS = 'body{max-width:44em;margin:0 auto;padding:16px 18px 60px;font:SIZEpx/1.6 Georgia,"Times New Roman",serif;color:#1b1b1b;background:#fffdf8}img,svg{max-width:100%;height:auto}a{color:#0b6b62}';
  function show(html, opts) {
    frame.srcdoc = html;
    frame.onload = function () {
      var doc = frame.contentDocument; if (!doc) return;
      var st = doc.createElement('style'); st.id = 'so-size';
      st.textContent = (opts && opts.css ? READ_CSS : '') .replace('SIZE', Math.round(17 * R.size)) + 'html{font-size:' + Math.round(R.size * 100) + '%}';
      doc.head.appendChild(st);
      doc.addEventListener('click', function (e) {
        var a = e.target.closest && e.target.closest('a'); if (!a) return;
        var to = a.getAttribute('data-go');
        if (to) { e.preventDefault(); go(to); return; }
        var h = a.getAttribute('href') || '';
        if (h[0] === '#') { e.preventDefault(); var t = doc.getElementById(h.slice(1)) || doc.getElementsByName(h.slice(1))[0]; if (t) t.scrollIntoView(); return; }
        if (/^https?:/i.test(h)) { e.preventDefault(); } // no internet links from here
      });
      if (opts && opts.after) opts.after(doc);
    };
  }
  function go(to) { if (R.kind === 'book') bookChapter(+to); else zimShow(to, true); }
  function setSize(f) {
    R.size = Math.max(0.7, Math.min(2.2, R.size * f)); store.set('size', R.size);
    var d = frame.contentDocument, st = d && d.getElementById('so-size');
    if (st) st.textContent = (R.kind === 'book' ? READ_CSS.replace('SIZE', Math.round(17 * R.size)) : '') + 'html{font-size:' + Math.round(R.size * 100) + '%}';
  }

  // ---------------------------------------------------------------- e-books
  async function openBook(path, title) {
    readerOpen(title || path.split('/').pop());
    frame.srcdoc = '<p style="font:16px system-ui;padding:20px">Opening the book…</p>';
    try {
      var z = await openZip(await getFile(path));
      var opfPath = (await z.text('META-INF/container.xml')).match(/full-path="([^"]+)"/)[1];
      var opf = new DOMParser().parseFromString(await z.text(opfPath), 'application/xml');
      var man = {};
      opf.querySelectorAll('manifest > item').forEach(function (it) { man[it.getAttribute('id')] = { href: resolve(opfPath, it.getAttribute('href')), type: it.getAttribute('media-type'), props: it.getAttribute('properties') || '' }; });
      var spine = Array.prototype.map.call(opf.querySelectorAll('spine > itemref'), function (r) { return man[r.getAttribute('idref')]; }).filter(function (x) { return x && /html/.test(x.type); });
      var toc = [];
      var nav = Object.keys(man).map(function (k) { return man[k]; }).filter(function (x) { return /\bnav\b/.test(x.props); })[0];
      if (nav) {
        var nd = new DOMParser().parseFromString(await z.text(nav.href), 'application/xhtml+xml');
        nd.querySelectorAll('nav a[href]').forEach(function (a) { toc.push({ t: a.textContent.trim(), h: resolve(nav.href, a.getAttribute('href')).split('#')[0] }); });
      } else {
        var ncxId = opf.querySelector('spine') && opf.querySelector('spine').getAttribute('toc');
        if (ncxId && man[ncxId]) {
          var nx = new DOMParser().parseFromString(await z.text(man[ncxId].href), 'application/xml');
          nx.querySelectorAll('navPoint').forEach(function (np) { var l = np.querySelector('navLabel text'), c = np.querySelector('content'); if (l && c) toc.push({ t: l.textContent.trim(), h: resolve(man[ncxId].href, c.getAttribute('src')).split('#')[0] }); });
        }
      }
      R.kind = 'book'; R.book = { z: z, spine: spine, toc: toc, path: path, title: title };
      var at = store.get('book:' + path, 0);
      bookChapter(at < spine.length ? at : 0);
    } catch (e) { frame.srcdoc = '<p style="font:16px system-ui;padding:20px">Could not open this book: ' + esc(e.message) + '</p>'; }
  }
  async function bookChapter(i) {
    var b = R.book; if (!b || i < 0 || i >= b.spine.length) return;
    b.at = i; store.set('book:' + b.path, i);
    $('#rtitle').textContent = (b.title || '') + ' · part ' + (i + 1) + ' of ' + b.spine.length;
    var item = b.spine[i], src = await b.z.text(item.href);
    var doc = new DOMParser().parseFromString(src, /xhtml/.test(item.type) ? 'application/xhtml+xml' : 'text/html');
    if (doc.querySelector('parsererror')) doc = new DOMParser().parseFromString(src, 'text/html');
    var jobs = [];
    doc.querySelectorAll('img[src], image').forEach(function (im) {
      var attr = im.hasAttribute('src') ? 'src' : (im.hasAttribute('href') ? 'href' : 'xlink:href');
      var v = im.getAttribute(attr) || im.getAttributeNS('http://www.w3.org/1999/xlink', 'href'); if (!v) return;
      var p = resolve(item.href, v);
      jobs.push(b.z.bytes(p).then(function (by) { var u = blobURL(by, mimeOf(p)); if (attr === 'xlink:href') im.setAttributeNS('http://www.w3.org/1999/xlink', 'href', u); else im.setAttribute(attr, u); }).catch(function () {}));
    });
    doc.querySelectorAll('link[rel~=stylesheet][href]').forEach(function (l) {
      var p = resolve(item.href, l.getAttribute('href'));
      jobs.push(b.z.text(p).then(function (css) { var s = doc.createElement('style'); s.textContent = css.replace(/@import[^;]+;/g, ''); l.replaceWith(s); }).catch(function () { l.remove(); }));
    });
    doc.querySelectorAll('script').forEach(function (s) { s.remove(); });
    doc.querySelectorAll('a[href]').forEach(function (a) {
      var h = a.getAttribute('href'); if (/^[a-z]+:/i.test(h) || h[0] === '#') return;
      var p = resolve(item.href, h).split('#')[0], k = b.spine.findIndex(function (s) { return s.href === p; });
      if (k >= 0) a.setAttribute('data-go', String(k));
    });
    await Promise.all(jobs);
    var html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
      (doc.head ? doc.head.innerHTML : '') + '</head><body>' + (doc.body ? doc.body.innerHTML : '') +
      '<p style="text-align:center;margin:40px 0 0;font-family:system-ui">' + (i + 1 < b.spine.length ? '<a href="#" data-go="' + (i + 1) + '">Next part ›</a>' : '— The end —') + '</p></body></html>';
    show(html, { css: true, after: function (d) { d.defaultView.scrollTo(0, 0); } });
  }

  // ---------------------------------------------------------------- encyclopedias (Kiwix .zim)
  function Zim(file) { this.f = file; this.clusters = new Map(); }
  Zim.prototype.read = async function (pos, len) { return new DataView(await this.f.slice(pos, pos + len).arrayBuffer()); };
  Zim.prototype.u64 = function (dv, o) { return dv.getUint32(o, true) + dv.getUint32(o + 4, true) * 4294967296; };
  Zim.prototype.open = async function () {
    var h = await this.read(0, 80);
    if (h.getUint32(0, true) !== 0x044D495A) throw new Error('not a ZIM archive');
    this.minor = h.getUint16(6, true); this.count = h.getUint32(24, true); this.nclusters = h.getUint32(28, true);
    this.urlPtr = this.u64(h, 32); this.titlePtr = this.u64(h, 40); this.clusterPtr = this.u64(h, 48); this.mimePos = this.u64(h, 56);
    this.mainPage = h.getUint32(64, true); this.checksumPos = this.u64(h, 72);
    var mb = new Uint8Array((await this.read(this.mimePos, 4096)).buffer), list = [], s = 0;
    for (var i = 0; i < mb.length; i++) if (mb[i] === 0) { if (i === s) break; list.push(new TextDecoder().decode(mb.subarray(s, i))); s = i + 1; }
    this.mimes = list;
    this.ns = this.minor >= 1 ? 'C' : 'A';
    var self = this;
    if (this.titlePtr < this.f.size) { // older archives: a list of every entry by title
      this.titles = { count: this.count, front: false, get: async function (i) { return (await self.read(self.titlePtr + i * 4, 4)).getUint32(0, true); } };
    } else { // newer ones: a listing entry (v1 = articles only)
      var le = await this.byPath('X', 'listing/titleOrdered/v1') || await this.byPath('X', 'listing/titleOrdered/v0');
      this.titles = le ? await this.listing(await this.follow(le), !!(await this.byPath('X', 'listing/titleOrdered/v1'))) : { count: 0, get: async function () { return 0; } };
    }
    return this;
  };
  Zim.prototype.listing = async function (e, front) { // a list of entry numbers, read 4 bytes at a time when it isn't compressed
    var self = this, a = this.u64(await this.read(this.clusterPtr + e.cluster * 8, 8), 0), info = (await this.read(a, 1)).getUint8(0);
    if ((info & 15) <= 1) {
      var w = (info & 16) ? 8 : 4, at = function (dv) { return w === 8 ? self.u64(dv, 0) : dv.getUint32(0, true); };
      var start = at(await this.read(a + 1 + e.blob * w, w)), end = at(await this.read(a + 1 + (e.blob + 1) * w, w));
      return { count: (end - start) / 4, front: front, get: async function (i) { return (await self.read(a + 1 + start + i * 4, 4)).getUint32(0, true); } };
    }
    var b = await this.bytes(e), dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    return { count: b.byteLength / 4, front: front, get: async function (i) { return dv.getUint32(i * 4, true); } };
  };
  Zim.prototype.entry = async function (idx) {
    var off = this.u64(await this.read(this.urlPtr + idx * 8, 8), 0), dv = await this.read(off, 1024), u8 = new Uint8Array(dv.buffer);
    var mime = dv.getUint16(0, true), ns = String.fromCharCode(u8[3]), e = { idx: idx, mime: mime, ns: ns }, p;
    if (mime === 0xffff) { e.redirect = dv.getUint32(8, true); p = 12; } else { e.cluster = dv.getUint32(8, true); e.blob = dv.getUint32(12, true); p = 16; }
    var z1 = u8.indexOf(0, p); if (z1 < 0) { dv = await this.read(off, 8192); u8 = new Uint8Array(dv.buffer); z1 = u8.indexOf(0, p); }
    var z2 = u8.indexOf(0, z1 + 1), dec = new TextDecoder();
    e.url = dec.decode(u8.subarray(p, z1)); e.title = dec.decode(u8.subarray(z1 + 1, z2)) || e.url;
    e.type = this.mimes[mime] || '';
    return e;
  };
  Zim.prototype.titleAt = async function (i) { return this.entry(await this.titles.get(i)); };
  function cmp(a, b) { return a < b ? -1 : a > b ? 1 : 0; }
  Zim.prototype.byPath = async function (ns, url) { // binary search on the url list
    var lo = 0, hi = this.count - 1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1, e = await this.entry(mid), c = cmp(e.ns + '/' + e.url, ns + '/' + url);
      if (c === 0) return e;
      if (c < 0) lo = mid + 1; else hi = mid - 1;
    }
    return null;
  };
  Zim.prototype.follow = async function (e) { for (var n = 0; e && e.redirect !== undefined && n < 6; n++) e = await this.entry(e.redirect); return e; };
  Zim.prototype.cluster = async function (n) {
    if (this.clusters.has(n)) return this.clusters.get(n);
    var a = this.u64(await this.read(this.clusterPtr + n * 8, 8), 0);
    var b = n + 1 < this.nclusters ? this.u64(await this.read(this.clusterPtr + (n + 1) * 8, 8), 0) : this.checksumPos;
    var raw = new Uint8Array(await this.f.slice(a, b).arrayBuffer()), info = raw[0], comp = info & 15, data;
    if (comp === 5) data = window.fzstd.decompress(raw.subarray(1));
    else if (comp <= 1) data = raw.subarray(1);
    else throw new Error('this archive uses an older kind of compression; open it with Kiwix instead');
    var c = { data: data, ext: (info & 16) ? 8 : 4 };
    this.clusters.set(n, c);
    if (this.clusters.size > 6) this.clusters.delete(this.clusters.keys().next().value);
    return c;
  };
  Zim.prototype.bytes = async function (e) {
    var c = await this.cluster(e.cluster), dv = new DataView(c.data.buffer, c.data.byteOffset, c.data.byteLength);
    var off = function (i) { return c.ext === 8 ? dv.getUint32(i * 8, true) + dv.getUint32(i * 8 + 4, true) * 4294967296 : dv.getUint32(i * 4, true); };
    return c.data.subarray(off(e.blob), off(e.blob + 1));
  };
  Zim.prototype.find = async function (prefix, max) { // titles starting with prefix (a few spellings)
    var self = this, seen = {}, out = [], ns = this.ns;
    var tries = [prefix, prefix.charAt(0).toUpperCase() + prefix.slice(1), prefix.replace(/\b\w/g, function (c) { return c.toUpperCase(); }), prefix.toLowerCase(), prefix.toUpperCase()];
    for (var t = 0; t < tries.length && out.length < max; t++) {
      var p = tries[t]; if (seen['q' + p]) continue; seen['q' + p] = 1;
      var n = this.titles.count, lo = 0, hi = n;
      while (lo < hi) { var mid = (lo + hi) >> 1, e = await self.titleAt(mid); if (cmp(e.ns + '/' + e.title, ns + '/' + p) < 0) lo = mid + 1; else hi = mid; }
      for (var i = lo; i < n && out.length < max; i++) {
        var e2 = await self.titleAt(i);
        if (e2.ns !== ns || e2.title.indexOf(p) !== 0) break;
        if (!seen[e2.title] && (e2.mime === 0xffff || /html/.test(e2.type))) { seen[e2.title] = 1; out.push(e2); }
      }
    }
    return out;
  };
  Zim.prototype.meta = async function (name) {
    var e = await this.byPath('M', name); if (!e) return '';
    return new TextDecoder().decode(await this.bytes(await this.follow(e)));
  };

  var zims = [];
  async function listZims() {
    var el = $('#zimlist');
    $('#zimnote').textContent = 'Looking for encyclopedias on the drive…';
    try {
      var paths = await findFiles(/\.zim$/i, /^(OsmAnd|AI-Offline|engine|models|obf|Kiwix-Reader)$/);
      zims = [];
      for (var i = 0; i < paths.length; i++) {
        try {
          var z = await new Zim(await getFile(paths[i])).open(), title = await z.meta('Title'), desc = await z.meta('Description');
          zims.push({ path: paths[i], z: z, title: title || paths[i].split('/').pop(), desc: desc, size: z.f.size });
        } catch (e) { zims.push({ path: paths[i], err: e.message, title: paths[i].split('/').pop() }); }
      }
      if (!zims.length) { $('#zimnote').textContent = 'No encyclopedias (.zim files) in this library folder.'; el.innerHTML = ''; return; }
      $('#zimnote').textContent = 'Tap one to read it. Find articles by their title with the box at the top of the reader.';
      el.innerHTML = '<div class="books">' + zims.map(function (z, i) {
        var sz = z.size >= 1e9 ? (z.size / 1e9).toFixed(1) + ' GB' : Math.max(1, Math.round(z.size / 1e6)) + ' MB';
        return '<a href="#" data-z="' + i + '"><b>' + esc(z.title) + '</b> <small>' + (z.err ? esc(z.err) : esc(z.desc || '') + ' · ' + sz +
          (/_maxi_/.test(z.path) ? ' · with pictures' : /_nopic_/.test(z.path) ? ' · no pictures' : /_mini_/.test(z.path) ? ' · short version' : '') +
          ' · ' + esc(z.path.split('/').slice(0, -1).join(' / '))) + '</small></a>';
      }).join('') + '</div>';
      el.querySelectorAll('a[data-z]').forEach(function (a) { a.onclick = function (e) { e.preventDefault(); var z = zims[+a.dataset.z]; if (!z.err) openZim(z); }; });
    } catch (e) { $('#zimnote').textContent = 'Could not look through the folder: ' + e.message; }
  }
  async function openZim(z) {
    readerOpen(z.title);
    R.kind = 'zim'; R.zim = z.z; R.hist = [];
    $('#rfind').hidden = false; $('#rtoc').hidden = true; $('#rprev').hidden = $('#rnext').hidden = true;
    try {
      var main = null;
      if (z.z.mainPage !== 0xffffffff) main = await z.z.follow(await z.z.entry(z.z.mainPage));
      if (!main) main = await z.z.follow(await z.z.byPath('W', 'mainPage'));
      if (main) zimShow(main.ns + '/' + main.url, false); else frame.srcdoc = '<p style="font:16px system-ui;padding:20px">Use the box at the top to find an article.</p>';
    } catch (e) { frame.srcdoc = '<p style="font:16px system-ui;padding:20px">Could not open: ' + esc(e.message) + '</p>'; }
  }
  async function zimShow(full, push) {
    var z = R.zim, slash = full.indexOf('/'), ns = full.slice(0, slash), url = full.slice(slash + 1);
    frame.srcdoc = '<p style="font:16px system-ui;padding:20px">Opening…</p>';
    try {
      var e = await z.follow(await z.byPath(ns, url));
      if (!e && ns !== z.ns) e = await z.follow(await z.byPath(z.ns, url));
      if (!e) { frame.srcdoc = '<p style="font:16px system-ui;padding:20px">That page isn\'t in this archive.</p>'; return; }
      full = e.ns + '/' + e.url;
      if (push && R.cur) R.hist.push(R.cur);
      R.cur = full;
      if (!/html/.test(e.type)) { // a picture or file: show it by itself
        var u = blobURL(await z.bytes(e), e.type);
        show('<!doctype html><body style="margin:0;background:#fff"><img src="' + u + '" style="max-width:100%"></body>');
        return;
      }
      var html = new TextDecoder().decode(await z.bytes(e));
      var doc = new DOMParser().parseFromString(html, 'text/html'), jobs = [];
      $('#rtitle').textContent = (doc.title || e.title).trim();
      doc.querySelectorAll('script, base, iframe, object, embed').forEach(function (s) { s.remove(); });
      doc.querySelectorAll('link[rel~=stylesheet][href]').forEach(function (l) {
        var p = resolve(full, l.getAttribute('href'));
        jobs.push(zimStyle(p).then(function (css) { var s = doc.createElement('style'); s.textContent = css; l.replaceWith(s); }).catch(function () { l.remove(); }));
      });
      doc.querySelectorAll('img').forEach(function (im) {
        var v = im.getAttribute('data-src') || im.getAttribute('src'); im.removeAttribute('srcset'); im.removeAttribute('loading');
        if (v && !/^(data|https?):/i.test(v)) { im.setAttribute('data-zim', resolve(full, v)); im.removeAttribute('src'); }
      });
      doc.querySelectorAll('a[href]').forEach(function (a) {
        var h = a.getAttribute('href'); if (/^[a-z]+:/i.test(h) || h[0] === '#') return;
        a.setAttribute('data-go', resolve(full, h).split('#')[0]);
      });
      await Promise.all(jobs);
      show('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' + doc.head.innerHTML +
        '<style>body{background:#fff;color:#202122;padding:0 12px}img{max-width:100%;height:auto}</style></head><body>' + doc.body.innerHTML + '</body></html>',
        { after: function (d) { d.defaultView.scrollTo(0, 0); fillPictures(d); } });
    } catch (err) { frame.srcdoc = '<p style="font:16px system-ui;padding:20px">Could not open this page: ' + esc(err.message) + '</p>'; }
  }
  async function zimStyle(p) { // a stylesheet with its own pictures and fonts made local
    var z = R.zim, zimCss = z.css || (z.css = new Map());
    if (zimCss.has(p)) return zimCss.get(p);
    var slash = p.indexOf('/'), e = await z.follow(await z.byPath(p.slice(0, slash), p.slice(slash + 1)));
    if (!e) throw new Error('no stylesheet');
    var css = new TextDecoder().decode(await z.bytes(e)), refs = [], m, re = /url\(\s*['"]?([^'")]+)['"]?\s*\)/g;
    while ((m = re.exec(css))) if (!/^(data|https?):/i.test(m[1])) refs.push(m[1]);
    for (var i = 0; i < refs.length && i < 40; i++) {
      try {
        var rp = resolve(p, refs[i]), sl = rp.indexOf('/'), re2 = await z.follow(await z.byPath(rp.slice(0, sl), rp.slice(sl + 1)));
        if (re2) css = css.split(refs[i]).join(URL.createObjectURL(new Blob([await z.bytes(re2)], { type: re2.type })));
      } catch (e2) {}
    }
    zimCss.set(p, css);
    return css;
  }
  async function fillPictures(d) {
    var imgs = Array.prototype.slice.call(d.querySelectorAll('img[data-zim]')), z = R.zim, cur = R.cur;
    for (var i = 0; i < imgs.length; i++) {
      if (R.cur !== cur) return; // moved on to another page
      try {
        var p = imgs[i].getAttribute('data-zim'), sl = p.indexOf('/'), e = await z.follow(await z.byPath(p.slice(0, sl), p.slice(sl + 1)));
        if (e) imgs[i].src = blobURL(await z.bytes(e), e.type);
      } catch (err) {}
    }
  }
  var findTimer = 0;
  $('#rfind').addEventListener('input', function () {
    clearTimeout(findTimer);
    var q = this.value.trim();
    findTimer = setTimeout(async function () {
      var box = $('#rlist');
      if (!q) { box.hidden = true; return; }
      var list = await R.zim.find(q, 25);
      box.hidden = false;
      box.innerHTML = list.length ? list.map(function (e) { return '<a href="#" data-p="' + esc(e.ns + '/' + e.url) + '">' + esc(e.title) + '</a>'; }).join('') : '<a>No titles start with that.</a>';
      box.querySelectorAll('a[data-p]').forEach(function (a) { a.onclick = function (ev) { ev.preventDefault(); box.hidden = true; zimShow(a.dataset.p, true); }; });
    }, 250);
  });

  // ================================================================ e-book shelves
  function shelves() {
    var books = DOCS.filter(function (d) { return /\.epub$/i.test(d.p); }), groups = {};
    books.forEach(function (b) { var parts = b.p.split('/'); var g = parts[parts.length - 2] || 'Books'; (groups[g] = groups[g] || []).push(b); });
    var order = ['Picture-Books-and-Rhymes', 'Ages-6-to-9', 'Ages-9-to-13', 'Teens-and-Adults'];
    var names = Object.keys(groups).sort(function (a, b) { var x = order.indexOf(a), y = order.indexOf(b); return (x < 0 ? 99 : x) - (y < 0 ? 99 : y) || cmp(a, b); });
    $('#shelves').innerHTML = names.map(function (g) {
      return '<details class="shelf"><summary>' + esc(g.replace(/-/g, ' ')) + ' (' + groups[g].length + ')</summary><div class="books">' +
        groups[g].sort(function (a, b) { return cmp(a.t, b.t); }).map(function (b) { return '<a href="#" data-b="' + b.i + '">' + esc(b.t) + ' <small>' + esc(b.d) + '</small></a>'; }).join('') + '</div></details>';
    }).join('') || '<p class="muted">No e-books in this library.</p>';
    $('#shelves').querySelectorAll('a[data-b]').forEach(function (a) { a.onclick = function (e) { e.preventDefault(); var d = DOCS[+a.dataset.b]; needFolder(function () { openBook(d.p, d.t); }); }; });
  }

  // ================================================================ wiring
  document.querySelectorAll('.tabs button').forEach(function (b) {
    b.onclick = function () {
      document.querySelectorAll('.tabs button').forEach(function (x) { x.setAttribute('aria-selected', x === b); $('#tab-' + x.dataset.tab).hidden = x !== b; });
      store.set('tab', b.dataset.tab);
    };
  });
  var tb = document.querySelector('.tabs button[data-tab="' + store.get('tab', 'guides') + '"]'); if (tb) tb.click();
  $('#pick').onclick = pickFolder;
  $('#again').onclick = openAgain;
  $('#dirpick').onchange = function () { if (this.files && this.files.length) useFiles(this.files); };
  var qt = 0; $('#q').addEventListener('input', function () { clearTimeout(qt); qt = setTimeout(search, 300); });
  $('#rclose').onclick = readerClose;
  $('#rback').onclick = function () { if (R.kind === 'zim' && R.hist.length) { R.cur = null; zimShow(R.hist.pop(), false); } else if (R.kind === 'book' && R.book) bookChapter(R.book.at - 1); };
  $('#rprev').onclick = function () { if (R.book) bookChapter(R.book.at - 1); };
  $('#rnext').onclick = function () { if (R.book) bookChapter(R.book.at + 1); };
  $('#rsmall').onclick = function () { setSize(1 / 1.12); };
  $('#rbig').onclick = function () { setSize(1.12); };
  $('#rtoc').onclick = function () {
    var box = $('#rlist'), b = R.book; if (!b) return;
    if (!box.hidden) { box.hidden = true; return; }
    var items = b.toc.length ? b.toc : b.spine.map(function (s, i) { return { t: 'Part ' + (i + 1), h: s.href }; });
    box.innerHTML = items.map(function (t) { var k = b.spine.findIndex(function (s) { return s.href === t.h; }); return k < 0 ? '' : '<a href="#" data-k="' + k + '">' + esc(t.t) + '</a>'; }).join('');
    box.hidden = false;
    box.querySelectorAll('a[data-k]').forEach(function (a) { a.onclick = function (e) { e.preventDefault(); box.hidden = true; bookChapter(+a.dataset.k); }; });
  };
  var origOpen = readerOpen;
  readerOpen = function (t) { origOpen(t); var z = R.kind === 'zim'; $('#rfind').hidden = true; $('#rtoc').hidden = false; $('#rprev').hidden = $('#rnext').hidden = false; $('#rfind').value = ''; return z; };
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('#reader').hidden) readerClose(); });
  shelves();
  idb('get').then(function (h) { if (h && window.showDirectoryPicker) $('#again').hidden = false; });
  var lastQ = store.get('q', ''); if (lastQ) { $('#q').value = lastQ; search(); }
  window.soBrowser = { lib: lib, Zim: Zim, openBook: openBook, openZim: openZim, zims: function () { return zims; } };
})();
