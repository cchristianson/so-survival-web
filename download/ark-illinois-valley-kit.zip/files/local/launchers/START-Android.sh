#!/data/data/com.termux/files/usr/bin/bash
# START-Android.sh - run the offline library on an Android phone or tablet, inside the free Termux app.
#
# FIRST TIME (see START-ON-ANY-DEVICE.html for pictures):
#   1. Install Termux from Phone-Apps/Android-Termux on this drive.
#   2. Copy this file into the tablet's Download folder.
#   3. Open Termux and type:   termux-setup-storage      (tap Allow)
#   4. Then type:              bash /sdcard/Download/START-Android.sh
# AFTER THAT: open Termux and type   library
#
# What it does: finds the library on the SD card or the tablet, installs the AI and Wikipedia helpers
# (from the drive - no internet needed - or from the internet if the drive doesn't have them), copies
# the Library Assistant into Termux (Android won't run programs straight from an SD card), and makes
# the "library" command. Nothing is sent anywhere.
set -u
say(){ printf '\n%s\n' "$*"; }

case "${PREFIX:-}" in
  *com.termux*) ;;
  *) echo "Please run this inside the Termux app (see START-ON-ANY-DEVICE.html)."; exit 1;;
esac

if ! ls /storage/emulated/0 >/dev/null 2>&1; then
  say "Termux needs permission to read your files. Tap ALLOW on the next screen,"
  say "then run this again:   bash /sdcard/Download/START-Android.sh"
  termux-setup-storage
  exit 0
fi

# ---- 1. find the library (the folder that has AI-Offline/Library-Assistant in it)
LIB=""
here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
[ -n "$here" ] && [ -d "$here/AI-Offline/Library-Assistant" ] && LIB="$here"
if [ -z "$LIB" ]; then
  say "Looking for the library on this device (this can take a minute)..."
  for base in /storage/*-* /storage/emulated/0; do
    [ -d "$base" ] || continue
    f="$(find "$base" -maxdepth 4 -type d -path '*/AI-Offline/Library-Assistant' 2>/dev/null | head -n1)"
    if [ -n "$f" ]; then LIB="${f%/AI-Offline/Library-Assistant}"; break; fi
  done
fi
if [ -z "$LIB" ]; then
  say "Couldn't find the library. Copy the whole library folder onto the SD card (or the tablet),"
  say "then run this again."
  exit 1
fi
LA="$LIB/AI-Offline/Library-Assistant"
say "Library found: $LIB"

# ---- 2. the AI (llama-server) and the Wikipedia search (kiwix-serve)
if ! command -v llama-server >/dev/null 2>&1 || ! command -v kiwix-serve >/dev/null 2>&1; then
  PK="$LIB/Phone-Apps/Android-Termux/packages"
  if ls "$PK"/*.deb >/dev/null 2>&1; then
    say "Installing the AI and Wikipedia helpers from the drive (no internet needed)..."
    tmp="$HOME/.library/packages"; rm -rf "$tmp"; mkdir -p "$tmp"
    for d in "$PK"/*.deb; do
      p="$(dpkg-deb -f "$d" Package 2>/dev/null)" || continue
      dpkg -s "$p" >/dev/null 2>&1 || cp "$d" "$tmp/"
    done
    if ls "$tmp"/*.deb >/dev/null 2>&1; then dpkg -i "$tmp"/*.deb >/dev/null 2>&1; fi
    rm -rf "$tmp"
  fi
  if ! command -v llama-server >/dev/null 2>&1 || ! command -v kiwix-serve >/dev/null 2>&1; then
    say "Trying to get them from the internet instead..."
    pkg install -y llama-cpp kiwix-tools >/dev/null 2>&1 || true
  fi
  command -v llama-server >/dev/null 2>&1 || say "NOTE: the AI helper isn't installed. Search and reading still work."
  command -v kiwix-serve  >/dev/null 2>&1 || say "NOTE: the Wikipedia search helper isn't installed. The books and guides are still searched."
fi

# ---- 3. the Library Assistant, and the 'library' command for next time
if [ ! -f "$LA/library-assistant-linux-arm64" ]; then
  say "The Library Assistant program is missing from $LA - copy the whole library again."
  exit 1
fi
mkdir -p "$HOME/.library"
cat > "$PREFIX/bin/library" <<EOF
#!/data/data/com.termux/files/usr/bin/bash
# Start the offline library. Keep Termux open while you use it; to stop, close Termux.
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
cp "$LA/library-assistant-linux-arm64" "\$HOME/.library/library-assistant" && chmod +x "\$HOME/.library/library-assistant" || exit 1
echo "Starting the library - your browser will open. Keep Termux open while you use it."
exec "\$HOME/.library/library-assistant" -root "$LIB" -index "$LA/index" "\$@"
EOF
chmod +x "$PREFIX/bin/library"
say "All set. From now on, just open Termux and type:   library"
exec "$PREFIX/bin/library"
