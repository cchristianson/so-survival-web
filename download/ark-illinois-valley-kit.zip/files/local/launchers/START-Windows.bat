@echo off
rem Double-click to start the offline library on a Windows computer.
call "%~dp0AI-Offline\Library-Assistant\START-LIBRARY-ASSISTANT.bat"
