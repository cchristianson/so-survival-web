#!/bin/bash
# Start the offline library on Linux - including Raspberry Pi (64-bit) and Chromebooks with Linux on.
# In the file manager: right-click this file > "Run as a Program" (or "Run in Terminal").
# Or open a terminal in this folder and type:   bash START-Linux.sh
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"; LA="$HERE/AI-Offline/Library-Assistant"
case "$(uname -m)" in
  x86_64|amd64) EXE="$LA/library-assistant-linux-x64";;
  aarch64|arm64) EXE="$LA/library-assistant-linux-arm64";;
  *) echo "This kind of computer ($(uname -m)) can't run the assistant. Open START-HERE.html in a web"
     echo "browser instead - all the guides and books work without it."; read -r _; exit 1;;
esac
[ -f "$EXE" ] || { echo "The Library Assistant isn't on this drive yet. Open START-HERE.html in a browser instead."; read -r _; exit 1; }
chmod +x "$EXE" 2>/dev/null
# some drives don't allow programs to run from them: if so, run a copy from the home folder
if ! "$EXE" -h >/dev/null 2>&1; then
  mkdir -p "$HOME/.local/share/so-survival-library" && cp "$EXE" "$HOME/.local/share/so-survival-library/library-assistant" \
    && chmod +x "$HOME/.local/share/so-survival-library/library-assistant" && EXE="$HOME/.local/share/so-survival-library/library-assistant"
fi
echo "================================================================"
echo "  LIBRARY ASSISTANT - keep this window open while you use it."
echo "  Your web browser will open; if it doesn't, open the address"
echo "  shown below. Press Ctrl+C here when you are done."
echo "================================================================"
"$EXE" -root "$HERE" -index "$LA/index" "$@"
