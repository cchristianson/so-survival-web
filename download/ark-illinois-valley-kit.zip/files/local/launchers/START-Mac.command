#!/bin/bash
# Double-click to start the offline library on a Mac.
# If the Mac says it "can't be opened": right-click this file, choose Open, then click Open again.
cd "$(dirname "$0")" || exit 1
LA="AI-Offline/Library-Assistant"
case "$(uname -m)" in arm64) EXE="$LA/library-assistant-mac-arm64";; *) EXE="$LA/library-assistant-mac-x64";; esac
if [ ! -f "$EXE" ]; then
  echo "The Library Assistant isn't on this drive yet. Open START-HERE.html in Safari instead -"
  echo "all the guides and books work without it."; read -r -p "Press Enter to close..." _; exit 1
fi
# programs copied from the internet are 'quarantined' by macOS; clear that for the library's programs only
xattr -dr com.apple.quarantine "$LA" "AI-Offline/engine" "Kiwix-Reader/tools" 2>/dev/null
chmod +x "$EXE" 2>/dev/null
echo "================================================================"
echo "  LIBRARY ASSISTANT - keep this window open while you use it."
echo "  Your web browser will open in a moment. Close this window"
echo "  when you are done."
echo "================================================================"
"$EXE" "$@"
echo; read -r -p "The assistant stopped. Press Enter to close..." _
