@echo off
title Library Assistant
cd /d "%~dp0"
echo ================================================================
echo   LIBRARY ASSISTANT - one search for the whole library
echo ================================================================
echo.
echo   Your web browser will open in a moment. Keep THIS window open
echo   while you use the library, and close it when you are done.
echo.
echo   The size of the AI is picked for this computer automatically.
echo   To change it, open the Settings tab in the browser.
echo   (If Windows SmartScreen warns, click "More info", then "Run anyway".)
echo.
set "EXE=library-assistant.exe"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "EXE=library-assistant-arm64.exe"
if /i "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "EXE=library-assistant-arm64.exe"
"%~dp0%EXE%" %*
echo.
echo The assistant stopped. If it closed right away, see the logs folder.
pause
