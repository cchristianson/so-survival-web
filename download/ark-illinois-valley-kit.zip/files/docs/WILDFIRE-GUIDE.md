# 🔥 Wildfire: Defending Your Place With No Grid

How a household in the Illinois Valley can get its people, house, animals and land through a wildfire when no engine,
air tanker, alert or phone is coming: reading the danger, hardening and clearing with hand tools, water without the grid,
hand line, deciding ahead whether to stay or go, the fire's arrival, and the years after. The basics (5-ft and 30-ft rules,
vent mesh, evacuation levels, a cleaner-air room) are in the [Illinois Valley guide](guide:ILLINOIS-VALLEY-START-HERE)
("Wildfire"), [Home Defense](guide:HOME-DEFENSE-GUIDE) ("Fire as a threat to your home") and the
[Shelter guide](guide:SHELTER-BUILDING-GUIDE) ("Earthquake and wildfire hardening"). Most books are in
`Southern-Oregon\Wildfire`: the federal firefighters' *Incident Response Pocket Guide* (IRPG), fire-behavior guide (PMS 437)
and tactics guide (PMS 465); the Australian Country Fire Authority's (CFA) plan for staying to defend a house, adapted here
because it assumes phone apps and daily ratings; Cohen's Forest Service research on how homes ignite; the State Fire Marshal
(OSFM); and OSU Extension. FEMA P-737 is in `Southern-Oregon\Shelter-Building\Wildfire-Quake-Hardening`, *Fire Weather*
(AH 360) in `Southern-Oregon\Navigation-Weather\Weather`, and the thinning and slash bulletins in `Southern-Oregon\Firewood\Woodlot`.

> ### The short version
> - **Leaving early beats staying late.** Deaths "can occur because people wait too long to leave"
>   ([Ready, Set, Go!, p. 2](lib:ready-set-go-wildland#page=2)); leaving early "does not mean waiting to see or smell
>   smoke" ([CFA, p. 11](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=11)). Decide **before fire season**, not on the day.
> - **Embers burn most houses:** up to **90%** of ignitions ([OSFM, p. 5](lib:osfm-defensible-space-homeowner-guide#page=5)),
>   from fires **1 km (0.6 mile) or more** away ([Cohen, p. 4](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=4)). Flames must be close: big flame fronts
>   don't light wood walls beyond **40 m (130 ft)** ([p. 2](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=2)). Keep **5 ft** bare, **30 ft** lean, **100 ft** thinned.
> - **Never stay to defend without** at least **two fit adults**, about **2,600 gallons** of water, **pumps that work with
>   the power out** and protective clothing ([CFA, p. 3](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=3)). Children, elders and the sick leave early.
> - **An east wind can blow 24–48 hours, strongest at night and early morning,** with humidity "extremely low around the
>   clock" ([PMS 465, p. 227](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=227)). Don't count on the fire "lying down" at night.
> - **Hand tools only stop flames under 4 ft** ([IRPG, p. 66](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=66)). Never fight the head of a fire; work
>   from the burned side, with **two ways out**.
> - **As the front passes, shelter inside:** "You will be unable to survive out in the open" ([CFA, p. 9](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=9)).
>   Then **patrol for embers**: "Many structures do not burn until after the fire front has passed" ([IRPG, p. 31](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=31)).
> - **After the fire,** burned trees fall, stump holes burn feet, and **½ inch of rain an hour** on a burned slope can start
>   a debris flow ([USGS, p. 1](lib:usgs-postfire-debris-flow-hazards-tips-fs-2022-3078#page=1)).
> - **No open burning June–October, until real rain** *(rule of thumb)*. Burn piles only on wet, calm days.

---

## 🌡️ Reading fire danger with no forecast

With no Red Flag Warnings, add wind, fuel dryness and smoke to the daily log in the
[Navigation & Weather guide](guide:NAVIGATION-WEATHER-GUIDE) *(rule of thumb)*. The region's fire season "usually runs from
June through September" ([AH 360, p. 211](lib:fire-weather-agriculture-handbook-360#page=211)), but "September bears the
greatest impact of easterly winds" ([PMS 465, p. 227](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=227)); the 2020 fires burned in September.

| Watch | Danger rises when |
|---|---|
| **Humidity** | Lowest about the hottest hour, rising slowly overnight ([AH 360, p. 50](lib:fire-weather-agriculture-handbook-360#page=50)). At **15–30%**: "Very high ignition, rapid buildup, extensive spotting and crowning"; under **15%**: "critical fire conditions" ([IRPG, p. 65](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=65)). |
| **How dry it feels** | "snap of sticks, crackle of litter, pop vs crumble of leaves, dust in duff"; cured grass, snags, slash, crowns closer than 20 ft ([IRPG, p. 52](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=52)). |
| **Wind** | Over **10 mph** ([IRPG, p. 50](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=50)). No gauge: 8–12 mph, small twigs in constant motion; 13–18, dust raised on the road; 19–24, "Branchlets are broken from trees" ([p. 59](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=59); [Beaufort scale](wiki:Beaufort_scale)). |
| **Unstable air** | Gusty wind, dust devils, very clear air, smoke rising straight up; steady wind and low haze mean stable air ([AH 360, p. 71](lib:fire-weather-agriculture-handbook-360#page=71); [IRPG, p. 50](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=50)). |
| **Time of day** | The "critical burn period" is **2 to 5 p.m.** ([IRPG, p. 19](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=19)). At night slope winds turn downhill at **2–5 mph** ([PMS 437, p. 37](lib:nwcg-fire-behavior-field-reference-guide-pms-437#page=37)), but fires in the mid-slope thermal belt stay active (Navigation & Weather guide; [IRPG, p. 51](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=51)). |
| **Slope and aspect** | Fire runs uphill and up-canyon; saddles "are one of the most hazardous locations for homes" ([FEMA P-737, pp. 17–18](lib:fema-p-737#page=17)). Southwest slopes have the driest afternoon fuels ([AH 360, p. 199](lib:fire-weather-agriculture-handbook-360#page=199)). Over **20%** slope (20 ft rise in 100 ft) or 10 mph wind, safety zones may need "more than double" ([IRPG, p. 21](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=21)); the saying that fire doubles its speed for every 10° of slope has no book behind it *(rule of thumb)*. |

![Two drawings: wind pouring through a low saddle between two hills, and wind rushing up a narrow canyon and out its sides](img:WILDFIRE-GUIDE/wind-saddle-and-canyon.png)
*Wind, and fire with it, funnels through saddles and up canyons, the worst places for a house ([FEMA P-737, p. 18](lib:fema-p-737#page=18)).*

### East wind: the night is not safe

"East wind in fire control means an exceptionally dry wind from an easterly quadrant that may blow continuously for 24 to
48 hours or longer. East wind often reaches maximum strength during night and early morning hours. Surface wind of 60 mph
is not uncommon", with humidity "extremely low around the clock" ([PMS 465, p. 227](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=227); [Foehn wind](wiki:Foehn_wind)).
When fire turns wind-driven, "This change can occur quickly" ([p. 262](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=262)). The 2020 numbers and warning
signs are in Navigation & Weather ("Illinois Valley weather through the year"). **On an east-wind day** *(rule of thumb)*: a
lookout awake **all night**; the car fueled, packed and facing out; tanks full; protective clothes laid out; no saw, mower,
grinder or fire of any kind; a leaving time agreed with the neighbors.

### Smoke columns, spotting and flame length

- **The column:** smoke trapped under an inversion means calmer fire; when it "begins to boil through the inversion ...
  Expect lowering RH, possible wind shifts, and increasing flames, spread, and spotting" ([IRPG, p. 54](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=54)).
  "sudden calm, smoke at your feet" mean a wind change; torching trees and more spot fires mean a blow-up ([p. 53](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=53)).
- **Spotting** (embers starting fires ahead) is usually 100 ft to ¼ mile, sometimes miles; the Cerro Grande Fire spotted 10
  miles ahead ([PMS 437, p. 153](lib:nwcg-fire-behavior-field-reference-guide-pms-437#page=153)). A home "within one mile of a natural area" is in the ember zone
  ([Ready, Set, Go!, p. 3](lib:ready-set-go-wildland#page=3)): every home here.
- **Where people die:** "On relatively small fires or deceptively quiet areas of large fires", in light fuels "such as grass",
  in a wind shift, when fire runs uphill, from 2 to 5 p.m.; "Blowup to burnover ... can be as little as 5 minutes" ([IRPG, p. 19](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=19)).

| Flame length | Fire | What hand tools can do ([IRPG, p. 66](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=66)) |
|---|---|---|
| Under 1 ft | Smoldering | "Handline holds" |
| 1–4 ft | Creeping, 2–5 chains an hour | Attack the head or flanks; a hand line "should hold" |
| 4–8 ft | Running, 6–20 chains an hour | "Too intense for direct attack with handtools" |
| 8–11 ft | Torching and spotting | Work at the head is "ineffective" |
| Over 11 ft | Crown fire to extreme | Over 25 ft: "Escape to safety should be considered" |

A chain is **66 ft**. The county expects flames under **8 ft** on the Rogue and Illinois valley floors and over **11 ft** in
the southern mountains ([County plan, p. 71](lib:josephine-county-multi-jurisdictional#page=71)), so a household with hand
tools works the flanks and the slow back edge, never the head *(rule of thumb)*.

📚 **Go deeper:** [IRPG, pp. 50–54](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=50) — "Look Up, Down, and Around": weather, terrain, fuel and smoke signs; [AH 360, pp. 121–125](lib:fire-weather-agriculture-handbook-360#page=121) — slope and valley winds through the day.

## 🏠 How houses catch fire

Three ways: **embers** land on something that burns; a **surface fire** creeps to the walls or roof; or **radiant heat** from
burning plants or buildings nearby. "Most commonly, homes are lost in wildfires when they come into contact with embers or
low-intensity surface fires — not from a giant wall of flames" ([OSU EM 9247, p. 2](lib:osu-em-9247-home-ignition-zone#page=2)).
- **Embers** cause up to 90% of house fires ([OSFM, p. 5](lib:osfm-defensible-space-homeowner-guide#page=5)), get in "through
  vents, windows, and other openings" ([Ready, Set, Go!, p. 3](lib:ready-set-go-wildland#page=3)), and pile up where snow
  drifts on the roof and deck ([p. 5](lib:ready-set-go-wildland#page=5)).
- **Flames have to be close.** By Cohen's calculations even crown fires won't light wood walls more than **40 m (130 ft)**
  away ([Cohen, p. 2](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=2)): there a wall needs over 10 minutes of heat, but crown-fire flames last about **1
  minute** in one spot ([p. 3](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=3)). Test walls **10 m (33 ft)** from crown fires didn't ignite, and homes with
  nonflammable roofs and **10–18 m (33–60 ft)** of clearance survived **95%** of the time ([pp. 3–4](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=3)).
- **The house can be the fuel:** homes with flammable roofs "ignite and burn without the surrounding vegetation also
  burning" ([Cohen, p. 4](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=4)). The roof "is the most vulnerable component" ([EM 9247, p. 3](lib:osu-em-9247-home-ignition-zone#page=3)).
- **Late burning** comes from "residual spot fires or creeping ground fire" ([IRPG, p. 31](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=31)). Single-pane
  glass can fail within **5 minutes** ([P-737, p. 47](lib:fema-p-737#page=47)); glazing: Home Defense ("Stronger windows and glass doors").

### The zones around the house

| From the house | Goal | What to do |
|---|---|---|
| **0–5 ft** | Nothing that burns | Gravel, rock, pavers or bare soil; no plants, bark or wood chips; nothing against the walls ([OSFM, p. 7](lib:osfm-defensible-space-homeowner-guide#page=7); [PNW 590, p. 7](lib:osu-pnw-590#page=7); [EC 1574, p. 4](lib:disposing-of-woody-material#page=4)) |
| **5–30 ft** | Lean, clean and green | Tree tops 15–20 ft apart; prune 6–10 ft up, keeping half the crown; no woodpile ([EM 9247, pp. 4–5](lib:osu-em-9247-home-ignition-zone#page=4); [OSFM, p. 13](lib:osfm-defensible-space-homeowner-guide#page=13)) |
| **30–100 ft** (200 on steep slopes) | Fire stays on the ground | Grass under 4 in, 10 ft between crowns, no ladder fuels, no snags ([OSFM, pp. 14–16](lib:osfm-defensible-space-homeowner-guide#page=14); [EM 9184, p. 11](lib:osu-em-9184#page=11)) |
| **Beyond 100 ft** | A slower, cooler fire | Thin over the years; a few snags per acre for wildlife ([EM 9184, pp. 11–12](lib:osu-em-9184#page=11)) |

The books number their zones differently, so this table uses feet ([🖼️ the zones](lib:fema-p-737#page=23)). Clearing need
"only occur within a few tens of meters from a home" ([Cohen, p. 4](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=4)): finish the inner zones first *(rule of thumb)*.

![The zones around a house, seen from above: 0–5 ft bare, 5–30 ft lean and clean, 30–100 ft thinned](img:WILDFIRE-GUIDE/zones-around-the-house.svg)
*The zones in the table above, seen from above (a diagram drawn for this guide).*

## 🔨 Hardening the house with what you have

Vents, gutters and woodpiles are in the Shelter guide; windows, fences, gates and the driveway in Home Defense. The order:
1. **Roof first.** Clean it and the gutters spring and fall, and in summer under madrones, which drop leaves then
   ([EM 9184, p. 9](lib:osu-em-9184#page=9)); debris gathers in valleys and where roof meets wall ([P-737, p. 25](lib:fema-p-737#page=25)).
   Untreated wood shakes are unrated and "not desirable" ([BCD, p. 3](lib:oregon-wildfire-home-hardening-guide-bcd#page=3)): keep
   hand-split shakes for sheds, and salvage metal roofing from buildings you won't defend *(rule of thumb)*.
2. **Vents: 1/8-inch metal mesh** over the old 1/4–1/2 in screen, which "may be plastic" ([OSFM, p. 8](lib:osfm-defensible-space-homeowner-guide#page=8)).
   This follows current Oregon advice over FEMA's 2008 "maximum opening of 1/4 inch" ([P-737, p. 40](lib:fema-p-737#page=40)).
   1/16 in clogs, and clogged debris can make embers; keep cardboard away from vents ([BCD, p. 5](lib:oregon-wildfire-home-hardening-guide-bcd#page=5)).
3. **Vent covers.** Ready, Set, Go! says cover attic and ground vents with "pre-cut plywood" ([p. 9](lib:ready-set-go-wildland#page=9));
   FEMA advises against it because people fall ([P-737, p. 42](lib:fema-p-737#page=42)). So cut and label covers now; always
   fit the ground and crawlspace vents; gable vents only from a tied-off ladder with time to spare *(rule of thumb)*.
4. **Gaps and gutters.** Caulk gaps; open eaves trap heat ([BCD, p. 6](lib:oregon-wildfire-home-hardening-guide-bcd#page=6)). Seal
   pipe and wire holes with mortar ([P-737, p. 72](lib:fema-p-737#page=72); lime mortar: [Masonry & Roads](guide:MASONRY-ROADS-GUIDE)).
   Vinyl gutters "can fail under radiant heat" ([EM 9247, p. 3](lib:osu-em-9247-home-ignition-zone#page=3)): use metal.
5. **Windows and walls.** "Metal blinds are best to protect the interior from radiant heat" ([Ready, Set, Go!, p. 6](lib:ready-set-go-wildland#page=6)).
   Rotting siding lets embers catch ([OSFM, p. 9](lib:osfm-defensible-space-homeowner-guide#page=9)); siding down to the ground
   lets fire into the wall ([BCD, p. 4](lib:oregon-wildfire-home-hardening-guide-bcd#page=4)). Nothing stored under an open
   foundation, and no lattice ([P-737, pp. 57–58](lib:fema-p-737#page=57)).
6. **Decks.** Clear on, around and under; 1/8-in metal mesh under deck openings ([OSFM, p. 10](lib:osfm-defensible-space-homeowner-guide#page=10)).
   Furniture and "even welcome mats" catch embers ([EM 9247, p. 4](lib:osu-em-9247-home-ignition-zone#page=4)).
7. **Woodpile and lumber 30 ft away** ([OSFM, p. 13](lib:osfm-defensible-space-homeowner-guide#page=13); ODF's handout says 20,
   every other source 30), level with or uphill of the house: "Embers that settle into your wood pile will slowly build a
   fire" ([Ready, Set, Go!, p. 7](lib:ready-set-go-wildland#page=7)).
8. **Propane and fuel.** Clear 10 ft around a fixed tank, which will "vent when overheated" and isn't "typically at risk of
   exploding"; BBQ cylinders 30 ft away ([OSFM, p. 12](lib:osfm-defensible-space-homeowner-guide#page=12)). Fuel, including the
   fire pump's gas, 30 ft from the house and "away from downhill slopes" ([P-737, p. 73](lib:fema-p-737#page=73)).
9. **Outbuildings 50 ft** from the house ([P-737, p. 23](lib:fema-p-737#page=23)); "Wet hay can start fires through spontaneous
   combustion" ([4-H Horse, p. 61](lib:4-h-horse-project#page=61)). Well power supplies "are vulnerable during a wildfire"
   ([P-737, p. 72](lib:fema-p-737#page=72)): clear around the pump house, panels and tank *(rule of thumb)*.

📚 **Go deeper:** [Oregon Home Hardening Guide, pp. 3–10](lib:oregon-wildfire-home-hardening-guide-bcd#page=3) — roofs, vents, siding, decks and glass; [FEMA P-737, pp. 25–65](lib:fema-p-737#page=25) — each part of the house, with drawings.

## 🪓 Clearing around the house with hand tools

Work from the house outward *(rule of thumb)*. The books differ on trees; this guide uses:
- **Spacing:** at least **10 ft** between crowns within 100 ft ([OSFM, p. 14](lib:osfm-defensible-space-homeowner-guide#page=14)),
  **15–20 ft** within 30 ft of the house and more on slopes ([EM 9247, p. 5](lib:osu-em-9247-home-ignition-zone#page=5));
  branches **15 ft** from the house ([PNW 590, p. 7](lib:osu-pnw-590#page=7)), **10 ft** from a chimney ([OSFM, p. 15](lib:osfm-defensible-space-homeowner-guide#page=15)).
- **Limbing:** **6 ft** up, or a third of the height on trees under 18 ft ([OSFM, p. 14](lib:osfm-defensible-space-homeowner-guide#page=14));
  mature trees **10 ft**, taking no more than a third of the live branches at once; conifers in fall and winter, hardwoods
  in spring ([EM 9184, p. 7](lib:osu-em-9184#page=7)).
- **Keep some:** deciduous trees "block embers" ([OSFM, p. 15](lib:osfm-defensible-space-homeowner-guide#page=15)); mature
  ponderosa pine and bigleaf maple "catch and filter embers" ([EM 9247, p. 5](lib:osu-em-9247-home-ignition-zone#page=5)).

**Brush and ladder fuels.** Small trees and brush under big ones are "ladder" fuels that carry a ground fire into the crowns
([EC 1573, p. 2](lib:reducing-hazardous-fuels-on-woodland-property-thinning#page=2)). Space shrubs 2–3 times their height
apart ([EM 9184, p. 16](lib:osu-em-9184#page=16)), none over one metre (about 3 ft) by a window ([CFA, p. 4](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=4)).
Worst burners: Scotch broom, gorse, blackberry, juniper, many manzanitas and ceanothus ([EM 9184, p. 15](lib:osu-em-9184#page=15)).
- **Oak, madrone and tanoak resprout**, and the sprouts "can quickly become new ladder fuels"; sometimes don't cut ([EM 9184, pp. 15–17](lib:osu-em-9184#page=15)).
  Black oaks cut December–May sprouted 92%, June–November 45% ([PSW-GTR-185, p. 36](lib:seeds-seedlings-and-sprouts#page=36)),
  but summer tool work starts fires: cut in late fall, after the first real rain *(rule of thumb)*.
- **Blackberry:** dig the crowns with a Pulaski or grub hoe ([EM 9184, pp. 20–21](lib:osu-em-9184#page=20)). **Scotch broom:**
  cutting old plants in late summer may kill them, but don't graze it: it is "toxic to livestock in large quantities" (p. 20).

![Side view, two panels. Left: tall grass, brush and branches down to the ground let fire climb into touching tree crowns. Right: trees limbed 6–10 ft up, no brush under them, crowns 10 ft or more apart, grass under 4 in](img:WILDFIRE-GUIDE/ladder-fuels-limbing-and-spacing.svg)
*Take out the brush and low limbs that let fire climb, and space the crowns (a diagram drawn for this guide).*

**Grass** under **4 in** within 100 ft ([OSFM, p. 16](lib:osfm-defensible-space-homeowner-guide#page=16)). Dry grass makes flames
"three times the height of the grass": cut it green, before fire season; in season mow only early in the morning ([EM 9184, p. 9](lib:osu-em-9184#page=9)).

**Slash with no chipper.** Lop and scatter it 12–18 in deep at most; it only moves the fuel, dry slash takes "a decade or
more" to rot, and never "within 100 feet of the home" ([EC 1574, p. 2](lib:disposing-of-woody-material#page=2)). Hand-pile
pieces under 6 in across ([p. 3](lib:disposing-of-woody-material#page=3)) and burn them in winter (see "Burning on purpose").

**Animals mow too.** Cattle keep grass down; goats and sheep browse brush but need fencing, water and predator control
([EM 9184, p. 14](lib:osu-em-9184#page=14)). **Keep it up:** without upkeep the benefit is "lost" in 5 to 10 years
([p. 3](lib:osu-em-9184#page=3)); work the 30–100 ft zone in sections, all of it every **5–8 years** ([p. 5](lib:osu-em-9184#page=5)).
Brush the driveway back 10 ft: "If firefighters can't see down your driveway, they will not enter" ([p. 7](lib:osu-em-9184#page=7)).

### Which work in which season

| Season | Work | Source |
|---|---|---|
| **Winter (wet)** | Thin, prune conifers, trim brush, pile slash; burn piles on wet, calm days | [EM 9184, p. 7](lib:osu-em-9184#page=7); [EC 1574, p. 4](lib:disposing-of-woody-material#page=4) |
| **Spring** | Mesh, gutters, roof, deck; debris out to 100 ft; mow while green; firewood to 30 ft; prune hardwoods | [OSFM, p. 20](lib:osfm-defensible-space-homeowner-guide#page=20); [EM 9184, pp. 7–9](lib:osu-em-9184#page=7) |
| **Summer (fire season)** | Keep roof, gutters, deck and the 5-ft strip clean; saws and mowers at dawn or not at all | [OSFM, p. 21](lib:osfm-defensible-space-homeowner-guide#page=21); [EM 9247, p. 6](lib:osu-em-9247-home-ignition-zone#page=6) |
| **Fall (after real rain)** | Trim within 5 ft, limb up, clear understory, brush back the driveway | [OSFM, p. 21](lib:osfm-defensible-space-homeowner-guide#page=21) |

## 💧 Water with no power

"Loss of power will prevent ... electric pumps from working" ([CFA, p. 8](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=8)), so plan water that needs no grid.
And "Never rely on water for firefighter safety" ([IRPG, p. 31](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=31)): water is not your escape plan.

| What | How much | Source |
|---|---|---|
| To defend a house | **10,000 litres (about 2,640 gal)** or more, with gear that works if the power goes out | [CFA, p. 3](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=3) |
| Reserve you never touch | **100 gal** | [IRPG, p. 31](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=31) |
| Filling 100 ft of hose | ¾-in **2 gal**; 1-in **4 gal** | [IRPG, p. 104](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=104) |
| Forestry nozzle, 3/16-in tip | **7 gal a minute** at 50 psi | [IRPG, p. 104](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=104) |
| A fire hose | **50–125 gal a minute** | [P-737, p. 67](lib:fema-p-737#page=67) |
| Water extinguisher | **2.5 gal**, reaching 30–40 ft | [CERT, p. 170](lib:cert-basic-training#page=170) |

At 7 gal a minute, 2,640 gallons lasts about **6 hours**; a fire hose empties it in **20–50 minutes** *(arithmetic)*. Use small
nozzles, short bursts and dirt, and save water for embers.

**Storing it**
- **Tanks** of "steel, concrete, or ferrocement"; fiberglass "may be placed underground" ([P-737, p. 77](lib:fema-p-737#page=77)).
  Clear 10 ft around a plastic tank and bury its pipe *(rule of thumb)*. A tank up the hill: [Storing Energy](guide:STORING-ENERGY-GUIDE)
  ("Gravity that works"); each **2 ft** of height gives about **1 psi** ([IRPG, p. 104](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=104)).
- **Ponds, pools and creeks.** A "dry hydrant" (fixed suction pipe) needs water at least **2 ft** deep ([P-737, p. 78](lib:fema-p-737#page=78)).
  Oregon needs no water right for "emergency firefighting" ([OWRD, p. 2](lib:exempt-water-uses-in-oregon#page=2)). Keep a
  hard road within 10 ft ([PNW 783, p. 7](lib:wildfires-smoke-and-livestock#page=7)). Inside, fill the bath and buckets ([CFA, p. 7](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=7)).

**Getting it there**
- **A gas fire pump** lifts at most **22 ft at sea level**, minus 1 ft per 1,000 ft of elevation ([IRPG, p. 104](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=104)):
  about **20 ft** on the valley floor *(arithmetic)*. Pumping uphill, fit a check-and-bleeder valve (same page). Keep
  "sufficient fuel which is clean" ([CFA, p. 6](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=6)); run it each spring and time how long a gallon lasts
  *(rule of thumb)*. The well: [Water Wells](guide:WATER-WELLS-GUIDE) ("Running the well pump without the grid").
- **Backpack pumps, buckets, mops.** "A few squirts from a backpack pump can easily cool down hot embers" ([PMS 465, p. 85](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=85));
  most hold about 5 gal *(rule of thumb)*. CFA adds "mops, metal buckets, ladders and rakes" ([p. 5](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=5)).
- **Hoses** to reach every side of the house ([Ready, Set, Go!, p. 7](lib:ready-set-go-wildland#page=7)), but "Long hose lays
  are not recommended"; "Charge garden hoses" (fill them) beforehand ([IRPG, p. 31](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=31)). **Plastic melts:** bring
  plastic fittings and hoses in before the front ([CFA, p. 9](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=9)); use brass *(rule of thumb)*.
- **Sprinklers** on the ridge or under the eaves, fed by a tank ([P-737, pp. 68–69](lib:fema-p-737#page=68)), though "High
  winds ... can significantly degrade" them ([p. 70](lib:fema-p-737#page=70)). Ready, Set, Go!'s "Don't leave sprinklers on"
  ([p. 9](lib:ready-set-go-wildland#page=9)) is about town pressure; with a tank, turn them on "When embers start to appear",
  and "Block downpipes and fill gutters with water" ([CFA, p. 8](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=8)).
- **Dirt is water too.** "Water can be used very sparingly but effectively when hand tools are used to expose burning fuels
  and mix soil with fire" ([PMS 465, p. 85](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=85)). "Let no person use water alone, but always with another person
  with a hand tool" ([p. 52](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=52)); "If a pump should fail, enough hand tools should be available to extinguish
  the fire with mineral soil" ([p. 91](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=91)).

## ⛏️ Hand tools and firebreaks

**[Pulaski](wiki:Pulaski_(tool)):** ax plus grub hoe, "about 5½ pounds"; short, shallow swings, the hoe landing on its corner;
goggles; "Never sharpen the top of the hoe" ([MTDC, p. 25](lib:handtools-for-trail-work#page=25)). **[McLeod](wiki:McLeod_(tool)):** rake plus hoe,
"inefficient in rocky or unusually brushy areas" ([p. 26](lib:handtools-for-trail-work#page=26)). **Fire shovel:** scrapes "down to mineral soil"
([p. 29](lib:handtools-for-trail-work#page=29)). Carry tools "at your side and downhill, with blades forward"; "Never throw a tool" ([p. 11](lib:handtools-for-trail-work#page=11)).
Saws in fire season: Firewood guide ("Bucking and limbing").

![A Pulaski (ax blade on one side, grub hoe on the other), a close-up of its head, and the hoe striking the ground on its corner](img:WILDFIRE-GUIDE/pulaski-hoe-on-its-corner.png)
*Grub with short, shallow strokes and let the hoe land on its corner ([MTDC, p. 25](lib:handtools-for-trail-work#page=25)).*

### Building a hand line

A **hand line** (fireline) is a strip cleared of fuel and scraped to bare mineral soil ([Firebreak](wiki:Firebreak)).
1. **Anchor it** to something that won't burn: road, creek, rock, plowed field or burned ground ([IRPG, p. 23](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=23)).
   Building "without safe anchor point" is one of the 18 Watch Out Situations ([p. 140](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=140)).
2. **Width:** "one and one half times as wide as the dominate fuel is high", 1–3 ft of it scraped to mineral soil, on the side
   away from the fire; in timber, 20–30 ft cleared with a 3–4 ft scrape ([PMS 465, p. 42](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=42)). Brush 6 ft tall
   needs a 9-ft line *(arithmetic)*.
3. **Down to mineral soil,** or fire creeps through roots; unburned material goes outside the line, burning material into the
   burn ([p. 37](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=37)). **Limb the trees** on both sides: heat crosses a narrow line without flames touching ([pp. 40–41](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=40)).
4. **Below a fire on a slope,** dig a "cup trench" to catch rolling logs and cones ([p. 38](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=38)); **above** it, the
   steeper the slope, the wider the line ([p. 17](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=17)).
5. **Short and straight,** tied to roads, rock and creeks; on a ridge, on top or just over ([IRPG, p. 101](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=101)).
   **Never** build line downhill toward a fire, mid-slope above it, or with unburned fuel between you and it ([p. 20](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=20)).

![A fire line: a wide strip cleared of brush and trees, with the outer 1–3 ft scraped to bare soil](img:WILDFIRE-GUIDE/fireline-cleared-and-scraped.png)
*Clear a strip, then scrape the side away from the fire down to bare soil ([PMS 465, p. 42](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=42)).*

![A cup trench dug along the downhill side of a fire line, catching burning logs that roll down](img:WILDFIRE-GUIDE/cup-trench.png)
*A cup trench below a fire on a slope catches burning logs and cones ([PMS 465, p. 38](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=38)).*

The burning edge itself is the "Safest place to work; firefighters can usually escape into the burned area"
([IRPG, p. 99](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=99)). "Most firelines will be unsuccessful in stopping a crown fire" ([PMS 465, p. 42](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=42)).

### How fast can you build line?

| Fuel | 20-person crew, chains an hour ([SDTDC, p. 10](lib:usfs-sdtdc-fireline-production-rates-2011#page=10)) | Per person, feet an hour *(arithmetic)* |
|---|---|---|
| Short grass | 9.5 | about 30 |
| Chaparral, brush, timber litter | 6.8–7 | about 22 |

Those are trained crews, measured over a whole shift. The older PMS 465 gives **1–2 chains (66–132 ft)** per person-hour in
our forests ([p. 228](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=228)); plan on the measured rates. Three adults might build **70 ft an hour** in brush
*(arithmetic)*, while fire there spreads **2–10 chains (130–660 ft) an hour** (same page). You can't out-dig a fire on the day:
build breaks in the wet season, and on the day use tools on spot fires, the 5-ft strip and the burned edge *(rule of thumb)*.

### Small fires, spot fires and wet sacks

- "Don't overestimate your ability" ([ODFW, p. 34](lib:todays-hunter-in-oregon#page=34)). "Do not ever try to fight a fire
  alone"; "Always have two ways to exit"; "If you feel the heat, you are too close" ([CERT, p. 173](lib:cert-basic-training#page=173)).
- **Dirt first:** throw mineral soil, scrape a line around, stir hot embers into dirt ([PMS 465, pp. 52, 91](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=52)).
- **In grass:** let it burn to a barrier, "cold-trail" the dead edge (feel along it, line any live spot), or use a "gunnysack
  or swatter" ([PMS 465, pp. 30, 59](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=59); [Fire flapper](wiki:Fire_flapper)). Soak a burlap sack, work from the
  burned side, press or drag it on the base of the flames instead of flapping, and re-wet it often *(rule of thumb)*.
- "Getting frequent spot fires across line" is a Watch Out: time to go ([IRPG, p. 140](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=140)).

### Burning out: mostly don't

**Burning out** is "setting fire inside the fireline to consume fuel between the fireline and the edge of the fire", so crews
"keep one foot in the black"; **backfiring** sets fire well ahead of the main fire, a riskier method ([PMS 465, pp. 112–113](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=112)).
Firing needs lookouts, escape routes, anchor points and "Adequate resources ... for both firing and holding" ([IRPG, p. 26](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=26)).
**Household rule** *(rule of thumb)*: never backfire. Burn out only a narrow strip of grass or litter off a finished, anchored
line, with the wind carrying it away from the line, someone holding the line with water and tools, and a lookout. If unsure, don't.

## 🚪 Stay or go: decide before fire season

"Do not wait to be advised to leave" ([Ready, Set, Go!, p. 10](lib:ready-set-go-wildland#page=10)). Alerts failed in 2020 (What
to Expect guide); now there are none. **Stay only if every answer is yes** ([CFA, p. 3](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=3)):
- [ ] At least **two fit adults** "physically and mentally prepared to work long and hard"
- [ ] About **2,600 gal** of water, and pumps and hoses that run with the power out, tested this season
- [ ] Protective clothing for each, and the house hardened and cleared to 100 ft
- [ ] A **safety zone** at the house: "Do not commit to stay and protect a structure unless a safety zone ... has been identified" ([IRPG, p. 27](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=27))
- [ ] Not a worst-weather day; children, elders and the sick already gone (CFA, p. 3), and the animals
- [ ] Everyone knows "staying to defend may involve trauma, injury or possibly death" ([CFA, p. 5](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=5))

**Places you can't defend:** "narrow canyon bottoms, mid-slope with fire below, and narrow ridges near chimneys and saddles"
([IRPG, p. 28](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=28)). **Worst-weather days:** "Do not plan to defend on CATASTROPHIC days" ([CFA, p. 3](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=3)).
With no ratings, call it catastrophic when an east wind breaks twigs from trees and humidity is under 15%, or leaves crumble
to dust *(rule of thumb, from [CFA, p. 2](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=2) and [IRPG, pp. 59–65](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=59))*; then leave "The night
before" or "Early in the morning" ([CFA, p. 11](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=11)).

### Triggers: write them down

A **trigger** is something you can see that means "go now". Leaving early "does not mean waiting for a warning or a siren"
([CFA, p. 11](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=11)); firefighters "Set trigger point for safe retreat" ([IRPG, p. 30](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=30)). Examples
*(rule of thumb)*: a worst-weather day; a smoke column building over a named ridge upwind; ash or embers falling; fire crossing
a named road or creek (time your escape against its spread, [IRPG, p. 21](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=21)); any one adult saying "go".

### LCES for a household

Firefighters' **LCES** "must be established and known to ALL firefighters BEFORE it is needed" ([IRPG, p. 21](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=21)):

| | Firefighters' rule (same page) | At home *(rule of thumb)* |
|---|---|---|
| **Lookouts** | "good vantage points"; "Knowledge of trigger points" | Someone on a high point with binoculars, day and night on east-wind days, taking turns |
| **Communications** | "Sound alarm early, not late" | Whistle and bell codes ([Signals guide](guide:SIGNALS-MORSE-GUIDE)); walkie-talkies ([Radio guide](guide:RADIO-GUIDE)) |
| **Escape routes** | "More than one"; "Avoid steep, uphill escape routes"; "Timed considering slowest person"; "Marked for day or night" | Two roads out, driven at night; a printed map ([Ready, Set, Go!, p. 8](lib:ready-set-go-wildland#page=8)); car facing out ([CFA, p. 7](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=7)) |
| **Safety zones** | "Back into clean burn"; rock, water, meadows, roads; bigger if upslope, downwind or near heavy fuel | A plowed or grazed-down field, irrigated pasture, gravel lot or big pond, sized below |

### Safety zones: how big

"Separation distance between the firefighter and the flames should be at least four times the maximum continuous flame
height" ([IRPG, p. 22](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=22)):

| Flame height | Distance to the flames | Area |
|---|---|---|
| 10 ft | 40 ft | 1/10 acre |
| 20 ft | 80 ft | ½ acre |
| 50 ft | 200 ft | 3 acres |
| 100 ft | 400 ft | 12 acres |

That counts radiant heat only, on flat ground with no wind, for a three-person crew, and is "Not intended for structure
protection" (same page). With wind over 10 mph or slope over 20%, it may need "more than double" ([p. 21](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=21)).

![Side view: flames of height H on the left, a person in a bare safety zone on the right, with four lengths of H marked on the ground between them](img:WILDFIRE-GUIDE/safety-zone-four-times-flame-height.svg)
*Measure from the flames to where you stand: at least four times the flame height (a diagram drawn for this guide).*

### Getting out and last resort

- Keep "old shoes and a flashlight handy in case of a sudden evacuation at night" ([Ready, Set, Go!, p. 8](lib:ready-set-go-wildland#page=8)).
  Lock up ([CFA, p. 11](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=11)); open any wood gate joined to the house to break the "wick" ([OSFM, p. 11](lib:osfm-defensible-space-homeowner-guide#page=11)).
  Don't leave "the key in the ignition" ([FEMA 2004, p. 127](lib:are-you-ready-citizen-preparedness-guide-2004#page=127)): keep it
  on a hook by the door *(rule of thumb)*.
- **Caught outside** ([IRPG, p. 46](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=46)): "Escape if you can." In light fuels "you may be able to move through the
  flames into the black"; on a flank, "try to get below the fire"; "Use bodies of water" and "heat barriers such as large
  rocks"; "Structures and vehicles may be an option for temporary refuge". Expect "Extremely heavy ember showers" and a
  "Superheated air blast" before the flames; lie face down, protect your airway, and "WHEN IN DOUBT, WAIT IT OUT"
  ([p. 47](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=47)). You have no [fire shelter](wiki:Fire_shelter): a pond or plowed ground is your last refuge *(rule of thumb)*.

## 🔥 When the fire comes

### Hours before the front

1. **Protective clothing on:** "always first thing to do" ([CFA, p. 8](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=8)). Anyone not defending leaves now.
2. **Fill** the bath, buckets and tanks; roll out hoses; set up and test pumps and backpack sprayers ([CFA, p. 7](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=7)).
3. **Clear the walls:** furniture, doormats and BBQ cylinders away; inside, furniture away from windows (same page); cloth
   curtains down unless the blinds are metal ([Ready, Set, Go!, p. 9](lib:ready-set-go-wildland#page=9)).
4. **Close up:** windows, doors, vent covers; gas off at the tank (same page); fans off so they can't draw embers in
   ([P-737, pp. 42–43](lib:fema-p-737#page=42)); wet wool blankets or cotton towels around the inside of windows and doors
   ([CFA, p. 8](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=8)); a ladder under the attic hatch and a flashlight in the attic ([p. 7](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=7)).
5. **Wet the house:** fill the gutters, "Hose down the side of the house facing the fire", sprinklers on when embers appear;
   "Patrol for embers ... You may need to do this for several hours"; "Drink lots of cool water" ([CFA, p. 8](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=8)).

### As the front passes: shelter inside

"As the fire front approaches it will become extremely hot outside. You will be unable to survive out in the open"
([CFA, p. 9](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=9)). Bring plastic hoses and fittings in, and go inside when "The skin on your ears and hands
will alert you" (same page). Then:
- Stay where you **can see the fire**. "Most bathrooms are unsuitable to shelter in": one door. Every shelter room needs two ways
  out; a window counts. Check the roof space for embers; drink water.
- **If the house catches fire:** shut the door on the burning room, close doors as you move to the far end, then go out to
  burned ground. "Do not return to the house for any reason if it's on fire."

"If it's hot inside the house, it is four to five times hotter outside" ([Ready, Set, Go!, p. 9](lib:ready-set-go-wildland#page=9)).
The flames pass quickly: about a minute in one spot for a crown fire ([Cohen, p. 3](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=3)).

### Right after: ember patrol

"Exercise extreme caution before deciding to go outside", then "Actively patrol your property for embers for hours after the
fire has passed" ([CFA, p. 10](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=10)): roof lines and gutters, garden beds and mulch, outdoor furniture, woodpiles,
doormats, decks, sheds, window ledges and door sills, under the house, inside the roof and under the floorboards (same page),
and the attic ([Ready, Set, Go!, p. 9](lib:ready-set-go-wildland#page=9)). "Water down the outside of the house, including the
roof" ([CFA, p. 10](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=10)); stay clear of "the structural collapse zone" ([IRPG, p. 31](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=31)). Duff,
stumps and log piles smolder for days: patrol day and night for at least **3 days**, then daily for **2 weeks** and after
every dry, windy day *(rule of thumb)*.

## 😷 Smoke, heat and people

**Protective clothing** ([CFA, p. 7](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=7)): a wide-brimmed hat, smoke goggles, a P2 (N95-type) mask, a long-sleeved
collared shirt and long pants of cotton or another natural fibre, "Tough leather garden gloves – not rubber or synthetic",
sturdy boots, wool or cotton socks. Many synthetics "can melt or catch fire" ([AFH 10-644, p. 177](lib:afh-10-644#page=177)).
If your clothes catch fire, "do not run ... Lie down and roll" ([Scout Handbook 1911, p. 284](lib:boy-scouts-handbook-for-boys#page=284)).

**A bandana is not a mask.** "Cloth face coverings, bandanas (damp or dry), handkerchiefs ... should not be relied on"
([EPA Smoke Guide, p. 78](lib:epa-wildfire-smoke-guide#page=78)). CFA lists a cotton scarf as an option ([p. 7](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=7));
this guide follows the EPA: cotton shields skin from embers, not lungs. Use an N95 or P100 marked "NIOSH", two head straps,
no ear loops; a beard breaks the seal; replace it when breathing gets hard; it raises heat-illness risk
([EPA *Protect Your Lungs*, pp. 1–2](lib:epa-protect-your-lungs#page=1)). For ages 2 to 7 an N95 rarely fits
([EPA Smoke Guide, p. 77](lib:epa-wildfire-smoke-guide#page=77)): children leave early.

**Smoke and carbon monoxide** bring "headaches and visual impairment, then impaired decision-making, and possible death";
rotate people out, and don't sleep where "smoke can concentrate at night" ([IRPG, p. 44](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=44)). With no power
for a filter fan, open windows at night to cool off even if some smoke comes in, then close them and the curtains by day
([EPA Smoke Guide, p. 49](lib:epa-wildfire-smoke-guide#page=49)); night inversions can hold smoke here, so look first.

**Heat and burns.** Drink "lots of cool water often even if you don't feel thirsty" ([CFA, p. 9](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=9)). Care:
[Field Care](guide:FIELD-CARE-GUIDE) ("Heat and cold in the Valley"; "Burns"); exhaustion: Home Defense ("Stress, fatigue and judgment").

## 🐐 Animals and livestock

**Leave early, in daylight,** to places agreed ahead ([PNW 783, pp. 7–8](lib:wildfires-smoke-and-livestock#page=7)). "Never leave
pets behind"; keep them "indoors or leashed" ([ODA, p. 2](lib:wildfire-prep-for-pets-and-livestock#page=2)). Horses:
[Horse guide](guide:HORSE-GUIDE) ("Local dangers"); poultry and rabbits: [Chickens](guide:CHICKENS-GUIDE#heat-smoke-and-fire-season) and [Rabbits](guide:RABBITS-GUIDE#predators-smoke-and-fire-season); goats: [Goats](guide:GOATS-GUIDE#brush-fire-breaks-and-fire-season).

**If they must stay** ([PNW 783, p. 8](lib:wildfires-smoke-and-livestock#page=8)): a pasture "light on fuel", such as one "heavily
grazed", or a ploughed paddock ([CFA, p. 4](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=4)); "remove rugs and halters" ([p. 7](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=7)); "Leave gates
open"; feed and water for "seven to 10 days"; irrigation on; electricity and propane off; "disked, plowed or scraped ground"
around the barn; dry bedding wetted or removed.

**A burning barn** ([4-H Horse, p. 61](lib:4-h-horse-project#page=61)): "Never lock stall doors". Blindfold a horse that won't
lead with a wet cloth. "Do not turn a horse loose, because it might run back into the barn." "Do not risk your own life".

**After:** burned animals may hide pain; badly burned ones may need to be put down ([PNW 783, pp. 8–9](lib:wildfires-smoke-and-livestock#page=8)). Burns
"may worsen for up to six (6) weeks"; froth from nose or mouth means fluid in the lungs ([ODA, pp. 1–2](lib:caring-for-livestock-after-wildfire#page=1)).

## 🌲 After the fire

### Hot ground, stump holes and mop-up

- **Stump holes:** roots burn underground under hot ash; "Minor burns are often experienced due to burning stump holes"
  ([PMS 465, p. 262](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=262)). Probe ash with a tool before stepping, and mark holes *(rule of thumb)*.
- **Mop-up** "is normally a slow, tedious job": "break up and scatter burning fuels, then cool them down with water. Dig,
  scrape, and scatter." Water alone "can actually insulate hot spots" ([PMS 465, p. 85](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=85)). "dig out burning
  roots" and stir embers into dirt ([p. 52](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=52)). Crews mop up a set distance, "100 feet, 500 feet"
  ([p. 51](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=51)); do at least 100 ft around buildings *(rule of thumb)*.
- Mix ash and dirt "until all steaming and sizzling stops"; "Never just bury a fire" ([ODFW, p. 34](lib:todays-hunter-in-oregon#page=34)).
  A smoldering log can "break out afresh with a rising wind" ([Scout Handbook 1911, p. 186](lib:boy-scouts-handbook-for-boys#page=186)).

### Burned trees

- **Warning signs:** "Trees burning for any period of time"; "Dead, broken, or burning tops"; "Absence of needles, bark, or
  limbs"; "Leaning or hung-up trees"; "Potential for trees to domino" ([IRPG, p. 36](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=36)). Mark "No Work Zones" ([p. 37](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=37)).
- **Fall zone:** a circle as wide as the tree is tall, up to 1.5 times, and farther downhill on a slope ([FS-1273, p. 36](lib:tree-risk-assessments#page=36)).
  Trees with recent fire damage fail more ([p. 56](lib:tree-risk-assessments#page=56)); near the house, take dead trees down the
  year they die ([p. 84](lib:tree-risk-assessments#page=84)). Felling: [Firewood guide](guide:FIREWOOD-GUIDE) ("Felling trees safely").

![Two drawings of a dead tree's fall zone: on flat ground a circle 1 to 1.5 times the tree's height all around; on a slope the zone stretches farther downhill where the tree can slide or roll](img:WILDFIRE-GUIDE/tree-fall-zone.png)
*Keep out of a dead tree's fall zone, and stay farther away below it on a slope ([FS-1273, p. 36](lib:tree-risk-assessments#page=36)).*

### Ash, ruins and wells

- Ash from burned buildings can hold arsenic, lead, asbestos and caustic chemicals; dust masks don't stop asbestos or carbon
  monoxide. A burned lithium battery that pops, hisses or smokes: move "upwind at least ... (330 feet)" ([EPA Smoke Guide, p. 120](lib:epa-wildfire-smoke-guide#page=120)).
- Ash from CCA-treated decks and fences "may contain lethal amounts of arsenic". Mist, don't dry-sweep; wash garden produce;
  children, pregnant women and elders stay out of cleanup ([p. 121](lib:epa-wildfire-smoke-guide#page=121)).
- Fence any new sinkhole, "as it may be a dug well" ([OWRD, p. 1](lib:owrd-maintaining-your-well-after-wildfire#page=1)). Don't
  use a propane cylinder with "fire damage" ([propane safety, p. 8](lib:home-safe-home-propane#page=8)).
- **Water:** see [Water Purification](guide:WATER-PURIFICATION-GUIDE) ("After a wildfire") and Water Wells ("Keeping well water clean").

### Debris flows and erosion

A **debris flow** is a fast mudflow of soil, rock, trees and ash. On burned land one can start "after only a few minutes of
heavy rainfall—about half an inch an hour or more", "days to years after a fire", travel many miles, and hit places "that
were neither burned nor received any rain" ([USGS, p. 1](lib:usgs-postfire-debris-flow-hazards-tips-fs-2022-3078#page=1); [Debris flow](wiki:Debris_flow)). USGS (same page):
"LEAVE BEFORE A STORM ARRIVES. IF YOU WAIT, YOU ARE TOO LATE"; if you can't, "GET TO HIGH GROUND" (upstairs, the roof, uphill,
a tree); listen for "cracking, breaking, roaring, or a fast-moving freight train". With no forecast, people below a burned
slope go when the first hard rain of the season starts *(rule of thumb)*.

**Slowing erosion by hand.** Severe heat can make the top few inches of soil shed water ("hydrophobic"); treat first where
"streams, roads or buildings are directly downslope" ([OSU EM 9562, p. 2](lib:osu-em-9562-mitigating-soil-erosion-after-a-fire-2025#page=2)).
- **Contour logs** need no fuel: burned trees **6–10 in thick, 10–30 ft long**, laid across the slope "in full contact" with
  the ground so soil settles behind them ([EM 9562, p. 3](lib:osu-em-9562-mitigating-soil-erosion-after-a-fire-2025#page=3)).
- **Straw mulch** at 1–2 tons an acre ([p. 2](lib:osu-em-9562-mitigating-soil-erosion-after-a-fire-2025#page=2)); straw-bale check dams last only "the first few storm events"
  ([p. 3](lib:osu-em-9562-mitigating-soil-erosion-after-a-fire-2025#page=3)). **Don't sow non-native grass:** it does little the first year and can "increase fire hazard as
  they cure" ([p. 2](lib:osu-em-9562-mitigating-soil-erosion-after-a-fire-2025#page=2)).

### Replanting

- Grasses, shrubs and hardwoods return on their own. For conifers, "Most seed falls within one or two tree lengths" of a seed
  tree, and bare mineral soil is a good seedbed for most ([OSU EM 9561, p. 1](lib:osu-em-9561-steps-to-reforestation-success-after-wildfire-2025#page=1)). Thick-barked black and
  Oregon white oaks resist heat; tanoak and canyon live oak "re-sprout after being top-killed" ([KBO oak guide, p. 45](lib:restoring-oak-habitats#page=45)).
- Use seed from "parent trees adapted to local conditions"; plantings fail from poor site preparation, competing plants and
  animal damage ([EM 9561, p. 3](lib:osu-em-9561-steps-to-reforestation-success-after-wildfire-2025#page=3)). With no nursery, gather cones and seedlings from surviving local trees
  *(rule of thumb)*. Near the house, plant fire-resistant kinds ([PNW 590, p. 7](lib:osu-pnw-590#page=7); [OSU privacy plants](lib:osu-fire-resistant-shrubs-and-trees-for-privacy)).

## 🤝 Neighbors: lookouts, signals and shared breaks

"In rural areas, your neighbor can be at your home faster than any emergency response" ([EM 9247, p. 2](lib:osu-em-9247-home-ignition-zone#page=2));
now they are the only response. "Your Home Ignition Zone overlaps onto adjacent properties" ([p. 5](lib:osu-em-9247-home-ignition-zone#page=5)),
and "your trees may pose a greater risk to your neighbor's home than to your own" ([Ready, Set, Go!, p. 4](lib:ready-set-go-wildland#page=4)).
- **Lookouts** on worst-weather days, in turns, day and night, who know the triggers and sound the alarm "early, not late"
  ([IRPG, p. 21](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=21); the rota *(rule of thumb)*).
- **Signals:** agree an alarm ahead (Signals guide: "Whistles, bells and alarm codes", "The neighborhood OK/HELP plan"; Radio
  guide). Give a fire's "exact location" ([ODFW, p. 34](lib:todays-hunter-in-oregon#page=34)). No signal fires in fire season.
- **A meeting place** such as a mailbox cluster, crossroads or central barn ([MYN Rural, p. 1](lib:map-your-neighborhood-in-rural-settings#page=1)),
  and a road map of water, gates, fuel breaks, hazards and livestock ([PNW 783, p. 7](lib:wildfires-smoke-and-livestock#page=7)).
- **A road crew** clears brush along the shared road out and keeps shared water signed and clear ([P-737, p. 77](lib:fema-p-737#page=77)).
  Mow or slash a **3 m (10 ft)** break around each property ([CFA, p. 4](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=4)), joined along the lines; small owners
  can pool work ([EC 1575, p. 3](lib:osu-ec-1575#page=3)).
- **A new smoke** is the best chance to stop a fire and also where firefighters die ([IRPG, p. 19](lib:nwcg-incident-response-pocket-guide-irpg-pms-461-2025#page=19)): go with
  tools and water, LCES first *(rule of thumb)*. Organizing: [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) ("Forming a
  neighborhood group"; "Keeping watch").

## 🍂 Burning on purpose: wet season only

The books put the fire season at June through September ([AH 360, p. 211](lib:fire-weather-agriculture-handbook-360#page=211)),
but east winds peak in September and fall can stay dry. This library's rule: **no open burning June–October, until real rain**
*(rule of thumb)*. Oregon allowed burning only outside fire season, on burn days, with fines "up to $12,000 per day"
([DEQ, p. 1](lib:oregon-deq-southern-oregon-outdoor-burning#page=1)), a permit from ODF and the fire district ([EC 1574, p. 4](lib:disposing-of-woody-material#page=4)),
and liability "if the fire escapes" ([p. 3](lib:disposing-of-woody-material#page=3)). What not to burn, and the burn barrel:
[Sanitation](guide:SANITATION-GUIDE) ("Burning trash and brush, and ash").

**Slash piles** ([EC 1574, pp. 3–4](lib:disposing-of-woody-material#page=3)):
1. In the open, **10 ft** from trees, snags and brush, **100 ft** from streams, away from buildings, propane and power lines.
2. Twigs under ½ in at the bottom, limbs parallel, at least **4 ft wide and 4 ft high**; cover it when about 80% built so it
   will light in the rain.
3. Burn "during daylight, and when it's wet or rainy with little or no wind", with "a shovel and water nearby".
4. **Check it after:** piles "may smolder for days or even weeks, roaring back to life in windy, warm weather, even during dry
   winter conditions" (p. 3). Stir and drown the last of it; look again after the next dry, windy day *(rule of thumb)*.

"Many wildfires start from escaped burn piles", and broadcast burning around homes is "very risky" ([EM 9184, p. 14](lib:osu-em-9184#page=14)).
Never burn poison oak ([p. 25](lib:osu-em-9184#page=25)).

**Fire in the oak woods.** The region's low-elevation oak woodlands are "fire adapted", kept by "Relatively frequent low- to
mixed-severity fire"; prescribed burns there go "prior to leaf out in the spring or after leaf fall in the autumn" ([KBO oak guide, p. 45](lib:restoring-oak-habitats#page=45)).
Cultural burning, the way the valley's first peoples tended the land with fire, is covered in "Tending the land with fire"
in [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE) ([Cultural burning](wiki:Cultural_burning)).

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Vent mesh "no larger than 6 millimeters or 1/4 inch" ([FEMA 2004, p. 126](lib:are-you-ready-citizen-preparedness-guide-2004#page=126)); "maximum opening of 1/4 inch" ([P-737, p. 40](lib:fema-p-737#page=40)) | **1/8-in** metal mesh, current Oregon advice ([OSFM, p. 8](lib:osfm-defensible-space-homeowner-guide#page=8); [BCD, p. 5](lib:oregon-wildfire-home-hardening-guide-bcd#page=5)) |
| "Create defensible space by thinning trees and brush within 30 feet" ([FEMA 2004, p. 126](lib:are-you-ready-citizen-preparedness-guide-2004#page=126)) | Out to **100 ft**, 200 ft on steep slopes ([EM 9247, p. 2](lib:osu-em-9247-home-ignition-zone#page=2)) |
| Lawn sprinklers on the roof and "Wet the roof" ahead of time; "Leave the key in the ignition" ([FEMA 2004, p. 127](lib:are-you-ready-citizen-preparedness-guide-2004#page=127)) | Save tank water for embers ([CFA, p. 8](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=8)); keys on a hook by the door *(rule of thumb)* |
| Fire "hand grenades" of "sugar of lead" (lead acetate), soda-acid extinguishers with sulfuric acid; "use milk" on burning kerosene ([*Household Discoveries*, p. 81](lib:household-discoveries#page=81)) | Poison and acid: don't make them. Smother a fuel fire with a lid, dirt or an ABC extinguisher, never water *(rule of thumb)* |
| Fireproof coatings of "Asbestos, powdered" ([Henley's, p. 345](lib:henleys-twentieth-century#page=345)) | Never asbestos; use metal, masonry, earth plaster and 1/8-in mesh |
| A wet "handkerchief ... held over the nostrils" against smoke ([*Household Discoveries*, p. 82](lib:household-discoveries#page=82)) | Wet cloth doesn't protect lungs ([EPA, p. 78](lib:epa-wildfire-smoke-guide#page=78)); crawl low and get out; N95 for wildfire smoke |
| Clear "a circle at least 1 meter in diameter" for a fire ([FM 21-76, p. 80](lib:fm-21-76#page=80)); clear under a signal "tree torch" ([AFH 10-644, p. 513](lib:afh-10-644#page=513)) | No outdoor fires June–October *(rule of thumb)*; otherwise 10 ft cleared, water and a shovel ([EC 1574, p. 4](lib:disposing-of-woody-material#page=4)) |

## 🖼️ Pictures & diagrams

- Fire running upslope; wind over a saddle and up a canyon — [🖼️ FEMA P-737, p. 17](lib:fema-p-737#page=17), [🖼️ p. 18](lib:fema-p-737#page=18); slope and valley winds — [🖼️ AH 360, p. 121](lib:fire-weather-agriculture-handbook-360#page=121), [🖼️ p. 124](lib:fire-weather-agriculture-handbook-360#page=124); the east-wind weather map — [🖼️ p. 212](lib:fire-weather-agriculture-handbook-360#page=212)
- How spotting works — [🖼️ PMS 437, p. 153](lib:nwcg-fire-behavior-field-reference-guide-pms-437#page=153); wind heights and durations — [🖼️ p. 37](lib:nwcg-fire-behavior-field-reference-guide-pms-437#page=37); the valley's burn-probability map — [🖼️ County plan, p. 71](lib:josephine-county-multi-jurisdictional#page=71); heat on a wall by distance — [🖼️ Cohen, p. 3](lib:usfs-cohen-reducing-the-wildland-fire-threat-to-homes-psw-gtr-173-1999#page=3)
- The zones — [🖼️ FEMA P-737, p. 23](lib:fema-p-737#page=23), [🖼️ EM 9247, p. 2](lib:osu-em-9247-home-ignition-zone#page=2), [🖼️ EM 9184, p. 4](lib:osu-em-9184#page=4); fire climbing into trees — [🖼️ P-737, p. 21](lib:fema-p-737#page=21); ladder fuels — [🖼️ EC 1573, p. 2](lib:reducing-hazardous-fuels-on-woodland-property-thinning#page=2)
- Crown spacing and limbing — [🖼️ OSFM, p. 14](lib:osfm-defensible-space-homeowner-guide#page=14), [🖼️ OSFM tool, p. 2](lib:osfm-defensible-space-assessment-tool#page=2); shrub spacing — [🖼️ EM 9184, p. 16](lib:osu-em-9184#page=16); regrowth 8 years on — [🖼️ p. 3](lib:osu-em-9184#page=3)
- Embers into vents; mesh sizes; a vent shutter — [🖼️ P-737, p. 40](lib:fema-p-737#page=40), [🖼️ OSFM, p. 8](lib:osfm-defensible-space-homeowner-guide#page=8), [🖼️ P-737, p. 41](lib:fema-p-737#page=41); open and boxed eaves — [🖼️ BCD, p. 6](lib:oregon-wildfire-home-hardening-guide-bcd#page=6); debris under a deck — [🖼️ P-737, p. 62](lib:fema-p-737#page=62)
- Sprinklers on a holding tank — [🖼️ P-737, p. 69](lib:fema-p-737#page=69); a dry hydrant — [🖼️ p. 78](lib:fema-p-737#page=78); Pulaski, McLeod, shovels — [🖼️ MTDC, p. 25](lib:handtools-for-trail-work#page=25), [🖼️ p. 26](lib:handtools-for-trail-work#page=26), [🖼️ p. 29](lib:handtools-for-trail-work#page=29)
- Hand line: cleared and scraped — [🖼️ PMS 465, p. 42](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=42); cup trench — [🖼️ p. 38](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=38); low limbs and heat across a line — [🖼️ p. 40](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=40), [🖼️ p. 41](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=41); mop-up — [🖼️ p. 52](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=52); burning out and backfiring — [🖼️ p. 112](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=112), [🖼️ p. 113](lib:nwcg-wildland-fire-suppression-tactics-reference-guide-pms-465-1996#page=113)
- The protective clothing kit — [🖼️ CFA, p. 7](lib:cfa-defending-your-property-bushfire-survival-plan-template-2023#page=7); tree fall zones — [🖼️ FS-1273, p. 36](lib:tree-risk-assessments#page=36); a debris flow — [🖼️ USGS, p. 1](lib:usgs-postfire-debris-flow-hazards-tips-fs-2022-3078#page=1); slash scattered and a proper burn pile — [🖼️ EC 1574, p. 2](lib:disposing-of-woody-material#page=2), [🖼️ p. 3](lib:disposing-of-woody-material#page=3); an underburn in oak — [🖼️ KBO, p. 45](lib:restoring-oak-habitats#page=45)
- With photos — [Wildfire](wiki:Wildfire); [Defensible space](wiki:Defensible_space_(fire_control)); [Fire whirl](wiki:Fire_whirl); [Fire flapper](wiki:Fire_flapper); [Snag](wiki:Snag_(ecology)); [Hydrophobic soil](wiki:Hydrophobic_soil); [Controlled burn](wiki:Controlled_burn)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — evacuation levels, the go-kit, basic defensible space, a cleaner-air room
- [Home Defense](guide:HOME-DEFENSE-GUIDE) — "Fire as a threat to your home"; windows, shutters, fences, gates, the driveway
- [Shelter & Building](guide:SHELTER-BUILDING-GUIDE) — "Earthquake and wildfire hardening": vents, gutters, woodpiles
- [What to Expect](guide:WHAT-TO-EXPECT-GUIDE) and [Navigation & Weather](guide:NAVIGATION-WEATHER-GUIDE) — the 2020 fires, east wind, inversions, judging smoke
- [Water Wells](guide:WATER-WELLS-GUIDE), [Storing Energy](guide:STORING-ENERGY-GUIDE) and [Water Purification](guide:WATER-PURIFICATION-GUIDE) — the well without the grid, a tank up the hill, water "After a wildfire"
- [Field Care](guide:FIELD-CARE-GUIDE) — "Burns" and "Heat and cold in the Valley"; [Firewood](guide:FIREWOOD-GUIDE) — felling burned trees, saws in fire season
- [Radio](guide:RADIO-GUIDE), [Signals & Morse](guide:SIGNALS-MORSE-GUIDE) and [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) — alarms, lookouts, a neighborhood group
- [Chickens](guide:CHICKENS-GUIDE), [Rabbits](guide:RABBITS-GUIDE), [Goats](guide:GOATS-GUIDE), [Sheep](guide:SHEEP-GUIDE), [Cattle](guide:CATTLE-GUIDE), [Pigs](guide:PIGS-GUIDE), [Geese](guide:GEESE-GUIDE) and [Horses](guide:HORSE-GUIDE) — animals in heat, smoke and fire
- [Sanitation](guide:SANITATION-GUIDE) and [Masonry & Roads](guide:MASONRY-ROADS-GUIDE) — burning brush and trash; mortar for sealing gaps
- [Floods, Ice Storms & Heat Waves](guide:FLOODS-STORMS-HEAT-GUIDE) — the first hour of a flood, cleaning up, ice storms, frozen pipes, carbon monoxide, heat waves
- [Chronic Illness With No Pharmacy](guide:CHRONIC-ILLNESS-GUIDE) — diabetes, blood pressure, asthma, seizures and other daily medicines when the pharmacy is gone
- [How the Power Grid Works](guide:POWER-GRID-GUIDE) — downed lines, step potential, and lines that come back to life
- [Dams, Weirs, Ditches & Ponds](guide:DAMS-DITCHES-GUIDE) — a farm pond for fire water
- [Building Soil](guide:GROWING-SOIL-GUIDE) — keeping mulch, hugelkultur beds and food forests out of the zones around the house
- [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE) — acorns, camas, salmon, cordage and baskets, houses, and tending the land with fire, the way people here lived for thousands of years.
