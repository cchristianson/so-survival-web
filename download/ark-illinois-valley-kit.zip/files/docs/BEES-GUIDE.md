# 🐝 Bees: Honey, Wax and Pollination

How to keep honey bees with no bee-supply store, no bought queens and no mite strips: hives you can build from
scrap, gear you can make, free bees from swarms and bee trees, the bee year in the Illinois Valley, queens,
swarms, mites and foulbrood, feeding and wintering through wet winters, honey and wax, bears, stings, and how
many hives a family needs for sweetener and pollination. The bee books are in `Animals\Bees`; the Oregon State
backyard bulletin and the beneficial-insects bulletin are in `Gardening-Food`, honey processing is in
`Food-From-Scratch\Wild-and-Local-Staples`, wax and candles in `Homestead-Skills\Soap-Candles`, and bears in
`Animals\Planning-Predators-Toxic-Plants`.

> ### The short version
> - **Never give honey to a baby under 1 year** — infant botulism
>   ([FDA *Bad Bug Book*, p. 108](lib:fda-bad-bug-book-2nd-edition-foodborne-pathogens-and-natural-toxins-incl-mushroom-toxins-2012#page=108)).
> - **Anyone who has had a whole-body reaction to a sting** (hives all over, wheezing, faintness) must not work
>   bees without epinephrine at hand. **Scrape stingers out** at once; don't pinch them.
> - **Swarms are your only new bees now.** Catch them **March–June**, set bait hives, and keep **at least 3
>   colonies** so one dead queen or one bad winter doesn't end your beekeeping *(rule of thumb)*.
> - **Count mites every month from spring to fall** and act at **1–2 mites per 100 bees**. Unchecked, mites
>   double monthly and kill a colony in 2–3 years.
> - **Leave about 60 lb of honey** on each colony for winter here, and harvest **only sealed comb**.
> - **Burn American foulbrood** — combs, frames and honey — and never feed honey from hives you don't know.
> - **Electric-fence the hives** against black bears: wires at **8, 20 and 32 inches**, **6,000+ volts**.
> - **Beeswax catches fire.** Melt it only in or over water, never over a bare flame, and never throw water on
>   burning wax.

---

## 🐝 How a colony works

A colony is one **queen** (the only egg-layer), several to **60,000 workers** and, in spring and summer, a few
hundred drones (males) ([USDA AH 335, p. 36](lib:beekeeping-in-the-united-states#page=36)). The colony, not the
bee, is the animal you keep.

| | Egg to adult | Lives | Job |
|---|---|---|---|
| Worker | **21 days** ([AH 335, p. 34](lib:beekeeping-in-the-united-states#page=34)) | **About 6 weeks** in summer; **months** for fall-raised "winter bees" ([p. 35](lib:beekeeping-in-the-united-states#page=35)) | Nurse and build comb (wax glands work at 12–15 days old), then forage the last ~3 weeks ([pp. 33–34](lib:beekeeping-in-the-united-states#page=33)) |
| Drone | **About 24–25 days** ([Langstroth, p. 68](lib:langstroth-on-the-hive#page=68); [FAO Forest, p. 148](lib:bees-and-their-role-in-forest-livelihoods#page=148)) | **8 weeks or less**; thrown out when nectar fails in fall ([AH 335, pp. 35–36](lib:beekeeping-in-the-united-states#page=35)) | Mating only |
| Queen | **About 16 days** *(rule of thumb)* | Lays **2–5 years** ([p. 35](lib:beekeeping-in-the-united-states#page=35)) | Lays every egg |

![Drawings of the three kinds of honey bee: a worker, the long-bodied queen, and the broad, big-eyed drone](img:BEES-GUIDE/worker-queen-drone.png)
*Left to right: worker, queen, drone. The queen is longer, with a long tapering abdomen ([AH 335, p. 36](lib:beekeeping-in-the-united-states#page=36)).*

- **The egg stage is 3 days** for all three ([p. 33](lib:beekeeping-in-the-united-states#page=33)): eggs standing
  in cells mean a queen laid within the last 3 days.
- A virgin queen flies to mate **5–6 days** after emerging, mates with **8–12 drones**, and lays **2–5 days**
  later ([p. 44](lib:beekeeping-in-the-united-states#page=44)). Delayed **over 3 weeks**, she will likely lay only
  drones ([p. 35](lib:beekeeping-in-the-united-states#page=35)).
- Bees forage mostly within **2 km** (1¼ miles), up to **7 km** when they must
  ([FAO Forest, p. 77](lib:bees-and-their-role-in-forest-livelihoods#page=77)) — about **12,500 acres**
  ([AH 335, p. 43](lib:beekeeping-in-the-united-states#page=43)).
- **Which bees:** there are no Africanized bees in Oregon ([OSU EM 9186, p. 14](lib:osu-residential-beekeeping-best-practices-em-9186#page=14)).
  Keep the gentle colonies that winter well with low mite counts and raise queens from them: local bees are
  better adapted than imported ones ([FAO 2006, p. 36](lib:honey-bee-diseases-and-pests#page=36)), and "some
  locally derived stocks" resist mites ([HBHC, p. 41](lib:tools-for-varroa-management#page=41)).

## 🏠 Hives: top-bar, Langstroth or log

| | [Top-bar hive](wiki:Horizontal_top-bar_hive) | [Langstroth hive](wiki:Langstroth_hive) | Log or box ("fixed comb") |
|---|---|---|---|
| Building | From scrap; **only the bar width must be exact**; a strip of beeswax on each bar guides the comb | Precise carpentry; frames, nails, wire, foundation | Hollow log, barrel or box |
| Inspecting | Lift one comb at a time | Easy; frames are strong | **Can't be checked for disease** |
| Harvest | Cut comb: honey **and wax**, **no extractor**; combs are fragile | Pays off with an extractor — empty combs go back in. A full deep frame holds about **5 lb** | Cut out end combs; messy |
| Honey : wax | About **10 : 1** | About **75 : 1** | About 10 : 1 |
| Source | [FAO Forest, pp. 43–45](lib:bees-and-their-role-in-forest-livelihoods#page=43) | [AH 335, pp. 72–73](lib:beekeeping-in-the-united-states#page=73); [🖼️ plans](lib:beekeeping-in-the-united-states#page=53); [🖼️ cutaway](lib:beekeeping-in-the-united-states#page=54) | [FAO Forest, pp. 42–43](lib:bees-and-their-role-in-forest-livelihoods#page=42); ratios [p. 107](lib:bees-and-their-role-in-forest-livelihoods#page=107) |

With no extractor or foundation, **build top-bar hives**; keep any Langstroth boxes you have — they work with
crush-and-strain too *(rule of thumb)*. Don't rely on frame hives unless their parts can be made locally
([FAO Forest, p. 45](lib:bees-and-their-role-in-forest-livelihoods#page=45)).

### Building a top-bar hive from scrap wood

1. **Wood:** seasoned (green wood warps), durable, no cracks or chemical smells
   ([FAO Forest, p. 44](lib:bees-and-their-role-in-forest-livelihoods#page=44)); no treated lumber *(rule of thumb)*.
2. **Top bars exactly 35 mm (1⅜ in) wide**, all the same: too narrow crowds the combs, too wide gets extra
   "brace comb" between them ([pp. 43–44](lib:bees-and-their-role-in-forest-livelihoods#page=43)). It matches
   Langstroth frame spacing, **1⅜ in** ([AH 335, p. 52](lib:beekeeping-in-the-united-states#page=52)).
3. **Comb guide:** a strip of beeswax down the centre of each bar's underside
   ([FAO Forest, p. 44](lib:bees-and-their-role-in-forest-livelihoods#page=44)), or a saw groove filled with
   melted wax *(rule of thumb)*.
4. **Size** *(rule of thumb)*: inside **36–42 in long** (26–30 bars), **10–12 in deep**, about **15 in wide** at
   the top; bars rest across the side walls. **Sides sloping in** toward the bottom keep comb off the walls;
   straight sides work if you cut the attachments ([p. 45](lib:bees-and-their-role-in-forest-livelihoods#page=45)).
5. **Entrance:** two or three **1-inch holes** at one end, with corks
   ([AH 335, p. 73](lib:beekeeping-in-the-united-states#page=73) uses 1-inch auger holes). A **follower board**
   cut to the hive's shape shrinks the space for a small colony *(rule of thumb)*; match hive space to colony
   strength ([FAO 2006, p. 38](lib:honey-bee-diseases-and-pests#page=38)).
6. **Roof** overhanging, weighted with rocks ([OSU EM 9186, p. 5](lib:osu-residential-beekeeping-best-practices-em-9186#page=5)),
   straw under it in winter ([FAO Forest, p. 44](lib:bees-and-their-role-in-forest-livelihoods#page=44)).
   **Legs** to waist height ([p. 47](lib:bees-and-their-role-in-forest-livelihoods#page=47)); at least **1 ft**
   up stops skunks ([OSU EM 9186, p. 10](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)).

![A top-bar hive cut across and cut along: top bars 1⅜ in wide resting on sloping side walls, combs hanging from the bars, a follower board, 1-in entrance holes at one end, a weighted roof and legs at least 1 ft high](img:BEES-GUIDE/top-bar-hive.svg)
*The hive in the list above; what matters most is that every bar is exactly the same width (a diagram drawn for this guide).*

### Building Langstroth boxes from scrap

- **The two numbers that matter:** the **bee space**, about **⅜ in** — smaller gaps get glued with propolis,
  bigger ones filled with comb ([AH 335, p. 9](lib:beekeeping-in-the-united-states#page=9)) — and **10 frames
  1⅜ in centre to centre** ([p. 52](lib:beekeeping-in-the-united-states#page=52)).
- Copy the drawing ([🖼️ AH 335, p. 53](lib:beekeeping-in-the-united-states#page=53)) or a borrowed factory box.
  Standard US sizes *(rule of thumb)*: deep box **19⅞ × 16¼ in outside, 9⅝ in tall** (18⅜ × 14¾ inside); deep
  frame **19 in** top bar, **9⅛ in** tall. Make every box the same so they swap (p. 53).
- **No foundation?** Give frames a wax starter strip like a top bar ([FAO 2006, p. 12](lib:honey-bee-diseases-and-pests#page=12)),
  or cast sheets in a plaster-of-Paris press ([FAO Forest, p. 114](lib:bees-and-their-role-in-forest-livelihoods#page=114)).

### Where to put the hives

- **Morning sun, facing southeast**, out of the wind ([OSU EM 9186, p. 5](lib:osu-residential-beekeeping-best-practices-em-9186#page=5)),
  with **afternoon shade** in our hot summers: shaded colonies can make **50% more honey** in strong sun; white
  paint helps ([FAO Forest, p. 47](lib:bees-and-their-role-in-forest-livelihoods#page=47)). Comb softens above
  **35 °C (95 °F)** in the hive ([p. 107](lib:bees-and-their-role-in-forest-livelihoods#page=107)).
- **Water within half a mile** ([AH 335, p. 51](lib:beekeeping-in-the-united-states#page=51)); out of sight of
  paths and thieves; not under dripping branches ([FAO Forest, pp. 46–47](lib:bees-and-their-role-in-forest-livelihoods#page=46)).
- **Space and colour the hives** so you can work from the side and young bees don't drift
  ([OSU EM 9186, p. 5](lib:osu-residential-beekeeping-best-practices-em-9186#page=5);
  [AH 335, p. 33](lib:beekeeping-in-the-united-states#page=33)). A **6-ft fence or hedge** in front lifts the
  flight path over people's heads ([OSU EM 9186, p. 6](lib:osu-residential-beekeeping-best-practices-em-9186#page=6)).
- Start with **no more than 10 colonies** in one place ([FAO Forest, p. 47](lib:bees-and-their-role-in-forest-livelihoods#page=47)).

## 🧰 Gear you can make

- **Veil:** a broad-brimmed hat with netting to the shoulders, tucked in
  ([FAO Forest, p. 46](lib:bees-and-their-role-in-forest-livelihoods#page=46);
  [Kephart, p. 367](lib:kephart-camping-and-woodcraft-vol-2#page=367)). Always wear one: a sting in the eye or mouth
  is dangerous ([FAO Forest, p. 49](lib:bees-and-their-role-in-forest-livelihoods#page=49)).
- **Clothes:** light-coloured, smooth; bees go for dark, rough or woolly cloth, suede and leather
  ([AH 335, p. 148](lib:beekeeping-in-the-united-states#page=148)). Tie cuffs and trouser legs; wash off the sting
  smell after ([FAO Forest, pp. 46, 49](lib:bees-and-their-role-in-forest-livelihoods#page=46)). **Gloves:**
  long gauntlets, or a plastic bag over each hand held with a band ([p. 46](lib:bees-and-their-role-in-forest-livelihoods#page=46)).
- **Smoker:** a fuel can with bellows, made by a smith; fuel is dry cow dung, burlap or cardboard
  ([p. 46](lib:bees-and-their-role-in-forest-livelihoods#page=46)), or dry punky rotten wood, which smoulders for
  hours ([Kephart, p. 368](lib:kephart-camping-and-woodcraft-vol-2#page=368)). Puff **cool** smoke, never close
  enough to scorch bees ([FAO Forest, p. 48](lib:bees-and-their-role-in-forest-livelihoods#page=48)): at the
  entrance first, then gently under the lid ([AH 335, p. 41](lib:beekeeping-in-the-united-states#page=41)).
- **Hive tool:** flat steel with a scraper end; an old knife bends too easily
  ([FAO Forest, p. 46](lib:bees-and-their-role-in-forest-livelihoods#page=46)). See the
  [Blacksmithing guide](guide:BLACKSMITHING-GUIDE). **Bee brush:** grass or a feather ([p. 48](lib:bees-and-their-role-in-forest-livelihoods#page=48)).
- **Feeder:** a lidded pail with nail holes, upside down over the bars or inner-cover hole
  ([AH 335, p. 50](lib:beekeeping-in-the-united-states#page=50)). **Entrance reducer** and **robbing screen**
  ([🖼️ OSU, p. 10](lib:osu-residential-beekeeping-best-practices-em-9186#page=10); [HBHC, p. 42](lib:tools-for-varroa-management#page=42)).
  **Mite-wash jar:** a quart jar, **#8 screen** in the lid, a ½-cup scoop ([HBHC, p. 8](lib:tools-for-varroa-management#page=8)).
- **Solar wax melter** (see "Beeswax: rendering and uses"). An **extractor** can be built from a plastic drum and
  bicycle parts ([FAO Forest, p. 92](lib:bees-and-their-role-in-forest-livelihoods#page=92)) — only for wired frames.

## 🎣 Getting bees: swarms, bait hives, bee trees and splits

Package bees came from California every April–May ([OSU EM 9186, p. 14](lib:osu-residential-beekeeping-best-practices-em-9186#page=14)).
That's over: new bees come from swarms, wild colonies and your own splits.

### Catching a swarm

A **[swarm](wiki:Swarming_(honey_bee))** is the old queen and **30–70%** of the workers
([OSU EM 9186, p. 14](lib:osu-residential-beekeeping-best-practices-em-9186#page=14)). Swarms come mostly
**March–June** and hang in a cluster for about an hour while scouts search
([AH 335, p. 38](lib:beekeeping-in-the-united-states#page=38); [🖼️ resting swarm](lib:osu-residential-beekeeping-best-practices-em-9186#page=4)).
They are full of honey and "in the most peaceable mood" ([Langstroth, p. 41](lib:langstroth-on-the-hive#page=41)).
1. Set a box, ideally with a comb or two of old comb in it, right under the cluster *(rule of thumb)*.
2. Shake the cluster in with one sharp jolt ([🖼️ hiving a swarm](lib:beekeeping-in-the-united-states#page=38)).
3. **Queen in?** Bees stand at the entrance fanning, tails raised, and the rest march in within minutes
   ([AH 335, p. 41](lib:beekeeping-in-the-united-states#page=41)). If they stream back to the branch, shake again.
4. **Close it at dusk** and move it to its stand *(rule of thumb)*.
5. With no flow, feed **2:1 syrup for 2–3 weeks** while they build comb ([AH 335, p. 51](lib:beekeeping-in-the-united-states#page=51)).
   Check mites even in a new swarm ([HBHC, p. 13](lib:tools-for-varroa-management#page=13)).

### Bait hives

An empty hive "rubbed inside with some beeswax" catches passing swarms where wild colonies are common
([FAO Forest, p. 47](lib:bees-and-their-role-in-forest-livelihoods#page=47)); old wax smell draws them
([plate 3.5, p. 96](lib:bees-and-their-role-in-forest-livelihoods#page=96)). Rule of thumb: about **10 gallons
(40 L)** inside, one entrance about **1 in** across, **8–15 ft up** in shade, an old dark comb inside, up by
**early March**. Check weekly; move a caught swarm at dusk.

### Bee trees and cut-outs

- **Bee lining** ([Kephart, pp. 358–366](lib:kephart-camping-and-woodcraft-vol-2#page=358)): a mile or more from
  tame bees, set out thin syrup (sugar in **3 times its bulk of water**, or honey thinned half and half) with a
  drop of anise. Note which way the loaded bees fly home, move **200–300 yards** to one side and repeat; the
  lines cross near the tree. Bee trees are seldom far from water. In settled country the tree belongs to the
  landowner ([p. 366](lib:kephart-camping-and-woodcraft-vol-2#page=366)) — ask.
- **Saving the colony:** cut out the brood combs, tie them into frames or onto top bars, let the bees cluster on
  them and carry them home at dusk ([FAO Forest, p. 47](lib:bees-and-their-role-in-forest-livelihoods#page=47);
  [Kephart, p. 368](lib:kephart-camping-and-woodcraft-vol-2#page=368)).

### Splits

A split (nuc) is **3–5 combs of bees and brood** from a strong colony ([AH 335, p. 65](lib:beekeeping-in-the-united-states#page=65)).
With a laying queen it reaches full strength in about **9 weeks**, against **12 weeks** for a 2-lb package; take
splits from your **strongest overwintered colonies** in spring ([p. 66](lib:beekeeping-in-the-united-states#page=66)).
Giving a split a queen is under "Queens" below.

## 📅 The colony's year in the Illinois Valley

Cave Junction winters average **40 °F** with nights near freezing, and only about **15%** of the year's rain
falls April–September ([Josephine soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)).
Winter here is **wet more than cold**, and the hungry time is the **late-summer drought**. Bloom months are for
the valley floor and shift with the weather *(rule of thumb)*.

| Months | The colony | Blooming | Your jobs |
|---|---|---|---|
| **Dec–Jan** | Clustered; queen restarts laying late Dec–Jan ([AH 335, p. 37](lib:beekeeping-in-the-united-states#page=37)) | Little; hazel catkins *(rule of thumb)* | Heft hives; don't open them. Oxalic dribble only if broodless ([HBHC, p. 29](lib:tools-for-varroa-management#page=29)). Build boxes, render wax |
| **Feb** | Brood growing; stores dropping | [Manzanita](wiki:Arctostaphylos) **Feb–Apr** ([NRCS, p. 1](lib:whiteleaf-manzanita-plant-guide#page=1)); willow *(rule of thumb)* | Heft; emergency feed if light |
| **Mar** | Drones appear; **swarm season opens** ([AH 335, p. 38](lib:beekeeping-in-the-united-states#page=38)) | Willow, [bigleaf maple](wiki:Acer_macrophyllum), plum *(rule of thumb)* | First look on a warm, still day; **mite count monthly from now** ([HBHC, p. 7](lib:tools-for-varroa-management#page=7)); bait hives up |
| **Apr–May** | Fast growth; swarm cells | Maple, fruit bloom, dandelion, ceanothus, clover *(rule of thumb)* | Check every 7–10 days for swarm cells; add room; **split**; raise queens; catch swarms; cut drone brood |
| **Jun–Jul** | Peak population; main flow | **Blackberry, the main flow** *(rule of thumb)* | Add space; harvest sealed surplus by late July; fire season — smoker care |
| **Aug–Sep** | **Dearth** (no nectar); robbing; mites peak as winter bees are raised *(rule of thumb)* | Little till the rains; star thistle, asters *(rule of thumb)* | **Count mites and act early** ([HBHC, p. 17](lib:tools-for-varroa-management#page=17)); narrow entrances; no open feeding; heft, feed 2:1 if light; check the bear fence |
| **Oct–Nov** | Drones out; brood stops; cluster below **57 °F** ([AH 335, p. 36](lib:beekeeping-in-the-united-states#page=36)) | A little after the rains *(rule of thumb)* | Combine weak colonies; mouse guards; upper vent; insulate lids; oxalic when broodless |

## 🌼 Forage, water and planting for bees

- **A colony feeds on the countryside, not your garden.** One colony needs "several acres of abundant flowers"
  and uses **50–100 lb of pollen** a season ([AH 335, p. 23](lib:beekeeping-in-the-united-states#page=23)) and
  the nectar of **300–500 lb** of honey a year ([p. 47](lib:beekeeping-in-the-united-states#page=47)). What you
  plant fills gaps and feeds pollinators.
- **Local forage:** western beekeepers build colonies up on manzanita in spring; wild buckwheat, star thistle and
  fireweed give honey crops ([p. 21](lib:beekeeping-in-the-united-states#page=21)); AH 335's bee-plant table
  includes blackberry, ceanothus, cascara and alder ([p. 24](lib:beekeeping-in-the-united-states#page=24)).
  [Manzanita](wiki:Arctostaphylos), which grows even on serpentine, blooms February–April and bees visit it
  ([NRCS, pp. 1–2](lib:whiteleaf-manzanita-plant-guide#page=1)). Fireweed comes up after a burn *(rule of thumb)*.
- **Plant** ([PNW 550, pp. 18–23](lib:pnw-encouraging-beneficial-insects#page=18)): single (not double),
  open-pollinated flowers, something in bloom spring to fall — **clover and vetch**, **phacelia**,
  **buckwheat**, **mustard and radish** left to flower, **aster, goldenrod and yarrow**, **lavender, thyme and
  catmint**, penstemon. Leave bare ground and hollow stems for native bees. Buckwheat sown in late spring blooms
  into the July–August dearth *(rule of thumb)*.
- **Spray nothing on open flowers**; systemic insecticides (neonicotinoids) stay in nectar and pollen for weeks to
  a year ([PNW 550, p. 24](lib:pnw-encouraging-beneficial-insects#page=24)).
- **Water:** set it up **early in spring**, **never let it go dry** (or they adopt the neighbour's trough), and
  give floats or a rock to stand on ([OSU EM 9186, p. 7](lib:osu-residential-beekeeping-best-practices-em-9186#page=7)).
- **Poison bloom:** avoid sites thick with California buckeye, death camas, laurel or rhododendron in flower
  ([AH 335, p. 23](lib:beekeeping-in-the-united-states#page=23)). Rhododendron and laurel honey can poison people —
  drunkenness, tingling, blurred sight, vomiting for 2–3 days ([Kephart, pp. 369–370](lib:kephart-camping-and-woodcraft-vol-2#page=369);
  [Grayanotoxin](wiki:Grayanotoxin)). Our [western azalea](wiki:Rhododendron_occidentale) is a rhododendron: if a
  May–June honey tastes bitter or makes the mouth tingle, don't eat it *(rule of thumb)*.

## 👑 Queens: finding her, queenless signs, raising your own

**Finding her:** longer than a worker, with a long tapering abdomen ([🖼️ AH 335, p. 36](lib:beekeeping-in-the-united-states#page=36)),
usually on combs with eggs. You don't need to see her: **eggs mean she was there within 3 days**. A good queen
lays a **solid, compact brood pattern**; replace spotty layers; queens **under a year old** are usually best
([AH 335, p. 70](lib:beekeeping-in-the-united-states#page=70); [🖼️ poor and good brood](lib:beekeeping-in-the-united-states#page=71)).

![Two close-up photos of brood comb, each with a queen on it: one with many open cells scattered among the capped brood, one almost solid capped brood](img:BEES-GUIDE/brood-pattern-spotty-and-solid.png)
*A spotty brood pattern (A, open cells scattered among the capped ones) and a good, solid one (B) ([AH 335, p. 71](lib:beekeeping-in-the-united-states#page=71)).*

**Queenless signs** ([OSU EM 9186, p. 11](lib:osu-residential-beekeeping-best-practices-em-9186#page=11)):
**emergency queen cells** on the **face** of brood combs within **1–2 days**; **no new eggs** within **4 days**;
bees growing **more defensive**. Experienced keepers hear the difference ([AH 335, p. 42](lib:beekeeping-in-the-united-states#page=42)).
**Only drone brood**, in raised bullet-shaped caps, means an unmated queen or "fertile workers," which lay only
drones ([Langstroth, p. 53](lib:langstroth-on-the-hive#page=53)); several eggs to a cell means laying workers
*(rule of thumb)*.

**Fixing it:** give a comb of **eggs and young larvae** from another colony so they can raise a queen (queens
come from larvae **12–24 hours old**: [AH 335, p. 64](lib:beekeeping-in-the-united-states#page=64)), or unite
with a queenright colony through a sheet of **newspaper** — by the time they chew through, their smells have
mixed ([p. 41](lib:beekeeping-in-the-united-states#page=41)). A long-queenless colony is hard to requeen
([OSU EM 9186, p. 11](lib:osu-residential-beekeeping-best-practices-em-9186#page=11)); if it's weak, shake the
bees out and give the combs to another colony ([AH 335, p. 70](lib:beekeeping-in-the-united-states#page=70)).

**Swarm cells or supersedure?** Swarm cells hang on the **bottom edges** of combs, **a dozen or more**; supersedure
or emergency cells sit on the comb **face**, **1–3** of them ([OSU EM 9186, pp. 10–11](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)).

![Two combs: one with a dozen or more queen cells hanging along its bottom edge (swarm cells), one with two queen cells on its face (supersedure or emergency cells)](img:BEES-GUIDE/swarm-vs-supersedure-cells.svg)
*Where the queen cells are tells you why the bees are making them (a diagram drawn for this guide).*

**Raising your own queens without grafting tools:**
1. **Pick the mother:** gentle, productive, not swarmy, winters well ([AH 335, p. 76](lib:beekeeping-in-the-united-states#page=76)),
   low mite counts ([HBHC, p. 41](lib:tools-for-varroa-management#page=41)).
2. **Wait for the season:** strong colonies, plenty of nectar and pollen, **drones flying** — April–June
   ([AH 335, p. 66](lib:beekeeping-in-the-united-states#page=66)).
3. **Split her colony:** the queenless half, given combs of eggs and young larvae, starts emergency cells in 1–2 days.
4. **About 10 days later**, cut out extra **capped** cells and give each, with a couple of combs of bees, to a
   small queenless split — the "mating nucs" queen breeders use ([AH 335, p. 64](lib:beekeeping-in-the-united-states#page=64)).
   Keep cells upright and handle them gently *(rule of thumb)*.
5. **Look for eggs about 2 weeks** after she emerges (p. 64). None after **3 weeks**: she likely won't mate
   ([p. 35](lib:beekeeping-in-the-united-states#page=35)); unite the split back.

**Keep the line going:** keep a card per hive — queen or eggs seen, brood, stores, queen cells, mites, temper,
what you did ([OSU EM 9186, p. 15](lib:osu-residential-beekeeping-best-practices-em-9186#page=15) has a sample
sheet) — and breed only from the best. A queen mates with drones from up to **5 miles** away, and in inbred lines
workers remove many larvae ([AH 335, p. 57](lib:beekeeping-in-the-united-states#page=57)), leaving gappy brood
*(rule of thumb)*; so swap swarms and queen cells with other beekeepers in the valley, and don't bring bees or
combs in from outside — that is how diseases travel ([FAO Forest, p. 41](lib:bees-and-their-role-in-forest-livelihoods#page=41)).

## 🌀 Swarm prevention

A colony swarms when **more than 6 frames of bees**, **crowding** and **lots of young bees** line up
([OSU EM 9186, pp. 4–5](lib:osu-residential-beekeeping-best-practices-em-9186#page=4)). Warnings: a beard of bees
at the entrance on warm afternoons ([AH 335, p. 37](lib:beekeeping-in-the-united-states#page=37)) and foragers
slacking off ([p. 42](lib:beekeeping-in-the-united-states#page=42)).
1. **Room early:** add space before the main flow, and more before the last box is **two-thirds full**
   ([OSU EM 9186, p. 10](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)).
2. **Langstroth:** swap top and bottom brood boxes every **10 days to 2 weeks** until the flow starts
   ([AH 335, p. 75](lib:beekeeping-in-the-united-states#page=75)). **Top-bar:** move full honey combs back and put
   empty bars at the edge of the brood *(rule of thumb)*.
3. **Split strong colonies in spring** ([OSU EM 9186, p. 11](lib:osu-residential-beekeeping-best-practices-em-9186#page=11)).
4. **Once swarm cells appear, cutting them out isn't enough** — the bees build more where you can't see. Move **at
   least half the sealed brood and bees** into a split (same page), and use the cells to raise queens.
5. **If a swarm leaves anyway,** the old hive raises a new queen from its cells; leave it a cell or two and look
   for eggs about 3 weeks later *(rule of thumb)*.

## 🕷️ Varroa and other pests without store chemicals

**[Varroa mites](wiki:Varroa_destructor) are the main killer.** Unchecked they double every month
([HBHC, p. 5](lib:tools-for-varroa-management#page=5); [🖼️ mites on bees and larvae](lib:honey-bee-diseases-and-pests#page=20)),
and untreated colonies usually die in **2–3 years**, spreading mites as they collapse; bees with crumpled wings
mean the mites are already heavy ([FAO 2006, p. 19](lib:honey-bee-diseases-and-pests#page=19)). Here they peak in
August–September, as the winter bees are raised *(rule of thumb)*.

**Counting mites** ([HBHC, pp. 9–10](lib:tools-for-varroa-management#page=9)):
1. Shake bees from 1–3 brood frames (**not the one with the queen**) into a tub.
2. Scoop **½ cup (about 300 bees)** into a jar of rubbing alcohol or soapy water, shake, and count the mites.
   No alcohol: shake them with 2 tablespoons of powdered sugar instead — less reliable (p. 9).
3. Mites ÷ 300 × 100 = mites per 100 bees. **Act at 1+ in winter and spring, 2+ in summer and fall.**
4. Count **monthly** from spring buildup ([p. 7](lib:tools-for-varroa-management#page=7)); if one colony is over,
   treat them all ([p. 10](lib:tools-for-varroa-management#page=10)).

**Controls with nothing bought** — none is enough alone; stack them ([HBHC, pp. 37–42](lib:tools-for-varroa-management#page=37)):
- **Cut out capped [drone](wiki:Drone_(bee)) brood** 2–3 times in spring; mites prefer it. Feed it to the hens
  ([p. 39](lib:tools-for-varroa-management#page=39)). In a top-bar hive, cut the drone comb off the brood combs'
  lower edges *(rule of thumb)*.
- **Brood break:** a split without a laying queen, or the queen caged **1–2 weeks**, leaves mites nowhere to hide
  ([p. 40](lib:tools-for-varroa-management#page=40)). Spring splitting and queen rearing does this anyway.
- **Breed from survivors** that keep counts low ([p. 41](lib:tools-for-varroa-management#page=41)).
- **Screened floor** of #8 mesh (only 5–10% fewer mites), **robbing screens**, hives spaced and marked against
  drifting, dead colonies removed fast, brood combs replaced after **5 years** ([pp. 37–38, 42](lib:tools-for-varroa-management#page=37)).
  Mites die within days without bees, so **empty hives and combs carry none** ([p. 5](lib:tools-for-varroa-management#page=5)).

**If you stockpiled [oxalic acid](wiki:Oxalic_acid)** ([HBHC, p. 29](lib:tools-for-varroa-management#page=29)):
**35 g, weighed** (about 2⅓ level tablespoons with no scale) in **1 liter of 1:1 syrup**; **5 mL on the bees in
each occupied gap** between combs, **50 mL at most per colony**, only with **no capped brood** (late fall, winter,
end of a brood break). Repeating it harms bees ([FAO 2006, p. 21](lib:honey-bee-diseases-and-pests#page=21)).
**Corrosive: gloves, goggles and a mask when mixing crystals. Vaporizing it is extremely dangerous.** If you can
still get it, stockpile pure oxalic acid dihydrate now *(rule of thumb)*.

**Other pests:**
- **[Wax moth](wiki:Galleria_mellonella)** can't kill a strong colony; it wrecks combs in weak hives and in dark,
  warm, airless storage ([AH 335, p. 132](lib:beekeeping-in-the-united-states#page=132)). Keep colonies strong and
  hives sized to them; store spare comb cool, light, airy and bee-tight, or in winter cold; **118 °F (48 °C) for
  3 hours** kills all stages ([FAO 2006, p. 29](lib:honey-bee-diseases-and-pests#page=29)). Render old black comb.
- **Robbing and [yellowjackets](wiki:Yellowjacket)** in the dearth: narrow entrances, never spill syrup or leave
  comb out, cover open combs with a damp cloth ([OSU EM 9186, pp. 9–10](lib:osu-residential-beekeeping-best-practices-em-9186#page=9)).
  Kill the first few hornets at a hive before the attack builds ([FAO 2006, p. 28](lib:honey-bee-diseases-and-pests#page=28)).
- **Skunks** scratch at entrances at night — mud, scratch marks, torn grass in front. Raise hives **1 ft+** or lay
  a nail-point board or chicken wire in front ([OSU EM 9186, p. 10](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)).
- **Mice** move in for winter: use a reducer ([AH 335, p. 132](lib:beekeeping-in-the-united-states#page=132)).
  **Ants:** hive legs in cans of water or oil; **toads:** stands **16–24 in** high ([FAO 2006, pp. 27, 32](lib:honey-bee-diseases-and-pests#page=27)).

## ☣️ Foulbrood and other brood diseases

**[American foulbrood](wiki:American_foulbrood) (AFB) means burning.** Its spores live **50+ years**, spread about
**1 km** by robbing and drifting, and often arrive in **foreign honey** ([FAO 2006, p. 10](lib:honey-bee-diseases-and-pests#page=10)).
- **Signs:** spotty brood; sunken, darker, pierced cappings; foul smell
  ([🖼️ FAO 2006, p. 10](lib:honey-bee-diseases-and-pests#page=10); [🖼️ dead larvae in cells](lib:beekeeping-in-the-united-states#page=126)).
- **Matchstick test:** push a matchstick into a dead larva and draw it out slowly. About **an inch of ropy brown
  goo** means AFB ([FAO Forest, p. 150](lib:bees-and-their-role-in-forest-livelihoods#page=150);
  [🖼️ photo](lib:honey-bee-diseases-and-pests#page=11)).
- **Then:** burn combs, frames, honey and dead bees in a pit about **3 ft deep** and fill it in; scorch the boxes
  inside until slightly brown ([FAO 2006, p. 11](lib:honey-bee-diseases-and-pests#page=11)). In fire season (no
  open burning June–October), shut it all in a bee-tight box or a well-covered pit and burn it after the rains
  *(rule of thumb)*.
- **Saving the bees (shook swarm):** brush them into a clean, scorched hive with only bars and wax starter strips,
  a queen excluder over the entrance; **3 days later** burn those first combs and give fresh bars
  ([FAO 2006, p. 12](lib:honey-bee-diseases-and-pests#page=12)).

**Telling them apart** ([AH 335, p. 124](lib:beekeeping-in-the-united-states#page=124);
[FAO 2006, pp. 12–15](lib:honey-bee-diseases-and-pests#page=12)):

| | Dead brood looks like | Smell | What to do |
|---|---|---|---|
| **AFB** | Older larvae in **capped** cells, coffee-brown, **ropy**; scale stuck tight | Foul | Burn (above) |
| **[European foulbrood](wiki:European_foulbrood)** | **Young, coiled** larvae dying **before capping**; rubbery scale lifts out | Sour | Requeen, remove the worst combs, feed or move to good forage ([FAO 2006, p. 13](lib:honey-bee-diseases-and-pests#page=13)) |
| **[Chalkbrood](wiki:Chalkbrood)** | Hard **white to black "mummies"** that rattle | — | Strong colony, **dry, ventilated hive** sized to the bees ([pp. 13–14](lib:honey-bee-diseases-and-pests#page=13)) |
| **Sacbrood** | Larva on its back, head dark, a **watery sac** | None | Usually recovers; requeen if bad ([p. 15](lib:honey-bee-diseases-and-pests#page=15)) |
| **Chilled brood** | Dead brood at the **edges** of the nest after a cold snap | — | Too few bees; clears itself ([AH 335, p. 129](lib:beekeeping-in-the-united-states#page=129)) |

**Nosema**, a gut disease of adult bees, shows as crawling, trembling bees and spring dwindling, worst after long
spells with no flying weather. Keep colonies strong and dry, and in a sick yard **replace combs about every 2
years** ([FAO 2006, pp. 15–16](lib:honey-bee-diseases-and-pests#page=15)).

📚 **Go deeper:** [HBHC *Tools for Varroa Management*](lib:tools-for-varroa-management#page=9) — mite counts and every treatment; [FAO *Honey Bee Diseases and Pests*](lib:honey-bee-diseases-and-pests#page=10) — photos of brood diseases, mites, beetles and wax moth.

## 🍬 Feeding: sugar if you have it, honey if you don't

**The best feed is their own honey:** leave enough, and save full combs of capped honey from strong colonies to
give to light ones ([AH 335, p. 74](lib:beekeeping-in-the-united-states#page=74)). **Never feed honey from
unknown hives** — it spreads foulbrood ([FAO 2006, p. 10](lib:honey-bee-diseases-and-pests#page=10);
[AH 335, p. 49](lib:beekeeping-in-the-united-states#page=49)).

**If you have white sugar** ([AH 335, pp. 50–51](lib:beekeeping-in-the-united-states#page=50)):
- **Spring 1:1** sugar to water by volume, stirred into water at about **140 °F**; **fall and new colonies 2:1**
  (new swarms get it **2–3 weeks**).
- **Late-winter emergency:** **1–2 lb of dry sugar** on the inner cover, or **candy** (sugar and water 1:1 by
  weight, boiled to soft-ball like fudge, set on waxed paper) laid over the cluster.
- Cane or beet sugar only; bees can't use milk sugar and some others ([p. 45](lib:beekeeping-in-the-united-states#page=45));
  skip brown sugar and molasses *(rule of thumb)*.
- **Feed inside the hive, late in the day, entrances narrowed**; no open buckets
  ([p. 51](lib:beekeeping-in-the-united-states#page=51); [OSU EM 9186, p. 9](lib:osu-residential-beekeeping-best-practices-em-9186#page=9)).

**If you have no sugar:** set a comb of capped honey from your own healthy hive right against the cluster, or pour
**2:1 syrup** — or your own honey thinned with a little warm water *(rule of thumb)* — into empty comb cells
([AH 335, p. 74](lib:beekeeping-in-the-united-states#page=74)). Combine a hopelessly light colony with a strong one
rather than feed it all winter ([p. 72](lib:beekeeping-in-the-united-states#page=72)).

**Pollen** for spring brood: a cake of your own trapped pollen with syrup and soy flour; **1 lb of pollen makes
about 12 lb** ([pp. 74–75](lib:beekeeping-in-the-united-states#page=74); [🖼️ pollen traps](lib:beekeeping-in-the-united-states#page=48)).
Never use another beekeeper's pollen ([p. 49](lib:beekeeping-in-the-united-states#page=49)).

## 🌧️ Wintering through wet winters

**How much to leave:** a colony with no brood eats about **4 lb of honey a month**; an average one about **60 lb**
between the last fall flow and first spring food, a strong one **80+ lb** ([AH 335, p. 72](lib:beekeeping-in-the-united-states#page=72)).
The book's **90 lb** is for cold climates; here plan on about **60 lb** — winters are mild but the long summer
dearth eats stores too *(rule of thumb)*. A full deep frame holds about **5 lb** ([p. 73](lib:beekeeping-in-the-united-states#page=73)),
so 60 lb is about **12 full combs** *(arithmetic)*. Also leave **500 square inches** of pollen comb and at least
**10 lb of bees** ([p. 72](lib:beekeeping-in-the-united-states#page=72)).

**Damp kills more than cold.** Moisture from the cluster condenses on a cold lid and drips on the bees — chill,
dysentery, mouldy combs — while wild colonies in thick tree hollows stay dry
([Langstroth, pp. 131–133](lib:langstroth-on-the-hive#page=131)). Chalkbrood and nosema thrive in damp hives too
([FAO 2006, pp. 14, 16](lib:honey-bee-diseases-and-pests#page=14)).
1. **Upper vent:** a **1-inch hole** high in the hive lets wet air out and gives a door on warm days
   ([AH 335, p. 73](lib:beekeeping-in-the-united-states#page=73); [🖼️ winter hive](lib:beekeeping-in-the-united-states#page=73)).
2. **Insulate the lid** (straw, or a box of dry leaves over a cloth) so the top stays warmer than the walls;
   **tilt the hive slightly forward** so water runs out the door *(rule of thumb)*.
3. **Don't wrap it heavily** — heavily packed bees don't fly on warm days (p. 73), and we get many.
4. **Stores against the cluster:** most honey in the top box of a Langstroth; in a top-bar hive, honey combs next
   to the cluster *(rule of thumb)*. Bees starve inches from honey they can't reach ([p. 37](lib:beekeeping-in-the-united-states#page=37)).
5. **Reducer on** against mice (p. 73), hive up off the wet ground. **Combine colonies under about 10 lb of bees**
   in fall ([p. 72](lib:beekeeping-in-the-united-states#page=72)).
6. **Heft hives monthly.** Mild winters start brood early and burn stores fast *(rule of thumb)*, and a cold, rainy
   spring can starve a colony ([p. 48](lib:beekeeping-in-the-united-states#page=48)): in February–March move honey
   against the cluster or feed ([p. 74](lib:beekeeping-in-the-united-states#page=74)).

## 🍯 Harvesting honey: crush, strain, store

**When:** take **only sealed comb** with no brood or pollen, and leave winter stores
([FAO Forest, p. 48](lib:bees-and-their-role-in-forest-livelihoods#page=48)). Bees cap honey once it is under
**20% water**; then it won't ferment ([Practical Action, p. 1](lib:honey-processing-practical-action#page=1)).
Work mid-morning to mid-afternoon in good weather, keep the hive open briefly
([OSU EM 9186, p. 8](lib:osu-residential-beekeeping-best-practices-em-9186#page=8)), and cover combs at once
([p. 10](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)).

**Crush and strain** ([FAO Forest, pp. 48, 91](lib:bees-and-their-role-in-forest-livelihoods#page=91);
[Practical Action, pp. 1–2](lib:honey-processing-practical-action#page=1)):
1. Brush bees off with grass or a feather; cut the comb from the bar, leaving **a finger's width** as a guide for
   the next. For Langstroth boxes, set a bee-escape board under them the day before
   ([AH 335, p. 100](lib:beekeeping-in-the-united-states#page=100); [🖼️ bee escape](lib:osu-residential-beekeeping-best-practices-em-9186#page=9)).
2. Work in a **bee-tight room**, screened windows ([AH 335, p. 99](lib:beekeeping-in-the-united-states#page=99)),
   with **clean, bone-dry** food-grade plastic or stainless buckets ([Practical Action, p. 2](lib:honey-processing-practical-action#page=2)).
   Honey over **19–20% water** ferments ([p. 3](lib:honey-processing-practical-action#page=3)).
3. Keep some as **cut-comb honey** — the wax is edible and the flavour best ([FAO Forest, p. 91](lib:bees-and-their-role-in-forest-livelihoods#page=91)).
4. Crush the rest; pour through a **coarse** strainer, then **finer** cloths; let it drain for hours; finally
   squeeze the comb in a cloth bag (p. 91). A warm room (75–100 °F) helps it run
   ([AH 335, p. 100](lib:beekeeping-in-the-united-states#page=100)); **don't heat the honey.** Save the wax.

![Four steps: cut the sealed comb off the bar leaving a strip, crush it in a bucket, pour it through a coarse strainer and a fine cloth into a bucket, and squeeze the rest in a cloth bag](img:BEES-GUIDE/crush-and-strain.svg)
*Crush and strain, step by step, with no extractor (a diagram drawn for this guide).*

**Storing it:**
- **Tight lids:** honey pulls water from the air, then ferments ([FAO Forest, p. 91](lib:bees-and-their-role-in-forest-livelihoods#page=91));
  above **60% humidity** it absorbs water ([AH 335, p. 95](lib:beekeeping-in-the-united-states#page=95)). Sealed,
  it stays good for years (FAO, p. 91).
- **Cool:** below **50 °F** stops fermentation; it granulates fastest at **55–60 °F**; warmth darkens it
  ([AH 335, p. 97](lib:beekeeping-in-the-united-states#page=97)). A root cellar works *(rule of thumb)*.
- **Under 17% water it won't ferment in a year; over 19% it will** ([p. 95](lib:beekeeping-in-the-united-states#page=95)).
  Dry wet honey with moving air over a shallow pan, **never by heating** ([Practical Action, p. 4](lib:honey-processing-practical-action#page=4)).
- **Granulated (solid) honey is fine** ([p. 3](lib:honey-processing-practical-action#page=3)). To liquefy, set
  the jar in hot water at about **140 °F for 30 minutes** — never on a flame ([AH 335, p. 94](lib:beekeeping-in-the-united-states#page=94)).
- **Fermenting honey** foams and smells of wine; **150 °F** stops it ([AH 335, p. 95](lib:beekeeping-in-the-united-states#page=95)),
  or make it into mead or vinegar ([FAO Forest, p. 90](lib:bees-and-their-role-in-forest-livelihoods#page=90)).
- Cooking with honey: the [Food From Scratch guide](guide:FOOD-FROM-SCRATCH-GUIDE). Honey as a burn dressing:
  "Burns" in the [Field Care guide](guide:FIELD-CARE-GUIDE).

## 🕯️ Beeswax: rendering and uses

Bees eat about **8 kg of honey to make 1 kg of wax** ([FAO Forest, p. 106](lib:bees-and-their-role-in-forest-livelihoods#page=106)),
so **30 lb** of top-bar honey comes with about **3 lb** of wax *(arithmetic, from the 10 : 1 ratio on
[p. 107](lib:bees-and-their-role-in-forest-livelihoods#page=107))*. Cappings give the best wax.

**Rules** ([FAO Forest, p. 111](lib:bees-and-their-role-in-forest-livelihoods#page=111)):
- **Never heat wax with a direct flame — always in or over water.** It melts at **62–64 °C (144–147 °F)**,
  darkens above **85 °C (185 °F)**, and boiling ruins it.
- **Soft rainwater** — hard water turns wax soapy. **Pots:** enamel, stainless or plastic; **no aluminium,
  copper, brass, zinc, tin or iron.**
- **Never throw water on burning wax** — it spreads the fire ([Practical Action, p. 3](lib:practical-action-candlemaking-technical-brief#page=3);
  [🖼️ double boiler](lib:practical-action-candlemaking-technical-brief#page=3)).

**Rendering step by step** ([FAO Forest, p. 112](lib:bees-and-their-role-in-forest-livelihoods#page=112)):
1. Soak the drained comb in warm water to wash out honey and pollen, three times.
2. Break it up, cover with clean water, and heat gently, stirring — **wax is highly flammable**.
3. Pour into a sack or coarse cloth bag and squeeze it between two sticks into a bucket.
4. Cool it **slowly** (bucket in a box of sawdust): the wax floats and sets in a cake. Scrape the dirt off below.
5. Melt again in an equal volume of water, strain through finer cotton into a lightly soaped bowl, and leave it
   **12 hours**. Store blocks away from strong smells; wax moths don't eat solid blocks ([p. 111](lib:bees-and-their-role-in-forest-livelihoods#page=111)).

**In fire season, use the sun.** A **solar melter** — black, insulated box, double-glass lid, sloping metal sheet
running into a pan — needs only **68–70 °C** and works best tilted about **40°** to the sun
([FAO Forest, pp. 112–113](lib:bees-and-their-role-in-forest-livelihoods#page=112)). Old black brood comb won't
give up wax in the sun: soak it a day, tie it in a sack and boil it in water ([p. 113](lib:bees-and-their-role-in-forest-livelihoods#page=113)).
The black leftover ("slum gum") makes fire starters; burn it after dark so it doesn't draw bees
([p. 114](lib:bees-and-their-role-in-forest-livelihoods#page=114)).

**Uses:** candles need a **thicker wick** in beeswax than in tallow ([Practical Action, p. 2](lib:practical-action-candlemaking-technical-brief#page=2)) —
see the [Lighting guide](guide:LIGHTING-GUIDE) for wicks, dipping and moulds. **Salve:** **1 cup of wax to 3 cups
of oil**, melted in a pot floating in water ([FAO Forest, p. 129](lib:bees-and-their-role-in-forest-livelihoods#page=129)).
Also cheese coating (the [Milk, Butter & Cheese guide](guide:DAIRY-GUIDE)), foundation sheets ([p. 114](lib:bees-and-their-role-in-forest-livelihoods#page=114)),
and waterproofing thread *(rule of thumb)*. Pure wax doesn't stick to your teeth when chewed; paraffin-cut wax
feels greasy ([p. 108](lib:bees-and-their-role-in-forest-livelihoods#page=108)).

## 🐻 Bears and fire season

**[Black bears](wiki:American_black_bear)** come mainly for the **brood**, and come back once they've had it
([UF ENY-2060, p. 1](lib:building-bear-fences#page=1)). Oregon has **25,000–30,000** of them, and ODFW says to
electric-fence beehives ([ODFW, pp. 1–2](lib:living-with-black-bears-odfw#page=1)).

**Building the bear fence** ([UF ENY-2060, pp. 1–5](lib:building-bear-fences#page=1)):
1. **Heavy T-posts every 8 ft**, **1½ ft** into the ground. **No trees as posts** — bears climb them and drop in.
   Fence **at least 3 ft from the hives**, clear of anything a bear could climb.
2. **Three wires at 8, 20 and 32 inches**, 12- or 14-gauge high-tensile, on insulators
   ([🖼️ step photos](lib:building-bear-fences#page=3)); a gate of spring handles ([🖼️ p. 4](lib:building-bear-fences#page=4)).
3. **Charger inside the fence**, solar panel facing south; a **6-ft ground rod**.
4. Test for **6,000–8,000 volts** ([🖼️ finished fence](lib:building-bear-fences#page=5)). BearWise asks at least
   **6,000 V and 0.5 joules**, and says lights and noisemakers don't work for long
   ([ODFW BearWise, pp. 1–2](lib:raising-chickens-in-bear-country-odfw#page=2)).
5. **Cut plants back 2–3 ft** — anything touching the wire drains it ([UF ENY-2060, p. 5](lib:building-bear-fences#page=5)).
6. Bait the wire with foil smeared with bacon grease so a bear's nose gets the first shock *(rule of thumb)*.

![An electric bear fence: from the side, three hot wires at 8, 20 and 32 inches on T-posts 8 ft apart and 1½ ft deep; from above, hives at least 3 ft inside the wire, the charger inside, a gate on spring handles, and plants cut back 2–3 ft](img:BEES-GUIDE/bear-fence.svg)
*The fence in the list above, from the side and from above (a diagram drawn for this guide).*

With no working charger: "bear platforms" (hives on a strong raised stand) have also worked
([AH 335, p. 132](lib:beekeeping-in-the-united-states#page=132)), and hives close to where people live are safer
([FAO 2006, p. 33](lib:honey-bee-diseases-and-pests#page=33)). For bears and cougars, see the
[Home Defense guide](guide:HOME-DEFENSE-GUIDE).

**Fire season (June–October): a smoker is a fire.** Beekeepers' torches have started forest fires
([FAO Forest, pp. 42, 56](lib:bees-and-their-role-in-forest-livelihoods#page=42)). Light it on bare ground, carry
water, snuff it in a lidded can, never knock embers into dry grass, and keep brush cut round the apiary
*(rule of thumb)*. To evacuate hives, close the entrances at dusk with screen and move them **at least 2 km
(1¼ miles)**, or foragers fly back to the old spot ([FAO Forest, p. 76](lib:bees-and-their-role-in-forest-livelihoods#page=76)).
See the [Wildfire guide](guide:WILDFIRE-GUIDE).

## 🩹 Stings and allergic reactions

**Avoiding them:** work gently on warm days when foragers are out; smoke first; never stand in the flight path;
no perfume or strong soap; don't crush bees ([FAO Forest, p. 48](lib:bees-and-their-role-in-forest-livelihoods#page=48)).
If a colony turns hot, close it and stop for the day ([OSU EM 9186, p. 8](lib:osu-residential-beekeeping-best-practices-em-9186#page=8)).
Bees are touchiest in a dearth, guarding big stores, or getting ready to swarm
([FAO Forest, p. 49](lib:bees-and-their-role-in-forest-livelihoods#page=49)), and when queenless
([OSU EM 9186, p. 11](lib:osu-residential-beekeeping-best-practices-em-9186#page=11)). Many "bee stings" are
yellowjackets ([AH 335, p. 149](lib:beekeeping-in-the-united-states#page=149)).

**A normal sting:** pain, redness and swelling — sometimes big, peaking in **24–48 hours**
([OSU EM 9186, p. 8](lib:osu-residential-beekeeping-best-practices-em-9186#page=8)). **Scrape the stinger out at
once** with a fingernail or knife edge; pinching squeezes in more venom ([AH 335, p. 147](lib:beekeeping-in-the-united-states#page=147)).
A cold cloth helps ([FAO Forest, p. 49](lib:bees-and-their-role-in-forest-livelihoods#page=49)).

**A whole-body reaction** ([anaphylaxis](wiki:Anaphylaxis)) follows **0.3–7.5%** of stings
([OSU EM 9186, p. 4](lib:osu-residential-beekeeping-best-practices-em-9186#page=4)): hives over the body, throat
swelling, wheezing, vomiting, faintness, collapse — usually within minutes, sometimes up to 24 hours later
([AH 335, p. 148](lib:beekeeping-in-the-united-states#page=148)). About **2%** of people grow more sensitive with
each sting (same page).
- **Give epinephrine (adrenaline) into the thigh muscle:** adults 50 kg+ **0.5 mg** (0.5 mL of 1:1000), repeated
  every 5 minutes as needed; children **0.15 mg**
  ([WHO, p. 235](lib:who-icrc-basic-emergency-care-approach-to-the-acutely-ill-and-injured-who-2018#page=235)).
- Lay a collapsed person on their side, airway clear, kept warm ([FAO Forest, p. 49](lib:bees-and-their-role-in-forest-livelihoods#page=49)).
  See the [Field Care guide](guide:FIELD-CARE-GUIDE) and the [Medical shelf](guide:Medical-READ-ME-FIRST).
- After one such reaction, keep that person away from the hives *(rule of thumb)*.

## 🍎 Pollination for the garden and orchard

- Apples, pears, plums, cherries, berries, squash, cucumbers and melons need or gain from insect pollination
  ([AH 335, p. 123](lib:beekeeping-in-the-united-states#page=123)). Many apples won't set with their own pollen:
  plant **two varieties** that bloom together ([p. 114](lib:beekeeping-in-the-united-states#page=114)).
- Well-pollinated fruit is bigger and better shaped: an apple fills all its seeds only after several bee visits;
  a full strawberry needs about **21** ([FAO Forest, p. 75](lib:bees-and-their-role-in-forest-livelihoods#page=75)).
  Misshapen fruit, half-filled pods and gappy seed heads at harvest mean too few bees ([p. 77](lib:bees-and-their-role-in-forest-livelihoods#page=77)).
- **Squash** has separate male and female flowers and must have pollinators; **one hive per acre** is usually
  enough, set out when **5–10%** of plants flower ([McCormack, p. 8](lib:cucurbit-seed-production#page=8);
  [🖼️ squash flowers](lib:beekeeping-in-the-united-states#page=119)).
- **Field figures:** **½ to 5 colonies per acre** ([AH 335, p. 80](lib:beekeeping-in-the-united-states#page=80));
  per hectare (2½ acres): apple 4, pear 4, peach 2, strawberry 8, blackberry 7, cucumber and melon 7, squash 4
  ([FAO Forest, p. 78](lib:bees-and-their-role-in-forest-livelihoods#page=78)). For a family garden and orchard,
  **one or two hives within a mile** do the job *(rule of thumb)*.
- **Seed saving:** bee-pollinated varieties need **½ mile** between them for pure seed; honey bees stick to one
  crop at a time ([McCormack, p. 5](lib:isolation-distances-for-seed-crops#page=5)). See the
  [Seed Bank guide](guide:SEED-BANK-GUIDE).
- **Native bees help:** bumblebees, squash bees and [mason bees](wiki:Osmia_lignaria). Mason bees nest in **7–8 mm**
  holes or bamboo tubes ([FAO Forest, pp. 79–80](lib:bees-and-their-role-in-forest-livelihoods#page=79)); hang
  drilled blocks under the eaves facing morning sun *(rule of thumb)*.

## 🧮 How many hives for a family's sweetener

**Need:** BYU's one-year list allows **70 lb of sugar or honey per adult** ([BYU, p. 1](lib:longer-term-food-storage#page=1));
the bare emergency ration (15 g a day) is about **12 lb** a year ([Food Security guide](guide:FOOD-SECURITY-GUIDE)).

**Yield:** unmanaged colonies seldom give more than **25–30 lb** of surplus, well-managed ones **100 lb+**
([AH 335, p. 70](lib:beekeeping-in-the-united-states#page=70)); the West averaged **27 lb**
([p. 21](lib:beekeeping-in-the-united-states#page=21)); OSU says one colony "can produce more than 40 pounds"
([OSU EM 9186, p. 1](lib:osu-residential-beekeeping-best-practices-em-9186#page=1)). With no bought sugar or mite
treatments, plan on **about 30 lb per colony** and lose some colonies every winter *(rule of thumb)*.

| Family of 2 adults + 2 children (about 3 adults) | Honey a year | Colonies harvested | Colonies to keep *(about 1 in 3 lost)* |
|---|---|---|---|
| Bare ration (12 lb each) | ~50 lb | 2 | **3–4** |
| Half the BYU amount | ~105 lb | 3–4 | **5–6** |
| Full BYU amount (70 lb each) | ~210 lb | 7 | **9–10** |

*(Arithmetic; the loss rate is a rule of thumb.)* Each 30 lb of top-bar honey also brings about **3 lb of wax**.
Build up from swarms and splits, and don't crowd more than about **10 colonies** in one spot
([FAO Forest, p. 47](lib:bees-and-their-role-in-forest-livelihoods#page=47)). While Oregon law still runs, **5 or
more colonies** must be registered with the Department of Agriculture ([OSU EM 9186, p. 13](lib:osu-residential-beekeeping-best-practices-em-9186#page=13)).

## 🧯 If this goes wrong

| Problem | Likely cause and fix |
|---|---|
| Bees fighting at the entrance in August | Robbing — narrow the entrance ([🖼️ entrance reducer](lib:osu-residential-beekeeping-best-practices-em-9186#page=10)); clean up syrup ([OSU EM 9186, p. 5](lib:osu-residential-beekeeping-best-practices-em-9186#page=5)) |
| A beard of bees at the entrance on warm spring afternoons | Crowded, about to swarm ([AH 335, p. 37](lib:beekeeping-in-the-united-states#page=37)) — add room or split |
| No eggs, cranky bees, cells on the comb faces | Queenless ([OSU EM 9186, p. 11](lib:osu-residential-beekeeping-best-practices-em-9186#page=11)) — give a comb of eggs, or unite |
| Only drone brood, bullet-shaped caps | Unmated queen or laying workers ([Langstroth, p. 53](lib:langstroth-on-the-hive#page=53)) — unite or shake out |
| Spotty brood, sunken greasy caps with holes | Matchstick test for AFB; burn if ropy |
| Bees with crumpled wings crawling out front | Heavy varroa ([FAO 2006, p. 19](lib:honey-bee-diseases-and-pests#page=19)) — count, then break the brood |
| Brown spots on the hive front, crawling bees in spring | Damp hive: dysentery or nosema ([Langstroth, p. 131](lib:langstroth-on-the-hive#page=131); [FAO 2006, p. 15](lib:honey-bee-diseases-and-pests#page=15)) |
| Dead cluster, heads in cells, honey a few inches away | Starved out of reach of stores ([AH 335, p. 73](lib:beekeeping-in-the-united-states#page=73)) |
| Combs full of silk webs and grubs | Wax moth in a weak hive ([AH 335, p. 132](lib:beekeeping-in-the-united-states#page=132)) — combine, shrink the space |
| Honey foaming, smells like wine | Fermenting — too wet ([AH 335, p. 95](lib:beekeeping-in-the-united-states#page=95)) |
| Hive knocked over, combs dragged off | Bear ([UF ENY-2060, p. 1](lib:building-bear-fences#page=1)) — fence before it comes back |

📚 **Go deeper:** [OSU EM 9186](lib:osu-residential-beekeeping-best-practices-em-9186#page=5) — robbing, swarms, water and defensive bees; [USDA AH 335, p. 124](lib:beekeeping-in-the-united-states#page=124) — brood diseases compared.

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Kill colonies over burning sulphur to take the honey ([Langstroth, p. 264](lib:langstroth-on-the-hive#page=264); history in [AH 335, p. 9](lib:beekeeping-in-the-united-states#page=9)) | Take only surplus sealed honey. Kill a colony only for AFB, and the shook swarm can save even those bees |
| Fell the bee tree and stupefy the bees with sulphur or a punk-wood smudge ([Kephart, pp. 367–368](lib:kephart-camping-and-woodcraft-vol-2#page=367)) | Cut out the brood combs, tie them into a hive and bring the colony home |
| Smear tobacco juice on your skin against stings ([Kephart, p. 368](lib:kephart-camping-and-woodcraft-vol-2#page=368)) | Veil, light clothes and smoke; nicotine soaks through skin *(rule of thumb)* |
| Bee drugs: antibiotics and sulfa for foulbrood, fumagillin for nosema ([AH 335, p. 132](lib:beekeeping-in-the-united-states#page=132)) | They don't kill AFB spores, so it returns, and they leave residues ([FAO 2006, p. 12](lib:honey-bee-diseases-and-pests#page=12)). The 1980 handbook has no varroa section — use the HBHC guide |
| Mothballs (paradichlorobenzene, naphthalene) or ethylene dibromide for wax moth ([AH 335, p. 132](lib:beekeeping-in-the-united-states#page=132); [FAO 2006, p. 29](lib:honey-bee-diseases-and-pests#page=29)) | Poisonous to bees and people, and they soak into wax and honey (same page; [FAO Forest, p. 108](lib:bees-and-their-role-in-forest-livelihoods#page=108)). Use cold, 118 °F heat, light and strong colonies |
| Count mites with ether or chloroform in the jar ([FAO 2006, p. 19](lib:honey-bee-diseases-and-pests#page=19)) | Alcohol or soapy water; ether is flammable and dangerous to breathe ([HBHC, p. 12](lib:tools-for-varroa-management#page=12)) |
| Spray livestock amitraz (Taktic) on the bees, or burn it on paper strips ([FAO 2006, pp. 21–22](lib:honey-bee-diseases-and-pests#page=21)) | Don't: it kills eggs and can kill bees (p. 21), and off-label use breeds resistant mites ([HBHC, p. 14](lib:tools-for-varroa-management#page=14)) |
| Line the wax-rendering room with asbestos board ([AH 335, p. 99](lib:beekeeping-in-the-united-states#page=99)) | No asbestos. Render in the sun, or in a separate shed **20 ft** from other buildings (same page); never leave wax on the fire |
| Heat honey to 160 °F, "often recommended" to stop granulation ([AH 335, p. 97](lib:beekeeping-in-the-united-states#page=97), which itself advises against it) | Granulated honey is fine; dry wet honey with moving air ([Practical Action, p. 4](lib:honey-processing-practical-action#page=4)) |
| Spray herbicide under the bear fence ([UF ENY-2060, p. 5](lib:building-bear-fences#page=5)) | Cut by hand: bees drink dew off sprayed plants ([FAO Forest, p. 81](lib:bees-and-their-role-in-forest-livelihoods#page=81)) |

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings and photos in the books on this drive; the other links open the offline
Wikipedia.

- Worker, queen and drone; brood stages — [🖼️ AH 335, p. 36](lib:beekeeping-in-the-united-states#page=36); [🖼️ p. 31](lib:beekeeping-in-the-united-states#page=31); [🖼️ p. 33](lib:beekeeping-in-the-united-states#page=33); [Western honey bee](wiki:Western_honey_bee); [Queen bee](wiki:Queen_bee)
- Poor vs. good brood; healthy vs. sick brood — [🖼️ AH 335, p. 71](lib:beekeeping-in-the-united-states#page=71); [🖼️ p. 77](lib:beekeeping-in-the-united-states#page=77)
- Langstroth plans and cutaway — [🖼️ AH 335, p. 53](lib:beekeeping-in-the-united-states#page=53); [🖼️ p. 54](lib:beekeeping-in-the-united-states#page=54); [Langstroth hive](wiki:Langstroth_hive)
- Top-bar hives, home-made smoker, veil and hive tool — [🖼️ FAO Forest, p. 97](lib:bees-and-their-role-in-forest-livelihoods#page=97); hives from ammunition boxes and home-made bee suits, [🖼️ p. 96](lib:bees-and-their-role-in-forest-livelihoods#page=96); stands in oil, [🖼️ p. 98](lib:bees-and-their-role-in-forest-livelihoods#page=98); [Top-bar hive](wiki:Horizontal_top-bar_hive); [Bee smoker](wiki:Bee_smoker)
- Feeders, water tank, pollen traps, winter hive — [🖼️ AH 335, p. 50](lib:beekeeping-in-the-united-states#page=50); [🖼️ p. 48](lib:beekeeping-in-the-united-states#page=48); [🖼️ p. 73](lib:beekeeping-in-the-united-states#page=73)
- Entrance reducer, bee escape, water with a rock — [🖼️ OSU EM 9186, p. 10](lib:osu-residential-beekeeping-best-practices-em-9186#page=10); [🖼️ p. 9](lib:osu-residential-beekeeping-best-practices-em-9186#page=9); [🖼️ p. 7](lib:osu-residential-beekeeping-best-practices-em-9186#page=7)
- Swarms and hiving one; what makes a colony swarm — [🖼️ OSU EM 9186, p. 4](lib:osu-residential-beekeeping-best-practices-em-9186#page=4); [🖼️ p. 5](lib:osu-residential-beekeeping-best-practices-em-9186#page=5); [🖼️ AH 335, p. 38](lib:beekeeping-in-the-united-states#page=38); reversing boxes, [🖼️ p. 75](lib:beekeeping-in-the-united-states#page=75); [Swarming](wiki:Swarming_(honey_bee))
- Swarm, supersedure and queen-rearing cells; mating nucs — [🖼️ OSU EM 9186, p. 10](lib:osu-residential-beekeeping-best-practices-em-9186#page=10); [🖼️ p. 11](lib:osu-residential-beekeeping-best-practices-em-9186#page=11); [🖼️ AH 335, p. 65](lib:beekeeping-in-the-united-states#page=65)
- Varroa — [🖼️ FAO 2006, p. 19](lib:honey-bee-diseases-and-pests#page=19); [🖼️ p. 20](lib:honey-bee-diseases-and-pests#page=20); [🖼️ HBHC seasons chart, p. 5](lib:tools-for-varroa-management#page=5); [Varroa destructor](wiki:Varroa_destructor)
- American foulbrood and the rope test — [🖼️ FAO 2006, p. 10](lib:honey-bee-diseases-and-pests#page=10); [🖼️ p. 11](lib:honey-bee-diseases-and-pests#page=11); [🖼️ AH 335, p. 126](lib:beekeeping-in-the-united-states#page=126); [🖼️ p. 127](lib:beekeeping-in-the-united-states#page=127); [American foulbrood](wiki:American_foulbrood)
- European foulbrood, chalkbrood, sacbrood — [🖼️ AH 335, p. 128](lib:beekeeping-in-the-united-states#page=128); [🖼️ FAO 2006, p. 13](lib:honey-bee-diseases-and-pests#page=13); [🖼️ AH 335, p. 130](lib:beekeeping-in-the-united-states#page=130); [European foulbrood](wiki:European_foulbrood); [Chalkbrood](wiki:Chalkbrood)
- Wax moth; small hive beetle (watch for it) — [🖼️ AH 335, p. 133](lib:beekeeping-in-the-united-states#page=133); [🖼️ p. 134](lib:beekeeping-in-the-united-states#page=134); [🖼️ FAO 2006, p. 26](lib:honey-bee-diseases-and-pests#page=26); [Galleria mellonella](wiki:Galleria_mellonella); [Small hive beetle](wiki:Small_hive_beetle)
- Bear fence — [🖼️ UF ENY-2060, p. 3](lib:building-bear-fences#page=3); [🖼️ p. 4](lib:building-bear-fences#page=4); [🖼️ p. 5](lib:building-bear-fences#page=5); [Electric fence](wiki:Electric_fence)
- Manzanita in bloom; bee-plant families — [🖼️ NRCS, p. 2](lib:whiteleaf-manzanita-plant-guide#page=2); [🖼️ PNW 550, p. 20](lib:pnw-encouraging-beneficial-insects#page=20); [🖼️ p. 21](lib:pnw-encouraging-beneficial-insects#page=21)
- Squash flowers; hives in an orchard — [🖼️ AH 335, p. 119](lib:beekeeping-in-the-united-states#page=119); [🖼️ p. 121](lib:beekeeping-in-the-united-states#page=121)
- Melting wax safely — [🖼️ Practical Action, p. 3](lib:practical-action-candlemaking-technical-brief#page=3); [Beeswax](wiki:Beeswax)

## 🔗 Related guides

- [Light Without the Grid](guide:LIGHTING-GUIDE) — beeswax candles, wicks and moulds
- [Field Care guide](guide:FIELD-CARE-GUIDE) — anaphylaxis with no help coming; honey on burns
- [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) and [Preserving Food](guide:PRESERVING-FOOD-GUIDE) — cooking with and storing honey
- [Root Cellar guide](guide:ROOT-CELLAR-GUIDE) — cool, steady storage for honey and wax
- [Food Security](guide:FOOD-SECURITY-GUIDE) — how much sweetener a family needs
- [Seed Bank guide](guide:SEED-BANK-GUIDE) — pollination and isolation distances
- [Wildfire guide](guide:WILDFIRE-GUIDE) and [Home Defense guide](guide:HOME-DEFENSE-GUIDE) — fire season; bears and cougars
- [Blacksmithing guide](guide:BLACKSMITHING-GUIDE) — hive tools, smokers, foundation presses
- The [Chickens guide](guide:CHICKENS-GUIDE) — drone brood and wax-moth grubs feed hens; bear fences for coops
- The [Milk, Butter & Cheese guide](guide:DAIRY-GUIDE) — beeswax for coating cheese
