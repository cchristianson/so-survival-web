# 👶 Childbirth, Newborns & Young Children When No Help Is Coming

Getting a mother and baby through pregnancy, birth and the first weeks, and keeping young children
alive and learning, with no hospital, pharmacy or phone. **Current WHO guidance comes first.**
Hesperian's *A Book for Midwives* (2026) and *Where There Is No Doctor* (2025) add detail; where they
differ from WHO, this guide gives the WHO answer. The books are in `Medical\Childbirth-Children`
(`Birth`, `Newborn`, `Mothers`, `Child-Health`), `Medical\A Book for Midwives`,
`Medical\Field-Care\Childbirth-Newborn`, `Medical\Where There Is No Doctor` and
`Southern-Oregon\Children-Learning`.

> ### ⚠️ Rules that prevent the worst outcomes
> - **Bleeding after birth kills fastest.** Every mother gets a bleeding medicine **within 1 minute**
>   of the last baby ([WHO 2025, p. 19](lib:bleeding-after-birth#page=19)), and someone feels her
>   womb every 15 minutes for the first hour ([p. 29](lib:bleeding-after-birth#page=29)).
> - **Never push on the belly, pull the cord, put anything in the vagina, or give drugs to speed
>   labor** ([PCPNC, p. 170](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=170)).
> - **A baby not breathing by 1 minute needs breaths now**, 40 a minute. Stop only after 10 minutes
>   with no heartbeat ([PCPNC, p. 152](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=152)).
> - **Put nothing on the cord stump.** Keep it clean and dry.
> - **Count a sick child's breaths** for a full minute. Fast breathing means pneumonia.
> - **Never make a child vomit**, and never give salt water.

---

## 📋 Plan now, while doctors and pharmacies still exist

**Cheap medicines bought ahead** save mothers and children. Most need a US prescription, so **talk
to a doctor now**:

| Medicine | For | Notes |
|---|---|---|
| [Misoprostol](wiki:Misoprostol) | Preventing and treating bleeding after birth | **No fridge needed**; keep dry ([WHO, p. 19](lib:bleeding-after-birth#page=19)). Can be handed out before a home birth ([BfM, p. 231](lib:a-book-for-midwives-13#page=10)) |
| Oxytocin | Same; WHO's first choice | **Must stay at 36–46 °F (2–8 °C)**; without cold storage use misoprostol (same page) |
| Tranexamic acid (TXA) | Bleeding that won't stop | 1 g into a vein, **only within 3 hours** of birth; needs someone who can start an IV ([WHO, p. 47](lib:bleeding-after-birth#page=47)) |
| Amoxicillin 250 mg | Child pneumonia; infection after a birth emergency | [IMCI, p. 16](lib:imci-chart-booklet#page=16) |
| ORS packets, zinc, mebendazole, vitamin A | Diarrhea, worms, measles | [IMCI, p. 20](lib:imci-chart-booklet#page=20) |
| Vitamin K 1 mg injection | Every newborn | [PCPNC, p. 153](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=153) |

**Vaccines:** bring children up to date on WHO's schedule: hepatitis B within 24 hours of birth;
DTP, polio, Hib, pneumococcal and rotavirus; **two doses of measles vaccine**
([WHO Table 2, Dec 2025](lib:routine-immunizations-for-children#page=1)). A child who fell behind
**resumes without repeating doses** ([Table 3](lib:catch-up-schedule#page=1)). Adults: tetanus
boosters, MMR if never vaccinated, and **Tdap in every pregnancy** *(general practice)*.

**Clean birth kit** ([PCPNC, p. 169](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=169);
[BfM, p. 152](lib:a-book-for-midwives-09#page=7); [🖼️ the kit drawn, WTND p. 254](lib:where-there-is-no-doctor-19#page=10)): soap and a nail brush, gloves (or very clean
plastic bags), a new razor blade, 3 strings 8 in (20 cm) long, a suction bulb ([🖼️ using one, BfM p. 214](lib:a-book-for-midwives-12#page=21)), many clean cloths, a
warm blanket, 3 bowls, plastic for the placenta, clean water and a way to heat it, light, and the
bleeding medicine. Add a **blood-pressure cuff and stethoscope ([🖼️ how to use them, BfM p. 123](lib:a-book-for-midwives-08#page=16)), a newborn bag-and-mask
([Bag valve mask](wiki:Bag_valve_mask)), a digital
thermometer and a hanging scale** *(general practice)*.

**Transport:** there is no 24-hour ER in the Illinois Valley
([Start Here](guide:ILLINOIS-VALLEY-START-HERE)). The nearest delivery hospital is in **Grants Pass,
about 30 miles**, an hour or more once roads or fuel fail *(general knowledge)*. Decide now who
drives or carries her, and save fuel for it.

📚 **Go deeper:** [WHO *Bleeding After Birth*](lib:bleeding-after-birth#page=19) — medicines; [WHO catch-up table](lib:catch-up-schedule#page=1) — missed vaccines; [*A Book for Midwives*, ch. 9](lib:a-book-for-midwives-09#page=7) — supplies.

## 🤰 Pregnancy: checkups and danger signs

- **Due date:** add 9 months and 7 days to the first day of the last monthly bleeding
  ([BfM, p. 88](lib:a-book-for-midwives-07#page=5)).
- **Checkups:** monthly, then weekly in the last month *(general practice)*: blood pressure, urine
  and the womb's height. The top of the womb rises about **2 finger-widths a month**: just above the
  pubic bone at 3 months, the navel at about 5, nearly the ribs by 8½–9. Much faster or slower is a
  warning sign ([BfM, p. 130](lib:a-book-for-midwives-08#page=23); [Fundal height](wiki:Fundal_height)).
- **[Pre-eclampsia](wiki:Pre-eclampsia)** causes fits and death before, during or after birth. Surest
  signs: **blood pressure 140/90 or higher plus protein in the urine**. Also: strong headache,
  spots or blurred vision, steady pain high in the belly, puffy face or hands on waking
  ([BfM, p. 125](lib:a-book-for-midwives-08#page=18)).
- **Urine protein test:** boil the top of a tube of urine. If cloudy, add a few drops of vinegar.
  Still cloudy means protein. Low-dose aspirin (81 mg a day) may prevent pre-eclampsia; ask a doctor
  now ([BfM, p. 127](lib:a-book-for-midwives-08#page=20)).
- **[Breech](wiki:Breech_birth)?** If the hard, round head is at the top of the belly late in pregnancy
  ([MCPC, p. 234](lib:managing-complications-in-pregnancy#page=234); [🖼️ listening for the heartbeat above the navel, WTND p. 252](lib:where-there-is-no-doctor-19#page=8)), WHO wants the birth in a
  hospital ([p. 239](lib:managing-complications-in-pregnancy#page=239)). **Go before labor.**

**Go for help at once, day or night**, for bleeding from the vagina, fits, severe headache with
blurred vision, fever with weakness, severe belly pain, or fast or difficult breathing
([PCPNC, p. 162](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=162)). She eats more,
rests and drinks no alcohol (same page). Smoke harms pregnant women more: in fire season keep her in
a **"cleaner air room"** with a box-fan filter ([EPA](lib:epa-prepare-for-wildfire-smoke#page=1)).

📚 **Go deeper:** [*A Book for Midwives*, ch. 8](lib:a-book-for-midwives-08#page=18) — every prenatal check; [PCPNC counselling sheets](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=162) — birth plans.

## 🛏️ Labor and birth: what helpers do

**Labor has started** with painful contractions every 20 minutes or less, waters breaking, or a
bloody sticky discharge ([PCPNC, p. 162](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=162)).
**During labor** ([WTND, p. 259](lib:where-there-is-no-doctor-19#page=15)):
- The first stage can last **over 20 hours** with a first baby. Don't hurry it.
- She **doesn't push until she feels she must**.
- She urinates and drinks often, eats lightly, walks, and **doesn't lie flat on her back** for long
  ([🖼️ positions for labor, MCPC p. 111](lib:managing-complications-in-pregnancy#page=111); [🖼️ for the birth, p. 123](lib:managing-complications-in-pregnancy#page=123);
  [🖼️ WTND p. 260](lib:where-there-is-no-doctor-19#page=16)).
- Helpers scrub hands, keep nails short and wear gloves.

**Never:** drugs to speed labor (they can kill mother and child —
[WTND, p. 266](lib:where-there-is-no-doctor-19#page=22)), anything in the vagina, **pushing on the
belly** (it can tear the womb — [BfM, p. 205](lib:a-book-for-midwives-12#page=12)), pulling on the cord.

**Leave for Grants Pass now if** waters broke with no labor after 6 hours, contractions last over 12
hours, she soaks over 2–3 pads in 15 minutes, or the placenta isn't out 1 hour after the baby
([PCPNC, p. 170](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=170)).

**Right after the baby is born** ([🖼️ a head-first birth, WTND p. 261](lib:where-there-is-no-doctor-19#page=17); [Childbirth](wiki:Childbirth)):
1. **Dry the baby**, lay it **skin-to-skin on the mother's belly**, and cover it, head too
   ([BfM, p. 240](lib:a-book-for-midwives-13#page=19)).
2. **Feel her belly for a second baby**, then give the **bleeding medicine within 1 minute** —
   **misoprostol 400–600 µg by mouth**, or oxytocin 10 units in the thigh. (The 800 µg dose is for
   treating bleeding, below.) Never before the last baby is out ([WHO, p. 19](lib:bleeding-after-birth#page=19)).
3. **Cut the cord after 1–3 minutes** (same page), once it is white and stops pulsing; waiting
   gives the baby iron. Tie it tightly **2 finger-widths from the belly**, tie a second string
   farther out, and cut between with a new or sterilized blade
   ([BfM, pp. 214–215](lib:a-book-for-midwives-12#page=21); [🖼️ tying and cutting, WTND p. 262](lib:where-there-is-no-doctor-19#page=18);
   [Umbilical cord](wiki:Umbilical_cord)). A baby needing breathing help gets it
   cut at once.
4. **Let the placenta come by itself**, and check it is whole
   ([PCPNC, p. 169](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=169); [Placenta](wiki:Placenta)).
5. **First breastfeed within the hour.** No bath the first day. **Don't leave the mother alone for
   24 hours** (same page).

![The cord coming from the baby's belly: a tight first tie 2 finger-widths from the belly, a second tie farther out, and the cut between them](img:CHILDBIRTH-CHILDREN-GUIDE/tying-and-cutting-the-cord.svg)
*Wait 1–3 minutes, tie twice, cut between the ties (a diagram drawn for this guide).*

**Cord care:** **clean and dry, nothing on it.** Dirt and dung cause tetanus
([WTND, p. 263](lib:where-there-is-no-doctor-19#page=19); [Neonatal tetanus](wiki:Neonatal_tetanus)).
WHO's one exception is **7.1% chlorhexidine** daily for a week, where a health authority recommends
it ([PCPNC, p. 169](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=169)). Fold the diaper
below the stump; it usually falls off within 1–3 weeks (sometimes in 5–7 days).

📚 **Go deeper:** [*A Book for Midwives*, ch. 12](lib:a-book-for-midwives-12#page=21) — the birth in drawings; [PCPNC home delivery](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=169).

## 🩸 Heavy bleeding after birth: the #1 killer

[Bleeding after birth](wiki:Postpartum_bleeding) kills more mothers than anything else *(general
knowledge)*, and **delay** is a common reason they die ([WHO, p. 59](lib:bleeding-after-birth#page=59)).
**A soft womb causes about 70%** of it ([p. 9](lib:bleeding-after-birth#page=9)).

**Feel the womb every 15 minutes for the first hour.** Hard like your forehead is good. Soft like the
tip of your nose **needs rubbing** ([🖼️ how to rub it, BfM p. 224](lib:a-book-for-midwives-13#page=3)). The top should be at or below the navel
([WHO, p. 29](lib:bleeding-after-birth#page=29)). Teach the family to check and rub
([BfM, p. 236](lib:a-book-for-midwives-13#page=15)).

**Dangerous bleeding: measure, don't guess** ([WHO, p. 43](lib:bleeding-after-birth#page=43);
[p. 15](lib:bleeding-after-birth#page=15)):
- **500 mL or more** (about 2 cups), **or**
- **300 mL or more plus a warning sign:** pulse over 100, top blood-pressure number under 100,
  bottom under 60, or **pulse higher than the top number**.
- No cuff? Soaking 2–3 pads in 15 minutes, or faint, pale, sweaty or confused
  ([BfM, p. 239](lib:a-book-for-midwives-13#page=18)). A **slow steady trickle** is as dangerous as a
  gush ([p. 226](lib:a-book-for-midwives-13#page=5)).
- Mark 250 and 500 mL lines on the basin that will catch blood *(rule of thumb)*.

**Then do ALL of these within 15 minutes, in any order** (WHO "MOTIVE",
[p. 47](lib:bleeding-after-birth#page=47)):

| Step | What to do |
|---|---|
| **M**assage | Cupped hand on top of the womb; rub in circles until hard. Alone? Massage first |
| **O**xytocic | **Misoprostol 800 µg under the tongue**, or oxytocin 10 units in the thigh. Nauseous? Pills go in the rectum ([BfM, p. 231](lib:a-book-for-midwives-13#page=10)) |
| **T**XA | 1 g into a vein over 10 minutes, if someone trained and under 3 hours |
| **IV** fluids | If you can; if not, sips of rehydration drink while awake ([BfM, p. 239](lib:a-book-for-midwives-13#page=18)) |
| **E**xamine | Baby to the breast; help her urinate; placenta whole? torn and bleeding? ([BfM, p. 236](lib:a-book-for-midwives-13#page=15)) |
| **E**scalate | Head for Grants Pass if bleeding stays heavy or passes 1,000 mL ([WHO, p. 57](lib:bleeding-after-birth#page=57)) |

**Still bleeding?**
1. **Squeeze the womb between two hands:** a gloved fist in the vagina above the cervix, the other
   hand pressing the womb down onto it ([BfM, p. 237](lib:a-book-for-midwives-13#page=16); [🖼️ WHO drawing, MCPC p. 178](lib:managing-complications-in-pregnancy#page=178)). Hold **at
   least 5 minutes**; it hurts, so tell her. **Don't wait for shock**, and don't pack the vagina
   ([WHO, p. 73](lib:bleeding-after-birth#page=73)).
2. Or **press a fist hard on the belly just above the navel** until the pulse in her thigh
   disappears, and keep pressing ([BfM, p. 238](lib:a-book-for-midwives-13#page=17); [🖼️ WHO drawing, MCPC p. 179](lib:managing-complications-in-pregnancy#page=179)).
3. **Shock:** feet up, keep her warm, sips if awake, **nothing by mouth if unconscious**
   ([BfM, p. 239](lib:a-book-for-midwives-13#page=18)).
4. Help more than 1 hour away? **Amoxicillin 1 g plus metronidazole 1 g by mouth, once**
   ([BfM, p. 231](lib:a-book-for-midwives-13#page=10)).

![Squeezing the womb between two hands, side view: a gloved fist inside the vagina pushes up against the womb while the other hand presses it down from outside](img:CHILDBIRTH-CHILDREN-GUIDE/bimanual-compression.png)
*Step 1: squeeze the womb between the fist inside and the hand outside, for at least 5 minutes ([MCPC, p. 178](lib:managing-complications-in-pregnancy#page=178)).*

![A fist pressing hard on the belly just above the navel while the other hand feels for the pulse in the thigh](img:CHILDBIRTH-CHILDREN-GUIDE/aortic-compression.png)
*Step 2: press until the pulse in her thigh disappears, and keep pressing ([MCPC, p. 179](lib:managing-complications-in-pregnancy#page=179)).*

📚 **Go deeper:** [WHO action plans](lib:bleeding-after-birth#page=47) — the bundle and shock; [*A Book for Midwives*, ch. 13](lib:a-book-for-midwives-13#page=15) — the family's part.

## 🔄 Stuck shoulders and breech

**[Stuck shoulders](wiki:Shoulder_dystocia):** the head is born, pulls back like a turtle, and the
shoulders won't come. The baby has **about 5 minutes** before brain damage
([BfM, p. 210](lib:a-book-for-midwives-12#page=17)). Call every helper. WHO's order
([MCPC, pp. 243–244](lib:managing-complications-in-pregnancy#page=243)):
1. **Knees to chest:** two helpers push her bent knees firmly up to her chest ([🖼️ MCPC p. 244](lib:managing-complications-in-pregnancy#page=244)).
2. **Press hard just above the pubic bone, not on the belly**, while you draw the head steadily
   downward. Cup the head; don't grip the neck; never jerk.
3. **Hand inside** along the baby's back: push a shoulder toward the baby's chest to turn it.
4. **Bring the back arm out**, swept across the chest.

Hesperian tries **hands-and-knees first** ([BfM, p. 211](lib:a-book-for-midwives-12#page=18)); use it
if WHO's steps fail. **Never push on top of the womb**: it can burst. Be ready to help the baby
breathe.

**[Breech](wiki:Breech_birth) (bottom first)** with no hospital
([BfM, pp. 215–217](lib:a-book-for-midwives-12#page=22)): **feet first** is the most dangerous kind.
No pushing until the cervix is fully open. **Hands off**: the bottom, belly and legs come on their
own, and **you never pull on the baby**. Wrap the body so it doesn't chill and gasp inside her. A
helper presses above the pubic bone to keep the head tucked. Hold the baby by the hips, never the
belly ([p. 217](lib:a-book-for-midwives-12#page=24); [🖼️ "hold the baby at the hips, but do not pull," MCPC p. 378](lib:managing-complications-in-pregnancy#page=378)).

![A breech baby coming bottom first, seen from below: the helper's two hands hold the baby by the hips](img:CHILDBIRTH-CHILDREN-GUIDE/breech-hold-at-hips.png)
*Hold the baby at the hips, never the belly, and don't pull ([MCPC, p. 378](lib:managing-complications-in-pregnancy#page=378)).*

📚 **Go deeper:** [*A Book for Midwives*, ch. 12](lib:a-book-for-midwives-12#page=17) — each move drawn; [WHO *Managing Complications*](lib:managing-complications-in-pregnancy#page=239) — hard births.

## 🫁 A baby who isn't breathing

Most babies breathe within 1–2 minutes, and drying is often enough. **Never hold a baby upside down
or slap it** ([BfM, p. 241](lib:a-book-for-midwives-13#page=20)). WHO's steps
([PCPNC, p. 152](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=152);
[Neonatal resuscitation](wiki:Neonatal_resuscitation)):

1. **Dry and rub the back.** Not breathing, or only gasping? **Start within 1 minute of birth.** Cut
   the cord; move the baby to a warm, dry, flat place.
2. **Open the airway:** head slightly tipped back, a folded towel **no thicker than ¾ in (2 cm)**
   under the shoulders ([🖼️ MCPC p. 311](lib:managing-complications-in-pregnancy#page=311)). Suction **only** if the mouth or nose is full.
3. **Breathe for the baby:** mask over chin, mouth and nose ([🖼️ fitting the mask, MCPC p. 313](lib:managing-complications-in-pregnancy#page=313)). Give 5 squeezes and watch the chest
   rise; if it doesn't, fix the head and seal. Then **40 breaths a minute** (one every 1½ seconds).
4. **No bag?** Your mouth over the baby's mouth and nose: **small puffs from your cheeks only**
   ([BfM, p. 242](lib:a-book-for-midwives-13#page=21)).
5. **After 1 minute, check the heart** with a stethoscope or 2 fingers on the chest. Count 6
   seconds, times 10 ([BfM, p. 243](lib:a-book-for-midwives-13#page=22)).
6. **Stop** when the baby breathes over 30 times a minute without deep chest sucking-in. Skin-to-skin,
   check every 15 minutes.
7. **No heartbeat (or under 60) after 10 minutes of good breaths: the baby has died.** Stop and care
   for the family.

![A newborn lying on its back with the head tipped back slightly to open the airway](img:CHILDBIRTH-CHILDREN-GUIDE/newborn-head-position.png)
*Head only slightly tipped back: a newborn's neck is bent back less than an adult's ([MCPC, p. 311](lib:managing-complications-in-pregnancy#page=311)).*

![Four baby faces with a breathing mask: the right size covering chin, mouth and nose; wrong when held too low, too small, or too large](img:CHILDBIRTH-CHILDREN-GUIDE/newborn-mask-fit.png)
*The mask covers the chin, mouth and nose, but not the eyes ([MCPC, p. 313](lib:managing-complications-in-pregnancy#page=313)).*

Alone with a bleeding mother? Baby first, then her medicine and womb check as soon as you can
([WHO, p. 17](lib:bleeding-after-birth#page=17)).

📚 **Go deeper:** [PCPNC resuscitation chart](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=152); [*A Book for Midwives*, p. 242](lib:a-book-for-midwives-13#page=21) — rescue breathing drawn.

## 🌡️ Warmth, small babies and newborn danger signs

**Warmth:** skin-to-skin, head covered, out of drafts. A baby needs **only one more layer than an
adult** ([BfM, p. 240](lib:a-book-for-midwives-13#page=19)). Watch for overheating in valley
summers over 100 °F, and chilling November–March *(general knowledge)*.

**[Kangaroo care](wiki:Kangaroo_care)** for babies under 2,500 g (5½ lb) or born 3+ weeks early
([WHO KMC, p. 10](lib:kangaroo-mother-care#page=10)):
- Skin-to-skin as close to **24 hours a day** as possible, **at least 8**, an hour or more at a time,
  breastfeeding **every 2–3 hours** ([p. 20](lib:kangaroo-mother-care#page=20)).
- Baby **upright between the breasts**, head to one side, hips spread; a cloth wrap tied high
  across the chest, its top **just below the baby's ear** ([p. 32](lib:kangaroo-mother-care#page=32);
  [🖼️ IYCF p. 84](lib:infant-and-young-child-feeding-model-chapter#page=84)).
- Room at **77–82 °F (25–28 °C)** ([PCPNC, p. 140](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=140)).
  Continue to about 2,500 g, or until the baby wriggles out ([KMC, p. 40](lib:kangaroo-mother-care#page=40)).

![Kangaroo care: a small baby in a diaper and hat lying upright on the mother's bare chest between her breasts, head turned to one side, legs bent and spread](img:CHILDBIRTH-CHILDREN-GUIDE/kangaroo-care-position.png)
*Upright, skin to skin between the breasts, head to one side, hips spread; then wrap the cloth high across her chest ([WHO KMC guide, p. 31](lib:kangaroo-mother-care#page=31)).*

**Newborn danger signs: treat as an emergency**
([*Caring for the Newborn at Home*, p. 71](lib:caring-for-the-newborn-at-home#page=71)):
- not feeding, or stopped feeding well; fits
- **60 or more breaths a minute** (count twice, baby calm); chest sucking in
- **99.5 °F (37.5 °C) or more, or 95.7 °F (35.4 °C) or less** (digital thermometer in the armpit —
  [p. 78](lib:caring-for-the-newborn-at-home#page=78))
- yellow soles; moves only when touched, or not at all
- red or pus-draining navel ([Omphalitis](wiki:Omphalitis_of_newborn)), boils, or pus from the eyes
  ([Neonatal conjunctivitis](wiki:Neonatal_conjunctivitis))

Newborn antibiotic doses: [BfM, p. 279](lib:a-book-for-midwives-15#page=12).

**[Jaundice](wiki:Neonatal_jaundice)** ([IMCI, p. 46](lib:imci-chart-booklet#page=46)):
- Yellow **on the first day**, or **yellow palms and soles at any age**, is **severe**. It needs
  hospital light treatment; there is no home cure. Press the soles with your thumbs and look **in
  daylight** ([*Caring for the Newborn*, p. 81](lib:caring-for-the-newborn-at-home#page=81)).
- Yellow after day 1 with palms and soles clear: **breastfeed often**, check daily. Yellow past 14
  days needs a check.
- **No direct sun.** WTND's bright window light is harmless if the baby doesn't chill or overheat,
  but don't count on it ([WTND, p. 274](lib:where-there-is-no-doctor-19#page=30)).

📚 **Go deeper:** [WHO *Caring for the Newborn at Home*](lib:caring-for-the-newborn-at-home#page=71) — checking each sign; [WHO KMC guide](lib:kangaroo-mother-care#page=32) — pictures.

## 🤱 Breastfeeding and the mother's recovery

**[Breast milk](wiki:Breastfeeding) only for 6 months.** **Unmodified animal milk is not suitable under 6 months**; it can
damage the kidneys ([WHO IYCF, p. 18](lib:infant-and-young-child-feeding-model-chapter#page=18)). A
baby who can't suckle is **fed by cup, not bottle** ([p. 81](lib:infant-and-young-child-feeding-model-chapter#page=81);
[🖼️ cup feeding, p. 86](lib:infant-and-young-child-feeding-model-chapter#page=86)).
No breast milk? See the [Food Security guide](guide:FOOD-SECURITY-GUIDE) for wet-nurses, relactation
and formula.

**Enough milk?** After day 5: 8–12 feeds a day with visible swallowing, **pale urine at least 6
times a day**, yellow stools 3+ times a day until 6 weeks, birth weight back **by 2 weeks**, then
**5–7 oz (150–200 g) a week**. **Few wet diapers or dark urine** is a reliable warning
([IYCF, pp. 135–136](lib:infant-and-young-child-feeding-model-chapter#page=135)).

**Breast problems** ([🖼️ good and poor attachment, IYCF p. 42](lib:infant-and-young-child-feeding-model-chapter#page=42)):
- **Overfull, hard breasts** ([Breast engorgement](wiki:Breast_engorgement)): get the milk out by feeding or hand-expressing
  ([🖼️ IYCF p. 155](lib:infant-and-young-child-feeding-model-chapter#page=155); [🖼️ WTND p. 277](lib:where-there-is-no-doctor-19#page=33)); warmth before, cool
  cloths after ([IYCF, p. 140](lib:infant-and-young-child-feeding-model-chapter#page=140)).
- **[Mastitis](wiki:Mastitis)** (fever, red painful breast): **keep breastfeeding**, good side first.
  She rests; the family does her work. Antibiotics only if not better after 24 hours of good draining
  ([p. 142](lib:infant-and-young-child-feeding-model-chapter#page=142); doses
  [BfM, p. 289](lib:a-book-for-midwives-16#page=10)).

![Two side views of a breastfeeding baby: well attached, with the mouth wide, lower lip turned out and chin on the breast; poorly attached, sucking on little more than the nipple with much of the dark skin showing](img:CHILDBIRTH-CHILDREN-GUIDE/good-and-poor-attachment.png)
*Well attached: mouth wide open, lower lip turned out, chin touching the breast, more of the dark skin showing above the mouth than below ([IYCF, p. 42](lib:infant-and-young-child-feeding-model-chapter#page=42)).*

**Womb infection** (fever 100.4 °F / 38 °C or more, bad-smelling discharge, chills, belly pain, fast
pulse) can kill quickly. Antibiotic plan: [BfM, p. 271](lib:a-book-for-midwives-15#page=4). Check
mother and baby **within 24 hours, on day 3, on days 7–14 and at 6 weeks**
([PCPNC, p. 170](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=170)).

**[Depression after birth](wiki:Postpartum_depression)** hits 1 in 10 to 1 in 5 mothers, and her baby
grows worse too ([*Thinking Healthy*, p. 11](lib:thinking-healthy#page=11)):
- Sadness or worry that is very strong, or lasts **over 2 weeks**, is depression. The family takes
  over chores, lets her sleep, sees she eats and moves a little each day
  ([BfM, p. 274](lib:a-book-for-midwives-15#page=7)).
- **Thinking Healthy** lets a trusted neighbor run home sessions in **3 steps**: spot unhelpful
  thoughts, swap in healthier ones, practice healthy actions ([p. 15](lib:thinking-healthy#page=15)).
- **Ask her directly about suicide and whether she has a plan.** Asking doesn't make it more likely.
  A woman with a plan needs help now and must not be left alone
  ([*Where Women Have No Doctor*, p. 431](lib:where-women-have-no-doctor-27#page=20)).

📚 **Go deeper:** [WHO *Infant Feeding* (2025)](lib:infant-and-young-child-feeding-model-chapter#page=135) — breastfeeding problems; [*Thinking Healthy*](lib:thinking-healthy#page=15) — the sessions.

## 🤒 Sick children under 5: fever, breathing, diarrhea, measles, worms

**Danger signs: act now** — can't drink or breastfeed, vomits everything, has had fits, very sleepy
or can't be woken ([IMCI, p. 5](lib:imci-chart-booklet#page=5)), or fever with a **stiff neck**
([p. 8](lib:imci-chart-booklet#page=8)).

**Fever** is a sign: look for the cause. Give plenty to drink, boiled water for babies
([WTND, p. 76](lib:where-there-is-no-doctor-10#page=2)). Paracetamol (acetaminophen) every 6 hours for
high fever: one 100 mg tablet at 2 months–3 years, 1½ at 3–5 years — with 500 mg tablets, **¼** and
**½** ([IMCI, p. 17](lib:imci-chart-booklet#page=17)). **No aspirin for children.**

**Pneumonia: count breaths for a full minute, child calm**
([IMCI, pp. 6, 45](lib:imci-chart-booklet#page=6)):

| Age | Fast breathing |
|---|---|
| Under 2 months | 60 or more |
| 2–12 months | 50 or more |
| 1–5 years | 40 or more |

Fast breathing or **chest sucking in** means [pneumonia](wiki:Pneumonia): **amoxicillin 250 mg twice a day for 5
days** — 1 tablet at 2–12 months, 2 at 1–3 years, 3 at 3–5 years (syrup 250 mg/5 ml: 5, 10 or
15 ml) ([p. 16](lib:imci-chart-booklet#page=16)).

**Diarrhea.** Severe dehydration is **two or more** of: very sleepy or unconscious, sunken eyes,
drinks poorly or not at all, a pinch of belly skin taking **over 2 seconds** to flatten
([IMCI, p. 7](lib:imci-chart-booklet#page=7); [🖼️ the pinch, WTND p. 151](lib:where-there-is-no-doctor-13#page=1); [Dehydration](wiki:Dehydration)).
- **Keep breastfeeding and feeding**, plus **zinc 10–20 mg a day for 10–14 days**
  ([WHO, p. 14](lib:treatment-of-diarrhoea#page=14)).
- After each loose stool, by spoon: under 2 years, 50–100 mL (¼–½ cup); ages 2–10, 100–200 mL (same
  page).
- **ORS packets are best.** Home mix: 1 liter clean water, **½ level teaspoon salt**, 6 level
  teaspoons sugar ([JTS, p. 7](lib:burn-wound-management#page=7)), **no saltier than tears**
  ([Oral rehydration](wiki:Oral_rehydration_therapy)).
- Blood in the stool needs an antibiotic ([IMCI, p. 7](lib:imci-chart-booklet#page=7)).

**[Measles](wiki:Measles)** starts like a cold with red eyes; days later a rash spreads from behind
the ears downward ([WTND, p. 311](lib:where-there-is-no-doctor-21#page=17)). Give **vitamin A**:
100,000 IU at 6–12 months, 200,000 IU from 1 year ([IMCI, p. 20](lib:imci-chart-booklet#page=20)).
Clouded eyes or deep mouth sores mean **severe** measles ([p. 8](lib:imci-chart-booklet#page=8)).

**Worms:** [pinworm](wiki:Pinworm_infection) itches at night. Cut nails short, wash hands and bottoms every morning, **treat
the whole family** ([WTND, p. 141](lib:where-there-is-no-doctor-12#page=11)). [Hookworm](wiki:Hookworm_infection) enters bare
feet ([🖼️ how it spreads, WTND p. 142](lib:where-there-is-no-doctor-12#page=12)): latrines and shoes ([p. 142](lib:where-there-is-no-doctor-12#page=12)). Mebendazole 500 mg once,
from age 1, at most every 6 months ([IMCI, p. 20](lib:imci-chart-booklet#page=20)). Untreated creek
water brings [giardia](wiki:Giardiasis) and weeks of diarrhea *(general knowledge)*.

📚 **Go deeper:** [WHO IMCI charts](lib:imci-chart-booklet#page=5) — every decision and dose; [WHO *Treatment of Diarrhoea*](lib:treatment-of-diarrhoea#page=14) — plans A, B, C.

## 📏 Growth, malnutrition and toddler food

**Weigh monthly and plot it** on the WHO-standard charts in pounds and inches
([boys](lib:growth-chart-boys); [girls](lib:growth-chart-girls); [Growth chart](wiki:Growth_chart)).
A homemade beam scale works ([WTND, p. 297](lib:where-there-is-no-doctor-21#page=3); [Steelyard balance](wiki:Steelyard_balance)). A baby whose
weight **drops across 2 lines** is not growing well
([IYCF, p. 136](lib:infant-and-young-child-feeding-model-chapter#page=136)).

**Arm measurement (MUAC)**, 6 months–5 years, around the middle of the upper arm
([IMCI, p. 10](lib:imci-chart-booklet#page=10); [MUAC](wiki:Anthropometry_of_the_upper_arm)):
**under 11.5 cm, or swelling of both feet ([Kwashiorkor](wiki:Kwashiorkor)), is severe** malnutrition; 11.5–12.5 cm is moderate; 12.5
cm or more is OK. Mark a paper strip at 11.5 and 12.5 cm *(rule of thumb)*. Refeeding a severely
malnourished child needs care: [WHO 1999](lib:management-of-severe-malnutrition-manual) and the
[Food Security guide](guide:FOOD-SECURITY-GUIDE).

**Toddler food and water** ([WHO, p. 38](lib:complementary-feeding-family-foods#page=38);
[p. 46](lib:complementary-feeding-family-foods#page=46); [🖼️ "five keys to safer food," IYCF p. 56](lib:infant-and-young-child-feeding-model-chapter#page=56)):
- **Boil water**, and boil milk that isn't pasteurized (goat milk too).
- Eat cooked food **within 2 hours**, or reheat it until it is all boiling hot.
- Feed by **cup or spoon, never a bottle**. Wash hands with soap. Keep animals out of the house.

📚 **Go deeper:** [WHO *Complementary Feeding*](lib:complementary-feeding-family-foods#page=46) — first foods; [WTND, ch. 21](lib:where-there-is-no-doctor-21#page=3) — growth charts.

## 🛡️ Accidents: drowning, burns, poisoning

> 📷 **A child ate a plant, berry or mushroom?** Keep a piece (and any vomit) and photograph the plant: the [plant and mushroom identifier](guide:PLANT-ID) may name it for whoever is helping. Don't wait for it to act.

**Drowning:** a small child **can drown in a few centimeters of water in a bucket**
([WHO, p. 78](lib:world-report-on-child-injury#page=78)). Empty buckets and tubs; cover wells,
cisterns and barrels ([p. 86](lib:world-report-on-child-injury#page=86)). Here that means rain
barrels ([Rain barrel](wiki:Rainwater_tank)), stock tanks, ditches, and the cold, deep pools of the Illinois and Rogue rivers *(general
knowledge)*.

**[Burns](wiki:Burn):** keep babies away from fires and wood stoves; turn pan handles inward. Cool a burn in clean
cool water (**not ice**) up to 20 minutes. **Never grease, fat, herbs or dung**
([WTND, p. 96](lib:where-there-is-no-doctor-10#page=22)). Canning kettles and soap-making lye are
local hazards; see the [Field Care guide](guide:FIELD-CARE-GUIDE).

**Poisons:** lock up lye, kerosene and lamp oil, rat poison and medicines (**iron pills
especially**), and **never store them in drink bottles**
([WTND, p. 103](lib:where-there-is-no-doctor-10#page=29)). Teach children to leave alone **western
water hemlock** by creeks and ditches, "the most poisonous plant in North America"
([PNW 109](lib:pnw-western-waterhemlock#page=1); [Cicuta douglasii](wiki:Cicuta_douglasii)), and
the **death cap mushroom** ([BCCDC](lib:bccdc-death-cap-mushroom-brochure#page=1); [Death cap](wiki:Amanita_phalloides)).

**If a child swallows poison** ([WHO, p. 155](lib:world-report-on-child-injury#page=155)):
1. Get them away from it; strip soaked clothes; **flush skin and eyes with lots of water**.
2. Airway and breathing first. Unconscious: on their side ([🖼️ ATP p. 79](lib:atp-4-02-11#page=79)).
3. [Activated charcoal](wiki:Activated_carbon) within 1 hour helps for many poisons, **not fuels, lye, alcohol or iron**.
4. **Do not make the child vomit.** WHO no longer uses it, and it harms with fuels and caustics.

📚 **Go deeper:** [WHO *Child Injury Prevention*](lib:world-report-on-child-injury#page=86) — what works; [WTND first aid](lib:where-there-is-no-doctor-10#page=22).

## 📚 Keeping children learning at home

**Babies and toddlers learn through play and talk**
([WHO/UNICEF cards](lib:care-for-child-development#page=2)):

| Age | Play and talk |
|---|---|
| Newborn | Skin-to-skin; look into the baby's eyes and talk |
| 6–9 months | Clean household things to bang and drop (pot and spoon) |
| 9–12 months | Peek-a-boo; hide a toy under a cloth; name things |
| 1–2 years | Stack, fill and empty containers; simple questions |
| 2 years + | Count, name and compare; stories, songs, picture books |

**Reading:** the [McGuffey](wiki:McGuffey_Readers) Primer adds **about 6 new words a lesson**, by
phonics or whole words ([Primer](lib:mcguffeys-eclectic-primer#page=7)), then the
[First](lib:mcguffeys-first-eclectic-reader), [Second](lib:mcguffeys-second-eclectic-reader) and
[Third](lib:mcguffeys-third-eclectic-reader) Readers.

**Arithmetic:** **count real beans, corn or pebbles before pictures**, then write out the sums to 20
([Ray's Primary](lib:rays-new-primary-arithmetic#page=11)). Mental math needs no paper
([Intellectual](lib:rays-new-intellectual-arithmetic)); written math goes on in the
[Practical](lib:rays-new-practical-arithmetic), with answers for parents in the
[Key](lib:key-to-rays-new-arithmetics).

**Older children teach younger ones**: a 6th-grader working at 4th-grade level can help a
2nd-grader. **Train tutors**, or they fall back on threats and put-downs
([*Peer Tutoring*, p. 21](lib:multigrade-classroom-book-7#page=21)).

📚 **Go deeper:** [*Care for Child Development*](lib:care-for-child-development#page=2) — if a child seems slow; [Key to Ray's](lib:key-to-rays-new-arithmetics) — worked answers.

## ⚠️ Old advice in the library to ignore

| Old book | What it says | Do this instead |
|---|---|---|
| [WTND, p. 103](lib:where-there-is-no-doctor-10#page=29) | Make a poisoned child vomit "with your finger or very salty water" | **Never.** Salt is on that page's poison list; WHO dropped vomiting ([p. 155](lib:world-report-on-child-injury#page=155)) |
| [WTND, p. 259](lib:where-there-is-no-doctor-19#page=15) | An enema in labor | WHO: **no enema** ([PCPNC, p. 63](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=63)) |
| [WTND, p. 270](lib:where-there-is-no-doctor-19#page=26) | Alcohol on the cord at every diaper change | Dry cord care; only 7.1% chlorhexidine where advised ([PCPNC, p. 170](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=170)) |
| [WTND, p. 152](lib:where-there-is-no-doctor-13#page=2) | Home drinks often beat ORS; ORS contains zinc | WHO: home recipes get mixed wrong ([p. 13](lib:treatment-of-diarrhoea#page=13)). **Stock ORS and zinc tablets** |
| [WTND, p. 266](lib:where-there-is-no-doctor-19#page=22) | Save bleeding medicine for emergencies | WHO: **every mother, within 1 minute** ([p. 19](lib:bleeding-after-birth#page=19)) |
| [BfM, pp. 242–243](lib:a-book-for-midwives-13#page=21) | Rescue breaths about 30 a minute; stop after 20 minutes | WHO: **40 a minute; stop at 10 minutes with no heartbeat** ([PCPNC, p. 152](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=152)) |
| [BfM, p. 279](lib:a-book-for-midwives-15#page=12) | Jaundiced baby in direct sun | **No direct sun.** Feed often; watch palms and soles ([IMCI, p. 46](lib:imci-chart-booklet#page=46)) |
| [PCPNC, p. 163](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=163) | At least 4 prenatal visits | WHO now says **8** *(2016; not on the drive)*. Check monthly, then weekly |
| [Ray's Primary, p. 11](lib:rays-new-primary-arithmetic#page=11) | Stop finger-counting | It's a normal step *(general practice)* |
| [Ray's Practical, p. 72](lib:rays-new-practical-arithmetic#page=74) | Mills, eagles, 1877 prices | Skip or update the money problems |
| McGuffey Readers (1909–1920) | 19th-century morals and stereotypes | Read them **with** the child *(general practice)* |

📚 **Go deeper:** [PCPNC, p. 170](lib:pregnancy-childbirth-postpartum-and-newborn-care#page=170) — WHO's list of harmful birth practices; [WHO *Child Injury*, p. 155](lib:world-report-on-child-injury#page=155) — current poisoning first aid.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Pregnancy and getting ready**
- How high the womb should be, month by month — [🖼️ BfM, p. 130](lib:a-book-for-midwives-08#page=23); [Fundal height](wiki:Fundal_height)
- Taking blood pressure — [🖼️ BfM, p. 123](lib:a-book-for-midwives-08#page=16); [Sphygmomanometer](wiki:Sphygmomanometer)
- Breech positions; where the heartbeat is loudest — [🖼️ MCPC, p. 234](lib:managing-complications-in-pregnancy#page=234); [🖼️ WTND, p. 252](lib:where-there-is-no-doctor-19#page=8); [Breech birth](wiki:Breech_birth)
- Clean birth kit — [🖼️ WTND, p. 254](lib:where-there-is-no-doctor-19#page=10)

**Labor and birth**
- Positions for labor and for the birth — [🖼️ MCPC, p. 111](lib:managing-complications-in-pregnancy#page=111); [🖼️ MCPC, p. 123](lib:managing-complications-in-pregnancy#page=123); [🖼️ WTND, p. 260](lib:where-there-is-no-doctor-19#page=16)
- How the baby comes out, head first — [🖼️ WTND, p. 261](lib:where-there-is-no-doctor-19#page=17); [Childbirth](wiki:Childbirth)
- Bulb syringe; when and how to tie and cut the cord — [🖼️ BfM, p. 214](lib:a-book-for-midwives-12#page=21); [🖼️ WTND, p. 262](lib:where-there-is-no-doctor-19#page=18); [Umbilical cord](wiki:Umbilical_cord)
- Drying the baby, skin-to-skin on the mother — [🖼️ BfM, p. 240](lib:a-book-for-midwives-13#page=19)

**Bleeding and hard births**
- Feeling and rubbing the womb — [🖼️ BfM, p. 224](lib:a-book-for-midwives-13#page=3); [🖼️ BfM, p. 236](lib:a-book-for-midwives-13#page=15); [Postpartum bleeding](wiki:Postpartum_bleeding)
- Squeezing the womb between two hands — [🖼️ MCPC, p. 178](lib:managing-complications-in-pregnancy#page=178); [🖼️ BfM, p. 237](lib:a-book-for-midwives-13#page=16)
- Fist above the navel until the thigh pulse goes — [🖼️ MCPC, p. 179](lib:managing-complications-in-pregnancy#page=179); [🖼️ BfM, p. 238](lib:a-book-for-midwives-13#page=17)
- Stuck shoulders: hands-and-knees, knees to chest, the back arm — [🖼️ BfM, pp. 210–211](lib:a-book-for-midwives-12#page=17); [🖼️ MCPC, p. 244](lib:managing-complications-in-pregnancy#page=244); [Shoulder dystocia](wiki:Shoulder_dystocia)
- Breech: hands off, hold by the hips — [🖼️ MCPC, pp. 377–378](lib:managing-complications-in-pregnancy#page=377); [🖼️ BfM, pp. 215–217](lib:a-book-for-midwives-12#page=22)

**The newborn**
- Head position and mask for a baby who isn't breathing — [🖼️ MCPC, pp. 311–313](lib:managing-complications-in-pregnancy#page=311); [Bag valve mask](wiki:Bag_valve_mask); [Neonatal resuscitation](wiki:Neonatal_resuscitation)
- Kangaroo care position and wrap — [🖼️ IYCF, p. 84](lib:infant-and-young-child-feeding-model-chapter#page=84); [🖼️ WHO KMC guide, p. 32](lib:kangaroo-mother-care#page=32); [Kangaroo care](wiki:Kangaroo_care)
- Danger signs you can see — [Omphalitis](wiki:Omphalitis_of_newborn); [Neonatal conjunctivitis](wiki:Neonatal_conjunctivitis); [Neonatal jaundice](wiki:Neonatal_jaundice)

**Breastfeeding**
- Good and poor attachment — [🖼️ IYCF, p. 42](lib:infant-and-young-child-feeding-model-chapter#page=42); [Breastfeeding](wiki:Breastfeeding)
- Holding a small baby to feed; feeding by cup — [🖼️ IYCF, p. 82](lib:infant-and-young-child-feeding-model-chapter#page=82); [🖼️ IYCF, p. 86](lib:infant-and-young-child-feeding-model-chapter#page=86)
- Expressing milk by hand — [🖼️ IYCF, p. 155](lib:infant-and-young-child-feeding-model-chapter#page=155); [🖼️ WTND, p. 277](lib:where-there-is-no-doctor-19#page=33)

**Sick and growing children**
- The skin-pinch test for dehydration — [🖼️ WTND, p. 151](lib:where-there-is-no-doctor-13#page=1); [Dehydration](wiki:Dehydration)
- Measles and chickenpox rashes — [🖼️ WTND, p. 311](lib:where-there-is-no-doctor-21#page=17); [Measles](wiki:Measles)
- Pinworm and how hookworm spreads — [🖼️ WTND, pp. 141–142](lib:where-there-is-no-doctor-12#page=11); [Pinworm](wiki:Pinworm_infection); [Hookworm](wiki:Hookworm_infection)
- Homemade beam scale — [🖼️ WTND, p. 297](lib:where-there-is-no-doctor-21#page=3); [Growth chart](wiki:Growth_chart)
- Upper-arm band and swollen feet — [MUAC](wiki:Anthropometry_of_the_upper_arm); [Kwashiorkor](wiki:Kwashiorkor)
- "Five keys to safer food" — [🖼️ IYCF, p. 56](lib:infant-and-young-child-feeding-model-chapter#page=56)
- Western water hemlock, to teach children — [🖼️ PNW 109 photos, pp. 1–2](lib:pnw-western-waterhemlock#page=1); [Cicuta douglasii](wiki:Cicuta_douglasii); [Death cap](wiki:Amanita_phalloides)
- Play and talk by age — [🖼️ WHO/UNICEF cards](lib:care-for-child-development#page=2)

---

## 🔗 Related guides

- [Field Care](guide:FIELD-CARE-GUIDE) — wounds, burns, shock and CPR
- [Medical — READ ME FIRST](guide:Medical-READ-ME-FIRST) — medicine storage, expiry and adult doses
- [Food Security](guide:FOOD-SECURITY-GUIDE) — infant feeding in a shortage
- [Sanitation](guide:SANITATION-GUIDE) — latrines and handwashing against diarrhea and worms
- [Water Purification](guide:WATER-PURIFICATION-GUIDE) — safe water for babies and toddlers
- [Community and Barter](guide:COMMUNITY-BARTER-GUIDE) — shared schooling and caring for neighbors
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — hospitals, roads, wildfire smoke
