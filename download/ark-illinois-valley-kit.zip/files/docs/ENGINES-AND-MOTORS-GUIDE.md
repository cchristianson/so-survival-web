# 🔧 Engines, Motors and Generators

How to keep small gas engines, chainsaws and generators running, how to test and rebuild
electric motors, and how to turn motors and car alternators into generators for charging
batteries. The full shop manuals are in `Engines-Motors\` (`Small-Engines`,
`Chainsaws-and-Saws`, `Electric-Motors`, `Motors-as-Generators`). Creek hydro and solar are in
`Off-Grid-Power\`; electricity basics are in the Navy NEETS modules there.

Fuel itself (storing, testing, getting it out of tanks) is in the [Fuel guide](guide:FUEL-GUIDE).

> ### ⚠️ Rules that prevent the worst accidents
> - **Never run an engine or generator indoors**, in a garage, shed or crawlspace — carbon
>   monoxide kills in minutes, even with doors open.
>   ([CPSC *Portable Generator Hazards*, p. 1](lib:cpsc-portable-generator-hazards#page=1))
> - **Never refuel a hot or running engine.** Keep the can touching the tank while pouring
>   (stops static sparks).
>   ([TM 5-6115-271-14, p. 60](lib:tm-5-6115-271-14#page=60))
> - **Never plug a generator into a wall outlet** ("backfeeding") — use a transfer switch or
>   interlock. It can kill someone working on the lines.
>   ([🖼️ how a transfer switch is wired](lib:emergency-power-systems-for-critical-facilities#page=125);
>   [Transfer switch](wiki:Transfer_switch))
> - **Capacitors bite.** Motor capacitors (and microwave ovens) can hold a deadly charge after
>   unplugging. Discharge across the terminals with an insulated screwdriver or a resistor
>   before touching.
> - **Pull the spark plug wire** before working on a mower blade, saw chain or anything the
>   engine turns.
> - **Keep away from diesel injection lines while the engine turns.** The injection pump
>   pushes fuel at **4,000–10,000 psi**
>   ([Practical Action *Diesel Engine Repair*, p. 13](lib:diesel-engine-repair-and-maintenance#page=13)).
>   Never hold a hand or face near a cracked line or a nozzle that is spraying. *(Rule of thumb)*
> - **Never carry a chainsaw or fuel in the passenger part of a vehicle.**
>   ([USFS *Chain Saw and Crosscut Saw Training*, p. 34](lib:usfs-chain-saw-and-crosscut-saw-training#page=34))

---

## ⛽ Small gas engines: why it won't start

Every engine needs three things: **compression, spark and fuel.** Find which one is
missing. ([MAVCC *Small Engine Repair*, p. 590](lib:small-engine-repair-two-stroke#page=590);
how it works: [🖼️ the four strokes drawn](lib:navy-construction-mechanic-3-and-2#page=23),
[Four-stroke engine](wiki:Four-stroke_engine), [Two-stroke engine](wiki:Two-stroke_engine))

![The four strokes of a gasoline engine: intake with the intake valve open and the piston moving down, compression with both valves closed, power when the spark ignites the mixture, and exhaust with the exhaust valve open](img:ENGINES-AND-MOTORS-GUIDE/four-stroke-cycle.png)
*Intake, compression, power, exhaust: fuel, compression and a spark at the right moment ([Navy *Construction Mechanic*, p. 23](lib:navy-construction-mechanic-3-and-2#page=23)).*

1. **Fuel:** pull the plug, cover the hole with a finger and pull the starter 2–3 times. A
   **wet finger** means fuel is arriving. If dry, check: fuel in the tank, shutoff valve open,
   **cap vent** not blocked, carburetor bowl (drain it — water or gum?), fuel filter and line.
   ([MAVCC, pp. 595–598](lib:small-engine-repair-two-stroke#page=596);
   [🖼️ drawings](lib:small-engine-repair-two-stroke#page=596))
2. **Spark:** put a spare plug on the plug wire, rest it against the metal head and crank.
   A **bright blue spark** is good. Yellow, weak or none = clean or replace the plug, check
   the kill-switch wire, then the coil/magneto.
   ([MAVCC, pp. 599–600](lib:small-engine-repair-two-stroke#page=600);
   [🖼️ spark-tester drawing](lib:small-engine-repair-two-stroke#page=599))
3. **Compression:** spin the flywheel backward against compression — a **sharp rebound** is
   good. Weak = loose plug or head, stuck valve, worn rings. With a compression gauge, crank
   at least six times before you read it.
   ([MAVCC, pp. 602–603](lib:small-engine-repair-two-stroke#page=602);
   [🖼️ flywheel check and gauge drawings](lib:small-engine-repair-two-stroke#page=602))

![A spark tester plug on the spark plug wire, clipped with an alligator clamp to the engine's cylinder head](img:ENGINES-AND-MOTORS-GUIDE/spark-test-plug.png)
*A tester plug on the plug wire, grounded to the cylinder head: crank and look for a bright blue spark ([MAVCC, p. 599](lib:small-engine-repair-two-stroke#page=599)).*

**Quick troubleshooting chart** ([MAVCC, p. 592](lib:small-engine-repair-two-stroke#page=592)):

| What it does | Look at these first |
|---|---|
| Won't start, plug **dry** | Empty tank, fuel valve shut, **plugged tank vent**, stuck or clogged float valve, blocked filter or line, choke not closing |
| Won't start, plug **wet** | Choke stuck or overused, **stale fuel**, water in fuel, flooded (mixture too rich), too much oil in 2-stroke mix, fuel-soaked air filter |
| Won't start, **no spark** | Kill button or wire grounded, bad plug, bad plug wire, dirty or wrongly gapped points (older engines), bad coil |
| Won't start, **weak compression** | Loose plug or head bolts, blown head gasket, valve stuck open, worn rings or bore |
| Starts but **lacks power** | Dirty air filter, carburetor out of adjustment, clogged muffler or exhaust port, low compression, governor fault |
| **Overheats** | Cooling fins or blower blocked, engine overloaded, clogged muffler, late ignition timing |
| **Smokes or uses oil** | Wrong oil, oil diluted by a rich mixture, worn rings, clogged crankcase breather, wrong 2-stroke mix |
| **Kicks back** when you pull it | Ignition timing off, **sheared flywheel key** ([🖼️ drawing](lib:small-engines-care-operation-maintenance#page=59)), loose blade |

**Old fuel is the #1 problem.** Gas goes stale in about **60 days** without stabilizer (sooner
with ethanol). For longer storage, **drain the tank and run the carburetor dry**, or add
stabilizer and run it a few minutes so it reaches the carburetor. Keep cans sealed — water in
ethanol gas separates and ruins engines.
([Oklahoma Extension BAE-1746, p. 2](lib:ethanol-gasoline-blends-and-small-engines#page=2))
- Ethanol is a solvent. In an old, neglected engine it can loosen years of deposits that then
  **clog the filter and tiny carburetor passages** — the main reason for "ethanol trouble."
  Older engines (before about 1995) may also have rubber or cork parts that suffer. (BAE-1746,
  [pp. 1–2](lib:ethanol-gasoline-blends-and-small-engines#page=1))

**Cleaning a carburetor** ([AAVIM *Small Engines* Vol 2](lib:small-engines-care-operation-maintenance#page=92);
[🖼️ float-type carburetors](lib:small-engines-care-operation-maintenance#page=91),
[🖼️ floats, needle valve and float settings](lib:small-engine-repair-two-stroke#page=525)):
- Take a photo before you take it apart. Soak **metal** parts several hours in carb cleaner,
  then blow out every passage with air.
  ([AAVIM, p. 97](lib:small-engines-care-operation-maintenance#page=97))
- **Plastic or nylon parts no more than 30 minutes; never soak cork or coated floats.**
  ([AAVIM, p. 95](lib:small-engines-care-operation-maintenance#page=95);
  [p. 93](lib:small-engines-care-operation-maintenance#page=93))
- **Don't poke jets with wire** — it enlarges them. Use a bristle, fishing line or air.
- Always fit new gaskets. Float too high = floods; too low = starves. A metal float with
  gasoline sloshing inside, or a crushed one, must be replaced.
  ([AAVIM, pp. 92–93](lib:small-engines-care-operation-maintenance#page=92);
  [🖼️ checking float height](lib:small-engines-care-operation-maintenance#page=93))

**Two-stroke fuel** (chainsaws, trimmers): mix oil at the ratio printed on the engine or in
its manual ([MAVCC, p. 186](lib:small-engine-repair-two-stroke#page=186)). **Never run straight
gas** — it seizes the engine in minutes. *Rule of thumb:* most modern saws are **50:1 (about
2.6 oz of 2-stroke oil per gallon)**; older gear is often 16:1–32:1. Don't mix mineral and
synthetic 2-stroke oils. ([Two-stroke oil](wiki:Two-stroke_oil))

**Routine care:** check oil every use (4-strokes), clean the air filter often (a choked filter
makes an engine run rich and weak), keep cooling fins clear, replace the plug yearly.
([Air filter](wiki:Air_filter))

**Replacing a starter rope:** for a wrap-around (non-recoil) starter, use **3/16-inch
braided nylon rope**, usually 4–5 feet long — enough to wrap the pulley 3–5 times plus about
6 inches. **Singe the cut ends with a match** so they don't fray, and tie a figure-eight or
double overhand knot in each end.
([AAVIM, pp. 14–15](lib:small-engines-care-operation-maintenance#page=14);
knots drawn step by step: [🖼️ figure-eight](lib:small-engines-care-operation-maintenance#page=14),
[🖼️ double overhand](lib:small-engines-care-operation-maintenance#page=15)) Recoil starters
take thinner rope — most often 5/32 inch — that fills the pulley groove without binding.
([AAVIM, p. 20](lib:small-engines-care-operation-maintenance#page=20);
[🖼️ parts of a recoil starter](lib:small-engines-care-operation-maintenance#page=16))

📷 What the parts look like: [Carburetor](wiki:Carburetor), [Spark plug](wiki:Spark_plug),
[Magneto](wiki:Ignition_magneto), [Flywheel](wiki:Flywheel), [Governor](wiki:Governor_(device)).

📚 **Go deeper:** [MAVCC *Small Engine Repair*](lib:small-engine-repair-two-stroke#page=587) — full troubleshooting unit and job sheets; [AAVIM *Small Engines* Vol 2](lib:small-engines-care-operation-maintenance#page=92) — carburetor, starter and valve repair step by step; [TM 9-2805-262-14 6 HP engine](lib:tm-9-2805-262-14) — Army maintenance checks for a small engine; [Oklahoma BAE-1746](lib:ethanol-gasoline-blends-and-small-engines) — ethanol fuel in small engines.

## 🚜 Diesel engines

Diesels have **no spark plugs** — squeezing the air makes it hot enough to light the fuel. So
a diesel needs **compression and clean fuel with no air in the lines.**
([Practical Action *Diesel Engine Repair*, p. 5](lib:diesel-engine-repair-and-maintenance#page=5);
[🖼️ gasoline and diesel strokes side by side](lib:navy-construction-mechanic-3-and-2#page=94);
[Diesel engine](wiki:Diesel_engine))
Diesels usually need less maintenance than gasoline engines because they have no ignition
system. ([FM 5-424, p. 114](lib:us-army-fm-5-424#page=114))

**Won't start or keeps dying:** suspect **air in the fuel lines** (an "air lock"),
an empty tank or a clogged filter. ([Practical Action, p. 12](lib:diesel-engine-repair-and-maintenance#page=12))
Bleed the air out ([p. 16](lib:diesel-engine-repair-and-maintenance#page=16)):
1. Fill the tank with clean diesel and open the tank valve.
2. Loosen the **bleed screw on the fuel filter** (and on the injection pump) until fuel runs
   out in a steady stream with no bubbles. Tighten it.
3. Loosen the **injection line nut** at the injector and crank the engine until fuel comes out
   without foam.
4. Tighten the nut and check every joint for leaks.

![Bleeding a diesel: open the tank valve, loosen the bleed screw on the fuel filter and then on the injection pump until fuel runs without bubbles, then loosen the line nut at the injector and crank until fuel comes without foam](img:ENGINES-AND-MOTORS-GUIDE/bleeding-a-diesel.svg)
*Bleed in order, from the tank toward the injector (a diagram drawn for this guide).*

**What the smoke and symptoms tell you** ([Practical Action, pp. 11–14](lib:diesel-engine-repair-and-maintenance#page=11)):

| Symptom | Common causes |
|---|---|
| Lots of **black smoke** | Faulty injector (p. 14) |
| **Overheating** | Low coolant, loose or torn fan belt, blocked water jacket, bad water pump, low oil, overload, long running at high speed |
| **Burns too much fuel** | Leaks in tank or lines, clogged air cleaner, wrong valve timing, overload, lots of stopping and starting, idling when not needed |
| **Burns oil** | Worn or wrongly fitted piston rings, worn cylinder, damaged seals or head gasket |
| **Knocking or noise** | Poor-quality fuel, loose connecting rod, worn or badly adjusted parts |

**Cleaning an injector nozzle:** soak the nozzle valve and body in clean diesel, scrub the soot
off with a **copper (not steel) wire brush**, and check the needle slides freely.
([Practical Action, p. 15](lib:diesel-engine-repair-and-maintenance#page=15);
[🖼️ injector valve, taken apart](lib:navy-construction-mechanic-3-and-2#page=109);
[🖼️ cleaning the spray holes](lib:navy-construction-mechanic-3-and-2#page=131);
[Fuel injection](wiki:Fuel_injection))

**Don't run a diesel generator lightly loaded for long.** It runs too cool, soot builds up in
the engine and exhaust ("**wet stacking**"), and over time this can permanently damage it.
([FEMA P-1019, p. 150](lib:emergency-power-systems-for-critical-facilities#page=150)) Give it a
real load when you run it.

Diesel fuel catches fire less easily than gasoline, but once burning a diesel fire is fierce
([Practical Action, p. 6](lib:diesel-engine-repair-and-maintenance#page=6)). Cold-weather
gelling, water and fuel substitutes are in the [Fuel guide](guide:FUEL-GUIDE).

📚 **Go deeper:** [Practical Action *Diesel Engine Repair and Maintenance*](lib:diesel-engine-repair-and-maintenance) — short, plain-language diesel fault-finding; [Navy *Construction Mechanic*](lib:navy-construction-mechanic-3-and-2#page=109) — diesel fuel systems, governors and bleeding; [TM 9-8000 *Principles of Automotive Vehicles*](lib:tm-9-8000) — how every engine and vehicle system works.

## 🪚 Chainsaws, crosscut saws and axes

- **A sharp chain throws chips; a dull one makes dust** — and dust clogs the filter and raises
  kickback risk.
  ([USFS *Chain Saw and Crosscut Saw Training Course*, p. 25](lib:usfs-chain-saw-and-crosscut-saw-training#page=25))
- **The four chain rules:** sharp, **depth gauges set right**, **correctly tensioned** (more
  bar and chain trouble comes from wrong tension than anything else), and **well oiled**. The
  chain should not hang below the bar but should still turn freely by hand.
  ([USFS, p. 31](lib:usfs-chain-saw-and-crosscut-saw-training#page=31);
  [🖼️ parts of the chain](lib:usfs-chain-saw-and-crosscut-saw-training#page=26);
  [🖼️ right and wrong tension](lib:chain-saw-repair-mavcc#page=40); [Saw chain](wiki:Saw_chain))
- **Filing:** use the file size for your chain, with a guide. Hold the file level with about
  one-fifth of it above the cutter's top plate, guide mark parallel to the chain. File from
  the inside of each cutter outward, all of one side, then turn the saw around. **Keep all
  cutters the same length.** If the chrome is chipped, file until the chip is gone.
  ([USFS, pp. 33–34](lib:usfs-chain-saw-and-crosscut-saw-training#page=33);
  [🖼️ filing angles](lib:usfs-chain-saw-and-crosscut-saw-training#page=33);
  [🖼️ file height and direction](lib:chain-saw-repair-mavcc#page=36))
- **Depth gauges** (the little humps in front of each cutter): check with a gauge tool every
  few sharpenings, file down only to the tool, and round off the front. **Never file one lower
  than the tool.** ([USFS, p. 34](lib:usfs-chain-saw-and-crosscut-saw-training#page=34);
  [🖼️ what the depth gauge does](lib:usfs-chain-saw-and-crosscut-saw-training#page=32);
  [🖼️ gauge tool and rounding off](lib:usfs-chain-saw-and-crosscut-saw-training#page=34))
- After several hand filings, the angles drift. The Forest Service then grinds the chain on a
  chain grinder to restore them — if you have none, file slowly and check angles against a new
  chain. ([USFS, p. 32](lib:usfs-chain-saw-and-crosscut-saw-training#page=32))

![Filing a saw chain, side view of one cutter: the round file sits with one-fifth of its width above the cutter's top plate; a depth-gauge tool laid on the chain shows how much of the depth gauge to file off, never lower than the tool](img:ENGINES-AND-MOTORS-GUIDE/filing-a-saw-chain.svg)
*The file's height on the cutter, and the depth gauge filed only down to the tool (a diagram drawn for this guide).*

**Cleaning a saw** ([USFS, p. 31](lib:usfs-chain-saw-and-crosscut-saw-training#page=31)):
- Take off the bar and chain. Clean the bar groove from the tip toward the base, clear the oil
  holes, check the rails for wear or flared edges ([🖼️ rail wear drawn](lib:usfs-chain-saw-and-crosscut-saw-training#page=29)),
  grease the nose sprocket, and turn the bar over when you refit it so it wears evenly.
- **Air filter:** tap it gently clean. **Never blow it out with an air hose and never wash it
  in saw fuel** — a damaged filter lets grit into the engine.
- **Spark plug:** the tip should be **tan (beige), not black**, and dry.
  ([🖼️ pictures of fouled and overheated plugs](lib:navy-construction-mechanic-3-and-2#page=209))
- **Spark arrester screen** in the muffler: replace it if it has any holes. Illinois Valley
  summers are fire season — a saw spitting sparks into dry grass can start a wildfire.
- Check the chain brake, loose bolts, and the rubber anti-vibration mounts.

**Things that make kickback more likely** ([USFS, p. 32](lib:usfs-chain-saw-and-crosscut-saw-training#page=32);
[🖼️ the kickback zone on the bar nose](lib:usfs-chain-saw-and-crosscut-saw-training#page=37)):
a loose or dull chain, wrong filing angles, depth gauges filed too low or left square, loose
rivets or cracked links, and anti-kickback parts removed.

**Running out of fuel isn't the end of cutting.** A sharp crosscut saw and ax still fell and
buck trees. Raker depth for a crosscut: **0.008 in** for hard, dry wood up to **0.030 in**
for soft, springy wood; start at about **0.012 in**.
([USFS *Crosscut Saw Manual*, p. 16](lib:usfs-crosscut-saw-manual#page=16), with
[🖼️ drawings of good and "whiskered" shavings](lib:usfs-crosscut-saw-manual#page=16);
[🖼️ how crosscut teeth and rakers cut](lib:usfs-saws-that-sing#page=14)) Set the teeth only
enough to stop binding — about **0.010 in** is a good first try; up to 0.030 in for soft,
punky wood. ([Crosscut Saw Manual, p. 21](lib:usfs-crosscut-saw-manual#page=21)) More in
[*Saws That Sing*](lib:usfs-saws-that-sing) and [*An Ax to Grind*](lib:usfs-an-ax-to-grind#page=34).

[Chainsaw](wiki:Chainsaw), [Crosscut saw](wiki:Crosscut_saw). More pictures:
[Axe](wiki:Axe), and the [🖼️ parts of an ax](lib:usfs-an-ax-to-grind#page=9).

📚 **Go deeper:** [USFS *Chain Saw and Crosscut Saw Training Course*](lib:usfs-chain-saw-and-crosscut-saw-training#page=25) — maintenance, felling and bucking; [MAVCC *Chain Saw Repair*](lib:chain-saw-repair-mavcc) — engine, clutch and oiler repair; [USFS *Crosscut Saw Manual*](lib:usfs-crosscut-saw-manual#page=16) — filing and setting a crosscut; [USFS *Saws That Sing*](lib:usfs-saws-that-sing) — using crosscut saws safely.

## 🔋 Generators

**Where to put it** ([CPSC, p. 1](lib:cpsc-portable-generator-hazards#page=1)):
- **Outdoors, far from doors, windows and vents**, exhaust pointed away from buildings. Put a
  battery-powered CO alarm in the house. ([Engine-generator](wiki:Engine–generator),
  [Carbon monoxide poisoning](wiki:Carbon_monoxide_poisoning))
- In rain, run it under an **open, canopy-like roof** on dry ground where water can't puddle
  under it. Dry your hands before touching it.
- Use heavy outdoor extension cords rated for more than the total watts on them, with all
  three prongs and no cuts. Don't pinch them in doors or windows.
- Turn it off and let it cool before refueling. Keep its fuel outside living areas.
- Set it nearly level — the Army 3 kW set allows no more than **15° of tilt** — on planks or
  timbers if the ground is soft. ([TM 5-6115-271-14, p. 60](lib:tm-5-6115-271-14#page=60))

**Maintenance** *(rule of thumb — the generator's own manual comes first)*: oil change every
50–100 hours (sooner when new), clean air filter, fresh or stabilized fuel, run it under load
for 20–30 minutes once a month. Machines that sit idle for long periods should be "exercised"
on a schedule to keep oil moving and moisture out.
([TM 5-683, p. 41](lib:tm-5-683-electrical-interior-facilities#page=41))

**Load:** add up the running watts of what you'll plug in, plus the **start surge** of motors
(fridges, pumps, power tools can need 2–3× their running watts for a second — *rule of
thumb*). Keep steady load under about 80% of the generator's rating.
- **Motors need extra generator size.** When a big motor starts, voltage dips and other motors
  can stall. **Unplug the other loads, start the big motor, then plug the small loads back
  in.** ([FM 5-424, p. 113](lib:us-army-fm-5-424#page=113))
- A generator feeding only heaters, cookers or light bulbs (a "resistive" load) can carry only
  about **80% of its kVA rating** — e.g. a 6.25 kVA Army set carries 5 kW.
  ([FM 5-424, p. 115](lib:us-army-fm-5-424#page=115))

**Grounding:** follow the generator's own manual. The Army 3 kW set procedure
([TM 5-6115-271-14, pp. 60–61](lib:tm-5-6115-271-14#page=60); drawings of
[🖼️ rod, plate and pipe grounds](lib:us-army-fm-5-424#page=49),
[🖼️ ways to ground a generator](lib:us-navy-construction-electrician-basic#page=71) and
[🖼️ driving a ground rod](lib:us-navy-construction-electrician-basic#page=72);
[Ground](wiki:Ground_(electricity))):
- Drive a **ground rod** — or a ¾-inch copper or steel pipe — **at least 8 ft** into the ground.
- In rock or hard ground, a buried metal plate can stand in (the manual gives sizes).
- **Soak the ground around the rod with water** to help it conduct.
- Run **copper** wire from the rod to the generator's ground stud — braided cable is best,
  **No. 6** or heavier solid wire will do — and tighten it securely.

**No output but the engine runs?** Check the breaker on the generator, then the brushes and
voltage regulator (most small generators). A generator that sat unused can **lose its
residual magnetism** — see "flashing the field" below.

📚 **Go deeper:** [CPSC *Portable Generator Hazards*](lib:cpsc-portable-generator-hazards#page=1) — CO, shock and fire rules on one page; [TM 5-6115-271-14 3 kW generator](lib:tm-5-6115-271-14#page=72) — grounding, troubleshooting tables and field flashing; [FM 5-424 *Electrical Systems*](lib:us-army-fm-5-424#page=111) — picking and loading a generator, wiring and grounding; [FEMA P-1019](lib:emergency-power-systems-for-critical-facilities#page=145) — generator sizing and fuel planning.

## ⚙️ Electric motors: testing and repair

**When a motor won't run, check the simple things first, in this order**
([Illinois *Electric Motors for Farm Use*, pp. 24–25](lib:electric-motors-for-farm-use#page=24);
know the parts first: [🖼️ cutaway of an induction motor](lib:tm-5-683-electrical-interior-facilities#page=38),
[🖼️ main parts laid out](lib:tm-5-683-electrical-interior-facilities#page=40),
[Induction motor](wiki:Induction_motor)):
1. **Power:** is the right voltage reaching the motor terminals? Check fuses, breakers and the
   switch.
2. **Load:** take the belt off. If the motor now runs, the machine it drives is stuck.
3. **Bearings:** power off, turn the shaft by hand. If it won't turn freely, a bearing is dry,
   worn or stuck.
4. **Thermal protector:** many motors have a red **reset button**; others reset themselves
   once cool. A tripped protector means something else is wrong — find it.
5. **Starting switch:** a motor that **hums but won't start, yet runs if you spin the shaft by
   hand,** has a fault in its starting circuit (see below).
6. **Windings:** a burned winding has a strong **burned smell**, and you may see charred
   insulation.

**Single-phase motor hums but won't start** (pumps, compressors, shop tools): suspect the
**start capacitor** or the **centrifugal start switch**, which should click open at about ¾
speed ([Illinois, p. 28](lib:electric-motors-for-farm-use#page=28);
[🖼️ capacitor-start motor](lib:electric-motors-for-farm-use#page=11);
[🖼️ the two parts of a centrifugal switch](lib:us-navy-construction-electrician-basic#page=237);
[Motor capacitor](wiki:Motor_capacitor)). Discharge the capacitor
and check it; if it's open or shorted, replace it
([TM 5-683, p. 56](lib:tm-5-683-electrical-interior-facilities#page=56)). A bulged or leaking
one is dead; a meter with a capacitance setting tells for sure. Replace with the **same
microfarads and same or higher voltage** *(rule of thumb)*. Switch contacts can be dirty,
burned or pitted, or a wire can burn in two. (Illinois, p. 24)

**Basic winding checks with a meter** ([Navy *Electrician's Mate*](lib:navy-electricians-mate-3-and-2#page=237)):
- Windings must have **no opens** (infinite ohms through a winding), **no shorts** (much lower
  reading than its twin), and **no grounds** (any reading from a winding to the frame).
- The three windings of a 3-phase motor should read nearly the same resistance; a high reading
  between any two leads means an open winding.
  ([Navy *Electrician's Mate*, p. 237](lib:navy-electricians-mate-3-and-2#page=237))
- **Insulation test (megger):** right after shutdown while warm and dry, with capacitors
  disconnected. At least **0.5 megohm** for motors 250 V and under, **1 megohm** up to 1000 V.
  Write readings down — a steady fall over months warns of trouble even above the minimum.
  ([TM 5-683, p. 54](lib:tm-5-683-electrical-interior-facilities#page=54))
- **Armatures** (brushed motors): test bar-to-bar on the commutator with a low-ohm meter; a
  "growler" finds shorted coils (a hacksaw blade buzzes over the bad coil).
  ([Navy EM, pp. 238–239](lib:navy-electricians-mate-3-and-2#page=238);
  [🖼️ armature test drawings](lib:navy-electricians-mate-3-and-2#page=239);
  [🖼️ how a growler is built](lib:navy-electricians-mate-3-and-2#page=240);
  [Armature](wiki:Armature_(electrical)))

**Bearings:** a rumbling or hot bearing is the most common motor failure. Replace with the same
number stamped on it. Fit new bearings by heating them to no more than about **200 °F** (oil
bath or oven, not a flame).
([Navy EM, p. 225](lib:navy-electricians-mate-3-and-2#page=225), with
[🖼️ bearing-puller drawings](lib:navy-electricians-mate-3-and-2#page=225)) **Never wash sealed bearings
in solvent** — factory-sealed bearings shouldn't be disturbed. Open bearings get **repacked
half to two-thirds full** of motor bearing grease; too much grease makes heat.
([Illinois, p. 23](lib:electric-motors-for-farm-use#page=23); [TM 5-683, p. 58](lib:tm-5-683-electrical-interior-facilities#page=58);
[🖼️ greasing a bearing step by step](lib:tm-5-683-electrical-interior-facilities#page=45);
[Ball bearing](wiki:Ball_bearing))

**Brushes and commutators** (drills, saws, mixers, car starters, DC motors): replace brushes
that stick, are chipped, or are **worn to about half their original length** (or to within
⅛ inch of a riveted clip). ([Navy EM, p. 228](lib:navy-electricians-mate-3-and-2#page=228);
[🖼️ brush holder and brush](lib:navy-electricians-mate-3-and-2#page=227); [Brush](wiki:Brush_(electric)))
Seat new brushes by pulling fine sandpaper (grit toward the brush) under them **in the
direction the motor turns**, lifting the brushes on the return stroke, then blow out the
carbon dust. ([Navy EM, p. 229](lib:navy-electricians-mate-3-and-2#page=229);
[🖼️ sanding a brush to fit](lib:navy-electricians-mate-3-and-2#page=229)) A blackened,
grooved commutator can be cleaned with a commutator stone or fine sandpaper — **never emery
cloth; emery dust conducts electricity and causes shorts**
([Illinois, p. 24](lib:electric-motors-for-farm-use#page=24); [🖼️ commutator stone](lib:navy-electricians-mate-3-and-2#page=232))
— or turned lightly on a lathe (no more than 0.010 in per cut).
([Navy EM, p. 233](lib:navy-electricians-mate-3-and-2#page=233); [🖼️ turning a commutator](lib:navy-electricians-mate-3-and-2#page=233))

![Seating a motor brush: a strip of sandpaper, rough side up against the brush, wrapped over the commutator under the brush, seen from the end and the side](img:ENGINES-AND-MOTORS-GUIDE/sanding-in-brushes.png)
*Sandpaper under the brush, rough side toward it, pulled the way the motor turns ([Navy *Electrician's Mate*, p. 229](lib:navy-electricians-mate-3-and-2#page=229)).*

**Keeping spare motors** (salvage is your parts store): wipe them clean, lubricate the
bearings, grease the bare shaft against rust, wrap them in heavy paper, and store them dry.
([Illinois, pp. 23–24](lib:electric-motors-for-farm-use#page=23))

**Rewinding a burned motor** ([Braymer & Roe *Rewinding Small Motors*](lib:rewinding-small-motors-braymer#page=12);
[DOE *Repair Specifications*](lib:doe-model-repair-specifications#page=8)):
- **Before stripping, record everything:** turns per coil, wire size, coil span (slots), how
  coils connect, and lead markings. Photograph each step.
  ([Braymer & Roe, p. 12](lib:rewinding-small-motors-braymer#page=12);
  [🖼️ marking the frame and end bells before you take it apart](lib:navy-electricians-mate-3-and-2#page=238);
  [🖼️ rewinding hand tools](lib:navy-electricians-mate-3-and-2#page=245))
- Strip old windings at no more than about **680 °F (360 °C)** or the iron core is damaged.
  ([DOE *Repair Specifications*, p. 8](lib:doe-model-repair-specifications#page=8))
- Rewind with the **same total copper area per turn and same turns** (two thinner wires in
  parallel can replace one thick one). Dry a damp winding at no more than about **195 °F**
  (90 °C); then dip it in varnish and bake it as the varnish maker directs.
  ([DOE, p. 9](lib:doe-model-repair-specifications#page=9);
  [p. 11](lib:doe-model-repair-specifications#page=11))
- Small burned motors are often easier to replace from salvage than to rewind — keep a stock.

[Commutator](wiki:Commutator_(electric)), [Centrifugal switch](wiki:Centrifugal_switch),
[Megger](wiki:Megohmmeter).

📚 **Go deeper:** [Illinois *Electric Motors for Farm Use*](lib:electric-motors-for-farm-use#page=24) — plain-English motor types, care and fault-finding; [Navy *Electrician's Mate*](lib:navy-electricians-mate-3-and-2#page=225) — bearings, brushes, armature and stator tests; [TM 5-683](lib:tm-5-683-electrical-interior-facilities#page=54) — insulation tests and full troubleshooting tables; [Braymer & Roe *Rewinding Small Motors*](lib:rewinding-small-motors-braymer) — rewinding step by step.

## 🔁 Motors as generators

**What works best, easiest first:**

1. **Permanent-magnet DC motors** (treadmill motors, wheelchair, scooter, some cordless tool
   motors): spin them and they make DC directly. Output voltage rises with speed, so choose
   one that makes **at least 14–15 V at the speed you can actually turn it** to charge a 12 V
   battery. Add a **blocking diode** so the battery can't run it as a motor. *(Rule of thumb)*
   ([Brushed DC motor](wiki:Brushed_DC_electric_motor), [Diode](wiki:Diode))
2. **Car alternators:** built-in rectifier and regulator, but they need **high speed** (*rule of
   thumb:* about 1,500+ rpm — step-up pulleys or belts for wind, water or pedals) and a
   **battery connected** to power their field — they are not self-starting. The field draws
   about 3 A, which wastes a lot at low power.
   ([*Alternator and Regulator Servicing*, p. 11](lib:alternator-and-regulator-servicing#page=11);
   [🖼️ how an alternator makes current](lib:alternator-and-regulator-servicing#page=8);
   [🖼️ testing the rotor](lib:alternator-and-regulator-servicing#page=18))
3. **Induction motors (ordinary AC motors) as generators:** drive it **about 1–5% faster than
   its synchronous speed** — e.g. a motor rated **1725 rpm** (1800 synchronous) is driven at
   about **1820–1890 rpm**. Output rises with the extra speed.
   ([DOE *Microhydropower Handbook* Vol 1 Pt 2, p. 54](lib:doe-microhydropower-handbook-vol-1-part-2#page=54))
   On its own (not tied to the grid) it needs **capacitors** across the windings to excite it.
   **Sources disagree here:** the DOE handbook (same page) and the European hydro guide say an
   induction generator can't run cut off from the grid
   ([ESHA *Layman's Guidebook* Pt 2, p. 30](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=30)),
   while village hydro schemes run them off-grid with a capacitor bank and controller
   ([Practical Action *Micro-Hydro O&M*, p. 23](lib:operation-and-maintenance-of-community-micro#page=23)).
   Expect some trial and error.
   - *Rule of thumb:* start with run capacitors whose current at rated voltage roughly matches
     the motor's no-load current, then trim until voltage and frequency are right. Use
     **AC motor-run (film) capacitors**, never electrolytic start capacitors.
   - Expect about **70–80% of the motor's rating** as output *(rule of thumb)*. Needs a
     **ballast (dump) load or controller** so voltage doesn't swing as loads switch. Aging
     capacitors make frequency creep up; a capacitor running hotter than the others is
     failing — feel them once a month. Too many capacitors overheat the generator.
     ([Practical Action, pp. 23–26](lib:operation-and-maintenance-of-community-micro#page=23))
4. **Build a permanent-magnet alternator** from magnets and magnet wire for a wind turbine or
   slow water wheel — full plans in Hugh Piggott's *Axial Flux Alternator* and *PMG
   Construction Manual*. His PMG makes about **180 W (15 A at 12 V) at only 420 rpm** — slow
   enough to drive directly from blades.
   ([Piggott *PMG Construction Manual*, p. 4](lib:pmg-construction-manual-piggott#page=4);
   [🖼️ exploded drawing of the PMG](lib:pmg-construction-manual-piggott#page=2);
   [🖼️ parts of a small wind generator](lib:small-wind-systems-for-battery-charging#page=12);
   [Small wind turbine](wiki:Small_wind_turbine))

**Rules for any homemade generator:**
- **Never let a wind or water generator run with no load** — it overspeeds and can destroy
  itself. Use a **diversion (dump-load) charge controller**, not a solar controller (solar
  controllers disconnect the source). The dump load can be light bulbs or a heating element —
  a water-heater element puts the spare power to use.
  ([DFID-ITDG *Small Wind Systems*, p. 16](lib:small-wind-systems-for-battery-charging#page=16);
  [DOE *Wind Power for Farms*, p. 122](lib:wind-power-for-farms-homes#page=122);
  [🖼️ a whole system with its dump load](lib:small-wind-systems-for-battery-charging#page=19);
  [Charge controller](wiki:Charge_controller))
- **Watch the battery voltage.** Over about 14 V on a 12 V battery means it's charging too hard
  — use more power or divert it.
  ([Piggott *Axial Flux*, p. 41](lib:how-to-build-a-wind-turbine-axial-flux#page=41))
- **Flashing the field:** if a generator won't build up voltage, it may have lost its residual
  magnetism. The Army 3 kW set does it with **two 1.5 V flashlight batteries** touched
  momentarily to the regulator terminals
  ([TM 5-6115-271-14, p. 73](lib:tm-5-6115-271-14#page=73)); village hydro operators use a
  **6 V or 12 V battery** on brush-type generators
  ([Practical Action, p. 26](lib:operation-and-maintenance-of-community-micro#page=26)). Use the
  lowest voltage that works, touch it only briefly, then try again. *(Rule of thumb)*
- **Creek power in Oregon:** under Oregon law all water belongs to the public — owning
  creek frontage doesn't by itself give you the right to divert it, and a hydro project needs
  a license
  ([OWRD *Water Rights in Oregon*, p. 7](lib:oregon-owrd-water-rights-in-oregon#page=7);
  [OWRD *Minor Hydroelectric License Guide*, p. 1](lib:oregon-owrd-minor-hydroelectric-license-instruction#page=1)).
  Screen your intake so fish aren't pulled in
  ([ODFW *Fish Screening Criteria*](lib:oregon-odfw-fish-screening#page=1)).
- Old method: the 1939 North Dakota circular shows turning a **car generator** into a 6-volt
  wind charger ([🖼️ drawing](lib:homemade-six-volt-wind-electric#page=8)), and the DOE *Wind Power
  for Farms* handbook covers matching any generator to a rotor.

[Induction generator](wiki:Induction_generator), [Car alternator](wiki:Alternator_(automotive)).
More pictures: [Micro hydro](wiki:Micro_hydro), [Rectifier](wiki:Rectifier).

📚 **Go deeper:** [Piggott *PMG Construction Manual*](lib:pmg-construction-manual-piggott#page=2) — build a slow-speed permanent-magnet generator; [DFID-ITDG *Small Wind Systems*](lib:small-wind-systems-for-battery-charging#page=16) — controllers, dump loads and batteries; [Practical Action *Micro-Hydro O&M*](lib:operation-and-maintenance-of-community-micro#page=23) — running and fixing a small hydro plant; [North Dakota *Homemade Six-Volt Wind-Electric Plants*](lib:homemade-six-volt-wind-electric#page=7) — 1939 car-generator wind charger.

## 🛠️ Reusing a generator for water or wind power

When the gasoline and diesel are gone, a portable generator still holds two valuable machines: an
**engine** and a **generator head** (the part that makes electricity). There are two ways to keep
using them.

**1. Keep the whole set and change the fuel.** FEMA's wood-gas plans say stationary engines on wood
gas "run electric generators, pumps, and industrial equipment"
([FEMA *Wood Gas Generator*, p. 19](lib:fema-construction-of-a-simplified-wood-gas#page=19)). A
generator sits still, so it needs a **gas cooler and a second filter** that a moving vehicle wouldn't,
and hot gas costs power: about 1% for every 10 °F above 70 °F
([p. 28](lib:fema-construction-of-a-simplified-wood-gas#page=28)). Most portable generators have
engines of 15 hp or less; for those FEMA says to use a **6-inch fire tube** with a narrowed throat
([p. 67](lib:fema-construction-of-a-simplified-wood-gas#page=67)). The rest (building it, and the
carbon monoxide danger) is in the [Fuel guide](guide:FUEL-GUIDE).

**2. Take the generator head off and turn it with water or wind.** The rest of this section is about
that.

### What's inside: two kinds of portable generator

**Standard generators** (the open-frame kind) have a **generator head** bolted to the engine:
- A spinning **rotor** makes the magnetic field and a still **stator** around it makes the power, so
  the output comes straight off the stator wires
  ([NEETS 5, pp. 64–66](lib:neets-module-05-generators-and-motors#page=64);
  [🖼️ rotating-field alternator with exciter](lib:neets-module-05-generators-and-motors#page=67)).
- The rotor's field is fed through **brushes and slip rings**, or with no brushes at all: a small
  **exciter** and **diodes spinning on the shaft** feed it
  ([ESHA *Small Hydro* Pt 2, p. 31](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=31);
  [🖼️ brushless alternator](lib:tm-9-8000-principles-of-automotive-vehicles#page=325)). The Army's
  3 kW set is the brushless kind; its book gives the normal winding resistances
  ([TM 5-6115-271-14, p. 26](lib:tm-5-6115-271-14#page=26)).
- A **voltage regulator (AVR)** holds the voltage steady by changing the field's strength, because the
  speed has to stay fixed for the frequency
  ([NEETS 5, p. 78](lib:neets-module-05-generators-and-motors#page=78)). Many cheap heads instead use
  a **capacitor** on an extra winding to make their field *(rule of thumb)*.
- **Speed sets the frequency:** a 2-pole head must turn **3,600 rpm** for 60 Hz, a 4-pole head 1,800 rpm
  ([NEETS 5, p. 76](lib:neets-module-05-generators-and-motors#page=76);
  [🖼️ 2-pole vs 8-pole](lib:neets-module-05-generators-and-motors#page=77)). Almost all portable sets
  are 2-pole, 3,600 rpm *(rule of thumb)*.
- **Most heads have only one bearing.** The other end of the rotor is bolted onto the engine's
  crankshaft, so a head taken off the engine needs a **new shaft end and bearing** before a belt can
  drive it *(rule of thumb; the hydro handbook notes horizontal generators "usually have a single
  bearing",
  [DOE *Microhydropower Handbook* Vol 1 Pt 2, p. 57](lib:doe-microhydropower-handbook-vol-1-part-2#page=57))*.

**Inverter generators** (the quiet, closed-case kind). There is **no manual for one in the library**;
this is how they are generally built *(rule of thumb)*:
- The engine's **flywheel is the rotor**: a ring of magnets spinning around a stator with many poles.
  It makes three-phase AC whose voltage and frequency both rise with speed, and there may be several
  separate sets of windings (for the inverter's own power, for battery charging).
- A **rectifier** turns that into DC, and the **inverter board** turns the DC into steady 120-volt,
  60 Hz power. The board usually also works the throttle and needs signals from the engine, so it
  rarely works without its engine.
- The magnet-and-stator part is the same family as the **flywheel alternator** on small engines
  ([MAVCC *Small Engine Repair*, p. 370](lib:small-engine-repair-two-stroke#page=370);
  [🖼️ flywheel alternator parts](lib:small-engine-repair-two-stroke#page=373)), and it behaves like any
  permanent-magnet alternator: **voltage rises in step with speed**
  ([Piggott *Axial Flux Alternator*, p. 15](lib:how-to-build-a-wind-turbine-axial-flux#page=15)).

### Which parts are worth saving

| Part | Best use | Watch out for |
|---|---|---|
| **Magnet alternator** (from an inverter generator) | Charging batteries from a **slow** water wheel or wind rotor: rectify it to DC, then a diversion controller | Test it first (below). Keep its magnets away from iron and don't drop it |
| **Wound-field generator head** (standard generator) | A **fast** turbine, like a Pelton wheel on a good drop, belted up to its speed | Wants 3,600 rpm; voltage holds but frequency swings with the load |
| **Engine** | Wood gas (above), or turning a pump, mill or saw directly | Same care as any engine (top of this guide) |
| **Voltage regulator, capacitors** | Stay with the generator head | Discharge capacitors before touching |
| **Inverter board** | Rarely reusable without its engine; keep for parts | **Can hold a deadly charge** |
| Bearings, pulleys, frame, outlets, breaker, wire | Your hydro or wind build | Check bearings (below) |

### Taking it apart safely

1. **Drain the fuel**, unplug the spark plug wire, and work outdoors or with the doors open
   *(rule of thumb)*.
2. **Discharge every capacitor** (inverter board, voltage regulator, capacitor-excited heads): the charge
   left in capacitors "is, in many cases, sufficient to cause a lethal shock." Use a **shorting probe**
   with its ground clip on first, touch each terminal several times, and keep your hands off the metal
   ([NEETS 21, pp. 32–33](lib:neets-module-21#page=32);
   [🖼️ shorting probe](lib:neets-module-21#page=33)). Short a stored capacitor's terminals with a wire;
   "CHARGED CAPACITORS CAN KILL" ([p. 34](lib:neets-module-21#page=34)).
3. **Photograph and tag every wire**, and **punch-mark the frame and end bells** so they go back the
   same way ([Navy *Construction Electrician*, p. 255](lib:us-navy-construction-electrician-basic#page=255);
   [🖼️ punch marks](lib:us-navy-construction-electrician-basic#page=255)).
4. **Turn the shaft by hand** before opening anything: binding means a bent shaft, bad bearings or
   debris (same page).
5. **Taking a magnet flywheel off:** hold it with a holding tool (the nut's thread direction depends on
   which way the engine turns), then use a **puller**, not a hammer: "Too much hammering will jar the
   magnetism out" ([AAVIM *Small Engines* Vol 2, pp. 58–59](lib:small-engines-care-operation-maintenance#page=58);
   [🖼️ flywheel pullers](lib:small-engines-care-operation-maintenance#page=59)). Don't drop it, store it
   away from iron, and pick metal chips off the magnets
   ([p. 60](lib:small-engines-care-operation-maintenance#page=60);
   [MAVCC, p. 374](lib:small-engine-repair-two-stroke#page=374)).
6. **Pulling a rotor out of a stator:** lift the brushes first, support the rotor **only by its shaft**,
   and slide thin **cardboard** into the gap to protect the windings
   ([Navy *Construction Electrician*, p. 256](lib:us-navy-construction-electrician-basic#page=256);
   [Kuphaldt Vol 6, p. 174](lib:lessons-in-electric-circuits-vol-6-experiments-kuphaldt#page=174)).
7. **Bearings:** leave good ones on the shaft; pull with the puller on the **inner** race (see "Electric
   motors: testing and repair" above; [Navy *Electrician's Mate*, p. 224](lib:navy-electricians-mate-3-and-2#page=224)).

### Testing what you salvaged

- **Spin it and measure.** Turn the shaft with a drill, a lathe or a rope at a speed you can count, and
  read the AC volts across the output wires. On a magnet alternator the voltage goes up in proportion to
  speed, so one reading tells you what it makes at any rpm
  ([Piggott, p. 36](lib:how-to-build-a-wind-turbine-axial-flux#page=36)).
- **Speed from frequency:** Hz = rpm × number of poles ÷ 120, so a multimeter that reads Hz is a
  tachometer (same page).
- **DC after the rectifier** ≈ 1.4 × the AC reading, minus about 1.5 V (same page). To charge a 12 V
  battery you need about 14 V DC.
- **Short two output wires** and turn it: a good one becomes stiff but smooth; "If it trembles as you
  turn it then there is a fault" ([Piggott *PMG Manual*, p. 42](lib:pmg-construction-manual-piggott#page=42)).
  No meter? A 3-volt flashlight bulb across two wires will glow when you turn it
  ([p. 40](lib:pmg-construction-manual-piggott#page=40)).
- **A wound-field head** makes little or nothing until its field is fed: spin it with the field wires on a
  **6-volt battery** ([Kuphaldt Vol 6, pp. 174–175](lib:lessons-in-electric-circuits-vol-6-experiments-kuphaldt#page=174)),
  or flash the field as described in "Motors as generators" above.
- **With an ohmmeter:** slip ring to shaft should read open (otherwise the rotor is grounded); ring to ring
  should match the spec (open = broken winding, low = shorted); each diode reads low one way and high the
  other. **Never test diodes with a 110-volt test lamp**
  ([*Alternator Servicing*, pp. 17–19](lib:alternator-and-regulator-servicing#page=17)). The Army's
  brushless set: flash the field; if the voltage holds under load the stator and rotor are good; if not,
  test the diodes on the exciter rotor ([TM 5-6115-271-14, p. 95](lib:tm-5-6115-271-14#page=95)).
- **Megger the windings** to the frame (minimums under "Electric motors" above). A head rated for standby
  use "may not hold up under continuous operation at full load", so run it well below its rating
  ([DOE Vol 1 Pt 2, p. 59](lib:doe-microhydropower-handbook-vol-1-part-2#page=59)).

### Matching it to a water wheel or wind rotor

- **The 3,600-rpm head is the hard part.** "The 2-pole generator with a speed of 3600 rpm is too high for
  practical use with a microhydropower system"; 1,800-rpm heads are the usual choice
  ([NRCan *Micro-Hydropower Systems*, p. 24](lib:nrcan-micro-hydropower-systems-a-buyers#page=24)).
- **Water:** a Pelton wheel turns fastest on a high drop. Its buckets work best at about half the speed of
  the jet ([ESHA Pt 2, p. 20](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=20)), so an
  8-inch Pelton on 100 ft of drop turns about **1,060 rpm**, and needs about **3.4 to 1** to drive a
  3,600-rpm head *(arithmetic)*. Many small turbines run under 400 rpm and need a speed increaser
  ([p. 28](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=28)). Water wheels are slower
  still ([NRCan, p. 23](lib:nrcan-micro-hydropower-systems-a-buyers#page=23)).
- **Wind:** an 8-ft rotor in a 7 mph wind turns about **167 rpm**
  ([Piggott, p. 9](lib:how-to-build-a-wind-turbine-axial-flux#page=9)); a 3,600-rpm head would need about
  22 to 1 *(arithmetic)*, which isn't practical. "Almost every small wind generator on the market uses a
  directly driven permanent magnet generator"
  ([DFID-ITDG *Small Wind Systems*, p. 12](lib:small-wind-systems-for-battery-charging#page=12)): use the
  magnet alternator, or build Piggott's (above).
- **Belts:** the speed ratio is generator rpm ÷ turbine rpm
  ([DOE Vol 1 Pt 2, p. 81](lib:doe-microhydropower-handbook-vol-1-part-2#page=81)); pulley diameter × rpm
  is the same on both shafts ([Illinois *Electric Motors for Farm Use*, p. 17](lib:electric-motors-for-farm-use#page=17)).
  **V-belts** are the best choice and slip instead of breaking things if the turbine jams
  ([DOE, p. 85](lib:doe-microhydropower-handbook-vol-1-part-2#page=85)). Don't go below the smallest pulley
  for the belt size, about 3 in for an A belt and 5.4 in for a B
  ([p. 86](lib:doe-microhydropower-handbook-vol-1-part-2#page=86);
  [🖼️ table](lib:doe-microhydropower-handbook-vol-1-part-2#page=87)). Size the belts for 1.4–1.5 times
  the turbine's power ([p. 89](lib:doe-microhydropower-handbook-vol-1-part-2#page=89)), make the distance
  between shafts adjustable because belts stretch, and expect to lose 3–6%, up to 10% if loose
  ([pp. 95–96](lib:doe-microhydropower-handbook-vol-1-part-2#page=95)). Don't mix old and new belts, and
  mark the generator and its base so it goes back in line
  ([Practical Action *Micro-Hydro O&M*, pp. 19–20](lib:operation-and-maintenance-of-community-micro#page=19)).
- **Mounting:** a **car wheel-bearing hub** makes a good bearing for a homemade alternator
  ([Piggott, p. 15](lib:how-to-build-a-wind-turbine-axial-flux#page=15);
  [🖼️ mounting it](lib:how-to-build-a-wind-turbine-axial-flux#page=18)). Driving the shaft directly needs
  careful alignment and a coupling that flexes a little
  ([Illinois, p. 17](lib:electric-motors-for-farm-use#page=17)).
- **Runaway:** with no load, a turbine and generator can reach **two to three times** normal speed
  ([DOE Vol 1 Pt 2, p. 61](lib:doe-microhydropower-handbook-vol-1-part-2#page=61)), and a disconnected magnet
  alternator's voltage "may become dangerously high"
  ([Piggott, p. 37](lib:how-to-build-a-wind-turbine-axial-flux#page=37)). Always keep the dump load on
  (rules above).

![A big pulley on a turbine turning 1,060 rpm drives, by V-belt, a small pulley on a generator head at 3,600 rpm; the turbine's pulley is about 3.4 times the diameter of the generator's](img:ENGINES-AND-MOTORS-GUIDE/belt-speed-matching.svg)
*Pulley diameter × rpm is the same on both shafts (a diagram drawn for this guide).*

### Hooking it up

- **To charge batteries:** a three-phase rectifier (six diodes, one pair per wire) turns the output into DC
  ([Kuphaldt Vol 3, p. 122](lib:lessons-in-electric-circuits-vol-3#page=122);
  [🖼️ three-phase bridge](lib:lessons-in-electric-circuits-vol-3#page=122)), then a diversion controller and
  the battery. For a long wire run, rectify to a high voltage and step it down at the battery
  ([NCAT *Micro-Hydro*, p. 18](lib:ncat-attra-micro-hydro#page=18)).
- **For heat and lights only,** use the AC as it comes: heating doesn't care about frequency
  ([DOE Vol 1 Pt 1, p. 153](lib:doe-microhydropower-handbook-vol-1-part-1#page=153)); hot water is the best
  place for the spare power (see [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE)).
- **Not for motors or electronics** unless something holds the frequency steady: "Fluctuating frequency
  will destroy small motors and solid state equipment"
  ([DOE Vol 1 Pt 2, p. 56](lib:doe-microhydropower-handbook-vol-1-part-2#page=56)).
- **A three-phase head on one phase** gives only about a third of its rating (same page).
- **What to expect:** magnet generators are over 80% efficient
  ([NRCan, p. 25](lib:nrcan-micro-hydropower-systems-a-buyers#page=25)); the whole system is the turbine
  × the belt × the generator ([ESHA Pt 2, p. 26](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=26)).
  The water sets the limit: watts ≈ gallons per minute × feet of drop ÷ 10 (see the creek hydro section of
  the [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE)), and Oregon's water law applies (above).

![Wiring for charging a battery from a salvaged magnet alternator: three wires into a six-diode rectifier, DC positive and negative to the battery with a fuse right at its positive post, and a diversion controller across the battery that sends spare power to a water-heater element dump load](img:ENGINES-AND-MOTORS-GUIDE/charging-from-a-salvaged-alternator.svg)
*Rectify, fuse the battery at its + post, and let a diversion controller send spare power to a dump load (a diagram drawn for this guide).*

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Small gas engines**
- The four strokes — [🖼️ Navy *Construction Mechanic*, p. 23](lib:navy-construction-mechanic-3-and-2#page=23); [Four-stroke engine](wiki:Four-stroke_engine)
- Valves on 4-stroke and 2-stroke engines — [🖼️ AAVIM, p. 110](lib:small-engines-care-operation-maintenance#page=110); [Two-stroke engine](wiki:Two-stroke_engine)
- Fuel, spark and compression checks — [🖼️ MAVCC, p. 596](lib:small-engine-repair-two-stroke#page=596); [🖼️ p. 599](lib:small-engine-repair-two-stroke#page=599); [🖼️ p. 602](lib:small-engine-repair-two-stroke#page=602)
- Float carburetors, floats and float height — [🖼️ AAVIM, p. 91](lib:small-engines-care-operation-maintenance#page=91); [🖼️ p. 93](lib:small-engines-care-operation-maintenance#page=93); [🖼️ MAVCC, p. 525](lib:small-engine-repair-two-stroke#page=525); [Carburetor](wiki:Carburetor)
- Flywheel magneto, cut away — [🖼️ AAVIM, p. 49](lib:small-engines-care-operation-maintenance#page=49); [Magneto](wiki:Ignition_magneto)
- Sheared flywheel key — [🖼️ AAVIM, p. 59](lib:small-engines-care-operation-maintenance#page=59); [Flywheel](wiki:Flywheel)
- Starter-rope knots and the recoil starter — [🖼️ AAVIM, p. 14](lib:small-engines-care-operation-maintenance#page=14); [🖼️ p. 15](lib:small-engines-care-operation-maintenance#page=15); [🖼️ p. 16](lib:small-engines-care-operation-maintenance#page=16)
- Reading a spark plug — [🖼️ Navy *Construction Mechanic*, p. 208](lib:navy-construction-mechanic-3-and-2#page=208); [🖼️ p. 209](lib:navy-construction-mechanic-3-and-2#page=209); [Spark plug](wiki:Spark_plug)
- How a governor works — [🖼️ AAVIM, p. 101](lib:small-engines-care-operation-maintenance#page=101); [Governor](wiki:Governor_(device))

**Diesel engines**
- Gasoline and diesel strokes compared — [🖼️ Navy *Construction Mechanic*, p. 94](lib:navy-construction-mechanic-3-and-2#page=94); [Diesel engine](wiki:Diesel_engine)
- Injector valve and cleaning its spray holes — [🖼️ p. 109](lib:navy-construction-mechanic-3-and-2#page=109); [🖼️ p. 131](lib:navy-construction-mechanic-3-and-2#page=131); [Fuel injection](wiki:Fuel_injection)

**Saws and axes**
- Parts of a saw chain and cutter types — [🖼️ USFS, p. 26](lib:usfs-chain-saw-and-crosscut-saw-training#page=26); [Saw chain](wiki:Saw_chain)
- Filing angles and file position — [🖼️ USFS, p. 33](lib:usfs-chain-saw-and-crosscut-saw-training#page=33); [🖼️ MAVCC *Chain Saw Repair*, p. 36](lib:chain-saw-repair-mavcc#page=36)
- Depth gauges — [🖼️ USFS, p. 32](lib:usfs-chain-saw-and-crosscut-saw-training#page=32); [🖼️ p. 34](lib:usfs-chain-saw-and-crosscut-saw-training#page=34)
- Chain tension, right and wrong — [🖼️ MAVCC *Chain Saw Repair*, p. 40](lib:chain-saw-repair-mavcc#page=40)
- Bar rail wear — [🖼️ USFS, p. 29](lib:usfs-chain-saw-and-crosscut-saw-training#page=29)
- The kickback zone — [🖼️ USFS, p. 37](lib:usfs-chain-saw-and-crosscut-saw-training#page=37); [Chainsaw](wiki:Chainsaw)
- Crosscut teeth, rakers and shavings — [🖼️ *Saws That Sing*, p. 14](lib:usfs-saws-that-sing#page=14); [🖼️ *Crosscut Saw Manual*, p. 16](lib:usfs-crosscut-saw-manual#page=16); [Crosscut saw](wiki:Crosscut_saw)
- Jointing a crosscut saw — [🖼️ *Crosscut Saw Manual*, p. 14](lib:usfs-crosscut-saw-manual#page=14)
- Parts of an ax — [🖼️ *An Ax to Grind*, p. 9](lib:usfs-an-ax-to-grind#page=9); [Axe](wiki:Axe)

**Generators**
- Transfer switch — [🖼️ FEMA P-1019, p. 125](lib:emergency-power-systems-for-critical-facilities#page=125); [Transfer switch](wiki:Transfer_switch)
- Grounding a generator — [🖼️ FM 5-424, p. 49](lib:us-army-fm-5-424#page=49); [🖼️ Navy *Construction Electrician*, p. 71](lib:us-navy-construction-electrician-basic#page=71); [🖼️ p. 72](lib:us-navy-construction-electrician-basic#page=72)

**Electric motors**
- Induction motor, cut away and taken apart — [🖼️ TM 5-683, p. 38](lib:tm-5-683-electrical-interior-facilities#page=38); [🖼️ p. 40](lib:tm-5-683-electrical-interior-facilities#page=40); [Induction motor](wiki:Induction_motor)
- Capacitor-start motor and centrifugal switch — [🖼️ Illinois, p. 11](lib:electric-motors-for-farm-use#page=11); [🖼️ Navy *Construction Electrician*, p. 237](lib:us-navy-construction-electrician-basic#page=237); [Centrifugal switch](wiki:Centrifugal_switch)
- Bearings: puller, greasing, yarn-packed — [🖼️ Navy EM, p. 225](lib:navy-electricians-mate-3-and-2#page=225); [🖼️ TM 5-683, p. 45](lib:tm-5-683-electrical-interior-facilities#page=45); [🖼️ Illinois, p. 23](lib:electric-motors-for-farm-use#page=23)
- Brushes and commutator — [🖼️ Navy EM, p. 227](lib:navy-electricians-mate-3-and-2#page=227); [🖼️ p. 229](lib:navy-electricians-mate-3-and-2#page=229); [🖼️ p. 232](lib:navy-electricians-mate-3-and-2#page=232); [Commutator](wiki:Commutator_(electric))
- Armature tests and the growler — [🖼️ Navy EM, p. 239](lib:navy-electricians-mate-3-and-2#page=239); [🖼️ p. 240](lib:navy-electricians-mate-3-and-2#page=240)

**Motors as generators**
- Car alternator — [🖼️ *Alternator Servicing*, p. 8](lib:alternator-and-regulator-servicing#page=8); [Car alternator](wiki:Alternator_(automotive))
- Piggott's permanent-magnet generator, exploded — [🖼️ p. 2](lib:pmg-construction-manual-piggott#page=2)
- Small wind system with charge controller and dump load — [🖼️ DFID-ITDG, p. 12](lib:small-wind-systems-for-battery-charging#page=12); [🖼️ p. 19](lib:small-wind-systems-for-battery-charging#page=19); [Small wind turbine](wiki:Small_wind_turbine)
- 1939 car-generator wind charger — [🖼️ North Dakota, p. 8](lib:homemade-six-volt-wind-electric#page=8)

**Reusing a generator for water or wind**
- Inside a generator head: rotating field, exciter and slip rings — [🖼️ NEETS 5, p. 67](lib:neets-module-05-generators-and-motors#page=67); brushless with rotating diodes, [🖼️ TM 9-8000, p. 325](lib:tm-9-8000-principles-of-automotive-vehicles#page=325); a brushless head taken apart, [🖼️ TM 5-6115, p. 140](lib:tm-5-6115-271-14#page=140)
- Flywheel alternator (magnets in the flywheel) — [🖼️ MAVCC, p. 373](lib:small-engine-repair-two-stroke#page=373); flywheel pullers, [🖼️ AAVIM, p. 59](lib:small-engines-care-operation-maintenance#page=59)
- Capacitor shorting probe — [🖼️ NEETS 21, p. 33](lib:neets-module-21#page=33)
- Three-phase rectifier bridge — [🖼️ Kuphaldt Vol 3, p. 122](lib:lessons-in-electric-circuits-vol-3#page=122)
- Pelton wheel driving a generator directly — [🖼️ NRCan, p. 25](lib:nrcan-micro-hydropower-systems-a-buyers#page=25); belt and pulley sizes, [🖼️ DOE, p. 87](lib:doe-microhydropower-handbook-vol-1-part-2#page=87); V-belt drives, [🖼️ Illinois, p. 17](lib:electric-motors-for-farm-use#page=17)
- Alternator on a car wheel hub — [🖼️ Piggott, p. 18](lib:how-to-build-a-wind-turbine-axial-flux#page=18); [Pelton wheel](wiki:Pelton_wheel); [Engine–generator](wiki:Engine–generator)

## 🔗 Related guides

- [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — where the dump load's spare power can go: hot water and other stores
- [Fuel guide](guide:FUEL-GUIDE) — storing, testing and rescuing gasoline and diesel, and
- [Salvage: Useful Things From Broken Things](guide:SALVAGE-GUIDE) — what to take from dead washers, freezers and cars, and what to make with it
- [How the Power Grid Works](guide:POWER-GRID-GUIDE) — two generators in step, and a generator feeding a small community grid
- [Dams, Weirs, Ditches & Ponds](guide:DAMS-DITCHES-GUIDE) — water wheels, millponds and races
- [Vehicles, Tractors & Heavy Equipment](guide:VEHICLES-EQUIPMENT-GUIDE) — cars, trucks and tractors, hydraulics, air brakes and electric vehicles
  getting fuel out of station tanks.
- [Blacksmithing and hand tools](guide:BLACKSMITHING-GUIDE) — sharpening axes and saws, making
  and repairing tools.
- [Make-do household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — repairs and substitutes around
  the home.
- [Radio guide](guide:RADIO-GUIDE) — keeping radios powered from batteries and generators.
- [EMP and solar storm guide](guide:EMP-GUIDE) — what an EMP or solar storm would really do to
  vehicles and electronics, and checking generators afterward.
- [Illinois Valley start here](guide:ILLINOIS-VALLEY-START-HERE) — the local picture and
  where everything is on the drive.
- [Heat into Work and Power](guide:HEAT-INTO-POWER-GUIDE) — steam and hot-air engines, and stove-top generators, when there is no fuel for an engine

---

*Measurements and settings in old manuals are fine for methods; for your specific engine,
motor or generator, its own nameplate and manual come first.*
