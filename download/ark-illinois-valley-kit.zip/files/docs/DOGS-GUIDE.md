# 🐕 Dogs: Guarding Stock, Herding, Hunting and Care

How to keep working dogs with no store, no vet and no kibble: livestock guardian dogs against coyotes, bears and
cougars, herding dogs, bird dogs and the Oregon law on hunting with dogs, watchdogs, feeding on meat, grain and scraps,
the fish and foods that kill dogs, kennels, breeding and puppies, vaccines, first aid, humane training and a humane end.
The dog books are in `Southern-Oregon\Animals\Dogs`: the Army's *War Dogs* manual (TM 10-396, 1943) and *Military
Working Dogs* (FM 3-19.17, 2005), Wickham's 1891 shepherd-dog manual, Miller's 1919 *American Hunting Dog* and a
parvovirus sheet. The guardian-dog and predator books are in `Animals\Planning-Predators-Toxic-Plants`, no-vet medicine
and euthanasia in `Animals\Veterinary`, and the hunting and trapping law in `Hunting` and `Trapping`. Old dog books are
full of poisons and beatings; this guide keeps their good parts and lists the rest under "Old advice in the library to
ignore".

> ### The short version
> - **Never let a dog eat raw salmon, steelhead or trout.** Salmon poisoning kills most dogs that aren't treated.
>   **Cook all fish, meat and offal** before dogs get it — raw offal also spreads tapeworm cysts to people
>   ([ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34);
>   [FDA, p. 156](lib:fda-bad-bug-book#page=156); [Zoonoses, p. 119](lib:zoonoses-diseases-animals-give-people-cvm#page=119)).
> - **Vaccinate now, while vets exist:** parvo from **6–8 weeks**, repeated every **3–4 weeks to 16 weeks**, a booster at
>   1 year, then every **3 years**; and rabies. Parvo lives in soil for up to **7 months**
>   ([parvo sheet, pp. 3–4](lib:canine-parvovirus#page=3); [*No Animal Doctor*, p. 272](lib:where-there-is-no-animal-doctor-cvm-2024#page=272)).
> - **Raise a guardian pup with the stock from 7–8 weeks, not in the house.** Where bears and cougars live, plan
>   **1–2 dogs per 50 ewes or does** — and still shut the stock in at night: **cougars kill dogs**
>   ([USDA AIB 588, pp. 12, 29](lib:livestock-guarding-dogs-usda-aib588#page=12); [Texas A&M, p. 6](lib:livestock-guardian-dogs-overview#page=6)).
> - **Llamas and donkeys don't stop cougars or bears** ([UC ANR 8598, p. 5](lib:livestock-protection-tools#page=5)).
> - **Oregon law: no dogs on any game mammal except western gray squirrel, and none on bear or cougar.** Bird dogs are
>   legal, and so are hounds on raccoon, bobcat and fox in their seasons ([ODFW, p. 21](lib:odfw-2026-big-game-hunting-regulations#page=21);
>   [furbearer regs, p. 6](lib:oregon-furbearer-trapping-and-hunting-regulations#page=6)).
> - **Train with praise, patience and timing.** "A dog never is slapped with the hand or struck with the leash"
>   ([TM 10-396, p. 60](lib:war-dogs-care#page=60)).
> - **No food for 2 hours before or after hard work, and feed big dogs twice a day** — bloat kills fast
>   ([FM 3-19.17, p. 67](lib:military-working-dogs#page=67)).
> - **Food is the real cost:** a 50-lb working dog eats about **1½ lb of meat a day**, roughly **550 lb a year**, plus
>   grain ([TM 10-396, p. 41](lib:war-dogs-care#page=41); *arithmetic*). Keep only the dogs that earn it.

---

## 🐕 Which dog for which job

| Job | Kind of dog | What to expect |
|---|---|---|
| Guard stock day and night | [Livestock guardian dog](wiki:Livestock_guardian_dog) | Lives with the stock and acts on its own: "not a herding dog but rather a full-time member of the flock" ([AIB 588, p. 6](lib:livestock-guarding-dogs-usda-aib588#page=6)) |
| Move stock | [Herding dog](wiki:Herding_dog): collie, border collie, Australian shepherd | Moves sheep by "biting, chasing, or barking" to voice and hand signals; "generally not left alone with the sheep" ([AIB 588, p. 7](lib:livestock-guarding-dogs-usda-aib588#page=7)) |
| Birds for the pot | [Gun dog](wiki:Gun_dog): pointers, setters, spaniels, retrievers | Finds, flushes and fetches; see the law below |
| Warning | Any alert dog in the house and yard | "One of the best security measures" ([WSDA, p. 1](lib:general-farm-security#page=1)) |

Don't ask one dog to do every job. Breeds that hunt or herd "rarely become effective" guardians ([Texas A&M, p. 5](lib:livestock-guardian-dogs-overview#page=5)),
and "the working dog should not be allowed to hunt" — a sheep dog that chases rabbits is gone when you need it
([Wickham, p. 91](lib:practical-training-of-the-shepherd-dog#page=91)).

## 🛡️ Guardian dogs: breeds and choosing a pup

A guardian dog "stays with sheep without harming them and aggressively repels predators", because it was raised with
them from puppyhood ([AIB 588, p. 6](lib:livestock-guarding-dogs-usda-aib588#page=6)); it works for goats, cattle and
pigs too ([p. 5](lib:livestock-guarding-dogs-usda-aib588#page=5)).

| Breed | What the books say |
|---|---|
| [Great Pyrenees](wiki:Pyrenean_Mountain_Dog) | Most common (57% of 763 dogs surveyed); matures earliest; hurts stock least; **83%** of yearlings rated good ([AIB 588, pp. 7, 9](lib:livestock-guarding-dogs-usda-aib588#page=9)). Gentlest with people, but the long coat needs grooming in heat ([Texas A&M, p. 5](lib:livestock-guardian-dogs-overview#page=5)) |
| [Anatolian Shepherd](wiki:Kangal_Shepherd_Dog) | Matures slowly (18–30 months); only **38%** of yearlings rated good, mostly for hurting sheep ([AIB 588, pp. 7, 9](lib:livestock-guarding-dogs-usda-aib588#page=9)) |
| [Akbash](wiki:Akbash), [Maremma](wiki:Maremmano-Abruzzese_Sheepdog), [Karakachan](wiki:Karakachan_dog) | Akbash: "one of the most aggressive and protective"; Maremma and Karakachan stay close to the herd ([Texas A&M, p. 5](lib:livestock-guardian-dogs-overview#page=5)) |
| [Komondor](wiki:Komondor) | Corded coat collects burrs, so most owners clip it each spring. Bit people most: **17%**, against 4% of Pyrenees ([AIB 588, p. 24](lib:livestock-guarding-dogs-usda-aib588#page=24)) |
| [Kuvasz](wiki:Kuvasz), Shar Planinetz, Kangal, mixed-breed | Also used ([AIB 588, pp. 8–9](lib:livestock-guarding-dogs-usda-aib588#page=8); [UC ANR 8598, p. 5](lib:livestock-protection-tools#page=5)). Navajo shepherds' mongrels succeed through "the manner in which they are reared" ([AIB 588, p. 9](lib:livestock-guarding-dogs-usda-aib588#page=9)) |

**Choosing a pup:** buy from someone who knows the dogs, from **working lines, not pet lines** ([AIB 588, p. 9](lib:livestock-guarding-dogs-usda-aib588#page=9);
[UC ANR 8598, p. 5](lib:livestock-protection-tools#page=5)). Pick one that is **self-confident and alert, not timid**,
and barks from suspicion, not fear; good guardians show it by **3–8 months**. Male or female makes no difference
([AIB 588, p. 10](lib:livestock-guarding-dogs-usda-aib588#page=10)). Be patient: "it takes 18 to 24 months for puppies
to become effective guardians" ([Texas A&M, p. 2](lib:livestock-guardian-dogs-overview#page=2)), and no training
"will guarantee that a dog will become a good guardian" ([AIB 588, p. 5](lib:livestock-guarding-dogs-usda-aib588#page=5)).

**Here in the valley:** a matted coat "may lead to serious skin infections", especially in moist climates; comb out
mats and burrs around the toes and ears, or clip ([AIB 588, pp. 24–25](lib:livestock-guarding-dogs-usda-aib588#page=24)).
With our wet winters and hot summers, clip long-coated guardians in late spring *(rule of thumb)*.

## 🐑 Raising a guardian pup with the stock

Bonding begins at about 3 weeks, peaks at **6–8 weeks** and levels off by 12; after 12 weeks it "may never be
satisfactorily achieved" ([AIB 588, p. 13](lib:livestock-guarding-dogs-usda-aib588#page=13)). Texas A&M sets the limit
at **16 weeks**: "Do not bring the puppy into your home to socialize it" ([p. 3](lib:livestock-guardian-dogs-overview#page=3)).

1. **Bring the pup home at 7–8 weeks** and put it straight into its pen with the stock, away from the house
   ([AIB 588, pp. 12, 21](lib:livestock-guarding-dogs-usda-aib588#page=12)).
2. **The pen:** about **150 sq ft** with **3–6 sheep**, lambs if you have them (orphans are ideal); a pup-only corner
   with food and shelter behind panels it can crawl through but sheep can't; water both must share. Check it several
   times a day at first, then daily; a pat is fine, but the bond you want is dog-to-sheep; take out any sheep that
   bullies it ([AIB 588, p. 13](lib:livestock-guarding-dogs-usda-aib588#page=13)). Texas A&M uses a bigger pen with
   4–6 calm animals of every kind the dog will guard ([p. 3](lib:livestock-guardian-dogs-overview#page=3)).
3. **Rough play** — chewing ears, pulling wool — stops at once: a sharp "No", bigger lambs that won't stand for it, or
   a pen next door for days to weeks with supervised visits ([AIB 588, p. 13](lib:livestock-guarding-dogs-usda-aib588#page=13)).
4. **At 16 weeks or older**, move it with "its" lambs to a bigger field. It will explore and slip through fences; take
   it back every time, and never let it hang around the house or children ([AIB 588, p. 14](lib:livestock-guarding-dogs-usda-aib588#page=14)).
5. **Teach enough to handle it:** "No", "Come" (always pleasant — never call it to punish it), the leash
   ([AIB 588, p. 14](lib:livestock-guarding-dogs-usda-aib588#page=14)), "Stay" as you leave the pen, and short, watched
   spells tied up. **15–20 minutes, 3–4 times a week**, keeps it catchable ([Texas A&M, pp. 4–5](lib:livestock-guardian-dogs-overview#page=4)).
6. **At lambing or kidding**, a young dog waits in the next pen until the mothers and young have "mothered up"
   ([AIB 588, p. 18](lib:livestock-guarding-dogs-usda-aib588#page=18)).
7. **It is not a pet.** A guardian petted at the house guards the house ([AIB 588, p. 15](lib:livestock-guarding-dogs-usda-aib588#page=15)).
   Praise it when you find it with the stock; take it straight back, with no fuss, when you find it elsewhere
   ([Texas A&M, p. 5](lib:livestock-guardian-dogs-overview#page=5)).

![A pen seen from above: a pup-only corner with food and shelter behind a panel with a low gap, a shared water trough, and 3 to 6 lambs](img:DOGS-GUIDE/guardian-pup-bonding-pen.svg)
*The pup can reach its own corner, the lambs can't, and the water makes them mix ([AIB 588, p. 13](lib:livestock-guarding-dogs-usda-aib588#page=13); a diagram drawn for this guide).*

Keep guardian and herding dogs from playing together ([AIB 588, p. 18](lib:livestock-guarding-dogs-usda-aib588#page=18));
loose farm pets teach a guardian pup bad habits ([p. 19](lib:livestock-guarding-dogs-usda-aib588#page=19)). Some
lessons take up to a year to show ([p. 21](lib:livestock-guarding-dogs-usda-aib588#page=21)).

## 🐻 What guardian dogs can and can't do

| Predator | What a guardian does |
|---|---|
| Coyotes, foxes | Usually keep away; 95% of surveyed guardians were aggressive to predators ([AIB 588, p. 28](lib:livestock-guarding-dogs-usda-aib588#page=28)) |
| Stray dogs | Usually leave — but young guardians may stand by, and some have **joined** them in killing sheep (same page). Dogs cause about 21% of predator losses of grown sheep ([UC ANR 8598, p. 2](lib:livestock-protection-tools#page=2)) |
| Black bear | The dog barks and closes in; the bear usually retreats, and the dog chases it off and comes back ([AIB 588, pp. 28–29](lib:livestock-guarding-dogs-usda-aib588#page=28)) |
| Cougar | "Cougars are known predators of dogs and might not avoid contact with the dog" ([AIB 588, p. 29](lib:livestock-guarding-dogs-usda-aib588#page=29)) |
| Wolf | Hard to predict ([AIB 588, p. 28](lib:livestock-guarding-dogs-usda-aib588#page=28)); it is **not legal** to kill a wolf even when it attacks your dog ([furbearer regs, p. 9](lib:oregon-furbearer-trapping-and-hunting-regulations#page=9)) |

UC ANR rates guardian dogs "highly effective" even against mountain lions ([p. 5](lib:livestock-protection-tools#page=5)),
but a lone dog can lose to a cougar, and cougars live throughout Oregon ([ODFW cougar, p. 2](lib:oregon-is-cougar-country-odfw#page=2)).
So run guardians **in pairs** and **pen the stock near the house at night** — night pens rate highly effective against
lions and bears ([UC ANR 8598, p. 5](lib:livestock-protection-tools#page=5)). "Move them to sheds or barns at night";
Oregon law lets a landowner kill a cougar that is damaging livestock ([ODFW cougar, p. 2](lib:oregon-is-cougar-country-odfw#page=2)).

**What they can't do:**
- **Protect right away:** a pup is no guard until it can defend itself ([AIB 588, p. 16](lib:livestock-guarding-dogs-usda-aib588#page=16)).
- **Guarantee anything:** "Nothing short of total confinement will guarantee complete protection"; use dogs with night
  corrals, electric fence and removing dead animals ([AIB 588, p. 29](lib:livestock-guarding-dogs-usda-aib588#page=29)).
- **Stay out through days of rain with no shelter**, or thunder and gunfire — some go home ([AIB 588, p. 17](lib:livestock-guarding-dogs-usda-aib588#page=17)).
- **Be trusted blindly:** 14% of surveyed dogs hurt or killed sheep; "suspect the dog until it is clear that it was not
  at fault" ([AIB 588, p. 28](lib:livestock-guarding-dogs-usda-aib588#page=28)). Most sleep by day and watch at dusk and
  dawn ([p. 17](lib:livestock-guarding-dogs-usda-aib588#page=17)).

**What kills guardians:** 32% of the USDA's working dogs died young — vehicles 23%, shot on purpose 23%, illness 18%,
accidents 9% ([AIB 588, pp. 25–26](lib:livestock-guarding-dogs-usda-aib588#page=25)). Only 52% live to age 6, and 57% of
deaths happen **off the property** ([Texas A&M, p. 4](lib:livestock-guardian-dogs-overview#page=4)). Watch for poison
baits, rat poison, traps and snares ([AIB 588, p. 26](lib:livestock-guarding-dogs-usda-aib588#page=26)).

**Llamas and donkeys** deter dogs, coyotes and foxes "but not wolves, bears, or mountain lions"; they are "prey animals"
themselves ([UC ANR 8598, pp. 5–7](lib:livestock-protection-tools#page=5)). They "will sometimes protect sheep"
([*Raising Healthy Sheep*, p. 133](lib:raising-healthy-sheep-cvm#page=133)) — not enough where cougars and bears hunt.

## 🔢 How many guardian dogs per flock

- **USDA:** where predators are few, one dog does for most pastures; brush, timber and ravines need more. First-timers
  should **start with one pup** and add a second once it is settled — the young one copies the old
  ([AIB 588, pp. 10–11](lib:livestock-guarding-dogs-usda-aib588#page=10)). **Keep a backup** ([p. 26](lib:livestock-guarding-dogs-usda-aib588#page=26)).
- **Texas A&M:** **1–2 dogs per 100** ewes or does; with **bears, mountain lions or wolves**, **1–2 per 50**. Two dogs
  beat one except for small flocks near the house; add young dogs over the years ([pp. 5–6](lib:livestock-guardian-dogs-overview#page=5)).
- **The books differ:** the USDA tells of one young Komondor guarding 600 ewe lambs on 125 acres ([AIB 588, p. 11](lib:livestock-guarding-dogs-usda-aib588#page=11)),
  but in open, coyote-only country. For our brushy hills, use Texas A&M: **two dogs** for a flock of up to about 50,
  raised a year apart, **plus** a night pen *(rule of thumb, from both books)*. Pairs often split the work, one patrolling
  wide and one staying close; extra dogs roam more, which neutering helps ([AIB 588, p. 11](lib:livestock-guarding-dogs-usda-aib588#page=11)).

## 🚧 Fences that keep guardians home

Fence respect "is the most important lesson an LGD can learn" ([Texas A&M, p. 4](lib:livestock-guardian-dogs-overview#page=4)).

1. **Teach it young:** an electric wire inside the bonding pen; a triangular PVC yoke stops a pup squeezing through
   ([Texas A&M, p. 4](lib:livestock-guardian-dogs-overview#page=4)).
2. **New pasture:** put the dog's shelter and feeder in it; walk the dog round the edge on a leash daily; leave it alone
   a few hours, then longer; bring it back at once each time it leaves ([AIB 588, p. 21](lib:livestock-guarding-dogs-usda-aib588#page=21)).
3. **Jumpers and crawlers:** a tire on a chain about 10 ft long ([AIB 588, p. 21](lib:livestock-guarding-dogs-usda-aib588#page=21)).
   Older dogs jump fences as high as **6 ft** ([p. 22](lib:livestock-guarding-dogs-usda-aib588#page=22)). **Never chain a
   dog beside a fence** — it can hang itself ([p. 26](lib:livestock-guarding-dogs-usda-aib588#page=26)). Near roads keep
   it inside; elsewhere a dog patrolling just outside makes a buffer ([pp. 21–22](lib:livestock-guarding-dogs-usda-aib588#page=21)).

**The fence** ([UC ANR 8598, p. 8](lib:livestock-protection-tools#page=8)): a coyote squeezes through a **4 × 6 in** gap
in woven wire and climbs or jumps fences under **66 in**, so add an electric top wire and a "trip wire" low on the
outside. Electric netting cut coyote entries from 47% to 6%; energizers can run on solar-charged batteries. Electric
fences fail on **dry soil**, poor grounding and weeds on the wire — a summer problem here. Against bears: at least
**3 wires** (5–6 better), lowest **7–9 in**, highest **36–42 in**, **8–10 in** apart, energizer at least **6,000 V and
0.5 J** ([ODFW bear country, p. 2](lib:raising-chickens-in-bear-country-odfw#page=2)).

**Neighbors:** a collar tag saying it is a livestock guardian, signs by the road, and a word with the neighbors
([Texas A&M, p. 2](lib:livestock-guardian-dogs-overview#page=2)). Many counties hold owners responsible "for damage done
by roaming dogs" ([AIB 588, p. 24](lib:livestock-guarding-dogs-usda-aib588#page=24)).

## 🐕‍🦺 Herding dogs: basic training

Sheep learn to ignore a quiet guardian but "will bunch and run from a dog that chases them" ([AIB 588, p. 19](lib:livestock-guarding-dogs-usda-aib588#page=19));
a herding dog uses that. Get a pup from a **working strain**; color doesn't matter ([Wickham, p. 115](lib:practical-training-of-the-shepherd-dog#page=115)).
Wickham's rules: kindness and patience; one thing at a time; one short word per order, always the same; show the dog
what you want; never punish it for what it doesn't understand ([pp. 76–77](lib:practical-training-of-the-shepherd-dog#page=76)).

**Yard lessons** in a quiet place ([Wickham, pp. 77–81](lib:practical-training-of-the-shepherd-dog#page=77)):
1. **A short name**, and a wide collar worn for days before any line goes on.
2. **"Come in!"** — every time you call it to eat; on walks a light cord **20–30 ft** long brings it back.
3. **"Lie down!"** — ease it gently down, praise it, step a little farther away each time until it stays.
4. **"Speak!"** — meat held just out of reach, rewarded at the first bark; later **"Quiet!"** ([p. 86](lib:practical-training-of-the-shepherd-dog#page=86)).
5. **A whistle** — whistle while it dozes, holding meat; later a pat replaces the meat.
6. **"Stop!", "Steady!", "Hie on!"** — with a plate of food and a check cord: wait, creep, eat.
7. **"Over!"** — meat tossed over a low board, then a stick raised bit by bit, to teach jumping fences.

**Out with the sheep** ([Wickham, pp. 85–92](lib:practical-training-of-the-shepherd-dog#page=85)): only once "Come in!"
works every time. For a week just drive the sheep to one place saying "Hie on!". Teach hand signals — at a distance and
in wind it sees what it can't hear. Don't send it round the flock until it is fast enough to circle them — 7–8 months
for some, a year for others; a slow dog runs straight at them. Over-eagerness "must be checked, but not by whipping".
"If the shepherd treats the sheep with gentleness, and does not allow the dog to bite them, he will be a protector of
the flock" ([p. 85](lib:practical-training-of-the-shepherd-dog#page=85)). Train on cattle first if it must work both
([p. 91](lib:practical-training-of-the-shepherd-dog#page=91)). A full course takes **two years**; half of it by one year
is good progress ([p. 92](lib:practical-training-of-the-shepherd-dog#page=92)).

![Top view of a flock with the shepherd behind it and numbered paths showing where the dog runs for "Away up", "Around them", "Away back", "Hold front" and "Come in"](img:DOGS-GUIDE/herding-commands-around-the-flock.svg)
*Where the dog goes for each command; use the same word every time ([Wickham, pp. 85–90](lib:practical-training-of-the-shepherd-dog#page=85); a diagram drawn for this guide).*

## 🦆 Hunting dogs: bird dogs and Oregon law

**The law** (check each year's rules):
- It is unlawful to "hunt any game mammal with dogs, except western gray squirrel" ([ODFW big game, p. 21](lib:odfw-2026-big-game-hunting-regulations#page=21));
  dogs may not hunt or pursue cougar ([p. 67](lib:odfw-2026-big-game-hunting-regulations#page=67)) or black bear ([p. 68](lib:odfw-2026-big-game-hunting-regulations#page=68)).
- "Use of dogs is permitted to hunt or pursue bobcat, raccoon, fox, and unprotected mammals" under the furbearer rules
  ([furbearer regs, p. 6](lib:oregon-furbearer-trapping-and-hunting-regulations#page=6)).
- Pets may not "harass (chase, molest, worry, disturb) wildlife" except when hunting or in a pursuit season — **Sept. 1
  to Jan. 31** for wild upland birds ([ODFW game birds, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)).
  A guardian that chases deer breaks the law too ([AIB 588, p. 8](lib:livestock-guarding-dogs-usda-aib588#page=8)).

So in Oregon a hunting dog is a **bird dog**: [pointers](wiki:Pointing_dog) and [setters](wiki:Setter) point,
[spaniels](wiki:Spaniel) flush, [retrievers](wiki:Retriever) fetch. Quail in the open want a wide-ranging dog; grouse in
the woods "a close, careful dog", quiet and "cat-like" ([Miller, p. 160](lib:the-american-hunting-dog#page=160); [p. 166](lib:the-american-hunting-dog#page=166)).
For ducks in cold water, a [Chesapeake](wiki:Chesapeake_Bay_Retriever) or Irish water spaniel ([p. 173](lib:the-american-hunting-dog#page=173));
double-coated dogs like the [griffon](wiki:Wirehaired_Pointing_Griffon) stand icy water and wet brush ([p. 81](lib:the-american-hunting-dog#page=81)).

**Training a bird dog** (Miller's lessons, without his spiked "force collar"):
1. A pup of hunting stock points at **about 3 months**. From 3 to 8 months teach manners: not to chase, to come to a
   whistle, heel, swim, and link guns with good times ([Miller, pp. 121, 154](lib:the-american-hunting-dog#page=121)).
   Yard lessons start at 6–12 months ([pp. 121, 152](lib:the-american-hunting-dog#page=152)), **never over half an hour** ([p. 153](lib:the-american-hunting-dog#page=153)).
2. **"Sit down!"** — ease it down, pet it, a bit of biscuit. **"Fetch!"** — a corn cob, "Hold it!", "Give up!", praise;
   then farther, dropped, tossed, and "Dead bird — seek!" ([pp. 153–154](lib:the-american-hunting-dog#page=153)).
3. **Steady on point:** "Steady!", then "Whoa!" (Miller: "To ho!") if it starts to break, with a **30-ft check cord**
   ([pp. 154–155](lib:the-american-hunting-dog#page=154)) on a plain collar or harness *(our change)*.
4. **Quartering:** a whistle and a wave each time you turn, walking the way you want ([p. 155](lib:the-american-hunting-dog#page=155)).
5. **The gun:** "only one gun and one barrel to the covey" at first; a nervous pup gets weeks of walking up birds with
   **no shells** ([p. 155](lib:the-american-hunting-dog#page=155); [pp. 186–187](lib:the-american-hunting-dog#page=186)).

**In the field:** in trapping season keep the dog close and carry **wire cutters** for snares; keep it close where there
is wolf sign; keep it from stagnant water and fish carcasses ([ODFW game birds, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)).

## 🔔 Watchdogs and warning

- "A dog's presence is a close substitute for human occupancy, and most burglars avoid houses with dogs. Small dogs
  may bark and attract attention" ([COPS *Burglary*, p. 20](lib:burglary-of-single-family-houses#page=20)). Post signs
  ([WSDA, p. 1](lib:general-farm-security#page=1)).
- A German Shepherd answered a sound at **24 m** that a man lost beyond **6 m** ([TM 10-396, p. 12](lib:war-dogs-care#page=12)).
- On a small place a dog kept indoors at night means the house "cannot be entered nor the dog poisoned"
  ([Miller, p. 108](lib:the-american-hunting-dog#page=108)); bed it "free from draughts and commanding the whole of
  downstairs" ([p. 112](lib:the-american-hunting-dog#page=112)).
- Guardians alert you to predators near the flock ([AIB 588, p. 27](lib:livestock-guarding-dogs-usda-aib588#page=27));
  old shepherds belled every few sheep, and a dog tied in the yard took up the alarm ([Wickham, pp. 111–113](lib:practical-training-of-the-shepherd-dog#page=111)).
- **Teach "Speak!" and "Quiet!"** so a bark means something ([Wickham, pp. 79, 86](lib:practical-training-of-the-shepherd-dog#page=79)).
- **Bark, don't bite.** Don't train a household dog to attack: even the Army says "the highly aggressive dog tactics of
  the 1960s and 1970s are long gone" ([FM 3-19.17, p. 5](lib:military-working-dogs#page=5)). Protecting people from
  your dog is your job ([AIB 588, p. 24](lib:livestock-guarding-dogs-usda-aib588#page=24)). Geese and guineas make good
  alarms too ([Home Defense guide](guide:HOME-DEFENSE-GUIDE)).

## 🎓 Basic obedience the Army way, without the harsh parts

The Army's 1943 manual rests training on knowing how a dog's mind works, "constant repetition", "suitable recognition
of a dog's progress" and "patience" ([TM 10-396, p. 58](lib:war-dogs-care#page=58)). Keep that, but use a **wide flat
collar or harness** instead of its choke chain and throwing chain ([p. 63](lib:war-dogs-care#page=63)), and guide with
hands and voice, not jerks. Gear: a **6-ft leash** and a **25-ft long line** (same page).

**The rules** ([TM 10-396, pp. 59–61, 66](lib:war-dogs-care#page=59)):
- Lessons of about **half an hour, twice a day**; start with something the dog knows and **end with praise** for
  something it does well. Don't drill one command too long. Tone, not loudness, carries the order.
- "The trainer must never lose patience". "No" is the only word for wrong; correct **at the moment** or not at all,
  never for clumsiness, slowness or not understanding, and never with the dog's name.
- "A dog never is slapped with the hand or struck with the leash. The hand is an instrument of praise and pleasure"
  ([p. 60](lib:war-dogs-care#page=60)). With a pup, holding back praise usually does it ([AIB 588, p. 15](lib:livestock-guarding-dogs-usda-aib588#page=15)).
  **Never call a dog to scold it** — go to it ([AIB 588, p. 14](lib:livestock-guarding-dogs-usda-aib588#page=14); [Wickham, p. 84](lib:practical-training-of-the-shepherd-dog#page=84)).
- Rewards: kind words, a pat, a romp ([TM 10-396, p. 60](lib:war-dogs-care#page=60)). The Army avoided food treats;
  Wickham used scraps of meat or cheese, then a pat ([pp. 80, 87](lib:practical-training-of-the-shepherd-dog#page=80)).
  Use small treats while teaching, then fade them out *(rule of thumb)*.

| Command | What the dog does | How to teach it gently |
|---|---|---|
| **Heel** | Walks on your left, shoulder by your knee, leash slack ([p. 67](lib:war-dogs-care#page=67)) | Say "Heel" and walk briskly. A steady pull only makes a dog brace ([p. 69](lib:war-dogs-care#page=69)): when it pulls, stop or turn away, and praise it the moment it is back *(our change from the manual's jerks)* |
| **Sit** | Sits at once ([p. 69](lib:war-dogs-care#page=69)) | Leash in the right hand; press the hindquarters gently down with the left; praise ([p. 70](lib:war-dogs-care#page=70)) |
| **Down** | Lies down at the word and a downward sweep of the arm ([p. 72](lib:war-dogs-care#page=72)) | From a sit, ease the front legs forward ([Wickham, pp. 78–79](lib:practical-training-of-the-shepherd-dog#page=78)); praise. A "depressing exercise" — few in a row ([TM 10-396, p. 73](lib:war-dogs-care#page=73)) |
| **Stay** | Holds its place until you return ([p. 74](lib:war-dogs-care#page=74)) | Start in the down; back away slowly saying "Stay", walk back around it, praise; build up time and distance ([pp. 74–76](lib:war-dogs-care#page=74)) |
| **Come** | Comes and sits facing you ([p. 77](lib:war-dogs-care#page=77)) | Name, then "Come", a light tug; then the long line: let it sniff, call, praise on arrival, release with "OK". It is "praised, never punished — even if he has been pulled on the leash for the entire distance" ([pp. 77–78](lib:war-dogs-care#page=77)) |
| **Riding; gunfire** | Rides quietly; doesn't flinch | Rides of 5, then 10 minutes, on an empty stomach if carsick ([pp. 89–90](lib:war-dogs-care#page=89)). Shots at a distance while it eats, closer over days; stop if it shows alarm ([p. 90](lib:war-dogs-care#page=90)) |

![A soldier walking with a dog at heel on his left side, the dog's shoulder level with his knee and the leash hanging slack](img:DOGS-GUIDE/heel-on-leash.png)
*Heel: dog on your left, shoulder by your knee, leash hanging loose ([TM 10-396, p. 67](lib:war-dogs-care#page=67)).*

## 🐓 Keeping dogs from chasing stock

"Without strong fences losses from sheep-killing dogs can be heavy" ([FB 2222, p. 7](lib:raising-a-small-flock-of-sheep#page=7)).

1. **Never teach the taste.** Shepherds who left dead sheep lying, butchered in front of the dog and tossed it pieces
   raised sheep-killers; "an ounce of prevention is better than a pound of cure" ([Wickham, pp. 116–117](lib:practical-training-of-the-shepherd-dog#page=116)).
   **Bury or burn dead stock** ([Zoonoses, p. 119](lib:zoonoses-diseases-animals-give-people-cvm#page=119)) and feed
   only cooked meat, from a bowl.
2. **Raise pups around stock and poultry** ([Wickham, p. 77](lib:practical-training-of-the-shepherd-dog#page=77)), on a
   leash at first *(rule of thumb)*. Say "No" the instant it chases a sheep or a vehicle ([AIB 588, p. 14](lib:livestock-guarding-dogs-usda-aib588#page=14)).
3. **Dogs of 6–18 months** often chase: a **dangle chain** with a short piece of 2×4, tire or PVC pipe slows them; take
   away any weak animal the dog keeps picking on ([Texas A&M, p. 4](lib:livestock-guardian-dogs-overview#page=4)).
4. **No loose, idle dogs:** they teach young dogs bad habits ([AIB 588, p. 19](lib:livestock-guarding-dogs-usda-aib588#page=19)),
   and a guardian may join strays in a kill ([p. 28](lib:livestock-guarding-dogs-usda-aib588#page=28)).
5. **A dog found away from its post** goes straight back, no reward; if that fails, a day or two kenneled away from the
   flock ([Texas A&M, p. 5](lib:livestock-guardian-dogs-overview#page=5)).
6. **A dog that keeps killing** must be shut up for good or put down; the USDA destroyed some guardians as
   "untrustworthy" ([AIB 588, p. 26](lib:livestock-guarding-dogs-usda-aib588#page=26)).

## 🍖 Feeding without kibble: what and how much

"To a great extent, the dog is able to digest and utilize the same foods as man"; the Army fed meat, grain and "good
mess scraps" ([TM 10-396, pp. 37, 40](lib:war-dogs-care#page=37)):
- **Meat** — about **half** the ration, with eggs, milk, cheese or fish ([p. 38](lib:war-dogs-care#page=38)). Offal —
  heart, liver, lungs, tripe, udder — is "more nourishing to the dog than cuts of muscle meat". Fresh beats salted;
  **never fried**; fatty horse meat is good, brought in slowly ([p. 37](lib:war-dogs-care#page=37)). **Cook it all**
  (next section).
- **Grain** — about **25%**: corn bread (best in cold weather and for hard workers), rice and rolled oats cooked well,
  dried bread soaked in broth or milk; **never moldy bread** ([p. 38](lib:war-dogs-care#page=38)).
- **Vegetables** — about **12½%**: mashed tomatoes are good; not much high-fiber stuff ([p. 39](lib:war-dogs-care#page=39)).
- **Calcium** comes from bone: the Army ground raw bone in with the meat and gave sick dogs bone meal
  ([pp. 40–41](lib:war-dogs-care#page=40)). Cooked whole bones splinter ([p. 39](lib:war-dogs-care#page=39)); bake bones
  dry and pound them to meal *(rule of thumb)*. Feed fairly **dry**, not sloppy ([p. 40](lib:war-dogs-care#page=40)).

**How much:** "a dog's main meal should consist of 1½ pounds of meat to each 50 pounds of body weight, depending upon
the size of the dog and the amount of work he is required to do" ([TM 10-396, p. 41](lib:war-dogs-care#page=41)). Grown
guardians eat **2–4 lb** of dry dog food a day ([AIB 588, p. 25](lib:livestock-guarding-dogs-usda-aib588#page=25)).
Weigh monthly ([FM 3-19.17, p. 59](lib:military-working-dogs#page=59)); you should feel the ribs but not see them
*(rule of thumb)*. By that rule a 25-lb dog needs about **¾ lb** of meat a day (**275 lb** a year), a 50-lb dog **1½ lb**
(**550 lb**), a 100-lb guardian **3 lb** (**1,100 lb**) — plus as much again in grain and vegetables *(arithmetic)*.

**Dog cake that keeps:** Miller's kennels boiled cornmeal, wheat bran and meat scraps soft and baked them in pans "the
harder the better" — **two half-pound cakes a day** per hunting dog ([Miller, pp. 149–150](lib:the-american-hunting-dog#page=149)).
Pick out the bones, bake it dry, store it sealed *(rule of thumb)*.

**Puppies:** **5** small meals a day at 2 months, **4** at 3 months, **3** from 6 to 18 months, then **2** — milk, broth,
oatmeal, dried bread, scraps and a little chopped meat, never old or smelly meat ([Miller, pp. 115–117](lib:the-american-hunting-dog#page=115)).

**Rules:**
- **Twice a day, never within 2 hours before or after hard work** (bloat) ([FM 3-19.17, p. 67](lib:military-working-dogs#page=67)).
  The 1943 manual fed once a day ([TM 10-396, p. 40](lib:war-dogs-care#page=40)); for big dogs follow the newer one.
  Pick up leftovers within about 2 hours; store food sealed, off the floor ([FM 3-19.17, p. 60](lib:military-working-dogs#page=60)).
- **Feed indoors** or in a closed kennel — pet food draws bears and cougars ([ODFW bears, p. 2](lib:living-with-black-bears-odfw#page=2);
  [ODFW cougar, p. 2](lib:oregon-is-cougar-country-odfw#page=2)).
- **Guardians** eat near the stock, not at the house ([AIB 588, p. 23](lib:livestock-guarding-dogs-usda-aib588#page=23)),
  from a feeder sheep can't reach ([p. 25](lib:livestock-guarding-dogs-usda-aib588#page=25)) — Texas A&M uses a
  4 × 6 × 4 ft station with a gate the dog jumps into, and warns feeders draw raccoons ([p. 6](lib:livestock-guardian-dogs-overview#page=6)).
  In bear country, hand-feed at the daily check and leave nothing out overnight *(rule of thumb; Texas A&M hand-feeds at
  daily checks, p. 6)*.

## ☠️ Salmon poisoning and other foods that kill dogs

**Salmon poisoning disease.** "Don't let your dog eat raw salmon." Signs: a high fever **5–7 days** after eating fish,
no appetite, dullness, dehydration, vomiting, watery or bloody diarrhea; "most dogs die if left untreated", and the cure
takes antibiotics, a wormer and IV fluids. **Cook fish thoroughly** or freeze it at **−4 °F for 24 hours**
([ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)). The fluke that carries it lives in fish from
the coastal streams of Oregon, Washington and northern California; **salmon, trout and steelhead** carry the most, and
**home-smoked fish counts as undercooked**: cook to **145 °F** inside ([FDA, p. 156](lib:fda-bad-bug-book#page=156);
[Neorickettsia helminthoeca](wiki:Neorickettsia_helminthoeca)). The Illinois and the Rogue carry salmon and steelhead:
keep dogs from fish cleaning, gut buckets and carcasses on the gravel bars *(rule of thumb)*.

**Raw meat and offal.** Dogs are the main host of the [hydatid tapeworm](wiki:Echinococcus_granulosus); its eggs in dog
droppings grow cysts in sheep, cattle and **people, especially children** ([Zoonoses, p. 117](lib:zoonoses-diseases-animals-give-people-cvm#page=117)).
"Never feed raw meat to dogs. Instead, burn the offal of slaughtered animals" ([*No Animal Doctor*, p. 360](lib:where-there-is-no-animal-doctor-cvm-2024#page=360));
"we must fully cook all meat products fed to dogs" ([Zoonoses, p. 119](lib:zoonoses-diseases-animals-give-people-cvm#page=119)).
Raw rabbit passes tapeworm too ([Peace Corps Vol 4, p. 340](lib:peace-corps-livestock-training-manual-vol-4-1982#page=340)).
Pork and wild game carry [trichinosis](wiki:Trichinosis): cook until all parts reach **77 °C (170 °F)** or turn from
pink to gray ([Zoonoses, p. 121](lib:zoonoses-diseases-animals-give-people-cvm#page=121)).

| Don't feed or leave within reach | Why |
|---|---|
| Moldy bread, old or smelly meat | Spoiled food sickens dogs ([TM 10-396, p. 38](lib:war-dogs-care#page=38); [Miller, p. 117](lib:the-american-hunting-dog#page=117)) |
| Cooked bones, chicken leg bones, small bones | Splinters cut or block the gut ([TM 10-396, p. 39](lib:war-dogs-care#page=39); [Miller, p. 116](lib:the-american-hunting-dog#page=116)) |
| Chocolate; grapes and raisins; onions; macadamia nuts; sugar-free gum (xylitol) | Poisonous to dogs ([Theobromine poisoning](wiki:Theobromine_poisoning); [Grape toxicity in dogs](wiki:Grape_toxicity_in_dogs); [Onion](wiki:Onion); [Macadamia](wiki:Macadamia); [Xylitol](wiki:Xylitol)) — no book on the drive covers these |
| Antifreeze, insecticides, weed killers, rat poison | Common dog poisons ([FM 3-19.17, p. 65](lib:military-working-dogs#page=65); [AIB 588, p. 26](lib:livestock-guarding-dogs-usda-aib588#page=26); [Ethylene glycol poisoning](wiki:Ethylene_glycol_poisoning)) |
| Wild mushrooms | Dogs often eat fly agaric and panther caps, which can kill dogs though rarely people ([NAMA, p. 3](lib:nama-thirty-plus-years#page=3)) |
| Black walnut (nuts, shavings) | Can poison dogs and horses ([WSU, p. 27](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=27)) |

**If a dog ate poison** ([FM 3-19.17, p. 65](lib:military-working-dogs#page=65)): treat only if you are sure; keep the
container. Vomiting "is not recommended in all types of poisoning"; when it is right, the Army gives **¼–½ cup of
hydrogen peroxide**. That amount is for a full-grown Army working dog, a big shepherd-type dog: **never give a small dog
or a pup that much**, and use only ordinary **3% drugstore peroxide**, never a stronger kind *(rule of thumb)*. Not if it
swallowed something caustic, petroleum or sharp, or is already drowsy or shaking *(rule of thumb)*. **Never salt water** (see the old-advice table). Keep it quiet and warm.

## 🏠 Water, shelter and grooming

**Water:** clean and fresh, always ([TM 10-396, p. 41](lib:war-dogs-care#page=41)); after hard work only **3 in** in the
bucket for the first hour ([FM 3-19.17, p. 67](lib:military-working-dogs#page=67)). In heat, shade and cool water, and
**never leave a dog in a car** ([ODA, p. 2](lib:wildfire-prep-for-pets-and-livestock-oregon-oda#page=2)). Stagnant water
can carry [leptospirosis](wiki:Leptospirosis) ([ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)).

**Shelter** — our winters are wet, so get the dog off the ground:
- In rainy climates raise the bed **6–10 in** ([TM 10-396, p. 43](lib:war-dogs-care#page=43)). The Army dog house is a
  **4 × 4 × 4 ft** box set **8–12 in** up, its floor draining out the door ([FM 3-19.17, p. 84](lib:military-working-dogs#page=84)).
- Miller's kennel: a lean-to with the **door at one end of the long side**, so the bed is out of the wind, and the rest of
  that side hinged for cleaning and summer air; about **24 × 36 in** of floor and **30 in** high for a setter-sized dog,
  a **10 × 16 in** door, **8-in** legs, front to the **south** and back to the north wind ([Miller, pp. 136–138](lib:the-american-hunting-dog#page=136)),
  and a slatted bench to lie on off the damp ground ([p. 139](lib:the-american-hunting-dog#page=139)).
- Guardians often ignore shelter, but give them one in the pasture — it helps keep them there ([AIB 588, p. 25](lib:livestock-guarding-dogs-usda-aib588#page=25)).

![Drawing of a dog kennel on short legs with a sloping roof, an arched door at one end of the long side, the rest of that side hinged, and a shelf under the roof](img:DOGS-GUIDE/side-door-kennel-on-legs.png)
*Miller's kennel for a nursing mother: door at the end of the side, hinged side for cleaning, raised off the ground, and an upper shelf where she can rest away from the pups ([Miller, pp. 111–112](lib:the-american-hunting-dog#page=111); [🖼️ p. 141](lib:the-american-hunting-dog#page=141)).*

- **Bedding:** clean **straw**; hay, shavings and leaves bring dust and seeds ([Miller, p. 112](lib:the-american-hunting-dog#page=112)).
  Shake it daily, change it weekly, pull wet straw at once ([TM 10-396, p. 46](lib:war-dogs-care#page=46)); a dog put
  away wet risks skin infection ([FM 3-19.17, p. 67](lib:military-working-dogs#page=67)).
- **A yard, not a chain:** a chain winds the dog up; a small fenced yard, wire buried and covered on top, is far better
  ([Miller, pp. 145–146](lib:the-american-hunting-dog#page=145)). Clean daily; pick up droppings at least twice a day
  ([FM 3-19.17, p. 62](lib:military-working-dogs#page=62)); don't set kennels face to face ([TM 10-396, p. 46](lib:war-dogs-care#page=46)).
- **Fire and smoke:** a go-kit (3–7 days of food and water, leash, records, ID tags); evacuate early; "never leave pets
  behind" ([ODA, p. 2](lib:wildfire-prep-for-pets-and-livestock-oregon-oda#page=2)). Hot ground burns pads ([FM 3-19.17, p. 67](lib:military-working-dogs#page=67)).

**Grooming** ([TM 10-396, pp. 31–35](lib:war-dogs-care#page=31)): **brush daily**, against the hair, then with it, but
go easy with the comb in winter to keep the undercoat. Check nails — long ones break or grow into the pads. In long-eared
dogs wipe out only the wax you can see, never forcing a swab in; constant head shaking means trouble. Look at the teeth;
a dog scooting may need its anal glands emptied. **Bathe as seldom as possible** — washing strips the skin's oils; use
water at about **105 °F**, keep soap out of the eyes, rinse every trace out and dry the dog well.

## 🐾 Breeding and puppies

Think first: ranchers have been "stuck" with six or eight unsold pups while the mother wasn't guarding, and pups kept
too long away from stock miss their bonding window ([AIB 588, p. 26](lib:livestock-guarding-dogs-usda-aib588#page=26)).

1. **Heats** come about every **six months** and last about **three weeks** ([Miller, p. 104](lib:the-american-hunting-dog#page=104)).
   Skip the first two (from 8–9 months) and breed at about **1½ years** ([p. 123](lib:the-american-hunting-dog#page=123)),
   to a young sire from a working family; old-to-young pairings give small pups ([pp. 124–125](lib:the-american-hunting-dog#page=124)).
   Guard her through the heat and about two weeks after mating ([p. 125](lib:the-american-hunting-dog#page=125)).
2. **Vaccinate her 2–3 weeks before breeding**, never while pregnant ([parvo sheet, p. 3](lib:canine-parvovirus#page=3)).
3. Pups come about **63 days** after mating ([Miller, p. 101](lib:the-american-hunting-dog#page=101)). **Whelping:** a quiet
   place, clean straw, a box with a **rail around the inside**; don't handle the newborns, just see each one is warm and
   nursing; feed her well three times a day the first week ([pp. 125–126](lib:the-american-hunting-dog#page=125)).

![Cut-through drawing of a whelping box: walls, straw floor, a board rail about 4 inches above the floor all around the inside, a pup lying safe under the rail and the mother nursing three pups](img:DOGS-GUIDE/whelping-box-rail.svg)
*The rail keeps a strayed pup from being pressed against the wall ([Miller, pp. 125–126, 148](lib:the-american-hunting-dog#page=125); a diagram drawn for this guide).*

4. Pups open their eyes about the **ninth day**; pups that cry and don't gain are in trouble; **five or six** is all most
   mothers raise well ([Miller, pp. 126, 129](lib:the-american-hunting-dog#page=126)).
5. **Worms:** pups catch [roundworm](wiki:Toxocara_canis) before birth, and children catch it from pups. Treat pups and
   mother at **2 weeks**, then **every 3 weeks to 3 months**, then every 3–6 months, dosed by the label
   ([*No Animal Doctor*, p. 348](lib:where-there-is-no-animal-doctor-cvm-2024#page=348)).
6. **Weaning:** at **3 weeks**, two small meals of broth and milk besides nursing; then three, four and by 6 weeks six
   small meals of cooked cereal and finely chopped cooked meat or liver, with a second pan for the weaker pups and a
   shelf where the mother can get away. Weaned at **2 months** ([Miller, pp. 130–131](lib:the-american-hunting-dog#page=130)).
7. **Guardian pups** can meet lambs from about 4 weeks ([AIB 588, p. 13](lib:livestock-guarding-dogs-usda-aib588#page=13);
   [Texas A&M, p. 3](lib:livestock-guardian-dogs-overview#page=3)).
8. **Keep the line going:** keep the best pups and later bring in an outside sire to avoid too much line breeding
   ([Miller, p. 105](lib:the-american-hunting-dog#page=105)); trading studs with neighbors does the same *(rule of thumb)*.

### Spaying and neutering when there's no vet

- **Do it now, while vets exist.** The USDA recommends spaying at about **6 months**, before the first heat, and
  neutering males at about **9 months**: it doesn't hurt guarding, cuts wandering, and a female in heat draws strange
  dogs and is shut away instead of guarding ([AIB 588, p. 10](lib:livestock-guarding-dogs-usda-aib588#page=10);
  [Texas A&M, p. 5](lib:livestock-guardian-dogs-overview#page=5)). Wickham (1891) said castration makes a working dog
  fat and lazy ([p. 116](lib:practical-training-of-the-shepherd-dog#page=116)); follow the newer studies and feed a
  neutered dog a little less *(rule of thumb)*.
- **No book on this drive teaches dog spay or castration surgery.** A spay is major belly surgery under full anesthesia:
  don't attempt it *(rule of thumb)*. *No Animal Doctor*'s castration chapter is for farm animals and still calls for a
  local anesthetic ([p. 187](lib:where-there-is-no-animal-doctor-cvm-2024#page=187)).
- **Without surgery,** shut the female for her whole three-week heat and two weeks after in a pen no dog can climb into
  or dig under, and keep males elsewhere *(rule of thumb; timing from Miller, pp. 104, 125)*.

## 💉 Vaccinate now: parvo, distemper and rabies

Wild animals carry "canine distemper virus, parvovirus, adenovirus, and rabies" ([ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)).
Vaccines need cold storage and nobody will make more once the stores close: **finish every dog's shots now and keep the
papers** *(rule of thumb)*.

**[Parvovirus](wiki:Canine_parvovirus)** ([parvo sheet, pp. 1–4](lib:canine-parvovirus#page=1)): hits unvaccinated pups
under 6 months most — dullness, no appetite, vomiting, heavy and often **bloody diarrhea**, **4–14 days** after
exposure. It spreads in droppings and on bowls, bedding, soil and **people's hands and clothes**; recovered dogs shed it
for 2 weeks. **Vaccine:** from **6–8 weeks**, every **3–4 weeks to 16 weeks**, booster at **1 year**, then every
**3 years**. Care is fluids, medicine and food, and the outlook "worsens as dogs develop more severe illness"
([p. 3](lib:canine-parvovirus#page=3)); with no vet, isolate the pup, keep it warm, give small sips of water often and soft
food as soon as it will eat *(rule of thumb)*. **Cleaning:** pick up all droppings, scrub with soap and water, then
**1 part household bleach to 32 parts water**, kept wet **10 minutes**; soap and water clean hands; keep unvaccinated dogs
off soiled ground for up to **7 months** — sunlight helps ([p. 4](lib:canine-parvovirus#page=4)).

**[Distemper](wiki:Canine_distemper)** spreads through the air: fever that comes and goes, thick discharge from red eyes
and nose, sometimes diarrhea, then twitching and fits that can kill. There is only "good supportive care"; the vaccine
prevents it ([*No Animal Doctor*, p. 295](lib:where-there-is-no-animal-doctor-cvm-2024#page=295)).

**[Rabies](wiki:Rabies)** ([*No Animal Doctor*, pp. 270–272](lib:where-there-is-no-animal-doctor-cvm-2024#page=270)):
- Spread in saliva, by dogs, skunks, bats and raccoons. Signs come **3–8 weeks** after a bite (sometimes over 6 months):
  changed behavior, weak hind legs, drooling, not eating, an odd voice, and what looks like **something stuck in the
  throat — don't reach in bare-handed**. Once signs show it is nearly always fatal.
- **Bitten?** Wash the wound at once with soap and water and get **post-exposure shots** fast. A dog that bit someone
  and may be rabid: kill it if crazed and attacking; otherwise chain it in a secure pen with food and water for
  **14 days** — alive after 14 days, it wasn't rabies ([pp. 271–272](lib:where-there-is-no-animal-doctor-cvm-2024#page=271)).
- "All dogs in the area should be vaccinated regularly" ([p. 272](lib:where-there-is-no-animal-doctor-cvm-2024#page=272));
  the law requires it, yearly or every 3 years ([Texas A&M, p. 6](lib:livestock-guardian-dogs-overview#page=6)).

**Ask the vet now** about [leptospirosis](wiki:Leptospirosis) vaccine ([*No Animal Doctor*, p. 397](lib:where-there-is-no-animal-doctor-cvm-2024#page=397)),
rattlesnake vaccine for outdoor dogs, and a supply of monthly heartworm, worm and flea-and-tick preventives
([Texas A&M, p. 6](lib:livestock-guardian-dogs-overview#page=6); [FM 3-19.17, p. 60](lib:military-working-dogs#page=60)).
**A new dog** stays apart for **21 days** ([TM 10-396, p. 50](lib:war-dogs-care#page=50)).

## 🩺 Health with no vet: parasites, foxtails and sickness

**Know normal** ([TM 10-396, pp. 47–48](lib:war-dogs-care#page=47)): temperature about **101 °F**, give or take 1°
(*No Animal Doctor* gives 102 °F, [p. 66](lib:where-there-is-no-animal-doctor-cvm-2024#page=66)), taken in the rectum
for 3 minutes; pulse **70–100**, felt inside the hind leg; gums **salmon pink**, pinking up within **2–3 seconds** after
you press them white ([FM 3-19.17, p. 64](lib:military-working-dogs#page=64)). A dog off its food is the first sign of
sickness; look dogs over while feeding and grooming. Isolate the sick, quarantine the exposed, clean before you
disinfect — "fresh air and sunlight are potent disinfectants" ([TM 10-396, pp. 48–50](lib:war-dogs-care#page=48)).

**Ticks:** pick them off with **tweezers, drawing gently but firmly** — a jerk leaves the head in; don't handle them
bare-handed (they carry disease to people); wash the spot and burn the ticks; groom daily in tick season
([TM 10-396, pp. 34, 55–56](lib:war-dogs-care#page=55)). **Fleas** lay eggs in bedding and cracks and carry dog
tapeworm, so clean the bed and kennel with the dog ([p. 34](lib:war-dogs-care#page=34)). For **lice**, clip long-haired
dogs and get rid of the hair and bedding ([p. 55](lib:war-dogs-care#page=55)) — bury it in fire season *(rule of thumb)*.
**Worms:** tapeworm segments show around the tail; worm medicines are poisons and can kill an already sick dog — don't
dose blindly ([p. 54](lib:war-dogs-care#page=54)).

**[Foxtails](wiki:Foxtail_(diaspore)) and grass awns** *(rule of thumb — no book on the drive covers them)*: from late
spring through summer, dry grass seeds work into ears, noses, eyes and between toes and keep travelling inward. After a
walk in dry grass, check toes, ears and armpits. Sudden **head shaking** means one in the ear, violent **sneezing** one
in the nose, a lump or limp one in the foot. Pull out what you can see; keep feet and ears clipped short in summer.

**Porcupines and skunks:** most dogs meet them once ([AIB 588, p. 8](lib:livestock-guarding-dogs-usda-aib588#page=8)).
Muzzle the dog and pull every quill straight out with pliers, inside the mouth too; quills left in work deeper *(rule of thumb)*.

**Bloat** ([gastric dilatation-volvulus](wiki:Gastric_dilatation_volvulus)): the stomach swells and twists — swelling
behind the ribs, mostly on the left, restlessness, pain, trying to vomit, labored breathing. Stop food and water; walking
may help it pass gas; "most cases require extensive treatment" ([FM 3-19.17, pp. 66–67](lib:military-working-dogs#page=66)),
so prevention (the feeding rules) is everything.

## 🩹 First aid for a hurt dog

**Muzzle first** — a hurt or frightened dog bites, even its owner ([TM 10-396, p. 57](lib:war-dogs-care#page=57)) —
but **not** if it is unconscious, has trouble breathing or a head injury, is overheated or may vomit
([FM 3-19.17, p. 63](lib:military-working-dogs#page=63)).

![Three drawings of a dog's head: a cloth strip looped round the mouth and knotted under the jaw, the two ends taken back below the ears, and tied in a bow behind the head](img:DOGS-GUIDE/tie-a-cloth-muzzle.svg)
*A gauze or cloth muzzle: loop, knot under the jaw, tie behind the ears ([TM 10-396, p. 57](lib:war-dogs-care#page=57); [FM 3-19.17, p. 63](lib:military-working-dogs#page=63); a diagram drawn for this guide).*

| Problem | What to do |
|---|---|
| **Bleeding** | Press directly on it with a clean pad, or pinch the edges; then a pressure bandage ([FM 3-19.17, p. 64](lib:military-working-dogs#page=64)) |
| **Cuts and bites** | Clip the hair, wash out dirt with clean water; don't pack, probe or stitch. Gauze, then cotton, then bandage — never cotton on the wound. Bite punctures infect easily: watch them ([TM 10-396, pp. 51–52](lib:war-dogs-care#page=51)) |
| **Bandaging a leg** | Snug, not tight; leave the foot out unless hurt, so you see swelling; knot on the outside, off the wound ([TM 10-396, p. 54](lib:war-dogs-care#page=54)) |
| **Broken leg** | Keep it lying quiet; splint the leg as you find it — don't straighten it; slide a board under to carry it ([FM 3-19.17, pp. 63–64](lib:military-working-dogs#page=63)) |
| **Shock** | Glassy eyes, fast weak pulse, cold lips and feet, pale gums slow to pink. Keep it warm and quiet, head low ([FM 3-19.17, p. 64](lib:military-working-dogs#page=64)) |
| **Overheating** | Shade, fanning, cool running water over head, body and legs, or stand it in a creek, head up; wet cloths in groin and armpits; no more than a cup of water until calm. Check temperature every 5–10 minutes; **stop cooling at 100–103 °F** ([FM 3-19.17, pp. 65–66](lib:military-working-dogs#page=65)) |
| **Rattlesnake bite** | Keep it calm and still; take off the collar (the head swells); a cold pack on the bite; **no tourniquet** ([FM 3-19.17, p. 65](lib:military-working-dogs#page=65)) |
| **Burns** | Cold water or cold packs about 20 minutes, clip, wash gently, loose dressing ([FM 3-19.17, p. 64](lib:military-working-dogs#page=64)) |
| **Stuck in the mouth** | Remove it if it blocks breathing, otherwise leave it for skilled help ([FM 3-19.17, p. 65](lib:military-working-dogs#page=65)). Pawing and drooling can be rabies — gloves ([TM 10-396, pp. 53–54](lib:war-dogs-care#page=53)) |
| **Not breathing** | Clear the mouth, hold it shut, breathe gently into the nose every 5–6 seconds ([FM 3-19.17, p. 64](lib:military-working-dogs#page=64)) |
| **Trap or snare** | **Wire cutters** for snares ([ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)); dogs taught to stand tied often lie still in a snare ([Texas A&M, p. 3](lib:livestock-guardian-dogs-overview#page=3)) |
| **Pills** | Thumb behind the canine tooth to open the mouth, pill at the back of the tongue, close the mouth, stroke the throat ([FM 3-19.17, p. 62](lib:military-working-dogs#page=62)) |

**Medicines:** no doses here. *No Animal Doctor* has dog doses in its drug tables ([pp. 373–394](lib:where-there-is-no-animal-doctor-cvm-2024#page=373));
read [Medical — read me first](guide:Medical-READ-ME-FIRST) before using any medicine. People bitten by dogs: see the
[Field Care guide](guide:FIELD-CARE-GUIDE).

## 📅 A dog year in the Illinois Valley

| When | What's happening | Dog work |
|---|---|---|
| Nov–Mar | Rain and mud; trapping peaks in winter | Dry raised beds, straw changed weekly; comb out mats; bird dogs close, wire cutters along ([ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)) |
| Feb–Apr | Lambing and kidding | Young guardians in the next pen; pick up afterbirth and dead lambs ([AIB 588, p. 18](lib:livestock-guarding-dogs-usda-aib588#page=18)) |
| Apr–Jun | Ticks; grass seeds forming | Daily tick checks; clip long coats before the heat |
| Jun–Oct | Heat, smoke, fire season, foxtails, rattlesnakes | Shade and water; go-kits ready; foxtail checks; no burning bedding |
| Sep–Jan | Bird and pursuit seasons; salmon and steelhead runs | Bird dogs hunt and train ([ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)); keep dogs off fish and gut piles |

The times are local knowledge *(rule of thumb)* except where a book is cited.

## 🕯️ Old age and a humane end

"Old age is not a disease", but with it "comes increased incidence of illness or disability" ([FM 3-19.17, p. 61](lib:military-working-dogs#page=61)).
A guardian may work up to **10 years** ([AIB 588, p. 25](lib:livestock-guarding-dogs-usda-aib588#page=25)). Give an old
dog softer food, a warm dry bed and lighter work, and check its teeth *(rule of thumb)*. **It is time** when it can't get
up, won't eat for days, is in pain you can't ease, or can't control its bowels — or attacks people or keeps killing stock.
Don't wait for it to suffer *(rule of thumb)*.

**How** ([AVMA](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=58)):
- A vet's injection is preferred ([p. 57](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=57)). Gunshot is
  "acceptable with conditions" in remote areas or emergencies where waiting means "prolonged, unrelieved pain and
  suffering", by a skilled shooter where firearms are legal ([p. 58](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=58)).
- **Where:** "midway between the level of the eyes and base of the ears, slightly off midline with aim directed across
  the dog toward the spine" ([p. 115](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=115)).
- **With what:** at least **300 ft-lb** of muzzle energy for animals up to 400 lb; solid-point bullets; a .22 is best
  fired from a rifle ([p. 43](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=43)); outdoors, with a safe
  backstop ([p. 42](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=42)). Let the dog be calm — eating, or
  resting with someone it trusts — and act at close range without hesitating *(rule of thumb)*.
- **Check death:** no heartbeat under the left elbow, no breathing, no blink when the eye is touched
  ([UF VM114, p. 12](lib:humane-euthanasia-of-sick-and-injured-livestock-uf-vm114#page=12)).
- **Burial:** deep and away from water, or burn the body ([Zoonoses, p. 119](lib:zoonoses-diseases-animals-give-people-cvm#page=119));
  bears dig up what is buried shallow ([ODFW bears, p. 2](lib:living-with-black-bears-odfw#page=2)). A body put down by
  injection poisons scavengers ([AVMA, p. 98](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=98)). A dog
  that may have rabies: gloves, hands off the head and saliva, and shots for everyone it bit
  ([*No Animal Doctor*, pp. 270–272](lib:where-there-is-no-animal-doctor-cvm-2024#page=270)).

## 👪 How many dogs for a household

| Job | How many | Source |
|---|---|---|
| Warning at the house | **1** alert dog in the house and yard | [WSDA, p. 1](lib:general-farm-security#page=1); [COPS, p. 20](lib:burglary-of-single-family-houses#page=20) |
| Guarding a small flock where cougars and bears hunt | **2** guardians for up to about 50 ewes or does, a year apart in age, plus a night pen | [Texas A&M, p. 6](lib:livestock-guardian-dogs-overview#page=6); [AIB 588, pp. 11, 26](lib:livestock-guarding-dogs-usda-aib588#page=11) *(rule of thumb)* |
| Herding | **1** trained dog; start its replacement two years ahead — training takes two years | [Wickham, p. 92](lib:practical-training-of-the-shepherd-dog#page=92) *(rule of thumb)* |
| Birds | **1** bird dog, matched to your birds | [Miller, pp. 160, 166](lib:the-american-hunting-dog#page=160) |
| Meat to feed them | About **550 lb** a year for a 50-lb dog, **1,100 lb** for a 100-lb guardian, plus as much again in grain and vegetables | [TM 10-396, pp. 38, 41](lib:war-dogs-care#page=41) *(arithmetic)* |
| Pups | At most **5–6** raised well per litter; heats twice a year | [Miller, pp. 104, 129](lib:the-american-hunting-dog#page=104) |

A household with stock might keep **3–4 dogs** and need **1–2 tons of meat** a year for them *(arithmetic)* — more than
many families eat. Let dogs share jobs (the guardians also warn you), and keep none that do no work. See
[Food Security](guide:FOOD-SECURITY-GUIDE) for your own needs.

## 🧯 If this goes wrong

| Problem | Likely cause and fix |
|---|---|
| Feverish, won't eat, about a week after a fishing trip | Salmon poisoning — most die untreated; cook fish ([ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)) |
| Pup vomiting with bloody diarrhea | Parvo: isolate, keep warm, sips of water, bleach the area ([parvo sheet, pp. 1–4](lib:canine-parvovirus#page=1)) |
| Guardian keeps coming to the house | Petted too much, or bonded too late: take it back each time, no reward; kennel a day or two ([AIB 588, pp. 14–15](lib:livestock-guarding-dogs-usda-aib588#page=14); [Texas A&M, p. 5](lib:livestock-guardian-dogs-overview#page=5)) |
| Guardian left the flock after days of rain | No dry shelter in the pasture ([AIB 588, p. 17](lib:livestock-guarding-dogs-usda-aib588#page=17)) |
| Young guardian chewing ears, chasing lambs | Play, not killing yet: "No", bigger lambs, a dangle chain ([AIB 588, p. 13](lib:livestock-guarding-dogs-usda-aib588#page=13); [Texas A&M, p. 4](lib:livestock-guardian-dogs-overview#page=4)) |
| Dog digs out or jumps the fence | Electric wire inside; tire on a 10-ft chain; never chain by a fence ([Texas A&M, p. 4](lib:livestock-guardian-dogs-overview#page=4); [AIB 588, pp. 21, 26](lib:livestock-guarding-dogs-usda-aib588#page=21)) |
| Belly swelling and retching after a meal and hard work | Bloat: stop food and water, walk it; prevent with two meals and rest ([FM 3-19.17, pp. 66–67](lib:military-working-dogs#page=66)) |
| Constant head shaking in summer | A foxtail in the ear *(rule of thumb)*, or ear trouble ([TM 10-396, p. 33](lib:war-dogs-care#page=33)) |
| Herding dog grips and bites sheep | Rough handling, or worked too young: slow it with "Steady!", never let it bite ([Wickham, pp. 85–86](lib:practical-training-of-the-shepherd-dog#page=85)) |
| Bird dog flinches at the gun | Too much shooting too soon: weeks of hunting with no shells ([Miller, pp. 186–187](lib:the-american-hunting-dog#page=186)) |

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Feed meat raw, raw "at least twice a week"; fresh fish, "particularly cod, salmon" — [TM 10-396, pp. 37–38, 41](lib:war-dogs-care#page=41) | Cook all meat, offal and fish ([*No Animal Doctor*, p. 360](lib:where-there-is-no-animal-doctor-cvm-2024#page=360); [ODFW, p. 34](lib:odfw-2026-2027-game-bird-hunting-regulations#page=34)) |
| "Bones a-plenty" — [Miller, p. 116](lib:the-american-hunting-dog#page=116) | Bones are "absolutely unnecessary" and dangerous; feed bone ground or as meal ([TM 10-396, pp. 39–41](lib:war-dogs-care#page=39)) |
| Make a poisoned dog vomit with salt water, soapy water or dish water — [TM 10-396, p. 54](lib:war-dogs-care#page=54) | Salt can poison a dog; follow the Army's 2005 steps ([FM 3-19.17, p. 65](lib:military-working-dogs#page=65)) |
| Mercury ointment in the eyes before a bath; ether on ticks; creolin (coal-tar) baths — [TM 10-396, pp. 35, 55](lib:war-dogs-care#page=55) | A cloth to keep soap from the eyes; tweezers and a steady pull; grooming, clipping and clean bedding |
| Tourniquet first, loosened every 15 minutes — [TM 10-396, pp. 51–52](lib:war-dogs-care#page=51) | Direct pressure and a pressure bandage; never a tourniquet for snakebite ([FM 3-19.17, pp. 64–65](lib:military-working-dogs#page=64)) |
| Choke chain, leash jerks, a throwing chain, pulling the forelegs out; a short chain to make a dog mean — [TM 10-396, pp. 15–16, 63, 72](lib:war-dogs-care#page=63) | Flat collar or harness, gentle hands, praise, a yard not a chain — the manual's own rule is never to strike a dog ([p. 60](lib:war-dogs-care#page=60)) |
| Shake a pup by the scruff; swat it with a newspaper — [AIB 588, pp. 13, 15](lib:livestock-guarding-dogs-usda-aib588#page=13) | A sharp "No", bigger lambs, a separate pen for a while (same pages) |
| A switch; "a few blows" for disobedience — [Wickham, pp. 82, 92–93](lib:practical-training-of-the-shepherd-dog#page=92) | His own better rule: "kindness is better than severity" ([p. 93](lib:practical-training-of-the-shepherd-dog#page=93)) |
| The spiked "force collar", an air rifle to sting, starving a gun-shy dog, beating a dog that mouths birds — [Miller, pp. 151, 155–156, 165, 167](lib:the-american-hunting-dog#page=151) | Plain collar and check cord, short lessons, praise, a slow start with the gun ([pp. 153, 186–187](lib:the-american-hunting-dog#page=153)) |
| Bichloride of mercury douche after an unwanted mating — [Miller, p. 125](lib:the-american-hunting-dog#page=125) | Mercury is poison. Shut her away in heat; spay now |
| Fowler's solution (arsenic); turpentine for worms; sulfur in crude oil, lye-sulfur dip, carbolic mouthwash — [Miller, pp. 222–223, 232, 117, 247, 227](lib:the-american-hunting-dog#page=222) | Leave them out. Wormers by the label ([*No Animal Doctor*, p. 348](lib:where-there-is-no-animal-doctor-cvm-2024#page=348)); soap and water, clean bedding |
| Dock tails and cut dewclaws with scissors in carbolated vaseline; "Pasteur's serum" for distemper — [Miller, pp. 130–132](lib:the-american-hunting-dog#page=130) | Don't dock; vaccinate with modern vaccines now |

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings and photos in the books on this drive; the other links open the offline Wikipedia.

- Guardian dogs with sheep; Pyrenees pups; a pup raised with lambs — [🖼️ AIB 588, p. 6](lib:livestock-guarding-dogs-usda-aib588#page=6); [🖼️ p. 8](lib:livestock-guarding-dogs-usda-aib588#page=8); [🖼️ p. 12](lib:livestock-guarding-dogs-usda-aib588#page=12); [🖼️ p. 20](lib:livestock-guarding-dogs-usda-aib588#page=20); [Livestock guardian dog](wiki:Livestock_guardian_dog); [Great Pyrenees](wiki:Pyrenean_Mountain_Dog); [Akbash](wiki:Akbash)
- Bonding pens, a dangle stick, tether training, a feeding station, guardian-dog signs — [🖼️ Texas A&M, p. 2](lib:livestock-guardian-dogs-overview#page=2); [🖼️ p. 3](lib:livestock-guardian-dogs-overview#page=3); [🖼️ p. 4](lib:livestock-guardian-dogs-overview#page=4); [🖼️ p. 6](lib:livestock-guardian-dogs-overview#page=6)
- Combing out a Komondor; donkeys and llamas on guard; electric netting — [🖼️ AIB 588, p. 25](lib:livestock-guarding-dogs-usda-aib588#page=25); [🖼️ UC ANR 8598, p. 7](lib:livestock-protection-tools#page=7); [🖼️ p. 9](lib:livestock-protection-tools#page=9)
- A border collie working sheep; bird-dog pups on point — [🖼️ AIB 588, p. 19](lib:livestock-guarding-dogs-usda-aib588#page=19); [🖼️ Miller, p. 114](lib:the-american-hunting-dog#page=114); [Border Collie](wiki:Border_Collie); [Pointing dog](wiki:Pointing_dog); [Western gray squirrel](wiki:Western_gray_squirrel)
- Kennels: Army dog houses, a raised kennel for a hot, wet climate, a two-dog kennel plan — [🖼️ TM 10-396, p. 45](lib:war-dogs-care#page=45); [🖼️ FM 3-19.17, p. 85](lib:military-working-dogs#page=85); [🖼️ Miller, p. 142](lib:the-american-hunting-dog#page=142); [Whelping box](wiki:Whelping_box)
- Brushing and nails; sit, down, stay, the stay hand signal, the drop — [🖼️ TM 10-396, p. 32](lib:war-dogs-care#page=32); [🖼️ p. 70](lib:war-dogs-care#page=70); [🖼️ p. 72](lib:war-dogs-care#page=72); [🖼️ p. 75](lib:war-dogs-care#page=75); [🖼️ p. 84](lib:war-dogs-care#page=84); [🖼️ p. 86](lib:war-dogs-care#page=86)
- Cougar and dog tracks; where to aim when a dog must be put down — [🖼️ ODFW cougar, p. 2](lib:oregon-is-cougar-country-odfw#page=2); [🖼️ AVMA, p. 115](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=115)
- Diseases — [Canine parvovirus](wiki:Canine_parvovirus); [Canine distemper](wiki:Canine_distemper); [Rabies](wiki:Rabies); [Echinococcus granulosus](wiki:Echinococcus_granulosus); [Dirofilaria immitis](wiki:Dirofilaria_immitis) (heartworm)

## 🔗 Related guides

- [Home Defense](guide:HOME-DEFENSE-GUIDE) — watchdogs, guardian dogs and geese as alarms
- [Goats guide](guide:GOATS-GUIDE) and the [Sheep guide](guide:SHEEP-GUIDE) — the flocks guardians protect; night shelter from cougars
- [Chickens guide](guide:CHICKENS-GUIDE) and [Rabbits guide](guide:RABBITS-GUIDE) — predator-proof pens; never feed dogs raw rabbit
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — bird seasons, trap safety, handling fish and game
- [Wildfire guide](guide:WILDFIRE-GUIDE) — evacuation plans for people and animals
- [Food Security](guide:FOOD-SECURITY-GUIDE) and [Preserving Food](guide:PRESERVING-FOOD-GUIDE) — your own food first; drying and storing meat
- [Field Care guide](guide:FIELD-CARE-GUIDE) and [Medical — read me first](guide:Medical-READ-ME-FIRST) — dog bites in people; medicines
- [Mushroom guide](guide:MUSHROOM-GUIDE) — mushrooms that kill dogs as well as people
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — donkeys and working-animal care
