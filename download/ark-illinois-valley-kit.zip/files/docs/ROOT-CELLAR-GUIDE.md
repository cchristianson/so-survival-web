# 🥔 Root Cellars & Food Storage Without Power

How to keep a year's harvest with no refrigerator: root cellars, storage rooms, pits and buried
barrels, cooling with water and evaporation, sun and solar drying, curing and smoking meat,
fermenting, and keeping eggs. The manuals are in `Food-Storage\` (`Root-Cellars-Pits`,
`Cooling-Without-Power`, `Drying`, `Curing-Smoking`, `Fermenting-Eggs-Vinegar`); canning and freezing
are in `Gardening-Food\`.

> ### ⚠️ Rules that prevent food poisoning and losses
> - **Low-acid food in sealed jars needs pressure canning** — never "water bath" or "oven can"
>   vegetables, meat or beans, and never can wild mushrooms. Follow the USDA canning guide exactly.
> - **Cured meat needs exact amounts.** Weigh salt and any curing salt (nitrite/saltpeter) — too little
>   lets meat spoil, too much nitrite is poisonous. Follow one tested recipe; don't mix them.
> - **Cold-smoked fish is not cooked.** Hot-smoke fish to **150–160 °F inside for 30 minutes**
>   ([PNW 238](lib:smoking-fish-at-home-safely)) unless it's heavily salted and dried.
> - **Green potatoes are toxic** ([why](wiki:Solanine)) — store potatoes in the dark and cut away green parts.
> - **Check stored food weekly.** One rotting apple or potato spreads; remove it at once.

---

## 🌡️ The Illinois Valley problem: warm ground

Old root-cellar books assume cold ground. **Deep soil stays near the average yearly air temperature**,
and across most of the U.S. that's 49–58 °F; at 6 ft down clay still swings about ±11 °F through the
year ([MSU *Earth Tempering*, p. 2](lib:earth-tempering-of-ventilation-air#page=2); [🖼️ ground-temperature map and chart](lib:earth-tempering-of-ventilation-air#page=3)). Here the yearly
average is **roughly 54 °F** *(rule of thumb, from Cave Junction's average highs and lows)*. So:

- **A cellar here idles around 50–58 °F.** That's perfect for **[winter squash](wiki:Winter_squash), pumpkins, [sweet potatoes](wiki:Sweet_potato)**,
  and fine for a few weeks of most other crops.
- **To get it down to the 32–40 °F that potatoes, carrots, cabbage and apples want, you must cool it
  with cold night air in winter**: open the vents on cold nights, close them on warm days
  ([USDA FB 1939 (1960), p. 5](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960#page=5);
  [Agriculture Canada Pub. 1478, p. 12](lib:home-storage-room-for-fruits-and-vegetables#page=12);
  [🖼️ where the cold air comes in](lib:home-storage-room-for-fruits-and-vegetables#page=11)).
  November–February nights here regularly fall into the 20s and 30s.
- **In a 50–60 °F space, root crops keep only 3–4 weeks**; packing them in **damp (not wet) sand or soil**
  cuts the shriveling, and a partitioned-off room or outdoor cellar let in to outside air about doubles the time
  ([USDA FB 1939 (1943), pp. 29–30](lib:pits-banks-and-cellars#page=29)).
- **Mild winters are also an advantage:** many crops can simply **stay in the garden** all winter
  (see below), so you need less cellar than people in cold country.

📚 **Go deeper:** [USDA FB 1939 (1943) — storage in a 50–60 °F space, p. 29](lib:pits-banks-and-cellars#page=29); [MSU *Earth Tempering* — ground temperature map, p. 2](lib:earth-tempering-of-ventilation-air#page=2); [PNW 548 — winter vegetables west of the Cascades](lib:winter-vegetable-production).

## 🧺 What each crop needs

Four groups — store each group together ([USDA FB 1939 (1943), p. 19](lib:pits-banks-and-cellars#page=19);
storage life from [Agriculture Canada Pub. 1478, pp. 13–15](lib:home-storage-room-for-fruits-and-vegetables#page=13)):

| Group | Crops | Ideal | Keeps (at ideal) |
|---|---|---|---|
| **Cold & moist** | [Potatoes](wiki:Potato) (39 °F) · carrots, beets, turnips, rutabagas, parsnips, cabbage (32–34 °F) · apples, pears (30–32 °F) | 85–95% humidity | potatoes 4–9 mo · carrots 4–5 · beets 1–3 · cabbage 3–4 · rutabaga ~6 · apples by variety |
| **Cold & dry** | [Onions](wiki:Onion), [garlic](wiki:Garlic) (32 °F) · dry beans, grain | 50–70% humidity, airy | onions 5–9 mo · garlic 6–8 · dry beans years |
| **Cool & fairly dry** | Winter squash, pumpkins | **50–55 °F**, 50–70% | squash ~6 mo · pumpkins 2–3 |
| **Warm-ish** | Sweet potatoes | **55–60 °F**, 75–85% | many months |

- **Potatoes:** first **cure 1–2 weeks at 59–68 °F** in high humidity so skins toughen and cuts heal.
  Below about 38 °F they turn sweet; above 40 °F they sprout sooner; they freeze near 30 °F. Keep them
  **dark**. ([USDA Ag Handbook 66, p. 517](lib:commercial-storage-of-fruits-vegetables#page=517))
- **Winter squash and pumpkins:** cure about **2 weeks at 80–85 °F** (a sunny porch in October), then store
  at 50–55 °F — **colder than 50 °F damages them**.
  ([USDA FB 1939 (1943), p. 30](lib:pits-banks-and-cellars#page=30); [AH 66, p. 525](lib:commercial-storage-of-fruits-vegetables#page=525))
- **Sweet potatoes:** cure about **10 days at 85 °F** and high humidity ([USDA FB 1442](lib:storage-of-sweet-potatoes)),
  then store at **55–60 °F** — below about 55 °F they suffer chilling injury and decay (FB 1442's older 50–55 °F is
  too cold) ([AH 66, p. 577](lib:commercial-storage-of-fruits-vegetables#page=577); [FB 1939 (1943), p. 30](lib:pits-banks-and-cellars#page=30)).
- **Garlic:** keeps 1–2 months at room temperature, 9+ months near freezing
  ([AH 66, p. 343](lib:commercial-storage-of-fruits-vegetables#page=343)).
- **Nuts:** dry [hazelnuts](wiki:Hazelnut) to a crisp kernel; they keep about 2 years below 50 °F
  ([AH 66, p. 761](lib:commercial-storage-of-fruits-vegetables#page=761)).

**Keep apples and pears away from vegetables.** They give off [ethylene gas](wiki:Ethylene_(plant_hormone)), which makes potatoes sprout
and carrots bitter; onion and potato smells taint apples
([Canada Pub. 1260, p. 16](lib:handbook-on-the-storage-of-fruits-and-vegetables#page=16);
[Pub. 1478, p. 4](lib:home-storage-room-for-fruits-and-vegetables#page=4)).

📚 **Go deeper:** [Agriculture Canada Pub. 1478 — crop tables, pp. 13–16](lib:home-storage-room-for-fruits-and-vegetables#page=13); [USDA Ag Handbook 66](lib:commercial-storage-of-fruits-vegetables) — every crop, in detail; [WSU *Storing Vegetables and Fruits at Home*](lib:storing-vegetables-and-fruits-at-home).

## 🏗️ Building a root cellar

**The essentials** ([Canada *A Practical Farm Root Cellar*, pp. 2–6](lib:a-practical-farm-root-cellar#page=2);
[Novia *Handbook for Building a Root Cellar*](lib:handbook-for-building-a-root-cellar); [🖼️ plan of a 10×14 ft farm cellar](lib:a-practical-farm-root-cellar#page=3)):

1. **Drainage first.** Pick a slope or high ground. **On the wet valley floor, build at or above ground
   level and heap earth over it** rather than digging into a winter water table; lay a drain pipe along
   the footings ([Novia, pp. 8–9](lib:handbook-for-building-a-root-cellar#page=8); [🖼️ plan and section drawings](lib:handbook-for-building-a-root-cellar#page=11)).
2. **Earth cover:** at least **3½ ft** of soil and straw over the roof (layers of ~6 in straw and 8–12 in
   soil), carried well past the sides. Add soil as the straw rots.
3. **Two vents at opposite ends,** about **12 in square** for a 10×14 ft cellar ([🖼️ how the air flows through](lib:handbook-for-building-a-root-cellar#page=43); [🖼️ vents in a cellar cross-section](lib:pits-banks-and-cellars#page=14)):
   - **Intake:** brings outside air **down to about 1½ ft above the floor**.
   - **Outlet:** starts at the **ceiling** and rises well above the roof (warm air leaves high).
   - Both **adjustable**, and **screened** against rodents and insects.
4. **Double doors** about 4 ft apart act as an air lock. **Face the door north and keep it shaded** so
   summer sun doesn't heat it ([Novia, pp. 13–14](lib:handbook-for-building-a-root-cellar#page=13)).
5. **Floor of earth or gravel** — it holds moisture. Shelves of **slats 4 in off the floor and walls**
   so air moves around everything.
6. **A thermometer and a [humidity gauge](wiki:Hygrometer)** inside (or a wet rag test: if things shrivel, it's too dry —
   sprinkle the floor).

![A root cellar cut through, covered by a mound of earth and straw: a vent pipe brings cold night air down to about 1½ ft above the floor at one end, warm air rises out of a second pipe at the ceiling at the other end, with slatted shelves, an earth floor and two doors at the entrance](img:ROOT-CELLAR-GUIDE/cellar-vents-and-night-air.svg)
*Night venting: open both vents on cold nights so cold air pours in low and warm air leaves high; close them on warm days (a diagram drawn for this guide).*

![Old drawing of a concrete storage cellar cut through: a ventilator at the top of the earth cover, an air inlet and air duct under the slat floor, and slatted bins along one wall](img:ROOT-CELLAR-GUIDE/cellar-cross-section.png)
*The same idea in a USDA plan: air comes in under the slat floor and leaves through the ventilator at the top ([USDA FB 1939 (1943), p. 14](lib:pits-banks-and-cellars#page=14)).*

**Simpler options:**
- **Basement-corner storage room:** about 10×10 ft with an outside window. Insulate the two inside walls
  and the ceiling (vapor barrier on the warm side), and run an intake duct from the window down to about
  18 in above the floor ([Pub. 1478, pp. 8–12](lib:home-storage-room-for-fruits-and-vegetables#page=8); [🖼️ perspective view](lib:home-storage-room-for-fruits-and-vegetables#page=9); [🖼️ cross-section](lib:home-storage-room-for-fruits-and-vegetables#page=11)).
- **Above-ground and part-underground cellars:** plans in
  [USDA FB 1939 (1960)](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960) ([🖼️ partly underground cellar](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960#page=7); [🖼️ outdoor cellar, side view](lib:pits-banks-and-cellars#page=12)).
- **Unheated outbuilding, porch or garage:** works for squash, onions and dry goods — not for the cold &
  moist group.

📚 **Go deeper:** [Canada *A Practical Farm Root Cellar* — full plan, p. 2](lib:a-practical-farm-root-cellar#page=2); [Novia *Handbook for Building a Root Cellar*](lib:handbook-for-building-a-root-cellar) — photo step by step; [USDA FB 1939 (1943) — cellars, pits and banks](lib:pits-banks-and-cellars); [Wikipedia: root cellar](wiki:Root_cellar).

## 🕳️ Pits, clamps, buried barrels — and the garden itself

- **Cone pit** ([USDA FB 1939 (1943), p. 16](lib:pits-banks-and-cellars#page=16); [🖼️ cross-section](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960#page=9)): on well-drained ground,
  dig 6–8 in deep, line with straw or leaves, pile the vegetables in a cone, cover with straw, then
  **2–3 in of earth, thickened as winter comes**. Leave a tuft of straw sticking out the top as a vent and
  cap it with a board. **Open a pit all at once** and use a new spot each year
  ([FB 1939 (1960), p. 9](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960#page=9)).
- **Clamp (long mound)** for potatoes: a straw bed, a vent duct along the bottom, about 8 in of packed
  straw and up to 12 in of soil; in mild climates use **more straw and less soil**
  ([FAO *Prevention of Post-Harvest Losses*](lib:prevention-of-post-harvest-food-losses); [🖼️ clamp drawing](lib:prevention-of-post-harvest-food-losses#page=104)).
- **Buried barrel or trash can:** a clean food-safe barrel laid in the ground on a slant so water runs
  out, mouth facing the path, covered with straw and earth
  ([USDA FB 1939 (1943), p. 18](lib:pits-banks-and-cellars#page=18); [🖼️ barrel pit](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960#page=10); [🖼️ buried trash can](lib:storing-vegetables-and-fruits-at-home#page=3)). Line or wrap it with
  **¼-inch hardware cloth** against gophers and voles *(rule of thumb)*.
- **Leave it in the ground** ([🖼️ in-garden and mound storage](lib:storing-vegetables-and-fruits-at-home#page=2)): [parsnips](wiki:Parsnip), carrots, beets, [leeks](wiki:Leek), kale, collards and rutabagas can stay in
  the garden through most Illinois Valley winters — **in raised or ridged beds** so roots don't rot in
  waterlogged soil, with straw over the roots in hard cold
  ([FB 1939 (1960), pp. 14–17](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960#page=14);
  [PNW 548](lib:winter-vegetable-production); [🖼️ raised beds](lib:winter-vegetable-production#page=4)). [Gophers](wiki:Gopher) and [voles](wiki:Vole) are the main risk.

![Old drawing of a storage pit cut through: potatoes piled in a cone on straw, covered with straw and then soil, with a straw vent up through the peak capped by a board and a stone, and a drain ditch on each side](img:ROOT-CELLAR-GUIDE/storage-pit-cross-section.png)
*A cone pit: straw around the vegetables, earth over the straw, a straw vent up the middle capped with a board, and drains around it ([USDA FB 1939 (1960), p. 9](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960#page=9)).*

📚 **Go deeper:** [USDA FB 1939 (1943) — pits, banks and barrels, pp. 16–18](lib:pits-banks-and-cellars#page=16); [FAO — potato clamps](lib:prevention-of-post-harvest-food-losses).

## ❄️ Cooling without power

- **Springhouse:** water from a spring or deep well sits near ground temperature — **about 52–55 °F here**
  *(rule of thumb)*. Run it through an insulated tank or a shaded stone trough and stand crocks, milk cans
  and butter in it ([USDA FB 976](lib:cooling-milk-and-cream-on-the-farm); [🖼️ insulated cooling tank](lib:cooling-milk-and-cream-on-the-farm#page=7)). See
  [springhouse](wiki:Spring_house).
- **[Evaporative cooler](wiki:Evaporative_cooler) — made for our dry summers:** a screened cabinet covered in flannel or burlap,
  kept wet by wicks from a pan of water on top, in **shade and breeze**. In hot, dry weather it can hold
  about 50 °F inside; it works poorly in humid weather
  ([USDA *The Iceless Refrigerator*](lib:the-iceless-refrigerator)). Bigger versions use a wall of wet
  charcoal, or a **double brick wall with wet sand between** (about 400 bricks keeps 220 lb of produce),
  wetted twice a day ([Practical Action *Evaporative Cooling*, p. 2](lib:charcoal-coolers-and-brick-cool-chambers#page=2); [🖼️ charcoal cooler](lib:charcoal-coolers-and-brick-cool-chambers#page=2); [🖼️ brick cool chamber](lib:charcoal-coolers-and-brick-cool-chambers#page=3)).
  The clay-pot [zeer](wiki:Pot-in-pot_refrigerator) is the small version (`Homestead-Skills\Food-Crafts-Tools`; [🖼️ how it works](lib:practical-action-clay-pot-cooler#page=2); [🖼️ pot sizes](lib:practical-action-clay-pot-cooler#page=3)).
- **[Ice house](wiki:Ice_house_(building)):** ice packed in **at least 15 in of sawdust** on all sides, on a drained floor, keeps
  through summer ([USDA FB 475, pp. 6, 12–13](lib:ice-houses#page=6); [🖼️ insulation diagram](lib:ice-houses#page=7)). Valley ponds rarely freeze thick,
  but the bulletin shows freezing ice in metal cans on cold nights. *Realistically a small ice store is a
  winter-only luxury here.*

![Drawing of a brick cool chamber: a double brick wall with wet sand in the cavity between, trays of food inside, and a raised water tank with a drip hose keeping the sand wet](img:ROOT-CELLAR-GUIDE/brick-cool-chamber.png)
*The brick cool chamber: keep the sand between the two brick walls wet and the food inside stays cool ([Practical Action, p. 3](lib:charcoal-coolers-and-brick-cool-chambers#page=3)).*

📚 **Go deeper:** [USDA *The Iceless Refrigerator*](lib:the-iceless-refrigerator); [Practical Action — charcoal and brick coolers](lib:charcoal-coolers-and-brick-cool-chambers); [USDA FB 475 *Ice Houses*](lib:ice-houses).

## ☀️ Drying food

**Our hot, dry late summer is ideal drying weather.** Sun drying needs about **90 °F, low humidity and
clean air**; dependable drying needs several days in a row near 95 °F
([PNW 651, p. 16](lib:drying-project-manual#page=16)).

- **Trays:** wooden frames with food-safe screen (not galvanized); cover with cheesecloth or netting
  against insects; **bring trays in at night** so dew doesn't re-wet the food
  ([USDA FB 984, pp. 13–14](lib:farm-and-home-drying#page=13); [🖼️ screened solar drier](lib:farm-and-home-drying#page=16)).
- **Solar dryer:** a dark box with a clear top, vents low and high, and screened trays — a 3×6 ft dryer
  serves a household of 4–6 ([Practical Action *A Simple Solar Dryer*](lib:a-simple-solar-dryer); [🖼️ layout](lib:a-simple-solar-dryer#page=2));
  more designs in the Peace Corps [solar food technologies manual](lib:solar-and-energy-conserving-food-technologies)
  and [Practical Action *Solar Drying*](lib:solar-drying-cabinet-tent-and-tunnel-dryers) ([🖼️ cabinet and tent dryers](lib:solar-drying-cabinet-tent-and-tunnel-dryers#page=2)).
- **Is it dry?** Fruit is **leathery with no moist center** ([photos](wiki:Dried_fruit)); vegetables are brittle. Squeeze a handful of
  fruit: it should spring apart "like rubber bands." Then **condition** it at least 2–4 days in a covered jar,
  shaking daily — if moisture beads up, dry it more
  ([USDA FB 984, p. 47](lib:farm-and-home-drying#page=47); [PNW 651, pp. 17–19](lib:drying-project-manual#page=17)).
- **Don't dry outdoors in wildfire smoke** — ash settles on the food *(rule of thumb)*.
- Jerky: [PNW 632](lib:making-jerky-at-home-safely) ([🖼️ dry enough: cracks, doesn't snap](lib:making-jerky-at-home-safely#page=18)). Store everything dry in sealed jars.

![Exploded drawing of a simple solar dryer: a plastic-covered wood frame on top, two wooden trays with black-painted metal mesh, and a box painted black inside with air inlets low on one side and air outlets high on the other, on an earth platform](img:ROOT-CELLAR-GUIDE/solar-dryer-layout.png)
*A solar dryer's parts: clear cover, mesh trays, a black-painted box with air inlets low and outlets high ([Practical Action, p. 2](lib:a-simple-solar-dryer#page=2)).*

📚 **Go deeper:** [PNW 651 *Drying Project Manual*](lib:drying-project-manual) — fruit-by-fruit and vegetable-by-vegetable; [USDA FB 984 *Farm and Home Drying*](lib:farm-and-home-drying) — sun driers and evaporators.

## 🥓 Curing and smoking meat

Dry-cured country ham and bacon keep **without refrigeration** once cured, smoked and aged.

- **Cure in the cold season:** meat must stay **36–40 °F for the whole cure** — warmer risks spoilage,
  colder stops the salt from soaking in ([USDA *Curing Pork Country Style*, p. 5](lib:curing-pork-country-style#page=5)).
  Here that means **December–February**, in a cellar or shed vented on cold nights. Carver's bulletin
  covers curing where winters are too warm ([Carver 1912](lib:pickling-and-curing-of-meat-in-hot-weather)).
- **The cure:** about **8 lb salt + 2 lb sugar per 100 lb of meat**, rubbed in, repeated after about a week;
  **1½–2 days per pound** of ham ([🖼️ parts of a ham](lib:dry-curing-virginia-style-ham#page=1); [🖼️ rubbing in the cure](lib:how-to-make-a-country-ham#page=3); [Virginia Tech 458-223, p. 3](lib:dry-curing-virginia-style-ham#page=3);
  [Kentucky ASC-213](lib:how-to-make-a-country-ham)). Curing salt (nitrite) must be **weighed exactly** —
  use a commercial premix by its label.
- **Smoke** with hardwood (never pine) at **100–120 °F** for cured pork
  ([Leaflet 273, p. 8](lib:curing-pork-country-style#page=8)). A barrel smoker at the top of a sloping
  covered trench, fire at the bottom, is the simplest [smokehouse](wiki:Smokehouse)
  ([USDA AWI-68](lib:smokehouses-and-hog-slaughtering-equipment); [🖼️ firebox plan](lib:smokehouses-and-hog-slaughtering-equipment#page=8)).
- **Store:** wrap cooled hams, bag in muslin or paper ([🖼️ wrapped and bagged](lib:how-to-make-a-country-ham#page=4)), and hang in a dark, dry, airy, rat-proof place;
  [skipper flies](wiki:Cheese_fly) don't breed below 45 °F ([Leaflet 273, p. 8](lib:curing-pork-country-style#page=8); [🖼️ ham pests](lib:dry-curing-virginia-style-ham#page=5)).
- **Fish:** dry-salting keeps longer than brining in warm weather
  ([Fishery Leaflet 18, p. 5](lib:home-preservation-of-fishery-products#page=5)); hot-smoke fish to safe
  temperatures ([PNW 238](lib:smoking-fish-at-home-safely); [🖼️ smoker layout](lib:smoking-fish-at-home-safely#page=3)).

📚 **Go deeper:** [Kentucky *How to Make a Country Ham*](lib:how-to-make-a-country-ham) — modern step by step; [USDA *Curing Pork Country Style*](lib:curing-pork-country-style); [Fishery Leaflet 18](lib:home-preservation-of-fishery-products); [Wikipedia: country ham](wiki:Country_ham).

## 🥬 Fermenting, salting, eggs and vinegar

- **Sauerkraut:** **2½% salt — 1 lb salt to 40 lb cabbage** (about 3 Tbsp per 5 lb); pack in a [crock](wiki:Crock_(dishware)) ([🖼️ crocks and jars](lib:making-fermented-pickles-and-sauerkraut#page=5)),
  weight it so brine covers the cabbage, skim scum. Ferment **3–4 weeks at 70–75 °F or 5–6 weeks at
  60–65 °F**; below 60 °F it may not ferment, above 75 °F it goes soft
  ([USDA FB 1438, p. 14](lib:making-fermented-pickles-and-sauerkraut#page=14);
  [USDA canning Guide 6](lib:guide-6-fermented)). Old bulletins say 86 °F and paraffin seals — **don't**.
- **Salted vegetables** (beans, greens, corn) in crocks: recipes in the
  [1918 Food Administration bulletin](lib:preserving-vegetables-by-salting-drying-and-storing).
- **Eggs for months** (USDA says 6–9, FAO only 1–6; plan on the shorter — see the [Preserving guide](guide:PRESERVING-FOOD-GUIDE)):
  fresh, clean, uncracked spring eggs in a crock of **1 quart water glass
  ([sodium silicate](wiki:Sodium_silicate)) to 9 quarts boiled, cooled water**, with 2 in of liquid over them; or clear [lime water](wiki:Calcium_hydroxide).
  Prick the shell before boiling ([USDA *Home Methods of Preserving Eggs*](lib:home-methods-of-preserving-eggs)).
- **Vinegar:** fruit juice → alcohol (yeast) → vinegar ([air-loving bacteria](wiki:Acetobacter)). Leave the container open to
  air under cheesecloth and keep it at least 70 °F ([USDA FB 1424](lib:making-vinegar); [🖼️ barrel "converter"](lib:making-vinegar#page=12)).

📚 **Go deeper:** [USDA FB 1438 *Fermented Pickles and Sauerkraut*](lib:making-fermented-pickles-and-sauerkraut); [USDA canning Guide 6 — fermented foods](lib:guide-6-fermented); [Wikipedia: sauerkraut](wiki:Sauerkraut).

## 🐀 Keeping rats, mice and bugs out

- **[Mice](wiki:House_mouse) get through ¼-inch gaps.** Use ¼-inch hardware cloth on vents and storage bins *(rule of thumb)*;
  line corncribs and grain bins with galvanized hardware cloth
  ([USDA *Rat Proofing Buildings*, p. 10](lib:rat-proofing-buildings#page=10); [🖼️ rat-proof grain bin and walls](lib:rat-proofing-buildings#page=10)).
- **Foundations:** concrete curtain walls 2 ft below ground, and metal or stucco on lath 2 ft up the walls,
  stop burrowing [rats](wiki:Brown_rat) ([*Rat Proofing*, p. 8](lib:rat-proofing-buildings#page=8); [🖼️ concrete curtain wall](lib:rat-proofing-buildings#page=21)).
- **Grain, beans and dried food in metal or glass** with tight lids. **Freeze dry beans and grain 2–3 days, warm
  them a day, then freeze again** (freezing alone misses some eggs), or heat them, to kill [weevils](wiki:Acanthoscelides_obtectus) — not the old chemical fumigants
  ([USU, p. 95](lib:food-storage-for-emergencies#page=95)).
- **Cats, traps and tidiness** — no open feed, no clutter for nesting.

📚 **Go deeper:** [USDA *Rat Proofing Buildings and Premises*](lib:rat-proofing-buildings); [Food From Scratch — storing grain](guide:FOOD-FROM-SCRATCH-GUIDE).

## 📆 A storage year in the Illinois Valley *(rule of thumb)*

| Month | Do this |
|---|---|
| **Aug–Sept** | Sun-dry fruit, tomatoes, beans and herbs. Cure onions and garlic in shade, then braid or bag. |
| **Oct** | Cure winter squash and pumpkins on a sunny porch, then into a 50–55 °F room. Cure potatoes 1–2 weeks, then into the dark. |
| **Nov** | Start **night-venting** the cellar as nights drop into the 30s. Move apples, potatoes, carrots, beets and cabbage in as it cools. Mulch roots left in the garden. |
| **Dec–Feb** | Coldest stretch: cure hams and bacon; make sauerkraut slowly; check stored food weekly. |
| **Mar–Apr** | Use up cellar crops before they sprout; replant the best roots for seed (see the [Seed Bank guide](guide:SEED-BANK-GUIDE)). Put up spring eggs in water glass. |
| **May–July** | Cellar warms toward 55 °F: dry goods, squash, canned and dried food only. Evaporative cooler and springhouse for butter, milk and greens. |

📚 **Go deeper:** [PNW 548 *Winter Vegetable Production*](lib:winter-vegetable-production) — winter crops west of the Cascades; [WSU *Storing Vegetables and Fruits at Home*](lib:storing-vegetables-and-fruits-at-home) — storage times and temperatures.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Ground temperature and the crops**
- Ground-temperature map and yearly soil curve — [🖼️ MSU *Earth Tempering*, p. 3](lib:earth-tempering-of-ventilation-air#page=3)
- Storage crops — [Potato](wiki:Potato); [Winter squash](wiki:Winter_squash); [Sweet potato](wiki:Sweet_potato); [Onion](wiki:Onion); [Garlic](wiki:Garlic)
- Green potatoes — [Solanine](wiki:Solanine)
- Why apples are kept apart — [Ethylene as a plant hormone](wiki:Ethylene_(plant_hormone))

**Root cellars and storage rooms**
- Plan of a 10×14 ft farm root cellar — [🖼️ Canada FB 98, p. 3](lib:a-practical-farm-root-cellar#page=3); [Root cellar](wiki:Root_cellar)
- Root cellar plan, section and elevations — [🖼️ Novia, p. 11](lib:handbook-for-building-a-root-cellar#page=11); [🖼️ p. 12](lib:handbook-for-building-a-root-cellar#page=12)
- How air flows through a cellar — [🖼️ Novia, p. 43](lib:handbook-for-building-a-root-cellar#page=43)
- Cellar cross-section with vents, slat floor and bins — [🖼️ USDA FB 1939 (1943), p. 14](lib:pits-banks-and-cellars#page=14)
- Outdoor cellar, end and side views — [🖼️ USDA FB 1939 (1943), p. 12](lib:pits-banks-and-cellars#page=12)
- Partly underground stone cellar — [🖼️ USDA FB 1939 (1960), p. 7](lib:home-storage-of-vegetables-and-fruits-usda-fb-1939-rev-1960#page=7)
- Basement-corner storage room — [🖼️ Pub. 1478, p. 9](lib:home-storage-room-for-fruits-and-vegetables#page=9); [🖼️ cross-section, p. 11](lib:home-storage-room-for-fruits-and-vegetables#page=11)
- Humidity gauge — [Hygrometer](wiki:Hygrometer)

**Pits, clamps and barrels**
- Cone pit of potatoes — [🖼️ USDA FB 1939 (1943), p. 16](lib:pits-banks-and-cellars#page=16)
- Potato clamp — [🖼️ FAO, p. 104](lib:prevention-of-post-harvest-food-losses#page=104)
- Barrel pit — [🖼️ USDA FB 1939 (1943), p. 18](lib:pits-banks-and-cellars#page=18)
- Cabbage pit and pen — [🖼️ USDA FB 1939 (1943), p. 20](lib:pits-banks-and-cellars#page=20)
- In-garden, mound and buried-can storage — [🖼️ WSU EB1326, p. 2](lib:storing-vegetables-and-fruits-at-home#page=2); [🖼️ p. 3](lib:storing-vegetables-and-fruits-at-home#page=3)
- Roots left in the field — [🖼️ PNW 548, p. 46](lib:winter-vegetable-production#page=46)
- The diggers — [Pocket gopher](wiki:Gopher); [Vole](wiki:Vole)

**Cooling without power**
- Insulated spring-water cooling tank — [🖼️ USDA FB 976, p. 7](lib:cooling-milk-and-cream-on-the-farm#page=7); [Spring house](wiki:Spring_house)
- Charcoal cooler and brick cool chamber — [🖼️ Practical Action, p. 2](lib:charcoal-coolers-and-brick-cool-chambers#page=2); [🖼️ p. 3](lib:charcoal-coolers-and-brick-cool-chambers#page=3); [Evaporative cooler](wiki:Evaporative_cooler)
- Clay-pot cooler (zeer) — [🖼️ Practical Action, p. 3](lib:practical-action-clay-pot-cooler#page=3); [Pot-in-pot refrigerator](wiki:Pot-in-pot_refrigerator)
- Ice-house insulation — [🖼️ USDA FB 475, p. 7](lib:ice-houses#page=7); [Ice house](wiki:Ice_house_(building))

**Drying, curing and smoking**
- Screened solar drier — [🖼️ USDA FB 984, p. 16](lib:farm-and-home-drying#page=16)
- Brick-and-plastic solar dryer — [🖼️ Practical Action, p. 2](lib:a-simple-solar-dryer#page=2)
- Country ham: cure, wrap, bag — [🖼️ Kentucky, p. 3](lib:how-to-make-a-country-ham#page=3); [🖼️ p. 4](lib:how-to-make-a-country-ham#page=4); [Country ham](wiki:Country_ham)
- Ham pests: skipper, larder beetle, mites — [🖼️ Virginia Tech, p. 5](lib:dry-curing-virginia-style-ham#page=5); [Piophila casei](wiki:Cheese_fly)
- Farm smokehouse firebox — [🖼️ USDA AWI-68, p. 8](lib:smokehouses-and-hog-slaughtering-equipment#page=8); [Smokehouse](wiki:Smokehouse)

**Ferments, eggs, vinegar and pests**
- Crocks for kraut — [🖼️ USDA FB 1438, p. 5](lib:making-fermented-pickles-and-sauerkraut#page=5); [Sauerkraut](wiki:Sauerkraut)
- Vinegar barrel — [🖼️ USDA FB 1424, p. 12](lib:making-vinegar#page=12); [Mother of vinegar](wiki:Mother_of_vinegar)
- Rat-proof grain bin and concrete curtain wall — [🖼️ USDA FB 1638, p. 10](lib:rat-proofing-buildings#page=10); [🖼️ p. 21](lib:rat-proofing-buildings#page=21); [Brown rat](wiki:Brown_rat)

---

## 🔗 Related guides

- [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — how much cold ice and cold water hold, and making ice in cans
- [Your Seed Bank](guide:SEED-BANK-GUIDE) — growing what goes into storage
- [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — grain, flour, lard, salt
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE)
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE)
