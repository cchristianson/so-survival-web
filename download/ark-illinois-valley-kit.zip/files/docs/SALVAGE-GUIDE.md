# ♻️ Salvage: Useful Things From Broken Things

When the stores are shut, every dead washing machine, freezer and car around the Illinois Valley is a parts store. This
guide takes the broken things you are most likely to find one at a time, always in the same order: what is inside
worth keeping, what to make with it, and what can hurt you. It starts with the few things never to cut, burn or
open, and a table to find a part fast. The books behind it are in `Engines-Motors\`, `Electronics-Repair\`,
`Blacksmithing-Tools\` and `Homestead-Skills\`; each link opens a book at the right page. Much salvage know-how is
in no book at all: those lines say *(rule of thumb)*.

> ### The short version
> - **Make it dead before you open it.** Unplug it, drain it, and discharge every capacitor: the charge left in one
>   "is, in many cases, sufficient to cause a lethal shock" ([NEETS 21, p. 32](lib:neets-module-21-test-methods-and-practices#page=32)).
> - **A few things are never cut, burned or opened** (the list is just below): gas and air tanks, fridge pipes,
>   microwave high-voltage parts, picture tubes, smoke detectors, lithium packs, fluorescent tubes, and drums that
>   held chemicals.
> - **The box is often the best part.** A dead freezer is an insulated chest, a washer's drum a fire pit, an electric
>   water heater a glass-lined tank, an oil drum a stove *(rule of thumb)*.
> - **Keep every motor.** Washer and dryer motors turn grinders and pumps; the magnet motors in treadmills and
>   cordless tools make power when you spin them ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#motors-as-generators)).
> - **Wind rarely pays.** It needs an average wind of at least **9 mph**
>   ([DOE *Small Wind*, p. 20](lib:doe-small-wind-electric-systems-consumers-guide#page=20)), and a car alternator
>   on a small homemade rotor makes almost nothing ([below](#the-alternator-and-the-wind-question)).
> - **Never burn plastic, rubber, tires or treated wood, and never heat galvanized or old painted steel**
>   ([Hesperian ch. 18, p. 24](lib:hesperian-community-guide-to-environmental-health-ch-18-solid-waste-2012#page=24);
>   [*Wood Handbook*, p. 329](lib:wood-handbook-wood-as-an-engineering-material-usda-fpl-gtr-190-2010#page=329);
>   [Navy *Hospital Corpsman*, p. 220](lib:hospital-corpsman-nonresident-training-course-navedtra-14295-us-navy-2000#page=220)).
> - **Sort metal as you go:** a magnet, a grinder's sparks and the weight tell most scrap apart
>   ([Navy *Steelworker*, pp. 21–25](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=21)).
> - **A dry, sorted, labelled parts store beats a pile** *(rule of thumb)*.

---

## ☠️ Never cut, burn or open these

These kill or poison people who salvage. Leave them whole, or use only what the last column says.

| Thing | Why | Instead |
|---|---|---|
| **Propane tanks, gas cylinders, air tanks, fire extinguishers** | An "empty" tank still holds gas: tanks and drums that held fuel are "potentially more dangerous than a filled container" ([FM 10-67-1, p. 14](lib:fm-10-67-1-petroleum-supply-operations-us-army-1998#page=14)). A steel cylinder that bursts acts like "a bomb burst" ([FM 10-67-2, p. 118](lib:fm-10-67-2-petroleum-testing-us-army-1997#page=118)) | Use a tank only for what it held. Never heat, weld or cut one, or make a stove or boiler of it ([Heat into Power](guide:HEAT-INTO-POWER-GUIDE#what-never-to-use-as-a-boiler)) |
| **Fridge, freezer and air-conditioner pipes** | The gas is under pressure; handle it with "extreme caution" ([TM 9-8000, p. 715](lib:tm-9-8000-principles-of-automotive-vehicles#page=715)). A gas (absorption) fridge holds ammonia, pressure-tested to 717 psi ([NBS report, p. 9](lib:performance-evaluation-of-a-propane-fired-absorption-refrigerator#page=9)) | Keep the sealed pipes shut; use the cabinet ([Fridges and freezers](#fridges-and-freezers)) |
| **Microwave-oven transformer, capacitor and magnetron** | Thousands of volts ([Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#electronics-repair-and-salvage)), and a capacitor's leftover charge can be "sufficient to cause a lethal shock" ([NEETS 21, p. 32](lib:neets-module-21-test-methods-and-practices#page=32)) | Discharge it, keep the safe parts, never power the transformer ([Microwave ovens](#microwave-ovens)) |
| **Old tube TVs and monitors (CRTs)** | A broken tube implodes: "Almost two tons of force hurl glass fragments," and the face's coating "is extremely toxic" ([NEETS 6, p. 131](lib:neets-module-06-electronic-emission-tubes-and-power-supplies#page=131)). Up to 30,000 volts inside ([NEETS 7, p. 268](lib:neets-module-07-solid-state-devices-and-power-supplies#page=268)) | Leave the tube whole; take only the case, knobs and speaker *(rule of thumb)* |
| **Smoke detectors** | The common (ionization) kind holds "a small amount of radioactive material" ([TM 5-683, p. 139](lib:tm-5-683-electrical-interior-facilities-army-navy-air-force-1995#page=139)) | Keep it working: smoke detectors "reduce the risk of deaths by over 70%" ([WHO, p. 107](lib:world-report-on-child-injury-prevention-drowning-burns-falls-poisoning-who-unicef-2008#page=107)). Never open, crush or burn one *(rule of thumb)* |
| **Lithium batteries** (phones, laptops, tools, e-bikes) | A charged cell is "a fire or explosion hazard if crushed, punctured, or incinerated" ([Lighting Global, p. 8](lib:lighting-global-lithium-ion-batteries-part-i-overview-world-bank-2019#page=8)) | Never cut a pack open; reuse it whole ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#lithium-lifepo4-and-salvaged-packs)) |
| **Fluorescent tubes and CFL bulbs** | Mercury: burning turns it "into even more harmful gas" ([Hesperian ch. 19, p. 23](lib:hesperian-community-guide-to-environmental-health-ch-19-health-care-waste-2012#page=23)) | Store them whole with the toxics; a broken one: [Sanitation](guide:SANITATION-GUIDE#hazardous-waste-batteries-oil-fuel-chemicals-medicines) |
| **Treated lumber, tires, plastic, wire insulation**: never burn | Treated wood "should not be burned in open fires or in stoves" ([*Wood Handbook*, p. 329](lib:wood-handbook-wood-as-an-engineering-material-usda-fpl-gtr-190-2010#page=329)); "burning even small amounts of plastic or rubber releases toxic chemicals such as dioxins, furans, and PCBs" ([Hesperian ch. 18, p. 24](lib:hesperian-community-guide-to-environmental-health-ch-18-solid-waste-2012#page=24)) | Strip wire with a knife, not a fire *(rule of thumb)*. Reuse or bury the rest ([Sanitation](guide:SANITATION-GUIDE#burning-trash-and-brush-and-ash)) |
| **Galvanized steel**, heated or welded | Vaporized zinc from its coating causes metal fume fever ([Navy *Hospital Corpsman*, p. 220](lib:hospital-corpsman-nonresident-training-course-navedtra-14295-us-navy-2000#page=220)): "temporary sickness, or death" ([TC 9-524, p. 15](lib:us-army-tc-9-524-fundamentals-of-machine-tools-1996#page=15)) | Never a fire pit, grill, stove or forge part. Cut it cold, with snips or a hacksaw *(rule of thumb)* |
| **Lead paint and asbestos** in old appliances, cars and buildings | Lead paint was used on houses until 1976 and "is still manufactured … for metal products, particularly those made of steel" ([*Wood Handbook*, pp. 391–392](lib:wood-handbook-wood-as-an-engineering-material-usda-fpl-gtr-190-2010#page=391)). Asbestos was used in heat insulation, "brake linings and clutch facings" and gaskets, and causes fatal lung disease ([NEETS 4, p. 110](lib:neets-module-04-conductors-wiring-techniques-and-schematics#page=110)) | Never torch, grind or burn painted scrap. Leave old heat shields, pipe wrap and brake dust alone *(rule of thumb)* |
| **Drums and tanks that held fuel or chemicals** | Heat or sparks on used barrels "is extremely dangerous and could lead to property damage or loss of life" ([Navy *Steelworker*, pp. 95–96](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=95)). Pesticide drums: "Do not attempt to use the drums" where they could reach feed or water ([Peace Corps M-2, p. 421](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=421)) | Read the label first. Cut a fuel drum only as in [55-gallon drums](#55-gallon-drums-and-ibc-totes); never reuse a pesticide drum |

## 🔎 I need… → where to find it

| I need… | Look in | See |
|---|---|---|
| **A motor** | Washers and dryers, furnace blowers, treadmills and cordless tools (magnet motors that also make power), drills, fans | [Washers](#washing-machines-and-dryers), [Treadmills](#treadmills), [Power tools](#ceiling-fans-drills-and-power-tools) |
| **12-volt power** | A car's battery and alternator, battery-backup (UPS) boxes, computer power supplies, solar garden lights | [Cars](#battery-wire-lights-and-horn), [Computers](#computers-ups-boxes-phones-and-tablets), [Garden lights](#solar-garden-lights-and-spent-batteries) |
| **Wire** | Extension and appliance cords, car wiring, motors and transformers (fine "magnet wire") | [Cars](#battery-wire-lights-and-horn), [Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#electronics-repair-and-salvage) |
| **Steel and springs** | Leaf and coil springs, old files, saw and mower blades, bed and trampoline frames, drums | [Springs](#leaf-and-coil-springs), [Scrap pile](#the-scrap-pile-sorting-metals) |
| **A stove or fire pit** | A washer drum, a steel drum, a water-heater tank, a brake drum | [Washers](#washing-machines-and-dryers), [Drums](#55-gallon-drums-and-ibc-totes), [Water heaters](#water-heaters) |
| **Water storage** | Food-grade drums and IBC totes, a water heater's tank, gutters to fill them | [Drums](#55-gallon-drums-and-ibc-totes), [Water heaters](#water-heaters) |
| **Insulation** | Fridge and freezer walls, water-heater foam, mattress and seat foam | [Fridges](#fridges-and-freezers), [Water heaters](#water-heaters) |
| **Glass and mirrors** | Old windows and doors, car mirrors, oven doors, microwave plates | [Windows](#old-windows-and-doors), [Car mirrors](#mirrors-and-glass) |
| **Wheels** | Bicycles, lawn mowers, strollers, wheelbarrows, car hubs | [Bicycles](#bicycles), [Mowers](#lawn-mowers-and-small-engines) |
| **Fans** | Computers (12 V), car radiators (12 V), microwaves, dryers, furnaces | [Computers](#computers-ups-boxes-phones-and-tablets), [Dryers](#washing-machines-and-dryers) |
| **Pumps** | Washer and dishwasher drain pumps, a car's windshield-washer pump (12 V) | [Washers](#washing-machines-and-dryers), [Cars](#battery-wire-lights-and-horn) |
| **Lights** | Car lights (12 V), solar garden lights, flashlights | [Cars](#battery-wire-lights-and-horn), [Garden lights](#solar-garden-lights-and-spent-batteries) |
| **Hose and pipe** | Washer hoses, garden hose, gutters, PVC, car heater hose | [Gutters, PVC and hose](#gutters-pvc-pipe-and-garden-hose) |
| **Rope and straps** | Seat belts, inner tubes, trampoline mats and springs, ratchet straps | [Seat belts](#seats-belts-fuel-and-fluids), [Inner tubes](#tires-and-inner-tubes) |

## 🧰 Before you take anything apart
<!-- fold: Make it dead, let stored force out, photograph it, and sort what comes off -->

1. **Make it dead.** Unplug it, take out the batteries, drain fuel, oil and water into marked cans, and pull the
   spark plug wire off any engine *(rule of thumb)*.
2. **Discharge the capacitors** in microwaves, TVs, power supplies, inverters and motors: ground clip on first, then
   touch each terminal several times, hands off the metal
   ([NEETS 21, p. 33](lib:neets-module-21-test-methods-and-practices#page=33)).
3. **Let stored force out:** springs, struts, tires on rims, anything under pressure. Leave a garage door's big
   wound spring alone: it breaks bones *(rule of thumb)*.
4. **Photograph, tag and mark** every wire and part before you pull it
   ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#taking-it-apart-safely)).
5. **Safety glasses and gloves;** cut, grind and strip outdoors *(rule of thumb)*.
6. **Sort as you go** into labelled bins: motors, wire, fasteners, bearings, belts, springs, magnets, glass. Store
   motors "in a dry place and kept free from dirt"
   ([Illinois *Electric Motors for Farm Use*, p. 23](lib:electric-motors-for-farm-use-university-of-illinois-1962#page=23)).
7. **Test before you trust it** ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#testing-what-you-salvaged)).

![A Navy safety shorting probe: an insulated handle about 25¾ inches long with a hooked metal rod at one end, a short straight probe beside it, and a long wire from the handle ending in a clip that goes on a ground](img:SALVAGE-GUIDE/capacitor-shorting-probe.png)
*A shorting probe for step 2: clip the wire to a good ground first, then hold the handle and touch the rod's tip to each terminal several times, never touching the metal ([NEETS 21, p. 33](lib:neets-module-21-test-methods-and-practices#page=33)).*

## 🧺 Washing machines and dryers
<!-- fold: The drum makes a fire pit or a sieve; the motor runs a grinder; the dryer's fan blows a forge -->

**Inside, worth keeping** *(rule of thumb)*: the **drum**, usually stainless steel full of holes; the **motor**, an
**induction motor** of about ⅓–½ horsepower in older top-loaders and dryers, and in newer washers a brushed
**"universal" motor** or a flat **magnet motor** on the drum; the **drain pump, belts, pulleys, springs, hoses and
water valves**; a dryer's **blower wheel**.

**Make with it:**
- **Fire pit or brazier:** cut off the plastic hub and fins (don't burn them), stand the drum on bricks and lay a
  grate across it; the holes feed air *(rule of thumb)*. Outdoor fires belong in the wet season
  ([Wildfire](guide:WILDFIRE-GUIDE#burning-on-purpose-wet-season-only)). Oregon counts "a fire in a burn barrel" as open burning, and bans burning plastic, rubber, tires and "auto parts,
including frames" anywhere, any time ([DEQ, p. 1](lib:southern-oregon-outdoor-burning#page=1)). Here: no open
fires June–October, until real rain *(rule of thumb)*. As a burn barrel, for
  dry paper and clean wood only: [Sanitation](guide:SANITATION-GUIDE#burning-trash-and-brush-and-ash).

![A washing-machine drum standing on two brick piers, a fire inside showing through its holes, a grate laid across the open top, arrows showing air coming in through the holes and from underneath, and the drum's plastic hub crossed out](img:SALVAGE-GUIDE/washer-drum-fire-pit.svg)
*The drum on bricks with a grate across it; the plastic hub and fins come off first and are never burned (a diagram drawn for this guide).*

- **Sieve or composter:** on its side on a frame with a crank, the drum sifts compost and soil, washes potatoes, or
  tumbles compost under a lid *(rule of thumb)*.
- **Smoker firebox:** the drum holds the smoky fire, and a pipe takes the smoke to a fridge cabinet
  ([below](#fridges-and-freezers)).
- **Grinder, buffer or lathe drive** from an induction motor. A 4-pole motor turns about **1,725 rpm**
  ([Illinois, p. 10](lib:electric-motors-for-farm-use-university-of-illinois-1962#page=10)). Choose pulleys so that
  **motor pulley × motor rpm = machine pulley × machine rpm**
  ([p. 17](lib:electric-motors-for-farm-use-university-of-illinois-1962#page=17)). Swap the starting winding's two
  leads to reverse it. A **split-phase** motor starts only easy loads; a **capacitor-start** motor starts pumps and
  compressors ([p. 11](lib:electric-motors-for-farm-use-university-of-illinois-1962#page=11)). Never run a grinding
  wheel faster than the speed printed on it *(rule of thumb)*.
- **A slow generator** for a water wheel, from a flat magnet motor: test it first
  ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#testing-what-you-salvaged)) *(rule of thumb)*.
- **Forge blower** from a dryer's blower ([Blacksmithing](guide:BLACKSMITHING-GUIDE#a-simple-forge-and-anvil))
  *(rule of thumb)*. With no power, an old bicycle can turn the washer ([Bicycles](#bicycles)).

**Watch out:** a universal motor "runs as fast as the load permits"
([Navy *Construction Electrician*, p. 241](lib:us-navy-construction-electrician-basic-navedtra-14026#page=241)): never
run one with nothing on it. Discharge the motor's capacitor
([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#electric-motors-testing-and-repair)). The cabinet may be galvanized
under its paint, so never burn or weld it, and cap a gas dryer's gas line first *(rule of thumb)*.

## 🔥 Water heaters
<!-- fold: The tank becomes a solar heater, a cistern or a stove body; the elements soak up spare power -->

**Before you scrap a working one:** its tank holds **20 to 60 gallons** of drinking water
([FEMA H-20, p. 31](lib:protection-in-the-nuclear-age-fema-h-20-1985#page=31)). Shut off the power or gas, open a hot
tap, and drain it from the bottom valve *(rule of thumb)*.

**Inside, worth keeping** *(rule of thumb)*: a steel tank, **glass-lined** in most and **galvanized** in some old
ones; foam or fiberglass insulation; the relief and drain valves. Electric ones have two **heating elements**; gas
ones a burner and a flue pipe up the middle.

**Make with it:**
- **Solar water heater:** the cheapest tanks "are those from discarded electric, glass-lined water heaters. You
  should use glass-lined tanks instead of galvanized tanks, which may rust." Test it for leaks with a garden hose,
  strip it and paint it flat black
  ([DOE *Breadbox*, p. 19](lib:breadbox-solar-water-heaters-principles-and-construction-doe-region-iv#page=19);
  the build: [Storing Energy](guide:STORING-ENERGY-GUIDE#solar-water-heaters-you-can-build)).
- **A cistern:** stood upright and open to the air at the top, it stores 30 to 80 gallons. Rusty water means the
  lining has failed: keep that one for washing water *(rule of thumb)*.
- **Dump loads:** a wind or hydro controller sends spare power into a water-heater element in a tank of water
  ([Storing Energy](guide:STORING-ENERGY-GUIDE#hot-water-where-spare-electricity-should-go)). An element made for
  240 volts gives only a quarter of its heat on 120 volts *(arithmetic: heat goes with the voltage squared)*.
- **Stove or smoker body:** a drained, opened, glass-lined tank. The glass flakes off the first time it is heated,
  so wear safety glasses *(rule of thumb)*. Stovepipe and clearances:
  [Firewood](guide:FIREWOOD-GUIDE#burning-safely-stoves-chimneys-ashes).
- **The foam** insulates a cool box, a hay-box cooker or a cellar door; keep it away from stoves, as it burns fast
  with poisonous smoke *(rule of thumb)*.

**Watch out:** never make a boiler of one, and never heat a closed tank. Old water heaters are on the list of things
never to use as a boiler ([Heat into Power](guide:HEAT-INTO-POWER-GUIDE#what-never-to-use-as-a-boiler)); even
carefully built wood-fired showers "occasionally leaked or even exploded!"
([Aprovecho, p. 9](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=9)). Check the
lining: a galvanized tank is never heated.

## 🧊 Fridges and freezers
<!-- fold: The insulated box becomes a cool box, a buried cellar, a smoker or a seed starter -->

**Inside, worth keeping:** an insulated cabinet with a tight door seal, shelves and bins, a thermostat, light and
small fan, and at the back the **compressor** (the black dome) on its sealed pipes *(rule of thumb)*.

**Make with it:**
- **Cool box:** block ice, or jugs frozen on winter nights, in the bottom. A chest freezer holds the cold best,
  because cold air stays in when the lid opens *(rule of thumb)*. More: [Root Cellars](guide:ROOT-CELLAR-GUIDE#cooling-without-power).
- **A buried cellar box:** a chest freezer, lid up, sunk into a shaded bank with a small vent *(rule of thumb)*; see
  [Root Cellars](guide:ROOT-CELLAR-GUIDE#pits-clamps-buried-barrels-and-the-garden-itself).
- **Smoker:** "A simple indirect smoker can be constructed from an old refrigerator by removing the compressor,
  cutting a vent in the top of the cabinet and fitting an adjustable air vent in the bottom of one side." The fire
  sits in a separate brick or metal box, and "a pipe is connected from the smoke generator to the hole in the side"
  ([Practical Action *Cured Meat Products*, p. 7](lib:practical-action-cured-meat-products#page=7)). The plastic
  liner softens if the smoke comes in too hot: keep the fire well away, or line the box with sheet metal
  *(rule of thumb)*. Smoking safely: [Preserving Food](guide:PRESERVING-FOOD-GUIDE#fish-smoking-canning-and-salting).

![An old refrigerator standing upright, cut away to show strips of meat hanging from two racks, smoke leaving through a vent cut in the top; a pipe runs from a separate brick fire box with a small air door into a vent low in the fridge's side](img:SALVAGE-GUIDE/fridge-smoker.svg)
*The fire stays in its own box, and a pipe brings only its smoke into the fridge ([Practical Action, p. 7](lib:practical-action-cured-meat-products#page=7); a diagram drawn for this guide).*

- **Seed-starting box:** a jug of hot water changed morning and night, or a small bulb where there is power, keeps
  seeds warm enough to sprout *(rule of thumb)*.
- **Hay-box cooker:** a pot at a full boil, on a board, packed round with blankets in a chest freezer
  ([Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#hay-box-cooking-saves-fuel)). Or a mouse-proof bin for grain and seed.
- **The compressor** makes a small air or vacuum pump, but only from a fridge whose gas has already leaked out:
  cut it free outdoors, in goggles *(rule of thumb)*.
- **12-volt camping coolers and wine fridges** have no gas: they hold a Peltier module, which makes a little power
  on a stove top ([Heat into Power](guide:HEAT-INTO-POWER-GUIDE#choosing-modules-teg-or-salvaged-peltier)).

**Watch out:** take the door off, or break the latch, of any fridge left where children play; a child shut inside
suffocates *(rule of thumb)*. **Gas fridges** from cabins and RVs hold ammonia under high pressure
([NBS report, p. 9](lib:performance-evaluation-of-a-propane-fired-absorption-refrigerator#page=9)): never cut or heat
the pipes, and keep a working one working
([Heat into Power](guide:HEAT-INTO-POWER-GUIDE#keeping-an-absorption-refrigerator-running)).

## 📡 Microwave ovens
<!-- fold: Keep the fan, turntable motor, glass plate, wire and case; leave the high-voltage parts -->

**First:** unplug it, wait, and discharge the capacitor before a hand goes inside
([Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#electronics-repair-and-salvage);
[NEETS 21, p. 33](lib:neets-module-21-test-methods-and-practices#page=33)).

| Part | Keep it? | Use |
|---|---|---|
| Cooling fan | Yes | A small 120-volt shaded-pole motor, the kind "used with small fans, timers" ([*Construction Electrician*, p. 242](lib:us-navy-construction-electrician-basic-navedtra-14026#page=242)) |
| Turntable motor | Yes | A slow 120-volt gear motor: a turning spit *(rule of thumb)* |
| Glass plate, roller ring, light, switches, fuses, wire, screws | Yes | Spares, and an oven-proof glass dish |
| The whole steel case, unplugged | Yes | A ready-made shield for small electronics; test it first ([EMP guide](guide:EMP-GUIDE#faraday-containers-building-one-that-works)) |
| Magnetron | Only its two ring magnets | Strong magnets. Don't break its ceramic parts: some hold beryllium oxide, toxic as dust *(rule of thumb)* |
| High-voltage capacitor and diode | **No** | Discharged, they go with the toxic waste *(rule of thumb)* |
| Transformer | **Never powered** | Once it is dead and discharged, its copper may be unwound for wire; never rewire it or plug it in *(rule of thumb)* |

## 🚗 Cars and trucks: a whole parts store
<!-- fold: Alternator, battery, wire, lights, horn, mirrors, glass, springs, seats, belts, fuel and fluids -->

One dead car holds a generator, a battery, a wire store, spring steel, glass, wheels, fuel and cloth. Drain the fuel
first ([Fuel guide](guide:FUEL-GUIDE#drums-and-vehicles)), and leave the airbags and seat-belt tensioners in place:
they hold explosive charges *(rule of thumb)*.

### The alternator, and the wind question

- **What it is:** a 12-volt generator with its own rectifier and regulator. It needs **fast** turning and a battery
  connected to power its field ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#motors-as-generators)).
- **The catch:** the field draws "about three amperes"
  ([*Alternator and Regulator Servicing*, p. 11](lib:alternator-and-regulator-servicing#page=11)), about **36 watts**
  from the battery before it makes anything *(arithmetic)*.
- **Wind:** power goes with the **cube** of the wind speed
  ([DOE *Small Wind*, p. 11](lib:doe-small-wind-electric-systems-consumers-guide#page=11)): half the wind, one-eighth
  the power. By that page's formula a homemade 6-ft rotor in a 10-mph wind makes about **40 watts**, little more than
  the field uses, and turns too slowly for an alternator without about 5-to-1 gearing *(arithmetic)*. Wind pays only
  where it averages **9 mph** or more ([p. 20](lib:doe-small-wind-electric-systems-consumers-guide#page=20)), with the
  rotor **30 ft above anything within 300 ft**
  ([p. 7](lib:doe-small-wind-electric-systems-consumers-guide#page=7)). Here, small wind is usually poor: only exposed ridgetops are worth testing, and solar and creek power come first
*(rule of thumb)*. The full comparison:
  [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#creek-hydro-and-why-not-wind).
- **Where it works:** belted up to speed on a fast water wheel, or kept as a spare for a running vehicle. For slow
  wind or water, use a magnet generator; a car's wheel hub and bearing make a good mount for one
  ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#matching-it-to-a-water-wheel-or-wind-rotor)).

### Battery, wire, lights and horn

- **Battery:** a starting battery, ruined after about 20 deep discharges
  ([Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#electronics-repair-and-salvage)). Care and safety:
  [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#keeping-lead-acid-alive).
- **Wire:** the wiring harness is fine stranded copper; keep the fuses, relays, switches and plugs. Thin wire on a
  heavy load gets hot ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#wiring-fuses-and-grounding)).
- **Lights:** headlights, tail lights and dome lights run on 12 volts; LED ones use least *(rule of thumb)*.
- **Horn:** a loud alarm for the neighborhood ([Signals](guide:SIGNALS-MORSE-GUIDE#whistles-bells-and-alarm-codes)).
- **12-volt motors** *(rule of thumb)*: the **wiper motor** (slow and strong: a winch, a spit), the **radiator
  fan**, the **heater blower**, and the **windshield-washer pump**, a small water pump.

### Mirrors and glass

- **Signal mirror:** a flat mirror, not the curved passenger-side one *(rule of thumb)*. A mirror flash "has been
  visible up to 100 miles under ideal conditions"
  ([AFH 10-644, p. 509](lib:afh-10-644-survival-evasion-resistance-escape-operations-signaling-chapter-21-us-air-force-2017#page=509));
  aiming it: [Signals](guide:SIGNALS-MORSE-GUIDE#signal-mirrors).
- **Glass** *(rule of thumb)*: side and back windows are **tempered**: they can't be cut and burst into small cubes
  when struck, so use them whole, as cold-frame lids. A windshield is two glued layers: hard to break or cut.

### Leaf and coil springs

- **The best tool steel in the car:** chisels, punches, knives, axes and pry bars; axles and torsion bars too
  ([Blacksmithing](guide:BLACKSMITHING-GUIDE#which-scrap-steel-to-use)).
- **Watch out** *(rule of thumb)*: a coil spring on a strut is held squeezed. Take the strut out whole and never undo
  its top nut until the spring is clamped. Gas struts and shock absorbers hold pressure: never heat or cut them.
- **Brake drums** make a forge's fire pot ([Blacksmithing](guide:BLACKSMITHING-GUIDE#a-simple-forge-and-anvil)).
  Old brake shoes and clutch plates may hold asbestos
  ([NEETS 4, p. 110](lib:neets-module-04-conductors-wiring-techniques-and-schematics#page=110)): never blow or grind
  the dust.

### Seats, belts, fuel and fluids

- **Seat belts:** strong webbing for straps, slings, pack frames and hinges. Cut the belt; leave the reel
  *(rule of thumb)*.
- **Seats:** foam for cushions and insulation, cloth, steel frames. The foam burns fast with poisonous smoke
  *(rule of thumb)*.
- **Tires and wheels:** [Tires and inner tubes](#tires-and-inner-tubes); wheels and axles for carts:
  [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE#wheelbarrows-handcarts-sledges-and-travois).
- **Fuel:** drain it into cans and test it before you trust it ([Fuel guide](guide:FUEL-GUIDE#drums-and-vehicles)).
- **Fluids** *(rule of thumb)*: keep motor oil for chains and rust-proofing tools. **Antifreeze is poison** with a
  sweet taste that draws children, dogs and stock: lock it up. Leave the air-conditioning gas sealed. Waste fluids:
  [Sanitation](guide:SANITATION-GUIDE#hazardous-waste-batteries-oil-fuel-chemicals-medicines).

## 🚲 Bicycles
<!-- fold: Ride a whole one; a dead one gives wheels, pulleys, pedal power, tubes, chain and wire -->

- **A rideable bike beats any part of it.** Repair first:
  [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE#wheels-hub-bearings-and-chains).
- **Wheels** carry carts and trailers
  ([Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE#bicycle-trailers-welded-steel-or-no-weld-pallets)). With the tire
  off, the rim is a pulley: wind twine on it to hold a belt
  ([*Handy Farm Devices*, p. 63](lib:handy-farm-devices-and-how-to-make-them-1912#page=63)).
- **Pedal power:** a 1912 farm book props an old bike up and belts it to a washing machine or an emery wheel (same
  page). A fit
  adult keeps up only about 75 watts for an hour *(rule of thumb)*: pedal to grind, pump, sharpen or wash, not to
  make electricity. To charge by pedal, a magnet motor beats a car alternator
  ([above](#the-alternator-and-the-wind-question)).

![An old bicycle propped in a wooden frame with its back wheel off the ground; a long belt runs from the back rim to the pulley on top of a washing machine standing on legs](img:SALVAGE-GUIDE/bicycle-turning-a-washer.png)
*The 1912 pedal-power washer: the back wheel's rim, its tire off, belted to the machine ([*Handy Farm Devices*, p. 63](lib:handy-farm-devices-and-how-to-make-them-1912#page=63)).*

- **Also** *(rule of thumb)*: spokes are stiff steel wire for pins and hooks; brake cables work latches; the chain
  and sprockets drive things; hub bearings spin small wheels. Check the frame with a magnet: aluminum can't be forged.

## 🌱 Lawn mowers and small engines
<!-- fold: The engine runs a pump or a mill; the blade is good steel; a reel mower cuts feed -->

- **The engine,** if it runs, turns a water pump, small generator, grain mill or saw by belt *(rule of thumb)*.
  Getting it to start: [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#small-gas-engines-why-it-won-t-start); running
  an engine on wood gas, and pulling a magnet flywheel safely:
  [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#reusing-a-generator-for-water-or-wind-power).
- **A reel mower:** "an old lawn mower can be arranged to make a fairly satisfactory straw or feed cutter", fed from a
  hopper and turned by a crank and belt
  ([*Handy Farm Devices*, pp. 120–121](lib:handy-farm-devices-and-how-to-make-them-1912#page=120)).
- **The blade** is hardened steel for a machete, hoe or scraper: file-test it
  ([Blacksmithing](guide:BLACKSMITHING-GUIDE#which-scrap-steel-to-use)) *(rule of thumb)*.
- **Also** *(rule of thumb)*: wheels and axles for carts, handle tubes, the pull cord and its spring, throttle
  cables, a riding mower's battery.
- **Watch out:** pull the spark plug wire before you touch the blade. Drain the tank; an empty fuel tank still holds
  vapor ([FM 10-67-1, p. 14](lib:fm-10-67-1-petroleum-supply-operations-us-army-1998#page=14)).

## 🏃 Treadmills
<!-- fold: The magnet motor makes power when spun; the flywheel, rollers and frame are useful too -->

- **The motor** is a permanent-magnet DC motor. Spun, it makes DC directly; to charge a 12-volt battery it must make
  **14–15 volts** at the speed you can turn it, with a blocking diode so the battery can't run it as a motor
  ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#motors-as-generators)). These are fast motors: gear them up from
  a water wheel or pedals *(rule of thumb)*.
- **Also** *(rule of thumb)*: the heavy flywheel, the rollers and their bearings, the steel frame, the belt (tough
  cloth for hinges and gaskets), and the **incline motor**, a slow, strong gear motor that pushes or lifts. An
  exercise bike's flywheel and stand make a ready pedal drive.
- **Watch out:** the control board holds charged capacitors; discharge it and keep it for parts. Never let a magnet
  generator spin fast with nothing connected: its voltage climbs with speed
  ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#matching-it-to-a-water-wheel-or-wind-rotor)).

## 🌀 Ceiling fans, drills and power tools
<!-- fold: Fan and drill motors, gearboxes, tool batteries, blades and bits -->

- **Ceiling fans** *(rule of thumb)*: an ordinary one has a slow AC induction motor that makes no power when spun.
  Newer "DC" fans have magnet motors that do: test one like any salvaged generator
  ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#testing-what-you-salvaged)).
- **Corded drills, saws and grinders** have brushed universal motors, used in "vacuum cleaners, sewing machines, food
  mixers, and power hand tools" ([*Construction Electrician*, p. 241](lib:us-navy-construction-electrician-basic-navedtra-14026#page=241)).
  Worn brushes are the usual fault ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#electric-motors-testing-and-repair)).
- **Cordless tools** have magnet motors with gearboxes: a cordless drill's motor and gearbox, turned by a hand crank,
  charges small batteries slowly *(rule of thumb)*. Their packs are lithium
  ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#lithium-lifepo4-and-salvaged-packs)); keep each charger with its packs.
- **Blades and bits** are high-carbon steel for knives and scrapers
  ([Blacksmithing](guide:BLACKSMITHING-GUIDE#which-scrap-steel-to-use)).
- **Watch out:** "Never grind nonferrous metals on a wheel intended for ferrous metals": the clogged wheel can become
  "unbalanced and fly apart" ([Navy *Steelworker*, p. 22](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=22)).

## 💻 Computers, UPS boxes, phones and tablets
<!-- fold: An old phone becomes a library reader; a computer gives 12-volt power and fans; a UPS a battery -->

- **Old phones, tablets and laptops:** a phone that will never call again still reads this library, shows the maps
  and takes pictures. Set them up now and store them about half charged
  ([Start on any device](guide:START-ON-ANY-DEVICE#put-old-devices-to-work-set-them-up-now);
  [Use on a phone](guide:USE-ON-PHONE)). A swollen battery goes out of the house.
- **Desktop computers:** the power supply gives 12 and 5 volts
  ([Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#electronics-repair-and-salvage)); keep the 12-volt fans, heat sinks, wire
  and plugs. A hard drive holds two very strong magnets *(rule of thumb)*.
- **UPS (battery-backup) boxes:** a 12-volt sealed lead-acid battery (often worn out: test it) and a small inverter
  built to run for minutes, not hours. On a car battery, give it light loads only and let it cool *(rule of thumb)*.
  Real inverters: [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#charge-controllers-and-inverters).
- **Watch out:** power supplies hold charged capacitors; tube monitors are on the list at the top.

## 🔆 Solar garden lights and spent batteries
<!-- fold: Garden lights are tiny solar chargers and night lights; what to do with each kind of dead battery -->

**Solar garden lights** hold a small solar panel, a rechargeable AA or AAA cell, an LED and a light sensor. Leave
them in the sun all day and bring them in at night for the outhouse, the hall or a child's room; swap in fresh
rechargeable cells as the old ones fade *(rule of thumb)*.

| Battery | Found in | What to do |
|---|---|---|
| Lead-acid | Cars, UPS boxes, golf carts, riding mowers | Test and reuse; keep upright, never break open ([Sanitation](guide:SANITATION-GUIDE#hazardous-waste-batteries-oil-fuel-chemicals-medicines); [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#battery-safety)) |
| Lithium-ion | Phones, laptops, tools, e-bikes | Reuse whole, with its management board; swollen ones out ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#lithium-lifepo4-and-salvaged-packs)) |
| Nickel (NiMH, NiCd) | Garden lights, cordless phones, old tools | Recharge; store NiCd apart ([Sanitation](guide:SANITATION-GUIDE#hazardous-waste-batteries-oil-fuel-chemicals-medicines)) |
| Alkaline (ordinary AA, C, D) | Flashlights, radios, remotes | Run them down in a radio, then finish them in a flashlight ([Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#electronics-repair-and-salvage)); never recharge them *(rule of thumb)* |
| Button cells | Watches, remotes, scales | Keep from small children: a swallowed one burns the gut *(rule of thumb)* |

## 🛢️ 55-gallon drums and IBC totes
<!-- fold: What the drum held decides what it may become: food and water, a stove, or nothing -->

**First, find out what it held** from the label, the stencil or the smell:

| It held | Good for |
|---|---|
| **Food or drink** (food-grade) | Water, grain and food. Food goes only in food-grade containers, never "fiber barrels that have been used for non-food purposes" ([USU, p. 12](lib:food-storage-in-the-home-grain-insect-control-usu#page=12)) |
| **Oil or fuel** | Once cleaned: a stove, burn barrel, smoker, compost bin or trough. Never food or drinking water *(rule of thumb)* |
| **Pesticide, or you don't know** | Nothing: "Old pesticide drums used as floats corrode and thus cause serious fish kills" ([Peace Corps M-2, p. 421](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=421)) |

- **Cutting a drum that held fuel:** open the bungs slowly ([Fuel guide](guide:FUEL-GUIDE#drums-and-vehicles)), clean
  it with steam or a strong caustic wash, then fill it with water to just below the cut and leave a bung open as a
  vent while you cut ([Navy *Steelworker*, p. 96](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=96)). A cold
  chisel or hacksaw is safer than a torch or grinder *(rule of thumb)*.

![A steel drum cut away to show it filled with water to just below a dashed cut line near the top, one bung open with vapor rising from it, and a cold chisel set on the cut line](img:SALVAGE-GUIDE/cutting-a-fuel-drum.svg)
*Filled with water to just below the cut, with a bung open as a vent ([Navy *Steelworker*, p. 96](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=96)), and cut with a cold chisel or hacksaw (a diagram drawn for this guide).*

- **Barrel stove:** Aprovecho made heat exchangers "cheaply out of 33 and 55-gallon drums"
  ([Aprovecho, p. 10](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=10)), and
  "Firebrick protects the thin walls of the combustion chamber, which then can last for ten years!"
  ([p. 11](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=11)). Burn the paint off
  once, outdoors and upwind, before it goes indoors *(rule of thumb)*.
- **Grain:** a clean, tight drum keeps out insects and rodents if the grain goes in dry (12% moisture or less) and
  the drum stays out of the sun ([Peace Corps M-2, pp. 291–292](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=291)).
  Use only a drum that held food.
- **Rain barrels:** the tank "should not have previously been used to store toxic materials", should be opaque, and
  covered with screened vents ([OSU EM 9101, p. 7](lib:osu-harvesting-rainwater-for-use-in-the-garden-em-9101#page=7));
  a 50- to 75-gallon drum with a spigot waters garden beds
  ([Texas *Rainwater*, p. 20](lib:texas-manual-on-rainwater-harvesting-3rd-ed-twdb-2005#page=20)). The whole system:
  [Water Wells](guide:WATER-WELLS-GUIDE#cisterns-and-rainwater).
- **IBC totes** *(rule of thumb)*: a 275- or 330-gallon plastic tank in a steel cage, with the same label rule. The
  white plastic lets in light (algae) and goes brittle in sun: shade or paint it. A spare cage makes pen panels.

## 🪵 Pallets
<!-- fold: Free lumber for trailers, compost bins, racks and store floors; read the stamp first -->

- **Read the stamp** *(rule of thumb)*: **HT** means heat-treated, fine to use. **MB** means fumigated with methyl
  bromide, one of the dangerous gases fuel handlers are warned about
  ([FM 10-67-1, p. 38](lib:fm-10-67-1-petroleum-supply-operations-us-army-1998#page=38)): not for food, bedding or
  firewood. Stained or painted pallets: outdoor jobs only.
- **Make with them:** a no-weld bike trailer
  ([Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE#bicycle-trailers-welded-steel-or-no-weld-pallets)), compost bins
  ([Sanitation](guide:SANITATION-GUIDE#composting-food-yard-waste-and-manure)), firewood racks
  ([Firewood](guide:FIREWOOD-GUIDE#seasoning-drying-wood-in-a-wet-climate)), fences and coops. In a food store, food
  goes "on pallets or on shelves off the floor at a minimum height of 45 cm", with no pallet against a wall
  ([WHO *Communicable Disease Control*, p. 68](lib:communicable-disease-control-in-emergencies-a-field-manual-who-2005#page=68)).
- **Taking one apart:** a pry bar and hammer, or saw the boards off beside the blocks; pull every nail
  *(rule of thumb)*.

## 🪟 Old windows and doors
<!-- fold: Windows make cold frames and solar heaters; doors make benches and tables -->

- **Cold frame:** a bottomless box with an old window on top. "The back or north side … should be 12 or 15 inches
  high, while the front should slope down to 8 inches"
  ([*Handy Farm Devices*, p. 148](lib:handy-farm-devices-and-how-to-make-them-1912#page=148)). Face it "south or
  southeast", sheltered from the north wind, with "great attention … to water and ventilation"
  ([p. 149](lib:handy-farm-devices-and-how-to-make-them-1912#page=149)). Prop the window open on warm days
  *(rule of thumb)*.

![A cold frame seen from the side: a bottomless wooden box on the soil with seedlings inside, its back board on the north side 12 to 15 inches high and its front board on the south side 8 inches high, an old window lying on top hinged at the back and propped open with a stick, the sun to the south](img:SALVAGE-GUIDE/cold-frame-from-a-window.svg)
*The back, 12–15 inches high, on the north; the front, 8 inches, facing south ([*Handy Farm Devices*, pp. 148–149](lib:handy-farm-devices-and-how-to-make-them-1912#page=148); a diagram drawn for this guide).*

- **Glazing** for a solar water heater ([Storing Energy](guide:STORING-ENERGY-GUIDE#solar-water-heaters-you-can-build))
  or a solar food dryer ([Root Cellars](guide:ROOT-CELLAR-GUIDE#drying-food)).
- **Doors:** a solid door is a workbench, table top or shelf; a hollow one is light and weak *(rule of thumb)*.
- **Watch out:** "When working on old painted surfaces, assume that one or more of the paint coats contain lead":
  never sand, burn or heat them ([*Wood Handbook*, p. 392](lib:wood-handbook-wood-as-an-engineering-material-usda-fpl-gtr-190-2010#page=392)).
  Tempered glass can't be cut, and a sealed double pane can't be split: use them whole *(rule of thumb)*.
  Reglazing: [Shelter](guide:SHELTER-BUILDING-GUIDE#reglazing-and-saving-windows).

## 🛏️ Mattresses, box springs and trampolines
<!-- fold: Spring wire, foam and cloth; a trampoline frame makes hoops for a greenhouse or a run -->

*(All rule of thumb.)*
- **Springs:** hard steel wire for trellis, fence ties and hooks; cut it with bolt cutters.
- **Foam:** cushions, kneeling pads, insulation. It burns fast with poisonous smoke: keep it away from stoves.
- **Cloth and frames:** the cover makes sacks; a box spring's frame is light lumber.
- **Trampoline:** the curved frame tubes make hoops for a greenhouse, a chicken run or a shade frame. They are
  galvanized: cut and bolt them, never weld or heat them. The **springs** pull gates and doors shut; the **mat** is
  sun-proof woven cloth for shade or a ground sheet. Wear glasses taking the springs off: they snap back.
- **Watch out:** a mattress stored in a shed is often a mouse nest; wet it down before you touch it
  ([Sanitation](guide:SANITATION-GUIDE#mice-hantavirus-fleas-and-plague)).

## 📡 Satellite dishes
<!-- fold: Lined with foil, a dish heats a pot of water in the sun; mind your eyes and dry grass -->

- **Heating water:** a solar cooker can be "a reflective 'satellite dish', on which the water pot sits", with the
  water in a blackened pot ([CAWST, p. 75](lib:household-water-treatment-and-safe-storage-fact-sheets-detailed-cawst-2011#page=75)).
  Pasteurizing water: [Water Purification](guide:WATER-PURIFICATION-GUIDE#step-3-kill-the-germs).
- **Making it shine** *(rule of thumb)*: line it with mirror film or kitchen foil, shiny side out. Most TV dishes are
  "offset": the hot spot is where the arm held the receiver, not in front of the middle.
- **Its limits:** dish cookers heat one pot at a time, "need constant refocusing towards the sun" and are
  "susceptible to being blown over by strong winds"
  ([Ciochetti & Metcalf, p. 1](lib:pasteurization-of-naturally-contaminated-water-with-solar-energy-ciochetti-metcalf-1984#page=1)).
- **Watch out** *(rule of thumb)*: never look into the bright spot; it burns eyes and lights dry grass, so in fire
  season use it only on bare ground. The arm and pole are galvanized: cut them cold.

## 🚿 Gutters, PVC pipe and garden hose
<!-- fold: Gutters catch rain, PVC carries water and makes frames, hose siphons and drips -->

*(Rule of thumb, unless a link says otherwise.)*
- **Gutters** fill rain barrels ([Water Wells](guide:WATER-WELLS-GUIDE#cisterns-and-rainwater)) and make shallow
  planters, troughs and small water channels.
- **PVC pipe** carries water and makes hoop-house frames, fences and racks. Sun makes it brittle: paint it or shade
  it. Never burn it, and never use it for compressed air: it shatters.
- **Garden hose** siphons water and makes drip lines; ordinary hose is not made for drinking water. A split length
  guards a saw blade or pads a bucket handle.

## ⛺ Tarps and plastic sheeting
<!-- fold: Roofs, rain catchers, ground sheets and greenhouse film, fixed so they don't tear -->

- **Uses:** emergency roofs and shelters, rain catchers, ground sheets, greenhouse and cold-frame covers
  *(rule of thumb)*.
- **Fixing it so it doesn't tear:** nail through wooden battens or bottle caps, never bare nails, and fold the sheet
  over on itself wherever you fasten it ([Shelter](guide:SHELTER-BUILDING-GUIDE#emergency-tarp-and-plastic-shelters)).
- **Watch out:** sunlight rots most plastic in a season or two *(rule of thumb)*; never burn it.

## 🛞 Tires and inner tubes
<!-- fold: Tires hold firewood for splitting and pad loads; tubes give straps and gaskets; never burn either -->

- **Splitting ring:** "Some folks use old tires to keep from having to stoop to pick up split firewood"; the tire is
  fixed on top of the splitting block
  ([UW Extension *Harvesting Firewood*, p. 16](lib:uw-extension-harvesting-firewood-from-your-woods-gwq060-2012#page=16);
  splitting safely: [Firewood](guide:FIREWOOD-GUIDE#splitting)).
- **Padding:** "old rubber tires are excellent materials to use as padding" where a sling crosses a sharp edge
  ([*Construction Electrician*, p. 21](lib:us-navy-construction-electrician-basic-navedtra-14026#page=21)).
- **Inner tubes:** cut in rings they are strong rubber bands; in strips, straps; in pieces, gaskets. "Pieces of
  rubber cut from old tires, and inner tubes" seal airtight grain stores
  ([Peace Corps M-2, p. 279](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=279)), and one hitches
  a no-weld trailer ([Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE#bicycle-trailers-welded-steel-or-no-weld-pallets)).
- **Also** *(rule of thumb)*: tread for sandal soles and door mats; whole tires as steps and bumpers.
- **Watch out:** a tire left lying fills with water and breeds mosquitoes: "Remove old tires or any items that
  collect water" ([*Where There Is No Doctor*, ch. 14, p. 9](lib:where-there-is-no-doctor-14-serious-illnesses-that-need-special-medical-attention#page=9)).
  Let all the air out before cutting one, and leave split-rim truck wheels alone: the ring can fly off
  *(rule of thumb)*.

## 🧲 The scrap pile: sorting metals
<!-- fold: A magnet, the sparks and the weight sort scrap; what each metal is good for -->

**Three quick tests:**
1. **Magnet:** iron and steel "normally are magnetic, and nonferrous metals are nonmagnetic", but "some stainless
   steels are nonmagnetic" ([Navy *Steelworker*, p. 25](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=25)).
2. **Sparks** on a grinder: low-carbon steel throws long, plain streams; high-carbon steel, bushy streams full of
   bursts; cast iron, short dull-red ones ([Blacksmithing](guide:BLACKSMITHING-GUIDE#which-scrap-steel-to-use)).
3. **Weight and look:** aluminum is light; lead "weighs about 710 pounds per cubic foot" and is gray, but white
   where scratched ([p. 19](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=19)). Cast iron "usually shows
   evidence of the sand mold" ([p. 21](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=21)).

| Metal | Where it turns up | Good for |
|---|---|---|
| Mild steel | Car bodies, drums, pipe, bolts, bed frames | Brackets, hinges, hooks, stoves; forge-welds easily ([Blacksmithing](guide:BLACKSMITHING-GUIDE#which-scrap-steel-to-use)) |
| Spring and tool steel | Leaf and coil springs, files, saw and mower blades | Knives, chisels, axes, punches (same) |
| Cast iron | Engine blocks, old stoves, pans, pulleys | Anvils, weights, cookware; brittle and hard to weld *(rule of thumb)* |
| Stainless steel | Washer drums, sinks, dishwasher tubs | Fire pits, food tubs, anything wet *(rule of thumb)* |
| Aluminum | Engine parts, ladders, window frames, cans | Light frames and sheet; never a firebox, as it melts *(rule of thumb)* |
| Copper and brass | Wire, pipe, radiators, valves | Wiring, tubing, bushings; brass softens if heated to 550–600 °F and left to cool ([*Steelworker*, p. 19](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=19)) |
| Lead | Wheel weights, old pipe, battery plates | Weights and sinkers only: "the dust, fumes, or vapors from it are highly poisonous" (same page) |
| Galvanized steel | Roofing, fence posts, garbage cans, trampoline frames | Rust-proof sheet and pipe, used cold; never heated (the list at the top) |

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| A boy "used a piece of old iron pipe for the boiler" of his steam engine ([Collins, p. 11](lib:the-boys-book-of-engine-building-steam-hot-air-and-gas-engines-collins-1918#page=11)) | Never make a boiler from pipe, a tank or a water heater ([Heat into Power](guide:HEAT-INTO-POWER-GUIDE#what-never-to-use-as-a-boiler)) |
| An ice maker "built from 5 and 3 gallon propane cylinders" ([Aprovecho, p. 37](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=37)) | Its builders "became worried about the potential for explosion" and handed the project on (same page). Never re-pressurize a salvaged cylinder |
| Dissolve old rubber by heating it "under pressure, for several hours, with a strong solution of caustic soda" ([Henley's, p. 624](lib:henleys-twentieth-century-formulas-recipes-and-processes-1916#page=624)) | Hot lye under pressure blinds and bursts pots. Use rubber as it is: cut tubes into straps and gaskets *(rule of thumb)* |
| Store grain in "220-litre oil drums" ([Peace Corps M-2, p. 291](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=291)) | Only a drum that held food: food goes only in food-grade containers ([USU, p. 12](lib:food-storage-in-the-home-grain-insect-control-usu#page=12)) |
| Dip cold-frame posts in kerosene overnight: "This will preserve them indefinitely" ([*Handy Farm Devices*, p. 148](lib:handy-farm-devices-and-how-to-make-them-1912#page=148)) | Kerosene evaporates and keeps little rot away. Use rot-resistant heartwood, or set posts on stones *(rule of thumb)*; see [Shelter](guide:SHELTER-BUILDING-GUIDE#rot-termites-carpenter-ants-and-woods-that-last) |
| "Line a wooden packing case with galvanized iron" for an ice chest ([VITA, p. 273](lib:village-technology-handbook-vita-usaid#page=273)) | Fine for ice, but keep acid foods and drinks off zinc: "Do not eat foods or drink beverages that have been prepared in galvanized containers" ([FM 21-10, p. 37](lib:us-army-fm-21-10-field-hygiene-and-sanitation-2000#page=37)). A dead chest freezer is already lined and insulated |

## 🖼️ Pictures & diagrams

🖼️ = drawings in the books on this drive; the other links are photos in the offline Wikipedia.

- A 33-gallon drum inside a 55 as a stove's heat exchanger — [🖼️ Aprovecho, p. 11](lib:aprovecho-capturing-heat-three-designing-home-made-wood-heating-stoves#page=11)
- A meat smoker — [🖼️ Practical Action, p. 7](lib:practical-action-cured-meat-products#page=7); [Smokehouse](wiki:Smokehouse)
- A lawn mower as a feed cutter — [🖼️ *Handy Farm Devices*, p. 120](lib:handy-farm-devices-and-how-to-make-them-1912#page=120)
- Motors: a split-phase motor's leads and a capacitor-start motor — [🖼️ Illinois, p. 11](lib:electric-motors-for-farm-use-university-of-illinois-1962#page=11); a universal motor's wiring, [🖼️ *Construction Electrician*, p. 241](lib:us-navy-construction-electrician-basic-navedtra-14026#page=241); [Universal motor](wiki:Universal_motor)
- A car generator made into a wind charger, 1939 — [🖼️ North Dakota, p. 8](lib:homemade-six-volt-wind-electric#page=8); [Alternator (automotive)](wiki:Alternator_(automotive))
- A picture tube cut open — [🖼️ NEETS 6, p. 114](lib:neets-module-06-electronic-emission-tubes-and-power-supplies#page=114)
- Food-grade barrels linked for rainwater — [🖼️ OSU EM 9101, p. 7](lib:osu-harvesting-rainwater-for-use-in-the-garden-em-9101#page=7); [Intermediate bulk container](wiki:Intermediate_bulk_container)
- Spark patterns of common metals — [🖼️ Navy *Steelworker*, p. 23](lib:us-navy-navedtra-14250-steelworker-vol-1-1996#page=23); [Spark testing](wiki:Spark_testing)
- Photos: [Washing machine](wiki:Washing_machine), [Water heating](wiki:Water_heating), [Pallet](wiki:Pallet), [Cold frame](wiki:Cold_frame), [Solar cooker](wiki:Solar_cooker), [Leaf spring](wiki:Leaf_spring), [Galvanization](wiki:Galvanization), [Metal fume fever](wiki:Metal_fume_fever), [Smoke detector](wiki:Smoke_detector), [Cathode-ray tube](wiki:Cathode_ray_tube)

## 🔗 Related guides

- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — testing and repairing salvaged motors, motors as generators, reusing a generator for water or wind
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) — salvaged solar panels and battery packs, and why creek power beats wind
- [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — electronics repair and salvage, containers and storage
- [Blacksmithing](guide:BLACKSMITHING-GUIDE) — which scrap steel to use, and a forge from a brake drum
- [Heat into Work and Power](guide:HEAT-INTO-POWER-GUIDE) — salvaged Peltier modules, and what never to use as a boiler
- [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE) — wheels, trailers and carts
- [Sanitation](guide:SANITATION-GUIDE) — burning trash, and hazardous waste
- [Wildfire](guide:WILDFIRE-GUIDE) — open fires only in the wet season
- [Root Cellars](guide:ROOT-CELLAR-GUIDE) and [Preserving Food](guide:PRESERVING-FOOD-GUIDE) — cool boxes and smokers
- [Storing Energy](guide:STORING-ENERGY-GUIDE) — solar water heaters and hot-water tanks
- [Fuel](guide:FUEL-GUIDE) — drums, vehicles, propane
- [EMP](guide:EMP-GUIDE) — a dead microwave as a shield for spare electronics
- [Vehicles, Tractors & Heavy Equipment](guide:VEHICLES-EQUIPMENT-GUIDE) — what is worth keeping on a dead car, truck or tractor
