# 🧼 Sanitation, Hygiene & Stopping Disease

When sewers, pumps and power fail, cholera, dysentery, typhoid and hepatitis follow, and they all travel
from human waste to someone's mouth. This guide covers toilets for every season in our clay soils, septic
systems with no power, greywater, handwashing, keeping clean with little water, lice and scabies,
stopping an outbreak, flies and mice, garbage with no pickup (sorting, pits, compost, bears, burning,
hazardous waste), sickroom waste, dead animals, and caring for the dead. The books are in
`Sanitation-Hygiene\` (`Latrines-Toilets`, `Septic-Greywater`, `Hygiene-Washing`, `Disease-Outbreaks`,
`Pests-Vectors`, `Waste-Burial`, which holds Oregon's burning and livestock-mortality guides) and
`Homestead-Skills\Sanitation-Water`; the compost bulletins are in `Gardening-Food`, the bear and vet books
under `Animals\`. The twin-bucket toilet, soap and cleaners are in the
[Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE); nursing the sick is in the
[Field Care guide](guide:FIELD-CARE-GUIDE).

> ### ⚠️ Rules that prevent the worst outcomes
> - **Keep every latrine, garbage pit and grave at least 100 ft (30 m) from wells, springs and creeks,
>   and downhill of them**, with the pit bottom 5 ft (1.5 m) above groundwater
>   ([Sphere, p. 140](lib:sphere-handbook-2018#page=140)). Some books say 65 ft (20 m). Use 100.
> - **Wash hands with soap or ash** after the toilet and before food. It cuts diarrhea by **42–47%**
>   ([Tippy-Tap, p. 1](lib:tippy-tap#page=1)).
> - **Diarrhea kills by drying people out.** Start the rehydration drink at the first watery stool
>   ([WTND ch. 13, p. 2](lib:where-there-is-no-doctor-13-some#page=2)).
> - **Never climb down into a septic tank, pit or vault.** The gases can kill in minutes *(rule of thumb)*.
> - **Never mix bleach with urine, ammonia or vinegar.** It makes poison gas
>   ([Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)).
> - **Never sweep or vacuum mouse droppings** (hantavirus).
> - **Never burn plastic, rubber, tires, oil, wet garbage or dead animals**: Oregon bans it anywhere, any
>   time ([DEQ, p. 1](lib:southern-oregon-outdoor-burning#page=1)). **No open burning June–October** *(rule of thumb)*.
> - **No food scraps in the garbage pit:** bears dig up buried garbage ([ODFW, p. 2](lib:living-with-black-bears-odfw#page=2)).
>   **Never cut open an animal that died suddenly with dark blood at the nose or mouth** (anthrax;
>   [WTNAD, p. 215](lib:where-there-is-no-animal-doctor#page=215)).

---

## 🗺️ Choosing and siting a toilet in our soils

**Siting:** 100 ft (30 m) from any well, spring or creek, downhill of it, with the pit bottom 5 ft (1.5 m)
above the water table; more in cracked rock ([Sphere, p. 140](lib:sphere-handbook-2018#page=140)). Keep
latrines downwind and well away from the kitchen ([FM 21-10, p. 77](lib:us-army-fm-21-10#page=77)). On
gravelly Illinois River terraces sewage travels fast toward shallow wells, so add distance *(rule of thumb)*.

**Our clay is waterlogged in winter.** Valley-floor soils such as Brockman clay loam have a **perched winter water
table only 24–36 in down** and very slow drainage; septic drainfields "function poorly" on them
([Soil Survey, p. 33](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=33)). A pit
dug there in winter fills with water. So:
- **Dig pits in the dry season**, on higher, well-drained ground.
- **November to April, on the valley floor,** use a bucket toilet or a compost toilet built on top of the
  ground. The Army switches to a pail latrine whenever the water table is too high
  ([FM 21-10, p. 134](lib:us-army-fm-21-10#page=134); [🖼️ pail latrine, p. 135](lib:us-army-fm-21-10#page=135)).

![A slope seen from the side: a well uphill, and a pit latrine at least 100 ft away downhill, its pit bottom at least 5 ft above the groundwater](img:SANITATION-GUIDE/latrine-siting.svg)
*100 ft away, downhill, 5 ft above groundwater; on valley clay in winter, don't dig a pit at all (a diagram drawn for this guide).*

| Situation | Use |
|---|---|
| One use, away from home | Cat hole ([🖼️ FM 21-10, p. 131](lib:us-army-fm-21-10#page=131)) |
| First 1–3 days, a few people | Straddle trench ([🖼️ FM 21-10, p. 133](lib:us-army-fm-21-10#page=133)) |
| Indoors, any season; winter on clay | [Twin-bucket toilet](guide:MAKE-DO-HOUSEHOLD-GUIDE) ([🖼️ photo, OSU p. 2](lib:osu-extension-survival-basics-sanitation#page=2)) or a [container toilet](wiki:Container-based_sanitation) |
| Months to years, one household, dry ground | Pit or VIP latrine ([🖼️ deep pit, FM 21-10 p. 134](lib:us-army-fm-21-10#page=134)) |
| A neighborhood or camp | Trench latrine ([🖼️ WHO/WEDC, p. 57](lib:who-wedc-technical-notes#page=57)) |
| Years, and you want fertilizer | Composting toilet, stored 2 years ([🖼️ EPA, p. 4](lib:epa-composting-toilets#page=4)) |

📚 **Go deeper:** [*Compendium of Sanitation Technologies in Emergencies*](lib:compendium-of-sanitation#page=38) — every emergency toilet, illustrated; [Hesperian Ch 7, p. 18](lib:building-toilets#page=18) — choosing a toilet site.

## ⛏️ Latrines step by step

- **[Cat hole](wiki:Cathole):** 6–12 in deep, used once and covered at once ([🖼️ FM 21-10, p. 131](lib:us-army-fm-21-10#page=131)).
- **Straddle trench:** **1 ft wide, 2½ ft deep, 4 ft long**, parallel trenches at least 2 ft apart. Cover
  each use with the dug earth ([Special Forces Handbook, p. 162](lib:special-forces-medical-handbook#page=162);
  [🖼️ FM 21-10, p. 133](lib:us-army-fm-21-10#page=133)),
  and cover well: a thin layer of soil can **increase** fly breeding
  ([Rozendaal, p. 321](lib:vector-control-methods#page=321)).
- **Simple pit:** a bit under 3 ft (1 m) across and 3–6½ ft (1–2 m) deep, under a slab whose hole has a
  lid that stays on ([WTND ch. 12, p. 9](lib:where-there-is-no-doctor-12-prevention#page=9)). Hesperian
  says at least 6½ ft deep, with the top lined so the edge can't collapse
  ([Ch 7, p. 19](lib:building-toilets#page=19)).
- **VIP latrine** ([pit latrine](wiki:Pit_latrine)): add a vent pipe that rises **at least 20 in (50 cm) above the roof, with fly
  screen on top** ([Hesperian Ch 7, p. 22](lib:building-toilets#page=22)), and keep the shelter **dark**, door shut. Smells go up the pipe; flies head for the
  light at its top and die there ([Practical Action *VIP Latrine*, p. 1](lib:practical-action-ventilated#page=1);
  [🖼️ how the air flows, Rozendaal p. 163](lib:vector-control-methods#page=163); [🖼️ Hesperian Ch 7, p. 22](lib:building-toilets#page=22)).
- **Neighborhood trench latrine:** about 3 ft wide, 5–10 ft deep, no more than 20 ft long, one stall per
  3 ft ([🖼️ WHO/WEDC, p. 57](lib:who-wedc-technical-notes#page=57)). Line the top 20 in so the edges don't cave in. Solids build up at **3–5 litres (about a gallon)
  per person per month** ([Compendium, p. 44](lib:compendium-of-sanitation#page=44)): a family of 5 fills
  about a cubic yard every 3 years *(arithmetic)*.
- **Closing a full pit:** when the waste is **1 ft below the surface**, fill the rest in packed 3-in
  layers and mound at least 1 ft of earth on top so fly pupae can't dig out
  ([Special Forces Handbook, p. 162](lib:special-forces-medical-handbook#page=162)). Or let it settle,
  top up, and **plant a tree** on it ([Hesperian Ch 7, p. 19](lib:building-toilets#page=19); [🖼️ a toilet for tree planting, p. 26](lib:building-toilets#page=26);
  [Arborloo](wiki:Arborloo)).

![Straddle-trench latrine: trenches 1 ft wide, 2½ ft deep and 4 ft long, 2 ft apart, with the dug dirt and a shovel beside each, inside a screen](img:SANITATION-GUIDE/straddle-trench.png)
*Straddle trenches: cover each use with the dug earth ([FM 21-10, p. 133](lib:us-army-fm-21-10#page=133)).*

![A VIP latrine cut open: air comes into the dark shelter, goes down the seat hole into the lined pit and out up the vent pipe, which has fly netting on top](img:SANITATION-GUIDE/vip-latrine-airflow.png)
*Air goes down the hole and up the vent, carrying the smell; flies head for the light at the top of the pipe and die at the netting ([Rozendaal, p. 163](lib:vector-control-methods#page=163)).*

**Indoor vented bucket:** a lidded 5-gallon can lined with a heavy bag, with a hose taped into a hole near
the top and run outdoors to 6 in above the ground. A full bag lifts out tied
([Kearny, p. 108](lib:nuclear-war-survival-skills-1979-original#page=108)). **Bury or compost the bags**;
piled outside, they breed flies.

📚 **Go deeper:** [WHO/WEDC *Technical Notes*, p. 55](lib:who-wedc-technical-notes#page=55) — trench and family latrines; [Practical Action *VIP Latrine*](lib:practical-action-ventilated#page=1) — vent and slab.

## ♻️ Composting toilets, humanure and urine

**After every use**, cover the deposit with **1–2 cups (200–500 mL) of wood ash or lime**. It dries it,
raises the pH to kill germs over time, and cuts flies and smell
([SEI EcoSanRes, p. 39](lib:ecological-sanitation#page=39); [Humanure](wiki:Compost)). Lime burns skin and eyes: wear gloves and goggles.

**How long to store it before it touches a garden** ([SEI, pp. 39–40](lib:ecological-sanitation#page=39)),
with nothing fresh added:

| Treatment | Store at least |
|---|---|
| Average temperature 36–68 °F (2–20 °C) — **our climate** | **1½–2 years** |
| Average temperature 68–95 °F (20–35 °C) | More than 1 year |
| Kept alkaline, pH above 9 (plenty of ash or lime) | More than 6 months |
| Hot compost: **all** of it above 122 °F (50 °C) for a week | Hard to do at home |

Then wait **1 month between spreading and harvest** (p. 40). Our mean annual air temperature is 48–54 °F
([Soil Survey, p. 32](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=32)), so
**use the 2-year rule**: in home [composting toilets](wiki:Composting_toilet), temperatures "typically
never become high enough to rapidly destroy pathogens" ([EPA, p. 4](lib:epa-composting-toilets#page=4)).
**Build two chambers** on top of the ground, not in it, so they work in waterlogged soil, and use them in
turn ([Practical Action, p. 2](lib:practical-action-compost-toilets#page=2); [🖼️ a 2-chamber dry toilet, Hesperian Ch 7, p. 28](lib:building-toilets#page=28);
[🖼️ double-vault toilet, Compendium p. 60](lib:compendium-of-sanitation#page=60)). Make each big enough to
take a year or more to fill *(rule of thumb)*.

![A double-chamber compost toilet with a wall cut away: two chambers built on the ground under a raised slab, one seat hole in use and one closed off, a vent pipe with a fly screen, a urine hole draining to a plant bed, and an ash bucket](img:SANITATION-GUIDE/two-chamber-compost-toilet.png)
*Two chambers on top of the ground: one is used while the other is closed and resting; ash goes in after each use ([Practical Action, p. 3](lib:practical-action-compost-toilets#page=3)).*

**Urine** carries few germs ([Kearny, p. 108](lib:nuclear-war-survival-skills-1979-original#page=108)),
and keeping it apart ([urine-diverting toilet](wiki:Urine-diverting_dry_toilet); [🖼️ urine-separating seats, SEI p. 35](lib:ecological-sanitation#page=35)) stops the smell
([OSU, p. 3](lib:osu-extension-survival-basics-sanitation#page=3)). On your own garden, dilute it with water and pour it on, but **stop on food crops a month before harvest**.
For crops others will eat, store it sealed 1 month, or 6 months to be safe
([SEI, pp. 21, 39](lib:ecological-sanitation#page=21)).

**Using the finished product:** worm eggs survive in soil for years ([SEI, p. 23](lib:ecological-sanitation#page=23)).
Use aged humanure around fruit trees, berries, and crops whose edible parts don't touch soil, never on
greens or root crops *(rule of thumb)*.

📚 **Go deeper:** [SEI *Safe Use of Urine and Faeces*](lib:ecological-sanitation#page=39) — the storage tables; [Practical Action *Compost Toilets*](lib:practical-action-compost-toilets#page=2) — building a two-chamber toilet.

## 🏠 Septic systems with no power, and greywater

**Find out now which kind of [septic system](wiki:Septic_tank) you have** ([🖼️ tank cross-section, Compendium p. 68](lib:compendium-of-sanitation#page=68);
[Drain field](wiki:Septic_drain_field)).
- **Gravity** (pipes slope down to the tank and drainfield) keeps working with no power
  ([Texas AgriLife, p. 2](lib:power-outages-and-floods#page=2)). Flush with a bucket of used wash water
  *(rule of thumb)*.
- **Pump tanks, sand filters, aerobic units, pressure or drip lines stop.** The reserve may be only
  **80 gallons** for a 3-bedroom house. Use water only to flush and wash hands, stop if drains slow, and
  **stop all use in a long outage** ([Texas AgriLife, p. 3](lib:power-outages-and-floods#page=3)); switch
  to a bucket toilet. Many Josephine County homes on clay or serpentine have these *(rule of thumb)*.

**With no pump trucks:** a tank needs pumping when scum is within 6 in of the outlet or sludge within 12 in,
normally every 3–5 years. Additives do nothing. Never pour grease, oil, solvents or paint down a drain
([EPA SepticSmart, pp. 3, 4, 7](lib:septicsmart#page=3)); keep food scraps and wipes out too *(rule of thumb)*.

**After a flood:** don't use it until water has left every part, and **don't pump a tank empty while the
ground is soaked**: it can float out of the ground ([Texas, p. 4](lib:power-outages-and-floods#page=4)).

**[Greywater](wiki:Greywater)**, following Oregon's rules
([DEQ, pp. 3–4](lib:oregon-deq-reusing-graywater#page=3)):
- Store it **no more than 24 hours**.
- Release it **at least 2 in under soil or mulch**, 4 ft above groundwater, 100 ft from wells, and never
  onto edible parts of crops or root vegetables ([🖼️ a simple system, DEQ p. 15](lib:oregon-deq-reusing-graywater#page=15)).
- A **soak pit** ([🖼️ FM 21-10, p. 130](lib:us-army-fm-21-10#page=130)) is 5–13 ft deep, filled with rocks, 6½ ft above the highest groundwater. **Clay won't take
  it** ([Compendium, p. 150](lib:compendium-of-sanitation#page=150)). On valley clay in winter, carry
  greywater to higher ground or use it to flush *(rule of thumb)*.
- **Kitchen water:** a barrel grease trap (gravel, then ashes or sand, burlap on top), cleaned every 2
  days ([Special Forces Handbook, p. 164](lib:special-forces-medical-handbook#page=164); [🖼️ FM 21-10, p. 131](lib:us-army-fm-21-10#page=131);
  [Grease trap](wiki:Grease_trap)).

📚 **Go deeper:** [Texas AgriLife *Septic Systems in Outages and Floods*](lib:power-outages-and-floods#page=2) — which systems stop; [EPA *Homeowner's Guide to Septic Systems*](lib:septicsmart#page=3); [Oregon DEQ *Reusing Graywater*](lib:oregon-deq-reusing-graywater#page=3).

## 🧼 Handwashing and water for hygiene

**Build a [tippy tap](wiki:Hand_washing)** ([USAID, pp. 1–2](lib:tippy-tap#page=1)):
1. Take a 1½-gallon (5 L) plastic jug **with a handle**. Warm the base of the handle over a candle, pinch
   it shut with pliers, and let it cool watertight.
2. With a candle-heated nail, make a **small hole** in the handle just above the seal, and two bigger holes
   in the back, halfway up, for the hanging string.
3. Hang it from a stick so the full jug tilts at 45°. Hang **soap on a string under an upside-down tin
   can**. Pull a string tied to the cap to tip water onto your hands.
4. Scrub the outside daily; clean the inside weekly.

![How to make a tippy tap: a jug with the base of its handle sealed and a small hole just above the seal, hung by two holes in its back from a stick so it tilts, with soap hanging under a tin can and a string on the cap to tip it](img:SANITATION-GUIDE/tippy-tap.svg)
*Pull the cap string and water runs out of the small hole in the handle (a diagram drawn for this guide).*

Put one **within 16 ft (5 m) of every toilet** and wherever food is made. No water? Rub hands with ash or
alcohol hand rub ([Compendium, p. 40](lib:compendium-of-sanitation#page=40)). Sanitizer needs **60%+
alcohol** and fails on visibly dirty hands ([OSU, p. 4](lib:osu-extension-survival-basics-sanitation#page=4)).
See [hand washing](wiki:Hand_washing) ([🖼️ the steps, WHO/WEDC p. 40](lib:who-wedc-technical-notes#page=40);
[🖼️ WHO handwashing steps, MCPC pp. 51–53](lib:managing-complications-in-pregnancy#page=51); [🖼️ field handwashing devices, FM 21-10 p. 139](lib:us-army-fm-21-10#page=139))
and [hand sanitizer](wiki:Hand_sanitizer).

**Wash hands** **before** cooking, eating or feeding anyone, and **after** the toilet, caring for someone
with diarrhea, cleaning a child's bottom, cleaning up feces or vomit, or touching a body
([MSF Cholera, p. 46](lib:management-of-a-cholera#page=46)).

**How much water** ([WHO/WEDC, pp. 36–37](lib:who-wedc-technical-notes#page=36)):

| Use | Per person per day |
|---|---|
| Drinking | 2.5–3 L (about ¾ gal) |
| Hygiene | 2–6 L |
| Cooking | 3–6 L |
| **Bare survival, total** | **7.5–15 L (2–4 gal)** |
| **Minimum for real hygiene** | **20 L (5 gal)** |
| A cholera patient | 60 L, plus 15 L for the carer |

**Enough water matters as much as safe water** ([Hesperian Ch 5, p. 3](lib:unsafe-water#page=3)).

📚 **Go deeper:** [*Tippy-Tap*](lib:tippy-tap#page=1) — the picture guide; [WHO/WEDC, p. 36](lib:who-wedc-technical-notes#page=36) — water quantities; [Army FM 21-10](lib:us-army-fm-21-10#page=10) — field hygiene for a group.

## 🧺 Dishes, laundry and periods

**Dishes:** scrape scraps into a bucket for the chickens. Wash in hot soapy water (120–140 °F) and rinse.
Then **dip in boiling water for 10 seconds**, or in **1 Tbsp unscented bleach per gallon**, and
**air-dry** ([FM 21-10, p. 114](lib:us-army-fm-21-10#page=114); [OSU EM9273, p. 3](lib:open-air-poultry-slaughter#page=3)).

**Laundry:** soap and cold water **don't** get rid of lice. Wash clothes and bedding **above 140 °F
(60 °C)**, then iron or dry in full sun ([Rozendaal, p. 274](lib:vector-control-methods#page=274)). No hot
water? **Seal them in a plastic bag for 72 hours** for scabies, or 2 weeks for head-lice items
([MSF Clinical Guidelines, pp. 133, 136](lib:msf-clinical-guidelines#page=133)). **Never wash a sick
person's clothes in a creek** or any drinking source ([MSF Cholera, p. 46](lib:management-of-a-cholera#page=46)).

**Periods:** a year's supply per woman is **6 reusable pads** (or 4 m² of absorbent cotton), **6 pairs
of underwear**, and an extra 250 g (½ lb) of soap a month ([Sphere, p. 129](lib:sphere-handbook-2018#page=129)).
Change cloth [pads](wiki:Menstrual_pad) ([🖼️ pattern, WASHplus](lib:making-reusable-menstrual-pads#page=1)) several times a day, wash with soap and dry in the sun. Change a
tampon **at least 3 times a day**, or it can cause serious infection
([WWHND ch. 5, p. 4](lib:where-women-have-no-doctor-05#page=4)). Plan a private place to wash and dry pads
by the latrine ([Compendium, p. 44](lib:compendium-of-sanitation#page=44)).

📚 **Go deeper:** [WASHplus pad pattern](lib:making-reusable-menstrual-pads#page=1) — sew your own; [FM 21-10, p. 114](lib:us-army-fm-21-10#page=114) — dishwashing setup; [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — laundry soap and hand washing.

## 🦠 How germs spread, and stopping an outbreak

**The "F-diagram"** ([fecal–oral route](wiki:Fecal–oral_route)): germs from feces reach the mouth by
**fingers, flies, fields, fluids (water) and food**. Every barrier counts: latrines, handwashing, safe
water, covered food, animals kept out of the house ([Hesperian Ch 5, p. 6](lib:unsafe-water#page=6);
[WTND ch. 12, p. 3](lib:where-there-is-no-doctor-12-prevention#page=3); [🖼️ the barriers drawn, WHO/WEDC p. 39](lib:who-wedc-technical-notes#page=39);
[🖼️ SEI p. 12](lib:ecological-sanitation#page=12)).

**An outbreak is starting** when you see bloody diarrhea, watery diarrhea in anyone over 5, suspected
cholera, or yellow eyes or skin in several people. Start isolation and hygiene measures neighborhood-wide
([WHO, p. 115](lib:communicable-disease-control#page=115)).

**"Enteric isolation"** ([cholera](wiki:Cholera), [shigella dysentery](wiki:Shigellosis), [typhoid](wiki:Typhoid_fever), E. coli, [hepatitis A](wiki:Hepatitis_A)) means handwashing, the
sick person's own dishes, and safe disposal of their feces and soiled things
([WHO, p. 133](lib:communicable-disease-control#page=133)).
- **Typhoid:** a separate room; stools buried deep. People who recover can carry it for a long time and
  **must not cook for others** ([WTND ch. 14, p. 12](lib:where-there-is-no-doctor-14-serious#page=12)).
- **Hepatitis A and E:** antibiotics don't help, and **acetaminophen (Tylenol) further damages the liver**
  ([WTND ch. 13, p. 22](lib:where-there-is-no-doctor-13-some#page=22)).

**Isolate kindly** ([WHO, p. 132](lib:communicable-disease-control#page=132)): let **one family member**
care for each sick person, with gloves and an apron and a lesson in using them. Explain isolation to
everyone. **Shame and fear make people hide sick relatives**, and hidden cases spread the outbreak.

**Rehydration drink** ([WTND ch. 13, p. 2](lib:where-there-is-no-doctor-13-some#page=2);
[oral rehydration](wiki:Oral_rehydration_therapy); [🖼️ drawn, Hesperian Ch 5, p. 10](lib:unsafe-water#page=10)): 1 litre (about 1 quart) of clean water and **½ level
teaspoon salt**. Taste it: it must be **less salty than tears**. Then add **8 level teaspoons sugar**.
Keep giving food and breast milk.

**Cholera or bloody diarrhea in the house** ([MSF Cholera, pp. 46–48](lib:management-of-a-cholera#page=46)):
1. Wipe up vomit or feces first, put it in the latrine or bury it, then wash the spot with soap.
2. Wash the sick person's clothes and bedding with soap and dry them in the sun. Sun the mattress too: the
   cholera germ dies when dried.
3. **Don't spray whole houses with chlorine.** No study shows it helps, and it makes families hide cases.
   A kit of bucket, soap, detergent and cloths does more.

📚 **Go deeper:** [WHO *Communicable Disease Control in Emergencies*](lib:communicable-disease-control#page=132) — isolation and disease pages; [MSF *Management of a Cholera Epidemic*](lib:management-of-a-cholera#page=46) — household rules.

## 🧪 Chlorine strengths from household bleach

**These are for cleaning — never for drinking.** Even the weakest (0.05%) is far too strong to drink.
To make **drinking water** safe, use **8 drops of 6% bleach (6 drops of 8.25%) per gallon** and wait 30
minutes ([Water Purification guide](guide:WATER-PURIFICATION-GUIDE);
[EPA, p. 2](lib:epa-emergency-disinfection-of-drinking-water#page=2)).

| Strength | Use it for ([Compendium, p. 174](lib:compendium-of-sanitation#page=174)) | From **6%** bleach | From **8.25%** bleach |
|---|---|---|---|
| **0.05%** | Skin and hands (if no soap), laundry, latrines, kitchen | About **2 Tbsp per gallon** | About **1½ Tbsp per gallon** |
| **0.2%** | Floors, beds, clothes, objects | About **½ cup per gallon** | About **6 Tbsp per gallon** |
| **2%** | Feces, vomit, washing bodies | **1 part bleach + 2 parts water** | **1 part bleach + 3 parts water** |

The rule is **parts of water = (bleach % ÷ % wanted) − 1** ([MSF Cholera, p. 226](lib:management-of-a-cholera#page=226));
the amounts above are that arithmetic.
- Read the strength on the label; use plain, unscented bleach.
- **Mix fresh every day**, and clean first: bleach doesn't work through dirt.
- **Never** pour it into a urine bucket or mix it with ammonia or vinegar.
- Drinking water needs a far weaker dose: see the [Water Purification guide](guide:WATER-PURIFICATION-GUIDE).

📚 **Go deeper:** [MSF Cholera, p. 226](lib:management-of-a-cholera#page=226) — dilution tables; [Compendium, p. 174](lib:compendium-of-sanitation#page=174) — cholera disinfection.

## 🪰 Flies, mosquitoes, lice and scabies

**Flies** ([housefly](wiki:Housefly)) go from egg to adult in **6–42 days**, faster in heat
([Rozendaal, p. 314](lib:vector-control-methods#page=314); [🖼️ the fly and its life cycle, p. 315](lib:vector-control-methods#page=315)). In hot weather **empty and bury garbage at
least twice a week**: maggots leave closed bins after 3–4 days. Cover a garbage pit with fresh soil at
least weekly; fit latrines with tight lids or screened vents (p. 321; [🖼️ tight-lidded bins, p. 321](lib:vector-control-methods#page=321);
[🖼️ a fly- and mosquito-proof latrine lid, p. 160](lib:vector-control-methods#page=160)). June–September is peak fly season
here *(rule of thumb)*.

**Mosquitoes** take about 7–13 days from egg to adult, so **empty and scrub small water containers
weekly**, and cover barrels with tight lids or netting ([Rozendaal, pp. 23, 156](lib:vector-control-methods#page=156);
[🖼️ mosquito life cycle, p. 22](lib:vector-control-methods#page=22); [🖼️ lids and netting, p. 156](lib:vector-control-methods#page=156); [Mosquito](wiki:Mosquito)).
Ditches, stock tanks, old tires and open rain barrels breed them here, and West Nile virus has been found
in southern Oregon *(rule of thumb)* ([West Nile virus](wiki:West_Nile_virus); [Culex tarsalis](wiki:Culex_tarsalis)).

**Body lice** ([body louse](wiki:Body_louse)) live and lay eggs **in clothing seams**, and spread typhus,
relapsing fever and trench fever. Hot washing and ironing fix it; in an outbreak, dust **0.5% permethrin
powder** inside clothes ([Rozendaal, p. 274](lib:vector-control-methods#page=274); [🖼️ how to dust clothing, p. 275](lib:vector-control-methods#page=275);
[MSF Clinical, p. 136](lib:msf-clinical-guidelines#page=136)). **[Head lice](wiki:Head_louse)** ([🖼️ the three kinds of lice, Rozendaal p. 266](lib:vector-control-methods#page=266); [🖼️ checking hair and combing, pp. 268–271](lib:vector-control-methods#page=268)): **dimeticone (from age 6 months) or 1% permethrin
(from 2 months) lotion, repeated after 7 days**; treat only contacts with live lice or nits (same page).

**[Scabies](wiki:Scabies)** ([🖼️ the mite and an infested wrist, Rozendaal pp. 291–292](lib:vector-control-methods#page=291); [Sarcoptes scabiei](wiki:Sarcoptes_scabiei)): itching worse at night, with fine wavy burrows between the fingers and on the
wrists. **Treat everyone in close contact at the same time, even if they don't itch**: **permethrin 5%
cream** (age 2 months and up) left on 8 hours, repeated after 7 days. Wash bedding hot or bag it 72 hours
([MSF Clinical, pp. 133–134](lib:msf-clinical-guidelines#page=133)). A first-time rash can take 4–6 weeks
to show, so one case means others are probably infested already
([Rozendaal, p. 292](lib:vector-control-methods#page=292)). Stock permethrin and dimeticone now *(rule of
thumb)*. Ticks ([western black-legged tick](wiki:Ixodes_pacificus)) are in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE).

📚 **Go deeper:** [WHO *Vector Control* (Rozendaal)](lib:vector-control-methods#page=314) — flies, mosquitoes, lice, fleas and mites; [MSF Clinical Guidelines, p. 133](lib:msf-clinical-guidelines#page=133) — scabies and lice treatment.

## 🐭 Mice, hantavirus, fleas and plague

**Hantavirus:** in the West the [deer mouse](wiki:Western_deer_mouse) carries it, and people usually catch
it by breathing dust from droppings. Illness starts **1–8 weeks** later with fever, aches and vomiting;
4–10 days after that comes [shortness of breath](wiki:Hantavirus_pulmonary_syndrome). There is no specific
treatment ([NPS, p. 1](lib:hantavirus-fact-sheet#page=1)). Woodsheds, cabins, root cellars and
barns here all hold deer mice *(rule of thumb)*.

**Keep them out:** seal every gap **wider than ¼ in** ([🖼️ gaps around pipes, USDA p. 18](lib:rat-proofing-buildings#page=18)), keep food and trash sealed, and keep plants 18 in from
walls ([NPS, p. 1](lib:hantavirus-fact-sheet#page=1)). Use snap traps ([Mousetrap](wiki:Mousetrap)) or cats, not poison, which kills pets
and children ([WTND ch. 14, p. 12](lib:where-there-is-no-doctor-14-serious#page=12)).

**Cleaning up droppings** ([NPS, p. 2](lib:hantavirus-fact-sheet#page=2)):
1. Open the windows and **leave for 30 minutes**. **Never sweep or vacuum.**
2. With gloves on, soak droppings, nests and dead mice with **1:10 bleach (about 1½ cups per gallon of
   water), mixed fresh that day**. Spray 2 ft around, and wait **at least 10 minutes**.
3. Wipe up with paper towels. Pick up dead mice with a bag turned inside out over your gloved hand.
   Double-bag everything.
4. Spray the gloves before taking them off, then wash your hands with soap.

**Fleas and [plague](wiki:Plague_(disease)):** flea cocoons can wait **up to a year** in an empty house and hatch all at once when
people move in ([Rozendaal, p. 256](lib:vector-control-methods#page=256); [🖼️ rat, human and cat fleas, p. 255](lib:vector-control-methods#page=255);
[Oriental rat flea](wiki:Oriental_rat_flea)). **Don't handle dead rats or
squirrels**: their fleas jump to people. Drown dead rats, then burn them
([WTND ch. 14, p. 12](lib:where-there-is-no-doctor-14-serious#page=12)), or bury them deep in fire season.
Plague lives in wild ground squirrels ([California ground squirrel](wiki:California_ground_squirrel)), chipmunks and their fleas in parts of Oregon. Keep cats from hunting,
and treat a cat with a swollen neck or fever as dangerous *(rule of thumb)*.

📚 **Go deeper:** [NPS *Hantavirus Fact Sheet*](lib:hantavirus-fact-sheet#page=2) — cleanup steps; [USDA *Rat Proofing Buildings*, p. 27](lib:rat-proofing-buildings#page=27) — keeping rodents out.

## 🗑️ Garbage when no truck comes

Open trash piles breed rats, flies and mosquitoes, and their chemicals seep into soil and water
([Hesperian Ch 18, p. 5](lib:ch-18-solid-waste#page=5)); heaps catch fire, and rain washes them into water
supplies ([WHO/WEDC, p. 27](lib:who-wedc-technical-notes#page=27)). So make less, and **sort it in the
kitchen** into two or three bins ([🖼️ Hesperian Ch 18, p. 13](lib:ch-18-solid-waste#page=13)). Sorting later,
at a dump, is dangerous and works worse (p. 14).

| Kind of waste | Where it goes |
|---|---|
| **Vegetable scraps, peelings, coffee grounds** | Chickens, pigs, a worm bin or compost. **Never the garbage pit**: bears dig it up (see "Garbage, bears and pests") |
| **Meat, bones, fat, fish** | **Cook scraps before pigs get them**: raw garbage gives pigs trichinosis ([Zoonoses, p. 121](lib:zoonoses#page=121)). Render fat into [soap](guide:MAKE-DO-HOUSEHOLD-GUIDE); burn bones in a hot stove *(rule of thumb)* |
| **Paper, cardboard, sawdust** | Shredded into compost, sawdust into dry toilets ([Hesperian Ch 18, pp. 18–19](lib:ch-18-solid-waste#page=18)), or burned in the cooking or heating fire ([p. 24](lib:ch-18-solid-waste#page=24)) |
| **Jars, bottles, tin cans, buckets** | Wash and keep: bottles reuse as they are, cans make lamps and planters ([Hesperian Ch 18, pp. 19–20](lib:ch-18-solid-waste#page=19)). Food-safe ones: "Containers and storage" in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) |
| **Batteries, oil, paint, pesticides, medicines, bulbs** | A separate toxics store ([Hesperian Ch 18, p. 13](lib:ch-18-solid-waste#page=13)): see "Hazardous waste" below |
| **Broken glass, plastic, rubber, scrap** | Rinse off any food, then the garbage pit. **Never burn it** |

### A household garbage pit or trench

- **Where:** **100 ft (30 m) from wells, springs and creeks**, downhill of them, the bottom 5 ft above
  groundwater ([Sphere, p. 140](lib:sphere-handbook-2018#page=140)), 100 ft from the kitchen
  ([FM 21-10, p. 129](lib:us-army-fm-21-10#page=129)), and on higher ground, dug in the dry season, as for latrines.
- **A pit** is 4 ft square and 4 ft deep, filled to 1 ft below ground and mounded over with earth
  ([Special Forces Handbook, p. 164](lib:special-forces-medical-handbook#page=164); [🖼️ FM 21-10, p. 129](lib:us-army-fm-21-10#page=129)).
  Cover each layer with **4 in of soil or ash**, and a full pit with **20 in** ([WHO/WEDC, p. 29](lib:who-wedc-technical-notes#page=29)).
- **A trench** lasts longer: **2 ft wide, 3–4 ft deep**, filled to within 1 ft of the top and dug onward,
  the new dirt covering the last load ([Special Forces Handbook, p. 164](lib:special-forces-medical-handbook#page=164)).
- **In the wet months,** dig a small new hole each week or month and roof it against rain
  ([Hesperian Ch 18, p. 29](lib:ch-18-solid-waste#page=29)). **Fence it**, and keep it deep enough that
  animals can't dig in ([WWHND ch. 10, p. 4](lib:where-women-have-no-doctor-10-staying-healthy#page=4)).

### A shared neighborhood dump

Country garbage usually goes into family or **shared neighborhood pits**
([WHO/WEDC, p. 28](lib:who-wedc-technical-notes#page=28)). A shared one needs:
1. **A site** 820 ft (250 m) from streams and ponds and 1,640 ft (500 m) from homes and wells, out of any
   flood zone, its bottom 6½ ft (2 m) above the highest groundwater ([Hesperian Ch 18, p. 27](lib:ch-18-solid-waste#page=27)).
2. **A fence with a locking gate**, sand or soil kept there for fires ([🖼️ p. 28](lib:ch-18-solid-waste#page=28)),
   and no open flames ([WHO/WEDC, p. 28](lib:who-wedc-technical-notes#page=28)).
3. **Each load pressed down and covered** with soil, or soil, ash and sand, under a roof (Hesperian p. 29).
4. **One person or team in charge**, with gloves, boots, masks, overalls and tetanus shots (WHO/WEDC p. 28).
5. **When full, a cap of 3 ft (90 cm) of soil**, planted with grass, never food plants, and no grazing until
   it's grown over ([Hesperian Ch 18, p. 29](lib:ch-18-solid-waste#page=29)). Circles of dead grass mean
   landfill gas: keep 33 ft (10 m) away (p. 30).

📚 **Go deeper:** [Hesperian Ch 18 *Solid Waste*](lib:ch-18-solid-waste#page=11) — reducing, sorting, reusing, landfills; [WHO/WEDC Technical Note 7, p. 27](lib:who-wedc-technical-notes#page=27) — solid waste in emergencies.

## 🌱 Composting food, yard waste and manure

A **hot pile** reaches **130–150 °F**, which kills most weed seeds and germs; a **slow pile** kills far fewer
([WSU EB1784E, p. 2](lib:wsu-backyard-composting#page=2), written for the Northwest; [Compost](wiki:Compost)).

**Building a hot pile** ([WSU, pp. 3–6](lib:wsu-backyard-composting#page=3)):
1. Collect **at least 1 cubic yard** at once: a heap 5 ft wide and 3 ft high, or a bin **3 × 3 × 3 ft** of
   pallets, lumber, wire mesh or blocks (pp. 4–5). Small piles stay cold.
2. Mix **1 part "greens" to 2 parts "browns"** by volume (p. 3). Greens are wet and rich in nitrogen (p. 2):
   food scraps, fresh manure ([Hesperian Ch 18, pp. 17–18](lib:ch-18-solid-waste#page=17)). Browns are dry:
   straw, brown leaves, husks, shredded paper (p. 18), wood chips (WSU p. 3).
3. **Squeeze a handful:** barely a drop should come out. Too dry, add water; too wet, add browns (p. 5).
4. **Turn it weekly for 4–6 weeks**, and **cover it in rainy weather**, or in a wet winter it may never heat (pp. 4–5).
5. After several hot weeks it **cures 2–3 months**. It's ready when turning no longer heats it and it looks
   dark and crumbly (p. 6).

Rotting instead of heating? Add browns. Smells? Turn it for air. Flies? Cover it better with soil
([Hesperian Ch 18, p. 18](lib:ch-18-solid-waste#page=18)).

**Slow pile:** heap yard waste for a year, tucking scraps into the middle, then turn it and leave it a second
year ([WSU, pp. 4–5](lib:wsu-backyard-composting#page=4); [🖼️ two-pile system, p. 5](lib:wsu-backyard-composting#page=5)).
It won't kill weed seeds or germs, so pull weeds before they seed (p. 5). **Worm bin**
([vermicompost](wiki:Vermicompost)): 1 cubic foot of bin, no more than 1 ft deep, per pound of scraps a week (a
14-gallon tote suits 2–3 people); outdoors, on the north side of a building, safe from rats and raccoons
([OSU EM 9034, pp. 2–3](lib:composting-with-worms#page=2); [🖼️ p. 4](lib:composting-with-worms#page=4)).

**Keep out:** meat, bones, fish, grease and dairy, which draw pests and bears ([WSU, p. 6](lib:wsu-backyard-composting#page=6);
[ODFW, p. 2](lib:living-with-black-bears-odfw#page=2)). Bury fruit and vegetable scraps fully inside the pile,
or use a pest-proof bin ([🖼️ WSU, p. 5](lib:wsu-backyard-composting#page=5)). Also keep out dog and cat feces
(WSU p. 7), plastic, metal, glass and poisonous plants ([Hesperian Ch 18, p. 18](lib:ch-18-solid-waste#page=18)).
Human waste: see "Composting toilets, humanure and urine".

**Manure** can carry *Salmonella* and *E. coli* O157:H7: give manure compost **a year or more** before it
goes on root crops, lettuce or strawberries. **Bought hay or straw** may carry clopyralid or aminopyralid
weed killers that pass into manure and harm tomatoes, potatoes and beans: ask the grower
([WSU, p. 7](lib:wsu-backyard-composting#page=7)). Cover dung heaps with plastic so the heat kills fly maggots
([🖼️ Rozendaal, p. 320](lib:vector-control-methods#page=320)). Each animal's manure: "Manure for the garden" in
the [Rabbits guide](guide:RABBITS-GUIDE), "Manure, litter and feathers" in the [Chickens guide](guide:CHICKENS-GUIDE), "Teeth and worms" in the [Horse guide](guide:HORSE-GUIDE).
**Use** 1–3 in mixed into a new bed, then ½–1 in a year. Moist, backyard-size piles don't catch fire (WSU pp. 6–7).

📚 **Go deeper:** [WSU *Backyard Composting*](lib:wsu-backyard-composting#page=2) — hot and slow piles, bins; [OSU *Composting with Worms*](lib:composting-with-worms#page=2) — worm bins; [OSU EC 1561, p. 7](lib:improving-garden-soils#page=7) — leaf and yard compost; [Hesperian Ch 18, pp. 16–17](lib:ch-18-solid-waste#page=16) — pit compost and a fast layered pile.

## 🐻 Garbage, bears and pests

Oregon has **25,000–30,000 black bears**; one that gets human food or garbage loses its fear of people and
often has to be killed ([ODFW *Living with Black Bears*, p. 1](lib:living-with-black-bears-odfw#page=1);
[American black bear](wiki:American_black_bear)). **"Do not bury garbage or fish refuse; bears will dig it
up"** ([p. 2](lib:living-with-black-bears-odfw#page=2)). A homestead still needs a pit, so keep every food
smell out of it, cover each layer, and fence it, with electric wire whenever bears are about *(rule of thumb)*.

**Around the house** (ODFW, p. 2): keep garbage cans in a shed or behind chain-link or electric fence,
scrubbed with **bleach**. ODFW also suggests mothballs: **don't**, they poison children and pets *(rule of
thumb)*. Electric-fence compost, gardens, orchards, berries and hives; pick up fallen fruit; feed pets
indoors; lock up livestock feed, since **plastic tubs won't stop a bear**
([BearWise, p. 1](lib:raising-chickens-in-bear-country-odfw#page=1)); and ask the neighbors to do the same.

**Electric fence for bears** ([BearWise, p. 2](lib:raising-chickens-in-bear-country-odfw#page=2); [Electric fence](wiki:Electric_fence)):
- **At least 3 wires** (5 or 6 is better), **8–10 in apart**: **lowest 7–9 in** up (a little lower stops
  skunks and raccoons too), **top 36–42 in**.
- An energizer of **at least 6,000 volts and 0.5 joules**; plants kept off the wires; **voltage tested often**.
- Step-by-step photos: "Bears and fire season" in the [Bees guide](guide:BEES-GUIDE)
  ([🖼️ UF, pp. 3–5](lib:building-bear-fences#page=3)).

**Cougars:** leave no food or garbage outside; anything that draws other wildlife can draw a cougar, and so can
animal kills ([ODFW, p. 2](lib:oregon-is-cougar-country#page=2)). **Raccoons** that learn the garbage cans go
after the poultry next ([Kentucky ID-245, p. 2](lib:predator-management-for-small-scale-poultry#page=2)).
**Rats:** "Neatness is of prime importance": covered cans, a deep covered pit for tin cans, lumber on racks
18 in high, woodpiles and manure piles away from food ([USDA *Rat Proofing*, p. 6](lib:rat-proofing-buildings#page=6)).
Deer mice: see "Mice, hantavirus, fleas and plague".

**Flies** breed mostly in garbage, then rotting grass clippings and compost ([Rozendaal, pp. 316–317](lib:vector-control-methods#page=316)),
and spread dysentery, typhoid and cholera (p. 319). Empty and clean bins **twice a week in hot weather, weekly
in cool**, scraping out the bottom (p. 321); more in "Flies, mosquitoes, lice and scabies".

📚 **Go deeper:** [ODFW *Living with Black Bears*, p. 2](lib:living-with-black-bears-odfw#page=2) — the homeowner's checklist; [BearWise, p. 2](lib:raising-chickens-in-bear-country-odfw#page=2) — electric fence facts.

## 🔥 Burning trash and brush, and ash

**Oregon bans burning these in the open, anywhere, any time**, and a burn barrel counts as open burning
([DEQ *Southern Oregon Outdoor Burning Guide*, p. 1](lib:southern-oregon-outdoor-burning#page=1)):
**plastic, rubber, tires** (even to start a fire), **wet garbage and food waste, dead animals, oil** and
anything petroleum-treated, asphalt, auto parts, asbestos, and anything making dense smoke or foul odors.
Plastic smoke carries dioxins, furans and PCBs ([Hesperian Ch 18, p. 24](lib:ch-18-solid-waste#page=24)).
Never burn **treated wood**, even in a stove: its smoke and ash carry poisons ([*Wood Handbook*, p. 329](lib:wood-handbook#page=329))
such as arsenic ([ATSDR, p. 1](lib:atsdr-toxfaqs-arsenic#page=1)); nor old paint (lead: [Shelter guide](guide:SHELTER-BUILDING-GUIDE)),
batteries, bulbs or chemicals ([Hesperian Ch 18, p. 25](lib:ch-18-solid-waste#page=25)). Every 3 bags burned
still leave about 1 bag of toxic ash ([Hesperian Ch 19, p. 6](lib:ch-19-health-care-waste#page=6)).

**When:** DEQ allows open burning in the Rogue Valley **only outside fire season, on burn days**;
Josephine County's burn-day line is **541-476-9663**, and fire districts can still say no
([DEQ, pp. 1–2](lib:southern-oregon-outdoor-burning#page=1)). With nobody to ask: **no open burning
June–October** *(rule of thumb)*, and otherwise only on wet, calm days, in daylight
([OSU EC 1574, p. 4](lib:disposing-of-woody-material#page=4)).

**A burn barrel**, for dry paper, cardboard and clean wood only:
1. Cut both ends out of a 55-gallon drum, punch many holes near the bottom, fit a grate a few inches above
   them, and raise it on stones or bricks so air gets under ([🖼️ Special Forces Handbook, p. 165](lib:special-forces-medical-handbook#page=165)).
2. Top it with a **lid or screen with holes no bigger than ¾ in**, clear **10 ft of ground** around it, and
   keep a hose or extinguisher ready ([FEMA, p. 126](lib:fema-are-you-ready-citizen-preparedness-guide-2004#page=126)).
3. Set it downwind: the Army puts incinerators 50 yards downwind of camp
   ([Special Forces Handbook, p. 164](lib:special-forces-medical-handbook#page=164)).
4. **Bury the cold ash** ([FM 21-10, p. 129](lib:us-army-fm-21-10#page=129)), never on the garden.

**Brush** ([OSU EC 1574](lib:disposing-of-woody-material#page=2), by the Extension forester for Jackson and Josephine counties):
- **Use it first:** firewood, posts, poles (pp. 1–2), compost or chips ([DEQ, p. 1](lib:southern-oregon-outdoor-burning#page=1)),
  but no chips against the house (OSU p. 4). Or lop and scatter it 12–18 in deep at most, never within 100 ft of the house (p. 2).
- **Piles** go **10 ft from trees and brush, 100 ft from creeks and ditches**, away from buildings, firewood,
  propane and power lines, **at least 4 ft wide and high**, with fine twigs at the bottom (pp. 3–4;
  [🖼️ a well-made pile, p. 3](lib:disposing-of-woody-material#page=3)). Cover one when 80% built so it stays dry
  for a winter burn, and **pull the plastic off before lighting**: OSU says a polyethylene cover may burn with
  the pile (p. 4), but DEQ bans burning plastic.
- **Burn in daylight, in wet weather with little wind**, shovel and water ready (p. 4).
- **"Piles may smolder for days or even weeks, roaring back to life in windy, warm weather, even during dry
  winter conditions"** (p. 3). Stir and soak a burned pile until it's cold *(rule of thumb)*.

**Ash:** hot ash goes in a **lidded metal can** on dirt, 10 ft from anything that burns, for a week ("Burning
safely: stoves, chimneys, ashes" in the [Firewood guide](guide:FIREWOOD-GUIDE)). **Only clean-wood ash goes on
the garden**, never ash from coal, painted or treated wood, or a trash fire ([OSU EC 1503, p. 5](lib:fertilizing-your-garden#page=5);
[Wood ash](wiki:Wood_ash)). A cord of oak's ash gives the potash for 4,200 sq ft of garden, Douglas-fir's for 900
(p. 4). Spread it thin in spring, mixed in, wearing goggles, gloves and a dust mask; **not** on blueberries,
rhododendrons, azaleas, potato ground (scab) or seedlings, or if the soil pH is 7 or more (pp. 4–5).

📚 **Go deeper:** [DEQ *Southern Oregon Outdoor Burning Guide*](lib:southern-oregon-outdoor-burning#page=1) — banned materials, burn days, alternatives; [OSU EC 1574](lib:disposing-of-woody-material#page=3) — piling and burning slash; [OSU EC 1503, p. 4](lib:fertilizing-your-garden#page=4) — wood ash as fertilizer.

## ☣️ Hazardous waste: batteries, oil, fuel, chemicals, medicines

Paint, batteries, motor oil and old pesticides ([Hesperian Ch 18, p. 13](lib:ch-18-solid-waste#page=13);
[Household hazardous waste](wiki:Household_hazardous_waste)) leak into drinking water if buried with the
garbage (p. 24). The rules ([p. 25](lib:ch-18-solid-waste#page=25)): keep them **in their original, labeled
containers**, away from food, water and children, and **apart from other garbage**. **Never burn them** or
pour them into a latrine, drain, ditch or creek, or onto the ground. **Punch holes in or crush empty
containers** so nobody stores food or water in them ([🖼️ p. 25](lib:ch-18-solid-waste#page=25)). Fuels and
solvents go in **metal containers 30 ft from the house** ([FEMA, p. 126](lib:fema-are-you-ready-citizen-preparedness-guide-2004#page=126));
a dry, locked shed far from the well suits the rest *(rule of thumb)*.

| Waste | What to do |
|---|---|
| **Used oil, solvents, old fuel** | Closed containers, cool place; never on the ground or in water ([Hesperian Ch 18, p. 26](lib:ch-18-solid-waste#page=26)), never burned ([DEQ, p. 1](lib:southern-oregon-outdoor-burning#page=1)). Most stale fuel can be saved: "Rescuing old fuel" in the [Fuel guide](guide:FUEL-GUIDE). Soak up spills with kitty litter, which then counts as hazardous waste too ([Penn State, p. 12](lib:penn-state-biodiesel-safety#page=12)) |
| **Lead-acid batteries** | Upright, terminals covered, cool and dry, kept to be reclaimed ([DOE, p. 50](lib:doe-primer-on-lead-acid#page=50)); NiCd stored apart ([Navy, p. 27](lib:navy-electronics-technician-vol-1#page=27)). Don't break batteries open ([Hesperian Ch 18, p. 26](lib:ch-18-solid-waste#page=26)). Spilled acid: "Keeping lead-acid alive" in the [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE) |
| **Lithium-ion (phones, tools, power packs)** | **Never in the garbage or a fire**: crushed, punctured or burned, a charged cell can catch fire or explode ([NFPA, p. 1](lib:nfpa-lithium-ion#page=1); [Lighting Global, p. 8](lib:lighting-global-lithium-ion#page=8)). Run it flat first (p. 8) |
| **Paint** | Lids on, in a cool place; latex needs the same care as oil paint ([Hesperian Ch 18, p. 26](lib:ch-18-solid-waste#page=26)) |
| **Pesticides, weed and rat poison** | Original container, locked up, never in a drink bottle; rinse empties three times ([OSU EC 631, p. 17](lib:home-orchards#page=17)) and pour the rinse into a hole **330 ft (100 m) from streams, wells and houses**, on the downhill side; crush the containers, bury them there, never reuse them ([Rozendaal, pp. 397, 400](lib:vector-control-methods#page=397)). Permethrin kills fish (p. 397) |
| **Treated lumber** | Never burned; never mulch, animal bedding, cutting boards or hives ([*Wood Handbook*, p. 329](lib:wood-handbook#page=329)) |
| **Mercury: thermometers, fluorescent tubes, CFLs** | Never burned: it becomes a worse gas ([Hesperian Ch 19, p. 23](lib:ch-19-health-care-waste#page=23)) |

**A broken thermometer or fluorescent bulb** ([Hesperian Ch 19, p. 24](lib:ch-19-health-care-waste#page=24),
written for thermometers; bulbs need the same care *(rule of thumb)*): keep people and pets away, turn off fans,
open the windows. **Don't touch the mercury**; take off rings and watches; wear chemical gloves or two pairs of
latex. Find the beads with a flashlight, push them together with stiff paper, suck them into a glass jar of water
with an eyedropper, and lift the rest with sticky tape. Bag the cleanup things, label the bag "mercury waste",
seal it in the jar, and store it with the toxics.

**Old medicines** (first read "Using found or expired medicines" in the [Medicines guide](guide:Medical-READ-ME-FIRST)):
wearing gloves, glasses and a dust mask, mix the pills with dry cement and water, roll the mix into balls, and
bury them in a sealed waste pit ([Hesperian Ch 19, p. 25](lib:ch-19-health-care-waste#page=25)); or seal them in
a can with used coffee grounds or cat litter ([FDA, p. 2](lib:fda-how-to-dispose#page=2)) and bury that. Dumped
antibiotics breed resistant germs (Hesperian p. 25): never put medicines in water, a latrine or a septic tank
*(rule of thumb)*. Used fentanyl patches still hold a lot of drug; inhalers are dangerous punctured or burned (FDA p. 2).

📚 **Go deeper:** [Hesperian Ch 18, pp. 25–26](lib:ch-18-solid-waste#page=25) — toxic household waste; [Hesperian Ch 19, pp. 23–25](lib:ch-19-health-care-waste#page=23) — mercury and medicines; [Rozendaal, pp. 397–400](lib:vector-control-methods#page=397) — getting rid of pesticides.

## 💉 Sickroom and birth waste

From [Hesperian Ch 19, pp. 21–22](lib:ch-19-health-care-waste#page=21):
- Needles and blades go in a **hard, sealed container** ([🖼️ Hesperian Ch 19, p. 17](lib:ch-19-health-care-waste#page=17); [Sharps waste](wiki:Sharps_waste)).
- Dig a waste pit **165 ft (50 m) from water and buildings**, downhill from wells, its bottom 5 ft above
  the water table.
- After each load, cover with **4 in of soil**, or soil mixed with lime.
- When it's 20 in from the top, cover with 20 in of soil and seal with **4–12 in (10–30 cm) of concrete**
  ([🖼️ the finished pit, p. 22](lib:ch-19-health-care-waste#page=22)).
- A placenta can go into the latrine or a deep burial ([p. 12](lib:ch-19-health-care-waste#page=12)).

📚 **Go deeper:** [Hesperian Ch 19 *Health Care Waste*](lib:ch-19-health-care-waste#page=21) — building the waste pit.

## 🐄 Dead animals and gut piles

**Move a dead animal at once:** carcasses draw predators ([Kentucky ID-245, p. 6](lib:predator-management-for-small-scale-poultry#page=6)),
and botulism poison builds up in maggots on dead birds, which chickens eat
([*Raising Healthy Poultry*, p. 70](lib:raising-healthy-poultry-cvm#page=70)). Oregon law, while enforced: a
carcass within **½ mile of a home or ¼ mile of a running stream** must be dealt with within **15 hours** of
death or discovery, and **may not be burned in the open** ([ODA *Livestock Mortality*, pp. 1, 3](lib:managing-livestock-mortality#page=1)).

**Could it be [anthrax](wiki:Anthrax)?** If an animal died suddenly with **dark blood from the nose, mouth or
anus, don't cut it open**: the spores foul the soil for good
([*Where There Is No Animal Doctor*, p. 215](lib:where-there-is-no-animal-doctor#page=215)). People catch it too.
Keep dogs and scavengers off, and bury it **unopened, where it lies**, deep, under quicklime
([*Zoonoses*, pp. 69–70](lib:zoonoses#page=69); [*Raising Healthy Cattle*, p. 108](lib:raising-healthy-cattle#page=108)).
*Zoonoses* would rather burn it in a pit, with old tires for heat (p. 69): **never burn tires**, and Oregon bans
burning carcasses ([DEQ, p. 1](lib:southern-oregon-outdoor-burning#page=1)).

**Burying a carcass** (Oregon's recommendations, [ODA, pp. 1–2](lib:managing-livestock-mortality#page=1)):
- **A dry hole bottom:** never soggy, flooded or floodplain ground, and groundwater **25 ft below** it. Valley
  clay is wet 2–3 ft down in winter ([Soil Survey, p. 33](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=33)),
  so bury on higher ground.
- **500 ft from creeks, ponds and wells** where you can, never under **100 ft**; 300 ft from a neighbor's house
  and 50 ft from a property line, on nearly flat ground.
- **Lime under the carcass and dusted on top** (it cuts smell and seepage), sod and manure around it, and
  **3–4 ft of soil over it**, mounded for settling and topped up as it sinks. More than 3 ft (1 m) keeps dogs
  from digging it up ([WTNAD, p. 229](lib:where-there-is-no-animal-doctor#page=229)). Lime is for animals; for
  people, see "Caring for the dead".
- **No more than 1,000 lb per hole**, except one bigger animal; over 4,200 lb needs an ODA plan or DEQ permit.

**Put down by a vet, or shot with lead:** the usual euthanasia drug, [pentobarbital](wiki:Pentobarbital),
**poisons eagles, hawks, ravens, bears, coyotes, cougars and dogs** that eat the remains, and lead harms
scavengers too ([AVMA, p. 17](lib:avma-guidelines#page=17)). Bury these deep at once (if the ground is frozen,
cover them securely until you can), and **never leave one out for scavengers** ([ODA, p. 2](lib:managing-livestock-mortality#page=2)),
nor gut piles from lead-shot game *(rule of thumb)*. Leaving any carcass out is legal only ½ mile from homes
and ¼ mile from open water (ODA, p. 2), and kills draw cougars ([ODFW, p. 2](lib:oregon-is-cougar-country#page=2)).

**Composting carcasses:** a farm may compost its own dead animals, up to 20 tons a year, with no DEQ permit if
it fouls no water and bothers no neighbors (ODA, p. 2); after a wildfire, ODA asks for a plan and a permit
([ODA wildfire sheet, p. 2](lib:caring-for-livestock-after-wildfire#page=2)). The library has no recipe: bury
small carcasses in the middle of a big hot pile, under 2 ft of sawdust, straw or manure, inside the bear
fence *(rule of thumb)*.

**Butchering waste:**
- **Never feed raw guts, offal or carcasses to dogs**, guardian dogs included: hydatid tapeworm
  ([Zoonoses, p. 119](lib:zoonoses#page=119); [Echinococcosis](wiki:Echinococcosis); [USDA AIB 588, p. 18](lib:livestock-guarding-dogs-usda-aib588#page=18)).
  Leave no raw meat where wild animals can reach it ([Zoonoses, p. 113](lib:zoonoses#page=113)).
- In the field, drag the gut pile 25 ft from the meat ([OSU PNW 517, p. 11](lib:osu-pnw517#page=11)). At home,
  bury guts, heads and bones like a carcass, or compost poultry blood, guts and feathers on the farm where
  they can't reach water ([OSU EM 9273, p. 7](lib:open-air-poultry-slaughter#page=7)).
- **Afterbirth and aborted young:** gloves (listeriosis), then bury ([WTNAD, p. 275](lib:where-there-is-no-animal-doctor#page=275)).
  **Birds dead of bird flu** infect birds of prey, scavengers and bears: bury them deep at once
  ([BearWise, p. 2](lib:raising-chickens-in-bear-country-odfw#page=2)).

**Deer and elk: [chronic wasting disease](wiki:Chronic_wasting_disease)**, an always-fatal prion disease, is in
wild deer and elk in Idaho, California and Washington ([ODFW 2026 regulations, p. 5](lib:big-game-hunting-regulations#page=5)).
Wear gloves and **don't cut into the brain or spinal cord** or saw through bone; hunters may have to bag the
bones, head and spine for incineration or a certified landfill ([OSU PNW 517, p. 4](lib:osu-pnw517#page=4)).
At home, bury them deep, away from where deer feed *(rule of thumb)*; more in the [Hunting guide](guide:HUNTING-TRAPPING-FISHING-GUIDE).

📚 **Go deeper:** [ODA *Landowner's Guide to Managing Livestock Mortality*](lib:managing-livestock-mortality#page=1) — Oregon's burial, composting and scavenger rules; [*Where There Is No Animal Doctor*, p. 215](lib:where-there-is-no-animal-doctor#page=215) — anthrax; [AVMA, p. 17](lib:avma-guidelines#page=17) — drugged remains and wildlife.

## ⚰️ Caring for the dead

**Bodies don't cause epidemics** when people died of injury, fire, cold or hunger. The exceptions are
deaths from cholera, Ebola-type fevers and similar infections
([PAHO, p. 17](lib:management-of-dead-bodies#page=17)). Handlers need **waterproof gloves, an apron and
boots**, and must wash with soap before eating; masks aren't essential (p. 18; [🖼️ photo of the gear, p. 18](lib:management-of-dead-bodies#page=18)).

**Burial** ([PAHO, p. 38](lib:management-of-dead-bodies#page=38); [WHO/WEDC, p. 33](lib:who-wedc-technical-notes#page=33)):
- An **individual, marked grave 5–10 ft (1.5–3 m) deep**, **no lime or chemicals** on the body
  ([🖼️ wrapping a body for burial, WHO/WEDC p. 32](lib:who-wedc-technical-notes#page=32)).
- At least **100 ft (30 m) from springs or streams** and **650 ft (200 m) from any well**.
- At least 4 ft between the grave bottom and the water table (5 ft in sand). With our valley clay wet 2–3
  ft down in winter, choose higher, well-drained ground, and choose it now *(rule of thumb)*.
- Record who is buried where, on a map and with a durable marker.

**After a cholera death** ([MSF Cholera, pp. 47–48](lib:management-of-a-cholera#page=47)): bury **within
24 hours**, near the place of death, **more than 165 ft (50 m) from water**, under at least 3 ft of soil.
Wash hands after touching the body. **Funeral meals cooked by people who handled the body spread
cholera.** Let families keep their customs with these hygiene rules; banning funerals makes people hide
deaths (p. 48). *While laws are enforced,* ask the county about private burial.

📚 **Go deeper:** [PAHO *Management of Dead Bodies after Disasters*](lib:management-of-dead-bodies#page=17) — myths, handling and graves; [WHO/WEDC, p. 33](lib:who-wedc-technical-notes#page=33) — disposal of the dead.

## ⚠️ Old advice in the library to ignore

- **The "burn-out latrine"**, burned daily with **1 qt gasoline to 5 qt diesel**
  ([Special Forces Handbook, p. 162](lib:special-forces-medical-handbook#page=162)). It wastes fuel and
  risks burns and wildfire; the same page admits burning and lime don't stop flies or smell. Use a lidded
  pit, VIP or bucket toilet, with ash.
- **Spraying latrine pits with insecticide twice a week** (same page). Use tight lids, screened vents and ash.
- **DDT and lindane** for lice, scabies and spraying ([Rozendaal, pp. 274, 293](lib:vector-control-methods#page=274)).
  Obsolete and toxic. Use permethrin or dimeticone.
- **Tossing each day's waste bag outside** ([Kearny, p. 108](lib:nuclear-war-survival-skills-1979-original#page=108)).
  Fine for two weeks in a fallout shelter; for long-term living, bury or compost the bags.
- **Boiling laundry "with soap and kerosene"**
  ([*Household Discoveries*, p. 191](lib:household-discoveries-encyclopaedia#page=191)). Fire and fume
  hazard. Use hot soapy water and sun.
- **Concrete "at least 90 centimeters thick"** over a waste pit
  ([*A Book for Midwives*, p. 22](lib:a-book-for-midwives-05-preventing-infection#page=22)). Almost
  certainly a misprint: Hesperian says **10–30 cm** ([Ch 19, p. 22](lib:ch-19-health-care-waste#page=22)).
- **Lime on dead bodies.** PAHO says don't ([p. 38](lib:management-of-dead-bodies#page=38)). Lime *does*
  help dry and disinfect waste in compost toilets and sickroom-waste pits.
- **Latrines only 65 ft (20 m) from water** ([WTND ch. 12, p. 9](lib:where-there-is-no-doctor-12-prevention#page=9);
  [Hesperian Ch 7, p. 18](lib:building-toilets#page=18)). Sphere, the Army and Oregon use 100 ft. Use 100.
- **Burning "cleaned plastic containers"** ([Rozendaal, p. 400](lib:vector-control-methods#page=400)) or a brush
  pile's polyethylene cover ([OSU EC 1574, p. 4](lib:disposing-of-woody-material#page=4)). Oregon bans burning plastic
  ([DEQ, p. 1](lib:southern-oregon-outdoor-burning#page=1)); the smoke carries dioxins ([Hesperian Ch 18, p. 24](lib:ch-18-solid-waste#page=24)).
- **Mothballs in garbage cans** ([ODFW, p. 2](lib:living-with-black-bears-odfw#page=2)). They poison children and pets *(rule of thumb)*. Use bleach.
- **Old tires on a carcass fire "to add additional heat"** ([*Zoonoses*, p. 69](lib:zoonoses#page=69)). Oregon bans
  burning both ([DEQ, p. 1](lib:southern-oregon-outdoor-burning#page=1)). Bury the carcass.

📚 **Go deeper:** [Sphere, p. 140](lib:sphere-handbook-2018#page=140) — the 30 m rule; [MSF Clinical Guidelines, p. 133](lib:msf-clinical-guidelines#page=133) — modern scabies and lice treatment.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Toilets**
- Cat hole, straddle trench, deep pit and pail latrine — [🖼️ FM 21-10, pp. 131–135](lib:us-army-fm-21-10#page=131); [Cat hole](wiki:Cathole)
- Trench latrines for a neighborhood — [🖼️ WHO/WEDC, p. 57](lib:who-wedc-technical-notes#page=57); [🖼️ Compendium, p. 44](lib:compendium-of-sanitation#page=44)
- VIP latrine and how its vent works — [🖼️ Rozendaal, p. 163](lib:vector-control-methods#page=163); [🖼️ Hesperian Ch 7, p. 22](lib:building-toilets#page=22); [🖼️ Compendium, p. 50](lib:compendium-of-sanitation#page=50)
- Raised latrine for wet ground — [🖼️ WHO/WEDC, p. 58](lib:who-wedc-technical-notes#page=58); [🖼️ Compendium, p. 56](lib:compendium-of-sanitation#page=56)
- Twin-bucket and hose-vented bucket toilets — [🖼️ OSU, p. 2](lib:osu-extension-survival-basics-sanitation#page=2); [🖼️ Kearny, p. 108](lib:nuclear-war-survival-skills-1979-original#page=108); [Container toilet](wiki:Container-based_sanitation)
- Filling a shallow pit and planting a tree on it — [🖼️ Hesperian Ch 7, p. 26](lib:building-toilets#page=26); [🖼️ Compendium, p. 140](lib:compendium-of-sanitation#page=140); [Arborloo](wiki:Arborloo)

**Compost, urine, septic and greywater**
- Composting toilet cross-section — [🖼️ EPA, p. 4](lib:epa-composting-toilets#page=4); [Composting toilet](wiki:Composting_toilet)
- Two-chamber dry toilets — [🖼️ Hesperian Ch 7, p. 28](lib:building-toilets#page=28); [🖼️ Compendium, p. 60](lib:compendium-of-sanitation#page=60); [Humanure](wiki:Compost)
- Urine-separating seats — [🖼️ SEI, pp. 33–35](lib:ecological-sanitation#page=33); [Urine-diverting dry toilet](wiki:Urine-diverting_dry_toilet)
- Septic tank — [🖼️ Compendium, p. 68](lib:compendium-of-sanitation#page=68); [Septic tank](wiki:Septic_tank); [Drain field](wiki:Septic_drain_field)
- Greywater, soak pit, grease trap — [🖼️ DEQ, p. 15](lib:oregon-deq-reusing-graywater#page=15); [🖼️ FM 21-10, pp. 130–131](lib:us-army-fm-21-10#page=130); [🖼️ Compendium soak pit, p. 150](lib:compendium-of-sanitation#page=150); [Grease trap](wiki:Grease_trap)

**Handwashing and hygiene**
- Tippy tap — [🖼️ USAID, pp. 1–2](lib:tippy-tap#page=1); [🖼️ Hesperian Ch 5, p. 15](lib:unsafe-water#page=15); [Tippy tap](wiki:Hand_washing)
- How to wash hands — [🖼️ WHO/WEDC, p. 40](lib:who-wedc-technical-notes#page=40); [🖼️ MCPC, p. 51](lib:managing-complications-in-pregnancy#page=51); [Hand washing](wiki:Hand_washing)
- Field handwashing and shower stands — [🖼️ FM 21-10, pp. 139–140](lib:us-army-fm-21-10#page=139)
- Sewing reusable pads — [🖼️ WASHplus pattern](lib:making-reusable-menstrual-pads#page=1); [Menstrual pad](wiki:Menstrual_pad)

**Germs and outbreaks**
- The F-diagram: barriers between feces and mouths — [🖼️ WHO/WEDC, p. 39](lib:who-wedc-technical-notes#page=39); [🖼️ Hesperian Ch 5, p. 6](lib:unsafe-water#page=6); [Fecal–oral route](wiki:Fecal–oral_route)
- Mixing the rehydration drink — [🖼️ Hesperian Ch 5, p. 10](lib:unsafe-water#page=10); [Oral rehydration](wiki:Oral_rehydration_therapy)

**Flies, mosquitoes, lice, fleas, mice**
- Housefly and its life cycle — [🖼️ Rozendaal, p. 315](lib:vector-control-methods#page=315); [Housefly](wiki:Housefly)
- Tight-lidded bins and latrine lids — [🖼️ Rozendaal, p. 321](lib:vector-control-methods#page=321); [🖼️ p. 160](lib:vector-control-methods#page=160)
- Mosquito life cycle; covering water containers — [🖼️ Rozendaal, p. 22](lib:vector-control-methods#page=22); [🖼️ p. 156](lib:vector-control-methods#page=156); [Culex tarsalis](wiki:Culex_tarsalis)
- Head, body and crab lice — [🖼️ Rozendaal, pp. 266–267](lib:vector-control-methods#page=266); [Head louse](wiki:Head_louse); [Body louse](wiki:Body_louse)
- Scabies mite and burrows — [🖼️ Rozendaal, pp. 291–292](lib:vector-control-methods#page=291); [Scabies](wiki:Scabies)
- Rat, human and cat fleas — [🖼️ Rozendaal, pp. 255–256](lib:vector-control-methods#page=255); [Oriental rat flea](wiki:Oriental_rat_flea)
- Deer mice; closing gaps rats use — [Western deer mouse](wiki:Western_deer_mouse); [🖼️ USDA, pp. 17–18](lib:rat-proofing-buildings#page=17)

**Garbage, compost, bears, burning and toxics**
- Sorting waste into bins; reusing cans; gear for handling garbage — [🖼️ Hesperian Ch 18, pp. 13, 19, 21](lib:ch-18-solid-waste#page=13); [🖼️ WHO/WEDC, p. 28](lib:who-wedc-technical-notes#page=28)
- A well-built landfill and its gas vents; an always-closed can — [🖼️ Hesperian Ch 18, pp. 28–30](lib:ch-18-solid-waste#page=28); [🖼️ Rozendaal, p. 322](lib:vector-control-methods#page=322); [🖼️ USDA FB 1638, p. 6](lib:rat-proofing-buildings#page=6); [Landfill](wiki:Landfill)
- Compost piles and bins, a layered pile, worm boxes, a covered dung heap — [🖼️ WSU, pp. 3–5](lib:wsu-backyard-composting#page=3); [🖼️ Hesperian Ch 18, pp. 15–17](lib:ch-18-solid-waste#page=15); [🖼️ OSU worm bin, p. 4](lib:composting-with-worms#page=4); [🖼️ Rozendaal, p. 320](lib:vector-control-methods#page=320); [Compost](wiki:Compost)
- Electric fences against bears — [🖼️ BearWise, p. 2](lib:raising-chickens-in-bear-country-odfw#page=2); [🖼️ UF step photos, pp. 3–5](lib:building-bear-fences#page=3); [Electric fence](wiki:Electric_fence)
- Barrel incinerator; brush scattered and piled for burning — [🖼️ Special Forces Handbook, p. 165](lib:special-forces-medical-handbook#page=165); [🖼️ OSU EC 1574, pp. 2–3](lib:disposing-of-woody-material#page=2)
- Destroying toxic containers; burying pesticide leftovers — [🖼️ Hesperian Ch 18, p. 25](lib:ch-18-solid-waste#page=25); [🖼️ Rozendaal, pp. 398–399](lib:vector-control-methods#page=398)

**Waste and the dead**
- Garbage pits — [🖼️ FM 21-10, p. 129](lib:us-army-fm-21-10#page=129); [🖼️ WHO/WEDC, p. 29](lib:who-wedc-technical-notes#page=29)
- Cow with anthrax (don't open it) — [🖼️ WTNAD, p. 215](lib:where-there-is-no-animal-doctor#page=215); [Anthrax](wiki:Anthrax)
- Sharps and the sickroom-waste pit — [🖼️ Hesperian Ch 19, p. 17](lib:ch-19-health-care-waste#page=17); [🖼️ p. 22](lib:ch-19-health-care-waste#page=22); [Sharps waste](wiki:Sharps_waste)
- Gear for handling bodies; wrapping for burial — [🖼️ PAHO, p. 18](lib:management-of-dead-bodies#page=18); [🖼️ WHO/WEDC, p. 32](lib:who-wedc-technical-notes#page=32)

---

## 🔗 Related guides

- [Firewood](guide:FIREWOOD-GUIDE) — hot ash cans and safe burning
- [Chickens](guide:CHICKENS-GUIDE), [Rabbits](guide:RABBITS-GUIDE), [Goats](guide:GOATS-GUIDE), [Horses](guide:HORSE-GUIDE) and [Bees](guide:BEES-GUIDE) — manure, and electric fences against bears
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — gut piles and game care
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) and [Fuel](guide:FUEL-GUIDE) — old batteries, battery acid and old fuel
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — the twin-bucket toilet, soap, cleaners, laundry, ticks
- [Water Purification](guide:WATER-PURIFICATION-GUIDE) — making drinking water safe
- [Water Wells, Pumps, Springs & Cisterns](guide:WATER-WELLS-GUIDE) — protecting wells and springs
- [Field Care](guide:FIELD-CARE-GUIDE) — treating diarrhea and dehydration, nursing the sick
- [Childbirth & Children](guide:CHILDBIRTH-CHILDREN-GUIDE) — clean birth and diapers
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local soils, burn permits, fire season
