# 📱 Use the Library on a Phone or Tablet

Carry the most useful parts of the library on your phone, with no internet. Pick the easiest way:

| Your phone | Easiest way |
|---|---|
| **Any phone**, near a laptop or tablet running the library | Open the library **shared over Wi-Fi** in the phone's browser. Everything works, even the AI. See [Start on any device](guide:START-ON-ANY-DEVICE). |
| **Android** | Install **Kiwix** (reading) and **OsmAnd** (maps) from the drive. Steps below. |
| **iPhone / iPad** | Install **Kiwix** and **OsmAnd** from the App Store **now, while you have internet**. Steps below. |

**Android can also run the full Library Assistant** (search everything, plus the offline AI) with
the free Termux app on the drive: see [Start on any device](guide:START-ON-ANY-DEVICE).

---

## 🤖 Android

The apps are on the drive in **OfflineLibrary** → **Phone-Apps**, as app files (names ending in
**.apk**) that install with no Play Store or internet. `OsmAnd-….apk` is OsmAnd; the other `.apk`
(usually ending in `universal-standalone.apk`) is Kiwix.

### 1. Install the apps

1. Plug the drive into the phone (USB-C, or a small USB adapter) and open the phone's **Files**
   app. *No adapter?* Copy the `.apk` files over from a computer by USB cable (on the phone, tap
   the **USB** notice → **File transfer**).
2. In **Phone-Apps**, tap the Kiwix `.apk` file.
3. The first time, a box says the phone **isn't allowed to install unknown apps** from this
   source. Tap **Settings**, turn on **Allow from this source**, then tap the back arrow.
4. Tap **Install**, then **Done**. (If **Play Protect** warns you, install anyway: these are the
   free official apps.)
5. Do the same with `OsmAnd-….apk`.

### 2. Add things to read

1. Copy the `.zim` files you want to the phone (see *What fits* below).
2. Open **Kiwix**. If it asks to see your files, tap **Allow**.
3. Tap **＋** (or **Open file**) and pick a `.zim` file. It can now be searched offline. Repeat
   for each file.

PDF books open in any PDF app; the `.html` guides open in the browser.

### 3. Add the maps

1. Copy your area's map files (in the drive's **OsmAnd** folder, ending in `.obf.zip`) to the
   phone. For Oregon, that's the files starting with `Us_oregon`.
2. Open **OsmAnd** → **Menu** → **Configure map / Download maps → Import** and pick the files.

**If that didn't work:** copy the map files into the phone's
`Android/data/net.osmand.plus/files/` folder instead (easiest from a computer).

---

## 🍏 iPhone and iPad

Apple doesn't allow installing apps from a file, so the drive's app files won't work here.

1. **While you still have internet,** install **Kiwix** and **OsmAnd Maps** (both free) from the
   **App Store**.
2. Plug the drive into the iPhone with a USB adapter (newer iPhones take USB-C directly). In the
   **Files** app, copy what you want onto the iPhone. (From a computer instead: see
   [Start on any device](guide:START-ON-ANY-DEVICE).)
3. Open the `.zim` files in **Kiwix** and the maps in **OsmAnd**. If OsmAnd won't open a map
   `.zip`, tap it once in **Files** to unzip it.
4. *Optional AI:* while online, also install **PocketPal AI**. Copy
   `AI-Offline\models\Qwen2.5-1.5B-Instruct-Q4_K_M.gguf` onto the iPhone and load it in the app.
   It chats, but doesn't search the books.

---

## 📏 What fits on a phone

Copy what you need most. Good first picks: the medical encyclopedia (`Medical\WikiMed`, about
1.7 GB), the survival guides (`Manuals\Survival-Water-Food`, under 1 GB) and your area's maps
(Oregon: about 0.4 GB). All of Wikipedia with pictures (about 120 GB) is too big for most phones;
while you have internet, the Kiwix app can download the short one (`wikipedia_en_all_mini`, about
13 GB) straight to the phone.
