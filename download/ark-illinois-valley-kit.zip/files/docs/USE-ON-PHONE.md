# 📱 Use the Library on a Phone or Tablet

| Your phone | Easiest way |
|---|---|
| **Any phone** near a laptop, tablet or ARK Vault running the library | Open the library **shared over Wi-Fi** in its browser. Everything works, even the AI. See [Start on any device](guide:START-ON-ANY-DEVICE) |
| **Android** | Install **Kiwix** (reading) and **OsmAnd** (maps) from the drive. Steps below |
| **iPhone / iPad** | Install **Kiwix** and **OsmAnd** from the App Store **now, while you have internet** |

Android can also run the full library with search and AI: see
[Start on any device](guide:START-ON-ANY-DEVICE).

**Just want a map?** The library has one that works in the phone's browser, with topo lines and
property lines and no app: see [Offline maps](guide:HOW-TO-VIEW-MAPS).

---

## 🤖 Android

The two apps are on the drive in **OfflineLibrary → Phone-Apps**. No Play Store or internet needed.

### 1. Install the apps

1. Plug the drive into the phone (with a USB adapter if needed) and open the **Files** app.
2. In **Phone-Apps**, tap the **Kiwix** file (ends in `.apk`).
3. If it says the phone **isn't allowed to install unknown apps**, tap **Settings**, turn on
   **Allow from this source**, and go back.
4. Tap **Install**. (If Play Protect warns you, install anyway: these are the free official apps.)
5. Do the same with the **OsmAnd** file.

### 2. Add things to read

1. Copy the `.zim` files you want onto the phone (see *What fits* below).
2. Open **Kiwix**, tap **＋** (or **Open file**) and pick a `.zim` file.

PDF books open in any PDF app.

### 3. Add the maps

1. Copy your area's map files (in the drive's **OsmAnd** folder, ending in `.obf.zip`) to the
   phone. For Oregon, that's the files starting with `Us_oregon`.
2. Open **OsmAnd** → **Menu** → **Download maps → Import** and pick the files.

---

## 🍏 iPhone and iPad

Apple doesn't allow installing apps from a file, so get them from the App Store first.

1. **While you have internet,** install **Kiwix** and **OsmAnd Maps** (both free).
2. Plug the drive into the iPhone with a USB adapter. In the **Files** app, copy what you want onto
   the iPhone.
3. Open the `.zim` files in **Kiwix** and the maps in **OsmAnd**. (If a map won't open, tap it once
   in **Files** to unzip it.)

---

## 📏 What fits on a phone

Copy what you need most. Good first picks: the medical encyclopedia (`Medical\WikiMed`, about
1.7 GB), the survival guides (`Manuals\Survival-Water-Food`, under 1 GB) and your area's maps
(Oregon: about 0.4 GB). All of Wikipedia with pictures (about 120 GB) is too big for most phones;
while you have internet, the Kiwix app can download the short one (`wikipedia_en_all_mini`, about
13 GB) straight to the phone.
