# 🛟 Offline Emergency Kit — START HERE

This drive is a self-contained **offline survival library + AI**. Everything works with
**no internet**. This page explains what's here and how to open each part.

> ### 🔎 Find it fast — no search, AI or internet needed
> These pages work in any web browser, even if no program on the drive will start:
> - **[🆘 Emergency finder](guide:EMERGENCY-FINDER)** — something happening right now (bleeding,
>   not breathing, snakebite, a baby coming, fire, fallout…)? Straight to the right page.
>   *Print it and keep it with the first-aid kit.*
> - **[📇 Subject index A–Z](guide:SUBJECT-INDEX)** — like the index at the back of a book: look up
>   any word and jump to the exact section of the right guide, book page or drawing.
> - **[🔢 Unit converter & calculators](guide:UNIT-CONVERTER)** — convert any measurement, and work out
>   tanks, concrete, roof pitch, rainwater, water pressure, wire sizes, battery time, recipes and more.
> - **[📚 Guides by subject](#guides-by-subject)** — all 54 guides in 14 groups (below).
> - **Every file on the drive:** `README.html` (full index) and
>   `Southern-Oregon\LOCAL-FILES.html` (the local books, by subject, with a filter box).
>
> Every guide has a **📘 Guides › group · 🆘 Emergency · 📇 Index A–Z** bar at the top, a clickable
> 📑 Contents box, and **Previous / Next** links at the bottom.

> **Works on almost any device.** Start files at the top of the drive: **`START-Windows.bat`**,
> **`START-Mac.command`**, **`START-Linux.sh`** (also Raspberry Pi and Chromebooks) and
> **`START-Android.sh`** (Android tablets and phones, with the free Termux app). They open the
> **Library Assistant**, one search for everything, with an offline AI sized for that device.
> Step-by-step: **[Start the Library on Any Device](guide:START-ON-ANY-DEVICE)**. To keep a
> computer for it sealed away from an EMP: **[ARK Vault, the ammo-can library computer](guide:AMMO-CAN-COMPUTER-GUIDE)**.

> **Two things to read things on this drive:**
> - **PDFs and these guides (.html)** open in **Edge or any web browser** — no software.
> - **`.zim` archives** open in **Kiwix** (portable, no install) — see
>   `E:\Kiwix-Reader\`.
> - **AI that answers from your PDFs** = **GPT4All** — see `E:\AI-Offline\`.

---

## What's on this drive

| Folder | What it is | How to open | Guide |
|---|---|---|---|
| `AI-Offline\` | The offline AI (small and large models) | Use it through the Library Assistant (`START-Windows` / `START-Mac`), or a `CHAT-*` shortcut | `AI-Offline\HOW-TO-RUN-OFFLINE-AI.html` |
| `AI-Offline\DocReader-GPT4All\` | AI that reads your PDFs & answers questions | Install once, then offline | `...\HOW-TO-ASK-YOUR-DOCS.html` |
| `Manuals\` | Survival & repair manuals (Army FMs, iFixit, Appropedia, survival/water/food) | PDF→browser, ZIM→Kiwix | `Manuals\READ-ME-FIRST.html` |
| `Manuals\Radio-Communications\` | How ham/CB/shortwave radio works + emergency comms | Browser | `RADIO-GUIDE.html` |
| `Medical\` | Offline medical Wikipedia + first-aid books | ZIM→Kiwix, PDF→browser | `Medical\READ-ME-FIRST.html` |
| `Wikipedia\` | Full English Wikipedia **with pictures** (one big `.zim` file, ~120 GB) | Kiwix | `Kiwix-Reader\HOW-TO-USE-KIWIX.html` |
| `OsmAnd\` | Offline maps (your chosen region; default US) — view on **PC (no phone)** or phone | PC: `MapViewer-Desktop\VIEW-MAPS-ON-PC.bat`; phone: bundled APK | `OsmAnd\HOW-TO-VIEW-MAPS.html` |
| `Kiwix-Reader\` | The reader for all `.zim` archives | Portable app | `Kiwix-Reader\HOW-TO-USE-KIWIX.html` |
| `Phone-Apps\` | Android apps (Kiwix + OsmAnd) to port the library to a phone, offline | Sideload the APKs | `Phone-Apps\USE-ON-PHONE.html` |
| `Southern-Oregon\` | **Illinois Valley local pack:** topo & forest maps, hunting & fishing regulations, gardening & food preservation, wild plants, wildfire, earthquake & tsunami, local radio/weather | Browser (PDF) | `Southern-Oregon\ILLINOIS-VALLEY-START-HERE.html` |

---

## Quick start by need

- **Ask anything and get an answer from the whole library (best place to start):**
  double-click the **START** file for your device at the top of the drive (see
  [Start the Library on Any Device](guide:START-ON-ANY-DEVICE)) — one search page for every
  manual, guide and encyclopedia on the drive, with an offline AI that answers with clickable
  sources. It picks the AI size for the device automatically; change it in ⚙️ Settings.
- **I want to chat with an AI offline:** double-click **`START-Windows`** (or **`START-Mac`**) and ask
  in the search box. Plain chat with no books: `AI-Offline\` → `CHAT-3B-light`.
- **I want the AI to answer from my manuals:** set up `DocReader-GPT4All` (see its guide),
  point it at `Manuals\ArmyFieldManuals` and `Medical\Manuals-PDF`, ask away.
- **I need to fix something (car/appliance/plumbing/electrical):** open Kiwix →
  `Manuals\Repair-iFixit` and `Manuals\DIY-Appropedia`.
- **Medical / first aid:** open Kiwix → `Medical\WikiMed`; or read the PDFs in
  `Medical\Manuals-PDF`; Army first aid in `Manuals\ArmyFieldManuals`.
- **Survival / water / food:** Kiwix → `Manuals\Survival-Water-Food`; plus the Army
  survival PDFs.
- **Communicate by radio:** read `Manuals\Radio-Communications\RADIO-GUIDE.html`.
- **Look something up:** open Kiwix → `Wikipedia\wikipedia_en_all_maxi_….zim` (full Wikipedia
  with pictures) and the maps (`OsmAnd\HOW-TO-VIEW-MAPS.html` — works on a PC with no phone).
- **Local info (Illinois Valley):** `Southern-Oregon\ILLINOIS-VALLEY-START-HERE.html` — weather
  radio, local stations, contacts, evacuation levels, and links to every local map and guide.

---

## 📚 Guides by subject

Plain-English guides written for this library. Each one links to the exact book page (📖), to
drawings and diagrams in the books (🖼️) and to photos in the offline Wikipedia (📷). Every guide has a
**📘 Guides › group** bar at the top and **Previous / Next** links at the bottom, in this order. The same
groups appear in the Library Assistant's **📘 Guides** and **📚 Books** tabs.

- <a id="start"></a>**🧭 Start here:** [🆘 Emergency finder](guide:EMERGENCY-FINDER) ·
  [📇 Subject index A–Z](guide:SUBJECT-INDEX) · [Illinois Valley quick reference](guide:ILLINOIS-VALLEY-START-HERE)
- <a id="health"></a>**🩹 Health & medicine:** [Injuries with no help coming](guide:FIELD-CARE-GUIDE) ·
  [Recovering from injuries: rehab](guide:REHAB-GUIDE) ·
  [Medical books & found medicines](guide:Medical-READ-ME-FIRST) ·
  [Childbirth & small children](guide:CHILDBIRTH-CHILDREN-GUIDE) ·
  [Sanitation, waste & disease](guide:SANITATION-GUIDE)
- <a id="water"></a>**💧 Water:** [Water purification](guide:WATER-PURIFICATION-GUIDE) ·
  [Wells, pumps, springs & cisterns](guide:WATER-WELLS-GUIDE)
- <a id="food"></a>**🍞 Food:** [Food when it is scarce](guide:FOOD-SECURITY-GUIDE) ·
  [Food from scratch](guide:FOOD-FROM-SCRATCH-GUIDE) · [Preserving food](guide:PRESERVING-FOOD-GUIDE) ·
  [Root cellars & food storage](guide:ROOT-CELLAR-GUIDE) · [Milk, butter & cheese](guide:DAIRY-GUIDE) ·
  [Your seed bank](guide:SEED-BANK-GUIDE)
- <a id="wild"></a>**🌲 Living off the land:** [Hunting, trapping & fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) ·
  [Mushrooms](guide:MUSHROOM-GUIDE) · [Skills of the valley's first peoples](guide:NATIVE-SKILLS-GUIDE)
- <a id="animals"></a>**🐐 Animals:** [Chickens](guide:CHICKENS-GUIDE) · [Ducks](guide:DUCKS-GUIDE) · [Geese](guide:GEESE-GUIDE) ·
  [Turkeys](guide:TURKEYS-GUIDE) · [Rabbits](guide:RABBITS-GUIDE) · [Goats](guide:GOATS-GUIDE) · [Sheep](guide:SHEEP-GUIDE) ·
  [Pigs](guide:PIGS-GUIDE) · [Cattle](guide:CATTLE-GUIDE) · [Horses, mules & draft animals](guide:HORSE-GUIDE) ·
  [Bees](guide:BEES-GUIDE) · [Dogs](guide:DOGS-GUIDE)
- <a id="shelter"></a>**🏠 Shelter & building:** [Shelter & building](guide:SHELTER-BUILDING-GUIDE) ·
  [Natural building](guide:NATURAL-BUILDING-GUIDE) · [Mortar, concrete & roads](guide:MASONRY-ROADS-GUIDE)
- <a id="power"></a>**💡 Heat, light & power:** [Firewood](guide:FIREWOOD-GUIDE) · [Fuel](guide:FUEL-GUIDE) ·
  [Off-grid power](guide:OFF-GRID-POWER-GUIDE) · [Storing energy without batteries](guide:STORING-ENERGY-GUIDE) ·
  [Heat into work & power](guide:HEAT-INTO-POWER-GUIDE) ·
  [Candles, lamps & lamp oil](guide:LIGHTING-GUIDE) · [Engines, motors & generators](guide:ENGINES-AND-MOTORS-GUIDE)
- <a id="making"></a>**🛠️ Making & repair:** [Practical math & measuring](guide:PRACTICAL-MATH-GUIDE) ·
  [Make-do household](guide:MAKE-DO-HOUSEHOLD-GUIDE) · [Blacksmithing & hand tools](guide:BLACKSMITHING-GUIDE) ·
  [Clothing, leather & shoes](guide:CLOTHING-LEATHER-GUIDE) · [Paper, ink & toilet paper](guide:PAPER-INK-GUIDE)
- <a id="travel"></a>**🥾 Getting around:** [On foot: backpacking & travel](guide:ON-FOOT-GUIDE) · [Bicycles & carts](guide:BICYCLES-CARTS-GUIDE) ·
  [Navigation & weather](guide:NAVIGATION-WEATHER-GUIDE)
- <a id="comms"></a>**📡 Radio, community & protection:** [Emergency radio](guide:RADIO-GUIDE) ·
  [Signals & Morse code](guide:SIGNALS-MORSE-GUIDE) · [Community & barter](guide:COMMUNITY-BARTER-GUIDE) ·
  [Home & property protection](guide:HOME-DEFENSE-GUIDE)
- <a id="disaster"></a>**🚨 Disasters:** [What to expect: scenarios & timelines](guide:WHAT-TO-EXPECT-GUIDE) ·
  [Wildfire with no fire department](guide:WILDFIRE-GUIDE) · [Nuclear fallout](guide:NUCLEAR-FALLOUT-GUIDE) · [EMP, solar storms & Faraday cages](guide:EMP-GUIDE)
- <a id="fun"></a>**📖 Stories & fun:** [Stories, games & fun for long evenings](guide:STORIES-GAMES-GUIDE)
- <a id="library"></a>**💾 Using this library:** [Start the library on any device](guide:START-ON-ANY-DEVICE) ·
  [ARK Vault (ammo-can computer)](guide:AMMO-CAN-COMPUTER-GUIDE) · [Get the whole library](guide:GET-THE-LIBRARY) ·
  [The offline AI](guide:HOW-TO-RUN-OFFLINE-AI) · [Ask the AI about your own PDFs](guide:HOW-TO-ASK-YOUR-DOCS) ·
  [Wikipedia and Kiwix](guide:HOW-TO-USE-KIWIX) · [Offline maps](guide:HOW-TO-VIEW-MAPS) ·
  [The library on a phone](guide:USE-ON-PHONE) · [The manuals folder](guide:Manuals-READ-ME-FIRST)
- <a id="kit"></a>**🧮 Tools:** [Calculator](guide:CALCULATOR) · [Unit converter & calculators](guide:UNIT-CONVERTER) —
  plus the pill identifier (`Medical\Pill-Identifier\PILL-IDENTIFIER.html`) and walking routes
  (`Southern-Oregon\Walking-Routes\WALKING-ROUTES.html`).

---

## Dependencies — kept to a minimum

| Content | Needs | Bundled here? |
|---|---|---|
| PDFs & `.html` guides | A web browser (Edge is on Windows) | n/a — already on Windows |
| `.zim` archives | **Kiwix** (portable, no install) | ✅ `E:\Kiwix-Reader\app` |
| Offline AI chat | Nothing extra (self-contained engine) | ✅ `E:\AI-Offline\engine` |
| AI doc-Q&A | **GPT4All** (one-time install; self-contained, CPU) | ✅ installer in `DocReader-GPT4All` |
| Maps on a computer | Bundled desktop viewer + portable Java (no phone needed) | ✅ `OsmAnd\MapViewer-Desktop` |
| Maps on Android | Bundled **OsmAnd~ APK** (sideload offline) | ✅ `OsmAnd\PhoneApp-Android` |
| Maps on iPhone/iPad | OsmAnd from the App Store | app store (get while online) |

Everything that needs a one-time online step (GPT4All's first run, phone apps) should be
set up **now, while you still have internet**, so the kit is fully usable offline later.

---

## ⚠️ Reminders

- Offline AIs and old manuals **can be wrong**. Verify anything safety-critical.
- Keep the drive **backed up** (a second copy on another drive/USB is wise).
- **Practice** using each tool now so it's familiar in an actual emergency.
