# 🛟 Offline Emergency Kit — START HERE

This drive is an **offline survival library with an AI**. Everything works with **no internet**.

> ### 🔎 Find it fast
> These pages open in any web browser:
> - **[🆘 Emergency finder](guide:EMERGENCY-FINDER)** — something happening right now (bleeding,
>   not breathing, fire, fallout…)? Go straight to the right page. *Print it and keep it with the
>   first-aid kit.*
> - **[📇 Subject index A–Z](guide:SUBJECT-INDEX)** — look up any word, like the index at the back
>   of a book.
> - **[🔢 Unit converter & calculators](guide:UNIT-CONVERTER)** — measurements, tanks, concrete,
>   wire sizes, recipes and more.
> - **[📚 Guides by subject](#guides-by-subject)** — all 54 guides in 14 groups (below).
> - **Every file on the drive:** `README.html`, and the local books by subject in
>   `Southern-Oregon\LOCAL-FILES.html`.

> ### 🔍 Search everything, and ask the AI
> Double-click the **START** file for your device: **`START-Windows`**, **`START-Mac`**,
> **`START-Linux.sh`** or **`START-Android.sh`**. One search box finds anything on the drive, and an
> offline AI writes an answer with links to the pages. See
> **[Start the Library on Any Device](guide:START-ON-ANY-DEVICE)**.

---

## What's on this drive

| Folder | What it is | Guide |
|---|---|---|
| `AI-Offline\` | The offline AI | [The offline AI](guide:HOW-TO-RUN-OFFLINE-AI) |
| `Manuals\` | Survival and repair manuals | [The manuals folder](guide:Manuals-READ-ME-FIRST) |
| `Medical\` | Medical encyclopedia and first-aid books | [Medical books](guide:Medical-READ-ME-FIRST) |
| `Wikipedia\` | All of English Wikipedia | [Wikipedia and Kiwix](guide:HOW-TO-USE-KIWIX) |
| `Map\` | A map for any web browser: roads, topo lines, property lines | [Offline maps](guide:HOW-TO-VIEW-MAPS) |
| `OsmAnd\` | Bigger offline maps, for the OsmAnd phone app or a computer | [Offline maps](guide:HOW-TO-VIEW-MAPS) |
| `Kiwix-Reader\` | The app that opens Wikipedia and the encyclopedias | [Wikipedia and Kiwix](guide:HOW-TO-USE-KIWIX) |
| `Phone-Apps\` | Apps to put the library on an Android phone | [The library on a phone](guide:USE-ON-PHONE) |
| `Southern-Oregon\` | **Illinois Valley local pack:** topo & forest maps, hunting & fishing regulations, gardening & food preservation, wild plants, wildfire, earthquake & tsunami, local radio/weather | [Illinois Valley quick reference](guide:ILLINOIS-VALLEY-START-HERE) |

**PDF books and these guides** open in any web browser. **Wikipedia and the other encyclopedias**
(`.zim` files) open in the Library Assistant or the Kiwix app.

---

## 📚 Guides by subject

Plain-English guides written for this library. Each one links to the exact book page (📖), to
drawings and diagrams in the books (🖼️) and to photos in the offline Wikipedia (📷). Every guide has a
**📘 Guides › group** bar at the top and **Previous / Next** links at the bottom, in this order. The same
groups appear in the library's **Library** screen, under **Guides** and under **Books**.

- <a id="start"></a>**🧭 Start here:** [🆘 Emergency finder](guide:EMERGENCY-FINDER) ·
  [📇 Subject index A–Z](guide:SUBJECT-INDEX) · [Illinois Valley quick reference](guide:ILLINOIS-VALLEY-START-HERE)
- <a id="health"></a>**🩹 Health & medicine:** [Injuries with no help coming](guide:FIELD-CARE-GUIDE) ·
  [Recovering from injuries: rehab](guide:REHAB-GUIDE) ·
  [Medical books & found medicines](guide:Medical-READ-ME-FIRST) ·
  [Childbirth & small children](guide:CHILDBIRTH-CHILDREN-GUIDE) ·
  [Sanitation, waste & disease](guide:SANITATION-GUIDE)
- <a id="water"></a>**💧 Water:** [Water purification](guide:WATER-PURIFICATION-GUIDE) ·
  [Wells, pumps, springs & cisterns](guide:WATER-WELLS-GUIDE)
- <a id="food"></a>**🍞 Food:** [Food when it is scarce](guide:FOOD-SECURITY-GUIDE) ·
  [Food from scratch](guide:FOOD-FROM-SCRATCH-GUIDE) · [Preserving food](guide:PRESERVING-FOOD-GUIDE) ·
  [Root cellars & food storage](guide:ROOT-CELLAR-GUIDE) · [Milk, butter & cheese](guide:DAIRY-GUIDE) ·
  [Your seed bank](guide:SEED-BANK-GUIDE)
- <a id="wild"></a>**🌲 Living off the land:** [Hunting, trapping & fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) ·
  [Mushrooms](guide:MUSHROOM-GUIDE) · [Skills of the valley's first peoples](guide:NATIVE-SKILLS-GUIDE)
- <a id="animals"></a>**🐐 Animals:** [Chickens](guide:CHICKENS-GUIDE) · [Ducks](guide:DUCKS-GUIDE) · [Geese](guide:GEESE-GUIDE) ·
  [Turkeys](guide:TURKEYS-GUIDE) · [Rabbits](guide:RABBITS-GUIDE) · [Goats](guide:GOATS-GUIDE) · [Sheep](guide:SHEEP-GUIDE) ·
  [Pigs](guide:PIGS-GUIDE) · [Cattle](guide:CATTLE-GUIDE) · [Horses, mules & draft animals](guide:HORSE-GUIDE) ·
  [Bees](guide:BEES-GUIDE) · [Dogs](guide:DOGS-GUIDE)
- <a id="shelter"></a>**🏠 Shelter & building:** [Shelter & building](guide:SHELTER-BUILDING-GUIDE) ·
  [Natural building](guide:NATURAL-BUILDING-GUIDE) · [Mortar, concrete & roads](guide:MASONRY-ROADS-GUIDE)
- <a id="power"></a>**💡 Heat, light & power:** [Firewood](guide:FIREWOOD-GUIDE) · [Fuel](guide:FUEL-GUIDE) ·
  [Off-grid power](guide:OFF-GRID-POWER-GUIDE) · [Storing energy without batteries](guide:STORING-ENERGY-GUIDE) ·
  [Heat into work & power](guide:HEAT-INTO-POWER-GUIDE) ·
  [Candles, lamps & lamp oil](guide:LIGHTING-GUIDE) · [Engines, motors & generators](guide:ENGINES-AND-MOTORS-GUIDE)
- <a id="making"></a>**🛠️ Making & repair:** [Practical math & measuring](guide:PRACTICAL-MATH-GUIDE) ·
  [Make-do household](guide:MAKE-DO-HOUSEHOLD-GUIDE) · [Blacksmithing & hand tools](guide:BLACKSMITHING-GUIDE) ·
  [Clothing, leather & shoes](guide:CLOTHING-LEATHER-GUIDE) · [Paper, ink & toilet paper](guide:PAPER-INK-GUIDE)
- <a id="travel"></a>**🥾 Getting around:** [On foot: backpacking & travel](guide:ON-FOOT-GUIDE) · [Bicycles & carts](guide:BICYCLES-CARTS-GUIDE) ·
  [Navigation & weather](guide:NAVIGATION-WEATHER-GUIDE)
- <a id="comms"></a>**📡 Radio, community & protection:** [Emergency radio](guide:RADIO-GUIDE) ·
  [Signals & Morse code](guide:SIGNALS-MORSE-GUIDE) · [Community & barter](guide:COMMUNITY-BARTER-GUIDE) ·
  [Home & property protection](guide:HOME-DEFENSE-GUIDE)
- <a id="disaster"></a>**🚨 Disasters:** [What to expect: scenarios & timelines](guide:WHAT-TO-EXPECT-GUIDE) ·
  [Wildfire with no fire department](guide:WILDFIRE-GUIDE) · [Nuclear fallout](guide:NUCLEAR-FALLOUT-GUIDE) · [EMP, solar storms & Faraday cages](guide:EMP-GUIDE)
- <a id="fun"></a>**📖 Stories & fun:** [Stories, games & fun for long evenings](guide:STORIES-GAMES-GUIDE)
- <a id="library"></a>**💾 Using this library:** [Start the library on any device](guide:START-ON-ANY-DEVICE) ·
  [ARK Vault (ammo-can computer)](guide:AMMO-CAN-COMPUTER-GUIDE) · [Get the whole library](guide:GET-THE-LIBRARY) ·
  [The offline AI](guide:HOW-TO-RUN-OFFLINE-AI) · [Ask the AI about your own PDFs](guide:HOW-TO-ASK-YOUR-DOCS) ·
  [Wikipedia and Kiwix](guide:HOW-TO-USE-KIWIX) · [Offline maps](guide:HOW-TO-VIEW-MAPS) ·
  [The library on a phone](guide:USE-ON-PHONE) · [The manuals folder](guide:Manuals-READ-ME-FIRST)
- <a id="kit"></a>**🔧 Tools:** [Calculator](guide:CALCULATOR) · [Unit converter & calculators](guide:UNIT-CONVERTER) —
  plus the pill identifier (`Medical\Pill-Identifier\PILL-IDENTIFIER.html`) and walking routes
  (`Southern-Oregon\Walking-Routes\WALKING-ROUTES.html`).

---

## ⏰ Do these now, while you have internet

- **Phones:** install the free **Kiwix** and **OsmAnd** apps (iPhones can only get them from the
  App Store). See [The library on a phone](guide:USE-ON-PHONE).
- **GPT4All** (optional): its first setup needs the internet once. See
  [Ask the AI about your own PDFs](guide:HOW-TO-ASK-YOUR-DOCS).
- **Try everything once** with the Wi-Fi off, so you know it works.

---

## ⚠️ Reminders

- Offline AIs and old manuals **can be wrong**. Verify anything safety-critical.
- Keep the drive **backed up** (a second copy on another drive/USB is wise).
- **Practice** using each tool now so it's familiar in an actual emergency.
