# 🤝 Community, Barter & Keeping Watch

How neighbors look after each other when no government, police or stores are coming: forming a
neighborhood group, running meetings and making fair decisions, knowing who has what skills and
tools, sharing work, trading fairly and keeping records, keeping watch, calming angry people,
settling disputes and theft without violence, and looking after people's minds through grief and
long hard months. The books are in `Southern-Oregon\Community-Barter\` (`Organizing-Neighbors`,
`Barter-Trade`, `Watch-Conflict`, `Wellbeing`); the *Map Your Neighborhood* plan and its OK/HELP
card are in `Southern-Oregon\Comms-Signals\Messaging-Plans`.

> ### ⚠️ Rules that keep a group safe, fair and together
> - **Rescuer safety comes first, and nobody goes alone** — always teams of at least two. In the 1985
>   Mexico City earthquake untrained volunteers saved 700 lives, but about 100 of them died
>   ([CERT manual, pp. 2, 58](lib:cert-basic-training#page=2)).
> - **Watchers watch and report. They don't confront, chase or carry weapons on patrol**
>   ([Neighborhood Watch Manual, p. 20](lib:neighborhood-watch-manual#page=20)).
> - **No punishment by force.** Physical force is "never recommended" except to stop an injury
>   ([De-escalation slides, p. 4](lib:using-verbal-de-escalation#page=4)). Beatings and armed posses
>   are crimes and start feuds that outlast the emergency *(rule of thumb)*.
> - **Help is voluntary.** Pool work by agreement — never force people to work (a 1918 booklet on the
>   drive says otherwise; see *Old advice* at the end).
> - **Never announce who is away or what the group has stored**
>   ([Watch Manual, p. 21](lib:neighborhood-watch-manual#page=21)).
> - **Write it down** — trades, stores and incidents
>   ([Braun, p. 19](lib:barter-associations-in-california#page=19);
>   [De-escalation, p. 23](lib:using-verbal-de-escalation#page=23)).

---

## 🏘️ Forming a neighborhood group

**Keep it small.** *Map Your Neighborhood* (MYN) uses **15–25 homes**, ideally ones within sight of
each other — any more can't all be checked in the "golden 60 minutes" after a disaster. In the
country, include **as many homes as you can check in an hour or two**
([MYN, pp. 3, 19](lib:map-your-neighborhood-discussion-guide#page=19)).

**Invite people in person** (a flyer on the porch doesn't bring them out), ask one or two neighbors
to help, and **meet in someone's home** — attendance drops at a school or church
([p. 19](lib:map-your-neighborhood-discussion-guide#page=19)).

**The 9 steps after a disaster** ([MYN, pp. 14–16](lib:map-your-neighborhood-discussion-guide#page=14);
rural changes from [MYN Rural, p. 3](lib:map-your-neighborhood-in-rural#page=3)):

| Step | At home first (1–6), then together (7–9) |
|---|---|
| 1 | Care for your own family. |
| 2 | Protect head, hands and feet: hard hat or bike helmet, sturdy shoes, leather gloves — **kept under the bed** ([p. 6](lib:map-your-neighborhood-discussion-guide#page=6)). |
| 3 | Smell or hear gas? **Shut off the propane** ([MYN, p. 22](lib:map-your-neighborhood-discussion-guide#page=22); [Propane](wiki:Propane)). Propane is heavier than air and settles in low spots. |
| 4 | Shut the house water valve ([🖼️ what it may look like](lib:map-your-neighborhood-discussion-guide#page=23)). On a well, this keeps the water heater and pipes from draining back out. |
| 5 | Post your **OK/HELP card** where it can be seen ([card](lib:help-ok-window-card)). |
| 6 | Town: put the [fire extinguisher](wiki:Fire_extinguisher) ([🖼️ how to use one](lib:cert-basic-training#page=172)) at the road edge. Rural: homes are too far apart — keep it at home. |
| 7 | Go to the **gathering site**. |
| 8 | Form **four teams of at least two**: one listens to the radio; one checks the neighbors flagged as needing help; one checks every propane tank and gas meter on the map; one goes door to door, **starting with HELP cards and homes with no card**. |
| 9 | Every team **reports back** so everyone knows what's done. |

![P.A.S.S. for a fire extinguisher in four small drawings: pull the pin, aim the nozzle, squeeze the handle, sweep the spray](img:COMMUNITY-BARTER-GUIDE/fire-extinguisher-pass.png)
*Using the extinguisher: pull the pin, aim at the base of the fire, squeeze the handle, sweep side to side ([CERT, p. 172](lib:cert-basic-training#page=172)).*

**Rural communication site:** pick a known, central spot — a **mailbox cluster, a crossroads, or a
home or barn near the middle.** Each household tapes its OK/HELP card there with name, date and time.
Anyone who can help writes what they'll do and when, then reports back
([MYN Rural, pp. 1–2](lib:map-your-neighborhood-in-rural#page=1)).

**Organize like a CERT team** ([CERT, pp. 58, 61](lib:cert-basic-training#page=58); [🖼️ organization chart](lib:cert-basic-training#page=37)):
- **One leader for about 5 people** (2 to 7 works). **Everyone takes direction from exactly one
  person.**
- Everyone has a **buddy**. Field teams of 1–5, with **one runner** carrying messages to the command
  post.
- Search teams need **at least 4**, with a safety team left outside ([🖼️ lifting, cribbing and carries](lib:cert-basic-training#page=210)).
[Community Emergency Response Team](wiki:Community_emergency_response_team).

📚 **Go deeper:** [MYN *Discussion Guide*](lib:map-your-neighborhood-discussion-guide#page=3) — a script for the 90-minute first meeting; [MYN *Rural Settings*](lib:map-your-neighborhood-in-rural#page=1) — wells, propane and the mailbox site; [FEMA *CERT Basic Training*](lib:cert-basic-training#page=58) — teams, fire, light search and rescue, disaster medicine.

## 🗳️ Meetings and fair decisions

**Small group:** "friendly, serious, courteous discussion is preferable to formal parliamentary
procedure" ([Braun 1933, p. 13](lib:barter-associations-in-california#page=13)).

**A bigger meeting** ([*Robert's Rules*, 1915, pp. 281–282, 291](lib:roberts-rules-of-order#page=281)):
- The organizers agree beforehand on the **place, time, who calls the meeting to order and who will
  be nominated chair.**
- Elect the chair by **majority voice vote**, then a **secretary** to keep minutes.

**Simple rules of order** ([*Robert's Rules*, pp. 32, 286](lib:roberts-rules-of-order#page=32)):
1. A member **proposes** something ("I move that…").
2. Someone else **seconds** it — otherwise it isn't discussed.
3. The chair **repeats it** so everyone knows exactly what's being decided.
4. **Discussion.** One speaker at a time; everyone who wants to speak gets a turn before anyone
   speaks twice *(rule of thumb)*.
5. The chair asks **"Are you ready for the question?"** and takes the vote.
6. The secretary **writes down** the decision.

**Before founding anything permanent**, make sure a majority agrees with the plan — groups that
skipped this "have found themselves in the minority" ([p. 290](lib:roberts-rules-of-order#page=290)).

**Choosing what to do first:** list the problems and rank them, then rank again asking **"Which can
we do with our own resources?"** and **"Which will benefit the most people?"**
([Peace Corps PACA, p. 116](lib:paca-using-participatory#page=116)).
[Robert's Rules of Order](wiki:Robert's_Rules_of_Order).

📚 **Go deeper:** [*Robert's Rules of Order* (1915)](lib:roberts-rules-of-order#page=281) — Part II: calling a mass meeting and founding a society; [Peace Corps PACA](lib:paca-using-participatory#page=116) — tools for a whole community to choose priorities.

## 📋 Skills, tools and the neighborhood map

**Skills and equipment inventory** ([MYN, p. 11](lib:map-your-neighborhood-discussion-guide#page=11)):
go down a list and write **who can do what** and who has what ([🖼️ a blank inventory form](lib:cert-basic-training#page=77)). **Every household keeps its own copy**,
in case it's the only one home. Oregon's own quake guide says the same
([*Living on Shaky Ground*, p. 14](lib:living-on-shaky-ground#page=14)).

| Skills to ask about *(examples)* | Tools to ask about *(examples)* |
|---|---|
| First aid, nursing, childbirth, child and elder care | Chainsaws, crosscut saws, axes, wedges |
| Carpentry, plumbing, wells and pumps, wiring | Generators, solar panels, batteries |
| Mechanics, small engines, welding, blacksmithing | Ham, GMRS and FRS radios |
| Gardening, livestock, butchering, canning | Pressure canners, grain mills, carts, trailers |
| Hunting, fishing, foraging, tanning | Water tanks, hand pumps, filters |
| Teaching, counseling, mediation, record-keeping | Tractors, horses, harness |

**Contact list and map** ([MYN, pp. 12–13](lib:map-your-neighborhood-discussion-guide#page=12)):
number each house on the map and write down who lives there. **Mark who will need extra help** —
older people, people with disabilities, children who may be home alone. It's **kept confidential**,
and anyone may decline to share. Pick a **Neighborhood Care Center** for frightened or frail
neighbors — a house with few steps ([p. 10](lib:map-your-neighborhood-discussion-guide#page=10)).
No paper? Draw the map with sticks and stones in the dirt
([PACA, p. 88](lib:paca-using-participatory#page=88); [🖼️ a sample community map](lib:paca-using-participatory#page=38)).

**Seasonal calendar:** chart when work peaks, when food runs short (the "hungry season") and when
people are free ([PACA, p. 105](lib:paca-using-participatory#page=105); [🖼️ an example](lib:paca-using-participatory#page=41)). In the Valley: wet winters
November–March, fire and smoke season roughly June–October (the state sets the dates each year), harvest August–October *(general practice)*.

📚 **Go deeper:** [MYN *Discussion Guide*, p. 11](lib:map-your-neighborhood-discussion-guide#page=11) — running the inventory, contact list and map; [Peace Corps PACA](lib:paca-using-participatory#page=88) — community maps, seasonal calendars, daily schedules.

## 🤲 Sharing the work

- **Give everyone a job.** People are less frightened when they have responsible jobs. Set a daily
  routine, post the assignments, and **rotate the unpleasant tasks**
  ([FEMA HS-4, p. 97](lib:preparedness-planning-for-a-nuclear-crisis#page=97)). A useful job (sorting
  supplies) also calms a disruptive person ([CERT, p. 152](lib:cert-basic-training#page=152)).
- **Pool teams and machines.** Three small farms that work together can each finish haying in two or
  three days instead of the whole season, then help the big farm
  ([USDA Circular 112, p. 7](lib:farm-labor-problem#page=7)). [Barn raising](wiki:Barn_raising).
- **A labor committee** lists everyone with farm (or other) experience who volunteers, and sends them
  where they're needed at rush times ([p. 9](lib:farm-labor-problem#page=9)).
- **People new to hard work** should do light work, a few hours a day, for the first days
  ([p. 10](lib:farm-labor-problem#page=10)).
- **Credit the hours** in the group's points ledger (next section), so work counts as much as goods.

📚 **Go deeper:** [USDA *The Farm Labor Problem* (1918)](lib:farm-labor-problem#page=7) — pooling crews for planting and haying (use its methods, not its 1918 coercion); [FEMA HS-4](lib:preparedness-planning-for-a-nuclear-crisis#page=97) — daily routine and duty rosters in a shelter.

## 🔄 Barter and fair trade

**What trades well** ([Barter](wiki:Barter)): a good that **many people need, that lasts, is cheap to store, divides into
small amounts and is easy to carry** ([Menger 1892, pp. 30–31](lib:origins-of-money#page=30)). Such
goods naturally become money ([p. 36](lib:origins-of-money#page=36); [Commodity money](wiki:Commodity_money)). Plain barter fails when A wants
what B has, B wants what C has, and C wants what A has ([p. 21](lib:origins-of-money#page=21)).
[Coincidence of wants](wiki:Coincidence_of_wants).
- **Likely trade goods here:** salt, sugar, coffee, soap, matches and lighters, seeds, canning lids,
  batteries, fuel, firewood — and skills: sewing, repair, medical care *(general practice)*.
- **Don't trade prescription drugs casually** *(general practice)* — fakes and wrong doses kill (see
  the [Medical guide](guide:Medical-READ-ME-FIRST)).

**Setting up a barter group** ([Braun 1933, pp. 13–15](lib:barter-associations-in-california#page=13)):
a few people first survey what the community needs and has to trade; present it at a meeting; elect a
**steering committee**; choose a **trading place**; write a **membership agreement**. **Start small,
"with people you know."** Members meet weekly on practical trading business only — don't leave
everything to one manager.

**The trader** should be trustworthy, "a natural trader but not a sharp, hard bargain driver," and
should arrange **three-way trades**: A has potatoes and wants oranges, B has oranges and wants beans,
C has beans and wants potatoes ([p. 15](lib:barter-associations-in-california#page=15)).

![Three households in a ring: A has potatoes and wants oranges, B has oranges and wants beans, C has beans and wants potatoes; potatoes go from A to C, beans from C to B, oranges from B to A](img:COMMUNITY-BARTER-GUIDE/three-way-trade.svg)
*Braun's three-way trade: no two of them can swap directly, but passed round the ring each gets what they want (a diagram drawn for this guide).*

**Fair exchange — the points ledger** ([p. 19](lib:barter-associations-in-california#page=19)):
- **1 hour of work = 100 points**; an 8-hour day = 800. Value goods in work: **a [cord](wiki:Cord_(unit)) of wood = one
  day's work = 800 points** ([🖼️ what a cord looks like](lib:osu-extension-home-heating-fuels-firewood-vs-pellets-ec1628#page=1)).
- Record every credit and debit in the **member's passbook and in a central book**, and balance them
  regularly like a bank account. **Losses from spoilage are shared by all members.**

| Date | Member | What | + points | − points | Balance |
|---|---|---|---|---|---|
| Mar 3 | House 4 | 4 hours splitting wood for House 9 | 400 | | 400 |
| Mar 5 | House 4 | Squash and potatoes from the trading post | | 150 | 250 |

*(Example only.)*

**Rules that kept barter groups healthy** ([pp. 17, 21](lib:barter-associations-in-california#page=17)):
put off paper [scrip](wiki:Scrip) as long as possible; **refuse junk**; admit new members fully only after they show
they cooperate; and nobody can take more from the group than they put in.

**Shared credit and local notes** ([Cleveland Fed, pp. 1–3](lib:private-money-local-currencies#page=1)):
[Ithaca Hours](wiki:Ithaca_Hours) were pegged to **one hour of local labor**. In a LETS shared-credit system everyone starts
at zero and all balances add up to zero — so **cap how far into debt any account can go**. Any currency
is "only as good as its spendability." [LETS](wiki:Local_exchange_trading_system),
[Time-based currency](wiki:Time-based_currency).

**Avoiding disputes** *(rule of thumb)*: agree on amount ([scales](wiki:Weighing_scale)) and quality before anything changes hands;
have a witness for big trades; enter it in both books the same day; bring complaints to the weekly
meeting, not to the street.

📚 **Go deeper:** [Braun *Barter Associations in California* (1933)](lib:barter-associations-in-california#page=13) — a whole Depression-era barter group in question-and-answer form; [Cleveland Fed *Private Money*](lib:private-money-local-currencies#page=1) — labor-hour notes and LETS in four pages; [Menger *On the Origins of Money*](lib:origins-of-money#page=30) — why some goods become money.

## 👀 Keeping watch

**Structure** ([Watch Manual, pp. 10–11](lib:neighborhood-watch-manual#page=10)):
- **One block captain per 10–15 houses.**
- A **phone tree**: call the next person, skip down if they're out, and the last person calls the
  captain to confirm. With phones down it becomes a **runner chain** *(general practice)*. Practice it,
  and use it to stop rumors you've checked.
- **Daily check-in:** OK/HELP cards at the communication site
  ([MYN Rural, p. 2](lib:map-your-neighborhood-in-rural#page=2)), or the radio check-ins on the
  [Illinois Valley page](guide:ILLINOIS-VALLEY-START-HERE).

![A phone tree drawn as a ring: the captain calls House 1, each house calls the next, House 3 is out so House 2 skips to House 4, and House 5 calls the captain back to confirm](img:COMMUNITY-BARTER-GUIDE/phone-tree.svg)
*Each house calls the next, skips anyone who's out, and the last one calls the captain to confirm (a diagram drawn for this guide).*

**Patrol rules** ([p. 20](lib:neighborhood-watch-manual#page=20)): watch members "do not possess
police powers and they shall not carry weapons or pursue." They "should never confront suspicious
persons." Carry **flashlights and radios that report to a staffed base.** Walk in pairs, observe,
report — don't intervene *(general practice)*.

**Describing what you saw** ([p. 24](lib:neighborhood-watch-manual#page=24)): note what **can't be
changed** — height, build, skin and eye color, scars, tattoos. Clothes can change. Write it down at
once, even on your hand. **Never hesitate to say "I'm not sure."**

**Night watch:** keep watch-standers on a **consistent schedule** rather than switching shifts, and
**protect their daytime sleep** — sentry duty is among the jobs most damaged by sleepiness
([Ship's Medicine Chest, p. 154](lib:ships-medicine-chest#page=154)). Use **2-hour shifts in pairs**
with a fixed handover, and in fire season **watch for smoke and glow** too *(general practice)*.

| Shift *(example)* | Post | Pair | Handover |
|---|---|---|---|
| 8–10 pm | Gathering site, radio on | Houses 2 + 5 | Anything seen; who's out late |
| 10 pm–12 am | Road junction | Houses 7 + 11 | Smoke or glow? Radio check |
| 12–2 am / 2–4 am / 4–6 am | Same posts | Fixed pairs, same nights each week | Write in the log |

[Neighborhood watch](wiki:Neighborhood_watch).

📚 **Go deeper:** [*Neighborhood Watch Manual*](lib:neighborhood-watch-manual#page=10) — starting a watch, block captains, observing and reporting; [Ship's Medicine Chest, p. 154](lib:ships-medicine-chest#page=154) — sleep and night watches.

## 🗣️ Calming an angry person

From the Kentucky de-escalation slides ([pp. 15–24](lib:using-verbal-de-escalation#page=15)):
- **Distance:** slightly more than a leg's length, **at an angle and off to the side**
  ([p. 17](lib:using-verbal-de-escalation#page=17)) — far enough that you can't be hit or kicked.
  **Hands visible. Never touch a hostile person** ([p. 15](lib:using-verbal-de-escalation#page=15)).
  No face-to-face, toe-to-toe or finger-pointing ([p. 16](lib:using-verbal-de-escalation#page=16)).
- **Voice:** slow and calm ([p. 19](lib:using-verbal-de-escalation#page=19)). Listen — really listen
  ([p. 21](lib:using-verbal-de-escalation#page=21)).
- **Move onlookers away** — they become "cheerleaders" or victims. Send one for help. **Two calm people
  with one angry person** lowers the chance of violence (same page).
- **Never** say "I know how you feel," get into power struggles, raise your voice, threaten, or give
  ultimatums ([p. 24](lib:using-verbal-de-escalation#page=24)).
- **Afterwards, write down every threatening incident** ([p. 23](lib:using-verbal-de-escalation#page=23)).

![Two views from above: standing face to face and within reach of an angry person (marked not like this), and standing a bit more than a leg's length away, off to the side at an angle, with a second calm person nearby](img:COMMUNITY-BARTER-GUIDE/where-to-stand-with-an-angry-person.svg)
*A bit more than a leg's length away, off to the side and at an angle, hands in view, with a second calm person nearby (a diagram drawn for this guide).*

📚 **Go deeper:** [*Using Verbal De-Escalation*](lib:using-verbal-de-escalation#page=15) — 25 plain slides on stance, voice and what not to say; [CERT, p. 152](lib:cert-basic-training#page=152) — giving a disruptive person a useful job; [*Conflict Resolution Education Guide*, p. 31](lib:conflict-resolution-education-guide#page=31) — rules for fighting fair.

## ⚖️ Settling disputes and dealing with theft

**Where conflict comes from:** limited resources, unmet needs, or different values. Values don't have
to change — first admit each side sees it differently
([Conflict Resolution Guide, pp. 22–23](lib:conflict-resolution-education-guide#page=22)). Giving in
("soft") or threats ("hard") don't last; only **"principled"** responses tend to make agreements that
hold ([pp. 23–24](lib:conflict-resolution-education-guide#page=23)).

**Four principles:** separate the people from the problem; focus on **interests, not positions**;
invent options that help both; use fair, outside standards. **Six steps:** set the stage, hear each
side, find the interests, list options, judge the options, agree
([pp. 24, 26](lib:conflict-resolution-education-guide#page=26)). **Fight fair:** attack the problem,
not the person; no put-downs; don't drag up the past ([p. 31](lib:conflict-resolution-education-guide#page=31)).

**Mediation** ([FAO, p. 27](lib:negotiation-and-mediation-techniques#page=27)): a **mediator** helps
both sides design their own solution; an **arbitrator** decides for them. To find interests, keep
asking **"Why is this important for you?"** ([p. 128](lib:negotiation-and-mediation-techniques#page=128)).
Turn insults into problems: "You are selfish, the whole community suffers" becomes "consider a solution
that meets your family's interests and the community's" ([p. 129](lib:negotiation-and-mediation-techniques#page=129)).
Water, firewood and fence-line disputes fit this well *(general practice)*. [Mediation](wiki:Mediation).

**Protecting shared stores** *(general practice)*: don't advertise what you have; keep common stores in
**locked, rodent-proof containers with a written in-and-out log**; **two people to open them**; rotate
who guards and who counts.

**When something goes missing — a fair process** *(rule of thumb)*:
1. **Write down the facts** — what, when, who saw what. Not guesses or rumors.
2. **Two calm people talk to the person privately.** Listen first.
3. If it's still disputed, use a **mediator**; if both sides agree to it, **three neutral members**
   decide (arbitration).
4. **Repair the harm:** return it, replace it, or work it off in ledger points.
5. **Repeated or serious harm:** the group can vote, under its written agreement, to remove someone
   from the barter group or shared stores. Report crimes to the sheriff while there is one.
6. **Never** beatings, public humiliation, locking people up, or taking a family's own food. Remember
   that hungry people steal — fair food sharing prevents a lot of theft (see the
   [Food Security guide](guide:FOOD-SECURITY-GUIDE)).

📚 **Go deeper:** [*Conflict Resolution Education Guide*](lib:conflict-resolution-education-guide#page=22) — principled negotiation and mediation in plain English; [FAO *Negotiation and Mediation Techniques*](lib:negotiation-and-mediation-techniques#page=27) — disputes over land, water and wood.

## 💛 Grief, stress and psychological first aid

**Look, listen, link** ([WHO *Psychological First Aid*, p. 25](lib:psychological-first-aid-guide-for-field-workers#page=25)):
look for safety, urgent needs and people in severe distress; listen and help them feel calm; link them
to practical help, information and loved ones.
- **Don't pressure anyone to tell their story.** Sit quietly, offer water, allow silence
  ([p. 21](lib:psychological-first-aid-guide-for-field-workers#page=21)).
- **Don't say** "You should feel lucky you survived," don't make false promises, and don't take away
  their sense of being able to care for themselves ([p. 22](lib:psychological-first-aid-guide-for-field-workers#page=22)).
- **Someone who seems unreal or far away:** feet on the floor, tap their hands on their lap, have them
  name what they see and hear, breathe slowly ([p. 30](lib:psychological-first-aid-guide-for-field-workers#page=30)).
- **Most people recover** once basic needs are met and others support them. **Don't leave a severely
  distressed person alone** ([p. 27](lib:psychological-first-aid-guide-for-field-workers#page=27)).
- Don't label normal reactions as disorders ([PFA Field Guide, p. 12](lib:psychological-first-aid-field-operations-guide#page=12)).
  Accept emotional injury as being as real as a sprained ankle ([FM 4-25.11, p. 174](lib:fm-4-25-11-first-aid#page=174)).

**To the [grieving](wiki:Grief), never say** "It could be worse," "Everything happens for the best," or to a child,
"You're the man of the house now" ([PFA Field Guide, p. 41](lib:psychological-first-aid-field-operations-guide#page=41)).

**Look after the helpers** ([🖼️ self-care toolkit](lib:cert-basic-training#page=147)): work in pairs ([WHO, p. 50](lib:psychological-first-aid-guide-for-field-workers#page=50));
watch for helpers taking on survivors' feelings and burning out — time away helps
([CERT, p. 144](lib:cert-basic-training#page=144)); sleep, exercise, eat, and balance work, play and rest
([p. 146](lib:cert-basic-training#page=146)).

**Over months:** expect a **"disillusionment" low in the second half of the first year** and again
around the anniversary ([CERT, p. 151](lib:cert-basic-training#page=151)). Counter it with **scheduled
good activities, problem-solving and helpful thinking** ([*Skills for Psychological Recovery*, p. 49](lib:skills-for-psychological-recovery#page=49)),
deliberately rebuilding friendships ([p. 65](lib:skills-for-psychological-recovery#page=65)), and
regular support-group meetings ([*Where Women Have No Doctor*, p. 14](lib:where-women-have-no-doctor-27-mental-health#page=14)).
[Psychological first aid](wiki:Psychological_first_aid).

📚 **Go deeper:** [WHO *Psychological First Aid*](lib:psychological-first-aid-guide-for-field-workers#page=25) — a short field guide; [PFA *Field Operations Guide*](lib:psychological-first-aid-field-operations-guide#page=41) — children, grief and handouts; [*Skills for Psychological Recovery*](lib:skills-for-psychological-recovery#page=49) — worksheets for the months after.

## 👵 Children, elders and neighbors who need help

- **About 1 in 6 people** has a disability that affects daily life
  ([*Where Women Have No Doctor*, ch. 9](lib:where-women-have-no-doctor-09-living-with-disability#page=2)).
- **Name one person to check on each older or disabled neighbor**; keep wheelchairs and walkers in one
  fixed place; and **ask neighbors now** whether they're willing to help
  ([Red Cross *Seniors*, pp. 8, 10, 15](lib:disaster-preparedness-for-seniors#page=8)).
- **Older adults:** speak clearly in a low pitch, and don't assume confusion is permanent
  ([PFA Field Guide, p. 13](lib:psychological-first-aid-field-operations-guide#page=13)).
- **Children:** crouch to eye level and use simple feeling words — mad, sad, scared, not "terrified"
  (same page). **Children cope the way their parents cope**
  ([FEMA *Are You Ready?*, p. 188](lib:fema-are-you-ready-citizen-preparedness-guide-2004#page=188)).

**Schooling with no school:** older children tutor younger ones ([peer tutoring](wiki:Peer_mentoring))
([*Peer Tutoring*, pp. 17–21](lib:peer-tutoring#page=18)). Structured tutoring beats casual help;
short focused stretches (up to 4 weeks) work best; **math, then reading,** show the biggest gains.
**Train tutors to be kind** — untrained tutors drift into threats and put-downs
([p. 21](lib:peer-tutoring#page=21)). The tutors gain skill and confidence too. For family talk and
journaling, use the day-by-day prompts in the [Oregon toolkit](lib:oregon-be-2-weeks-ready-complete-toolkit#page=35).
[One-room school](wiki:One-room_school).

📚 **Go deeper:** [Red Cross *Disaster Preparedness for Seniors by Seniors*](lib:disaster-preparedness-for-seniors#page=8) — written by elders after a two-week outage; [NWREL *Peer Tutoring*](lib:peer-tutoring#page=18) — teaching mixed ages with few adults.

## 📍 Illinois Valley notes

- **Take a CERT class now.** The Illinois Valley Fire District has run free CERT Basic classes in Cave
  Junction *(local listings 2025–2026, not from a file — verify)*.
- **We're used to waiting.** Sheriff patrols were cut back after public-safety levies failed from 2012
  on *(general knowledge)* — one more reason to organize before anything happens.
- **Wells and propane:** most Valley homes have both, so use the rural MYN steps
  ([MYN Rural, p. 3](lib:map-your-neighborhood-in-rural#page=3)).
- **Mailbox clusters** on the side roads make natural communication sites *(general practice)*.
- **Radios:** cheap [FRS](wiki:Family_Radio_Service)/[GMRS](wiki:General_Mobile_Radio_Service) handhelds reach about 1–2 miles in our hills *(general practice)*. Listen
  to the local nets now — see the [Illinois Valley page](guide:ILLINOIS-VALLEY-START-HERE) and
  [Signals guide](guide:SIGNALS-MORSE-GUIDE).
- **Fire season** (roughly June–October): the night watch doubles as a fire lookout.

📚 **Go deeper:** [MYN *Rural Settings*](lib:map-your-neighborhood-in-rural#page=1) — the rural plan; [Red Cross *Seniors*](lib:disaster-preparedness-for-seniors#page=15) — building a support network before you need it.

## ⚠️ Old advice in the library to ignore

| Old book | What it says | Do this instead |
|---|---|---|
| [USDA Circular 112 (1918), pp. 6, 11](lib:farm-labor-problem#page=6) | Enforce vagrancy laws against "idlers and loafers"; fixed men's and women's farm roles | **Keep it voluntary.** Use only its labor-pooling ideas; anyone can do any job they're able to |
| [Braun (1933)](lib:barter-associations-in-california#page=13) | 1933 California law on workers' comp, scrip and truck permits | Obsolete — use only its trading methods |
| [MYN Rural, p. 1](lib:map-your-neighborhood-in-rural#page=1) | $20 walkie-talkies reach "about 15 miles" | Badly overstated — expect 1–2 miles in our hills *(general practice)* |
| [MYN, p. 7](lib:map-your-neighborhood-discussion-guide#page=7) | Only the gas company may turn gas back on | With no gas company, a competent person relights propane appliances only after a **soapy-water leak check — never a flame** *(general practice)*; see the [Fuel guide](guide:FUEL-GUIDE) |
| [Watch Manual](lib:neighborhood-watch-manual#page=20), Red Cross and PFA guides | Call 911, police and referral services | Report to your group's base and leaders — but keep "no weapons, never confront" exactly as written |
| [De-escalation slides, p. 11](lib:using-verbal-de-escalation#page=11) | "80–90% of communication is non-verbal" | A popular overstatement; the advice itself is sound |
| [Menger, pp. 8–10](lib:origins-of-money#page=8) | 2009 foreword on central banks | Modern opinion — read the 1892 essay itself |
| [*Robert's Rules* (1915)](lib:roberts-rules-of-order#page=32) | Old edition, "he" for every member | Fine for the basics |

📚 **Go deeper:** [USDA Circular 112, p. 11](lib:farm-labor-problem#page=11) — the 1918 coercion, to recognize and avoid; [*Neighborhood Watch Manual*, p. 20](lib:neighborhood-watch-manual#page=20) — the patrol rules to keep exactly as written.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Getting organized after a disaster**
- The OK/HELP card to print — [🖼️ window card](lib:map-your-neighborhood-help-ok-window-card-washington-emd)
- The house water shut-off valve — [🖼️ MYN, p. 23](lib:map-your-neighborhood-discussion-guide#page=23); [Propane](wiki:Propane)
- Using a fire extinguisher (P.A.S.S.) — [🖼️ CERT, p. 171](lib:cert-basic-training#page=171); [🖼️ p. 172](lib:cert-basic-training#page=172); [Fire extinguisher](wiki:Fire_extinguisher)
- How a CERT team is organized — [🖼️ CERT, p. 37](lib:cert-basic-training#page=37); [🖼️ p. 61](lib:cert-basic-training#page=61); [CERT](wiki:Community_emergency_response_team)
- Lifting, cribbing and carrying people — [🖼️ CERT, pp. 210–217](lib:cert-basic-training#page=210)

**Maps, lists and calendars**
- A community map drawn by neighbors — [🖼️ PACA, p. 38](lib:paca-using-participatory#page=38); [🖼️ maps by different groups, pp. 142–143](lib:paca-using-participatory#page=142)
- Seasonal calendar — [🖼️ PACA, p. 41](lib:paca-using-participatory#page=41)
- Daily activity schedules — [🖼️ PACA, p. 43](lib:paca-using-participatory#page=43)
- Blank forms: equipment inventory, check-in, general message — [🖼️ CERT, p. 77](lib:cert-basic-training#page=77); [🖼️ p. 71](lib:cert-basic-training#page=71); [🖼️ p. 78](lib:cert-basic-training#page=78)

**Fair trade**
- What a cord of firewood looks like — [🖼️ OSU EC 1628, p. 1](lib:osu-extension-home-heating-fuels-firewood-vs-pellets-ec1628#page=1); [🖼️ Univ. of Minnesota, p. 3](lib:univ-of-minnesota-heating-the-home-with-wood-eb-436-1979#page=3); [Cord](wiki:Cord_(unit))
- Scales for weighing trades — [Weighing scale](wiki:Weighing_scale)
- Barter and goods that become money — [Barter](wiki:Barter); [Commodity money](wiki:Commodity_money); [Coincidence of wants](wiki:Coincidence_of_wants)
- Labor-hour notes, scrip and shared credit — [Ithaca Hours](wiki:Ithaca_Hours); [Scrip](wiki:Scrip); [LETS](wiki:Local_exchange_trading_system)

**Watch, work and wellbeing**
- Neighborhood watch and the phone tree — [Neighborhood watch](wiki:Neighborhood_watch)
- FRS and GMRS handhelds — [FRS](wiki:Family_Radio_Service); [GMRS](wiki:General_Mobile_Radio_Service)
- Working together — [Barn raising](wiki:Barn_raising)
- Self-care for helpers — [🖼️ CERT, pp. 147–148](lib:cert-basic-training#page=147); [Psychological first aid](wiki:Psychological_first_aid)
- Teaching mixed ages — [One-room school](wiki:One-room_school); [Peer tutoring](wiki:Peer_mentoring)

## 🔗 Related guides

- [Signals & Morse](guide:SIGNALS-MORSE-GUIDE) — the OK/HELP card plan, runners, message forms and alarm signals
- [Injuries & Illness When No Help Is Coming](guide:FIELD-CARE-GUIDE) — first aid for neighborhood teams, nursing, caring for the dying
- [Food Security](guide:FOOD-SECURITY-GUIDE) — storing and sharing food fairly through lean times
- [Medical — READ ME FIRST](guide:Medical-READ-ME-FIRST) — medicines, and why not to trade loose pills
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local contacts, radio nets, wildfire evacuation
- [Fuel guide](guide:FUEL-GUIDE) — propane leaks and safe fuel storage
- [Chronic Illness With No Pharmacy](guide:CHRONIC-ILLNESS-GUIDE) — diabetes, blood pressure, asthma, seizures and other daily medicines when the pharmacy is gone
- [How the Power Grid Works](guide:POWER-GRID-GUIDE) — a neighborhood power committee, metering and fair shares
- [How Town Water and Sewer Work](guide:TOWN-WATER-SEWER-GUIDE) — getting the valve list and system map, and running a small water system together
