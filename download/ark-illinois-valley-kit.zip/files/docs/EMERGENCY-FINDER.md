# 🆘 Emergency Finder

> **Something is happening right now?** Find it below and tap the link — it opens the exact section of the guide. No search, AI or internet needed. Print this page and keep it with the first-aid kit. For everything else use the [📇 Subject index A–Z](guide:SUBJECT-INDEX).

## 🩸 Someone is hurt

| What is happening | Go to |
|---|---|
| Don't know where to start — unconscious, not breathing, badly hurt | [Injuries › The first look: check in this order](guide:FIELD-CARE-GUIDE#the-first-look-check-in-this-order)<br>[Medicines › The first few minutes](guide:Medical-READ-ME-FIRST#the-first-few-minutes) |
| Bleeding badly or spurting | [Injuries › Stopping life-threatening bleeding, then shock](guide:FIELD-CARE-GUIDE#stopping-life-threatening-bleeding-then-shock) |
| In shock after an injury: pale, cold, sweaty, fast weak pulse | [Injuries › Stopping life-threatening bleeding, then shock](guide:FIELD-CARE-GUIDE#stopping-life-threatening-bleeding-then-shock) |
| Allergic reaction: swollen face or throat, can't breathe, hives | [Medicines › Using found or expired medicines](guide:Medical-READ-ME-FIRST#using-found-or-expired-medicines) |
| Seizure (fits) | [Injuries › Broken bones, sprains, spine and head](guide:FIELD-CARE-GUIDE#broken-bones-sprains-spine-and-head)<br>[Chronic illness › The first minutes](guide:CHRONIC-ILLNESS-GUIDE#the-first-minutes) |
| Burned | [Injuries › Burns](guide:FIELD-CARE-GUIDE#burns) |
| Broken bone, sprain, bad fall, head or neck injury | [Injuries › Broken bones, sprains, spine and head](guide:FIELD-CARE-GUIDE#broken-bones-sprains-spine-and-head) |
| Deep cut, or a wound turning red, hot or full of pus | [Injuries › Wounds and infection when there's no hospital](guide:FIELD-CARE-GUIDE#wounds-and-infection-when-there-s-no-hospital) |
| Hydraulic oil or grease sprayed into the skin (a tiny mark, little pain at first) | [Vehicles, tractors & equipment › Hydraulic dangers: injected oil and falling loads](guide:VEHICLES-EQUIPMENT-GUIDE#hydraulic-dangers-injected-oil-and-falling-loads) |
| Someone pinned under a tractor, vehicle or load | [Vehicles, tractors & equipment › Tractor safety: rollovers, PTO, runovers and riders](guide:VEHICLES-EQUIPMENT-GUIDE#tractor-safety-rollovers-pto-runovers-and-riders) |
| Caught in a spinning shaft (PTO) or belt | [Vehicles, tractors & equipment › Tractor safety: rollovers, PTO, runovers and riders](guide:VEHICLES-EQUIPMENT-GUIDE#tractor-safety-rollovers-pto-runovers-and-riders) |
| Rattlesnake bite, spider bite, bee or wasp sting | [Injuries › Rattlesnakes, spiders and stings](guide:FIELD-CARE-GUIDE#rattlesnakes-spiders-and-stings) |
| Too hot (heat stroke) or too cold (hypothermia) | [Injuries › Heat and cold in the Valley](guide:FIELD-CARE-GUIDE#heat-and-cold-in-the-valley) |
| Toothache, knocked-out tooth, swollen face | [Injuries › Teeth: pain and emergencies](guide:FIELD-CARE-GUIDE#teeth-pain-and-emergencies) |
| Thunderstorm coming, or someone struck by lightning | [Navigation & weather › Lightning safety](guide:NAVIGATION-WEATHER-GUIDE#lightning-safety) |
| Someone may not survive | [Injuries › Knowing when someone can't be saved](guide:FIELD-CARE-GUIDE#knowing-when-someone-can-t-be-saved) |

## 🤒 Someone is sick

| What is happening | Go to |
|---|---|
| Diarrhea or vomiting, getting dried out | [Medicines › Diarrhea and dehydration: the homemade drink](guide:Medical-READ-ME-FIRST#diarrhea-and-dehydration-the-homemade-drink) |
| Diabetic acting drunk, confused, sweaty or passing out | [Chronic illness › The first minutes](guide:CHRONIC-ILLNESS-GUIDE#the-first-minutes) |
| Asthma attack: can't breathe out, can't finish a sentence | [Chronic illness › The first minutes](guide:CHRONIC-ILLNESS-GUIDE#the-first-minutes) |
| Chest pain or pressure | [Chronic illness › The first minutes](guide:CHRONIC-ILLNESS-GUIDE#the-first-minutes) |
| A daily medicine is running out | [Chronic illness › Medicines you must never stop suddenly](guide:CHRONIC-ILLNESS-GUIDE#medicines-you-must-never-stop-suddenly) |
| Insulin with no fridge | [Chronic illness › Diabetes](guide:CHRONIC-ILLNESS-GUIDE) |
| A child under 5 with fever, fast breathing or diarrhea | [Childbirth & kids › Sick children under 5: fever, breathing, diarrhea, measles, worms](guide:CHILDBIRTH-CHILDREN-GUIDE#sick-children-under-5-fever-breathing-diarrhea-measles-worms) |
| Several people sick at once | [Sanitation › How germs spread, and stopping an outbreak](guide:SANITATION-GUIDE#how-germs-spread-and-stopping-an-outbreak) |
| Ate a wild mushroom and feels sick | [Mushrooms › If someone may have eaten a bad mushroom](guide:MUSHROOM-GUIDE#if-someone-may-have-eaten-a-bad-mushroom) |
| Ate a wild plant that might be poisonous | [Food when scarce › Foraging safety rules](guide:FOOD-SECURITY-GUIDE#foraging-safety-rules)<br>[Illinois Valley › Wild plants — the deadly look-alikes](guide:ILLINOIS-VALLEY-START-HERE#wild-plants-the-deadly-look-alikes) |
| Only found or expired medicine to use | [Medicines › Using found or expired medicines](guide:Medical-READ-ME-FIRST#using-found-or-expired-medicines) |
| Mouse droppings in the house (hantavirus), fleas | [Sanitation › Mice, hantavirus, fleas and plague](guide:SANITATION-GUIDE#mice-hantavirus-fleas-and-plague) |
| Lice or scabies | [Sanitation › Flies, mosquitoes, lice and scabies](guide:SANITATION-GUIDE#flies-mosquitoes-lice-and-scabies) |
| Someone starving, or starting to eat again after hunger | [Food when scarce › Starvation and refeeding slowly](guide:FOOD-SECURITY-GUIDE#starvation-and-refeeding-slowly) |
| Someone in emotional shock, grieving or panicking | [Community & barter › Grief, stress and psychological first aid](guide:COMMUNITY-BARTER-GUIDE#grief-stress-and-psychological-first-aid) |
| Someone angry or threatening | [Community & barter › Calming an angry person](guide:COMMUNITY-BARTER-GUIDE#calming-an-angry-person) |
| Someone has died | [Sanitation › Caring for the dead](guide:SANITATION-GUIDE#caring-for-the-dead) |

## 👶 Pregnancy, birth and babies

| What is happening | Go to |
|---|---|
| Pregnant and bleeding, bad headache, swelling or fits | [Childbirth & kids › Pregnancy: checkups and danger signs](guide:CHILDBIRTH-CHILDREN-GUIDE#pregnancy-checkups-and-danger-signs) |
| Labor has started | [Childbirth & kids › Labor and birth: what helpers do](guide:CHILDBIRTH-CHILDREN-GUIDE#labor-and-birth-what-helpers-do) |
| Heavy bleeding after the birth | [Childbirth & kids › Heavy bleeding after birth: the #1 killer](guide:CHILDBIRTH-CHILDREN-GUIDE#heavy-bleeding-after-birth-the-1-killer) |
| Baby stuck at the shoulders, or coming bottom first | [Childbirth & kids › Stuck shoulders and breech](guide:CHILDBIRTH-CHILDREN-GUIDE#stuck-shoulders-and-breech) |
| Newborn not breathing | [Childbirth & kids › A baby who isn't breathing](guide:CHILDBIRTH-CHILDREN-GUIDE#a-baby-who-isn-t-breathing) |
| Newborn cold, very small or sick | [Childbirth & kids › Warmth, small babies and newborn danger signs](guide:CHILDBIRTH-CHILDREN-GUIDE#warmth-small-babies-and-newborn-danger-signs) |
| Child swallowed something poisonous, burned, or nearly drowned | [Childbirth & kids › Accidents: drowning, burns, poisoning](guide:CHILDBIRTH-CHILDREN-GUIDE#accidents-drowning-burns-poisoning) |
| No milk or formula for a baby | [Food when scarce › Babies and toddlers in a shortage](guide:FOOD-SECURITY-GUIDE#babies-and-toddlers-in-a-shortage) |

## 🔥 Fire, earthquake, fallout

| What is happening | Go to |
|---|---|
| Wildfire nearby, or an evacuation level is called | [Illinois Valley › Evacuation levels (Josephine County)](guide:ILLINOIS-VALLEY-START-HERE#evacuation-levels-josephine-county)<br>[Illinois Valley › Wildfire](guide:ILLINOIS-VALLEY-START-HERE#wildfire) |
| Heavy wildfire smoke | [Illinois Valley › Smoke](guide:ILLINOIS-VALLEY-START-HERE#smoke) |
| Chimney fire, or a stove that smokes or roars | [Firewood › Burning safely: stoves, chimneys, ashes](guide:FIREWOOD-GUIDE#burning-safely-stoves-chimneys-ashes)<br>[Shelter › Chimneys and stovepipe](guide:SHELTER-BUILDING-GUIDE#chimneys-and-stovepipe) |
| A battery smoking, swelling or getting hot | [Off-grid power › Battery safety](guide:OFF-GRID-POWER-GUIDE#battery-safety)<br>[Off-grid power › Lithium, LiFePO4 and salvaged packs](guide:OFF-GRID-POWER-GUIDE#lithium-lifepo4-and-salvaged-packs) |
| An electric or hybrid car smoking, hissing or burning | [Vehicles, tractors & equipment › Electric cars and hybrids](guide:VEHICLES-EQUIPMENT-GUIDE#electric-cars-and-hybrids) |
| Earthquake just happened | [Illinois Valley › Earthquake (Cascadia) and tsunami](guide:ILLINOIS-VALLEY-START-HERE#earthquake-cascadia-and-tsunami) |
| Nuclear flash, or a fallout warning | [Nuclear fallout › The first minutes](guide:NUCLEAR-FALLOUT-GUIDE#the-first-minutes)<br>[Nuclear fallout › Where to shelter](guide:NUCLEAR-FALLOUT-GUIDE#where-to-shelter) |
| How long to stay inside after fallout | [Nuclear fallout › How long to stay in](guide:NUCLEAR-FALLOUT-GUIDE#how-long-to-stay-in) |
| Potassium iodide (KI): who takes it, how much | [Nuclear fallout › Potassium iodide (KI)](guide:NUCLEAR-FALLOUT-GUIDE#potassium-iodide-ki) |
| Solar-storm or EMP warning | [EMP › When a solar-storm warning comes](guide:EMP-GUIDE#when-a-solar-storm-warning-comes)<br>[EMP › Rule one: unplug and disconnect](guide:EMP-GUIDE#rule-one-unplug-and-disconnect) |

## 🌊 Flood, storm or heat wave

| What is happening | Go to |
|---|---|
| Water rising: flood | [Floods, storms & heat › The first hour of a flood](guide:FLOODS-STORMS-HEAT-GUIDE#the-first-hour-of-a-flood) |
| Water over the road | [Floods, storms & heat › Moving water: turn around](guide:FLOODS-STORMS-HEAT-GUIDE#moving-water-turn-around) |
| Going back into a flooded house | [Floods, storms & heat › After the flood](guide:FLOODS-STORMS-HEAT-GUIDE) |
| Windstorm coming | [Floods, storms & heat › Windstorms](guide:FLOODS-STORMS-HEAT-GUIDE) |
| Ice storm or snowstorm, power out | [Floods, storms & heat › Winter storms and ice storms](guide:FLOODS-STORMS-HEAT-GUIDE) |
| Power line down, tree on the house | [Floods, storms & heat › Winter storms and ice storms](guide:FLOODS-STORMS-HEAT-GUIDE) |
| Heat wave, house too hot, no power | [Floods, storms & heat › Heat waves](guide:FLOODS-STORMS-HEAT-GUIDE) |

## 🏠 Shelter and heat

| What is happening | Go to |
|---|---|
| Roof leaking in a storm | [Shelter › Finding and patching roof leaks](guide:SHELTER-BUILDING-GUIDE#finding-and-patching-roof-leaks) |
| House damaged — need shelter tonight | [Shelter › Emergency tarp and plastic shelters](guide:SHELTER-BUILDING-GUIDE#emergency-tarp-and-plastic-shelters) |
| House too cold, no heat | [Shelter › One warm room: drafts, plastic and heat](guide:SHELTER-BUILDING-GUIDE#one-warm-room-drafts-plastic-and-heat) |
| Running a generator (carbon monoxide, backfeed) | [Off-grid power › Generators, cars and backfeed](guide:OFF-GRID-POWER-GUIDE#generators-cars-and-backfeed)<br>[Engines › Generators](guide:ENGINES-AND-MOTORS-GUIDE#generators) |
| Headache, dizzy or sleepy with a heater, stove or generator running | [Floods, storms & heat › Carbon monoxide: the quiet killer](guide:FLOODS-STORMS-HEAT-GUIDE#carbon-monoxide-the-quiet-killer) |

## 💧 Water and food

| What is happening | Go to |
|---|---|
| No safe drinking water | [Water purification › Which method does what](guide:WATER-PURIFICATION-GUIDE#which-method-does-what)<br>[Water purification › Step 3 — Kill the germs](guide:WATER-PURIFICATION-GUIDE#step-3-kill-the-germs) |
| How much bleach to put in water | [Water purification › Step 3 — Kill the germs](guide:WATER-PURIFICATION-GUIDE#step-3-kill-the-germs) |
| Water after a wildfire | [Water purification › After a wildfire](guide:WATER-PURIFICATION-GUIDE#after-a-wildfire) |
| Well pump dead — no power | [Wells & pumps › Running the well pump without the grid](guide:WATER-WELLS-GUIDE#running-the-well-pump-without-the-grid)<br>[Wells & pumps › Getting water up by hand](guide:WATER-WELLS-GUIDE#getting-water-up-by-hand) |
| Food running low | [Food when scarce › Setting and running a fair ration](guide:FOOD-SECURITY-GUIDE#setting-and-running-a-fair-ration)<br>[Food when scarce › How much food people need](guide:FOOD-SECURITY-GUIDE#how-much-food-people-need) |
| A bulging can or a jar that smells wrong (botulism) | [Preserving food › Jars, lids, storage and spoilage](guide:PRESERVING-FOOD-GUIDE#jars-lids-storage-and-spoilage)<br>[Preserving food › Botulism: why low-acid food needs a pressure canner](guide:PRESERVING-FOOD-GUIDE#botulism-why-low-acid-food-needs-a-pressure-canner) |
| Fresh meat in hot weather | [Hunting & fishing › Cooling meat in our heat](guide:HUNTING-TRAPPING-FISHING-GUIDE#cooling-meat-in-our-heat) |

## 📡 Lost, cut off, need help

| What is happening | Go to |
|---|---|
| Lost in the woods | [Navigation & weather › Getting un-lost](guide:NAVIGATION-WEATHER-GUIDE#getting-un-lost) |
| Signal a plane or searchers | [Signals & Morse › Distress signals and talking to aircraft](guide:SIGNALS-MORSE-GUIDE#distress-signals-and-talking-to-aircraft)<br>[Signals & Morse › Ground-to-air symbols (print this)](guide:SIGNALS-MORSE-GUIDE#ground-to-air-symbols-print-this) |
| Call for help by radio | [Radio › 9. How to call for help (procedure)](guide:RADIO-GUIDE#9-how-to-call-for-help-procedure) |
| Text family or neighbors with no phone service | [Mesh radio (Meshtastic) › 6. Sending messages and positions](guide:MESH-RADIO-GUIDE#6-sending-messages-and-positions) |
| Tell the neighbors you need help | [Signals & Morse › The neighborhood OK/HELP plan](guide:SIGNALS-MORSE-GUIDE#the-neighborhood-ok-help-plan) |
| Theft, or a dispute between neighbors | [Community & barter › Settling disputes and dealing with theft](guide:COMMUNITY-BARTER-GUIDE#settling-disputes-and-dealing-with-theft) |
| Someone at the gate, or trying to break in | [Home protection › Someone at the gate, strangers, or a break-in](guide:HOME-DEFENSE-GUIDE#someone-at-the-gate-strangers-or-a-break-in) |
| After a break-in or theft | [Home protection › Someone at the gate, strangers, or a break-in](guide:HOME-DEFENSE-GUIDE#someone-at-the-gate-strangers-or-a-break-in) |

## 🐐 Animals

| What is happening | Go to |
|---|---|
| Goat sick, bloated, or trouble kidding | [Goats › Goat health with no vet](guide:GOATS-GUIDE#goat-health-with-no-vet)<br>[Goats › Breeding, kidding and kids](guide:GOATS-GUIDE#breeding-kidding-and-kids) |
| Horse with colic, a wound or lameness | [Horses › Health checks and first aid](guide:HORSE-GUIDE#health-checks-and-first-aid)<br>[Horses › If this goes wrong](guide:HORSE-GUIDE#if-this-goes-wrong) |
| Chickens sick | [Chickens › Health with no vet](guide:CHICKENS-GUIDE#health-with-no-vet) |
| Rabbits sick | [Rabbits › Health with no vet](guide:RABBITS-GUIDE#health-with-no-vet) |
| Animals in heat, smoke or fire | [Chickens › Heat, smoke and fire season](guide:CHICKENS-GUIDE#heat-smoke-and-fire-season)<br>[Goats › Brush, fire breaks and fire season](guide:GOATS-GUIDE#brush-fire-breaks-and-fire-season) |
| Bee stings or an allergic reaction | [Bees › Stings and allergic reactions](guide:BEES-GUIDE#stings-and-allergic-reactions) |
| Bee swarm, or a bear at the hives | [Bees › Getting bees: swarms, bait hives, bee trees and splits](guide:BEES-GUIDE#getting-bees-swarms-bait-hives-bee-trees-and-splits)<br>[Bees › Bears and fire season](guide:BEES-GUIDE#bears-and-fire-season) |
| Livestock and gardens after fallout | [Nuclear fallout › Livestock and gardens](guide:NUCLEAR-FALLOUT-GUIDE#livestock-and-gardens) |

## 🔧 Something stopped working

| What is happening | Go to |
|---|---|
| Engine won't start | [Engines › Small gas engines: why it won't start](guide:ENGINES-AND-MOTORS-GUIDE#small-gas-engines-why-it-won-t-start) |
| Car or truck won't start | [Vehicles, tractors & equipment › Cars and pickups with no shop](guide:VEHICLES-EQUIPMENT-GUIDE) |
| Tractor or diesel truck won't start in the cold | [Vehicles, tractors & equipment › Diesel trucks and tractors](guide:VEHICLES-EQUIPMENT-GUIDE) |
| Hydraulics weak, slow or leaking | [Vehicles, tractors & equipment › Hydraulics: how it works and keeping it healthy](guide:VEHICLES-EQUIPMENT-GUIDE) |
| Is this old gas or diesel still good? | [Fuel › Is this fuel still good?](guide:FUEL-GUIDE#is-this-fuel-still-good) |
| Out of fuel | [Fuel › Getting fuel out of gas-station tanks](guide:FUEL-GUIDE#getting-fuel-out-of-gas-station-tanks) |
| Electronics dead after a solar storm or EMP | [EMP › After an event: check and repair](guide:EMP-GUIDE#after-an-event-check-and-repair) |
