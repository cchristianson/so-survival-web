# 📚 How to Read the Offline Archives (Kiwix)

Wikipedia and the medical, repair and survival encyclopedias are saved as **`.zim` files**. Open
them with the **Library Assistant** or the free **Kiwix** app. No internet needed.

- **Don't unzip `.zim` files.** Open them as they are.
- On a phone? See [Use the library on a phone](guide:USE-ON-PHONE).

---

## 🚀 Easiest: the Library Assistant

1. Double-click **`START-Windows`** (Mac: **`START-Mac`**, Linux: **`START-Linux.sh`**) in the
   **OfflineLibrary** folder.
2. Your browser opens. Search for anything and click a result to read it.

A warning the first time? See [Start on any device](guide:START-ON-ANY-DEVICE).

---

## 🪟 Windows: the Kiwix app

1. On the drive, open **OfflineLibrary → Kiwix-Reader → app**.
2. Double-click **`kiwix-desktop`**. Nothing to install.
3. If a blue box says **Windows protected your PC**, click **More info**, then **Run anyway**.
4. Choose **Open file** and pick a `.zim` file (for example in `Medical\WikiMed`).

Kiwix remembers each file you open. **Mac and Linux:** use the Library Assistant instead.

---

## 📂 What's in the .zim files

| Folder | What's inside |
|---|---|
| `Medical\WikiMed` | Wikipedia's medical articles, with pictures |
| `Medical\zimgit-medicine` | A medical and first-aid guide |
| `Manuals\Repair-iFixit` | Repairs: cars, appliances, electronics, phones |
| `Manuals\DIY-Appropedia` | DIY: plumbing, electrical, building, energy, water, food |
| `Manuals\Survival-Water-Food` | Survival, water, food, knots |
| `Wikipedia` | All of English Wikipedia (the biggest file) |

Your drive may not have every one.
