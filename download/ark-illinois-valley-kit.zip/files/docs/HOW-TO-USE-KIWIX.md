# 📚 How to Read the Offline Archives (Kiwix)

**`.zim` files** are whole websites saved for offline use: Wikipedia and the medical, repair and
survival archives. Open them with the **Library Assistant** or the free **Kiwix** reader. No
internet needed.

- **Don't unzip `.zim` files.** Open them as they are.
- PDF books don't need Kiwix. They open in any web browser.
- On a phone? See [Use the library on a phone](guide:USE-ON-PHONE).

---

## 🚀 Easiest, on any computer: the Library Assistant

It opens every `.zim` file in your web browser and searches them all, plus the books.

1. In the **OfflineLibrary** folder on the drive, double-click **`START-Windows`** (Mac:
   **`START-Mac`**, Linux: **`START-Linux.sh`**).
2. Your browser opens. Type what you're looking for, then click a result to read it.

A warning the first time? See [Start on any device](guide:START-ON-ANY-DEVICE).

---

## 🪟 Windows: the Kiwix app

1. On the drive, open **OfflineLibrary** → **Kiwix-Reader** → **app** (if there's one more folder
   inside, open it too).
2. Double-click **`kiwix-desktop`**. Nothing to install.
3. If a blue box says **Windows protected your PC**, click **More info**, then **Run anyway**.
4. In Kiwix, choose **Open file** and pick a `.zim` file, for example in `Medical\WikiMed`.
5. It opens like a website. Use the **search box** to find any article.

Open each `.zim` file once; Kiwix remembers them in its **Library**. (No **app** folder, or it's
empty? Use the Library Assistant above.)

**Mac and Linux:** use the Library Assistant. (On a Mac you can also get **Kiwix** from the Mac App
Store while you have internet.)

---

## 📂 What's in the .zim files

All inside **OfflineLibrary**. Your drive may not have every one.

| Folder | What's inside |
|---|---|
| `Medical\WikiMed` | Wikipedia's medical articles, with pictures |
| `Medical\zimgit-medicine` | Medical and first-aid guide |
| `Manuals\Repair-iFixit` | Repairs: cars, appliances, electronics, phones |
| `Manuals\DIY-Appropedia` | DIY: plumbing, electrical, building, energy, water, food |
| `Manuals\Survival-Water-Food` | Survival, water, food preparation, knots |
| `Wikipedia` | All of English Wikipedia (the biggest file) |

Asking the offline AI about your PDFs: see [Ask your documents](guide:HOW-TO-ASK-YOUR-DOCS).

---

## 🧰 For helpers

- **Without the Library Assistant:** in a Command Prompt, run `kiwix-serve.exe --port=8090`
  followed by the `.zim` files, then open **http://localhost:8090**. It's in `Kiwix-Reader\tools`
  (maybe one folder deeper).
- A drive made on a Linux PC also has a Kiwix `.appimage` program in `Kiwix-Reader`.
