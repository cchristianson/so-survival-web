# 🪚 Woodworking With Hand Tools

How to make and mend useful things from wood with no power tools: the tools to keep and how to sharpen them, which
wood to use and how to dry it, splitting green wood, sawing and planing true, the joints (including ones that need no
glue or nails), tool handles, a bench, stools, shelves, a ladder, and repairs to doors and furniture. The woodworking
books are in `Southern-Oregon\Blacksmithing-Tools\Hand-Tools` (Griffith's *Essentials of Woodworking*, Brace and
Mayne's *Farm Shop Work*, the Disston saw book, *Handtools for Trail Work*); the USDA *Wood Handbook* is in
`Southern-Oregon\Shelter-Building\Carpentry-Timber`; old shop recipes are in
`Southern-Oregon\Homestead-Skills\Household-Make-Do`; the Army's *Carpentry* (FM 5-426) and *Use and Care of Hand
Tools* (TM 9-243) are in `Manuals\ArmyFieldManuals`.

> ### The short version
> - **Sharp tools are safe tools:** "Dull tools are useless and dangerous"
>   ([*Handtools*, p. 49](lib:usfs-mtdc-handtools-for-trail-work-2005#page=49)). Grind chisels and plane irons at
>   about 25°, hone a little steeper ([Griffith, p. 69](lib:griffith-essentials-of-woodworking#page=69)).
> - **Both hands behind the edge**, and clamp the work ([Griffith, pp. 61–62](lib:griffith-essentials-of-woodworking#page=61)).
>   The drawknife comes toward you: "keep fingers clear of blade corners"
>   ([*Handtools*, p. 45](lib:usfs-mtdc-handtools-for-trail-work-2005#page=45)).
> - **Crosscut saws are filed at an angle, rip saws straight across.** Joint and set before you file
>   ([Disston, pp. 35–39](lib:disston-saw-tool-and-file-book-1929#page=35)).
> - **Split, don't saw, anything that must be strong** — handles, pegs, rungs
>   ([Griffith, p. 100](lib:griffith-essentials-of-woodworking#page=100)). Hickory for striking tools, ash for the rest
>   ([*Handtools*, p. 53](lib:usfs-mtdc-handtools-for-trail-work-2005#page=53)).
> - **Wood moves with water:** most along the growth rings, half that across them, hardly at all along its length
>   ([Wood Handbook, p. 84](lib:wood-handbook#page=84)). Rough it out green, finish it dry *(rule of thumb)*.
> - **Joints with no glue or nails:** a pegged (drawbored) mortise and tenon, or a tenon wedged through a hole
>   ([FM 5-426, p. 206](lib:fm-5-426-carpentry#page=206); [Brace & Mayne, p. 42](lib:brace-and-mayne-farm-shop-work-1915#page=42)).
>   Hide glue fails in the damp ([Brace & Mayne, p. 204](lib:brace-and-mayne-farm-shop-work-1915#page=204)).
> - **Oily rags can catch fire by themselves** ([*An Ax to Grind*, p. 34](lib:usfs-an-ax-to-grind#page=34)). Never burn
>   pressure-treated wood or make food boards from it ([Wood Handbook, p. 329](lib:wood-handbook#page=329)).

---

## 🧰 The tool kit worth keeping
<!-- fold: The saws, planes, chisels and other tools to keep, and the ones you can make -->

Besides the tools below, a 1912 farm list names a gouge, a hatchet, files, a vise, a shaving horse and a grindstone
([*Handy Farm Devices*, pp. 13–14](lib:handy-farm-devices#page=13)).

| Tool | What to know |
|---|---|
| **Crosscut and rip saws** | Crosscut teeth are pointed like knives; rip teeth are little chisels ([Griffith, p. 31](lib:griffith-essentials-of-woodworking#page=31)). 8 points to the inch is the all-round crosscut, 5½ the usual rip ([Disston, p. 9](lib:disston-saw-tool-and-file-book-1929#page=9)) |
| **Jack plane, jointer, smooth plane** | The jack (about 13 in) takes wood off; the jointer (2 ft or more) straightens long edges; the smoother finishes ([Griffith, pp. 39–41](lib:griffith-essentials-of-woodworking#page=39)) |
| **Chisels** | Paring chisels are pushed by hand, "never" struck; framing chisels take the mallet ([Brace & Mayne, pp. 183–184](lib:brace-and-mayne-farm-shop-work-1915#page=183)) |
| **Brace and auger bits** | The number on the tang is sixteenths of an inch: 8 bores 1/2 in ([Griffith, p. 55](lib:griffith-essentials-of-woodworking#page=55)) |
| **Drawknife, spokeshave** | Shaping handles, rungs and curves; the spokeshave is "a small plane" ([Brace & Mayne, p. 184](lib:brace-and-mayne-farm-shop-work-1915#page=184)) |
| **Square, gauge, knife** | Laying out (see [Measuring, sawing and planing](#measuring-sawing-and-planing)) |
| **Scraper** | Saw steel with a turned edge, for curly grain a plane tears ([Griffith, p. 79](lib:griffith-essentials-of-woodworking#page=79)) |

**Make these yourself:** clamps from a bar, two blocks and a pair of wedges
([Griffith, pp. 90–91](lib:griffith-essentials-of-woodworking#page=90); [🖼️ drawing](lib:griffith-essentials-of-woodworking#page=90));
a bench hook, which doubles as a shooting board for planing ends square
([Griffith, p. 51](lib:griffith-essentials-of-woodworking#page=51)); two winding sticks for checking twist
([p. 46](lib:griffith-essentials-of-woodworking#page=46)); and a hardwood mallet *(rule of thumb)*.

📚 **Go deeper:** [Griffith *Essentials of Woodworking*](lib:griffith-essentials-of-woodworking#page=17) — every hand tool and how to use it, with drawings; [Brace and Mayne *Farm Shop Work*](lib:brace-and-mayne-farm-shop-work-1915#page=181) — the tools, then farm projects; [TM 9-243](lib:tm-9-243) — care of every common hand tool. Pictures: [Hand plane](wiki:Plane_(tool)), [Brace (tool)](wiki:Brace_(tool)), [Spokeshave](wiki:Spokeshave).

## 🪨 Sharpening chisels and plane irons
<!-- fold: Grinding, honing, stropping and testing an edge, and caring for stones -->

**The grindstone shapes; only the oilstone sharpens.** "No tool, after it has been ground, is ready for use until it has
been whetted" ([Griffith, p. 68](lib:griffith-essentials-of-woodworking#page=68)). Grind only when the edge is rounded
or nicked; otherwise just hone.

1. **Grind** on a wet stone turning toward the edge, at one steady angle, moving across the stone. The water keeps
   the edge from being "burned or softened" ([Griffith, pp. 67–68](lib:griffith-essentials-of-woodworking#page=67);
   [🖼️ drawing](lib:griffith-essentials-of-woodworking#page=67)). Mechanics use 20–30°; 23° suits everything, honed
   steeper for hard wood ([Brace & Mayne, p. 209](lib:brace-and-mayne-farm-shop-work-1915#page=209)). The bevel is
   about 1/4 in long on a plane iron, 3/8–1/2 in on a chisel ([Griffith, p. 67](lib:griffith-essentials-of-woodworking#page=67)).
2. **Hone:** lay the bevel flat in the oil, raise the handle until the oil squeezes out from under the edge, and rub at
   that angle without rocking ([Griffith, pp. 69–70](lib:griffith-essentials-of-woodworking#page=69);
   [🖼️ drawing](lib:griffith-essentials-of-woodworking#page=69)).
3. **Take off the burr** (wire edge) with the flat side dead flat on the stone; never raise it, or you start a second
   bevel ([Brace & Mayne, pp. 209–210](lib:brace-and-mayne-farm-shop-work-1915#page=209)).
4. **Strop** on leather on a board: the bevel drawn toward you several times, the flat side once or twice
   ([Griffith, p. 70](lib:griffith-essentials-of-woodworking#page=70)).
5. **Test:** in good light a dull edge shows a white line; a sharp one shows none
   ([Griffith, pp. 71–72](lib:griffith-essentials-of-woodworking#page=71)).

![Side view of the end of a chisel, much enlarged: the flat side on top, a long ground bevel underneath at about 25 degrees, about 1/4 in long on a plane iron and 3/8 to 1/2 in on a chisel, and a narrow honed edge at the tip a little steeper. The flat side is kept dead flat on the stone to rub off the burr](img:WOODWORKING-GUIDE/chisel-bevel.svg)
*The ground bevel, the steeper honed edge, and the flat side that stays flat (a diagram drawn for this guide).*

Plane irons are ground straight across with the corners just rounded; gouges are rolled on the stone and the inside
burr taken off with a shaped slip ([Griffith, pp. 70–71](lib:griffith-essentials-of-woodworking#page=70)). Keep a
drawknife at 33° ([*Handtools*, p. 45](lib:usfs-mtdc-handtools-for-trail-work-2005#page=45)). A scraper is filed square,
honed, then its edge turned over with a burnisher (any smooth hard steel) under light pressure
([Griffith, pp. 80–81](lib:griffith-essentials-of-woodworking#page=80); [🖼️ drawing](lib:griffith-essentials-of-woodworking#page=81)).

**Stones:** use a little light oil and the **whole** stone, or it wears hollow. Flatten a worn stone on sandpaper on a
flat surface, or on a board with sand and water ([Griffith, pp. 68–69](lib:griffith-essentials-of-woodworking#page=68);
[Brace & Mayne, p. 211](lib:brace-and-mayne-farm-shop-work-1915#page=211)); clean a glazed one with kerosene, or citrus
solvent and a stiff brush ([*Handtools*, p. 52](lib:usfs-mtdc-handtools-for-trail-work-2005#page=52)). A glazed grindstone
cuts again with a little sand poured on ([*Handy Farm Devices*, p. 15](lib:handy-farm-devices#page=15)).

**Axes, hoes and shovels**, and forging new chisels and plane irons from old files, are in
[Blacksmithing & Hand Tools](guide:BLACKSMITHING-GUIDE#keeping-hand-tools-working).

📚 **Go deeper:** [Griffith, pp. 66–72](lib:griffith-essentials-of-woodworking#page=66) — grinding, whetting and testing; [Brace & Mayne, pp. 208–212](lib:brace-and-mayne-farm-shop-work-1915#page=208) — angles and stones; [*Handtools for Trail Work*, pp. 49–52](lib:usfs-mtdc-handtools-for-trail-work-2005#page=49). Pictures: [Whetstone](wiki:Whetstone), [Strop](wiki:Razor_strop).

## 🪚 Sharpening hand saws
<!-- fold: Jointing, shaping, setting and filing crosscut and rip saws -->

"Learning to sharpen a saw is a difficult thing" ([Griffith, p. 34](lib:griffith-essentials-of-woodworking#page=34)):
learn on a coarse saw ([Brace & Mayne, p. 205](lib:brace-and-mayne-farm-shop-work-1915#page=205)). Touching up the teeth
with a file now and then saves a full sharpening ([Disston, p. 34](lib:disston-saw-tool-and-file-book-1929#page=34)).
Clamp the saw at elbow height with the bottoms of the gaps (gullets) **1/8 in** above the jaws, or the file chatters
([Disston, p. 38](lib:disston-saw-tool-and-file-book-1929#page=38)); two boards bolted together make a clamp *(rule of thumb)*.

1. **Joint** (only if teeth are uneven): run a flat file along the tops of the teeth until it touches every one,
   keeping it from tipping ([Disston, p. 35](lib:disston-saw-tool-and-file-book-1929#page=35)). A wooden block holding the
   file square helps ([Brace & Mayne, p. 207](lib:brace-and-mayne-farm-shop-work-1915#page=207)).
2. **Shape** (only after jointing): file straight across until all teeth are equal and pointed
   ([Disston, pp. 35–36](lib:disston-saw-tool-and-file-book-1929#page=35)).
3. **Set:** bend the top of each tooth out, alternately left and right, with a saw set. **Never deeper than half the
   tooth**, or the blade cracks. Wet or soft wood needs more set ([Disston, p. 36](lib:disston-saw-tool-and-file-book-1929#page=36)).
4. **File** with a three-cornered file, cutting on the push stroke, every other gap from one side and then the rest
   from the other; filing all from one side makes the saw run crooked
   ([Brace & Mayne, p. 206](lib:brace-and-mayne-farm-shop-work-1915#page=206)).
   - **Crosscut:** saw handle on your right, start at the point. Put the file in the gap left of the first tooth bent
     toward you, square across, then swing the **file's handle about 45° toward the saw's point**. Then turn the saw
     around for the other side ([Disston, pp. 38–39](lib:disston-saw-tool-and-file-book-1929#page=38);
     [🖼️ the two positions](lib:disston-saw-tool-and-file-book-1929#page=38)).
   - **Rip:** the same, but the file held **straight across** ([Disston, p. 39](lib:disston-saw-tool-and-file-book-1929#page=39)).
5. **Side-dress** for fine work in dry hardwood: rub an oilstone once along each side of the teeth
   ([Brace & Mayne, p. 208](lib:brace-and-mayne-farm-shop-work-1915#page=208)).

![Two drawings from above of a crosscut saw in a clamp. First position: the saw's handle to the right, the file in the teeth at the point end with its handle swung toward the point, and where to stand, at that end in front of the saw. Second position: the saw turned round, handle to the left, the file again swung toward the point, and where to stand at that end](img:WOODWORKING-GUIDE/filing-a-crosscut-saw.png)
*Filing a crosscut saw: the file's handle swung toward the point, from one side and then the other ([Disston, p. 38](lib:disston-saw-tool-and-file-book-1929#page=38)).*

Soft wood takes a long, sharp bevel; hardwood a blunter tooth ([Brace & Mayne, pp. 206–207](lib:brace-and-mayne-farm-shop-work-1915#page=206);
[🖼️ three tooth shapes](lib:brace-and-mayne-farm-shop-work-1915#page=207)). **A saw that runs to one side** has longer or wider-set
teeth on that side; file and set them evenly ([Brace & Mayne, p. 190](lib:brace-and-mayne-farm-shop-work-1915#page=190)).
**One that grabs and kinks** has "too much angle and too heavy a set" ([Disston, p. 40](lib:disston-saw-tool-and-file-book-1929#page=40)).
Two-person crosscut saws need raker gauges and special tools ([*Saws That Sing*, pp. 24–26](lib:saws-that-sing#page=24)).

📚 **Go deeper:** [Disston *Saw, Tool and File Book*, pp. 34–41](lib:disston-saw-tool-and-file-book-1929#page=34) — the whole job step by step; [USFS *Crosscut Saw Manual*](lib:usfs-crosscut-saw-manual) — big saws; [Nicholson *Files and Rasps*](lib:nicholson-treatise-on-files) — files. Pictures: [Hand saw](wiki:Hand_saw).

## 🌳 Which wood for which job
<!-- fold: Woods for handles, pegs, furniture and outdoor work, and salvaged wood -->

| Job | Good woods |
|---|---|
| **Axe, hammer and maul handles** | **Hickory**: second growth, white sapwood, no more than 17 rings per inch ([*An Ax to Grind*, p. 26](lib:usfs-an-ax-to-grind#page=26)). Birch beats maple ([Brace & Mayne, p. 87](lib:brace-and-mayne-farm-shop-work-1915#page=87)) |
| **Shovel, rake, fork and hoe handles** | **Ash**, used for "nonstriking tool handles" ([Wood Handbook, p. 19](lib:wood-handbook#page=19)) |
| **Pegs, dowels, wedges, mallets** | Beech, birch or oak ([Griffith, p. 100](lib:griffith-essentials-of-woodworking#page=100)), seasoned ([*Timber*, p. 85](lib:timber-as-a-construction-material#page=85)) |
| **Furniture, boxes, shelves** | Pine, maple, birch, cherry, walnut, oak ([Griffith, pp. 149–157](lib:griffith-essentials-of-woodworking#page=149)) |
| **Carving** | Basswood, "a favorite of wood carvers" ([Wood Handbook, p. 19](lib:wood-handbook#page=19)) |
| **Touching the ground** | Heartwood rated "very resistant": black locust, mulberry, Osage-orange, Pacific yew ([Wood Handbook, p. 316](lib:wood-handbook#page=316)) |
| **Outdoors, off the ground** | "Resistant" heartwood: the cedars, junipers, white oaks, black walnut (same page) |

Toughest first: hickory, ironwood, rock elm, birch, oak, ash ([Brace & Mayne, p. 177](lib:brace-and-mayne-farm-shop-work-1915#page=177)).
Heartwood is usually better, but not in hickory and ash ([p. 176](lib:brace-and-mayne-farm-shop-work-1915#page=176)).
Ash, maple, hickory, pine, true fir and tanoak rot outdoors ([Wood Handbook, p. 316](lib:wood-handbook#page=316)).

**Our own trees.** Hickory does not grow here: the Wood Handbook's list of western hardwoods is red alder,
Oregon ash, aspen, paper birch, cottonwood, bigleaf maple, California black oak, Oregon white oak and tanoak
([Wood Handbook, Table 2–1, p. 18](lib:wood-handbook#page=18)). Decay ratings are for heartwood
([p. 316](lib:wood-handbook#page=316)).

| Local tree | Use it for | What to know |
|---|---|---|
| [Oregon ash](wiki:Fraxinus_latifolia) | Shovel, rake, fork and hoe handles; axe and hammer handles when there is no hickory | In the white-ash group; "somewhat lower strength" than eastern white ash, "but it is used for similar purposes" ([p. 18](lib:wood-handbook#page=18), [p. 19](lib:wood-handbook#page=19)). Rots in the ground |
| [Oregon white oak](wiki:Quercus_garryana) | Mallets, pegs, wedges, wheel parts, barrels, anything outdoors | In the white-oak group: the heartwood "has good decay resistance" ([p. 24](lib:wood-handbook#page=24)). Like all oak it "shrinks and checks badly" while drying ([Griffith, p. 155](lib:griffith-essentials-of-woodworking#page=155)) |
| [Pacific madrone](wiki:Arbutus_menziesii) | Small hard parts: mallet heads, handles, spoons *(rule of thumb)* | Very hard and heavy; it checks and warps badly as it dries, so rough it out green and dry it slowly *(rule of thumb)* |
| [Bigleaf maple](wiki:Acer_macrophyllum) | Furniture, bowls, spoons, boxes | In the soft-maple group, used for "furniture ... wooden ware" ([p. 23](lib:wood-handbook#page=23)). Rots outdoors |
| [Douglas-fir](wiki:Douglas_fir) | Benches, shelves, framing | Used "mostly for building and construction" ([p. 26](lib:wood-handbook#page=26)); moderately decay resistant |
| [Incense-cedar](wiki:Calocedrus_decurrens) | Posts, shakes, chests, outdoor work | "Low shrinkage and is easy to dry, with little checking or warping"; used for fence posts and split shingles ([p. 28](lib:wood-handbook#page=28)). Decay resistant |
| [Ponderosa pine](wiki:Pinus_ponderosa) and sugar pine | Shelves, boxes, doors, cabinets | Ponderosa "has little tendency to warp and twist" ([p. 29](lib:wood-handbook#page=29)). Rots outdoors |
| [Tanoak](wiki:Notholithocarpus) | Firewood more than lumber | Heavy and hard, but it shrinks more than white oak, can collapse while drying, and "is quite susceptible to decay" ([p. 24](lib:wood-handbook#page=24)) |

Port-Orford-cedar heartwood is resistant to decay too, and Pacific yew "very resistant"
([p. 316](lib:wood-handbook#page=316)): see the [Shelter guide](guide:SHELTER-BUILDING-GUIDE#rot-termites-carpenter-ants-and-woods-that-last).

**Salvaged wood:** pull every nail before sawing or boring ([Disston, p. 10](lib:disston-saw-tool-and-file-book-1929#page=10);
[Griffith, p. 56](lib:griffith-essentials-of-woodworking#page=56)). **Pressure-treated wood:** never burn it, keep its
sawdust off you, and never use it for cutting boards, food or feed bins, or hive parts that touch honey
([Wood Handbook, p. 329](lib:wood-handbook#page=329)).

📚 **Go deeper:** [Wood Handbook ch. 2](lib:wood-handbook#page=18) — every American tree's wood and uses; [Brace & Mayne, pp. 175–180](lib:brace-and-mayne-farm-shop-work-1915#page=175) — hardness, toughness and woods for each job. Pictures: [Hickory](wiki:Hickory), [Ash](wiki:Fraxinus).

## 💧 Green wood, drying and warping
<!-- fold: How wood shrinks, checks and warps, and how to dry boards -->

Green (fresh-cut) wood is easier to split and shape *(rule of thumb)*; dry wood is "much stronger"
([Brace & Mayne, p. 177](lib:brace-and-mayne-farm-shop-work-1915#page=177)).

**How wood moves** ([Wood Handbook, p. 84](lib:wood-handbook#page=84); [🖼️ drawing](lib:wood-handbook#page=84)): it shrinks
most along the growth rings, about half as much across them, and slightly along its length. So log ends **check**
(crack), flat-sawn boards **cup** away from the heart of the tree
([Brace & Mayne, p. 178](lib:brace-and-mayne-farm-shop-work-1915#page=178); [🖼️ drawing](lib:brace-and-mayne-farm-shop-work-1915#page=178)),
and tool handles work loose (Wood Handbook, p. 84). Warp comes as bow, crook, twist, cup, oval or diamond
([p. 301](lib:wood-handbook#page=301); [🖼️ drawing](lib:wood-handbook#page=304)).

![The end of a log with flat, square and round pieces drawn at different places in it, each shown as it changes in drying: boards cup away from the heart, squares cut with the rings at a slant turn into diamonds, and a round piece turns oval](img:WOODWORKING-GUIDE/how-wood-shrinks.png)
*How pieces change shape as they dry, by where they were cut from the log; wood shrinks about twice as much along the rings as across them ([Wood Handbook, p. 84](lib:wood-handbook#page=84)).*

**Work with it:**
- **Rough out green, finish dry.** A dry peg or tenon set into green wood is gripped tighter as the wood shrinks round it *(rule of thumb)*.
- **Edge-glued boards:** turn every other one so the rings curve the opposite way and the warping cancels
  ([Brace & Mayne, p. 178](lib:brace-and-mayne-farm-shop-work-1915#page=178)).
- Keep boards narrower than **eight times their thickness**; boards with the rings on edge cup and check less
  ([Wood Handbook, p. 366](lib:wood-handbook#page=366)).
- **No green wood in doors and windows**, and cut green parts oversize ([*Timber*, p. 88](lib:timber-as-a-construction-material#page=88)).

**Drying boards:** stack under cover, off the ground, with **sticks between every layer**; **seal or paint the ends**;
dry hardwoods slowly or they check ([Brace & Mayne, p. 179](lib:brace-and-mayne-farm-shop-work-1915#page=179)). A 1-in
board takes about a year ([*Timber*, p. 45](lib:timber-as-a-construction-material#page=45)). Here, lumber dries fast in the dry summers and hardly at all in the wet winters: stack it in spring,
under a roof with open sides *(rule of thumb)*.
Furniture wood should be drier than air-drying gets it outdoors, 6–8% moisture for hardwood
([Wood Handbook, p. 297](lib:wood-handbook#page=297)): finish drying it indoors for some weeks *(rule of thumb)*. With no
moisture meter, oven-dry a weighed sample and compare ([*Timber*, p. 44](lib:timber-as-a-construction-material#page=44)).
More on stacking lumber and hewing is in [Shelter & Building](guide:SHELTER-BUILDING-GUIDE#hand-tool-carpentry-and-drying-lumber).

📚 **Go deeper:** [Wood Handbook ch. 4](lib:wood-handbook#page=84) and [ch. 13](lib:wood-handbook#page=297) — shrinking, drying and warp. Pictures: [Wood drying](wiki:Wood_drying).

## 🪓 Splitting and riving green wood
<!-- fold: Splitting logs into bolts and riving thin boards with a froe -->

A split follows the grain, so split stock is stronger than sawn *(rule of thumb)*: for dowels, "split, not saw, these
pieces" ([Griffith, p. 100](lib:griffith-essentials-of-woodworking#page=100)), and treenails (wooden pegs) are split from
straight-grained oak ([*Shifts and Expedients*, p. 315](lib:shifts-and-expedients#page=315)).

**Riving with a froe** ([Kephart, pp. 207–213](lib:kephart-camping-and-woodcraft-vol-2#page=207)):
1. **Pick a sound, straight, springy tree** with bark ridges running straight up the trunk. Cedar rives best; oak and
   pine work.
2. Saw a cut 2½–3 ft long and split it in half with an axe and mallet: tap lightly along the line and strike hard only
   at the end, or the split runs off.
3. **Always split through the middle.** A log splits straight through the center from any side; splits parallel to
   that wander ([🖼️ splitting rails](lib:kephart-camping-and-woodcraft-vol-2#page=207)). Halve, quarter, then make
   **bolts** about 5 in across, and knock off the tough heart ([🖼️ bolts](lib:kephart-camping-and-woodcraft-vol-2#page=211)).
4. Hold the bolt in a **riving brake** (a forked limb, or a small log staked beside a big one)
   ([🖼️ brake](lib:kephart-camping-and-woodcraft-vol-2#page=212)) and drive the froe into the end with a mallet.
5. **If the split runs toward one side,** turn the **thicker** side down, open the cleft, and bear down on that side while
   you work the froe ([🖼️ drawing](lib:kephart-camping-and-woodcraft-vol-2#page=213)).

![Drawing of a man riving with a froe: the bolt stands on end in a brake made of a small log laid across a big one, the froe's blade in the top of the bolt, its handle in one hand and a wooden mallet raised in the other](img:WOODWORKING-GUIDE/riving-in-a-brake.png)
*Step 4: the bolt held in a brake while the froe is driven in ([Kephart, p. 212](lib:kephart-camping-and-woodcraft-vol-2#page=212)).*

![Drawing of a man riving a bolt that rests at a slant in the brake: he leans over it, bearing down on the thicker lower part while he works the froe, so the split runs back to the middle](img:WOODWORKING-GUIDE/springing-the-rift.png)
*Step 5: steering a split that runs off, the thicker side down ([Kephart, p. 213](lib:kephart-camping-and-woodcraft-vol-2#page=213)).*

A froe is a blunt blade about 14 in long on a green-stick handle ([Kephart, p. 211](lib:kephart-camping-and-woodcraft-vol-2#page=211)).
Splitting firewood safely is in [Firewood](guide:FIREWOOD-GUIDE#splitting); shingles in
[Shelter & Building](guide:SHELTER-BUILDING-GUIDE#splitting-and-laying-your-own-shingles-and-shakes).

📚 **Go deeper:** [Kephart *Camping and Woodcraft* vol. 2, "Axemanship"](lib:kephart-camping-and-woodcraft-vol-2#page=207) — splitting, riving and hewing. Pictures: [Froe](wiki:Froe).

## 📏 Measuring, sawing and planing
<!-- fold: Marking with knife and gauge, sawing to a line, planing flat and square, boring -->

**Marking** ([Griffith, pp. 17–24](lib:griffith-essentials-of-woodworking#page=17)): stand the rule on edge and mark
with a knife point. Mark across the grain with knife and try-square, along it with the marking gauge, set from a rule
("the graduations on the beam are seldom reliable"). Light lines; pencil only on rough wood. **Plane one face and one
edge true, mark them, and measure and square everything from those two**
([p. 47](lib:griffith-essentials-of-woodworking#page=47)). Squaring big layouts with 3-4-5 is in
[Practical Math](guide:PRACTICAL-MATH-GUIDE#right-angles-and-layout).

**Sawing to a line** ([Disston, p. 10](lib:disston-saw-tool-and-file-book-1929#page=10); [🖼️ positions](lib:disston-saw-tool-and-file-book-1929#page=10)):
start on the **waste side**, thumb against the blade, with a few pulls back. Crosscut at about 45° to the board, rip at
about 60°, with long full strokes, and hold up the waste so it doesn't split off. For joints the cut sits in the waste
**just touching the line** ([Griffith, p. 32](lib:griffith-essentials-of-woodworking#page=32);
[🖼️ good and bad sawing](lib:griffith-essentials-of-woodworking#page=33)). If it binds, tap a wedge into the cut
([Griffith, p. 30](lib:griffith-essentials-of-woodworking#page=30)).

**Setting the plane:** the iron sticks out about the thickness of a sheet of paper, evenly — sight down the sole to
check ([Griffith, p. 39](lib:griffith-essentials-of-woodworking#page=39); [🖼️ sighting](lib:griffith-essentials-of-woodworking#page=39)).
Lay a plane on its side ([p. 44](lib:griffith-essentials-of-woodworking#page=44)).

**Planing a board to size** ([Griffith, pp. 43–52](lib:griffith-essentials-of-woodworking#page=43)):
1. Read the grain and plane "downhill" with it; against it the wood tears.
2. **Face:** press the front knob as you start, the handle as you finish. Test with a straightedge along, across and
   corner to corner, and with **winding sticks** for twist ([🖼️ drawing](lib:griffith-essentials-of-woodworking#page=46)).
3. **Edge:** straight, and square to the face.
4. **Width and thickness:** gauge from the face edge and face side, and plane to the lines.
5. **Ends:** stop short of the far corner or it breaks off; work in from both edges, or use the shooting board
   ([pp. 50–51](lib:griffith-essentials-of-woodworking#page=50)).

**Boring:** sight the bit from two sides. For a clean hole, bore until the screw tip shows, then finish from the back
([Griffith, pp. 58–59](lib:griffith-essentials-of-woodworking#page=58)).

📚 **Go deeper:** [Griffith, Part I](lib:griffith-essentials-of-woodworking#page=17) — layout, sawing, planing, boring and chiseling, a drawing for each step. Pictures: [Try square](wiki:Try_square), [Steel square](wiki:Steel_square).

## 🔗 Joints
<!-- fold: Nailed, lap, dado, mortise and tenon, dovetail, and pegged joints with no glue -->

Lay out every joint with the knife from the face side and edge, number matching parts, and cut on the waste side
([Griffith, pp. 92–94](lib:griffith-essentials-of-woodworking#page=92)). A good fit goes together by hand but doesn't
fall apart under its own weight ([p. 97](lib:griffith-essentials-of-woodworking#page=97)). "Most joints are weak unless
triangulated" — braced ([*Timber*, p. 82](lib:timber-as-a-construction-material#page=82)).

**Nails and screws:** a nail at least **three times as long** as the wood it holds, two-thirds in the second piece,
driven at a slight angle toward its neighbor; nails across the grain hold better than with it
([FM 5-426, pp. 33–34](lib:fm-5-426-carpentry#page=33)). **Stagger** them rather than setting a row along one edge
([Brace & Mayne, p. 157](lib:brace-and-mayne-farm-shop-work-1915#page=157)). In hardwood, bore a shank-size hole in the top
piece and a smaller one in the bottom for a screw ([Griffith, pp. 87–88](lib:griffith-essentials-of-woodworking#page=87)).

**Lap and dado** (a dado is a groove across a board, as for a shelf): knife both sides, gauge the depth, saw on the waste
side down to the gauge lines, chisel out between, and pare to the lines
([Griffith, pp. 95–97](lib:griffith-essentials-of-woodworking#page=95); [🖼️ dado](lib:griffith-essentials-of-woodworking#page=94);
[🖼️ cross-lap](lib:griffith-essentials-of-woodworking#page=96)). When chopping to a line, chop 1/32 in inside it first:
the bevel pushes the chisel past the line ([p. 62](lib:griffith-essentials-of-woodworking#page=62)).

**Mortise and tenon** — "no joint has a greater variety of applications"
([Griffith, pp. 105–109](lib:griffith-essentials-of-woodworking#page=105); [🖼️ the order of cuts](lib:griffith-essentials-of-woodworking#page=109)):
- **Tenon:** knife the shoulders all round, gauge, **rip to the gauge lines first**, then saw the shoulders.
- **Mortise:** gauge with the **same settings** from the same face. Bore a row of holes and pare, or chop with a chisel
  as wide as the mortise, from the middle out to 1/8 in short of each end, then chop the ends to the lines last.

**Dovetails** ([Griffith, pp. 110–112](lib:griffith-essentials-of-woodworking#page=110); [🖼️ drawings](lib:griffith-essentials-of-woodworking#page=111)):
cut the tails first, flared about 1 in 6 for softwood and 1 in 8 for hardwood *(rule of thumb)*; stand them on the
second board, knife round them, and cut that board to fit. Glued dovetails and mortises should be pegged or screwed too
([Brace & Mayne, p. 202](lib:brace-and-mayne-farm-shop-work-1915#page=202)).

### Pegged and wedged joints: no glue, no nails
<!-- fold: Drawbored pegs, tenons wedged through holes, and making pegs -->

Oak furniture "put together with wooden pins or by means of mortise and tenon" lasts for centuries
([Leland, p. 84](lib:leland-a-manual-of-mending#page=84)).

**Drawbored mortise and tenon:** "a mortise-and-tenon joint with holes bored so that when a pin is driven through, the
joint becomes tighter" ([FM 5-426, p. 206](lib:fm-5-426-carpentry#page=206)). How *(rule of thumb)*:
1. Fit the joint. Bore the peg hole through the mortise sides only, a third of the way in from the shoulder side.
2. Push the tenon in, mark the hole's center on it, and take it out.
3. Bore the tenon **1/16–1/8 in closer to the shoulder** than the mark (less in softwood).
4. Assemble and drive a tapered, **split, dry hardwood** peg through: the offset pulls the shoulder tight.

![Two drawings of a drawbored mortise and tenon. First: the post's peg hole is a distance X in from its face; on the tenon the same distance X from the shoulder is marked, and the tenon's hole is bored 1/16 to 1/8 in nearer the shoulder than the mark. Second: put together, a split, dry, tapered hardwood peg driven through both holes bends through them and pulls the shoulder tight against the post](img:WOODWORKING-GUIDE/drawbore-peg-holes.svg)
*The tenon's hole sits a little nearer the shoulder, so the peg pulls the joint tight (a diagram drawn for this guide).*

Pegs should be "seasoned hardwood that will not swell or shrink", placed so gravity tightens them, and the joint's shape,
not the peg, should carry the load ([*Timber*, p. 85](lib:timber-as-a-construction-material#page=85)).

**Wedged through a hole:** round the end to fit a bored hole, saw a slit down it, drive it through, drive a hardwood wedge
into the slit, and saw flush ([Brace & Mayne, pp. 41–42](lib:brace-and-mayne-farm-shop-work-1915#page=41);
[🖼️ drawing](lib:brace-and-mayne-farm-shop-work-1915#page=42)). Turn the slit **across** the grain of the piece it passes
through, or "driving in the wedges will be apt to split the bars" ([p. 111](lib:brace-and-mayne-farm-shop-work-1915#page=111)).

![Two drawings of a round tenon wedged through a bored hole. Cut through the middle: the leg's rounded end passes through the seat, a hardwood wedge driven into a saw slit in its end spreads it tight, and it is then sawn off flush. Seen from above: right, the slit and wedge across the seat's grain; wrong, along the grain, which splits the seat](img:WOODWORKING-GUIDE/wedged-through-tenon.svg)
*Wedge across the grain of the piece the tenon passes through (a diagram drawn for this guide).*

**Pegs and dowels:** split straight beech, birch or oak into sticks 8–10 in long, plane them roughly round, and drive them
through a **dowel plate** (steel with sized holes) with a mallet, never a hammer
([Griffith, p. 100](lib:griffith-essentials-of-woodworking#page=100); [🖼️ drawing](lib:griffith-essentials-of-woodworking#page=100)).

📚 **Go deeper:** [Griffith Part II, "Simple Joinery"](lib:griffith-essentials-of-woodworking#page=92) — every joint step by step; [Griffith Appendix I](lib:griffith-essentials-of-woodworking#page=172) — dozens more joints drawn; [*Timber*, pp. 82–86](lib:timber-as-a-construction-material#page=82) — joints, pegs and lashings in buildings. Pictures: [Woodworking joints](wiki:Joinery), [Mortise and tenon](wiki:Mortise_and_tenon), [Dovetail joint](wiki:Dovetail_joint).

## 🔨 Tool handles
<!-- fold: Making a handle from split wood and fitting it to an axe, hammer or shovel -->

Checking an axe's hang, wedging and filing it are in [Blacksmithing & Hand Tools](guide:BLACKSMITHING-GUIDE#keeping-hand-tools-working);
this is the wood.

**The wood:** hickory for striking tools, ash for the rest (Oregon ash grows here; hickory does not)
([*Handtools*, p. 53](lib:usfs-mtdc-handtools-for-trail-work-2005#page=53)). The grain must run **parallel to the length
and to the wedge slot**: "If the handle is not straight-grained, it is likely to break"
([*An Ax to Grind*, p. 26](lib:usfs-an-ax-to-grind#page=26); [🖼️ good and bad grain](lib:usfs-an-ax-to-grind#page=26)).
Keep handles bare: paint hides flaws ([*Handtools*, p. 53](lib:usfs-mtdc-handtools-for-trail-work-2005#page=53)).

![Two axe handles seen from the side: good, the grain running straight along the handle; bad, the grain running out across it. Below, two handle ends seen end-on with the wedge slot: good, the grain lines parallel to the slot; bad, the grain across the slot](img:WOODWORKING-GUIDE/handle-grain.png)
*The grain runs along the handle and parallel to the wedge slot ([*An Ax to Grind*, p. 26](lib:usfs-an-ax-to-grind#page=26)).*

**Making one:**
1. **Rive** a blank a little bigger than the handle (see [Splitting and riving](#splitting-and-riving-green-wood)).
2. **Rough it out green** on a shaving horse, with the old handle as a pattern. Let it dry a few weeks *(rule of thumb)*,
   then shave to final size, since shrinking wood loosens handles ([Wood Handbook, p. 84](lib:wood-handbook#page=84)).
3. **Shape:** saw down to the deepest point of each curve and chisel toward the cut; finish with spokeshave and plane. A
   hammer handle is oval, not round ([Brace & Mayne, pp. 88–90](lib:brace-and-mayne-farm-shop-work-1915#page=88)). Axe
   handles run 32–36 in for 3–6 lb heads ([*An Ax to Grind*, p. 27](lib:usfs-an-ax-to-grind#page=27)).

**Fitting it** ([*Handtools*, pp. 54–56](lib:usfs-mtdc-handtools-for-trail-work-2005#page=54); [🖼️ photographed step by step](lib:usfs-mtdc-handtools-for-trail-work-2005#page=55)):
1. **Clear the eye:** saw the old handle off at the head and drive the stub out **through the large end of the eye**
   ([TM 9-243, p. 128](lib:tm-9-243#page=128)), drilling holes in it first if it is tight.
2. Saw the wedge slot **two-thirds of the depth of the head**, and draw center lines on the end.
3. Shave and fit, tapping the head on and off, until it sits squarely **1/4–3/8 in above** its final place. Cut a small
   square shoulder there and smooth the wood just below the head.
4. Drive a **long, tapered hardwood wedge** the full width of the slot, tapping wedge and handle end in turn until the
   hammer bounces equally off both. No metal wedges: they crush the wood (p. 53).
5. Trim flush and rub in **raw linseed oil**, again now and then.

Soaking a loose head in water or linseed oil tightens it for a day; fix it properly soon (p. 54). **Shovels and forks**
with a socket: fit the end to fill the socket, drive it home, and screw or rivet through the socket's hole *(rule of thumb)*.

📚 **Go deeper:** [*Handtools for Trail Work*, pp. 53–56](lib:usfs-mtdc-handtools-for-trail-work-2005#page=53) — rehandling any tool, photographed; [*An Ax to Grind*, pp. 24–33](lib:usfs-an-ax-to-grind#page=24) — choosing and hanging an axe handle; [Brace & Mayne Lesson XIII](lib:brace-and-mayne-farm-shop-work-1915#page=87) — a hammer handle. Pictures: [Hickory](wiki:Hickory), [Drawknife](wiki:Drawknife).

## 🛠️ Things worth making
<!-- fold: A workbench, shaving horse, sawbuck, stools, shelves, boxes, a ladder, rakes and a wheelbarrow -->

**Workbench** ([Brace & Mayne, pp. 154–160](lib:brace-and-mayne-farm-shop-work-1915#page=154); [🖼️ drawing](lib:brace-and-mayne-farm-shop-work-1915#page=155)):
**36 in high**; a top of 2 × 12 in hardwood planks 6 ft long on 2 × 4 legs, braced between the legs; a vise jaw of
2 × 6 maple on a bench screw; and a **bench stop**, a hardwood stick 1 in square driven through a square hole near the
end and tapped up or down.

**Shaving horse** ([*Handy Farm Devices*, p. 18](lib:handy-farm-devices#page=18); [🖼️ drawing](lib:handy-farm-devices#page=18)):
a 2-in plank to sit astride, a slanting platform on it, and a clamp head "of heavy hard wood that is tough and will not
split" on an arm down to a foot treadle. Push the treadle and the work is held, leaving both hands for the drawknife.

![Side view of a shaving horse: a thick plank on four legs to sit astride, a sloping platform on it, and a swinging arm through the plank on a pivot pin, with a heavy hardwood clamp head at the top over the work and a foot bar at the bottom. Pushing the foot bar away swings the head down onto the work](img:WOODWORKING-GUIDE/shaving-horse.svg)
*One common pattern: push the foot bar away and the head grips the work (a diagram drawn for this guide).*

**Sawbuck:** oak legs halved together and a hickory crossbar wedged through bored holes
([Brace & Mayne, pp. 36–42](lib:brace-and-mayne-farm-shop-work-1915#page=36); [🖼️ drawing](lib:brace-and-mayne-farm-shop-work-1915#page=39)).

**Stools and tables:** a one-legged stool or camp table is a pillar cut to fit a large auger hole in the seat, then
split and wedged; a wider top is boards treenailed edge to edge ([*Shifts and Expedients*, p. 375](lib:shifts-and-expedients#page=375);
[🖼️ drawing](lib:shifts-and-expedients#page=375)). Wedge three or four legs into a slab the same way, splayed a little,
with dry legs in a greener seat *(rule of thumb)*.

**Shelves and boxes:** let shelves into dadoes, "used in the making of shelving"
([Griffith, p. 95](lib:griffith-essentials-of-woodworking#page=95)), and brace the case. Nail rough boxes; dovetail tool
boxes ([p. 110](lib:griffith-essentials-of-woodworking#page=110)); screw drawer bottoms in
([Leland, p. 89](lib:leland-a-manual-of-mending#page=89)).

**Ladder** ([Brace & Mayne, pp. 101–111](lib:brace-and-mayne-farm-shop-work-1915#page=101); [🖼️ drawing](lib:brace-and-mayne-farm-shop-work-1915#page=102)):
white-oak rails and steps held with carriage bolts, each hole bored from both sides to meet in the middle. **Round rungs
without a lathe:** plane a stick square, gauge half its diagonal from every side, plane off the corners to make eight
sides, then the eight corners, and sand round ([pp. 109–110](lib:brace-and-mayne-farm-shop-work-1915#page=109)). A
**log ladder** is a log with long treenails driven through auger holes about 2 ft apart
([*Shifts and Expedients*, p. 335](lib:shifts-and-expedients#page=335)). Use straight-grained, knot-free wood, look for
cracks and rot each season, and set the foot out a quarter of the height *(rule of thumb)*.

**Rakes, mallets and wheelbarrows** *(rule of thumb; no book here covers wooden rakes)*: a rake head of ash or oak, its
teeth of split dry hardwood driven into holes a shade small; a mallet whose handle goes through a hole that widens
toward the striking end, so each blow tightens it; a barrow whose two long ash or oak handles are its frame. Put the load
over one big wheel — see [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE#wheelbarrows-handcarts-sledges-and-travois).

📚 **Go deeper:** [Brace & Mayne *Farm Shop Work*](lib:brace-and-mayne-farm-shop-work-1915#page=15) — 27 farm projects with working drawings; [*Handy Farm Devices*](lib:handy-farm-devices#page=13) — shop gadgets from scrap; [*Shifts and Expedients*](lib:shifts-and-expedients#page=375) — camp furniture with axe and auger. Pictures: [Shaving horse](wiki:Shaving_horse), [Workbench](wiki:Workbench).

## 🚪 Repairing doors, windows and furniture
<!-- fold: Sticking and sagging doors, broken chair legs, warped panels and sticking drawers -->

**Doors:** a door "must not be fitted perfectly tight; it must have a little play"; plane where it rubs
([Griffith, p. 121](lib:griffith-essentials-of-woodworking#page=121)), and leave about 1/4 in round a plank door
([FM 5-426, p. 134](lib:fm-5-426-carpentry#page=134)). Dried wood swells again in damp weather
([*Timber*, p. 44](lib:timber-as-a-construction-material#page=44)), so trim a sticking door in the wet season, not the
dry *(rule of thumb)*. **A new plank door:** boards on two crosspieces 6 in from the ends, with a diagonal brace from the
top crosspiece at the **latch side** down to the bottom one at the **hinge side**
([FM 5-426, p. 134](lib:fm-5-426-carpentry#page=134)). **Windows:** see
[Shelter & Building](guide:SHELTER-BUILDING-GUIDE#reglazing-and-saving-windows).

**Furniture** ([Leland, pp. 85–89](lib:leland-a-manual-of-mending#page=85)):
- **Broken chair leg:** fit the pieces, bore across the break, glue, and drive a screw through before the glue dries.
  A **stepped splice** — both ends cut to matching steps, glued and screwed — makes it "stronger than before"
  ([p. 87](lib:leland-a-manual-of-mending#page=87); [🖼️ drawing](lib:leland-a-manual-of-mending#page=87)).
- **Loose joints:** take apart, scrape off old glue *(rule of thumb)*, re-glue and peg
  ([Brace & Mayne, p. 202](lib:brace-and-mayne-farm-shop-work-1915#page=202)). If nothing holds, bore through and twist
  wire round ([Leland, p. 88](lib:leland-a-manual-of-mending#page=88)).
- **Warped panel:** wet the hollow side, weight it flat, then screw strips across the grain on the back
  ([pp. 87–88](lib:leland-a-manual-of-mending#page=87)). **Sticking drawers:** plane where they rub
  ([p. 88](lib:leland-a-manual-of-mending#page=88)).
- **Holes and chips:** fill with fine sawdust of the same wood mixed with glue; it dries to carve and sand like wood
  ([p. 89](lib:leland-a-manual-of-mending#page=89)).

**Rot in sills, posts and steps:** probe with an ice pick, because rot hides under a sound surface
([Wood Handbook, p. 368](lib:wood-handbook#page=368)). Cut back to sound wood, scarf in new
([*Timber*, p. 82](lib:timber-as-a-construction-material#page=82)), and stop the water
([Shelter & Building](guide:SHELTER-BUILDING-GUIDE#rot-termites-carpenter-ants-and-woods-that-last)).

📚 **Go deeper:** [Leland *A Manual of Mending and Repairing*](lib:leland-a-manual-of-mending#page=84) — wood, furniture and glue; [FM 5-426 ch. 8](lib:fm-5-426-carpentry#page=133) — doors and windows; [Griffith, pp. 120–123](lib:griffith-essentials-of-woodworking#page=120) — fitting and hinging a door.

## 🫙 Glue without a store
<!-- fold: Hide glue from skins and bones, casein glue from milk, and clamping -->

**Hide glue:** "Strippings of hide, bone, horn, hoofs, etc., are boiled to a jelly"
([Griffith, p. 88](lib:griffith-essentials-of-woodworking#page=88); [PA *Additives to Clay*, p. 4](lib:additives-to-clay-organic#page=4)).
To make it *(rule of thumb)*: simmer clean rawhide scraps, hair and fat removed, for hours without a hard boil; strain,
let it jell, slice thin and dry. Only from healthy animals: anthrax ([p. 3](lib:additives-to-clay-organic#page=3)).

**Using it** ([Griffith, pp. 88–91](lib:griffith-essentials-of-woodworking#page=88); [Brace & Mayne, pp. 201–204](lib:brace-and-mayne-farm-shop-work-1915#page=201)):
1. Soak overnight in cold water; melt in a **double boiler** (a pot inside a pot of hot water).
2. Use it hot and thin; **warm the wood** first ([Leland, p. 86](lib:leland-a-manual-of-mending#page=86)).
3. Size **end grain** with a first thin coat, let it partly dry, then glue.
4. Spread thinly on both faces, clamp, and wipe off the squeeze-out with a warm wet cloth. About ten hours in clamps
   ([Griffith, p. 99](lib:griffith-essentials-of-woodworking#page=99)).
5. Make it fresh daily: glue kept hot half a day loses half its strength
   ([Brace & Mayne, p. 204](lib:brace-and-mayne-farm-shop-work-1915#page=204)).

A good glued edge joint is stronger than the wood ([Griffith, p. 98](lib:griffith-essentials-of-woodworking#page=98)).
But hide glue "will not hold if kept in a damp place" ([Brace & Mayne, p. 204](lib:brace-and-mayne-farm-shop-work-1915#page=204)).
For glue that stays liquid cold: 2 oz glue, 3 oz vinegar, 2 oz water, 1 oz alcohol
([*Household Discoveries*, p. 331](lib:household-discoveries#page=331)).

**Casein (milk) glue** is "water-resistant but not waterproof": soured skim-milk curd, dried and ground, mixed with
water and slaked lime ([VITA, pp. 313–314](lib:village-technology-handbook-vita-usaid#page=313)); details and pine-pitch
glue are in the [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE#glue-patching-and-waterproofing). **Outdoors,
use pegs, wedges and bolts instead.**

**No clamps?** Wedges between blocks on a bar ([Griffith, p. 90](lib:griffith-essentials-of-woodworking#page=90)), weights,
or a rope loop twisted tight with a stick *(rule of thumb)*; or **rub** a short edge joint together until it grips
([p. 91](lib:griffith-essentials-of-woodworking#page=91)).

📚 **Go deeper:** [Brace & Mayne Lesson XXXI](lib:brace-and-mayne-farm-shop-work-1915#page=201) — glue and clamping; [VITA, p. 313](lib:village-technology-handbook-vita-usaid#page=313) — casein glue. Pictures: [Hide glue](wiki:Animal_glue).

## 🛢️ Finishes, outdoor wood and rot
<!-- fold: Oil, wax and food-safe finishes, charring, and keeping outdoor wood sound -->

**Indoors:**
- **Oil:** linseed or tung oil soaks in. "Apply two or more coats of oil followed by a paste wax"
  ([Wood Handbook, p. 388](lib:wood-handbook#page=388)). Raw linseed oil is the tool-handle finish
  ([*Handtools*, p. 54](lib:usfs-mtdc-handtools-for-trail-work-2005#page=54)).
- **Wax:** beeswax with a third its volume of turpentine, melted in a double boiler away from flame
  ([Griffith, p. 179](lib:griffith-essentials-of-woodworking#page=179)); rub on very thin and polish after 5–10 minutes. It
  "will not stand wetting" but is easy to repair ([pp. 165–166](lib:griffith-essentials-of-woodworking#page=165)).
- **Bowls, spoons, cutting boards:** drying oils (tung, linseed, walnut) take weeks to cure; kitchen oils go rancid and
  feed mildew; the simplest board finish is melted paraffin wax, heated gently, never over a flame
  ([Wood Handbook, p. 389](lib:wood-handbook#page=389)).
- **Stain:** logwood boiled in water makes brown; vinegar that has stood a week on iron filings, brushed over it, black
  ([Griffith, p. 179](lib:griffith-essentials-of-woodworking#page=179)).

**Outdoors:**
- **Dry wood doesn't rot.** Air-dry wood (below about 20% moisture) is safe; rot needs it soaked past about 30%
  ([Wood Handbook, p. 314](lib:wood-handbook#page=314)). Keep wood off the ground and let every joint drain *(rule of thumb)*.
- **Seal end grain** ([Wood Handbook, p. 368](lib:wood-handbook#page=368)). Paint slows wetting, but "paint is not a
  preservative" ([p. 377](lib:wood-handbook#page=377)).
- Bare wood erodes only about 1/4 in a century, but checks, mildews and rots unless it is decay-resistant heartwood
  ([Wood Handbook, pp. 366, 371](lib:wood-handbook#page=371)).
- **Charring** gives "temporary protection ... only for cheaper timber, such as fence posts"
  ([*Timber*, p. 48](lib:timber-as-a-construction-material#page=48)). It doesn't replace durable wood.

**Fire:** oily rags "are subject to spontaneous combustion": burn them, or keep them in a bucket of water
([Griffith, p. 164](lib:griffith-essentials-of-woodworking#page=164); [*An Ax to Grind*, p. 34](lib:usfs-an-ax-to-grind#page=34)).

📚 **Go deeper:** [Wood Handbook ch. 16](lib:wood-handbook#page=366) — weathering and every finish; [ch. 14](lib:wood-handbook#page=314) — decay; [Griffith ch. XIII](lib:griffith-essentials-of-woodworking#page=158) — finishing by hand. Pictures: [Linseed oil](wiki:Linseed_oil), [Beeswax](wiki:Beeswax), [Yakisugi](wiki:Yakisugi).

## 🩹 Working safely
<!-- fold: Cuts, the drawknife, putting tools down, splitting and sharpening -->

- **Both hands behind the edge;** fasten the work so they're free ([Griffith, pp. 61–62](lib:griffith-essentials-of-woodworking#page=61)).
- **The drawknife comes toward you.** Clamp the work, start each stroke with straight arms, keep your fingers off the
  blade's corners, and carry it by one handle at your side ([*Handtools*, p. 45](lib:usfs-mtdc-handtools-for-trail-work-2005#page=45)).
  End each stroke short of your body *(rule of thumb)*.
- **Dull tools are dangerous:** they take "undue strength" ([Griffith, p. 11](lib:griffith-essentials-of-woodworking#page=11)),
  and forcing an edge is how it slips into a hand *(rule of thumb)*.
- **Edges away when you put a tool down.** Never stand an axe on the floor or hang a saw where it can scratch a leg
  ([Disston, p. 42](lib:disston-saw-tool-and-file-book-1929#page=42)).
- **Sharpening:** gloves at the file and stone, eye protection at the grinder
  ([*Handtools*, pp. 49, 52](lib:usfs-mtdc-handtools-for-trail-work-2005#page=52)). Test an edge with "just a touch" of the
  calloused thumb, never a finger ([Griffith, p. 72](lib:griffith-essentials-of-woodworking#page=72)).
- **Splitting:** goggles, boots, people back, and never strike steel with an axe — see [Firewood](guide:FIREWOOD-GUIDE#splitting).
- **Cuts:** see [Field Care](guide:FIELD-CARE-GUIDE).

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| A walnut stain of "powdered bichromate of potash" ([Griffith, p. 179](lib:griffith-essentials-of-woodworking#page=179)) | Chrome is one of the old poisons to skip ([Clothing & Leather guide](guide:CLOTHING-LEATHER-GUIDE)). Use the logwood brown or iron-in-vinegar black on the same page |
| Oil stains with "medium chrome yellow" ([Griffith, p. 180](lib:griffith-essentials-of-woodworking#page=180)) | A lead pigment *(rule of thumb)*. Use the umbers and siennas on the same page |
| Clean oilstones by "soaking in dilute sulphuric acid or lye" ([Brace & Mayne, pp. 211–212](lib:brace-and-mayne-farm-shop-work-1915#page=211)) | Kerosene, or citrus solvent and a brush ([*Handtools*, p. 52](lib:usfs-mtdc-handtools-for-trail-work-2005#page=52)) |
| Liquid glue made with "strong nitric acid" ([*Household Discoveries*, p. 331](lib:household-discoveries#page=331); [Leland, pp. 85–86](lib:leland-a-manual-of-mending#page=85)) | The vinegar glue on the same page; Leland says strong vinegar works too |
| Keep mucilage with "corrosive sublimate" (mercury), carbolic acid or creosote ([*Household Discoveries*, p. 331](lib:household-discoveries#page=331)) | "A few whole cloves" or a little alcohol, same page |
| Wood filler of white lead, red lead and litharge ([*Household Discoveries*, p. 339](lib:household-discoveries#page=339)) | Glue with sawdust or chalk, same page ([Leland, p. 89](lib:leland-a-manual-of-mending#page=89)) |
| Preserve timber by "Kyanizing" in corrosive sublimate — "very poisonous" even there — or in zinc chloride and creosote ([Henley's, pp. 779, 781](lib:henleys-twentieth-century#page=781)) | Durable heartwood kept dry ([Wood Handbook, p. 316](lib:wood-handbook#page=316)); charred posts for short service ([*Timber*, p. 48](lib:timber-as-a-construction-material#page=48)) |
| Fill round a new axe handle with epoxy ([*Handtools*, p. 54](lib:usfs-mtdc-handtools-for-trail-work-2005#page=54)) | "Epoxy should not be used, either": a good fit and a wooden wedge are enough ([*An Ax to Grind*, p. 33](lib:usfs-an-ax-to-grind#page=33)) |

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Tools and sharpening**
- Saw teeth and set — [🖼️ Griffith, p. 31](lib:griffith-essentials-of-woodworking#page=31), [🖼️ Disston, p. 9](lib:disston-saw-tool-and-file-book-1929#page=9), [🖼️ p. 34](lib:disston-saw-tool-and-file-book-1929#page=34); [Hand saw](wiki:Hand_saw)
- Setting, jointing and filing a saw — [🖼️ Griffith, pp. 34–35](lib:griffith-essentials-of-woodworking#page=34), [🖼️ Disston, p. 38](lib:disston-saw-tool-and-file-book-1929#page=38), [🖼️ Brace & Mayne, p. 207](lib:brace-and-mayne-farm-shop-work-1915#page=207)
- Parts of a plane; sighting the iron — [🖼️ Griffith, p. 37](lib:griffith-essentials-of-woodworking#page=37), [🖼️ p. 39](lib:griffith-essentials-of-woodworking#page=39); [Hand plane](wiki:Plane_(tool))
- Grinding, honing, stropping, testing — [🖼️ Griffith, pp. 67–72](lib:griffith-essentials-of-woodworking#page=67); [Whetstone](wiki:Whetstone)
- Homemade clamps — [🖼️ Brace & Mayne, p. 202](lib:brace-and-mayne-farm-shop-work-1915#page=202), [🖼️ Griffith, p. 90](lib:griffith-essentials-of-woodworking#page=90)

**Wood**
- How boards shrink and warp — [🖼️ Wood Handbook, p. 84](lib:wood-handbook#page=84), [🖼️ p. 304](lib:wood-handbook#page=304), [🖼️ Brace & Mayne, p. 178](lib:brace-and-mayne-farm-shop-work-1915#page=178); [Wood drying](wiki:Wood_drying)
- Riving: rails, bolts, the brake, steering a split — [🖼️ Kephart, p. 207](lib:kephart-camping-and-woodcraft-vol-2#page=207), [🖼️ p. 211](lib:kephart-camping-and-woodcraft-vol-2#page=211), [🖼️ p. 212](lib:kephart-camping-and-woodcraft-vol-2#page=212), [🖼️ p. 213](lib:kephart-camping-and-woodcraft-vol-2#page=213); [Froe](wiki:Froe)
- Our woodworking trees — [Oregon ash](wiki:Fraxinus_latifolia), [Oregon white oak](wiki:Quercus_garryana), [Pacific madrone](wiki:Arbutus_menziesii), [Bigleaf maple](wiki:Acer_macrophyllum), [Incense-cedar](wiki:Calocedrus_decurrens)

**Planing and joints**
- Face marks; winding sticks; shooting board — [🖼️ Griffith, p. 47](lib:griffith-essentials-of-woodworking#page=47), [🖼️ p. 46](lib:griffith-essentials-of-woodworking#page=46), [🖼️ p. 51](lib:griffith-essentials-of-woodworking#page=51)
- Dado, cross-lap, glue joint, dowel plate — [🖼️ Griffith, pp. 94–100](lib:griffith-essentials-of-woodworking#page=94)
- Mortise and tenon; dovetails — [🖼️ Griffith, pp. 105–112](lib:griffith-essentials-of-woodworking#page=105); [Mortise and tenon](wiki:Mortise_and_tenon), [Dovetail joint](wiki:Dovetail_joint)
- Dozens more joints — [🖼️ Griffith, pp. 172–178](lib:griffith-essentials-of-woodworking#page=172); [Woodworking joints](wiki:Joinery)
- Wedged crossbar; joints, pegs and lashings — [🖼️ Brace & Mayne, p. 42](lib:brace-and-mayne-farm-shop-work-1915#page=42), [🖼️ *Timber*, p. 82](lib:timber-as-a-construction-material#page=82), [🖼️ p. 85](lib:timber-as-a-construction-material#page=85)

**Things to make and mend**
- Handle grain; rehandling step by step; a hammer handle — [🖼️ *An Ax to Grind*, p. 26](lib:usfs-an-ax-to-grind#page=26), [🖼️ *Handtools*, pp. 53–56](lib:usfs-mtdc-handtools-for-trail-work-2005#page=53), [🖼️ Brace & Mayne, p. 88](lib:brace-and-mayne-farm-shop-work-1915#page=88); [Hickory](wiki:Hickory)
- Workbench, sawbuck, ladders — [🖼️ Brace & Mayne, p. 155](lib:brace-and-mayne-farm-shop-work-1915#page=155), [🖼️ p. 39](lib:brace-and-mayne-farm-shop-work-1915#page=39), [🖼️ p. 102](lib:brace-and-mayne-farm-shop-work-1915#page=102), [🖼️ p. 106](lib:brace-and-mayne-farm-shop-work-1915#page=106)
- Shaving horse; folding horse — [🖼️ *Handy Farm Devices*, pp. 18–19](lib:handy-farm-devices#page=18); [Shaving horse](wiki:Shaving_horse)
- Camp table, stool, wooden latches — [🖼️ *Shifts and Expedients*, p. 375](lib:shifts-and-expedients#page=375)
- A door and its hinges; splicing a chair leg — [🖼️ Griffith, pp. 120–121](lib:griffith-essentials-of-woodworking#page=120), [🖼️ Leland, p. 87](lib:leland-a-manual-of-mending#page=87)

---

## 🔗 Related guides

- [Blacksmithing & Hand Tools](guide:BLACKSMITHING-GUIDE) — axes, forging chisels, plane irons and froes
- [Firewood](guide:FIREWOOD-GUIDE) — felling, crosscut saws, splitting with maul and wedges
- [Shelter & Building](guide:SHELTER-BUILDING-GUIDE) — carpentry, hewing, drying lumber, shingles, rot and windows
- [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE) — wheelbarrows, handcarts and wheels
- [Practical Math](guide:PRACTICAL-MATH-GUIDE) — squaring with 3-4-5 and measuring
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — casein and pine-pitch glue, mending
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — the local picture and where everything is on the drive
