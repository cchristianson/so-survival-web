# ☢️ Nuclear Fallout Guide

What to do if there is a nuclear detonation or a radiation release: how to shelter, how long,
how to protect food, water and animals, how to clean up, and when potassium iodide (KI) helps.
The full manuals — shelter plans, the homemade KFM fallout meter, farm and livestock guides —
are in `Nuclear-Radiation\`.

> ### The three rules
> 1. **Get inside. Stay inside. Stay tuned.** Most deaths from fallout are avoidable just by
>    being behind enough mass in the first day or two.
> 2. **Fallout is dust.** It hurts you from what lands on and near you, so put **mass and
>    distance** between you and the roof, walls and ground outside.
> 3. **Time is on your side.** Radiation from fallout drops fast — **90% in the first 7
>    hours, 99% in 2 days.**

---

## ⚡ The first minutes

- **If you see a flash:** drop behind anything solid, face down, cover your head, and **don't
  look at it** — the flash can blind you even when you are too far away for the blast to hurt
  you ([FEMA H-20, p. 14](lib:protection-in-the-nuclear-age#page=14)). The blast wave can
  arrive many seconds later — stay down until it passes. Being outdoors in the first minute can
  mean burns, cuts from flying glass and broken bones
  ([FEMA *Planning Guidance*, p. 76](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=76)).
  What happens in those seconds: [🖼️ flash, heat and blast drawing](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=13);
  [Effects of nuclear explosions](wiki:Effects_of_nuclear_explosions), [Flash blindness](wiki:Flash_blindness).
- **Fallout near a blast can start arriving in 15–30 minutes;** 100–200 miles downwind, often
  **5–10 hours or more.** Use the time before it arrives to put out small fires, bring people,
  pets and water inside, and move to the best shelter you can reach.
  ([FEMA *Protection in the Nuclear Age*, H-20, p. 7](lib:protection-in-the-nuclear-age#page=7);
  [🖼️ how fallout comes down](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=14);
  [Nuclear fallout](wiki:Nuclear_fallout))
- **Officials will tell everyone within about 50 miles to shelter** until they know where the
  fallout is going.
  ([FEMA *Planning Guidance*, 3rd ed., p. 54](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=54))
- **Know the sirens.** A **3–5 minute steady blast** means "turn on the radio." A **3–5
  minute wavering tone** (or short blasts repeated) is the **attack warning** — go to shelter
  now. ([FEMA H-20, p. 12](lib:protection-in-the-nuclear-age#page=12); what they look like:
  [Civil defense siren](wiki:Civil_defense_siren))

**First-hour checklist:** get people and pets inside; close doors, windows and blinds; take a
few minutes to **check the house for fires** — stamp out smoldering drapes, throw burning furniture
outside ([FEMA H-20, p. 26](lib:protection-in-the-nuclear-age#page=26)); fill containers and tubs
while the taps run *(rule of thumb)*; carry food, water, radio, medicines and the toilet bucket
to the shelter spot.

📚 **Go deeper:** [FEMA H-20 *Protection in the Nuclear Age*](lib:protection-in-the-nuclear-age#page=12) — warning signals, the flash, fallout timing, fires; [FEMA *Planning Guidance*, 3rd ed.](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=53) — today's official "Get Inside, Stay Inside, Stay Tuned" advice.

## 🏠 Where to shelter

**Best to worst:** a basement (especially a corner below ground level) → the middle floors and
center of a large concrete or brick building → a crawl space or interior room of a house →
a vehicle (poor). See the
[🖼️ FEMA drawing of protection inside different buildings](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=78)
and [Fallout shelter](wiki:Fallout_shelter).

![Cut-away drawing of houses and buildings from a 1-story wood house to a large office building, each room marked with its protection factor: 2 to 3 on the main floor of a wood house, 10 in its basement, up to 200 deep underground](img:NUCLEAR-FALLOUT-GUIDE/protection-inside-buildings.png)
*Protection factors: 10 means a tenth of the outdoor dose. A 1-story wood house gives only 2–3 on its main floor and 10 in a basement; basements and the middle of big buildings give the most ([FEMA *Planning Guidance*, p. 78](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=78)).*

> **Most homes in the Illinois Valley are one-story wood frame with no basement.** FEMA says
> these, and vehicles, **are not adequate shelter** on their own
> ([*Planning Guidance*, p. 76](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=76)).
> Plan now: a nearby building with a basement or thick masonry, a crawl-space shelter you can
> shield, or an outdoor trench shelter (plans in [`MP-79`](lib:plans-for-expedient-fallout-shelters),
> [*In Time of Emergency*](lib:in-time-of-emergency-citizens-handbook), and *Nuclear War
> Survival Skills* Appendix A — see the
> [🖼️ Door-Covered Trench Shelter](lib:nuclear-war-survival-skills-1979#page=148) and
> [🖼️ Pole-Covered Trench Shelter](lib:nuclear-war-survival-skills-1979#page=154) drawings).
> Permanent backyard plans: [🖼️ FEMA H-12-1 outside concrete shelter](lib:outside-concrete-home-fallout-shelter-plan#page=5),
> [🖼️ FEMA H-12-2 aboveground shelter](lib:aboveground-home-fallout-shelter-plan#page=3).

- **Inside any building:** get as far from the roof and outside walls as you can, away from
  windows and doors. Close and lock windows, **turn off fans, A/C and forced-air heat**, close
  fireplace dampers.
  ([CDC *Where to Go*](lib:where-to-go-in-a-radiation-emergency#page=1);
  [🖼️ CDC picture: best places inside a building](lib:where-to-go-in-a-radiation-emergency#page=1))
- **No need to tape windows or hang plastic sheeting** — fallout shelters don't have to be
  airtight. A building with minor damage still works if it is structurally sound.
  ([EPA *Protective Action Q&A*, p. 31](lib:protective-action-questions-and-answers#page=31);
  [*Planning Guidance*, p. 76](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=76))
- **Stuck in a poor shelter?** If a good one is **under 15 minutes away, move within about 30
  minutes** of the blast, before heavy fallout arrives. If you're already in a moderate shelter,
  stay 1–2 hours, then move.
  ([FEMA *Planning Guidance*, p. 77](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=77))

**"Adequate" means it cuts your dose 10× or more.** Concrete, brick, stone and earth stop a lot;
wood, drywall and sheet metal stop little
([*Planning Guidance*, p. 76](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=76);
[🖼️ EPA dose-reduction diagram by building type](lib:pag-manual#page=30)).

**Adding shielding** — each of these stops about as much as 4 inches of concrete
([FEMA H-20, p. 22](lib:protection-in-the-nuclear-age#page=22)):

| Material | Thickness |
|---|---|
| Brick | 5–6 in |
| Sand or gravel | 6 in |
| Packed earth | 7 in |
| Hollow concrete block (sand-filled) | 8 in (6 in) |
| Water | 10 in |
| Books or magazines | 14 in |
| Wood (firewood stack) | 18 in |

Pile it **on the floor above you** and **around the walls** of your shelter spot: earth-filled
drawers and boxes, water jugs, firewood, books, heavy furniture. **Every extra ~4 inches of packed
earth roughly halves what gets through — about 3 feet of earth cuts it around 1,000×**
([*Nuclear War Survival Skills*, 1979, p. 23](lib:nuclear-war-survival-skills-1979#page=23): one
"halving thickness" of packed earth is 3.6 in; [🖼️ halving-thickness drawing](lib:nuclear-war-survival-skills-1979#page=24);
[Radiation protection](wiki:Radiation_protection)). Crawl space: shelter under the center of the
house, ring yourself with blocks or earth-filled containers, and pile mass on the floor above.

![Diagram of ten layers of packed earth, each 3.6 inches thick, about 3 feet in all, with bars showing the radiation getting through halving at each layer from 1,000 down to about 1](img:NUCLEAR-FALLOUT-GUIDE/halving-thickness-of-earth.svg)
*Each 3.6 in of packed earth halves what gets through, so about 3 ft cuts it around 1,000 times (a diagram drawn for this guide).*

**Quick shelters, step by step** ([FEMA H-20, pp. 23–25](lib:protection-in-the-nuclear-age#page=23);
[HS-4, p. 67](lib:preparedness-planning-for-a-nuclear-crisis#page=67)):

1. **Table shelter:** a sturdy table or workbench in the most-underground basement corner, loaded
   on top and walled around with shielding. Crawl in and block the opening.
   ([🖼️ drawing of a basement table shelter](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=26))
2. **Door-roof shelter:** walls of dressers or appliances, a roof of heavy doors propped and piled
   with shielding. **Fill drawers and boxes with earth after they're in place** — full ones are too
   heavy to carry.
3. **Crawl-space shelter:** cut an access now. Under the middle of the house, wall a spot with
   blocks or earth-filled containers up to the joists and pile mass on the floor above. **Make sure
   no heavy appliance sits right above you.** Dig down so you can sit up.
4. **Last resort:** dig a trench beside a slab house and tunnel no more than **4 feet** under the
   slab; shore it and pile shielding on the slab inside.

![Drawing of a man in a basement corner stacking boxes of heavy material on top of and around a sturdy workbench to make a fallout shelter](img:NUCLEAR-FALLOUT-GUIDE/basement-table-shelter.png)
*A table shelter (step 1): heavy material stacked on and around a sturdy table in a basement corner; dirt in the window wells adds more ([OCD H-6, p. 26](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=26)).*

**Ventilation:** a crowded, sealed shelter gets dangerously hot in warm weather. Kearny's
homemade **air pump** (KAP) — plans in *Nuclear War Survival Skills* and the ORNL *Expedient
Shelter Handbook* — moves air without bringing in fallout dust
([🖼️ KAP swinging in a doorway](lib:nuclear-war-survival-skills-1979#page=182);
[🖼️ photos of homemade KAPs](lib:nuclear-war-survival-skills-1979#page=60)). In a heat wave, plan on about
**4 quarts of water and 10 grams of salt per person a day** and as few clothes as practical
([NWSS 1979, p. 62](lib:nuclear-war-survival-skills-1979#page=62)).

📚 **Go deeper:** [FEMA H-20](lib:protection-in-the-nuclear-age#page=22) — shielding table and home expedient shelters; [FEMA HS-4 *Citizen's Guide*](lib:preparedness-planning-for-a-nuclear-crisis#page=67) — rating and upgrading your house; [*Expedient Shelter Handbook* ORNL-4941](lib:expedient-shelter-handbook#page=272) — trench and log shelters, plus full Kearny Air Pump plans; [MP-79](lib:plans-for-expedient-fallout-shelters) — construction drawings for homes without basements.

## 🧰 Stocking the shelter

FEMA says to have **at least two weeks** of water, food and supplies ready to carry to the
shelter ([H-20, p. 13](lib:protection-in-the-nuclear-age#page=13);
[🖼️ illustrated 1961 supply chart](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=27)).

| Item | How much / what kind ([FEMA H-20, pp. 29–31](lib:protection-in-the-nuclear-age#page=29)) |
|---|---|
| **Water** | H-20's bare minimum is **1 quart per person per day** just to drink; today FEMA advises storing **1 gallon per person per day**. Kearny says store **15 gallons per person** for two weeks ([NWSS 1979, p. 71](lib:nuclear-war-survival-skills-1979#page=71); [🖼️ storing water in lined bags and pits](lib:nuclear-war-survival-skills-1979#page=72)). |
| **Food** | Canned or sealed, no cooking needed. Most adults do fine on **half their usual amount** — not children or pregnant women. |
| **Toilet** | Bucket with a tight lid, liner bags, a second lidded can, bleach, toilet paper ([🖼️ hose-vented toilet-can](lib:nuclear-war-survival-skills-1979#page=108); [Bucket toilet](wiki:Bucket_toilet)). |
| **Radio and light** | Battery radio, flashlight, spare batteries — the radio "may be your only link." |
| **Medicines, babies** | Two weeks of regular medicines and a first-aid kit; formula or canned milk and diapers. |
| **Tools** | Shovel, pick, saw, hammer, crowbar, broom, nails, wire ([H-20, p. 18](lib:protection-in-the-nuclear-age#page=18)). |

- **Water hiding in your house:** the water heater (20–60 gallons), toilet **tanks** (not
  bowls) and the pipes — shut the main valve, open the **highest** faucet, draw from the
  **lowest** ([H-20, pp. 31–32](lib:protection-in-the-nuclear-age#page=32)). **Don't ration
  drinking water below thirst** — nothing is gained by it.
- **Never burn charcoal indoors**; any stove used inside needs good ventilation.
- **Toilet routine:** a little bleach after each use, lid back on; when you can step out briefly,
  **bury the waste 1–2 feet deep** ([H-20, p. 33](lib:protection-in-the-nuclear-age#page=33)).

📚 **Go deeper:** [FEMA H-20, Part 4 "Shelter Living"](lib:protection-in-the-nuclear-age#page=27) — supply lists, water, food and sanitation; [*Expedient Shelter Handbook* Appendix C](lib:expedient-shelter-handbook#page=307) — emergency water storage, lights and sanitation; [*Shelter Management Handbook* H-16](lib:shelter-management-handbook) — running a shelter with a group.

## ⏳ How long to stay in

**The 7-10 rule:** every **7×** increase in time after the blast cuts the radiation **10×**
(once the fallout has finished falling). ([FEMA H-20, p. 8](lib:protection-in-the-nuclear-age#page=8);
see the [🖼️ seven-ten rule chart](lib:protection-in-the-nuclear-age#page=8) and the
[🖼️ decay curve for the first two days](lib:nuclear-war-survival-skills-1979#page=22))

| Time after blast | Radiation level (example) |
|---|---|
| 1 hour | 1,000 R/hr |
| 7 hours | 100 R/hr |
| 2 days | 10 R/hr |
| 2 weeks | 1 R/hr |

- **Stay sheltered at least 12–24 hours** unless officials say otherwise or fire, collapse or
  a medical emergency forces you out
  ([FEMA *Planning Guidance*, pp. 53, 76](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=53)).
  In heavy fallout areas it can be **several days to two weeks**, with only short trips out
  once levels drop ([H-20, p. 9](lib:protection-in-the-nuclear-age#page=9)). USDA adds that
  where fallout is light or moderate you **might** be able to come out for part of each day
  after 2–3 days ([PA-515, p. 6](lib:fallout-and-your-farm-food#page=6)).
- **Late fallout decays more slowly where you are** — if it arrives 8 hours after the blast,
  it takes about two days to fall to one-tenth
  ([KFM report ORNL-5040, p. 69](lib:kfm-homemade-fallout-meter#page=69)).
- **Gritty dust on ledges, cars or walks after an attack = assume fallout**
  ([H-20, p. 33](lib:protection-in-the-nuclear-age#page=33)).
- **Without a meter, listen for official word.** With a meter, you can make your own decisions —
  see below.

**Dose yardsticks** — what a short-term whole-body dose does to a group of people
([DCPA home-study course, p. 49](lib:introduction-to-radiological-monitoring#page=49);
[Acute radiation syndrome](wiki:Acute_radiation_syndrome)):

| Dose received over a short time | What to expect |
|---|---|
| 50 R | No visible effects |
| 75–100 R | Brief nausea the same day in about 1 in 10 people |
| 200 R | Up to half get some radiation sickness; 5–10% need care; deaths not expected |
| 450 R | Serious sickness in most; about half die within 2–4 weeks |
| 600 R | Serious sickness in all; nearly all die within 1–3 weeks |

Sources set the line differently: the old civil-defense course says **keep short-term doses under
100 R** ([DCPA, p. 50](lib:introduction-to-radiological-monitoring#page=50)); today's EPA guideline
for emergency workers is **5 rem**, up to 25 rem only to save lives
([EPA PAG Manual, p. 46](lib:pag-manual#page=46)). Treat 1 R of fallout as about 1 rem *(rule of
thumb)*. Lower is always better — the dose adds up.

📚 **Go deeper:** [FEMA H-20](lib:protection-in-the-nuclear-age#page=8) — the 7-10 rule and radiation sickness by dose; [DCPA *Introduction to Radiological Monitoring*](lib:introduction-to-radiological-monitoring#page=49) — dose effects and how to predict decay; [EPA PAG Manual](lib:pag-manual#page=17) — official dose thresholds for sheltering, KI, food and water.

## 🧼 Cleaning yourself up (decontamination)

([CDC *Decontamination*](lib:decontamination-for-yourself#page=1); [EPA *Protective Action Q&A*, p. 32](lib:protective-action-questions-and-answers#page=32);
pictures: [🖼️ CDC step-by-step sheet](lib:decontamination-for-yourself#page=1),
[🖼️ FEMA self-decontamination steps](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=116),
[Radioactive contamination](wiki:Radioactive_contamination))
- **Taking off your outer layer of clothes removes up to 90%** of the fallout on you. Do it
  before you enter the shelter if you can, and do it **gently** so dust doesn't shake loose.
  Bag the clothes and put them away from people and pets.
- **Shower with soap and shampoo — no conditioner** (it glues particles to hair). Don't scrub
  hard or scratch the skin; keep cuts covered. Keep suds out of your mouth and don't swallow
  the water.
- **No shower?** Wipe exposed skin, blow your nose, wipe eyelids, ears and face with a damp cloth.
- Clothes from closed drawers and closets are fine to wear. **No clean clothes?** Take off the
  outer layer, shake or brush it off, put it back on, then rewash your hands and face.
- **A cut or wound with fallout in it:** flush with plenty of clean water or saline, or keep
  it covered ([EPA Q&A, p. 33](lib:protective-action-questions-and-answers#page=33)).
- **Visitors:** have them strip the outer layer, bag it, and wash before coming in — then
  they're no danger to you ([EPA Q&A, p. 33](lib:protective-action-questions-and-answers#page=33)).
  **Radiation sickness is not contagious**
  ([H-20, p. 9](lib:protection-in-the-nuclear-age#page=9)).
- **Pets:** bring them in. Wash with soap or shampoo and water, wearing gloves and a dust mask,
  keep your cuts (and theirs) covered, rinse completely, then wash yourself
  ([EPA Q&A, p. 44](lib:protective-action-questions-and-answers#page=44)).
- **Fallout looks like sand, ash or grit** ([🖼️ photos of real fallout particles](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=38)). Brush or hose it off roofs and away from the house
  after levels drop; wear a dust mask, gloves and a hat, and wash afterward. If you must be out
  while dust is in the air, **cover nose and mouth with a cloth**
  ([EPA Q&A, p. 30](lib:protective-action-questions-and-answers#page=30)).

📚 **Go deeper:** [CDC *Decontamination for Yourself and Others*](lib:decontamination-for-yourself#page=1) — the one-page picture guide; [EPA *Protective Action Q&A*](lib:protective-action-questions-and-answers#page=32) — self-decontamination, visitors, wounds, pets and service animals.

## 💊 Potassium iodide (KI)

- **KI only protects the thyroid, and only from radioactive iodine.** It does nothing against
  other fallout. **Take it only when health officials say to** — or, with no officials, when you
  have reason to believe fresh fallout or a reactor plume is arriving. **Table salt and iodine
  tincture are not substitutes** (tincture is poisonous to swallow). Iodine dietary supplements
  aren't either — use only FDA-approved KI.
  ([CDC *How KI Works*](lib:how-potassium-iodide-works#page=1); [FDA, p. 12](lib:potassium-iodide-as-a-thyroid-blocking-agent#page=12);
  [🖼️ CDC picture sheet: how KI fills the thyroid](lib:how-potassium-iodide-works#page=1);
  where the gland is: [Thyroid](wiki:Thyroid))
- **One dose protects about 24 hours.** It works best just before or as the plume arrives and
  still helps 3–4 hours after. Avoid repeat doses for newborns and pregnant or breastfeeding
  women. ([FDA, pp. 9–11](lib:potassium-iodide-as-a-thyroid-blocking-agent#page=11))

**FDA dose by age (one dose per day)** ([FDA 2001, p. 9](lib:potassium-iodide-as-a-thyroid-blocking-agent#page=9)):

| Who | Dose | 130 mg tablets | 65 mg tablets |
|---|---|---|---|
| Adults over 18 (including pregnant or breastfeeding) | 130 mg | 1 | 2 |
| Ages 12–18 (130 mg if 154 lb or more) | 65 mg | ½ | 1 |
| Ages 3–12 | 65 mg | ½ | 1 |
| 1 month – 3 years | 32 mg | ¼ | ½ |
| Birth – 1 month | 16 mg | ⅛ | ¼ |

Adults over 40 need it only for a very large expected exposure. To make liquid doses for small
children from tablets, use the two FDA sheets in `Nuclear-Radiation\Government-Guidance`.

**Making liquid KI for children** — the two FDA sheets give the same recipe for one 130 mg tablet
or two 65 mg tablets ([FDA, one 130 mg tablet](lib:ki-liquid-dosing-instructions-one-130#page=1);
[FDA, two 65 mg tablets](lib:ki-liquid-dosing-instructions-two-65#page=1)):

1. Put the tablet(s) in a small bowl with **4 teaspoons of water**. Soak 1 minute.
2. Crush with the back of a spoon until there are no large pieces.
3. Stir in **4 teaspoons** of milk, chocolate milk, orange juice, cola, formula, raspberry syrup
   or water. You now have 8 teaspoons of KI liquid.
4. Give once a day: **19 and older — 8 tsp; 13–18 years and 150 lb or more — 8 tsp; 13–18
   under 150 lb — 4 tsp; 4–12 years — 4 tsp; over 1 month to 3 years — 2 tsp; birth to
   1 month — 1 tsp.**
5. Keep leftover liquid in the refrigerator; **throw it out after 7 days.**

*(The liquid sheet uses 150 lb for teens; the 2001 FDA guidance says 70 kg, about 154 lb. Either way
a near-adult-size teen gets the adult dose.)*

- **A nursing mother's KI does not protect her baby** — the baby needs its own dose, and
  newborns given KI should see a doctor afterward if one can be found
  ([FDA, pp. 9–10](lib:potassium-iodide-as-a-thyroid-blocking-agent#page=10);
  [EPA Q&A, p. 38](lib:protective-action-questions-and-answers#page=38)).
- **Repeat daily only while the risk of breathing or eating radioactive iodine continues**
  ([FDA, p. 9](lib:potassium-iodide-as-a-thyroid-blocking-agent#page=9)). Once the cloud has
  passed, FDA says the protection is **controlling the food — especially fresh milk — not more
  KI.** Stored grain and canned milk or vegetables kept weeks to months carry no radioiodine risk
  ([FDA, p. 11](lib:potassium-iodide-as-a-thyroid-blocking-agent#page=11)).
- **Too much is dangerous too** — don't double up "to be safe"
  ([CDC](lib:how-potassium-iodide-works#page=1)).

📚 **Go deeper:** [FDA KI dosing guidance](lib:potassium-iodide-as-a-thyroid-blocking-agent#page=9) — the official dose table and timing; [FDA liquid KI sheet](lib:ki-liquid-dosing-instructions-two-65#page=1) — step by step for children; [CDC *How KI Works*](lib:how-potassium-iodide-works#page=1) — what it does and doesn't do. Pictures: [Potassium iodide](wiki:Potassium_iodide).

## 🥫 Food and water

([EPA *Protective Action Q&A*, p. 29](lib:protective-action-questions-and-answers#page=29); FDA; *Nuclear War Survival Skills* Ch. 8)
- **Food that was indoors is fine.** Sealed cans, jars and bags that were outside are fine after
  wiping the outside — bag the wiping cloths. **Stored grain and canned food have no
  radioactive-iodine risk.**
- **Don't eat garden produce or anything left uncovered outdoors** until levels have dropped and
  it's declared clear — then wash and peel it. **Leafy vegetables:** strip the outer leaves of
  cabbage and lettuce and wash the rest thoroughly. **Roots and tubers:** normal washing and
  peeling is enough. **Fruit:** wash before eating.
  ([FB 2107, p. 14](lib:defense-against-radioactive-fallout-on-the-farm#page=14); [PA-515, p. 7](lib:fallout-and-your-farm-food#page=7))
- **Don't drink fresh milk** from animals grazing fallout-covered pasture for the first weeks
  (radioactive iodine concentrates in milk). Milk made into cheese and aged two months or more
  is fine — the radioactive iodine ([Iodine-131](wiki:Iodine-131)) decays away (it loses half its strength every **8 days** —
  [USDA Ag Handbook 234, p. 9](lib:protection-of-food-and-agriculture#page=9); USDA puts the
  wait at **30–60 days** — [PA-515, p. 8](lib:fallout-and-your-farm-food#page=8)).
  **If you have a baby, keep canned or dry milk in a protected place.**
- **Water:** bottled and sealed water is certain. **Covered wells, tanks and cisterns** are the
  best sources; deep wells are well protected. Tap water is fine for washing.
- **Boiling does not remove radioactivity.** To clean doubtful water: stir in clay soil, let it
  settle several hours, and pour off the clear water — or filter it through a bucket of packed
  earth. Both remove most fallout particles. Then disinfect as usual.
- **Cover rain barrels, tanks and well heads ahead of time.** ([Rain barrel](wiki:Rainwater_tank))

**Water sources, safest first** ([NWSS 1979, pp. 76–77](lib:nuclear-war-survival-skills-1979#page=76)):
deep wells and covered tanks → covered shallow wells → deep lakes → shallow ponds → streams (worst
after the **first heavy rains**) → roof runoff → melted snow. With the power off, a well can still
be used with a homemade **bail-can** on a rope
([🖼️ bail-can drawing](lib:nuclear-war-survival-skills-1979#page=77); [Well](wiki:Well)).

**Settling method** ([NWSS 1979, pp. 78–79](lib:nuclear-war-survival-skills-1979#page=78)):

1. Fill a bucket three-quarters full of the doubtful water.
2. Dig clay or clayey soil from **at least 4 inches below the surface** (fallout stays near the top).
3. Stir in about **1 inch of dry clay for every 4 inches of water** until it's all suspended.
4. Let it settle **at least 6 hours.** The clay carries the fallout down.
5. Dip or siphon off the clear water, then disinfect it.

(USDA says settle **a day**, then strain through cloth; for stock, stir up a pond's mud bottom
and let it settle — [PA-515, p. 8](lib:fallout-and-your-farm-food#page=8).)

**Earth filter** ([NWSS 1979, pp. 77–78](lib:nuclear-war-survival-skills-1979#page=77);
[🖼️ cut-away drawing of the filter can](lib:nuclear-war-survival-skills-1979#page=78)):

1. Punch about a dozen nail holes, from the bottom upward, within 2 inches of the center of the
   bottom of a 5-gallon can or bucket.
2. Put in **1½ inches of washed pebbles**, then one layer of towel or burlap cut a bit bigger
   than the can.
3. Add **6–7 inches** of crumbled soil with some clay in it, dug from 4+ inches deep, pressed down
   in layers. **Not pure clay** (too tight) **or sand** (too loose).
4. Cover with one layer of towel held by a few stones. Set the can on sticks over a pan.
5. Pour in (settled) water. Expect about 6 quarts an hour at first, 2 quarts an hour later.
   If it runs faster than a quart in 10 minutes, repack the soil. **Replace the soil after about
   50 quarts.** Disinfect the filtered water.

![Cut-away diagram of a bucket earth filter: nail holes in the bottom, 1.5 inches of pebbles, a towel, 6 to 7 inches of clayey soil, a towel held by stones, water poured on top, the bucket on sticks dripping into a pan](img:NUCLEAR-FALLOUT-GUIDE/earth-filter.svg)
*The earth filter from the steps above, cut away: pebbles, cloth, 6–7 in of clayey soil, cloth and stones, set on sticks over a pan (a diagram drawn for this guide).*

**Disinfecting afterward:** boil, or use plain unscented bleach — **8 drops of 6% bleach or 6 drops
of 8.25% bleach per gallon, double if cloudy or very cold, wait 30 minutes**
([EPA *Emergency Disinfection*, pp. 1–2](lib:epa-emergency-disinfection-of-drinking-water#page=2)).

📚 **Go deeper:** [*Nuclear War Survival Skills* 1979, Ch. 8](lib:nuclear-war-survival-skills-1979#page=76) — water sources, bail-can, settling and earth filter; [USDA PA-515 *Fallout and Your Farm Food*](lib:fallout-and-your-farm-food#page=7) — cleaning home-grown food; [FDA *Accidental Radioactive Contamination of Food and Feeds*](lib:accidental-radioactive-contamination#page=1) — official food and milk limits.

## 🐄 Livestock and gardens

([USDA FB 2107, pp. 8–14](lib:defense-against-radioactive-fallout-on-the-farm#page=8), [PA-516](lib:your-livestock-can-survive-fallout); [Oregon ODOE, p. 2](lib:radiological-emergency-preparedness-in-oregon#page=2))
- Shelter animals if you can (a barn helps), and **take them off pasture**. Feed **protected
  feed** — hay from inside the stack, covered silage, grain from closed bins
  ([🖼️ USDA plan: dairy barn with a built-in family fallout shelter](lib:protection-of-food-and-agriculture#page=40);
  [Silage](wiki:Silage)).
- Water from a covered well, tank or flowing spring is best; open pond water clears more slowly
  but improves quickly.
- **Hold off on slaughter, fresh milk and eggs** until levels drop.
- Gardens: stop harvesting; after levels drop, wash and peel produce. Fallout on soil decays and
  is diluted by digging it in.

**More from USDA FB 2107 (pp. 8–14):**

- **Animals are as sensitive to radiation as people.** Crowd them into the barn — they shield each
  other; **ventilation, not floor space, is the limit.** **Dairy animals first** ([Dairy cattle](wiki:Dairy_cattle)) — milk them before
  fallout arrives if you can, and turn calves in with the cows (pp. 9–11).
- **Feed:** fallout only coats the **outside** of a haystack or stack of feed bags. Peel off the
  outer layer and feed the inside; a tarp over a field stack ahead of time is enough (p. 10).
- **Tanks and ponds:** use what's already in a covered tank first. Pond water usually clears in a
  few days — **keep stock off it a few days longer if it rains** (pp. 9–10).
- **Poultry** stand about **twice the radiation cattle do**; eggs clear soon after hens get clean
  feed ([PA-515, p. 8](lib:fallout-and-your-farm-food#page=8)).
- **Meat:** an animal exposed only to outside radiation can be eaten if slaughtered **before** it
  shows sickness; keep hide and gut contents off the meat. Wash fallout off animals with any water,
  wearing coveralls, gloves and boots (p. 12).
- **Pasture:** lightly contaminated pasture can be grazed again after **one to a few weeks** (p. 13).
  **Bees:** don't move or harvest hives until checked
  ([ODOE, p. 2](lib:radiological-emergency-preparedness-in-oregon#page=2)).

**Long-term garden choices:** radioactive strontium ([Strontium-90](wiki:Strontium-90)) acts like calcium. **Liming acid soil cuts how
much plants take up.** Alfalfa, clover, soybeans and leafy greens take up more than grains,
grasses, corn, potatoes and fruit — favor the latter on contaminated ground
([FB 2107, p. 13](lib:defense-against-radioactive-fallout-on-the-farm#page=13)).

📚 **Go deeper:** [USDA FB 2107 *Defense Against Radioactive Fallout on the Farm*](lib:defense-against-radioactive-fallout-on-the-farm#page=8) — livestock, feed, water, milk and crops; [USDA Ag Handbook 234](lib:protection-of-food-and-agriculture#page=9) — the science of fallout on soil, crops and animals; [USDA Radiological Monitoring Handbook](lib:usda-radiological-monitoring-handbook) — checking pasture, water and livestock with a meter.

## 📟 Measuring radiation

- **A meter turns guessing into decisions** — when to leave the shelter, which room is safest,
  whether the water is clear.
- **KFM (Kearny Fallout Meter):** a homemade meter from a can, foil and paper. Build it **before**
  you need it. The patterns must print **exactly to scale** — check against a ruler; OISM warns
  online copies of the templates aren't fully reliable and recommends the printed book. Full
  patterns and tables: ORNL-5040 and *Nuclear War Survival Skills* Appendix C. See it first:
  [🖼️ photos of a finished KFM](lib:kfm-homemade-fallout-meter#page=35),
  [🖼️ full-scale cut-away drawing](lib:kfm-homemade-fallout-meter#page=37). It is a kind of
  [electroscope](wiki:Electroscope).
- **Old civil-defense meters** turn up at sales: the yellow **CD V-715** reads high levels
  (fallout); the **CD V-700** is a low-range Geiger counter for checking food, water and people
  ([Geiger counter](wiki:Geiger_counter)).
  Manuals and a home-study course are in `Nuclear-Radiation\Measuring-Radiation`.

**What a KFM is made of** ([ORNL-5040, pp. 33, 39](lib:kfm-homemade-fallout-meter#page=39)): an
8-ounce can (or a cut-down soup can), 2 square feet of aluminum foil, clean thread, clear plastic,
doorbell wire. A **drying agent** goes in the bottom — gypsum from heated drywall, or silica gel,
**not calcium chloride or salt.** Charge it by rubbing a plastic ruler on dry paper
([🖼️ the other way: charging with unrolled tape](lib:kfm-homemade-fallout-meter#page=63)).

**Using it** ([ORNL-5040, pp. 69–73](lib:kfm-homemade-fallout-meter#page=69)):

1. Charge it and read the gap between the two foil leaves on the paper scale.
2. Hold it on a stick about **3 feet above the ground** for a set time — **1 minute** if you have
   no idea of the level — then read again. The table on the meter turns the drop into a dose rate.
3. **Dose = dose rate × time.** At 1,200 R/hr, a 30-second dash outside is 10 R.
4. **Keep a daily dose record for every person,** and use the meter indoors to find the
   lowest-dose spot in your shelter, then add shielding there.

**Civil-defense instruments** ([DCPA course](lib:introduction-to-radiological-monitoring#page=99)):

| Instrument | Range | Use |
|---|---|---|
| **CD V-715** (yellow) | 0–500 R/hr | Fallout levels outside and in the shelter ([🖼️ picture](lib:introduction-to-radiological-monitoring#page=100)) |
| **CD V-717** | 0–500 R/hr, 25-ft remote probe | Read outside levels without leaving shelter ([p. 109](lib:introduction-to-radiological-monitoring#page=109); [🖼️ picture](lib:introduction-to-radiological-monitoring#page=108)) |
| **CD V-700** | 0–50 mR/hr | Low levels: food, water, people, training ([p. 89](lib:introduction-to-radiological-monitoring#page=89); [🖼️ drawing](lib:introduction-to-radiological-monitoring#page=89)) |
| **CD V-742** | Pocket dosimeter, reads to 200 R | Your total dose; recharge with a CD V-750 ([p. 83](lib:introduction-to-radiological-monitoring#page=83); [🖼️ the scale you read](lib:introduction-to-radiological-monitoring#page=77); [Dosimeter](wiki:Dosimeter)) |

**If this goes wrong:**

| Problem | What to do |
|---|---|
| KFM won't hold a charge | The air is too damp. Above about 90% humidity it can't be charged — make and use the **dry-bucket** ([ORNL-5040, pp. 65, 73](lib:kfm-homemade-fallout-meter#page=73); [🖼️ dry-bucket drawing](lib:kfm-homemade-fallout-meter#page=65)). Check the drying agent. |
| Leaves leak charge fast | Modern thread and floss may not insulate. Use **2-lb monofilament fishing line** or **1/16-inch strips of dry-cleaner bag** ([ORNL-5040 preface, p. 1](lib:kfm-homemade-fallout-meter#page=1)). |
| Old CD V meter reads nothing | Check batteries and run its operational check before trusting it ([DCPA, p. 116](lib:introduction-to-radiological-monitoring#page=116)). |

📚 **Go deeper:** [KFM report ORNL-5040](lib:kfm-homemade-fallout-meter#page=33) — full build instructions, patterns and the dose table; [DCPA home-study course](lib:introduction-to-radiological-monitoring#page=99) — using CD V meters and dosimeters; [CD V-715 manual](lib:cd-v-715-survey-meter) — operating and maintaining the yellow meter. Pictures: [Kearny fallout meter](wiki:Kearny_fallout_meter), [civil-defense meters (CD V-715 and others)](wiki:Civil_defense_Geiger_counters), [CD V-700](wiki:CD_V-700).

## 🩺 If this goes wrong in the shelter

| Problem | What to do |
|---|---|
| **Shelter is getting too hot** | Move air (a KAP or fan from outside air), strip to minimal clothes, drink freely and add salt to food ([NWSS 1979, p. 62](lib:nuclear-war-survival-skills-1979#page=62); only one opening? [🖼️ using a "divider" with a KAP](lib:nuclear-war-survival-skills-1979#page=199)). |
| **Someone is vomiting** | Nausea and vomiting are the first signs of radiation sickness ([H-20, pp. 10–11](lib:protection-in-the-nuclear-age#page=11)) — but stress and bad food cause them too. It isn't contagious. Keep them drinking small sips of the rehydration drink ([Field care](guide:FIELD-CARE-GUIDE)). (NWSS's "slightly salted water", about a teaspoon of salt per quart, is saltier than needed, especially for children — [NWSS 1979, p. 114](lib:nuclear-war-survival-skills-1979#page=114).) See the Medical guides. |
| **Water is running low** | Drink as needed anyway. Plan a short trip when levels allow; use the settling and earth-filter methods above. Water stored soon after fallout gets safer with time as iodine decays ([NWSS 1979, p. 79](lib:nuclear-war-survival-skills-1979#page=79)). |
| **Someone must go out for medicine** | Only if life depends on it — EPA calls it a last resort after asking neighbors. Strip and wash on return ([EPA Q&A, p. 43](lib:protective-action-questions-and-answers#page=43)). |
| **A nursing mother was outside** | If she has stored breast milk or formula, use it for now; if not, **keep breastfeeding** — feeding the baby comes first ([EPA Q&A, p. 36](lib:protective-action-questions-and-answers#page=36)). |
| **The radio is silent** | Listen on a schedule to save batteries and try every band *(rule of thumb)*. See the Radio guide. |

📚 **Go deeper:** [EPA *Protective Action Q&A*](lib:protective-action-questions-and-answers#page=36) — pregnancy, breastfeeding, children, medicines; [*Nuclear War Survival Skills* 1979](lib:nuclear-war-survival-skills-1979#page=62) — shelter heat, water and salt, first aid; [FEMA H-20](lib:protection-in-the-nuclear-age#page=10) — radiation sickness signs.

## 📍 Our area

- The region's only operating nuclear power plant is the **Columbia Generating Station at
  Hanford, Washington** — roughly **350 miles** from the Illinois Valley, far outside its planning
  zones. ([Oregon ODOE, p. 1](lib:radiological-emergency-preparedness-in-oregon#page=1);
  [Columbia Generating Station](wiki:Columbia_Generating_Station), [Hanford Site](wiki:Hanford_Site)) Its
  zones are a **10-mile plume zone** (Oregon is not in it) and a **50-mile ingestion zone** that
  reaches parts of northern Oregon
  ([ODOE, p. 2](lib:radiological-emergency-preparedness-in-oregon#page=2)).
- The more realistic threats here are **fallout drifting from detonations elsewhere** and
  **fallout carried across the Pacific** on west winds. After Chernobyl ([Chernobyl disaster](wiki:Chernobyl_disaster)), radioactive iodine showed
  up in milk in northwest Oregon. ([*Nuclear War Survival Skills*, 1987](lib:nuclear-war-survival-skills-1987))
  Even in the 1960s, Chinese test fallout put measurable radioactive iodine in American milk
  ([NWSS 1979, pp. 117–118](lib:nuclear-war-survival-skills-1979#page=118)). Winds across the U.S.
  run mostly west to east, but change day to day
  ([FEMA H-20, p. 7](lib:protection-in-the-nuclear-age#page=7)).
- **OISM, publisher of *Nuclear War Survival Skills*, is in Cave Junction** — the printed edition
  (with accurate KFM patterns) may be easy to get locally
  ([Nuclear War Survival Skills](wiki:Nuclear_War_Survival_Skills)).
- **Stay tuned locally:** NOAA Weather Radio broadcasts on seven frequencies, **162.400–162.550
  MHz** ([FEMA *Planning Guidance*, p. 167](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=167);
  [NOAA Weather Radio](wiki:NOAA_Weather_Radio)).
  Which stations reach the valley, and local AM/FM, are on the Illinois Valley page.

📚 **Go deeper:** [Oregon ODOE Hanford pamphlet](lib:radiological-emergency-preparedness-in-oregon#page=2) — Oregon's zones and farm steps; [*Nuclear War Survival Skills* 1987 (OISM, Cave Junction)](lib:nuclear-war-survival-skills-1987) — trans-Pacific fallout and the corrected KFM patterns; [FEMA *Planning Guidance*](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=167) — emergency alert channels.

---

*The 1987 edition of* Nuclear War Survival Skills *includes the author's personal view that small
radiation doses are healthful; FEMA, EPA and CDC do not accept that. Follow the government
guidance in this folder for dose decisions.*

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**The first minutes**
- Flash, heat and blast — [🖼️ OCD H-6, p. 13](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=13); [Effects of nuclear explosions](wiki:Effects_of_nuclear_explosions)
- How fallout comes down — [🖼️ OCD H-6, p. 14](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=14); [Nuclear fallout](wiki:Nuclear_fallout)
- Warning sirens — [Civil defense siren](wiki:Civil_defense_siren)

**Shelters, shielding and air**
- How much protection each part of a building gives — [🖼️ FEMA *Planning Guidance*, p. 78](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=78); [🖼️ EPA PAG Manual, p. 30](lib:pag-manual#page=30); [Fallout shelter](wiki:Fallout_shelter)
- Each 3.6 in of earth halves the rays — [🖼️ NWSS 1979, p. 24](lib:nuclear-war-survival-skills-1979#page=24); [Radiation protection](wiki:Radiation_protection)
- Table shelter in a basement corner — [🖼️ OCD H-6, p. 26](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=26)
- Basement block shelter and lean-to shelter — [🖼️ OCD H-6, p. 20](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=20); [🖼️ p. 21](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=21)
- Door-Covered Trench Shelter — [🖼️ NWSS 1979, p. 148](lib:nuclear-war-survival-skills-1979#page=148); [🖼️ photo of a family's finished one, p. 44](lib:nuclear-war-survival-skills-1979#page=44)
- Pole-Covered Trench Shelter — [🖼️ NWSS 1979, p. 154](lib:nuclear-war-survival-skills-1979#page=154); [🖼️ placing the roof poles, p. 46](lib:nuclear-war-survival-skills-1979#page=46)
- Small-Pole Shelter — [🖼️ NWSS 1979, p. 161](lib:nuclear-war-survival-skills-1979#page=161)
- Aboveground crib-walled shelter — [🖼️ NWSS 1979, p. 179](lib:nuclear-war-survival-skills-1979#page=179)
- Car-over-trench shelter — [🖼️ NWSS 1979, p. 63](lib:nuclear-war-survival-skills-1979#page=63); [🖼️ ORNL-4941 plan, p. 243](lib:expedient-shelter-handbook#page=243)
- Permanent backyard shelters — [🖼️ FEMA H-12-1, p. 5](lib:outside-concrete-home-fallout-shelter-plan#page=5); [🖼️ FEMA H-12-2, p. 3](lib:aboveground-home-fallout-shelter-plan#page=3)
- Kearny Air Pump (KAP) — [🖼️ NWSS 1979, p. 182](lib:nuclear-war-survival-skills-1979#page=182); [🖼️ photos, p. 60](lib:nuclear-war-survival-skills-1979#page=60); [🖼️ installing it, ORNL-4941, p. 289](lib:expedient-shelter-handbook#page=289)
- Hand-cranked shelter blower — [🖼️ OCD H-6, p. 33](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=33)

**Supplies, decay and cleaning up**
- Illustrated two-week supply chart — [🖼️ OCD H-6, p. 27](lib:fallout-protection-what-to-know-and-do-about-nuclear-attack#page=27)
- Water in lined bags and pits — [🖼️ NWSS 1979, p. 72](lib:nuclear-war-survival-skills-1979#page=72)
- Hose-vented toilet-can — [🖼️ NWSS 1979, p. 108](lib:nuclear-war-survival-skills-1979#page=108); [Bucket toilet](wiki:Bucket_toilet)
- The seven-ten rule — [🖼️ FEMA H-20, p. 8](lib:protection-in-the-nuclear-age#page=8); [🖼️ NWSS 1979, p. 22](lib:nuclear-war-survival-skills-1979#page=22); [🖼️ FEMA *Planning Guidance*, p. 43](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=43)
- What fallout looks like — [🖼️ FEMA *Planning Guidance*, p. 38](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=38)
- Cleaning yourself up — [🖼️ CDC sheet](lib:decontamination-for-yourself#page=1); [🖼️ FEMA *Planning Guidance*, p. 116](lib:planning-guidance-for-response-to-a-nuclear-detonation#page=116); [Radioactive contamination](wiki:Radioactive_contamination)
- Potassium iodide and the thyroid — [🖼️ CDC sheet](lib:how-potassium-iodide-works#page=1); [Potassium iodide](wiki:Potassium_iodide); [Thyroid](wiki:Thyroid)

**Water, food and the farm**
- Bail-can for a well — [🖼️ NWSS 1979, p. 77](lib:nuclear-war-survival-skills-1979#page=77); [Well](wiki:Well)
- Earth filter — [🖼️ NWSS 1979, p. 78](lib:nuclear-war-survival-skills-1979#page=78)
- Dairy barn with a family fallout shelter — [🖼️ USDA Ag Handbook 234, p. 40](lib:protection-of-food-and-agriculture#page=40); [Dairy cattle](wiki:Dairy_cattle)

**Fallout meters**
- KFM, finished and in use — [🖼️ ORNL-5040, p. 35](lib:kfm-homemade-fallout-meter#page=35); [🖼️ NWSS 1979, p. 100](lib:nuclear-war-survival-skills-1979#page=100); [Kearny fallout meter](wiki:Kearny_fallout_meter)
- KFM full-scale drawing, charging and dry-bucket — [🖼️ ORNL-5040, p. 37](lib:kfm-homemade-fallout-meter#page=37); [🖼️ p. 63](lib:kfm-homemade-fallout-meter#page=63); [🖼️ p. 65](lib:kfm-homemade-fallout-meter#page=65)
- CD V-715 survey meter — [🖼️ DCPA course, p. 100](lib:introduction-to-radiological-monitoring#page=100); [Civil defense Geiger counters](wiki:Civil_defense_Geiger_counters)
- A medium-range survey meter in use on a farm — [🖼️ USDA Ag Handbook 234, p. 36](lib:protection-of-food-and-agriculture#page=36)
- CD V-717 with remote probe — [🖼️ DCPA course, p. 108](lib:introduction-to-radiological-monitoring#page=108)
- CD V-700 Geiger counter — [🖼️ DCPA course, p. 89](lib:introduction-to-radiological-monitoring#page=89); [CD V-700](wiki:CD_V-700); [Geiger counter](wiki:Geiger_counter)
- CD V-742 pocket dosimeter — [🖼️ DCPA course, p. 77](lib:introduction-to-radiological-monitoring#page=77); [Dosimeter](wiki:Dosimeter)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local radio stations, water, wildfire and animal care
- [Radio guide](guide:RADIO-GUIDE) — staying tuned when the power and phones are down
- [EMP guide](guide:EMP-GUIDE) — protecting radios and electronics from a high-altitude blast
- [Medical guides](guide:Medical-READ-ME-FIRST) — first aid, vomiting and dehydration, oral rehydration
- [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — sanitation, bleach and cleaning without stores
- [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — stored food, milk and gardens
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — sheltering and feeding stock
