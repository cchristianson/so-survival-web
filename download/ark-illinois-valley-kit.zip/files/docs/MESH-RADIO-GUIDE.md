# 📡 Mesh Radio (Meshtastic)

Small, cheap radios that send **text messages and positions** from one to another with **no phone
service, no internet and no license**. Every radio in range passes messages along, so a few of them
spread out over a neighborhood or a valley reach further than any one could. The free software they
run is called **Meshtastic**. Each radio talks to a phone by Bluetooth: you type and read on the
phone, the radio does the sending.

This guide covers what to buy, what to do **now, while there is internet**, setting a radio up,
keeping messages private, getting range, linking up with neighbors, power, and fixing problems. The
project's own manual is on the drive too:
[the Meshtastic documentation, offline copy](lib:meshtastic-documentation-offline-copy-november-2026)
(325 pages, in `Comms-Signals\Mesh-Radio`), with the phone app beside it. The ARK Vault has two of
these radios: see [The ARK Vault's mesh radios](#11-the-ark-vault-s-mesh-radios).

> ### ⚠️ Rules that prevent the worst outcomes
> - **Antenna on before power, every time.** A radio that sends with no antenna can burn out its
>   radio chip ([docs, p. 64](lib:meshtastic-documentation-offline-copy-november-2026#page=64);
>   [p. 264](lib:meshtastic-documentation-offline-copy-november-2026#page=264)).
> - **Set the region to US** before anything else. With no region set, the radio does not send
>   at all ([docs, p. 74](lib:meshtastic-documentation-offline-copy-november-2026#page=74)).
> - **The ready-made channel is public.** Its key is printed in the software, so anyone with a
>   Meshtastic radio in range can read it. Use a **private channel** for anything private
>   ([docs, p. 160](lib:meshtastic-documentation-offline-copy-november-2026#page=160)).
> - **It is text, not voice,** and not a way to reach 911. In an emergency, also use the
>   [Radio guide](guide:RADIO-GUIDE) and the [Signals guide](guide:SIGNALS-MORSE-GUIDE).
> - **Put the app and the radio's software on now.** Both are downloaded from the internet.

---

## 1. What it is, and what it is not

| It does | It doesn't |
|---|---|
| Short text messages, up to about **200 letters** each ([docs, p. 108](lib:meshtastic-documentation-offline-copy-november-2026#page=108)) | Voice, pictures or files |
| Messages to a whole group (a **channel**) or to **one person** | Reach the phone network or 911 |
| Share where each radio is, on a map in the app | Work without a phone, mostly (the radio has no keyboard) |
| Pass messages along: up to **3 radios in a row** by default, 7 at most ([docs, p. 133](lib:meshtastic-documentation-offline-copy-november-2026#page=133)) | Get through a big ridge on its own |
| Run for days on a small battery | Need a license, a tower or a monthly bill |

**How far** *(rule of thumb)*: through thick forest or over hills, ¼ to 1 mile; around town, 1 to 3
miles; with a clear view across a valley or from a hilltop, 5 to 20 miles or more. People have
reached over 200 miles from mountain to mountain
([docs, p. 30](lib:meshtastic-documentation-offline-copy-november-2026#page=30)). What matters most
is **height and a clear line** between the radios, not power.

**Why it works when phones don't:** the radios use a free band (902 to 928 MHz in the US) that
anyone may use at low power, and each one repeats what it hears. There is nothing in between to
fail but the radios themselves.

---

## 2. What to buy

Get radios made for the **915 MHz** band (sold as "US 915" or "902-928 MHz"). The ones sold for
Europe (868) or Asia (433) will not talk to American radios.

| Kind | Example | Good for |
|---|---|---|
| **Pocket radio** with its own battery and GPS, nothing to set up | **SenseCAP T1000-E** (card size, rain-proof, about $40) | Carrying, one per person; the ARK Vault's pocket radio |
| **Board with a screen** | **Heltec WiFi LoRa 32 V4** (about $25, plus a battery and a case) | A radio at home or in a car; the ARK Vault's own radio |
| **Low-power board** for a solar relay | RAK WisBlock (nRF52 kind) | A relay on high ground that runs on a small panel |
| **Ready-made relay** in a weather-proof box with a solar panel | sold by several makers | A neighborhood relay with no building |

Also: a **USB-C cable that carries data** (not a charge-only one: test it by copying a file), a
**915 MHz antenna** for boards that don't have one built in, and a **power bank** for each radio.

*Tip:* buy the **same kind for everyone in the household**: one way of charging, one set of
buttons to learn.

---

## 3. Do these now, while there is internet

1. **Put the app on every phone.** Android: **Meshtastic** from Google Play, or the copy on this
   drive, [Meshtastic app for Android](lib:meshtastic-app-for-android-f-droid-build-apk) (copy it
   to the phone, tap it, and allow installing from that source when the phone asks). iPhone and
   iPad: **Meshtastic** from the App Store. An iPhone cannot install it later from a file.
2. **Put Meshtastic on each radio** if it didn't come with it, and bring it up to date. On a
   computer with **Chrome or Edge**, plug the radio in with a data cable and open
   **flasher.meshtastic.org** ([docs, p. 67](lib:meshtastic-documentation-offline-copy-november-2026#page=67)).
   Pocket radios like the T1000-E come with it.
3. **Set each radio up** (next section): region US, a name, and the household's private channel.
4. **Print the channel's QR code** and the card in [section 13](#13-print-and-keep-mesh-card), and
   keep them with the radios.
5. **Test:** send a message each way, then walk until it stops arriving, so you know your range.
6. **Find your local mesh:** neighbors may already run one. Ask what channel and preset they use
   ([docs, p. 79](lib:meshtastic-documentation-offline-copy-november-2026#page=79)).

---

## 4. Setting up a radio, step by step

1. **Antenna on, then switch on** (the T1000-E: hold its button until it beeps).
2. **Connect the phone:** in the app, open **Connect**, tap **Scan for Bluetooth devices** and pick
   the radio. Type the 6-number PIN the radio shows on its screen; a radio with no screen uses
   **123456** ([docs, p. 93](lib:meshtastic-documentation-offline-copy-november-2026#page=93)).
3. **Set the region:** tap **SET YOUR REGION** (or **Settings → LoRa**), choose **US**, tap **Send**
   ([docs, p. 74](lib:meshtastic-documentation-offline-copy-november-2026#page=74)). The radio
   restarts.
4. **Check the preset is Long Fast** (Settings → LoRa). Every radio that should talk to yours must
   use the same one. A radio whose region was first set **on its own screen** starts on **Long
   Turbo**, which cannot hear Long Fast: change it
   ([docs, p. 131](lib:meshtastic-documentation-offline-copy-november-2026#page=131)).
5. **Give it a name:** Settings → **User**: a long name (Dad's radio) and a 4-letter short name
   (DAD). That is what others see.
6. **Add the household channel** (next section) and send a test message.

> **The Vault's Heltec board:** in the web flasher choose **Heltec LoRa32 V4**. If the big chip on
> the board reads **ESP32-S3R8**, choose **V4-R8** instead: the two take different software
> ([docs, p. 268](lib:meshtastic-documentation-offline-copy-november-2026#page=268)).

---

## 5. Channels: who can read what

- **The primary channel** comes ready-made, named **LongFast**, with a key everyone has. It is how
  strangers' radios find each other and pass messages along. Treat it like shouting in the street.
- **A private channel** has a random key that only the radios you give it to have. Make one for the
  household: Settings → **Channels** → add a channel and give it a name (the app makes a new random
  key for it), tap **Save**, then **Send** to put it on the radio
  ([docs, p. 100](lib:meshtastic-documentation-offline-copy-november-2026#page=100)). A radio holds up to 8 channels.
- **Sharing it:** the app shows the channel as a **QR code**. On each other phone, scan it with the
  app. Typing the same name by hand does **not** work: the random key is in the code, and the code
  carries the radio settings too ([docs, p. 29](lib:meshtastic-documentation-offline-copy-november-2026#page=29)). Only scan codes from people you trust, for
  the same reason.
- **Direct messages** (to one radio, from the **Nodes** list) are locked to that person, so other
  people on the same channel can't read them either. Your radio must have heard the other radio
  first ([docs, p. 101](lib:meshtastic-documentation-offline-copy-november-2026#page=101)).
- **Your position:** on the public channel it is only shared roughly (about half a mile). On a
  private channel you choose how exact
  ([docs, p. 154](lib:meshtastic-documentation-offline-copy-november-2026#page=154)).
- **The lock in the app** tells you: green, private; yellow, readable by anyone; red, readable by
  anyone *and* sharing exact positions
  ([docs, p. 100](lib:meshtastic-documentation-offline-copy-november-2026#page=100)).

---

## 6. Sending messages and positions

- **To the group:** open the channel in **Messages** and type. A message to a channel only shows
  that it went out; no one confirms reading it.
- **To one person:** tap them in **Nodes**, then message. You see **Delivered** when their radio
  has it ([docs, p. 102](lib:meshtastic-documentation-offline-copy-november-2026#page=102)).
- **Keep it short:** who, where, what, what you need. "DAD at barn. All OK. Back 5pm."
- **Positions:** the map in the app shows every radio that shares where it is. The T1000-E sends
  its position when you **press its button twice**; **three presses** turn its GPS off or on to save
  the battery ([docs, p. 302](lib:meshtastic-documentation-offline-copy-november-2026#page=302)).
- **Waypoints:** drop a marked point on the app's map (a meeting place, a water source) and it
  appears on everyone's map on that channel
  ([docs, p. 119](lib:meshtastic-documentation-offline-copy-november-2026#page=119)).
- **Did it get through, and which way?** In Nodes, **Traceroute** shows which radios a message
  passed through ([docs, p. 257](lib:meshtastic-documentation-offline-copy-november-2026#page=257)).

---

## 7. Range: getting a message across

1. **Get it high.** A radio on a roof, in a tree or on a ridge reaches many times further than one
   in a pocket. Five feet up a fence post beats being on the ground.
2. **Antenna straight up**, and clear of metal and of your body. Indoors, by a window that faces
   the other radio.
3. **Check the line between two places** before carrying a radio there: on the library's map,
   **Measure** two points, and it says whether one can see the other, which is what a radio link
   needs ([Maps guide](guide:HOW-TO-VIEW-MAPS)).
4. **Relay over a ridge:** a radio on the ridge top between two valleys passes messages both ways.
   It should stay switched on, on a solar panel ([section 10](#10-power)).
5. **A better antenna** helps more than more power: a longer, upright 915 MHz antenna on the
   house's highest point, with short, good cable
   ([docs, p. 261](lib:meshtastic-documentation-offline-copy-november-2026#page=261)).
6. **Wet trees and leaves soak up the signal.** Range in a wet forest in winter can be half of what
   it is in a dry summer *(rule of thumb)*.

---

## 8. Roles: which job each radio does

Settings → **Device** → **Role**. Leave almost every radio on **Client**: it already passes
messages along. The others are for special places
([docs, p. 166](lib:meshtastic-documentation-offline-copy-november-2026#page=166);
[choosing a role, p. 179](lib:meshtastic-documentation-offline-copy-november-2026#page=179)).

| Role | Use it for |
|---|---|
| **Client** | Every radio people carry or keep at home. The right choice nearly always |
| **Client Mute** | Several radios in one house: one passes messages along, the others only listen and send |
| **Client Base** | Your own radio on the roof: it always passes on messages to and from the radios you mark as **favorites** (your family's) |
| **Router** | **Only** a radio in a high, open place everyone agreed on (a ridge-top relay). Routers always repeat, so one in a low or crowded place clogs the mesh for everyone |
| **Tracker** | A radio that only reports where it is (on a pack animal, a vehicle) |

---

## 9. A neighborhood mesh

A mesh is only as good as the radios in it. A street where several houses keep one radio on all
the time, with one relay up high, can reach across a whole valley.

1. **Agree one private channel** for the neighborhood (separate from each household's) and share
   its QR code in person, on paper.
2. **One or two relays on high ground**, set to **Router**, on solar power, with the owner's
   permission ([section 10](#10-power)).
3. **A check-in time:** every evening at 7, each house sends "OK" or "HELP" and what it needs, the
   radio side of the [neighborhood OK/HELP plan](guide:SIGNALS-MORSE-GUIDE#the-neighborhood-ok-help-plan).
4. **Short names that say who:** OAKS for the Oaks place, not a gadget's number.
5. **Someone keeps the list** of short names and channels, printed (the card in
   [section 13](#13-print-and-keep-mesh-card)). See also
   [forming a neighborhood group](guide:COMMUNITY-BARTER-GUIDE#forming-a-neighborhood-group).

---

## 10. Power

- **Pocket radio (T1000-E):** about a week on a charge if its GPS is off or reports rarely, a few
  days if it reports often *(rule of thumb)*. It charges from a magnetic USB cable: **keep that cable with
  it**, nothing else fits ([docs, p. 302](lib:meshtastic-documentation-offline-copy-november-2026#page=302)).
- **Boards with screens** use more: run them from a power bank, and switch the screen to turn off
  after a while.
- **A solar relay:** a small panel (5 to 10 watts), a battery pack that charges and powers at the
  same time, and a weather-proof box, with the antenna on top. The low-power (nRF52) boards run a
  long time on very little. Power planning: the
  [Off-grid power guide](guide:OFF-GRID-POWER-GUIDE).
- **Stored for an emergency:** charged every few months, in a sealed metal box with the phone
  (see the [EMP guide](guide:EMP-GUIDE#faraday-containers-building-one-that-works)).

---

## 11. The ARK Vault's mesh radios

The Vault can hold two radios: a **Heltec board** under the lid, powered whenever the Vault is on,
and a **T1000-E pocket radio** taped to a second phone, for whoever goes out. Each talks to its own
phone through the Meshtastic app. Fitting them, and the steps to do before the can is sealed, are in
the [Vault guide](guide:AMMO-CAN-COMPUTER-GUIDE#the-mesh-radio-optional). Screw the antenna on
**before** flipping the Vault's switch.

---

## 12. The law, privacy and safety

- **No license needed** in the US on the 915 MHz band at Meshtastic's normal settings
  ([docs, p. 14](lib:meshtastic-documentation-offline-copy-november-2026#page=14)).
- **Ham radio settings** (the "licensed" mode, and the ham-band regions) are only for licensed
  amateurs. In that mode messages may not be locked (encrypted), and your call sign is the radio's
  name. Licensed and unlicensed radios don't talk to each other
  ([docs, p. 77](lib:meshtastic-documentation-offline-copy-november-2026#page=77); [p. 307](lib:meshtastic-documentation-offline-copy-november-2026#page=307)).
- **Anyone can listen** to the public channel, and see positions shared on it. Some radios also
  pass the public channel to the internet when they have it. Keep names, addresses and plans to
  private channels.
- **Change the Bluetooth PIN** from 123456 on a radio with no screen, so a stranger nearby can't
  connect to it ([docs, p. 216](lib:meshtastic-documentation-offline-copy-november-2026#page=216)).
- **A lost radio:** it holds your private channel's key. Make a new channel and share the new code
  with everyone else.

---

## 13. Print-and-keep mesh card

| | Household | Neighborhood |
|---|---|---|
| Channel name | | |
| QR code | *(stick a printout here)* | *(stick a printout here)* |
| Region / preset | US / Long Fast | US / Long Fast |
| Check-in time | | |
| Meeting place if messages stop | | |

| Short name | Who | Where it usually is |
|---|---|---|
| | | |
| | | |
| | | |
| | | |

**Message form:** WHO · WHERE · OK or HELP · WHAT YOU NEED · WHEN YOU'LL CHECK IN AGAIN.

---

## 14. If this goes wrong

| Problem | Try |
|---|---|
| Two radios don't see each other | Same **region** (US), same **preset** (Long Fast), same **channel and key**? Scan the QR code again rather than typing |
| A radio set up from its own screen hears nothing | It started on Long Turbo: set Long Fast ([docs, p. 131](lib:meshtastic-documentation-offline-copy-november-2026#page=131)) |
| The app can't find the radio | Bluetooth on, the app allowed to find **nearby devices**, the radio near the phone. Still no: forget the radio in the phone's Bluetooth settings and pair again ([docs, p. 93](lib:meshtastic-documentation-offline-copy-november-2026#page=93)) |
| Asked for a PIN you don't know | It is on the radio's screen; no screen, **123456** |
| Messages to a channel never seem to arrive | Out of range: get higher, add a relay, or send a direct message to see **Delivered** |
| A direct message won't send | Your radio hasn't heard theirs yet. Wait until they show in Nodes |
| The T1000-E can't hear an old radio | Some older radios (SX127x chip) can't be heard by it directly; it works through a third radio ([docs, p. 301](lib:meshtastic-documentation-offline-copy-november-2026#page=301)) |
| The battery dies fast | GPS on and reporting often: report less, or turn GPS off (T1000-E: press 3 times) |
| A radio needs new software and there's no internet | It can't be done offline from this library: carry on with what it has. All radios on 2.x software still talk to each other |

---

## 15. Where to learn more offline

- [Meshtastic documentation, offline copy](lib:meshtastic-documentation-offline-copy-november-2026):
  setting up ([p. 48](lib:meshtastic-documentation-offline-copy-november-2026#page=48)), the
  Android app ([p. 88](lib:meshtastic-documentation-offline-copy-november-2026#page=88)), every
  setting ([p. 127](lib:meshtastic-documentation-offline-copy-november-2026#page=127)),
  antennas ([p. 261](lib:meshtastic-documentation-offline-copy-november-2026#page=261)), the
  Heltec radio ([p. 267](lib:meshtastic-documentation-offline-copy-november-2026#page=267)), the
  T1000-E ([p. 300](lib:meshtastic-documentation-offline-copy-november-2026#page=300)) and
  common questions ([p. 306](lib:meshtastic-documentation-offline-copy-november-2026#page=306)).
- [Meshtastic app for Android](lib:meshtastic-app-for-android-f-droid-build-apk), to install with
  no internet.
- How radio waves travel and antennas: the [Radio guide](guide:RADIO-GUIDE).

*Meshtastic® is a registered trademark of Meshtastic LLC. This guide is not made or endorsed by
Meshtastic.*

---

## 🔗 Related guides

- [Radio guide](guide:RADIO-GUIDE) — ham, GMRS, CB and shortwave: voice, longer range, and how to call for help
- [Signals guide](guide:SIGNALS-MORSE-GUIDE) — the neighborhood OK/HELP plan, runners and message forms
- [Community and barter guide](guide:COMMUNITY-BARTER-GUIDE) — organizing the neighbors who share a mesh
- [ARK Vault guide](guide:AMMO-CAN-COMPUTER-GUIDE) — the Vault's two mesh radios
- [Maps guide](guide:HOW-TO-VIEW-MAPS) — checking the line between two places before a trip
- [Off-grid power guide](guide:OFF-GRID-POWER-GUIDE) — panels and batteries for a relay
- [EMP guide](guide:EMP-GUIDE) — keeping radios safe in storage
