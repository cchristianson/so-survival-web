# 🔋 Batteries: Keeping Them, Charging Them, Reviving Them

Every battery in the house except the solar bank: AA and AAA cells, the 9 V in the smoke alarm, the coin
cells in watches and remotes, rechargeable AAs, the car battery, and the packs inside laptops, cordless
tools and e-bikes. How to store them, how to charge them with no proper charger, how to test them with a
cheap meter, when a "dead" battery is only dead for that one job, and where the line is between a sensible
repair and a house fire. The solar bank has its own guide:
[Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#choosing-batteries-and-reading-their-charge) covers choosing,
sizing, watering and equalizing a bank, and this guide links to it rather than repeat it. The books are in
`Off-Grid-Power\Batteries`, `Off-Grid-Power\Electrical-Basics`, `Electronics-Repair\` and
`Homestead-Skills\Household-Make-Do`.

> ### The short version
> - **Cool and dry is most of the secret.** Ten weeks at 95 °F costs a dry cell about **19%** of its punch;
>   at 41 °F, **4.4%** ([Circular 79, p. 37](lib:electrical-characteristics-and-testing-of-dry-cells#page=37)).
> - **A cell that will not run a flashlight will run a clock for months.** Through 64 ohms one cell gave
>   **480 times** the service it gave through 2 ohms ([p. 39](lib:electrical-characteristics-and-testing-of-dry-cells#page=39)).
> - **Voltage on its own lies.** One cell watched for 20 years still read **1.36 V** on a laboratory
>   instrument but **0.215 V** on an ordinary voltmeter ([p. 53](lib:electrical-characteristics-and-testing-of-dry-cells#page=53)).
>   **Test under load.**
> - **Never recharge a cell that is not marked rechargeable.** Charging a lithium cell "can result in cell
>   rupture and/or explosion" ([NASA JSC-20793, p. 83](lib:nasa-jsc-20793#page=83)).
> - **Never short any battery** ([NEETS 1, p. 96](lib:neets-module-01#page=96)): shorted cells have
>   "exploded with considerable force" ([p. 88](lib:neets-module-01#page=88)).
> - **A swallowed button cell is a two-hour emergency.** One stuck in a child's gullet "can cause serious
>   burns in only 2 hours" ([CDC MMWR, p. 3](lib:injuries-from-batteries-among-children#page=3)). Hospital, now.
> - **Swapping a whole pack is sensible. Rebuilding a lithium pack out of mixed salvaged cells is how house
>   fires start** ([below](#laptop-tool-and-e-bike-packs-what-is-inside-and-where-the-line-is)).

---

## 🔢 Every kind of battery, compared

| Type | Volts per cell | Good for | Keeps on the shelf | Recharges | How it dies | What kills it fastest |
|---|---|---|---|---|---|---|
| **[Zinc-carbon](wiki:Zinc–carbon_battery)** ("heavy duty") | 1.3–1.5, sags to 0.8–0.9 | The cheapest cell, for light on-and-off work | About 1 year | **None** | Voltage sags under load, then it leaks | Heat; any heavy drain |
| **[Alkaline](wiki:Alkaline_battery)** | 1.5 | Almost all household gear | Several years | **None** | Resistance climbs, then the seal lets go | Heat; being left inside unused gear |
| **[Lithium primary](wiki:Lithium_battery)** (AA, coin) | 1.5 (AA), 3.0 (coin) | Cold, smoke alarms, long storage | Up to 20 years | **None** | Runs nearly full, then stops quickly | Charging it; crushing it; heat |
| **[NiMH](wiki:Nickel–metal_hydride_battery)** | 1.2, and it holds steady | Anything that eats alkalines | 15–30% a month; 2% low-self-discharge | 500–1,000 | Capacity fades, self-discharge rises | Heat; overcharge; a flat series pack |
| **[NiCd](wiki:Nickel–cadmium_battery)** | 1.2 | Old tools, hard use, deep cold | 15–20% a month | 300–1,000 | A weak cell is reverse-charged and destroyed | Reverse charging; heat over 113 °F |
| **Lead-acid, starting** (car, tractor) | 2.0 | Short, heavy pulls | Recharge every 3–6 months | About 20 deep cycles | Sulfation, then shedding plates | Standing discharged |
| **Lead-acid, deep-cycle, AGM, gel** | 2.0 | The solar bank | 4–8% a month | 200–3,000 | Sulfation and plate corrosion | Heat; standing flat; undercharge |
| **[LiFePO4](wiki:Lithium_iron_phosphate_battery)** | 3.2 (2.5–3.6) | The best bank there is | 2–10% a month | 1,000+ | Slow fade | Charging below freezing |
| **[Lithium-ion](wiki:Lithium-ion_battery)** (phone, laptop, tool, e-bike) | 3.6–3.7 | Everything portable | 2–10% a month | 500+ | Capacity fades, then a cell swells or shorts | Heat; stored full; charged cold; a dent |

**Where the numbers come from.** Voltages and shelf life of the throw-away cells:
[Practical Action, pp. 2–3](lib:practical-action-batteries#page=2),
[NEETS 1, p. 88](lib:neets-module-01#page=88) (lithium's "remarkably long shelf life of up to 20 years")
and [NEETS 21, p. 94](lib:neets-module-21#page=94). By weight a D-size alkaline holds about **37 watt-hours
per pound**, a carbon-zinc D about **17**, a lithium D about **175**
([NASA, p. 83](lib:nasa-jsc-20793#page=83)). Cycles, self-discharge and the 113 °F NiCd and 125 °F
lead-acid limits: Table A1 of [Lighting Global, p. 10](lib:lighting-global#page=10),
[Practical Action, p. 4](lib:practical-action-batteries#page=4),
[Navy *Electronics Technician*, p. 27](lib:navy-electronics-technician-vol-1-safety#page=27). Lead-acid
cycles and the 20-deep-cycle life of a car battery:
[Practical Action, p. 5](lib:practical-action-batteries#page=5),
[IEA, pp. 13, 23](lib:iea-pvps-lead-acid#page=13); lithium stored at 20–40%,
[Lighting Global, p. 7](lib:lighting-global#page=7).

Two things no table shows. **Capacity is not a fixed number:** amp-hours "varies inversely with the
discharge current", and a battery gives its full rating only when emptied over 20 hours or more
([NEETS 1, pp. 96–97](lib:neets-module-01#page=96)); a D cell asked for the 0.3–0.5 A a flashlight wants
gives about **half** its rating, a quarter if it never rests
([Practical Action, p. 2](lib:practical-action-batteries#page=2)). And **cold cuts capacity:** cells are
rated at 68 °F, so warming them in a pocket gives extra run time
([p. 3](lib:practical-action-batteries#page=3)).

📚 **Go deeper:** [Lighting Global *Lithium-ion Batteries*](lib:lighting-global#page=10) — the full comparison table; [Practical Action *Batteries*](lib:practical-action-batteries#page=2) — every type in plain words; [NEETS 1, ch. 2](lib:neets-module-01#page=79) — how each kind works. Pictures: [🖼️ inside a dry cell, NEETS 1 p. 86](lib:neets-module-01#page=86), [🖼️ cylindrical, prismatic and pouch cells, Lighting Global p. 4](lib:lighting-global#page=4), [List of battery sizes](wiki:List_of_battery_sizes).

## 🔦 Small batteries: AA to 9 V, and button cells

**Heat is what empties a cell on the shelf**
([Circular 79, p. 37](lib:electrical-characteristics-and-testing-of-dry-cells#page=37)):

| Stored at | Lost in 10 weeks |
|---|---|
| 41 °F | 4.4% |
| 77 °F | 10% |
| 95 °F | 19% |
| 113 °F | 25% |
| 131 °F | 52% |

A year at room temperature costs about **25%** (same page), so the glovebox, the metal shed and the shelf
above the stove are the places that kill cells. Here summer afternoons reach 100 °F, so a shed, an attic or a parked vehicle is the worst place for
cells: keep them in the coolest inside cupboard *(rule of thumb)*.

**The fridge: true, but barely worth it.** The old Navy rule was to keep unused cells "in refrigerated
spaces" ([NEETS 1, p. 86](lib:neets-module-01#page=86)), written for zinc-carbon cells that went off in a
year. Modern alkalines keep for several years between **50 and 77 °F** below 65% humidity
([Practical Action, p. 3](lib:practical-action-batteries#page=3)), which a cool cupboard does. A cold cell
sweats when it comes out, and damp corrodes contacts, so if you do use a fridge, seal the cells in a bag and
let them warm up inside it *(rule of thumb)*.

**Never loose in a drawer with coins, keys or screws, and never left inside gear you are not using.** A 9 V's
terminals sit side by side and a coin across them is a dead short; batteries "can explode, release toxic
gases, or leak hazardous chemicals" when mishandled
([Navy, p. 25](lib:navy-electronics-technician-vol-1-safety#page=25)), and the first rule for every type is
**never short the terminals** ([NEETS 1, p. 96](lib:neets-module-01#page=96)). The Navy's other rule is "Do
Not store carbon-zinc batteries in electronic equipment for extended periods. The corrosive electrolyte
could leak out of the battery and damage the equipment", and it says the alkaline rules are identical
([p. 26](lib:navy-electronics-technician-vol-1-safety#page=26)): a radio put away for a winter with cells in
it is how good radios die. Keep cells in their card, or upright in a box with the + ends one way, and tape
over every 9 V's terminals *(rule of thumb)*.

**Why a "dead" battery still runs a clock.** To the same cut-off voltage, identical cells gave 2.2 hours
through 2 ohms, **20 times** that through 8 ohms and **480 times** through 64 ohms; and a cell whose voltage
"has fallen to one-half its initial value" is "by no means one-half discharged"
([Circular 79, p. 39](lib:electrical-characteristics-and-testing-of-dry-cells#page=39)). The old practice is
to use cells in radios until they quit, then "finish them off" in flashlights, where low voltage only means
a dim yellow light ([Practical Action, p. 3](lib:practical-action-batteries#page=3)). Keep a marked box for
**used but not finished** cells, and feed clocks, remotes and door chimes out of it *(rule of thumb)*.

![Three devices in a row with a battery passed down the line: a flashlight, a remote control and a wall clock, with the hours each gets from the same cell: 2.2 hours through two ohms, twenty times that through eight ohms, four hundred and eighty times through sixty-four ohms](img:BATTERIES-GUIDE/pass-the-cell-down-the-line.svg)
*The same cell, three jobs: what the flashlight calls dead, the clock calls new ([Circular 79, p. 39](lib:electrical-characteristics-and-testing-of-dry-cells#page=39)).*

**Never mix old with new, or one type with another, in one device.** In a series string the strong cells
push current backwards through the weak one, and reversing a cell "usually destroys it completely"; it
happens "when one cell in a battery of ni-cad cells is weaker than the rest", which is "one reason why it is
not a good policy to mix old cells and new ones"
([Practical Action, p. 4](lib:practical-action-batteries#page=4)). In parallel it is as bad the other way:
with unequal voltages "the good batteries will overpower the failed (lower voltage) battery, causing
relatively large currents within the batteries' connecting wires"
([Kuphaldt *DC*, p. 417](lib:lessons-in-electric-circuits-vol-1-dc#page=417)). 1.5 V and 1.2 V cells are not
partners either *(rule of thumb)*.

**A leaking alkaline.** The white crust is the cell's own electrolyte, and it is a caustic alkali, not an
acid — "leakage of caustic alkaline electrolyte" is one of the ways a swallowed battery burns tissue
([CDC MMWR, p. 3](lib:injuries-from-batteries-among-children#page=3)) — so baking soda, which neutralizes
battery acid, does nothing here. Gloves and eye protection; cells out for disposal; brush the crust out dry,
outdoors; wipe with a cloth damp with vinegar, then a clean damp cloth, and dry it fully; scrape the
contacts with a wooden stick and burnish them with fine abrasive paper. Wash skin with plenty of water
*(rule of thumb — no book on this drive gives a cleanup method)*.

**Button and coin cells** are the ones to lock away: of 14 battery deaths of US children over 16 years,
**12 involved button batteries**, and every child was under four
([CDC MMWR, p. 2](lib:injuries-from-batteries-among-children#page=2)). See [Dangers](#dangers); keep spares
in a screw-top jar on a high shelf.

📚 **Go deeper:** [Circular 79 *Testing of Dry Cells*](lib:electrical-characteristics-and-testing-of-dry-cells#page=36) — storage, temperature and how much service a cell gives; [Practical Action *Batteries*](lib:practical-action-batteries#page=2) — sizes and capacity. Pictures: [🖼️ how a cell's voltage falls as it is used, Practical Action p. 2](lib:practical-action-batteries#page=2), [🖼️ warmth and cold change a cell's punch, Circular 79 p. 36](lib:electrical-characteristics-and-testing-of-dry-cells#page=36), [AA battery](wiki:AA_battery), [Button cell](wiki:Button_cell).

## 🔁 Rechargeable AAs, and what they are not
<!-- fold: 1.2 volts instead of 1.5, but it holds steady; buy the low-self-discharge kind -->

A NiMH AA is **1.2 V**, not 1.5 V ([Lighting Global, p. 10](lib:lighting-global#page=10)), and that worries
people for the wrong reason. An alkaline starts at 1.5 V and slides down all its life, ending near 0.9 V
([Practical Action, p. 2](lib:practical-action-batteries#page=2)); a NiMH sits near 1.2 V almost to the end
and then drops off a cliff. In most gear that means brighter for longer, then a sudden stop. A few fussy
low-voltage cut-outs and some old meters call a fresh NiMH flat; everything else is happy *(rule of thumb)*.

- **How many charges:** **500–1,000** ([Lighting Global, p. 10](lib:lighting-global#page=10)); Practical
  Action puts small rechargeables at 100 to 1,000 and says they "work out much less expensive in the long
  run" ([p. 4](lib:practical-action-batteries#page=4)).
- **Buy the low-self-discharge kind.** Ordinary NiMH loses **15–30% a month** in a drawer, the advanced sort
  about **2%** ([Lighting Global, p. 10](lib:lighting-global#page=10)) — the whole difference between a
  working flashlight and a dead one. NiMH has a mild memory effect, less than NiCd (same page); running one
  flat on purpose only does harm *(rule of thumb)*.
- **Charge between 32 and 104 °F** ([Lighting Global, p. 10](lib:lighting-global#page=10)), in series and
  never in parallel ([Navy, p. 27](lib:navy-electronics-technician-vol-1-safety#page=27)), with a charger
  that watches **each cell**: a cheap two-at-a-time charger overcooks the stronger one *(rule of thumb)*.
- **Keep sets together**, marked, so they age as a set
  ([Practical Action, p. 4](lib:practical-action-batteries#page=4)).

**Buy now, while there is a shop:** 16 to 24 low-self-discharge AA and 8 AAA, a charger that handles each
cell on its own, a second charger that runs from 12 V, and AA-to-C and AA-to-D spacers so one size of cell
serves everything *(rule of thumb)*.

📚 **Go deeper:** [Lighting Global, p. 10](lib:lighting-global#page=10) — NiMH against every other chemistry; [Practical Action, p. 4](lib:practical-action-batteries#page=4) — rechargeables, memory and mixing. Pictures: [Nickel–metal hydride battery](wiki:Nickel–metal_hydride_battery), [Rechargeable battery](wiki:Rechargeable_battery).

## ⛔ Never recharge a non-rechargeable

A throw-away cell is "based on an irreversible electrochemical reaction, and consequently cannot be
recharged" ([Practical Action, p. 2](lib:practical-action-batteries#page=2)). Pushing current back into one
does not refill it; it makes gas and heat inside a sealed can.

- **Lithium is the dangerous case.** NASA lists charging among the abuses that make a lithium cell "yield
  their contained energy suddenly and explosively": "Charging lithium cells can result in cell rupture
  and/or explosion", and so can draining one to 0 V and forcing it backwards. The same page warns that
  **parallel connections between cells, batteries and power sources can force a charging current through a
  weak or dead cell** ([JSC-20793, p. 83](lib:nasa-jsc-20793#page=83)) — exactly what happens when someone
  wires a mixed handful of cells together. The standing rule is "Do Not pierce, short-circuit, recharge,
  crush, cut, burn, drop, dismantle, modify, or otherwise carelessly handle them"
  ([Navy, p. 26](lib:navy-electronics-technician-vol-1-safety#page=26); the same caution is in
  [NEETS 1, p. 88](lib:neets-module-01#page=88)).
- **Alkaline and zinc-carbon** rarely explode, but they gas, heat, split the seal and vent caustic paste
  into the charger and whatever it is standing on, and there is nothing to gain *(rule of thumb)*.
- **Coin cells.** A CR2032 is not rechargeable; rechargeable coin cells are marked LIR *(rule of thumb)*.
  Even the old mercury cells came with "recharging of mercury cells is possible, but is not recommended"
  ([NEETS 21, p. 94](lib:neets-module-21#page=94)). **If a cell is marked rechargeable, believe the marking
  and nothing else; anything unmarked is a throw-away.**

## 🚗 Lead-acid away from the solar bank
<!-- fold: A battery that sits goes flat and then sulfates; how to store one, and what reviving really does -->

Watering, equalizing, hydrometers and bank wiring are in
[Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#keeping-lead-acid-alive); starting and charging a vehicle is in
[Vehicles, Tractors & Heavy Equipment](guide:VEHICLES-EQUIPMENT-GUIDE#cars-and-pickups-with-no-shop). This
is the car, truck and tractor battery that spends months doing nothing.

**A battery that sits loses capacity even before it loses charge**, and some of the loss is a temporary
"sluggishness" that takes several charge-and-discharge cycles to clear
([Circular 92, p. 46](lib:operation-and-care-of-vehicle-type-storage-batteries#page=46)). Keep a stored
battery charged: every **3–6 months** flooded ([IEA, p. 23](lib:iea-pvps-lead-acid#page=23)), every 3 sealed
([Practical Action, p. 6](lib:practical-action-batteries#page=6)).

**Standing discharged is what ruins it.** Sulfation "is always the result of some sort of abuse", namely
"(a) standing discharged for some time, (b) neglecting evidence of trouble, (c) replacing loss of water by
electrolyte, and (d) regular undercharging"
([Circular 92, p. 53](lib:operation-and-care-of-vehicle-type-storage-batteries#page=53)). Note (c): topping
up with acid instead of water is one of the four named abuses. Use
[distilled water](wiki:Distilled_water) only ([Navy, p. 27](lib:navy-electronics-technician-vol-1-safety#page=27)),
after a charge; "adding the active ingredient only increases the specific gravity" and "does not bring the
battery back to a charged condition" ([NEETS 1, p. 97](lib:neets-module-01#page=97)). Terminals should be
"tight and free of corrosion", cleaned "with bicarbonate of soda", and a corroded stranded cable end is cut
off rather than brushed ([TM 5-683, p. 24](lib:tm-5-683#page=24)); grease them afterwards
([IEA, p. 25](lib:iea-pvps-lead-acid#page=25)).

**Cold.** A cold battery gives about **13% less for every 18 °F** below 68 °F
([Circular 92, p. 46](lib:operation-and-care-of-vehicle-type-storage-batteries#page=46)), and **a flat
battery freezes and cracks**: at a specific gravity of 1.100 the electrolyte freezes at **18 °F**, at 1.220
at **−31 °F**, and a fully charged battery at 1.285 not until about **−95 °F**
([Navy *Construction Mechanic*, p. 168](lib:navy-construction-mechanic-3-and-2#page=168)). So the most
useful winter job is keeping batteries full. Here most winter nights stay above 20 °F, but a cold snap has reached −6 °F, which is cold enough to
freeze and crack a battery left standing flat: charge anything that overwinters outdoors *(rule of thumb)*. To overwinter one: charge it right up, clean
the top and posts, disconnect it, stand it cool but above freezing and off damp ground, and charge it again
every three months *(rule of thumb, from those pages)*.

**Reviving a sulfated battery — honestly rated.** Three things get called desulfating, and they are not
equal.

| The claim | Does it work? |
|---|---|
| **A long, low finishing charge**, and on a flooded battery an equalizing charge | **Yes, for a battery that was merely undercharged.** Sulfate that has not gone hard is reduced by the current, and the test is that every cell's specific gravity stops rising ([Circular 92, p. 54](lib:operation-and-care-of-vehicle-type-storage-batteries#page=54); [Navy, p. 167](lib:navy-construction-mechanic-3-and-2#page=167); set points in [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#keeping-lead-acid-alive)) |
| **The water treatment**, flooded batteries only: tip the electrolyte out, fill the cells with distilled water, charge at **half** the finishing rate, read each cell's gravity every 4–6 hours, keep the acid under **110 °F**, carry on until every cell has been steady for **12 hours**, then set the gravity | **Sometimes, on a stubborn case.** A real federal procedure, written out in full ([Circular 92, p. 54](lib:operation-and-care-of-vehicle-type-storage-batteries#page=54)). It takes days, a variable charger, a hydrometer and acid, and cannot be done at all on a sealed, AGM or gel battery |
| **Pulse "desulfator" gadgets, Epsom salts, aspirin** | **Wishful.** No book on this drive supports any of them, and the modern reference is blunt: plate sulfate from standing deeply discharged "can never be recovered" ([IEA, p. 23](lib:iea-pvps-lead-acid#page=23)) |

Both the first two and the IEA's verdict can be true at once: the soft sulfate of a battery that went flat
last week often comes back; the hard crystals in one that sat flat all winter do not. **Judge it by a
measured discharge, never by the voltage after charging** — charge it fully, discharge at its normal rate to
**1.70 V per cell** (10.2 V on a 12 V battery), and if it will not give its rated capacity it is still
sulfated ([Circular 92, p. 54](lib:operation-and-care-of-vehicle-type-storage-batteries#page=54)).

📚 **Go deeper:** [Circular 92 *Operation and Care of Vehicle-Type Storage Batteries*](lib:operation-and-care-of-vehicle-type-storage-batteries#page=53) — sulfation, the water treatment, charging and capacity; [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#keeping-lead-acid-alive) — watering, equalizing, hydrometers. Pictures: [🖼️ capacity lost standing idle, Circular 92 p. 46](lib:operation-and-care-of-vehicle-type-storage-batteries#page=46), [🖼️ inside a car battery, TM 9-8000 p. 284](lib:tm-9-8000#page=284), [Lead–acid battery](wiki:Lead–acid_battery).

## 💻 Laptop, tool and e-bike packs: what is inside, and where the line is

**What is inside.** Cells — cylindrical, prismatic or flat pouch
([Lighting Global, p. 4](lib:lighting-global#page=4)) — wired in **series** to add volts and in **parallel**
to add amp-hours ([NEETS 1, pp. 90–91](lib:neets-module-01#page=90)), joined by welded metal strips, with a
small board: the **[battery management system](wiki:Battery_management_system)**. The board is not optional:
"cells used in battery packs should be individually monitored and controlled by a battery management system
(BMS) to prevent electrical abuse", and a pack "should be designed to allow passive cooling of individual
cells, and cell spacing should be designed to prevent thermal runaway from spreading cell-to-cell"
([Lighting Global, p. 8](lib:lighting-global#page=8)). An 18 V tool pack is five cells in series; an 11.1 V
laptop pack is three in series, often two or three such strings in parallel *(rule of thumb)*.

![Inside a battery pack: six cells in three groups, each group two cells joined at both ends by welded strips, the three groups chained one to the next, and a management board below them carrying a fuse, switches and a heat sensor with a thin wire to every joint; the pack reads 11.1 volts at its terminals and 3.7 volts at each cell](img:BATTERIES-GUIDE/inside-a-battery-pack.svg)
*Series for volts, parallel for amp-hours, welded strips between, and a board that watches every cell and can switch the whole pack off (a diagram drawn for this guide).*

**Why a pack "dies" when most of it is fine.** The board shuts the pack down when **any one** cell goes out
of range, so one cell at 2.0 V locks out the four good ones beside it; the board, its fuse or its heat
sensor can also fail. Two common pictures *(rule of thumb)*: **nothing at the terminals but 3.5–3.7 V on
each cell inside** means the board has tripped or gone to sleep (its own charger sometimes wakes it; a dead
board does not come back); **charges for a minute and quits** means one cell or one parallel group is far
below the rest. Measured at the tabs or the balance connector, a healthy pack has every group within about
0.05 V of the others — these cells live by small margins, with an overcharge tolerance of
[50 mV or less per cell](guide:OFF-GRID-POWER-GUIDE#lithium-lifepo4-and-salvaged-packs) — and a group 0.3 V
or more below the rest is the bad one. Open a pack **only** if it opens without cutting, prying or drilling
near a cell: a charged lithium cell is "a fire or explosion hazard if crushed, punctured, or incinerated"
([Lighting Global, p. 8](lib:lighting-global#page=8); see
[Salvage](guide:SALVAGE-GUIDE#never-cut-burn-or-open-these)).

**What a careful person can do:** swap the whole pack, or a whole factory module out of a big one; re-seat a
loose connector; replace a blown pack fuse with the same rating; wake a sleeping pack with its own charger;
rebuild a **NiCd or NiMH** pack with matched new cells (below); or rebuild a lithium pack with **new,
identical, matched** cells and the original board — slow, costly, and only worth it for a tool you cannot
replace.

**What a careful person cannot do** is build a lithium pack out of mixed salvaged cells. NASA's rule for any
pack whose failure matters is that "cells shall be matched in a battery based on charge retention, internal
resistance and/or AC impedance, and ampere-hour capacity", and that cell matching and balancing circuits
"should not be rationale for accepting lots with poor cell lot uniformity"
([JSC-20793, p. 32](lib:nasa-jsc-20793#page=32)). A tub of pulls from six dead laptops is the definition of
a poor lot, and no board and no amount of matching fixes it.

**The hard rules**

1. **Never solder onto a lithium cell.** Tin-lead solder melts at **361 °F**, and 60/40 runs between 361 and
   375 °F ([Navy 2M manual, p. 190](lib:navy-2m-miniature#page=190)) — while the lithium inside the cell
   melts at **356 °F**, and anything that reaches it "is a hazardous condition"
   ([NASA, p. 83](lib:nasa-jsc-20793#page=83)). The iron is hotter than the cell's own melting point. That
   is why packs are spot-welded, and why only a factory-welded tab is ever soldered *(rule of thumb)*.
2. **Never mix cells of different age, make or capacity** ([NASA, p. 32](lib:nasa-jsc-20793#page=32);
   [Practical Action, p. 4](lib:practical-action-batteries#page=4)).
3. **Never build a lithium pack without a balancing board**
   ([Lighting Global, p. 8](lib:lighting-global#page=8)).
4. **Never charge a cell that is swollen, dented, punctured, smells, has changed colour, heats, or has sat
   below 2.5–3 V** — below that a cell is permanently damaged and may be internally shorted
   ([Lighting Global, p. 7](lib:lighting-global#page=7)); the warning signs are an NFPA list
   ([p. 1](lib:nfpa-lithium#page=1)).
5. **Fuse it close to the terminals**, "rated well below the battery's peak current source capability" and
   "as close to the cell or battery terminals as the design will allow"
   ([NASA, p. 44](lib:nasa-jsc-20793#page=44)).
6. **Charge a salvaged pack outdoors or on stone**, away from anything that burns, never on a bed or a
   couch, and never leave it after it is full ([NFPA, p. 1](lib:nfpa-lithium#page=1)).

**Where the line is.** Swapping a whole pack or module is sensible work. Rebuilding a lithium pack from
mixed salvaged cells is how house fires start: one cell in [thermal runaway](wiki:Thermal_runaway) sets off
its neighbours ([NTSB, p. 18](lib:safety-risks-from-lithium-ion-battery-fires#page=18)), and reignition "can
occur within several hours to a day or more after the fire is extinguished"
([p. 67](lib:safety-risks-from-lithium-ion-battery-fires#page=67)).

**NiCd and NiMH packs are a different matter.** Their electrolyte is water-based, with none of the flammable
solvent that makes a lithium cell burn ([Lighting Global, p. 8](lib:lighting-global#page=8)); the cells are
cheap, tolerant and work below freezing
([Practical Action, p. 4](lib:practical-action-batteries#page=4)); and a single cell really can be replaced.
What still holds: every cell the same make and capacity, or the strong ones reverse-charge the weak one and
destroy it (same page); the tabs are spot-welded, so you solder the **tab**, not the cell *(rule of thumb)*;
charge in series, never in parallel, and stay under 113 °F
([Navy, p. 27](lib:navy-electronics-technician-vol-1-safety#page=27)); and NiCd holds cadmium, a toxic metal
([Lighting Global, p. 10](lib:lighting-global#page=10)), so it is never cut open, burned or buried.

📚 **Go deeper:** [NASA JSC-20793](lib:nasa-jsc-20793#page=32) — how packs are built so they do not burn: cell matching, fusing, every short-circuit path; [Lighting Global, p. 8](lib:lighting-global#page=8) — management systems, handling and disposal. Pictures: [🖼️ inside a cylindrical cell, Lighting Global p. 9](lib:lighting-global#page=9), [🖼️ cells in series and in parallel, NEETS 1 pp. 90–91](lib:neets-module-01#page=90), [Battery management system](wiki:Battery_management_system).

## 🔧 Tool batteries: keeping a drill alive for years
<!-- fold: Store part charged and cool, never in a hot truck, and what to do when the packs are gone -->

- **Store lithium packs part charged**, between **20 and 40%** near room temperature; storing one full or
  hot "will put stress on the cell, reduce battery life, and increase the amount of energy available for
  thermal runaway should an accident occur" ([Lighting Global, pp. 7–8](lib:lighting-global#page=7)).
- **Charge between 32 and 105 °F**, and never leave a pack on the charger after it is full
  ([NFPA, p. 1](lib:nfpa-lithium#page=1)); hot charging "will decrease cycle life and may present a safety
  hazard", and charging below freezing grows metal spikes inside the cell that short it and can start a fire
  ([Lighting Global, p. 7](lib:lighting-global#page=7)). Warm a cold pack in your coat and charge it indoors
  *(rule of thumb)*. A NiCd pack, by contrast, works at sub-zero temperatures
  ([Practical Action, p. 4](lib:practical-action-batteries#page=4)).
- **NiCd packs:** charge in series, never parallel; stay under 113 °F; do not store them in the same box as
  lead-acid batteries ([Navy, p. 27](lib:navy-electronics-technician-vol-1-safety#page=27)). The "waking up"
  routine of three or four full cycles is for sealed NiCd only
  ([Practical Action, p. 4](lib:practical-action-batteries#page=4)), never NiMH or lithium
  ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#old-advice-in-the-library-to-ignore)).
- **Label and rotate.** Write the month on each pack, use them in turn, and keep the best one for the job
  that needs the run time *(rule of thumb)*.

**When the packs are gone.** Most cordless tools are plain DC motors, so a dead pack's gutted shell with
heavy wire out to a 12 V battery through a fuse will run an 18 V drill slowly and a 12 V drill properly
*(rule of thumb)*. More volts than the tool's rating burns out the motor or the switch. The dependable
answers are a corded tool and an inverter
([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#charge-controllers-and-inverters)), a hand drill, or a brace;
and the motors and magnets in dead tools are worth keeping either way
([Salvage](guide:SALVAGE-GUIDE#ceiling-fans-drills-and-power-tools)).

📚 **Go deeper:** [NFPA *Lithium-Ion Battery Safety*](lib:nfpa-lithium#page=1) — one page of charging rules worth pinning up; [Lighting Global, p. 7](lib:lighting-global#page=7) — charge limits, storage charge and cold charging.

## 🔌 Charging with no proper charger
<!-- fold: Constant current and constant voltage in plain words, and what each chemistry will put up with -->

"The two principal methods of charging are (1) constant current, and (2) constant voltage (constant
potential). Constant current charging may be used on a single battery or a number of batteries in series.
Constant potential charging is used with batteries connected in parallel" — and only direct current will do
it, so alternating current must go through a rectifier first
([Navy *Construction Mechanic*, p. 166](lib:navy-construction-mechanic-3-and-2#page=166)).

In plain words: **constant current** means you fix the amps, watch the volts climb and stop by yourself;
**constant voltage** means you fix the volts and the amps fall away as the battery fills, which stops
itself. A lithium cell needs both in turn — constant current to the cell's limit, then constant voltage
while the current dies away ([Lighting Global, p. 7](lib:lighting-global#page=7)).

| Battery | How to charge it with what you have |
|---|---|
| **Flooded lead-acid** | Most forgiving: any rate that does not cause heavy gassing, overcharge or heat ([IEA, p. 20](lib:iea-pvps-lead-acid#page=20)). Too high a rate "will overheat and damage the plates", and it is full when the specific gravity has stopped rising for two hours ([Navy, p. 167](lib:navy-construction-mechanic-3-and-2#page=167)). Set points: [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#keeping-lead-acid-alive) |
| **AGM and gel** | The same idea at lower limits, never past the maker's figure ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#keeping-lead-acid-alive)) |
| **NiCd and NiMH** | In series, never parallel ([Navy, p. 27](lib:navy-electronics-technician-vol-1-safety#page=27)). A slow charge is the forgiving one — about a tenth of the cell's amp-hour rating for 14 hours *(rule of thumb: no book here gives that figure)*. NiCd puts up with overcharge better than NiMH ([Practical Action, p. 4](lib:practical-action-batteries#page=4)) |
| **LiFePO4 and lithium-ion** | **Do not improvise.** Only a charger or controller made for the chemistry, never below 32 °F, never an "equalize" setting ([Lighting Global, p. 7](lib:lighting-global#page=7); [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#lithium-lifepo4-and-salvaged-packs)) |
| **Alkaline, zinc-carbon, lithium primary** | Never ([above](#never-recharge-a-non-rechargeable)) |

**From a solar panel:** through a charge controller, always, for a lead-acid battery, because overcharging
leads to "electrolysis of the water ('boiling' the water out of the battery) and shortened life"
([Kuphaldt, p. 417](lib:lessons-in-electric-circuits-vol-1-dc#page=417)); sizing is in
[Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#charge-controllers-and-inverters). A few watts on a parked
vehicle's battery is the old trickle trick and still wants checking *(rule of thumb)*. **From a car or a
generator:** + to +, − to −, run the generator under load, and treat violent gassing as a sign the rate is
too high ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#generators-cars-and-backfeed)). **From a hand crank or
a bicycle:** a few watts at best — a phone or a radio through a proper regulator, nothing like a bank
*(rule of thumb)*.

**The resistor-and-meter charger.** A 12 V source, a resistor and a meter in series make a crude
constant-current charger: **amps = (source volts − battery volts) ÷ ohms** *(arithmetic, from Ohm's law; see
[Practical Math](guide:PRACTICAL-MATH-GUIDE))*. Pick the resistor for the current you want, check it with
the meter, and watch the voltage and the temperature. It wastes most of the energy as heat, has no idea when
to stop, and needs a person in the room with a watch. Use it for flooded lead-acid, NiCd or NiMH if you
must, and **never for lithium of any kind**. Charge in a vented place, away from flame
([below](#dangers)).

📚 **Go deeper:** [Navy *Construction Mechanic*, pp. 166–167](lib:navy-construction-mechanic-3-and-2#page=166) — charging methods, rates and when a battery is full; [Lighting Global, p. 7](lib:lighting-global#page=7) — the lithium charge curve. Pictures: [🖼️ current and voltage through a lithium charge, Lighting Global p. 7](lib:lighting-global#page=7), [Battery charger](wiki:Battery_charger).

## 📏 Testing with no tester

**Buy a multimeter** — cheap now, the only instrument in this guide, and nothing else tells you what a
battery is doing. Set it to DC volts and touch the leads to the terminals, red to +, black to −
([*Multimeters*, p. 19](lib:multimeters-how-to-measure-voltage-current-resistance-kuphaldt#page=19); more in
[NEETS 16](lib:neets-module-16#page=112) and
[Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE#electronics-repair-and-salvage)) *(rule of thumb: buy two,
and spare probes)*.

| Battery | At rest, in good order | Call it finished at |
|---|---|---|
| Alkaline or zinc-carbon AA | **1.50–1.60 V** fresh; under **1.45 V** means age, damage or a fault ([Circular 79, p. 53](lib:electrical-characteristics-and-testing-of-dry-cells#page=53)) | Below about 1.2 V for most gear *(rule of thumb)* |
| NiMH or NiCd | **1.25–1.30 V** open circuit ([NEETS 21, p. 94](lib:neets-module-21#page=94)) | **1.1 V** is completely discharged; no lower (same page) |
| Lithium-ion cell | 3.6–3.7 V nominal, about 4.2 V full ([Lighting Global, pp. 7, 10](lib:lighting-global#page=7)) | Below **2.5–3.0 V** it is damaged, not flat (p. 7) |
| 12 V lead-acid | **12.9 V** full, **12.0 V** empty at rest ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#choosing-batteries-and-reading-their-charge)) | Never below about 10.8 V under load (same) |

**Why voltage under load is the real test.** The Bureau of Standards kept one dry cell under observation for
20 years: on a laboratory instrument that draws almost no current it still read **1.36 V**, but on an
ordinary voltmeter it read **0.215 volt**, because the cell's internal resistance had risen
([Circular 79, p. 53](lib:electrical-characteristics-and-testing-of-dry-cells#page=53)). That is exactly
what a tired AA does in a flashlight; and the other way round, a cell at half voltage is "by no means
one-half discharged" ([p. 39](lib:electrical-characteristics-and-testing-of-dry-cells#page=39)). The meter
alone cannot tell you either thing; the meter **with a load on** can.

![Load-testing a 1.5 volt cell: with nothing connected the meter reads 1.52 volts on both cells, but with a bulb across them the good cell holds 1.28 volts and the worn one falls to 0.70 volts with the bulb barely glowing](img:BATTERIES-GUIDE/load-test-a-cell.svg)
*The meter alone says both cells are fine. With a bulb across them, the worn cell collapses (a diagram drawn for this guide).*

- **A 1.5 V cell:** hold the meter on the cell and switch on a small bulb, a 2.2-ohm resistor or the device
  itself. A sound AA stays above about **1.2 V**; a worn one falls below 1.0 V within seconds *(rule of
  thumb)*.
- **A pack:** read every series group at the tabs or the balance connector, charged, then again after a few
  minutes of use ([above](#laptop-tool-and-e-bike-packs-what-is-inside-and-where-the-line-is)).
- **A 12 V battery:** the only honest test is a timed discharge at a known current. Batteries are rated at
  the **20-hour rate**, and "all standard batteries deliver 100 percent of their available capacity if
  discharged in 20 hours or more, but they will deliver less than their available capacity if discharged at
  a faster rate" ([NEETS 1, pp. 96–97](lib:neets-module-01#page=96)); the classic end point is **1.70 V per
  cell**, 10.2 V on a 12 V battery
  ([Circular 92, p. 54](lib:operation-and-care-of-vehicle-type-storage-batteries#page=54)), and headlight
  bulbs make a cheap known load *(rule of thumb)*. On a flooded battery a [hydrometer](wiki:Hydrometer) is
  quicker: full reads **1.275–1.290** at 77 °F
  ([Circular 92, p. 55](lib:operation-and-care-of-vehicle-type-storage-batteries#page=55)), below 1.240 "is
  a danger signal", corrected for temperature
  ([Navy, p. 166](lib:navy-construction-mechanic-3-and-2#page=166)).
- **Do not test a cell by shorting it.** The 1923 federal test for carbon-zinc cells did measure
  short-circuit current with a calibrated ammeter, and the same page warns the result "is not a true measure
  of the cell's capacity" ([Circular 79, p. 53](lib:electrical-characteristics-and-testing-of-dry-cells#page=53)).
  With a modern alkaline, lithium or rechargeable cell it is simply dangerous
  ([NEETS 1, p. 88](lib:neets-module-01#page=88)).

**Signs a cell or pack will not hold charge** *(rule of thumb)*: it charges in minutes and empties in
minutes; it warms just sitting on charge; it reads full an hour after charging and low next morning; a
rechargeable AA full a fortnight ago is flat (ordinary NiMH loses 15–30% a month —
[Lighting Global, p. 10](lib:lighting-global#page=10)); a pack whose groups have drifted apart; or one cell
of a flooded battery whose gravity stays low after an equalizing charge.

📚 **Go deeper:** [*Multimeters: How to Measure Voltage, Current and Resistance*](lib:multimeters-how-to-measure-voltage-current-resistance-kuphaldt#page=19) — using a meter from scratch; [Circular 79, p. 53](lib:electrical-characteristics-and-testing-of-dry-cells#page=53) — what the voltage test shows and what it hides. Pictures: [🖼️ a meter across a component, *Multimeters* p. 19](lib:multimeters-how-to-measure-voltage-current-resistance-kuphaldt#page=19), [🖼️ reading a hydrometer, NEETS 1 p. 95](lib:neets-module-01#page=95), [Multimeter](wiki:Multimeter).

## ⚠️ Dangers

**Shorting, the one that catches careful people.** The first safety rule for every type is "NEVER SHORT THE
TERMINALS OF A BATTERY" ([NEETS 1, p. 96](lib:neets-module-01#page=96)), and shorted cells have "exploded
with considerable force" ([p. 88](lib:neets-module-01#page=88)). A wrench across a car battery's posts
carries thousands of amps — one golf-cart battery can push about **8,000 A**
([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#battery-safety)). The wrench glows, welds itself to the posts,
and the heat can boil acid out of the cells. Take off rings and watches, tape wrench handles, keep a cover
on the + post, fit the main fuse right at the + terminal, and if a tool does short a battery, **get away
rather than grab it** (same section). In a pack the fuse goes as close to the terminals as the design
allows, rated well below what the cells can push ([NASA, p. 44](lib:nasa-jsc-20793#page=44)).

![A wrench laid across a car battery's two posts, glowing and welded there, with a red arrow showing thousands of amps and acid spitting from a vent cap; beside it the right way, with a cover on the positive post, a taped wrench handle and rings and watch taken off](img:BATTERIES-GUIDE/shorted-battery-and-wrench.svg)
*A dropped wrench is a short circuit: thousands of amps, a red-hot wrench welded to the posts and boiling acid. Cover the post, tape the handles, take the rings off (a diagram drawn for this guide).*

**Hydrogen.** "Any battery containing water in the electrolyte is subject to the production of hydrogen gas"
when charged ([Kuphaldt, p. 417](lib:lessons-in-electric-circuits-vol-1-dc#page=417)), hydrogen with air "is
flammable and/or explosive" ([NASA, p. 38](lib:nasa-jsc-20793#page=38)), and **4% in air is enough**
([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#battery-safety)). No smoking, flames or sparks near a charging
battery ([NEETS 1, p. 96](lib:neets-module-01#page=96)); vent the top of the space; check the water level
with a flashlight, never a match.

**Acid.** Flush skin or eyes "with large quantities of fresh water for a minimum of 15 minutes", eyelids
held apart, and get help ([NEETS 1, p. 96](lib:neets-module-01#page=96)). Goggles and rubber gloves whenever
a cap comes off. When mixing, **always pour the acid into the water**, and keep the level above the
separators ([Navy, p. 27](lib:navy-electronics-technician-vol-1-safety#page=27)); neutralize spills with
baking soda and water ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#keeping-lead-acid-alive)). **Never put
salt water in a lead-acid battery: it makes chlorine gas**
([Navy, p. 27](lib:navy-electronics-technician-vol-1-safety#page=27)). The white paste out of a leaking
alkaline cell is caustic the other way round and burns too
([CDC MMWR, p. 3](lib:injuries-from-batteries-among-children#page=3)).

**Lithium fires, which come back.** A charged lithium cell is "a fire or explosion hazard if crushed,
punctured, or incinerated" ([Lighting Global, p. 8](lib:lighting-global#page=8)), and abused cells can vent
sulfur dioxide, thionyl chloride or hydrogen chloride ([NASA, p. 83](lib:nasa-jsc-20793#page=83)). If one
burns: **put out the flames, then soak the pack with water from a distance to cool it — never cover it, use
ice, or pick it up** ([FAA SAFO 09013](lib:faa-safo#page=1)). **Keep cooling after the flames are gone**,
which "could take an hour or more", because reignition "can occur within several hours to a day or more
after the fire is extinguished" ([NTSB, p. 67](lib:safety-risks-from-lithium-ion-battery-fires#page=67)).
**Get out of the room and stay out:** one cell's runaway sets off the next
([p. 18](lib:safety-risks-from-lithium-ion-battery-fires#page=18)), the gas is toxic and flammable, and a
pack can reignite days later ([fire FAQ, p. 2](lib:home-lithium-ion-battery-fire#page=2)). A damaged pack
also holds "stranded energy" that can shock whoever handles it
([NTSB, p. 10](lib:safety-risks-from-lithium-ion-battery-fires#page=10)), so leave a burned pack outdoors,
in the open, for days.

**A swallowed button cell: a two-hour emergency.** A coin cell lodged in a child's gullet makes hydroxide
against the tissue and "can cause serious burns in only 2 hours". The symptoms are "relatively nonspecific" —
vomiting, belly pain, fever, diarrhoea, trouble breathing, trouble swallowing — so the diagnosis gets missed,
and the worst injuries come from **3 V coin cells of 20 mm or more**, the CR2032 size
([CDC MMWR, p. 3](lib:injuries-from-batteries-among-children#page=3)). Of 14 child deaths recorded over 16
years, 12 involved button batteries, all the children were under four, and in four cases the child was
examined and sent home before anyone found the battery
([p. 2](lib:injuries-from-batteries-among-children#page=2)).

1. **Go now,** to whoever can take an X-ray and get it out. Do not wait for symptoms, and do not wait to be
   sure.
2. **Say out loud that it may be a battery,** and bring an identical one so its size can be read.
3. **Do not make the child vomit, and give no food or drink** *(rule of thumb)*. US poison centres also now
   advise honey by mouth on the way to hospital for a child over one year, but no book on this drive says
   so, so ask a doctor if you can reach one *(not in the books here)*.
4. **It is not over when the battery comes out.** Children sent home after removal have bled fatally
   "several days to weeks later" ([p. 2](lib:injuries-from-batteries-among-children#page=2)): treat blood,
   chest or belly pain, vomiting or trouble swallowing as an emergency.
5. **Prevent it:** battery doors that need a screwdriver or are taped shut, spares in a screw-top jar out of
   reach, and a check of what these cells come out of — toys, flashlights, remote controls, watches, hearing
   aids and light-up jewellery ([p. 2](lib:injuries-from-batteries-among-children#page=2)).

**Disposal.** Never burn a battery: carbon-zinc cells "could explode" in a fire and hold metal pollutants
([Navy, p. 26](lib:navy-electronics-technician-vol-1-safety#page=26)). A charged lithium cell crushed in a
garbage truck starts fires — the EPA traced **245 fires at 64 US waste facilities** to lithium batteries,
some of which destroyed whole buildings
([EPA, p. 7](lib:an-analysis-of-lithium-ion-battery-fires-in-waste#page=7)) — and they "should be fully
discharged before disposal" ([Lighting Global, p. 8](lib:lighting-global#page=8)). Lead and cadmium are
poisonous ([p. 10](lib:lighting-global#page=10)). Tape the terminals of every dead cell, keep them in a
steel or glass container away from the house, and hand them in where they are taken
([Sanitation](guide:SANITATION-GUIDE#hazardous-waste-batteries-oil-fuel-chemicals-medicines)). Nearest takers here are the scrapyards and auto parts stores in Grants Pass for lead-acid; for
household cells and packs, ask the county's transfer station what it will accept before you drive out
*(rule of thumb)*.

📚 **Go deeper:** [FAA SAFO 09013](lib:faa-safo#page=1) — the two-step method for a burning lithium pack; [NTSB *Lithium-Ion Battery Fires*](lib:safety-risks-from-lithium-ion-battery-fires#page=66) — reignition, stranded energy, how much water it takes; [CDC MMWR](lib:injuries-from-batteries-among-children#page=3) — swallowed batteries; [EPA](lib:an-analysis-of-lithium-ion-battery-fires-in-waste#page=7) — battery fires in the waste stream.

## 🎯 Getting the most out of what you have
<!-- fold: Which gear deserves the best cells, and what to stock while there is still a shop -->

**Put the right cell in the right job.** Lithium primaries, with a shelf life "of up to 20 years"
([NEETS 1, p. 88](lib:neets-module-01#page=88)), belong in the smoke alarm, the emergency radio, the winter
headlamp and the kit you hope never to open; NiMH in everything used weekly; alkaline in daily gear; and
tired cells in clocks and remotes, where a cell gives hundreds of times the service it gave the flashlight
([Circular 79, p. 39](lib:electrical-characteristics-and-testing-of-dry-cells#page=39)).

**Rechargeables plus a small panel are the long-term answer.** Throw-away cells are "one of the least
cost-effective electrical power sources", at between **US$140 and $1,300 per kWh** — 700 to 6,500 times grid
power ([Practical Action, pp. 2–3](lib:practical-action-batteries#page=2)) — while small NiMH cells "work
out much less expensive in the long run since they can be recharged and re-used from 100 to 1,000 times" and
"are particularly well suited for small photovoltaic application"
([p. 4](lib:practical-action-batteries#page=4)). A 10–20 W panel, a controller and a 12 V cell charger keep
a household in AA cells for years
([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#charge-controllers-and-inverters)). Then use less: modern LEDs
give about 80–150 lumens per watt
([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#old-advice-in-the-library-to-ignore)), so a 3 W LED headlamp on
two NiMH cells beats a shelf of old flashlights
([Light Without Power](guide:LIGHTING-GUIDE#which-light-for-which-job)), and the load most worth planning
for is the radio ([Using a Radio](guide:USING-A-RADIO-GUIDE)).

**What to stock now** *(rule of thumb)*: 16–24 low-self-discharge NiMH AA and 8 AAA, with a charger that
handles each cell separately and a second one that runs from 12 V; a card of lithium AA for cold and
storage, the coin cells your gear takes, and a couple of 9 V; dated alkaline AA/AAA in a cool cupboard,
checked yearly with the meter; two multimeters, spare probes, a 2.2-ohm resistor and small bulbs for load
tests; a hydrometer, distilled water, baking soda, goggles, rubber gloves, a terminal brush and grease;
fuses and holders in several ratings, and heavy battery cable with lugs; and a spare charge controller and
12 V USB adapter in a [Faraday can](guide:EMP-GUIDE). **Standardize on AA** wherever the gear lets you.

📚 **Go deeper:** [Practical Action *Batteries*, pp. 3–4](lib:practical-action-batteries#page=3) — what dry cells really cost and why rechargeables win; [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — the jobs that need no battery at all.

## 🆘 If this goes wrong

| What happened | What to do |
|---|---|
| A tool shorted a car battery; the wrench is welded on and glowing | **Get away; do not grab it** ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#battery-safety)). Expect boiling acid and a possible rupture; deal with it from a distance, goggles on, once it has cooled |
| Acid in the eyes or on skin | Flush with plenty of water for **at least 15 minutes**, eyelids held apart, then get help ([NEETS 1, p. 96](lib:neets-module-01#page=96)); [Burns](guide:FIELD-CARE-GUIDE#burns) |
| A child may have swallowed a button cell | Hospital **now**, for an X-ray and removal; say it may be a battery; no food, no drink, no making them vomit ([above](#dangers)) |
| A pack is swollen, hot, smells or has changed colour | Stop using it and stop charging it; put it outdoors on stone away from anything that burns, and never charge it again ([NFPA, p. 1](lib:nfpa-lithium#page=1)) |
| A lithium pack is burning | Flames out, then soak it with water from a distance; do not cover it or pick it up; leave the room and expect it to reignite ([above](#dangers)) |
| Cells leaked inside a flashlight or radio | Gloves and eye protection; cells out; brush the crust out dry outdoors, wipe with a vinegar-damp cloth, dry, clean the contacts ([above](#small-batteries-aa-to-9-v-and-button-cells)) |
| A car battery sat flat all winter | Charge it slowly, then **measure** it with a timed discharge or a hydrometer; if it will not give its capacity it is sulfated ([above](#lead-acid-away-from-the-solar-bank)) |
| A pack reads 0 V at its terminals | Probably the board, not the cells; try its own charger, and measure the groups inside only if the pack opens without cutting ([above](#laptop-tool-and-e-bike-packs-what-is-inside-and-where-the-line-is)) |
| Rechargeable AAs go flat in the drawer in a fortnight | Ordinary NiMH loses 15–30% a month; replace them with low-self-discharge cells ([Lighting Global, p. 10](lib:lighting-global#page=10)) |
| A parallel bank keeps blowing the main fuse | A failed battery is being overpowered by the good ones: fuse each battery separately and find the bad one ([Kuphaldt, p. 417](lib:lessons-in-electric-circuits-vol-1-dc#page=417)) |

## ⚠️ Old advice in the library to ignore

| Old book | What it says | Do this instead |
|---|---|---|
| [NEETS 21, p. 94](lib:neets-module-21#page=94) | "The alkaline cell provides 1.2 volts" | An alkaline AA is **1.5 V** ([NEETS 1, p. 88](lib:neets-module-01#page=88); [Practical Action, p. 2](lib:practical-action-batteries#page=2)); 1.2 V is the NiMH and NiCd figure. That one sentence mixes up the two kinds people most often confuse |
| [NEETS 21, p. 94](lib:neets-module-21#page=94) | "Discard both types of batteries at the first indication of weakness" | Right for a warship's radio room, wasteful at home: move weak cells down to light work ([Circular 79, p. 39](lib:electrical-characteristics-and-testing-of-dry-cells#page=39)) |
| [NEETS 21, p. 94](lib:neets-module-21#page=94) | NiCd cells "can be stored for a number of years with no significant loss of performance" | A sealed NiCd loses **15–20% a month** ([Lighting Global, p. 10](lib:lighting-global#page=10)) and self-discharges faster than lead-acid ([Practical Action, p. 4](lib:practical-action-batteries#page=4)). Charge one before you trust it |
| [NEETS 1, p. 86](lib:neets-module-01#page=86) | Unused cells "should be stored in refrigerated spaces" | The direction is right ([Circular 79, p. 37](lib:electrical-characteristics-and-testing-of-dry-cells#page=37)), but modern alkalines keep for years at 50–77 °F ([Practical Action, p. 3](lib:practical-action-batteries#page=3)); a cool cupboard is enough, and a cold cell sweats when it comes out *(rule of thumb)* |
| [Circular 92, p. 46](lib:operation-and-care-of-vehicle-type-storage-batteries#page=46) | To revive an idle battery, discharge it to zero "then short-circuit for at least 5 hours" | That is for **Edison nickel-iron** cells, which no longer exist outside museums. Never short a modern battery of any kind ([NEETS 1, p. 96](lib:neets-module-01#page=96)) |
| [Practical Action, p. 4](lib:practical-action-batteries#page=4) | "Wake" cells by fully charging and discharging them three or four times | Sealed **NiCd** only. Running NiMH or lithium flat on purpose shortens their life, and below 2.5–3 V a lithium cell is ruined ([Lighting Global, p. 7](lib:lighting-global#page=7)) |
| Garage lore | "A concrete floor drains a battery" | It came from the days of wooden battery cases. Keep a battery clean, charged and off wet ground and the floor does not matter *(rule of thumb — no book on this drive supports the claim)* |

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; the other links are photos in the offline
Wikipedia.

**Inside batteries**
- A dry cell cut open, and small button-type cells — [🖼️ NEETS 1, p. 86](lib:neets-module-01#page=86), [🖼️ p. 87](lib:neets-module-01#page=87); [Zinc–carbon battery](wiki:Zinc–carbon_battery), [Button cell](wiki:Button_cell)
- Cylindrical, prismatic and pouch lithium cells, and inside one — [🖼️ Lighting Global, p. 4](lib:lighting-global#page=4), [🖼️ p. 9](lib:lighting-global#page=9); [Lithium-ion battery](wiki:Lithium-ion_battery)
- Inside a car battery — [🖼️ TM 9-8000, p. 284](lib:tm-9-8000#page=284); [🖼️ *Equipment Operator*, p. 93](lib:navy-equipment-operator-basic#page=93); [Lead–acid battery](wiki:Lead–acid_battery)

**Small cells, packs and charging**
- How a cell's voltage falls as it is used; hours of service against the load — [🖼️ Practical Action, p. 2](lib:practical-action-batteries#page=2), [🖼️ Circular 79, p. 41](lib:electrical-characteristics-and-testing-of-dry-cells#page=41); [AA battery](wiki:AA_battery)
- Warmth and cold change a cell's punch — [🖼️ Circular 79, p. 36](lib:electrical-characteristics-and-testing-of-dry-cells#page=36)
- Cells in series and in parallel, and fusing each battery in a bank — [🖼️ NEETS 1, p. 90](lib:neets-module-01#page=90), [🖼️ Practical Action, p. 1](lib:practical-action-batteries#page=1), [🖼️ Kuphaldt *DC*, p. 417](lib:lessons-in-electric-circuits-vol-1-dc#page=417)
- Current and voltage through a lithium charge; blocking diodes on each series string — [🖼️ Lighting Global, p. 7](lib:lighting-global#page=7), [🖼️ NASA JSC-20793, p. 85](lib:nasa-jsc-20793#page=85); [Battery charger](wiki:Battery_charger), [Battery management system](wiki:Battery_management_system)

**Lead-acid care and testing**
- Capacity lost standing idle, and against the rate of discharge — [🖼️ Circular 92, p. 46](lib:operation-and-care-of-vehicle-type-storage-batteries#page=46), [🖼️ p. 45](lib:operation-and-care-of-vehicle-type-storage-batteries#page=45)
- Reading a hydrometer, and the temperature correction — [🖼️ NEETS 1, p. 95](lib:neets-module-01#page=95), [🖼️ Navy *Construction Mechanic*, p. 166](lib:navy-construction-mechanic-3-and-2#page=166); [Hydrometer](wiki:Hydrometer)
- A meter across a component; setting up an ohmmeter — [🖼️ *Multimeters*, p. 19](lib:multimeters-how-to-measure-voltage-current-resistance-kuphaldt#page=19), [🖼️ NEETS 16, p. 112](lib:neets-module-16#page=112); [Multimeter](wiki:Multimeter)

---

## 🔗 Related guides

- [Off-Grid Power: Solar, Batteries & Creek Hydro](guide:OFF-GRID-POWER-GUIDE#choosing-batteries-and-reading-their-charge) — the solar battery bank: choosing, sizing, watering, equalizing, battery rooms, lithium banks, controllers and inverters
- [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — water tanks, heat and cold: the stores that never wear out
- [Vehicles, Tractors & Heavy Equipment](guide:VEHICLES-EQUIPMENT-GUIDE#cars-and-pickups-with-no-shop) — starting, charging and jump-starting a vehicle, and the packs in electric cars
- [Salvage: Useful Things From Broken Things](guide:SALVAGE-GUIDE#never-cut-burn-or-open-these) — what to take from dead appliances and cars, and what never to cut open
- [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE#electronics-repair-and-salvage) — soldering, meters and fixing small electronics
- [Light Without Power](guide:LIGHTING-GUIDE#which-light-for-which-job) — which light for which job, and how little a good LED needs
- [Using a Radio](guide:USING-A-RADIO-GUIDE) — the load most worth keeping powered
- [EMP & Solar Storms](guide:EMP-GUIDE) — spare chargers, controllers and radios in a Faraday can
- [Sanitation & Waste](guide:SANITATION-GUIDE#hazardous-waste-batteries-oil-fuel-chemicals-medicines) — getting rid of dead batteries, oil and chemicals safely
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — charging from a generator, and motors as generators
- [Practical Math](guide:PRACTICAL-MATH-GUIDE) — volts, amps, watts and amp-hours, worked slowly
