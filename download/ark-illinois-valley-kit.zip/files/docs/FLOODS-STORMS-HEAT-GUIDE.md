# 🌊 Floods, Ice Storms & Heat Waves With No Grid

How a household in the Illinois Valley can ride out the weather disasters that come with no power, no forecast and no rescue:
floods and debris flows and the clean-up after; winter storms, ice, carbon monoxide, frozen pipes and falling trees; heat
waves with no air conditioning; and windstorms. In the Illinois Valley the county rates floods ([County plan, p. 46](lib:josephine-county-multi-jurisdictional#page=46)),
extreme heat ([p. 58](lib:josephine-county-multi-jurisdictional#page=58)), windstorms ([p. 61](lib:josephine-county-multi-jurisdictional#page=61))
and winter storms ([p. 64](lib:josephine-county-multi-jurisdictional#page=64)) each "high" probability: one may strike within 10 to 35
years. A moderate to severe winter storm comes about once a year. Most books: FEMA's *Are You Ready?* (2004 and 2020) in
`Southern-Oregon\Earthquake-Tsunami`; the weather spotter's guide in `Southern-Oregon\Navigation-Weather\Weather`; EPA's
flooded-well sheet in `Southern-Oregon\Water-Wells-Pumps\Water-Quality`; the septic bulletin in
`Southern-Oregon\Sanitation-Hygiene\Septic-Greywater`; FEMA P-1019 (storms and power lines) in `Southern-Oregon\Fuel\Fuel-Quality-Storage`;
the CPSC carbon monoxide leaflets in `Southern-Oregon\Homestead-Skills\Cooking-Heating` and `Southern-Oregon\Off-Grid-Power`;
and a report on the 2021 heat-wave deaths in `Southern-Oregon\Disaster-Scenarios\Fire-Heat-Drought`.

> ### The short version
> - **Never drive or walk into moving water.** "Six inches of fast-moving water can knock you off your feet," and "Two feet
>   of moving water will carry away most vehicles." More than half of flood drownings happen in a vehicle driven into the
>   water ([Spotter Guide, p. 12](lib:weather-spotters-field-guide#page=12)).
> - **If a flash flood is possible, walk to high ground now.** "Do not wait for instructions to move"; flash floods come
>   "with or without" rain clouds or heavy rain ([FEMA, p. 53](lib:are-you-ready-citizen-preparedness-guide-2004#page=53)).
> - **Generators, grills, camp stoves and charcoal stay outdoors,** at least 20 ft from windows ([FEMA 2020, p. 15](lib:are-you-ready-citizen-preparedness-guide-2020#page=15)).
>   Carbon monoxide "CAN KILL YOU IN MINUTES," even with doors and windows open ([CPSC, p. 1](lib:cpsc-portable-generator#page=1)).
> - **After a flood:** throw out all food that touched the water ([FEMA 2020, p. 31](lib:are-you-ready-citizen-preparedness-guide-2020#page=31)),
>   don't run or drink from a flooded well until it is disinfected and tested, and don't use the septic system until the water is
>   gone ([EPA, pp. 1–3](lib:what-to-do-after-the-flood-private-wells#page=1)).
> - **In a winter outage, heat one room.** If the house will go cold for days, shut the water off and drain the pipes
>   ([*Household Discoveries*, p. 103](lib:household-discoveries#page=103)). Keep **50 ft** from a downed line
>   ([Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23)).
> - **In a heat wave, check on everyone who lives alone, twice a day** *(rule of thumb)*. In the 2021 heat dome at least 48 of
>   the 68 dead who had a home lived alone, and half of all the dead had only a fan ([heat report, pp. 10, 12](lib:excessive-heat-events#page=10)).
> - **Cool the house by night, shut it by day:** windows open in the cool of the night, then windows and shades closed before
>   it gets hot ([EPA smoke guide, p. 49](lib:epa-wildfire-smoke-guide-2026#page=49)).
> - **Drink before you are thirsty.** "Very hot temperatures can double the amount of water needed" ([FEMA, p. 34](lib:are-you-ready-citizen-preparedness-guide-2004#page=34)).

---

## 🌊 The first hour of a flood

1. **A flash flood is possible? Leave on foot for high ground now.** "If there is any possibility of a flash flood, move
   immediately to higher ground. Do not wait for instructions to move" ([FEMA, p. 53](lib:are-you-ready-citizen-preparedness-guide-2004#page=53)).
   Below a steep or burned slope, the rule is the same: "If you wait, you are too late" ([USGS, p. 1](lib:usgs-postfire-debris-flow#page=1)).
2. **Stay out of moving water,** in a car or on foot (next section). If your vehicle is caught in rising water, "leave it
   immediately and get to higher ground" ([Spotter Guide, p. 12](lib:weather-spotters-field-guide#page=12)).
3. **Trapped in a building:** go to the highest floor, but "do not climb into a closed attic, as you may become trapped there
   if floodwater rises. Go onto the roof only if necessary. Signal for help" ([FEMA 2020, p. 12](lib:are-you-ready-citizen-preparedness-guide-2020#page=12)).
   In a debris flow, get upstairs or on the roof; outdoors, go uphill or climb a tree ([USGS, p. 1](lib:usgs-postfire-debris-flow#page=1)).
4. **If there is time before you go:**
   - **Power off at the main switch,** but only if you are dry: "Do not touch electrical equipment if you are wet or standing
     in water" ([FEMA, p. 53](lib:are-you-ready-citizen-preparedness-guide-2004#page=53)).
   - **Propane:** close the valve at the tank, fasten its dome, turn off pilot lights ([propane tips, p. 10](lib:home-safe-home-propane#page=10)).
   - **Septic:** power to it off at the panel, stop all water use, and plug floor drains so sewage can't back up into the
     house ([Texas A&M, p. 4](lib:septic-systems-responding-to-electrical-power-outages#page=4)).
   - **Move essential items to an upper floor** ([FEMA, p. 53](lib:are-you-ready-citizen-preparedness-guide-2004#page=53)), and fill
     clean jugs with drinking water before the well is flooded *(rule of thumb)*.
   - **Animals:** open the gates to high ground. Never go back through water for an animal *(rule of thumb)*.
5. **Take** medicines, papers, a radio, lights, water, and dry, warm clothes for each person *(rule of thumb)*.

## 🚗 Moving water: turn around

| Moving water | What it does |
|---|---|
| **6 inches** | Knocks you off your feet ([Spotter Guide, p. 12](lib:weather-spotters-field-guide#page=12)); reaches the bottom of most cars, "causing loss of control and possible stalling" ([FEMA, p. 54](lib:are-you-ready-citizen-preparedness-guide-2004#page=54)) |
| **1 foot** | "will float many vehicles" ([FEMA, p. 54](lib:are-you-ready-citizen-preparedness-guide-2004#page=54)) |
| **2 feet** | Carries away "most vehicles including sport utility vehicles (SUV's) and pick-ups" (same page) |

![Three scenes drawn to one scale in moving water: a person standing in 6 inches of it, which can knock you off your feet; a car in 1 foot of it, which floats many vehicles; a pickup in 2 feet of it, which carries away most vehicles, SUVs and pickups too](img:FLOODS-STORMS-HEAT-GUIDE/moving-water-depths.svg)
*How little moving water it takes, drawn to scale ([Spotter Guide, p. 12](lib:weather-spotters-field-guide#page=12); [FEMA, p. 54](lib:are-you-ready-citizen-preparedness-guide-2004#page=54); a diagram drawn for this guide).*

- **You can't see the depth or the road under it.** "The road might be washed out," and floods are worst at night, when it is
  "harder to see the road is flooded" ([Spotter Guide, p. 12](lib:weather-spotters-field-guide#page=12)). After the water
  drops, "Roads may have weakened and could collapse under the weight of a car" ([FEMA, p. 54](lib:are-you-ready-citizen-preparedness-guide-2004#page=54)).
- **If you must walk in water,** "walk where the water is not moving. Use a stick to check the firmness of the ground in front of
  you." Floodwater can carry oil, gasoline and raw sewage, and can be "electrically charged" by downed lines (same page).
- **With no road crews there are no barricades:** make it a household rule that nobody crosses a flooded road or creek *(rule of thumb)*.

## 👀 Reading rising water with no forecast
<!-- fold: The kinds of flood, the signs in the rain, the creek and the ground, and old flood marks -->

**Floods here** ([County plan, pp. 43–46](lib:josephine-county-multi-jurisdictional#page=43)): they come **October to April**, from the
Illinois, Rogue and Applegate rivers and their creeks; Slate Creek and Butcher Knife Creek have flooded too. Homes stand in mapped
floodplains at Cave Junction (the Illinois), Kerby, O'Brien and Wilderville ([p. 44](lib:josephine-county-multi-jurisdictional#page=44)).
The benchmark is the [Christmas flood of 1964](wiki:Christmas_flood_of_1964): 10 inches of rain in six days, the Rogue at 35 ft at
Grants Pass (flood stage is 24.5), the Rogue and Illinois valleys cut off ([p. 45](lib:josephine-county-multi-jurisdictional#page=45)).
Cave Junction got **8.12 inches in one day**, on 22 December 1964 ([NRCS soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)).
In **January 1997**, 4 inches in 48 hours brought the Rogue to 90,100 cubic feet a second at Grants Pass and a state of emergency; in
**February 2015** a foot of water covered US-199 near Selma, Butcher Knife Creek flooded, and roads closed near Selma and O'Brien
([p. 46](lib:josephine-county-multi-jurisdictional#page=46)). The storms of 1996–97 set off 9,582 recorded landslides across the state
([p. 52](lib:josephine-county-multi-jurisdictional#page=52)), and about 70% of the county's land is highly or very highly prone to slides
([p. 50](lib:josephine-county-multi-jurisdictional#page=50)).

| Kind | How it comes | Where |
|---|---|---|
| **Flash flood** | "Water rises rapidly with little or no advance warning," from heavy rain, ice jams or a dam break ([Spotter Guide, p. 43](lib:weather-spotters-field-guide#page=43)) | Steep creeks, canyons, dry streambeds, low crossings |
| **River flood** | Rain or snowmelt more than the channel holds "spreads out over the adjacent land" ([P-1019, p. 39](lib:emergency-power-systems-for-critical-facilities#page=39)); long floods can be "slow to recede" ([p. 40](lib:emergency-power-systems-for-critical-facilities#page=40)) | Bottoms and flats along rivers |
| **Debris flow** (mudflow) | "rivers of rock, earth, and other debris saturated with water," at "avalanche speeds," running "several miles from their source" ([FEMA, p. 107](lib:are-you-ready-citizen-preparedness-guide-2004#page=107)) | Below steep slopes; in channels and at canyon mouths |
| **Landslide** | Small or large, slow or fast (same page) | Steep slopes, road cuts, old slides |

**Watch the rain upstream, not just here.** "A storm that produces heavy rain higher on the mountain could produce a flash flood
lower on the mountain," and snowmelt adds to it ([TC 3-97.61, p. 27](lib:tc-3-97-61#page=27)). Floods can run "many miles
downstream" of the rain ([FM 3-97.6, p. 15](lib:fm-3-97-6-mountain-operations#page=15)). A warm, heavy rain on snow
(an [atmospheric river](wiki:Atmospheric_river)) is the classic winter flood *(general practice)*. On a burned slope, **about half an
inch an hour** of rain can start a debris flow ([USGS, p. 1](lib:usgs-postfire-debris-flow#page=1)): keep a rain gauge
([Navigation & Weather guide](guide:NAVIGATION-WEATHER-GUIDE)).

**Watch your creek like a weather spotter:** is the water standing or flowing? Rising, steady or falling? Is it in a place known to
flood ([Spotter Guide, p. 5](lib:weather-spotters-field-guide#page=5))? Drive a stake at the bank, mark it every foot, and read it
every hour through a rising night *(rule of thumb)*.

**Learn where water has been.** "Observe the previous flood marks" ([Kephart, Vol. 1, p. 213](lib:kephart-camping-and-woodcraft-vol-1#page=213)):
"driftwood and weeds washed into the branches of waterside trees" show the old flood level ([*Shifts and Expedients*, p. 74](lib:shifts-and-expedients#page=74)).
"It is quite common ... for wide bottoms to be flooded in a night" ([Kephart, Vol. 1, p. 217](lib:kephart-camping-and-woodcraft-vol-1#page=217)).

![A creek bank in cross-section: a stake driven in at the water's edge with a mark every foot from 1 to 5 feet, the water now at the 1-foot mark; up the bank a waterside tree with driftwood and weeds caught in its branches, and a dashed line from them showing an old flood level](img:FLOODS-STORMS-HEAT-GUIDE/creek-stake-gauge.svg)
*A marked stake read every hour, and the old flood level that driftwood in the branches shows ([Spotter Guide, p. 5](lib:weather-spotters-field-guide#page=5); [*Shifts and Expedients*, p. 74](lib:shifts-and-expedients#page=74); a diagram drawn for this guide).*

**Signs a slide or debris flow is coming** ([FEMA, p. 108](lib:are-you-ready-citizen-preparedness-guide-2004#page=108);
[FEMA 2020, p. 13](lib:are-you-ready-citizen-preparedness-guide-2020#page=13); [USGS, p. 1](lib:usgs-postfire-debris-flow#page=1)):
- doors or windows that stick for the first time; new cracks in plaster, foundations, the ground or the driveway;
- bulging ground at the foot of a slope; water breaking out of the ground in new places; a creek that suddenly rises or falls;
- fences, poles or trees that tilt; a rumble that grows louder; "cracking, breaking, roaring, or a fast-moving freight train."

Get out of its path at once. "Watch for flooding after a landslide," because the same storm starts both ([FEMA 2020, p. 13](lib:are-you-ready-citizen-preparedness-guide-2020#page=13)).

## 🐄 Getting people, animals and supplies up high
<!-- fold: Who goes first, where to, the generator and fuel, stock and pets, sandbags -->

- **People first.** Children, elders and the sick go early, by daylight, to a high place picked ahead, by a route that crosses no
  creek *(rule of thumb)*. Debris flows "are faster than you" ([USGS, p. 1](lib:usgs-postfire-debris-flow#page=1)).
- **Food and supplies** live on shelves "safely out of the way of contaminated water" ([PNW 612, p. 22](lib:storing-food-for-safety#page=22)),
  not on a basement or shop floor. Move what you can upstairs before the water comes ([FEMA, p. 53](lib:are-you-ready-citizen-preparedness-guide-2004#page=53)).
- **Generator, fuel and switches above the flood line:** "the entire system must be above the flood level"
  ([P-1019, p. 110](lib:emergency-power-systems-for-critical-facilities#page=110)). Run it in the rain only "under an open, canopy-like
  structure on a dry surface where water cannot reach it" ([CPSC, p. 1](lib:cpsc-portable-generator#page=1)). Fuel, poison and paint
  go up or out, or they end up in the water you clean up *(rule of thumb)*.
- **Livestock:** keep winter paddocks "on high ground away from water" ([EC 1558, p. 5](lib:small-acreage-horse-farms#page=5)), and take
  horses off low pasture before the fall rains ([p. 18](lib:small-acreage-horse-farms#page=18)). Poultry and rabbits go in crates to high
  ground; never leave animals shut in a flooding barn: open the gates or cut the fence *(rule of thumb)*.
- **Sandbags** only hold back shallow, slow water *(rule of thumb)*. Fill each bag about **75 percent** and interlock them like bricks
  ([FM 90-3, p. 80](lib:fm-90-3-desert-operations#page=80)). Barriers and a "check valve" in the sewer line keep water out of the
  house ([FEMA, p. 53](lib:are-you-ready-citizen-preparedness-guide-2004#page=53)).

## 🧹 After the flood
<!-- fold: Going back in, power and fuel, the well, the septic, food to throw out, drying out, sickness, rebuilding higher -->

### Going back in

- **Don't go in** if floodwater is still around the building or you smell gas ([FEMA, p. 182](lib:are-you-ready-citizen-preparedness-guide-2004#page=182)),
  or if the walls are cracked, doors and windows are "out of square," or the foundation has shifted ([FEMA 2020, p. 31](lib:are-you-ready-citizen-preparedness-guide-2020#page=31)).
  No lanterns, candles or torches inside until you are sure there is no gas ([FEMA, p. 183](lib:are-you-ready-citizen-preparedness-guide-2004#page=183)).
- **Switch your flashlight on outside;** its battery "may produce a spark that could ignite leaking gas" ([p. 182](lib:are-you-ready-citizen-preparedness-guide-2004#page=182)).
  Snakes and animals often shelter upstairs: open a window and let them leave ([p. 184](lib:are-you-ready-citizen-preparedness-guide-2004#page=184)).
- **A flooded basement:** pump out about **a third of the water a day**, or "The walls may collapse and the floor may buckle"
  ([p. 183](lib:are-you-ready-citizen-preparedness-guide-2004#page=183)).
- **Wear** goggles, work gloves, a hard hat and waterproof boots ([FEMA 2020, p. 12](lib:are-you-ready-citizen-preparedness-guide-2020#page=12)).

### Power, appliances and fuel

- **Breaker off** if you can reach it dry. Wet appliances: power off, unplug, let them dry, and have them checked before use
  ([FEMA, p. 183](lib:are-you-ready-citizen-preparedness-guide-2004#page=183)). "Rubber boots and gloves are not adequate protection from
  electric shock" ([EPA, p. 3](lib:what-to-do-after-the-flood-private-wells#page=3)).
- **Propane:** if the tank has shifted, the lines are bent or broken, or the regulator or an appliance's controls were under water,
  it needs a qualified person ([propane tips, p. 10](lib:home-safe-home-propane#page=10)). With none to call, replace a flooded regulator
  and don't relight a flooded appliance *(rule of thumb)*; more in the [Fuel guide](guide:FUEL-GUIDE).
- **Drums and chemical containers** that floated onto your land are a job for the health department ([EPA, p. 3](lib:what-to-do-after-the-flood-private-wells#page=3)):
  leave them shut, away from water, and never burn them *(rule of thumb)*; see "Hazardous waste" in the
  [Sanitation guide](guide:SANITATION-GUIDE).

### The well and drinking water

- **"DO NOT TURN ON THE PUMP"** and don't drink or wash with the water. Wells "more than 10 years old or less than 50 feet deep are
  likely to be contaminated, even if there is no apparent damage." Don't run the pump until the wiring is dry and checked, and its
  silt cleaned out ([EPA, p. 1](lib:what-to-do-after-the-flood-private-wells#page=1)).
- **Disinfect it** ([p. 2](lib:what-to-do-after-the-flood-private-wells#page=2)):
  1. Run an outside hose until the water is clear. Pour **a gallon of plain, unscented bleach** down the casing (gloves, goggles).
  2. Run the hose back into the casing until it smells of chlorine; then open every cold tap until each smells of it.
  3. **Wait 6 to 24 hours**, using none of it. Then flush it away from plants, streams and the septic system until the smell is gone.
  4. **Test for bacteria 7 to 10 days later.**
- **It may stay unsafe "for many months"** as polluted ground water moves, so test again. Bleach does nothing for pesticides,
  metals or other chemicals ([p. 3](lib:what-to-do-after-the-flood-private-wells#page=3)). Until then boil or treat every drop
  ([Water Purification guide](guide:WATER-PURIFICATION-GUIDE)); doses for your well's size are in "Keeping well water clean" in the
  [Water Wells guide](guide:WATER-WELLS-GUIDE).

### The septic system

- "Septic systems should not be used immediately after floods. Drain fields will not work until underground water has receded"
  ([EPA, p. 3](lib:what-to-do-after-the-flood-private-wells#page=3)). "Do not flush toilets until you know that sewage lines are intact"
  ([FEMA, p. 183](lib:are-you-ready-citizen-preparedness-guide-2004#page=183)).
- **Don't pump the tank empty** while the ground is soaked: "empty tanks are buoyant and will try to float out of the ground." Look for
  soil washed off the tank, broken lids and ports; pumps and panels that were under water must be checked before the power goes back
  on ([Texas A&M, p. 4](lib:septic-systems-responding-to-electrical-power-outages#page=4)).
- Meanwhile use a bucket toilet or latrine ([Sanitation guide](guide:SANITATION-GUIDE)).

### Food to throw out

- **"Throw away all food and other supplies that may have been contaminated or have come into contact with floodwater"**
  ([FEMA 2020, p. 31](lib:are-you-ready-citizen-preparedness-guide-2020#page=31)), and food from damaged cans
  ([EM 9331, p. 8](lib:survival-basics-food#page=8)). That includes sacks of grain, flour, anything in paper, cardboard or plastic bags,
  and home-canned jars, whose lids don't keep floodwater out *(rule of thumb)*.
- **The refrigerator** is safe about 4 hours with the door shut. Throw out meat, fish, eggs and leftovers above **40 °F for over two
  hours** ([FEMA 2020, p. 31](lib:are-you-ready-citizen-preparedness-guide-2020#page=31)), and refrigerated medicines after a day without
  power unless the label says otherwise ([p. 15](lib:are-you-ready-citizen-preparedness-guide-2020#page=15)).
- **If you cannot afford to lose them,** undamaged factory cans can be saved: peel the labels, scrub, boil 10 minutes, and mark the
  contents on the lid *(rule of thumb)*.

### Mud, drying out and mold

- **"Clean and disinfect everything that got wet. Mud left from floodwater can contain sewage and chemicals"**
  ([FEMA, p. 54](lib:are-you-ready-citizen-preparedness-guide-2004#page=54)). The strengths of bleach for floors and objects are in
  "Chlorine strengths from household bleach" in the [Sanitation guide](guide:SANITATION-GUIDE).
- **Dry it fast.** Open every door and window on dry days, and pull out soaked carpet, padding, mattresses, insulation and the wet part
  of wallboard; what can't be dried in about two days will grow mold. Wear an N95 mask to tear out moldy material *(rule of thumb)*.
- **Let the framing dry before you close the walls.** "any wood moisture content above 20 percent will probably support decay fungi,"
  and mold is a warning that rot can start ([*Wood-Frame House Construction*, p. 201](lib:wood-frame-house-construction#page=201)).
  Rot and its repair: the [Shelter guide](guide:SHELTER-BUILDING-GUIDE).

### Sickness from floodwater

- **Leptospirosis** spreads from water fouled by animal urine, "through the skin or mucous membranes," and outbreaks have followed
  floods. It starts like the flu, with chills, headache and high fever, and can go on to jaundice, kidney failure and meningitis
  ([*Zoonoses*, pp. 74–75](lib:zoonoses-diseases-animals-give-people#page=74); [Leptospirosis](wiki:Leptospirosis)). Cover cuts, wear boots
  and gloves, and wash after any contact *(rule of thumb)*.
- Infected cuts: "Wounds and infection when there's no hospital" in the [Field Care guide](guide:FIELD-CARE-GUIDE).

### Rebuilding higher

- **Raise the furnace, water heater and electric panel**, and fit check valves in the sewer line ([FEMA, p. 53](lib:are-you-ready-citizen-preparedness-guide-2004#page=53)).
- **Keep the well tightly capped:** an open well lets "sediment and flood water" in ([EPA, p. 1](lib:what-to-do-after-the-flood-private-wells#page=1)).
- **Replant bare slopes soon:** lost ground cover "can lead to flash flooding and additional landslides" ([FEMA, p. 109](lib:are-you-ready-citizen-preparedness-guide-2004#page=109)).
- **Build anything new** away from "steep slopes ... drainage ways, or natural erosion valleys" ([FEMA, p. 108](lib:are-you-ready-citizen-preparedness-guide-2004#page=108)),
  and never with earth or straw walls where floods reach ([Natural Building guide](guide:NATURAL-BUILDING-GUIDE)).

📚 **Go deeper:** [EPA *What to Do After the Flood*](lib:what-to-do-after-the-flood-private-wells#page=1) — the well, step by step; [Texas A&M](lib:septic-systems-responding-to-electrical-power-outages#page=3) — septic systems in outages and floods; [FEMA *Are You Ready?*, pp. 182–184](lib:are-you-ready-citizen-preparedness-guide-2004#page=182) — returning home.

## ❄️ Winter storms and ice storms
<!-- fold: One warm room, frozen pipes, falling trees and lines, travel, cold injuries -->

**Winter storms here** come October to March, and destructive ones once or twice a decade ([County plan, pp. 62, 64](lib:josephine-county-multi-jurisdictional#page=62)).
In February 2019 fallen trees closed US-199 at the California line and 2,500 customers lost power around Grants Pass, Cave Junction and
O'Brien; in January 2021 heavy snow left 45,000 customers without power ([p. 64](lib:josephine-county-multi-jurisdictional#page=64)).
The valley is "one way in, one way out": a storm on US-199 can strand Cave Junction, and "all of Cave Junction and the Illinois Valley
could be cut off from power for an extended period" ([p. 140](lib:josephine-county-multi-jurisdictional#page=140)). Trees here blow
over most in the wet season, on shallow roots in saturated ground ([p. 62](lib:josephine-county-multi-jurisdictional#page=62)).

**Freezing rain** is rain "that freezes when it hits the ground, creating a coating of ice on roads, walkways, trees, and power lines"
([FEMA, p. 81](lib:are-you-ready-citizen-preparedness-guide-2004#page=81)). Ice and wind snap lines and poles, and trees and limbs
breaking under ice bring down more. When damage is widespread, repairs are slow ([P-1019, p. 30](lib:emergency-power-systems-for-critical-facilities#page=30)),
and across several states "weeks may pass before power is completely restored" ([p. 29](lib:emergency-power-systems-for-critical-facilities#page=29)).

### One warm room

- **Fuel first:** "store a good supply of dry, seasoned wood" ([FEMA, p. 81](lib:are-you-ready-citizen-preparedness-guide-2004#page=81));
  how much, and how to burn it safely, is in the [Firewood guide](guide:FIREWOOD-GUIDE).
- **Heat one room and close off the rest:** "Conserve fuel ... by keeping your residence cooler than normal. Temporarily close off
  heat to some rooms" ([p. 83](lib:are-you-ready-citizen-preparedness-guide-2004#page=83)). Caulk, weatherstrip and cover windows with
  plastic ([p. 82](lib:are-you-ready-citizen-preparedness-guide-2004#page=82)); the plastic lobby and straw insulation are in
  "One warm room" in the [Shelter guide](guide:SHELTER-BUILDING-GUIDE).
- **Dress and eat for it:** several loose layers, mittens, a hat; eat regularly and drink plenty, but no caffeine or alcohol
  ([p. 83](lib:are-you-ready-citizen-preparedness-guide-2004#page=83)); a sleeping bag or warm blanket for each person
  ([Red Cross, p. 6](lib:disaster-preparedness-for-seniors#page=6)).
- **Share:** go to family or friends if your home loses heat for more than a few hours ([FEMA 2020, p. 17](lib:are-you-ready-citizen-preparedness-guide-2020#page=17));
  two households in one warm house burn half the wood *(rule of thumb)*.
- **A heater with no chimney** needs **1 square inch of open window for every 1,000 Btu** ([MSU E-1669, p. 3](lib:some-considerations-about-portable-kerosene#page=3)).
  Refuel kerosene heaters outside and keep them **3 ft** from anything that burns ([FEMA, p. 83](lib:are-you-ready-citizen-preparedness-guide-2004#page=83)).
  Read the carbon monoxide section below.

### Frozen pipes

Here the record low is **−6 °F** at Cave Junction (December 1972), and every few years a cold air mass from the east brings several
days well below freezing ([NRCS soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)); the
county warns of breaks "in un-insulated water lines" ([County plan, p. 65](lib:josephine-county-multi-jurisdictional#page=65)).

- **If the house will go cold for days, drain it:** shut the main valve, "Open all faucets and allow pipes to drain thoroughly"
  ([*Household Discoveries*, p. 103](lib:household-discoveries#page=103)). First save the water: shutting the main valve traps the water
  in the pipes and the water-heater tank ([Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23)); draw it off
  into clean jugs, with the heater's power or gas off *(rule of thumb)*.
- **A wood cookstove with a water jacket (a "water back"):** never light it while its pipes are frozen. "direct heat from the pipes will
  generate steam and severe explosions may follow" ([*Household Discoveries*, p. 104](lib:household-discoveries#page=104)).
- **Drain traps** in a house left cold can be filled with "crude glycerin, or a very strong brine made of common salt and water"
  ([USDA FB 1460, p. 15](lib:usda-simple-plumbing-repairs#page=15)).
- **Thawing:** "The middle of a frozen pipe should never be thawed first," or the trapped water bursts it. Open the faucet and work back
  toward the supply with hot cloths or hot water. A buried pipe can be thawed by pushing a small tube into it from the house end and
  pouring boiling water down a funnel ([USDA FB 1460, p. 14](lib:usda-simple-plumbing-repairs#page=14)). No flame (see "Old advice" below).

![A frozen water pipe running through a wall, with its fittings at the house end taken off; a thin thaw pipe is pushed into it from the house side, a funnel on the thaw pipe's raised end, boiling water poured into the funnel from a pail, and a bucket under the opening to catch the water running back](img:FLOODS-STORMS-HEAT-GUIDE/thawing-a-buried-pipe.png)
*Thawing a buried pipe: push the thaw pipe forward as the ice melts, with the bucket catching the water that runs back ([USDA FB 1460, p. 14](lib:usda-simple-plumbing-repairs#page=14)).*

### Trees and lines coming down

- **Downed lines:** "You cannot tell by looking at them whether they are 'live' or not. NEVER try to move them. NEVER try to hop over
  them. NEVER walk under a power line that is resting on a tree branch or fallen tree." Rope them off **at least 50 feet** in all
  directions ([Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23)). With the grid down, a neighbor's
  generator plugged into a wall outlet can still put power on the lines ([CPSC, p. 1](lib:cpsc-portable-generator#page=1)).
- **A line falling near you:** current spreads through the ground, so run (one foot on the ground at a time) or stand on one foot
  ([*Lessons in Electric Circuits*, p. 110](lib:lessons-in-electric-circuits-vol-1#page=110)).
- **How far a tree reaches when it falls:** **1 to 1.5 times its height** all round; a tree leaning **15° or more** falls toward its
  lean; a broken top or limb reaches **1.5 times its length**, farther in wind ([FS-1273, pp. 36–37](lib:tree-risk-assessments#page=36)).
  Stay out of those zones, and out of rooms under big trees, while ice and wind last *(rule of thumb)*.
- **Cutting up what fell:** windfalls are "difficult to evaluate"; a rootwad cut free can stand back up or roll downhill
  ([EC 1124, p. 10](lib:safe-and-effective-use-of-chain-saws#page=10)), and on wet ground its roots are "under a lot of pressure"
  ([*Saws That Sing*, p. 43](lib:usfs-saws-that-sing#page=43)). Bent saplings and limbs whip when cut: "Bucking and limbing" in the
  [Firewood guide](guide:FIREWOOD-GUIDE).

### Travel in snow and ice

- **Drive only if you must:** by day, not alone, with someone told your route, on main roads ([FEMA, p. 84](lib:are-you-ready-citizen-preparedness-guide-2004#page=84)).
- **The car kit:** blanket, hat, mittens, shovel, sand, chains, scraper and a bright distress flag ([Red Cross, p. 6](lib:disaster-preparedness-for-seniors#page=6));
  jumper cables, a flashlight, water, snacks, and a full tank ([FEMA 2020, p. 17](lib:are-you-ready-citizen-preparedness-guide-2020#page=17)).
- **Stuck:** stay with the car unless a building is close. Run the engine about **10 minutes an hour**, with an upwind window open a
  crack, and keep snow off the exhaust pipe. One person stays awake ([FEMA, p. 84](lib:are-you-ready-citizen-preparedness-guide-2004#page=84)).
  Walking out: the [On Foot guide](guide:ON-FOOT-GUIDE).
- **Shovel slowly:** overexertion "can bring on a heart attack—a major cause of death in the winter" ([FEMA, p. 83](lib:are-you-ready-citizen-preparedness-guide-2004#page=83)).

### Cold injuries

- **Hypothermia:** "uncontrollable shivering, memory loss, disorientation, incoherence, slurred speech, drowsiness"; **frostbite:** "loss
  of feeling and white or pale" fingers, toes, ears or nose ([FEMA, p. 83](lib:are-you-ready-citizen-preparedness-guide-2004#page=83)).
- What to do: "Heat and cold in the Valley" in the [Field Care guide](guide:FIELD-CARE-GUIDE). A frostbitten part is warmed
  against skin, in an armpit or on a belly, and never "massaged, exposed to a fire or stove, rubbed with snow"
  ([FM 4-25.11, p. 120](lib:fm-4-25-11-first-aid#page=120)).

📚 **Go deeper:** [FEMA *Are You Ready?*, pp. 81–84](lib:are-you-ready-citizen-preparedness-guide-2004#page=81) — winter storms and extreme cold; [P-1019, pp. 29–30](lib:emergency-power-systems-for-critical-facilities#page=29) — how ice brings lines down.

## ☠️ Carbon monoxide: the quiet killer

Carbon monoxide "is a colorless and odorless gas," made by anything that burns fuel, and kills "more than 100 people" a year in the
United States from household products alone ([CPSC, p. 1](lib:cpsc-carbon-monoxide-the-invisible-killer#page=1)). Outages, with
generators and makeshift heaters, are when it strikes *(rule of thumb)*.
- **Never indoors:** no generator in the house, garage, basement, crawlspace or shed, "even when using fans or opening doors and
  windows"; the gas can "linger for hours, even after the generator has shut off" ([CPSC, p. 1](lib:cpsc-portable-generator#page=1)).
  Run generators, camp stoves and grills "at least 20 feet away from windows" ([FEMA 2020, p. 15](lib:are-you-ready-citizen-preparedness-guide-2020#page=15)),
  with the exhaust pointed away from buildings.

![A house with a window on one side and, at least 20 feet from that window, a generator on a raised dry platform under an open roof on posts, its exhaust pointed away from the house; a battery CO alarm inside the house; below, a warning: never inside the house, garage, basement, crawlspace or shed, even with fans running or doors and windows open](img:FLOODS-STORMS-HEAT-GUIDE/generator-outdoors.svg)
*Outdoors, at least 20 feet from windows, exhaust away from the house; in rain, under an open roof on a dry surface ([FEMA 2020, p. 15](lib:are-you-ready-citizen-preparedness-guide-2020#page=15); [CPSC, p. 1](lib:cpsc-portable-generator#page=1); a diagram drawn for this guide).*

- **Never heat with a gas range, oven or dryer. Never burn charcoal in homes, tents, vehicles or garages.** Never run an unvented gas
  heater in a closed room or where people sleep, or a car in a garage "even with the garage door open"
  ([CPSC, p. 2](lib:cpsc-carbon-monoxide-the-invisible-killer#page=2)).
- **Watch the stove and chimney:** soot, debris falling from the chimney, rust or water streaks on the pipe, loose pipe joints and water
  beading inside the windows are clues (same page; [🖼️ where it comes from](lib:cpsc-carbon-monoxide-the-invisible-killer#page=2)).
- **The signs** are like flu without the fever: headache, tiredness, shortness of breath, nausea, dizziness
  ([p. 1](lib:cpsc-carbon-monoxide-the-invisible-killer#page=1)), and they ease when you are away from home ([p. 2](lib:cpsc-carbon-monoxide-the-invisible-killer#page=2)).
  Several people, and pets, sick at once is a warning *(rule of thumb)*.
- **Anyone dizzy or weak: everyone out to fresh air "RIGHT AWAY. DO NOT DELAY"** ([CPSC, p. 1](lib:cpsc-portable-generator#page=1)).
- **A battery CO alarm** near the bedrooms, tested monthly, with spare batteries ([CPSC, p. 1](lib:cpsc-carbon-monoxide-the-invisible-killer#page=1);
  [p. 1](lib:cpsc-portable-generator#page=1)). Wiring a generator safely: "Generators, cars and backfeed" in the
  [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE).

## 🌡️ Heat waves
<!-- fold: A cool house with no power, water, who is at risk, and animals in the heat -->

**Heat here** ([County plan, pp. 57–58](lib:josephine-county-multi-jurisdictional#page=57)): days with a heat index of 90 °F or more are
expected to go from about **13 a year to about 40** by the 2050s. The county saw up to **111 °F** in August 2020 and **92–108 °F** in the
June 2021 heat dome, with two more heat waves later that summer. Grants Pass hit 108 °F as long ago as 1955, and every few years a
"sweltering" week or longer comes ([NRCS soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)).

"Heat kills by pushing the human body beyond its limits" ([FEMA, p. 87](lib:are-you-ready-citizen-preparedness-guide-2004#page=87)).
In the 2021 heat dome Portland's county had **72 heat deaths**, where a typical year has none ([heat report, p. 2](lib:excessive-heat-events#page=2)).
The most died the day **after** the hottest day ([p. 7](lib:excessive-heat-events#page=7)), and 94% died in their own homes
([p. 10](lib:excessive-heat-events#page=10)).

### Keeping the house cool with no power

1. **Night:** open the windows when the outside air is cooler, and use fans to push hot air out or pull cool air in
   ([EPA smoke guide, p. 49](lib:epa-wildfire-smoke-guide-2026#page=49)).
2. **Morning, before it heats up:** close the windows and the shades, blinds and awnings (same page).
3. **Shade the glass from outside.** Awnings or louvers "can reduce the heat that enters a home by up to 80 percent"; foil-covered
   cardboard set between the window and the curtains reflects heat back out ([FEMA, pp. 88–89](lib:are-you-ready-citizen-preparedness-guide-2004#page=88)).
   A tarp or shade cloth hung a foot outside a sunny window does the same *(rule of thumb)*.

![Two drawings of the same house. Night: windows open, cool air coming in one side and a fan in the far window pushing hot air out. Day: windows shut with the shades drawn inside, an awning over the sunny window turning the sun away, cool air kept in](img:FLOODS-STORMS-HEAT-GUIDE/cool-by-night-shut-by-day.svg)
*Open at night, shut before the day heats up, and shade the glass from outside ([EPA smoke guide, p. 49](lib:epa-wildfire-smoke-guide-2026#page=49); [FEMA, p. 88](lib:are-you-ready-citizen-preparedness-guide-2004#page=88); a diagram drawn for this guide).*

4. **Live low.** "Stay on the lowest floor out of the sunshine" ([FEMA, p. 89](lib:are-you-ready-citizen-preparedness-guide-2004#page=89)):
   a basement or cellar is coolest, and a third of the people who died in apartments lived on the third floor or higher
   ([heat report, p. 10](lib:excessive-heat-events#page=10)).
5. **Let the attic breathe.** A ceiling passes "more heat ... when the attic temperature is 150° F. than if it is 120° F"
   ([*Wood-Frame House Construction*, p. 111](lib:wood-frame-house-construction#page=111)): open gable vents and attic hatches to the outside *(rule of thumb)*.
6. **Fans:** "At temperatures in the upper 90s, fans simply move hot air around" ([heat report, p. 12](lib:excessive-heat-events#page=12)),
   and above 90 °F don't point one at yourself ([EPA smoke guide, p. 49](lib:epa-wildfire-smoke-guide-2026#page=49)). Wet the skin or a
   cloth instead, and let the air dry it. In dry heat, a wet sheet hung in a breezy window cools the air coming in. Cook outdoors or
   early *(rules of thumb)*. Summer afternoons here are dry, with humidity of 25–30% ([NRCS soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)),
so wet cloths and wet sheets cool well.
7. **When the house no longer cools at night,** move the people at risk to a cooler house, a basement or deep shade by water
   ([EPA smoke guide, p. 49](lib:epa-wildfire-smoke-guide-2026#page=49)).
8. **Dress light and work early:** loose, light-colored clothes, a wide-brimmed hat, no hard work in the hottest hours
   ([FEMA, p. 89](lib:are-you-ready-citizen-preparedness-guide-2004#page=89)). Full sun "can increase the heat index by 15 degrees" ([p. 88](lib:are-you-ready-citizen-preparedness-guide-2004#page=88)).

### Water in the heat

- **Store at least a gallon a person a day**; half a gallon is just for drinking, and "Very hot temperatures can double the amount of
  water needed" ([FEMA, p. 34](lib:are-you-ready-citizen-preparedness-guide-2004#page=34)). Hard work in heavy heat can take **more
  than 3 gallons** a day ([FM 90-3, p. 28](lib:fm-90-3-desert-operations#page=28)).
- **Drink before you are thirsty, a little at a time.** "When you become thirsty you will be about a 'quart and a half low'" (same page).
- **Check the color:** "If urine is more colored than diluted lemonade ... there is probably insufficient water intake"
  ([FM 90-3, p. 29](lib:fm-90-3-desert-operations#page=29)).
- **No salt tablets:** "One salt tablet increases your water requirement by at least a pint" ([FM 21-10, p. 13](lib:fm-21-10-field-hygiene#page=13));
  ordinary meals carry the salt. Too much plain water is dangerous too (Field Care guide).
- **Bodies adjust in about two weeks,** a good part of it in 4–5 days ([FM 90-3, p. 23](lib:fm-90-3-desert-operations#page=23)): ease into heavy work.
- People with heart, kidney or liver disease or epilepsy, or on limited fluids, should ask a doctor before drinking more
  ([FEMA, p. 89](lib:are-you-ready-citizen-preparedness-guide-2004#page=89)).

### Who is at risk

| At risk | Why ([heat report](lib:excessive-heat-events#page=2); [FEMA, p. 87](lib:are-you-ready-citizen-preparedness-guide-2004#page=87)) |
|---|---|
| **Older people** | 78% of the dead were 60 or older ([p. 8](lib:excessive-heat-events#page=8)) |
| **People living alone** | "Living alone is a known risk factor for heat death" ([p. 10](lib:excessive-heat-events#page=10)) |
| **Young children, the sick and the overweight** | "more likely to succumb to extreme heat" ([FEMA, p. 87](lib:are-you-ready-citizen-preparedness-guide-2004#page=87)) |
| **Upstairs, with no cooling** | Half of the dead had only a fan; 18% had nothing ([p. 12](lib:excessive-heat-events#page=12)) |
| **Outdoor workers and people in vehicles** | Emergency visits came from work and from vehicles ([p. 25](lib:excessive-heat-events#page=25)) |

- **Never leave children or pets alone in closed vehicles** ([FEMA, p. 89](lib:are-you-ready-citizen-preparedness-guide-2004#page=89)).
- **A heat buddy for each person at risk:** a visit morning and evening, and a cooler place to go *(rule of thumb)*.
- **Heat exhaustion and heat stroke:** "Heat and cold in the Valley" in the [Field Care guide](guide:FIELD-CARE-GUIDE).
  Confusion or collapse in the heat is heat stroke: cool them first, fast.

### Animals in the heat

- **Chickens** pant instead of sweating; "severe stress sets in above 40 °C" (104 °F), and 46 °C (115 °F) kills most. Give shade and
  moving air; white paint reflects "up to 70 percent" of the sun's heat ([FAO, p. 27](lib:small-scale-poultry-production-technical-guide#page=27)).
- **Pigs** "can even die from heat stress": handle them only "early morning or evening" ([*No Animal Doctor*, p. 47](lib:where-there-is-no-animal-doctor#page=47)).
- **Water:** cattle drink **4–20 gallons** a day and heat "dramatically" increases it ([EC1514, p. 9](lib:beef-production-for-small-farms#page=9));
  an idle horse **10–12 gallons**, more when sweating ([G1781, p. 4](lib:basics-of-feeding-horses#page=4)).
- Each animal's details: "Heat, smoke and fire season" in [Chickens](guide:CHICKENS-GUIDE), "Heat stress" in [Rabbits](guide:RABBITS-GUIDE),
  shade and wallows in [Pigs](guide:PIGS-GUIDE), and the [Cattle](guide:CATTLE-GUIDE), [Goats](guide:GOATS-GUIDE) and [Horse](guide:HORSE-GUIDE) guides.

📚 **Go deeper:** [Heat report](lib:excessive-heat-events#page=2) — who died in the 2021 heat dome, and why; [FEMA *Are You Ready?*, pp. 87–90](lib:are-you-ready-citizen-preparedness-guide-2004#page=87) — extreme heat and its first aid; [FM 90-3, pp. 23–29](lib:fm-90-3-desert-operations#page=23) — water and work in heat.

## 🌬️ Windstorms
<!-- fold: Getting ready, where to be while it blows, and the danger afterwards -->

**Windstorms here** come mostly October to March, and the county expects **60 mph** winds about once in 25 years
([County plan, p. 61](lib:josephine-county-multi-jurisdictional#page=61)); most winters bring one or two damaging storms
([NRCS soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)). Cave Junction had **64 mph** gusts
in December 1995, when wet soil left trees easy to topple; in April 2016 trees came down from Cave Junction to Selma; in April 2017 more
than 60,000 people lost power, mostly in Josephine County ([County plan, p. 60](lib:josephine-county-multi-jurisdictional#page=60)).
Poorly anchored manufactured homes and older buildings that need roof repair are the most at risk ([p. 61](lib:josephine-county-multi-jurisdictional#page=61)).

- **Before:** "Cut down or trim trees that may be in danger of falling on your home," and tie down or bring in anything that could blow
  away ([FEMA 2020, p. 15](lib:are-you-ready-citizen-preparedness-guide-2020#page=15)). Measure your big trees against the falling
  distances above ([FS-1273, p. 36](lib:tree-risk-assessments#page=36)).
- **Wet ground and ice make it worse.** Soaked soil loses strength, and poles and their anchors pull out ([P-1019, p. 40](lib:emergency-power-systems-for-critical-facilities#page=40));
  ice adds weight and more surface for the wind ([p. 29](lib:emergency-power-systems-for-critical-facilities#page=29)). Trees on soaked ground
  go over more easily too *(general practice)*.
- **While it blows:** stay inside, away from windows and from rooms under big trees. The safest place is "a small, interior, windowless
  room ... on the lowest level" of a sturdy building ([FEMA 2020, p. 13](lib:are-you-ready-citizen-preparedness-guide-2020#page=13)).
  FEMA says mobile homes "are not safe" when a tornado threatens ([p. 16](lib:are-you-ready-citizen-preparedness-guide-2020#page=16));
  in a violent windstorm a neighbor's sturdy house is safer *(rule of thumb)*. Lightning: the [Navigation & Weather guide](guide:NAVIGATION-WEATHER-GUIDE).
- **Judging wind with no gauge:** the twig-and-branch scale in "Reading fire danger with no forecast" in the [Wildfire guide](guide:WILDFIRE-GUIDE)
  ([Beaufort scale](wiki:Beaufort_scale)). A **blizzard** is wind of 35 mph or more with snow cutting sight to under a quarter mile for
  three hours or longer ([FEMA, p. 81](lib:are-you-ready-citizen-preparedness-guide-2004#page=81)).
- **After:** the same dangers as an ice storm: lines down, limbs hanging overhead, windfalls under strain (see "Trees and lines coming
  down" above). Look up before you walk under any tree *(rule of thumb)*.

## ✅ A household weather-ready checklist
<!-- fold: What to do before the wet season, before winter, before summer, and all year -->

**Before the wet season**
- [ ] Know where water has reached on your land: old flood marks, and what older neighbors remember.
- [ ] A high place to go and a walking route there that crosses no creek; a marked stake at the creek.
- [ ] Gutters, culverts and ditches clear — "Flashing, gutters and keeping water away" in the [Shelter guide](guide:SHELTER-BUILDING-GUIDE).
- [ ] Everyone knows how to shut off the water, power and propane ([Map Your Neighborhood, pp. 22–23](lib:map-your-neighborhood-discussion-guide#page=22)).
- [ ] Well cap tight; septic floor drains can be plugged; a check valve on the sewer line.
- [ ] Generator, fuel, food and seed stored above the flood line; animals' winter ground high.

**Before winter**
- [ ] A winter of dry firewood and a clean chimney — [Firewood guide](guide:FIREWOOD-GUIDE).
- [ ] The warm room chosen; plastic, tape and blankets for it — [Shelter guide](guide:SHELTER-BUILDING-GUIDE).
- [ ] A battery CO alarm by the bedrooms, and spare batteries.
- [ ] The main water valve found and tagged; everyone knows how to drain the pipes.
- [ ] Saw, chains, wedges and fuel ready — [Engines & Motors guide](guide:ENGINES-AND-MOTORS-GUIDE); a car kit packed.
- [ ] A hypothermia wrap: sleeping bag, pad, tarp, plastic sheet — [Field Care guide](guide:FIELD-CARE-GUIDE).

**Before summer**
- [ ] Shade for every sunny window, and foil-covered cardboard cut to fit.
- [ ] The coolest room picked, and a heat buddy for everyone at risk.
- [ ] Water for at least two gallons a person a day in a heat wave; shade and water for the animals.

**All year**
- [ ] Two weeks of water, food and medicine ([What to Expect guide](guide:WHAT-TO-EXPECT-GUIDE)).
- [ ] A battery or crank radio ([Radio guide](guide:RADIO-GUIDE)), and the twice-a-day weather log ([Navigation & Weather guide](guide:NAVIGATION-WEATHER-GUIDE)).
- [ ] A neighborhood plan to check on each other ("The neighborhood OK/HELP plan" in the [Signals & Morse guide](guide:SIGNALS-MORSE-GUIDE)).

📚 **Go deeper:** [County plan, pp. 43–65](lib:josephine-county-multi-jurisdictional#page=43) — floods, landslides, heat, wind and winter storms in the county, year by year; [NRCS soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5) — the valley's climate and its records.

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Thaw a pipe with a newspaper "torch, light it, and pass it along the pipe" ([Lee's, p. 138](lib:lees-priceless-recipes#page=138)); "a torch or burning newspaper" ([USDA FB 1460, p. 14](lib:usda-simple-plumbing-repairs#page=14)); "gasoline or kerosene gas in lamps" ([*Household Discoveries*, p. 104](lib:household-discoveries#page=104)) | No flame: it starts fires inside walls and melts plastic pipe *(rule of thumb)*. Open the faucet and work back toward the supply with hot cloths or hot water ([FB 1460, p. 14](lib:usda-simple-plumbing-repairs#page=14)) |
| Fit "circular tubes of asbestos" over pipes, or line the wall "with asbestos" ([*Household Discoveries*, p. 103](lib:household-discoveries#page=103)) | Never asbestos. Wrap pipes in rags, foam or straw *(rule of thumb)*, or "turn the water off" on cold nights, as the same page says |
| Fill the traps of a vacant house with "kerosene" ([FB 1460, p. 15](lib:usda-simple-plumbing-repairs#page=15)) | Use the strong salt brine or glycerin from the same list; no fuel in the drains *(rule of thumb)* |
| Frostbite: "rub the frozen surface gently with snow, or ice-water" ([Kephart, Vol. 2, p. 466](lib:kephart-camping-and-woodcraft-vol-2#page=466)) | Warm it against skin; never rub it, never with snow, never at a fire ([FM 4-25.11, p. 120](lib:fm-4-25-11-first-aid#page=120)) |
| Heat cramps: "large amounts of cold salt water," made with "two salt tablets" ([FM 5-34, p. 31](lib:fm-5-34-engineer-field-data#page=31)) | "DO NOT TAKE SALT TABLETS" ([FM 21-10, p. 13](lib:fm-21-10-field-hygiene#page=13)); sip an electrolyte drink ([Field Care guide](guide:FIELD-CARE-GUIDE)) |
## 🖼️ Pictures & diagrams

- Flood hazard areas in the county — [🖼️ County plan, p. 45](lib:josephine-county-multi-jurisdictional#page=45); ground prone to landslides — [🖼️ p. 51](lib:josephine-county-multi-jurisdictional#page=51); Cave Junction's power-shutoff areas — [🖼️ p. 140](lib:josephine-county-multi-jurisdictional#page=140); [Christmas flood of 1964](wiki:Christmas_flood_of_1964)
- Street flooding and a flash flood — [🖼️ Spotter Guide, p. 12](lib:weather-spotters-field-guide#page=12), [🖼️ p. 43](lib:weather-spotters-field-guide#page=43); how a debris flow starts and spreads — [🖼️ USGS, p. 1](lib:usgs-postfire-debris-flow#page=1)
- Pouring bleach into a flooded well, two kinds of well top — [🖼️ EPA, p. 2](lib:what-to-do-after-the-flood-private-wells#page=2); a generator raised above the flood line — [🖼️ P-1019, p. 111](lib:emergency-power-systems-for-critical-facilities#page=111)
- Ice on a power line — [🖼️ P-1019, p. 30](lib:emergency-power-systems-for-critical-facilities#page=30); a line pulled down when flooding softened the ground — [🖼️ p. 41](lib:emergency-power-systems-for-critical-facilities#page=41)
- How far a falling tree reaches, on flat ground, on a slope and leaning — [🖼️ FS-1273, p. 36](lib:tree-risk-assessments#page=36), [🖼️ p. 37](lib:tree-risk-assessments#page=37); rootwads and springpoles — [🖼️ EC 1124, p. 10](lib:safe-and-effective-use-of-chain-saws#page=10)
- Shock through the ground around a downed line — [🖼️ *Lessons in Electric Circuits*, p. 110](lib:lessons-in-electric-circuits-vol-1#page=110); the water main valve — [🖼️ Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23)
- Where carbon monoxide comes from in a house — [🖼️ CPSC, p. 2](lib:cpsc-carbon-monoxide-the-invisible-killer#page=2)
- Heat deaths by day in the 2021 heat dome — [🖼️ heat report, p. 7](lib:excessive-heat-events#page=7)
- With photos — [Flash flood](wiki:Flash_flood); [Atmospheric river](wiki:Atmospheric_river); [Debris flow](wiki:Debris_flow); [Freezing rain](wiki:Freezing_rain); [Ice storm](wiki:Ice_storm); [Windthrow](wiki:Windthrow); [Carbon monoxide poisoning](wiki:Carbon_monoxide_poisoning); [Heat wave](wiki:Heat_wave); [Heat index](wiki:Heat_index); [Sandbag](wiki:Sandbag)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — NOAA Weather Radio, local contacts and maps
- [What to Expect](guide:WHAT-TO-EXPECT-GUIDE) — timelines for "Winter storm, ice, flood and landslides" and "Extreme heat and drought"
- [Navigation & Weather](guide:NAVIGATION-WEATHER-GUIDE) — reading the sky, "Illinois Valley weather through the year", lightning, a home weather log
- [Field Care](guide:FIELD-CARE-GUIDE) — "Heat and cold in the Valley", wounds and infection
- [Water Wells](guide:WATER-WELLS-GUIDE) and [Water Purification](guide:WATER-PURIFICATION-GUIDE) — the pump with no grid, shock chlorination, treating water
- [Sanitation](guide:SANITATION-GUIDE) — septic systems with no power, latrines, bleach strengths, hazardous waste, mosquitoes
- [Shelter & Building](guide:SHELTER-BUILDING-GUIDE) — one warm room, gutters, rot; [Natural Building](guide:NATURAL-BUILDING-GUIDE) — keeping earth walls dry
- [Firewood](guide:FIREWOOD-GUIDE) — a winter's wood, safe stoves, cutting storm-felled trees
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) and [Fuel](guide:FUEL-GUIDE) — generators and backfeed; kerosene heaters and propane
- [Wildfire](guide:WILDFIRE-GUIDE) — debris flows on burned slopes, judging wind
- [Chickens](guide:CHICKENS-GUIDE), [Rabbits](guide:RABBITS-GUIDE), [Pigs](guide:PIGS-GUIDE), [Goats](guide:GOATS-GUIDE), [Cattle](guide:CATTLE-GUIDE) and [Horses](guide:HORSE-GUIDE) — animals in heat and wet winters
- [On Foot](guide:ON-FOOT-GUIDE) — walking out, and camps above the flood marks
- [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) and [Signals & Morse](guide:SIGNALS-MORSE-GUIDE) — checking on neighbors, elders who need help, OK/HELP signs
- [How the Power Grid Works](guide:POWER-GRID-GUIDE) — downed lines, step potential, and lines that come back to life
- [Dams, Weirs, Ditches & Ponds](guide:DAMS-DITCHES-GUIDE) — warning signs at a dam, living below one, low-head dams
- [How Town Water and Sewer Work](guide:TOWN-WATER-SEWER-GUIDE) — boil-water notices, and sewage backing up into houses
