# 🌾 Food From Scratch

How to make staple ingredients — flour, masa, leavening, salt, sweetener, fat — from what grows
or can be raised around the Illinois Valley, and how to cook them: bread, tortillas, pasta and crackers,
and the everyday meals that follow — broth and stew, beans, porridge and mush, pan breads and
dumplings, roasts and pot-roasts, puddings, sauces — over a fire, on a stove, in an oven, in a
hay box or in the sun. Details and more recipes are in `Food-From-Scratch\`
(grain, wild and local staples, breads and staples) and `Gardening-Food\`. The links open each
book on the drive at the right page.

> ⚠️ **Two foods here can kill if you get them wrong:** **camas** has a deadly look-alike
> (death camas), and **acorns and lye/ash-cooked corn** must be processed properly. Follow the
> steps exactly, and never eat a wild plant you can't identify with certainty.

> 🍲 **Don't know what to make with what's in the house?** Open [What can I cook?](guide:RECIPES)
> (under **Tools**): tick the ingredients you have and what you can cook on, and it lists the
> meals you can make now, the ones you're one thing short of, and the steps. Every recipe here
> is in it, with the book and page it came from.

---

## 🗓️ The year at a glance

| When | What to gather or make | Source |
|---|---|---|
| Spring | Cattail shoots, 4–16 inches long | [Cattail guide, p. 1](lib:broadleaf-cattail-plant-guide-usda-nrcs#page=1) |
| April–May | Death camas blooms ([🖼️ what it looks like](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2)) — watch and mark your camas bed now | [PNW 104, p. 1](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=1) |
| Mid-April | Plant corn and potatoes (Rogue Valley advice — our valley floor frosts later; see the Start Here frost table) | [OSU EM 9027, p. 22](lib:osu-growing-your-own-practical-guide-to-gardening-in-oregon-em-9027#page=22) |
| June–July | [Hazelnuts](wiki:Corylus_cornuta) — pick before the bears do | [Hupa, p. 39](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=39) |
| Summer | Grain harvest; dig camas after it flowers | [SARE](lib:home-grain-harvest-threshing-and-winnowing-sare#page=1); [Camas, p. 1](lib:great-camas-plant-guide-usda-nrcs#page=1) |
| Late Sept–Nov | Acorns (the second fall); sugar pine nuts; bay nuts | [UCCE, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2); [Hupa, p. 40](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=40) |
| Cool months | Butcher and render (raw fat keeps only 5–7 days even chilled) | [Minnesota, p. 2](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=2) |
| Leaf drop → bud break | Tap bigleaf maples on freeze–thaw days ([🖼️ how to tap](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=4)) | [OSU EM 9163, p. 3](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=3) |

📚 **Go deeper:** [OSU *Growing Your Own*, p. 21](lib:osu-growing-your-own-practical-guide-to-gardening-in-oregon-em-9027#page=21) — gardening in southern Oregon; [*Food Plants of the North American Indians*](lib:food-plants-of-the-north-american-indians-usda-misc-pub-237-1936#page=6) — 1,112 native food plants and how each was prepared.

## 🌾 Flour from grain

- **Grow hulless varieties** of oats and barley if you can — hulled types need dehulling.
  Wheat and corn are the easiest staples to grow and grind. Winter grains are sown in fall and cut
  the next summer: ¼–½ inch deep, about 1 foot apart each way
  ([SARE, p. 2](lib:home-grain-harvest-threshing-and-winnowing-sare#page=2)).
- **Harvest** when the heads are fully tan and nodding and the kernels are too hard to dent
  with a fingernail. Cut about 10 inches below the heads.
- **[Thresh](wiki:Threshing)** by stomping the heads in a clean bin or on a tarp ([🖼️ a threshing box](lib:seed-processing-and-storage-principles-and-practices-mccormack-2010#page=4)); **[winnow](wiki:Winnowing)** by
  pouring the grain slowly in front of a fan (or in a breeze) so the chaff blows away. Repeat.
  ([SARE handout, p. 1](lib:home-grain-harvest-threshing-and-winnowing-sare#page=1))
- **Dry to 12–13% moisture before storing** — wetter grain heats, molds and draws insects. Field
  test: a dry kernel resists your thumbnail and **cracks sharply between your teeth**.
  ([Peace Corps *Small Farm Grain Storage*, p. 55](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=55))
  If you dry it with heat, keep eating grain below **140 °F** and seed grain below **113 °F**
  ([p. 53](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=53)).
- **Store whole grain, grind as needed.** Whole grain keeps for years; flour goes rancid within
  months once milled. A hand grain mill ([🖼️ drawing](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=17); [🖼️ a homemade pipe grinder](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=83)) is worth owning; otherwise grind between two stones (a
  [quern](wiki:Quern-stone): a turning top stone on a fixed bottom one) and sift out the bran
  ([*Shifts and Expedients*, p. 519](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=519)).
- **Kill pests in stored grain:** freeze small bags 2–3 days, or heat a ½-inch layer at
  140–150 °F for 30 minutes (may weaken bread rise). Store airtight, and only when dry.
  ([USU *Food Storage in the Home*, p. 14](lib:food-storage-in-the-home-grain-insect-control-usu#page=14); [🖼️ the common grain pests, FAO p. 78](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=78); [rice weevil](wiki:Rice_weevil))
- **A sealed, full container kills bugs on its own** — they use up the oxygen. Keep the grain you
  dip into daily in a separate small container ([Peace Corps, p. 279](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=279)).

![Winnowing: threshed grain poured slowly from a pan in front of a fan; the light chaff blows away across a tarp while the heavy grain falls straight into a tub](img:FOOD-FROM-SCRATCH-GUIDE/winnowing-grain.svg)
*Winnowing after threshing: the breeze carries off the light chaff and the grain drops into the tub; pour it through again until it's clean (a diagram drawn for this guide).*

**Best-quality rotation times** (sealed, about 70 °F; a 90 °F shed roughly halves them —
[USU, pp. 11, 17–19](lib:food-storage-in-the-home-grain-insect-control-usu#page=17)): whole wheat
kernels 25 years · white flour 1 year · cornmeal 1 year · dry beans 1 year · **whole-wheat flour
only 2 weeks**. USU says these are for rotating stock, not how long food stays usable; dry beans and rice
packed with oxygen absorbers keep for decades ([Food Security guide](guide:FOOD-SECURITY-GUIDE)).

| If this goes wrong | Fix |
|---|---|
| Grain feels warm or smells musty | Too wet — spread it and dry it now; by the time you feel heat you're late ([Peace Corps, p. 54](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=54)) |
| Bugs after freezing | Thaw a sample on a tray; if anything crawls, freeze again ([USU, p. 14](lib:food-storage-in-the-home-grain-insect-control-usu#page=14)) |
| "Bay leaves didn't work" | They don't — only clean, dry grain in tight containers stays bug-free ([USU, p. 15](lib:food-storage-in-the-home-grain-insect-control-usu#page=15)) |

📚 **Go deeper:** [Peace Corps *Small Farm Grain Storage*, p. 278](lib:small-farm-grain-storage-peace-corps-vita-manual-m-2-1976#page=278) — drying, airtight storage and insects in depth; [USU *Food Storage in the Home*, p. 13](lib:food-storage-in-the-home-grain-insect-control-usu#page=13) — pest treatments and storage times; [FAO *Barley*, p. 63](lib:barley-post-harvest-operations-and-recipes-fao#page=63) — barley breads and dishes.

## 🌰 Acorn flour

> 📷 **Not sure what it is?** Photograph it with the [plant and mushroom identifier](guide:PLANT-ID) (under **Tools**). It suggests names and flags poisonous groups, but it's often wrong: confirm every feature here before you eat or use anything.

Our oaks — **[tanoak](wiki:Notholithocarpus)** (the traditional favorite), **[California black
oak](wiki:Quercus_kelloggii)**, **[Oregon white oak](wiki:Quercus_garryana)** and [canyon live
oak](wiki:Quercus_chrysolepis) ([🖼️ tanoak photo](lib:tanoak-plant-guide-usda-nrcs#page=1); [🖼️ oak and acorn drawing](lib:fm-3-05-70-survival-2002#page=449)) — all make good flour, but **every [acorn](wiki:Acorn) must be leached** to remove
bitter tannins. A tanoak can drop over 200 pounds in a good year and bears some crop every year
([NRCS Tanoak, p. 1](lib:tanoak-plant-guide-usda-nrcs#page=1)).

1. **Gather the second fall** (late September–October); the first acorns down are mostly wormy.
   Dry them 2–5 days in the sun or 20 minutes in a 175 °F oven, door ajar. Whole, dry acorns
   keep **several years** — in sacks or jars, not plastic.
   ([UCCE, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2))
2. Crack and shell them, and remove any moldy or wormy ones. Grind the nutmeats to a coarse meal
   or flour.
3. **Leach** — any one of these:
   - **Hot:** soak in hot water for an hour, drain, repeat several times (fastest).
   - **Running water:** a cloth bag of meal in cold running water for several hours.
   - **Daily change:** 3 parts water to 1 part meal in jars, kept cool; pour off the dark water
     and refill every day for about a week.
   - Traditional: pour nearly scalding water over fine flour in a hollow scooped in clean sand
     ([Hupa, p. 38](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=38)).
4. **It's done when it tastes sweet, not bitter or puckery.** Cold leaching keeps more of the
   starch's binding power (better for bread); hot is faster.
5. Use it wet as **mush/porridge**, pat it into **flatbread** on a hot stone or pan, or dry it and
   replace **¼ to ½ of the wheat flour** in bread (acorn flour has no gluten on its own).
6. **Ground meal goes rancid** in a warm room — grind only a few weeks' worth and keep it cold
   ([UCCE, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2)).

**Other local nuts** need no leaching: hazelnuts (June–July, dry and eat raw; [🖼️ photo](lib:beaked-and-california-hazelnut#page=1)) and [sugar
pine](wiki:Pinus_lambertiana) nuts (October; pound the cones to free the seeds) —
[Hupa, pp. 39–40](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=39). **Bay
nuts** ([Oregon myrtle](wiki:Umbellularia); [🖼️ peeled bay fruit](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=3)) must be **roasted** at 350 °F for 30–45 minutes until
dark-chocolate brown; they taste of coffee and contain a caffeine-like stimulant
([UCCE, pp. 2–3](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=3)).

📚 **Go deeper:** [UCCE *Foods from the Tanoak Forest*, p. 2](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=2) — modern acorn and bay-nut processing step by step; [Goddard, *Life and Culture of the Hupa*, p. 37](lib:life-and-culture-of-the-hupa-acorn-leaching-goddard-1903#page=37) — how acorns were gathered, ground, leached and cooked just south of us; [NRCS Tanoak guide, p. 2](lib:tanoak-plant-guide-usda-nrcs#page=2) — storage, leaching and acorn bread.

🌰 **The local way:** choosing oaks, storing, pounding, leaching in a sand basin and stone-boiled mush, as the valley's first peoples did it, are in [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE).

## 🌿 Camas, cattail and other local starches

- **Camas bulbs** ([*Camassia quamash*](wiki:Camassia_quamash) — meadows, blue flowers in spring; [🖼️ photo](lib:great-camas-plant-guide-usda-nrcs#page=1))
  were a major food here. They must be **[pit-roasted](wiki:Earth_oven) or slow-baked 24–36 hours** — long cooking
  turns the indigestible starch sweet. Dry cooked bulbs or cakes for storage.
  ⚠️ **Death camas grows in the same meadows and its bulbs look the same.** Flower color is
  *not* a safe test. Only harvest from a bed you have watched bloom and learned plant by plant;
  if there's any doubt, leave it. ([USDA *Great Camas* guide, pp. 1–2](lib:great-camas-plant-guide-usda-nrcs#page=1); `Wild-Plants\` [death camas guide](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=1); [🖼️ death camas flowers and leaves](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2))
- **Dig after flowering**, take only the big bulbs, replant the small ones, and rest each patch a
  few years. Fresh bulbs don't keep; dried camas cakes are soaked overnight before eating
  ([Camas guide, pp. 1–2](lib:great-camas-plant-guide-usda-nrcs#page=2)).

| | Camas (edible) | [Death camas](wiki:Toxicoscordion_venenosum) (deadly) |
|---|---|---|
| Flowers | Blue-violet to **creamy white**, on a tall leafless stalk | Greenish to yellowish-white, in a pointed cluster |
| Height | 24–48 inches | 6–18 inch stem |
| Leaves | Long, narrow, grass-like | Grass-like, V-shaped, **edged with stiff hairs** |
| Bulb | Edible only after long cooking | Blackish scales, no onion smell — every part poisonous |

Sources: [Camas guide, p. 2](lib:great-camas-plant-guide-usda-nrcs#page=2); [PNW 104, pp. 1–2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2).
Death camas drawn: [🖼️ Army survival manual](lib:fm-3-05-70-survival-2002#page=507); [🖼️ Air Force survival handbook](lib:afh-10-644#page=347).
Some Oregon camas ([great camas](wiki:Camassia_leichtlinii)) is white-flowered — which is why color can't be trusted. Death camas symptoms
start **1–8 hours** after eating (drooling, vomiting, weakness, irregular heartbeat): get help at once.

![Old line drawing of camas in bloom: a tall stalk with star-like six-petaled flowers along the top and long, narrow, grass-like leaves, labeled "Camas (Camassia esculenta)"](img:FOOD-FROM-SCRATCH-GUIDE/camas-drawing.png)
*Camas: open, six-petaled flowers spaced up a tall stalk above long, narrow leaves ([Saunders, p. 44](lib:useful-wild-plants-of-the-united-states#page=44)). The flowers are **blue** (this old drawing has no color); the bulbs look like death camas, so dig only plants you marked while they bloomed blue.*

![Two USDA photographs of death camas in bloom: clusters of small yellowish-white flowers on short stalks above grass-like leaves](img:FOOD-FROM-SCRATCH-GUIDE/death-camas-in-bloom.png)
*Death camas: small yellowish-white flowers crowded at the top of a short stalk, grass-like leaves; left, meadow death camas ([AIB 415, p. 35](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=35)).*

- **Cattail** ([*Typha latifolia*](wiki:Typha_latifolia); [🖼️ drawing](lib:fm-3-05-70-survival-2002#page=416); [🖼️ photo](lib:broadleaf-cattail-plant-guide-usda-nrcs#page=1)): young shoots and stem bases (boiled or
  roasted), green flower spikes (boiled like corn), **pollen** to stretch flour, and **rhizome
  flour** (the root core is 30–46% starch — pound, soak, let the starch settle, dry it). Harvest
  only from **clean** water; cattails take up pollutants.
  ([Cattail guide, p. 1](lib:broadleaf-cattail-plant-guide-usda-nrcs#page=1))
- ⚠️ **[Western waterhemlock](wiki:Cicuta_douglasii) grows in the same wet ground** — the most
  poisonous plant in North America; a walnut-sized piece of root can kill a cow. Its stem base and
  roots are **hollow with cross-walls** and ooze yellow, oily juice. Never dig roots in wet ground
  unless you're sure. ([PNW 109, p. 1](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ photos of the chambered root](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ look-alikes compared, pp. 3–4](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3); [🖼️ Army drawing](lib:fm-3-05-70-survival-2002#page=519))
- More: USDA *Food Plants of the North American Indians* lists about 1,100 native food plants
  and how each was prepared ([p. 6](lib:food-plants-of-the-north-american-indians-usda-misc-pub-237-1936#page=6)).

![USDA photograph of a western water hemlock rootstalk split lengthwise, showing the stacked hollow chambers inside, with thick tubers and fine roots below](img:FOOD-FROM-SCRATCH-GUIDE/water-hemlock-root.png)
*Western water hemlock, the killer in wet ground: the thick rootstalk is hollow, with cross-walls making chambers full of poisonous juice ([AIB 415, p. 110](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=110)).*

📚 **Go deeper:** [USDA *Great Camas* guide](lib:great-camas-plant-guide-usda-nrcs#page=1) — harvest, cooking, drying; [PNW 104 *Meadow Deathcamas*](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=1) — identification photos; [PNW 109 *Western Waterhemlock*, p. 3](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3) — photo comparison with look-alikes.

## 🌽 Corn: masa, tortillas and hominy

**Always cook dried corn with lime or wood ash ("[nixtamal](wiki:Nixtamalization)")** before
making it a staple — it unlocks the corn's niacin. People living mostly on untreated cornmeal get
**pellagra** ([FAO *Maize*, p. 13](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=13)).

- **[Masa](wiki:Masa) with lime** (food-grade slaked lime, *cal*): use lime **1% of the dry corn's weight**
  (5 g of lime per 500 g of corn — weigh it if you can) and water **1½ times the corn's volume**. Heat to just below
  a simmer (200–210 °F) until the skins slip off but the center is still firm (often under 30
  minutes). **Rest 8–12 hours** in the liquid, then rub and rinse off the skins. Grind while cold
  (a [metate](wiki:Metate) or stone mill, with a little cold water; [🖼️ metate and hand mill](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=17)); use the masa within a day.
  ([Smithsonian method, pp. 1–3](lib:nixtamalization-and-corn-tortillas-smithsonian#page=2))
  Fresh corn needs less lime and cooking; old, hard corn more
  ([FAO, p. 66](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=66)).
- **With wood ash instead:** boil shelled corn 15–30 minutes in weak lye water made from
  **hardwood** ashes until the hulls loosen, then rinse very thoroughly in running water until no
  lye remains. **Lye is caustic** — gloves and eye protection; never taste it.
- **Lye hominy with store [lye](wiki:Lye)** (USDA) — use **pure** lye (100% sodium hydroxide, sold for
  soap-making), never a drain cleaner with other chemicals: 5 oz lye in 6 quarts cold water; stir in 5 quarts whole
  corn and let stand 15 hours. Wash and rub the corn in a cloth bag until hulls and black tips are
  gone, then boil 3–4 hours in salted water, changing the water once or twice to remove the lye
  taste. Makes 15–20 quarts.
  ([FB 1236, pp. 20–21](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=20))
- **[Corn tortillas](wiki:Corn_tortilla):** knead masa with a little water to a soft, play-dough feel, press balls flat
  between plastic or cloth, and cook on a hot dry griddle about a minute a side. Keep the masa under
  a damp cloth — dry masa cracks ([Smithsonian, p. 3](lib:nixtamalization-and-corn-tortillas-smithsonian#page=3)).
- **[Hominy](wiki:Hominy)** (whole kernels; [🖼️ an old hominy block](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=9); [🖼️ stone mortar and muller](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=68)) and **cornbread, mush, polenta and corn pone** recipes: USDA
  *Corn and Its Uses as Food* (FB 1236, [p. 11](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=11)).
  To stretch wheat, use a scant cup of cornmeal per cup of flour in quick breads and bake longer.
- **If the kernels go mushy all the way through,** they're overcooked and won't make masa — stop
  sooner next time ([Smithsonian, p. 2](lib:nixtamalization-and-corn-tortillas-smithsonian#page=2)).

![Old drawing of a corn kernel cut through, with the skin (a) around the outside, the germ (b) low in the middle and the starchy endosperm (c) filling the rest](img:FOOD-FROM-SCRATCH-GUIDE/corn-kernel-section.png)
*Inside a kernel: lime or lye loosens the skin (a) so it rubs off; the germ (b) holds most of the fat ([FB 1236, p. 6](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=6)).*

📚 **Go deeper:** [Smithsonian *Nixtamalization*](lib:nixtamalization-and-corn-tortillas-smithsonian#page=1) — the full masa method; [USDA FB 1236 *Corn and Its Uses*, p. 11](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=11) — mush, pone, cornbreads and hominy; [FAO *Maize*, p. 96](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=96) — tortillas and other corn recipes; [Parker, *Iroquois Uses of Maize*, p. 115](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=115) — hominy, samp and old corn dishes.

## 🍞 Leavening without store yeast or baking powder

- **Wild [sourdough](wiki:Sourdough) starter:** mix equal weights of flour (whole-grain or rye
  starts fastest) and unchlorinated water in a jar. **Every day, discard all but a little and feed it
  equal weights of flour and water** (twice a day from day 4). Keep it at 70–82 °F. Usable around
  **day 7**, strong in 2–4 weeks — it's ready when it **doubles within 4–6 hours** of feeding
  and smells yeasty and pleasant. Throw it out if mold appears.
  (Illinois *Sourdough 101*, [pp. 1–3](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=2))
- **Keep it going:** save ½ cup each time you bake; the night before, feed it equal parts flour
  and water and leave it warm 6–8 hours. Store in glass, not metal, with the lid loose. (Alaska's
  guide warns against all metal; Illinois allows stainless steel but never copper, iron or
  galvanized.) ([UAF *Sourdough*, p. 2](lib:sourdough-alaska-starter-and-recipes-uaf-fnh-00061#page=2))
- **Back-up:** spread some starter thin, dry it until brittle, and store it airtight. Revive by
  crumbling into warm water overnight, then feeding.
- **Sourdough pancakes and muffins** get ½ tsp baking soda dissolved in 1 Tbsp water, stirred in
  **last**. Never put soda in the starter itself — it can kill the yeast
  ([UAF, pp. 2–3](lib:sourdough-alaska-starter-and-recipes-uaf-fnh-00061#page=2)).
- **Potato yeast** and "saving a piece of dough" for next time: USDA *Bread and Bread Making*
  (FB 807, [p. 10](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=10)) — liquid
  yeast keeps about two weeks in a cool, dark place.
- **Quick breads:** **sour milk or [buttermilk](wiki:Buttermilk) + ½ tsp baking soda per cup** replaces sweet milk
  and baking powder ([FB 1136, p. 22](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=22)).
  Homemade baking powder = 1 part baking soda : 2 parts cream of tartar
  ([Fannie Farmer, p. 92](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=92)).

![A timeline for starting sourdough: day 1 mix flour and water, days 2 and 3 discard and feed once a day, from day 4 feed twice a day, usable about day 7, strong at 2 to 4 weeks; below, two jars show a starter that has doubled within 4 to 6 hours of feeding](img:FOOD-FROM-SCRATCH-GUIDE/sourdough-starter-schedule.svg)
*The first weeks of a wild starter, and the doubling test that tells you it's ready (a diagram drawn for this guide).*

| Starter trouble | Fix |
|---|---|
| Not rising after a week | Somewhere warmer; switch to rye or whole-grain flour; avoid very hard or chlorinated water ([Illinois, pp. 1–2](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=2)) |
| Dark liquid on top ("hooch") | It's hungry — pour it off or stir it in, then feed ([Illinois, p. 3](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=3)) |
| Any mold | Throw it out; restart from your dried back-up ([Illinois, p. 3](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=3)) |

📚 **Go deeper:** [Illinois *Sourdough Bread 101*, p. 4](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=4) — step-by-step loaf and schedules; [UAF *Sourdough*, p. 3](lib:sourdough-alaska-starter-and-recipes-uaf-fnh-00061#page=3) — hotcakes, muffins and bread; [USDA FB 807, p. 10](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=10) — potato yeast and saved dough.

## 🧂 Salt, 🍯 sweeteners and 🥓 fat

- **Salt from seawater** ([sea salt](wiki:Sea_salt)): seawater is about 3.5% salt — **roughly 4–5 gallons per pound** of salt
  in practice. Collect it away from harbors and outfalls, filter through cloth, boil down to a
  slush, then finish drying slowly; pour off the last bitter liquid for better taste.
- **[Bigleaf maple](wiki:Acer_macrophyllum) syrup** (OSU 2025 guide): tap after leaf drop and a hard freeze, through
  winter freeze–thaw days, until buds break. 5/16-inch spile in a 2-inch hole ([🖼️ tapping, step by step](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=4)); collect sap daily
  and boil it within 24 hours. Bigleaf sap is thin — **about 80 gallons of sap per gallon of
  syrup** (20 gallons ≈ 1 quart after ~8 hours of boiling). Syrup is done at **7 °F above the
  boiling point of water** where you are — about **216 °F around Cave Junction's elevation**
  (219 °F at sea level). ([OSU EM 9163, pp. 2–8](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=8))
  Keep buckets lidded — "ropey" (stringy) sap is spoiled ([🖼️ photos](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=6)). Let syrup settle and pour it off the
  gritty "sugar sand"; to keep it on a shelf, bottle it at **180–190 °F** into just-boiled jars
  ([pp. 6, 8–9](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=9)).
- **Honey:** strain through progressively finer cloth, keep it sealed (wet honey ferments);
  render the wax for candles and salves (`Practical Action` brief, [p. 1](lib:honey-processing-practical-action#page=1)).
  **Never heat honey to dry it** — blow air over a pan instead. Solid ("granulated") honey is fine.
  ([pp. 3–4](lib:honey-processing-practical-action#page=3)) Honey replaces sugar cup for cup in
  baking ([FB 1136, p. 23](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=23)).
- **[Lard](wiki:Lard) and [tallow](wiki:Tallow):** chill fat and render it within about a week. Melt slowly with a little
  water, stirring, at 235–245 °F (no copper pots), until bubbling stops and the cracklings float
  and turn chestnut-brown ([cracklings](wiki:Cracklings)); strain into clean jars, fill full, store cool and dark.
  ([Minnesota, pp. 2–3](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=3))
  Leaf (kidney) fat makes the best lard; strong-tasting gut fat is for soap. *Slightly* rancid lard
  can be rescued by heating it with sliced potatoes until they're dark brown, then straining
  ([pp. 2, 4](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=4)).
- **Nut oil** (hazelnuts, acorns): grind, boil with water, and skim the oil as it rises; clarify
  and store cool (`Practical Action` brief, [p. 2](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=2)).
  Discard moldy nuts first; store oil dark and airtight, never in copper
  ([pp. 1, 6](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=6); [🖼️ hand oil presses, p. 3](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=3)).
- **Butter:** sour the cream mildly at 65–75 °F, churn at 52–66 °F until grains the size of wheat
  form, drain, wash twice in cold water, and work in ¾ oz salt per pound
  ([USDA FB 876, pp. 23–24](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=23); [🖼️ the churn, p. 10](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=10); [🖼️ working the butter, p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16); [🖼️ a small churn](lib:butter-and-ghee-practical-action-2008#page=3); [butter churn](wiki:Butter_churn)).
- ⚠️ **Homemade vinegar** ([FB 1424](lib:usda-farmers-bulletin-1424-making-vinegar-1924#page=4)) is
  fine for cooking, but **never for canned pickles** — its acid strength is unknown, and canning
  recipes need tested 5% vinegar ([USDA Canning Guide 1, p. 28](lib:usda-complete-guide-to-home-canning-2015-guide-1-principles#page=28)).

📚 **Go deeper:** [OSU *Making Bigleaf Maple Syrup*, p. 3](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=3) — tapping, sanitation and bottling, with photos; [Minnesota *Making Lard at Home*](lib:making-lard-at-home-rendering-fat-univ-minnesota-1962#page=2) — rendering and what spoils lard; [Practical Action *Honey Processing*](lib:honey-processing-practical-action#page=1) — straining, moisture and wax; [USDA FB 876 *Making Butter*](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=3) — cream, churning and storage.

## 🥩 Jerky

- **Heat the meat to 160 °F** (poultry 165 °F) before or right after drying — drying alone doesn't
  kill *E. coli*, *Salmonella* or [trichinosis](wiki:Trichinosis). Ten people caught trichinosis from **cougar** jerky
  in 1995 ([PNW 632, p. 8](lib:pnw632-making-jerky-at-home-safely#page=8)); cougar and bear are
  hunted in our units ([ODFW, pp. 67–68](lib:odfw-2026-big-game-hunting-regulations#page=67)).
  Either dip strips 1½–2 minutes in simmering brine before drying, or heat the dried strips 10
  minutes in a 275 °F oven ([pp. 9, 17](lib:pnw632-making-jerky-at-home-safely#page=9); [🖼️ oven-heated jerky, p. 14](lib:pnw632-making-jerky-at-home-safely#page=14)).
- **Dry at 145–155 °F** (check with a thermometer; an oven with the door propped open works). Sun
  drying isn't recommended. **Done** when a cooled strip cracks but doesn't snap
  ([pp. 9, 18](lib:pnw632-making-jerky-at-home-safely#page=18); [photos](wiki:Jerky)). It keeps 1–2 months.

📚 **Go deeper:** [PNW 632 *Making Jerky at Home Safely*](lib:pnw632-making-jerky-at-home-safely#page=8) — tested methods and the hot-brine recipe; [NDSU *Preservation of Game Meats and Fish*, p. 5](lib:ndsu-wild-side-of-the-menu-3-preservation-of-game-meats-and-fish#page=5) — game jerky, smoking and curing.

## 🥖 Staples

- **No oven thermometer?** Put a scrap of white paper or ½ tsp flour on a tin plate in the oven; if
  it turns **light golden brown in 5 minutes**, it's right to start bread
  ([FB 807, p. 15](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=15)).
  Over a fire, cook on **coals**, not flames ([OSU EM 9331, p. 4](lib:osu-survival-basics-food-em-9331#page=4)).
- **Danger zone:** cooked food left between 40 °F and 140 °F for over 2 hours can make you sick
  ([OSU EM 9331, p. 5](lib:osu-survival-basics-food-em-9331#page=5)).

**Basic yeast bread — per loaf** (USDA FB 807, [pp. 13–17](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=16)): 1 cup lukewarm liquid, about **3 cups flour**,
1 tsp salt, 1 Tbsp sugar or honey, up to 1 Tbsp fat, and yeast (or ½ cup active sourdough
starter in place of yeast and part of the liquid). [Knead](wiki:Kneading) until smooth and springy, let it double,
shape, let it rise again, and bake at about 400 °F for 40–50 minutes, until it sounds hollow when
tapped. **Stop adding flour** once the dough doesn't stick to unfloured hands — too much flour
makes heavy bread. Rise it covered, at about 80 °F; it's ready for the oven when a light touch
leaves a slight dent.

**Simple sourdough loaf:** 1 cup active starter + 1 cup water + about 3 cups flour + 1½ tsp
salt. Knead, let rise 4–8 hours (longer when cool), shape, rise 2–4 hours more, bake at about
425 °F for 35–45 minutes. **Poke test:** a floured finger-dent that springs back halfway means
bake now; one that stays means over-risen — bake at once. A preheated **[Dutch oven](wiki:Dutch_oven)** (lid on 30
minutes, then off) gives a good crust without a real oven
([Illinois, pp. 5–6](lib:sourdough-bread-101-wild-starter-from-scratch-univ-illinois#page=5)).

**Flour tortillas / [flatbread](wiki:Flatbread):** 2 cups flour, ¼ cup lard, 1 tsp salt, about ¾ cup warm water.
Knead, rest 20 minutes, roll thin, cook on a hot dry pan 30–60 seconds a side. Works with part
acorn or barley flour. **Barley flatbread** with no yeast: [FAO *Barley*, p. 63](lib:barley-post-harvest-operations-and-recipes-fao#page=63).

**Biscuits** (USDA FB 1136, [p. 23](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=23)): 2 cups flour, 1 tsp salt, 2 tsp baking powder (or the soda and sour
milk swap above), 2 Tbsp fat, ⅔–¾ cup liquid. Bake hot (about 450 °F) 12–15 minutes. Keep it all
cold and handle it lightly. Too much soda makes them yellow and bad-tasting
([p. 22](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=22)).

**Crackling bread:** for each cup of cornmeal, ¾ tsp salt and ½ cup cracklings left from rendering
lard; pour on boiling water until you can mash it by hand, shape into cakes and bake
([FB 1236, p. 12](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=12)).

**Pasta / egg noodles:** 2 cups flour, 1 egg + 2 yolks, ½ tsp salt, about ⅓ cup water (or the old
way: one egg, a pinch of salt and enough flour for a very stiff dough). Knead 8–10 minutes,
rest 10–20, roll paper-thin, cut ⅛–¼ inch strips. Cook fresh 2–4 minutes, dried 10–12. To store,
dry until the noodles **snap**; keep airtight about a month (longer frozen). (Illinois Extension,
[p. 2](lib:homemade-egg-noodles-univ-illinois-extension#page=2);
Fannie Farmer 1896, [p. 167](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=167))
Because of the raw egg, Illinois says don't air-dry over 2 hours — finish them at about 135 °F.

**[Hardtack](wiki:Hardtack) (keeps for years):** 3 parts flour to 1 part water (no salt — salt draws moisture and
mold), stiff dough, ½ inch thick, prick with holes, bake 1 hour at 375 °F, then dry 3 more days.
Soak or crumble into soup to eat. ([City of Alexandria](lib:ship-biscuits-hardtack-how-to-make-city-of-alexandria#page=1))

**Beans:** soak overnight (6 cups water + 2 tsp salt per pound) or quick-soak (boil 2 minutes,
stand 1 hour), then simmer 2–4 hours. Old beans take longer; lentils and split peas need no soak.
**Beans + corn (or wheat) together make complete protein.** Add tomatoes or vinegar only after
they're tender — acid stops beans softening
([USU, pp. 2–4](lib:dry-beans-and-peas-soaking-and-cooking-usu#page=3)). Canning beans needs a
**pressure canner**: at Cave Junction's elevation a weighted-gauge canner runs at **15 lb**
([OSU EM 9435, p. 3](lib:osu-preserving-dry-beans-em-9435#page=3)).

**Porridge and mush:** cracked wheat, oats, barley, cornmeal or leached acorn meal simmered in
about 3–4 times their volume of water with a pinch of salt. Hominy grits can finish overnight
in a [hay box](wiki:Haybox) ([🖼️ how to build one](lib:usda-homemade-fireless-cookers-fb771-1919#page=8); [🖼️ its parts](lib:practical-action-fireless-cookers-haybox-technical-brief#page=2)) after a 10-minute boil; coarse hominy needs longer on the fire first
([FB 1236, p. 19](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=19)).

📚 **Go deeper:** [USDA FB 807 *Bread and Bread Making*, p. 12](lib:bread-and-bread-making-in-the-home-usda-fb-807-1917#page=12) — kneading, rising and baking; [USDA FB 1136 *Quick Breads and Biscuits*, p. 22](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=22) — biscuits, muffins and griddle cakes; [Fannie Farmer 1896, p. 92](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=92) — hundreds of everyday recipes; [Practical Action *Fireless Cookers*, p. 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5) — hay-box cooking times.

## 🔥 What to cook it on

Every recipe below says what heat it needs. These are the heats a household has when the power is off.

| Heat | Best for | Watch for |
|---|---|---|
| **Flames** | Boiling water, searing the outside of meat | Never fry over flames — the grease burns and can catch fire ([Kephart, p. 295](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=295)) |
| **Coals** | Broiling, frying, pan bread, roasting *in front of* the fire | Rake a thin layer of coals out in front of the fire; small dry sticks make coals fast ([Kephart, p. 295](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=295)) |
| **Wood stove top** | Soups, stews, porridge, frying — anything a stove top does | Hottest over the firebox; the back of the stove is the slow spot *(rule of thumb)* |
| **Oven** | Bread, roasts, puddings, custards | No thermometer? The flour-on-a-plate test is under **Staples** above |
| **[Dutch oven](wiki:Dutch_oven) or covered pot in coals** | Bread, beans, braises, pot-roasts | Coals on the lid as well as under it *(rule of thumb)* |
| **Reflector in front of the fire** | Biscuits, roasts | Build the fire high; turn the pan when the front is done ([Kephart, pp. 300, 351](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=351)) |
| **[Hay box](wiki:Haybox)** (fireless cooker) | Anything long and slow, after a hard boil | Food goes in boiling hot and must be reheated to boiling before eating ([Practical Action, p. 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5)) |
| **Solar oven** | Slow baking on a sunny day | A well-made box reaches about **300 °F**, and 400 °F on a hot summer day ([Aprovecho, p. 7](lib:aprovecho-capturing-heat-five-earth-friendly-cooking-technologies#page=7)) |
| **Ashes, or a pit of coals** | Loaves, whole birds, camas, a pot left overnight | Try it on something cheap first — the heat and timing come only with practice ([Kephart, pp. 301, 348](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=301)) |

**The four rules that make the difference:**

1. **Sear, then move it away from the heat.** Set the outside in a bright flame or a very hot pan, then
   cook it gradually until done ([Kephart, p. 295](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=295)).
2. **Match the time to the method.** Frying and broiling are quick; roasting, baking and boiling take an
   hour or two; a stew or a soup made from raw materials takes **half a day**
   ([Kephart, p. 295](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=295)).
3. **Meat starts in cold water, fish in boiling water.** Bring meat up slowly, then keep it barely
   simmering, covered ([Kephart, p. 304](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=304)).
4. **Tough cuts are boiled or braised; only tender pieces are broiled or roasted**
   ([Kephart, p. 295](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=295)).

> ⚠️ **Hay box safety.** A hay box holds heat; it does not make heat. Boil the food hard first — **beans
> and meat 20–25 minutes**, soft food about 3 minutes — then 2 to 2½ hours in the box for hard food and
> about 25 minutes for soft. **Reheat it to boiling before eating.** Meat and beans (kidney beans and
> chickpeas especially) are the risky ones, because food sitting between 40 °F and 140 °F grows bacteria.
> ([Practical Action, p. 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5);
> [OSU EM 9331, p. 5](lib:osu-survival-basics-food-em-9331#page=5))

**Hay-box timings that work** ([FB 771, pp. 14–15](lib:usda-homemade-fireless-cookers-fb771-1919#page=14)):
porridge and cereals — boil 10 minutes, in the box overnight, reheat in the morning · soup stock — boil
15 minutes, box overnight · pot roast — sear, cover with boiling water, boil gently 30 minutes (20 for a
3-lb roast), box overnight, reheat and box again till noon · **green vegetables — two and a half times as
long in the box as on the stove** · potatoes in a boiled dinner only in the last hour and a quarter.

📚 **Go deeper:** [USDA FB 771 *Homemade Fireless Cookers*, p. 14](lib:usda-homemade-fireless-cookers-fb771-1919#page=14) — recipes and timings for the box; [Practical Action *Fireless Cookers*, p. 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5) — how to use one safely; [Aprovecho *Capturing Heat*, p. 7](lib:aprovecho-capturing-heat-five-earth-friendly-cooking-technologies#page=7) — a solar oven that really cooks; [Kephart, *Camping and Woodcraft*, p. 295](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=295) — cooking over a fire, chapter and verse; [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE) — cooking with little fuel.

## 🍲 Broth, soup and stew
<!-- fold: Bone broth, stew with dumplings, bean and pea soups, chowder, and broth for someone who is ill -->

Soup is how a household lives on bones, scraps and whatever the garden gave. Long, slow heat gets
everything out of a bone, so soup is the natural job for the back of the stove and for the hay box
([FB 771, p. 14](lib:usda-homemade-fireless-cookers-fb771-1919#page=14)).

**Bone broth (brown soup stock)** *(stove top, the back of a slow fire, or a hay box · 7½ hours)* —
6 lb of shin or any bony cut, 3 quarts cold water, ½ cup each of carrot, turnip, onion and celery cut
in dice, 1 Tbsp salt, ½ tsp peppercorns, a few cloves, ½ bay leaf, a sprig or two of herbs.

1. Cut the lean meat in 1-inch cubes. Brown **a third** of it in a hot pan in marrow or fat.
2. Put the other two-thirds, with the bone and fat, in the kettle. Add the water and let it stand 30 minutes.
3. Add the browned meat and heat slowly to boiling. Skim off the scum as it rises.
4. Cover and cook **6 hours**, kept below boiling the whole time.
5. Add the vegetables and seasonings, cook **1½ hours** more, strain, and cool it as fast as you can.

([Fannie Farmer, p. 142](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=142))
**Don't salt a stock until it is half cooked**, and set the pot far back on the stove so it comes to the
boil slowly; five or six hours of simmering gets everything out of the bones
([*Household Discoveries*, p. 805](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=805)).

**The same broth in a hay box:** split the bones well or cut the meat small, cover with cold water, bring
to a boil and **boil 15 minutes**, then into the box overnight. In the morning lift out the meat and
bones, strain, skim the fat, season, bring back to a boil and return it to the box until dinner. One
kettle of stock becomes vegetable soup, clear soup or noodle soup
([FB 771, p. 14](lib:usda-homemade-fireless-cookers-fb771-1919#page=14)).

**Stew with dumplings** *(stove top or a slow fire · about 3½ hours)* — 5 lb of a bony, tough cut (beef,
venison, goat or mutton), ½ cup flour, salt, pepper, 4 cups potatoes in slices, ½ cup each turnip and
carrot in cubes, half a small onion sliced.

1. Cut the meat off the bone in 1½-inch cubes, season, and dredge with flour.
2. Try out some of the fat in a frying pan, add the meat, and stir constantly so the surface sears quickly.
3. Put the meat in the kettle with the sawn bones; rinse the frying pan out with boiling water into the
   kettle so none of the goodness is lost.
4. Cover with boiling water, boil 5 minutes, then cook below boiling until tender — **about 3 hours**.
5. Add carrot, turnip and onion for the **last hour**, with salt and pepper. Parboil the potatoes 5
   minutes and add them **15 minutes** before the end.
6. Skim, then thicken with ¼ cup of flour stirred smooth in cold water. Surround with dumplings
   (**Pan breads, dumplings, pancakes and fritters**, below).

([Fannie Farmer, pp. 218–219](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=218))

**Bean or pea soup** *(stove top or hay box · 3–4 hours)* — 1 pint of dry beans, 2 quarts cold water,
a small onion, 2 stalks of celery, ½ Tbsp salt, pepper, mustard, 3 Tbsp butter or lard, 1½ Tbsp flour.

1. Soak the beans overnight. Drain, cover with the cold water.
2. Cook the sliced onion 5 minutes in half the fat and add it, with the celery broken up.
3. Simmer **3–4 hours** until the beans are soft, adding water as it boils away.
4. Rub it all through a sieve, reheat to boiling, and season.
5. Thicken with the rest of the fat and the flour cooked together.

([Fannie Farmer, p. 157](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=157))
Dried lima beans, peas and lentils make a good soup with **no meat at all**, and the long cooking they
need suits a hay box exactly; cooked with less water, sieved and thinned with milk they become a
"cream" soup ([FB 771, p. 14](lib:usda-homemade-fireless-cookers-fb771-1919#page=14)). Left-over baked
beans make soup too: simmer 3 cups of them with 3 pints of water, onion and celery for 30 minutes, sieve,
and thicken ([Fannie Farmer, p. 158](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=158)).

**Corn chowder** *(stove top · about 40 minutes)* — a 1½-inch cube of fat salt pork, 1 sliced onion,
4 cups potatoes in ½-inch slices, 2 cups boiling water, 2 cups corn, 4 cups scalded milk, salt, pepper,
3 Tbsp butter, hardtack or crackers.

1. Cut the pork small and try it out. Add the onion and cook 5 minutes, stirring so it does not burn.
   Strain the fat into a stewpan.
2. Parboil the potatoes 5 minutes, drain, and add them to the fat. Add the boiling water and cook until
   the potatoes are soft.
3. Add the corn and the milk and heat to boiling. Season, add the butter.
4. Split the crackers or hardtack, soak them in a little cold milk, and put them on top.

([Fannie Farmer, p. 163](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=163))
**Fish chowder** is the same dish with 4 lb of fish instead of corn: simmer the head, tail and backbone
in 2 cups of water for 20 minutes for the broth, add that and the fish to the potatoes, simmer 10
minutes, then add the milk, butter and crackers
([pp. 163–164](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=164)).

**Broth for someone who is ill** *(a cool oven · 4–5 hours)* — 3 lb of lean shin cut small, in a jar
with seasoning and just enough water to cover; tie brown paper over the top and leave it in a cool oven
4–5 hours, then strain. It sets as a jelly when cold, and someone who cannot keep hot broth down can
sometimes keep this down ([*Priceless Recipes*, pp. 181–182](lib:lees-priceless-recipes-3000-formulas-1900#page=181)).
A **beef-tea custard** — a gill of broth, 2 egg yolks, 1 white, a pinch of salt, steamed 20 minutes in a
buttered cup with the water never bubbling — is another way to get meat into someone who is weak
([p. 181](lib:lees-priceless-recipes-3000-formulas-1900#page=181)). Feeding someone who has been
starving is its own subject: see [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE).

📚 **Go deeper:** [Fannie Farmer 1896, p. 157](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=157) — soups made without any stock; [USDA FB 771, p. 14](lib:usda-homemade-fireless-cookers-fb771-1919#page=14) — soups and stews in a hay box; [*Household Discoveries*, p. 805](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=805) — dozens of plain soups, including soup from left-over vegetables.

## 🫘 Beans, peas and lentils
<!-- fold: Baked beans, beans in a hay box, bean and hominy cakes, and the old corn-bean-squash winter dish -->

Dry beans keep for years, and beans with corn or wheat make a complete protein (**Staples**, above).
Soaking and simmering are there too; these are the dishes.

> ⚠️ **Boil beans hard before they go in a hay box or a solar oven** — 20–25 minutes — and reheat to
> boiling before eating. Kidney beans and chickpeas are the ones that cause trouble when they sit warm
> ([Practical Action, p. 5](lib:practical-action-fireless-cookers-haybox-technical-brief#page=5)).
> Add tomatoes or vinegar only once the beans are tender, or they will never soften
> ([USU, p. 3](lib:dry-beans-and-peas-soaking-and-cooking-usu#page=3)).

**Baked beans** *(a slow oven, a Dutch oven in coals, or a bean hole · 6–8 hours)* — 1 quart of small
white beans, ½ lb fat salt pork, 1 Tbsp salt, 1 Tbsp molasses, 3 Tbsp sugar (honey or maple syrup does
the same job), boiling water.

1. Pick over the beans, cover with cold water, and soak overnight.
2. Drain, cover with fresh water, and heat slowly — **below boiling** — until the skins burst. Test by
   taking a few beans on a spoon and blowing on them: if the skins break, they are ready. Drain.
3. Scald the pork rind, cut a ¼-inch slice off it and lay that in the bottom of the pot. Score the rest
   of the rind every ½ inch, cuts an inch deep.
4. Put in the beans and bury the pork among them with the rind showing.
5. Mix the salt, molasses and sugar with 1 cup of boiling water, pour it over, then add boiling water to
   cover.
6. Cover and bake slowly **6–8 hours**, adding water as needed. Take the lid off for the last hour so the
   rind browns and crisps.

([Fannie Farmer, pp. 247–248](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=247))
You do not need a bean pot: a five-pound lard pail works just as well
([p. 248](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=248)). In a pit, the same beans go
in a covered kettle, the coals are raked around and over it, and it is buried overnight
([Kephart, p. 301](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=301)).

**Hominy and bean cakes** *(stove top or coals · 15 minutes once the beans are cooked)* — 1 cup boiled
coarse hominy, 1 cup cooked beans, ½ cup milk, 1 Tbsp fat, ½ Tbsp cornstarch or flour, 1 tsp salt,
a pinch of cayenne.

1. Melt the fat, blend in the flour, salt and pepper, add the milk, and cook until thick.
2. Grind or mash the hominy and beans together and mix them into the sauce.
3. Shape into cakes and brown them in a little fat. They can take the place of meat.

([FB 1236, p. 19](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=19))

**Four-vegetables-mixed** *(stove top or a fire · about an hour)* — the winter dish of the Hidatsa
gardeners, built entirely on things that store: dried beans, dried squash, parched corn and parched
sunflower seed. It needs no meat, because the sunflower seed carries the fat.

1. Put a pot of water on the fire and throw in **one double handful of beans** — no more, whatever the
   size of the family, or it makes gas.
2. Add a ring of dried squash slices and cook until they are soft.
3. Lift the squash out, chop and mash it, and return it to the pot.
4. Add **four or five double handfuls** of mixed meal of pounded parched sunflower seed and pounded
   parched corn.
5. Boil a few minutes more and serve. A little salt, if you like; nothing else.

([Buffalo Bird Woman, p. 44](lib:agriculture-of-the-hidatsa-indians-told-by-buffalo-bird-woman-wilson-1917#page=44))

**Beans mashed in fat** *(stove top · 10 minutes)*: cooked beans mashed into hot lard or tallow with
salt and a little of their own liquid, fried until they hold together, make a filling for flatbread and
a way to use yesterday's pot *(rule of thumb)*.

📚 **Go deeper:** [USU *Dry Beans and Peas*, p. 3](lib:dry-beans-and-peas-soaking-and-cooking-usu#page=3) — soaking, cooking and why acid stops them softening; [OSU *Preserving Dry Beans*, p. 3](lib:osu-preserving-dry-beans-em-9435#page=3) — drying and canning them.

## 🥣 Porridge, mush, hominy and grain dishes
<!-- fold: Cornmeal mush and fried mush, polenta, hominy and samp, barley, and acorn mush and bread -->

Whole grain keeps for years and a sack of it is most of a winter's food. These are the ways it gets eaten
day after day without anyone minding.

**Cornmeal mush** *(a double boiler or the back of a stove · 30 minutes to 4 hours)* — per cup of
cornmeal: **1 to 1½ level tsp salt and 3½ to 6½ cups of water** (more water the longer you cook it).
Milk can replace part or all of the water.

1. Put the meal, cold water and salt together in the top of a double boiler. **No stirring is needed** —
   that is the whole point of starting cold.
2. Set it over the lower pan and let it heat slowly. Cook **half an hour, or longer if convenient**. Many
   people cook it four hours.
3. Just before serving, take the top pan off and boil the mush hard for two or three minutes. It will not
   lump at this stage, and it needs to reach a boil for the flavor.

([FB 1236, p. 11](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=11))
In a hay box: boil it 10 minutes at night, leave it in the box overnight, and reheat in the morning
([FB 771, p. 14](lib:usda-homemade-fireless-cookers-fb771-1919#page=14)).

**Three ways to make mush into another meal**
([FB 1236, p. 12](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=12)):
- **Fried mush:** pack it in a pan, let it set cold, slice it, and fry the slices. Or cook meal in three
  times its volume of water just long enough to make a mush and finish the cooking by frying it in fat —
  faster, because fat is far hotter than boiling water.
- **With cheese:** stir in about **½ cup (2 oz) of grated cheese per cup of meal** at the end. It then
  needs no butter or cream, and it can be fried or baked afterwards.
- **In buttermilk:** cook white meal in buttermilk — **1 part meal to 6 parts buttermilk, 1 tsp salt per
  cup of meal**. It tastes like cottage cheese, and is best cold with cream.

**Polenta with a sauce** *(stove top · 20 minutes after the mush is made)* — mush, reheated in a sauce
and sprinkled with cheese. Cut it small so the sauce gets through it.
- **Tomato sauce:** melt 2 Tbsp butter, cook 2 Tbsp flour in it thoroughly, add 1 cup thick strained
  tomato juice, salt and pepper, and cook smooth, stirring.
- **Savory sauce:** cut up 2 oz of salt pork, bacon or sausage and heat it crisp but not burnt; cook a
  little chopped onion and pepper in the fat; add a cup of thick tomato juice and cook it down to a cupful;
  salt it. Mushrooms or chopped pickle can go in.

([FB 1236, pp. 11–12](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=11))

**Coarse hominy or samp** *(hay box, double boiler, or over the fire · 2 to 12 hours)* — 1 cup coarse
hominy, 6 cups boiling water, 3 tsp salt.

1. Soak the hominy in 2 cups of water for 6 hours or overnight.
2. Add the boiling water and salt and **boil 10 minutes** over the fire.
3. Then either: into the hay box for **8–12 hours**; or a double boiler for **5–6 hours**; or straight
   over the fire for about **2 hours**. A cup of milk stirred in 15 minutes before the end is good.
4. Cook a big batch — it keeps well in a cool place. Serve it plain, or browned in a little fat in place
   of a vegetable.

([FB 1236, p. 19](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=19))
**Hominy grits:** 1 cup grits to 5 cups water and 2 tsp salt — add the grits slowly to the boiling
salted water, boil 10 minutes, then overnight in the hay box or 2 hours in a double boiler (same page).
**Hominy turnover** (a supper from a pint of cooked hominy, 1 cup milk, 2 beaten eggs, 1 Tbsp fat, 1 tsp
salt, stirred in a greased pan until hot, browned on the bottom and folded like an omelet) and
**scalloped hominy** (layers of hominy and minced meat, fish or grated cheese under a cup of white sauce,
baked 30 minutes) are on the same page.

**The older way with whole corn** ([Parker, pp. 115–116](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=116)):
coarse pounded corn, **1 part meal to 8 parts water, boiled 2 hours**, with meat and beans cooked in it;
or **hulled corn**, washed free of skins and hulls, put in cold water and **boiled 4 hours** until the
kernels burst open, with small chunks of meat and fat thrown into the boiling liquid.
⚠️ Corn that will be a daily staple must first be cooked with lime or ash (**Corn**, above), or people
get pellagra.

**Barley** *(stove top · ½–¾ hour)*: simmer barley in about four times its volume of water until just
tender, **half to three-quarters of an hour**, then sweeten it, or use it in soup or in place of rice
([FAO *Barley*, p. 63](lib:barley-post-harvest-operations-and-recipes-fao#page=63)). **Barley water**
for the sick or for thinning milk: ¼ cup pearl barley and 1 quart water with lemon rind, simmered
covered on the lowest heat for **two hours**, then strained (same page).

**Acorn mush and acorn bread** *(stone-boiling, a hot flat rock, an earth oven or hot stones)*: leached
acorn meal (see **Acorn flour**, above) mixed with water and cooked makes porridge and a thick soup;
poured onto a hot flat rock it makes pancakes and bread. Acorn cakes about 3 inches across were wrapped
between two layers of grass and cooked **overnight** in an earth oven, and a dry acorn bread baked on
hot stones **kept for a month or more**
([NRCS Tanoak, p. 2](lib:tanoak-plant-guide-usda-nrcs#page=2)).

📚 **Go deeper:** [USDA FB 1236 *Corn and Its Uses*, p. 11](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=11) — mush, polenta, hominy and the breads; [FAO *Barley*, p. 63](lib:barley-post-harvest-operations-and-recipes-fao#page=63) — soups, breads, puddings and drinks from barley; [Parker, *Iroquois Uses of Maize*, p. 115](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=115) — dozens of corn dishes as they were really made.

## 🥘 Pan breads, dumplings, pancakes and fritters
<!-- fold: Bannock, ash cake, corn pone and dodgers, dumplings, flapjacks, steamed bread and fritters -->

Bread with no oven, and the quick things that turn flour and meal into a meal. Yeast bread, sourdough,
biscuits, flatbread, hardtack and noodles are under **Staples**, above.

**Bannock (camp bread)** *(a frying pan propped in front of coals, a reflector, or a covered pot · 25–40
minutes)* — enough for four: 3 pints flour, 3 heaping tsp baking powder, 1 heaping tsp salt, 2 heaping
Tbsp cold grease (lard, pork fat, drippings or tallow), 1 scant pint cold water.

1. Mix the baking powder through the flour thoroughly, then the salt.
2. Rub in the cold grease until there are no lumps and none sticks to the pan. Do not skimp this.
3. Stir in the water and work it to a rather stiff dough.
4. Grease the pan, turn the loaf in, and rake embers out in front of the fire. Set the pan on them just
   long enough to crust the bottom.
5. Prop the pan up at an angle facing the fire so the top gets the heat. Turn the loaf now and then, both
   ways. **Never less than 25 minutes.**
6. Done when no dough sticks to a sliver pushed into the middle. Break hot bread with your hands, never
   cut it.

([Kephart, pp. 348, 351](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=351))
Left over and dry, sprinkle it with water and heat it through — once only
([p. 351](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=351)). The same dough rolled
¾ inch thick and cut out makes **two dozen biscuits** in a reflector (same page).

**Ash bread (damper)** *(a fire's own ashes · until done)*: build a good fire on level ground, let it
burn to coals and heat the earth, rake the embers aside, drop the loaf on the hot ground, pat it smooth,
rake hot ashes and then embers back over it, and leave it until a sliver comes out clean. It is not
dirty; brush it off ([Kephart, p. 348](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=348)).

**Corn pone and corn dodgers** *(a Dutch oven, an oven, or a hot frying pan · about 45 minutes + 15)* —
1 quart cornmeal, 1 tsp salt, 1 pint warm (not scalding) water — 1¼ pints if the meal is old.

1. Stir the meal, salt and water together until the batter is light.
2. Bake to a good brown all round, **about 45 minutes**, then let it sweat 15 minutes more in the closed
   oven off the fire.
3. For **dodgers**, mix it stiff instead, roll cylinders 4–5 inches long and 1¼ inches thick between your
   hands, drop them into a very hot greased pan, brown them, then bake them through.
4. For **ash cakes**, roll the same dough into balls the size of hen's eggs, roll them in dry flour, lay
   them in hot ashes and cover them completely.

([Kephart, p. 356](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=356))
Plain corn bread with no flour, milk or egg is hard to get right without a Dutch oven, and is usually
spoiled by being baked too fast and not long enough to be done inside (same page). The milk-and-soda
version — 2 cups cornmeal, ¾ cup water, ½ cup sour milk or buttermilk, ½ tsp soda, 1 tsp salt, 1 Tbsp
sugar, 2 tsp baking powder, shaped into cakes and baked in a hot greased pan in a hot oven — is in
[FB 1236, p. 12](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=12).

**Dumplings** *(steam over boiling water, or on top of a stew · 12 minutes)* — 2 cups flour, 4 tsp
baking powder, ½ tsp salt, 2 tsp butter or lard, ¾ cup milk.

1. Sift the dry things together, rub in the fat with your fingertips, and add the milk gradually, cutting
   it in with a knife.
2. Pat and roll the dough out ½ inch thick on a floured board and cut rounds.
3. Set them close together in a greased steamer over boiling water, cover tightly, and **steam 12
   minutes**. A tin pie plate punched full of holes works as a steamer.
4. Or make the dough a little wetter, drop it by spoonfuls on top of a stew, and cook it there — ladle
   some liquid out first so the dumplings rest on the meat and potato instead of sinking.

([Fannie Farmer, p. 218](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=218))

**Corn dumplings** *(a pot of boiling water or a pot of boiling meat · 30 minutes)*: moisten cornmeal
with boiling water, shape it quickly into cakes in a closed hand dipped in cold water, drop them one by
one into boiling water and **boil half an hour**. They were the favourite thing to cook with boiling
meat, especially game birds — speared out of the pot on a sharp stick and nibbled with the meat
([Parker, p. 115](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=115)).

**Flapjacks** *(a hot pan over a thin bed of coals · a minute or two each)* — 1 quart flour, 1 tsp salt,
2 tsp sugar or 4 of molasses, 2 level Tbsp baking powder, 2 heaped Tbsp grease rubbed in dry (leave the
grease out if you have none), and milk or water.

1. Make a smooth batter, thin enough to pour from a spoon but no thinner.
2. Set the pan level over a thin bed of coals, get it quite hot, and grease it with a piece of pork held
   in a split stick. The batter must sizzle as it touches.
3. Pour enough to fill the pan to within half an inch of the rim.
4. When the cake is full of bubbles and the edges have stiffened, shuffle the pan to be sure it is loose,
   then turn it.
5. Grease the pan and stir the batter again before every cake. Two eggs make them much better; cold
   boiled rice mixed half and half with the flour makes them tender.

([Kephart, p. 359](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=359))
For **sourdough hotcakes**, stir ½ tsp of baking soda dissolved in 1 Tbsp of water into the batter last
(**Leavening**, above).

**Rieska — unleavened barley bread** *(a hot oven · 30 minutes)* — ½ cup buttermilk (or any liquid),
½ cup cream, ½ tsp salt, ½ tsp sugar, 1 cup barley flour, 1 Tbsp melted butter. Mix the liquids, beat in
the flour until smooth, add the butter, pour into a buttered 9-inch round pan — or spread the dough on
cabbage leaves on a greased sheet — and bake at **450 °F for about 30 minutes**. Serves 4–6.
([FAO *Barley*, pp. 63–64](lib:barley-post-harvest-operations-and-recipes-fao#page=63))

**Steamed bread, for a kitchen with no oven** *(a covered tin or can in a kettle of boiling water ·
3½ hours)* — 1 cup each of cornmeal, rye meal and graham flour, 1 tsp salt, soda and baking powder,
¾ cup molasses, 2 cups sour milk (or 1½ cups sweet milk). Mix and sift the dry things, add the molasses
and milk, beat well, and **steam 3½ hours** in well-buttered covered tins; take the covers off and dry
the top by the fire or in the oven
([FB 1236, p. 13](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=13)).

**Fritters** *(a deep pan of hot fat · 3–5 minutes a batch)* — batter: 1 cup flour, ½ tsp salt, ⅔ cup
milk or water, 2 egg yolks, 1 Tbsp melted fat, and 2 egg whites beaten stiff and folded in last. Stir in
sliced sour apples (or corn, cooked beans, or chopped greens), drop by spoonfuls into hot deep fat, fry,
and drain ([Fannie Farmer, p. 347](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=347)).

📚 **Go deeper:** [Kephart, *Camping and Woodcraft*, p. 348](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=348) — breadstuffs over a fire, in detail; [USDA FB 1136 *Quick Breads and Biscuits*, p. 22](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=22) — muffins, griddle cakes and biscuits; [UAF *Sourdough*, p. 3](lib:sourdough-alaska-starter-and-recipes-uaf-fnh-00061#page=3) — hotcakes and muffins from a starter.

## 🍖 Meat: roasts, pot-roasts and tough cuts
<!-- fold: Broiling times, braising, pot roast in a hay box, pit baking, old birds, game, gravy and sausage -->

Most of the meat a household eats is tough, because most of an animal is tough and the tender part is
small. Tough meat is not worse meat — it just needs water, a lid and time.

**Broiling, for tender pieces only** *(a bed of bright coals · 5–20 minutes)*: cut the meat at least an
inch thick. Have clear coals with a flaming fire to one side. Sear the outside in the flame for a moment,
then broil it **in front of** the fire rather than over it, with a pan underneath for the drippings.
**1 inch thick — 5 minutes · 1¼ inches — 10 minutes · 2 inches — 20 minutes.** Do not season until it is
done. Venison usually wants pounding first, but do not gash it.
([Kephart, p. 297](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=297))
With no broiler, get a clean frying pan almost red hot, cover it, and turn the meat often without
stabbing it: a large venison steak is done in **10 minutes**, and the juices are saved (same page).
**Kabobs** when you are in a hurry: 1½–2-inch pieces off the saddle, pounded, cut small, speared on a
sharpened stick, salted and peppered, plunged into a bright flame for a moment and then toasted slowly
over the embers — eat one while the next toasts
([p. 300](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=300)).

**Braising, for everything else** *(a Dutch oven or any covered pot, on coals or a stove · 15 minutes to
the pound)* —

1. Put the meat in the pot with about **2 inches of hot water** and a bit of bacon or salt pork (no pork
   with bear). Add chopped onion if you like.
2. Cover and cook about **15 minutes to the pound**.
3. Season with salt and pepper **half an hour before** it is done.
4. For gravy, pour the grease off the pot, add a little water and salt, and rub flour into it gradually
   with a spoon.

([Kephart, p. 301](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=301))
**In an oven** the same thing takes longer and comes out better: 3 lb from the round or rump, seasoned,
floured and browned all over in pork fat, set on a trivet in a deep pan, surrounded with diced carrot,
turnip, onion and celery and 3 cups of boiling water, covered closely and baked **4 hours in a very slow
oven**, basted every half-hour and turned after two hours, the liquid kept below boiling throughout
([Fannie Farmer, p. 217](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=217)). When you
turn meat, do not pierce it with a fork — the juices run out (same page).

**Pot roast in a hay box** *(sear on the fire, then the box · overnight)*: sear the meat in hot fat,
put it in the cooker kettle, cover with boiling water, boil gently **30 minutes** (20 is enough for a
3-lb roast), and put it in the box overnight. Reheat in the morning, season, and return it to the box
until noon. Thicken some of the liquor for gravy
([FB 771, p. 15](lib:usda-homemade-fireless-cookers-fb771-1919#page=15)).

**Pit baking (the bean hole)** *(a pit of coals · overnight)*:

1. Dig a hole about 18 × 18 × 12 inches. Lay kindling in it and build a "cob house" of split hardwood
   over it — sticks crossed in layers, not touching, two feet high — and light it so it all burns to
   coals together.
2. Cut the meat or bird in pieces, season it, add a chunk of fat pork the size of your fist, put it in the
   kettle with water to cover, and put the lid on.
3. Rake the coals out of the hole, set the kettle in, shovel the coals around and over it, cover it with
   a few inches of earth, and leave it overnight. (Bark over the top if it rains.)
4. Practice two or three times before you trust a meal to it.

([Kephart, p. 301](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=301))

**An old hen, an old rooster, an old anything** *(a hay box overnight, or a covered pot on the stove
until the meat leaves the bone)*:
**brown fricassee** will reduce the toughest old fowl on the place to meat that falls off the bone. Joint
the bird, roll the pieces in flour and brown them in fat, packing them into the kettle as they brown;
make a gravy in the frying pan and add it with boiling water to cover; salt and pepper; **boil 20
minutes**; hay box overnight; reheat and return to the box until noon
([FB 771, p. 15](lib:usda-homemade-fireless-cookers-fb771-1919#page=15)). To **roast** a bird you fear
is tough, boil it 15–20 minutes, put it boiling hot into the box for **10 hours**, then drain, wipe dry,
stuff if you want, and roast it only long enough to brown (same page).
**Boiled fowl** without a box: truss a 4-lb fowl, tie it in a cloth so the scum does not mark the skin,
set it on a trivet half surrounded with boiling water, cover, and cook slowly until tender, salting in
the last hour ([Fannie Farmer, p. 255](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=255)).
A young bird can simply be **broiled**: split down the back, seasoned, in a greased broiler, **20 minutes
over a clear fire**, flesh side to the fire most of the time (same page).

**Game** ([NDSU, p. 5](lib:ndsu-wild-side-of-the-menu-1-care-and-cookery#page=5)): game is leaner and
stronger-flavored than farm meat, and the strong flavor sits in the **fat** — trim it off. Then put fat
back in another form (butter, lard, cream, bacon over the top) or it cooks dry. **Do not overcook it.**
Tell a young bird from an old one at the joints: stiff joints and brittle bones mean an old bird, which
must be braised or stewed; flexible joints and soft bones mean it can be fried. A plucked bird roasts
without drying out because the fat under the skin melts into it; a skinned bird needs bacon over it, or a
slice of bread dipped in egg and milk laid on top. Game takes the place of beef in any chili, soup or stew
you already make.
- **Roast duck** *(a 325 °F oven · 1–1½ hours)*: fill the cavity with quartered apples, skewer it shut,
  tie the legs and wings close, rub it with onion, salt and pepper, and roast it **back up, uncovered**,
  basting every 10 minutes ([NDSU, p. 9](lib:ndsu-wild-side-of-the-menu-1-care-and-cookery#page=9)).
- **Any bird in milk** *(stove top or a 350 °F oven · 1–1½ hours)*: dredge the pieces in seasoned flour,
  brown them in fat, add about 2 inches of milk or cream, and simmer or bake until done — **at least
  165 °F inside** (same page).
- **Rabbit** *(stove top · about 1 hour after browning)*: dredge in flour, brown well in fat with a
  little bacon, cover, and cook over moderate heat until tender, adding a few spoonfuls of liquid to make
  steam ([NDSU, p. 8](lib:ndsu-wild-side-of-the-menu-1-care-and-cookery#page=8)).

**Fresh sausage, from trimmings that would otherwise be dog food** — **⅓ fat to ⅔ lean**. A test batch:
**4 lb trimmings, 5 tsp salt, 4 tsp ground sage, 2 tsp ground pepper, 1 tsp sugar**, and if you like
½ tsp ground cloves or 1 tsp nutmeg. Mix the seasoning, spread it over the trimmings, and grind it all.
For bulk sausage that slices and fries without crumbling, work a scant half cup of cold water into each
4 lb of ground seasoned meat until it is sticky and dough-like, pack it tightly into small pans, and chill
before slicing ([FB 2138, p. 45](lib:pork-slaughtering-cutting-preserving-on-the-farm-usda-fb2138#page=45)).
Scrapple and head cheese — the dishes that use the rest of the head and trimmings — are in the
[Pigs guide](guide:PIGS-GUIDE).

> ⚠️ **Hang game at least two days before you cook it**, or it will be tough and tasteless; venison eaten
> before it has cooled right through causes diarrhoea
> ([Kephart, p. 295](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=295)).
> **Pork, bear and cougar must be cooked through** — see the [Pigs guide](guide:PIGS-GUIDE) and **Jerky**,
> above, for trichinosis. Drying and smoking are **not** cooking
> ([PNW 632, p. 8](lib:pnw632-making-jerky-at-home-safely#page=8)).

📚 **Go deeper:** [Kephart, *Camping and Woodcraft*, p. 295](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=295) — frying, broiling, roasting, braising and pit baking; [NDSU *Wild Side of the Menu 1*](lib:ndsu-wild-side-of-the-menu-1-care-and-cookery#page=5) — game cookery and kitchen safety; [Fannie Farmer 1896, p. 217](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=217) — braised beef, beef à la mode and stews; [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — getting the meat home in good shape.

## 🐟 Fish, eggs, milk and cheese
<!-- fold: Fish over coals, boiled fish, eggs and omelets, a greens-and-egg bake, baked custard and cheese dishes -->

**Fish over coals** *(a moderate bed of coals · 10–20 minutes)*: rub the broiler with fat bacon so the
fish does not stick. For a large fish, take the head off and split it **down the back**, not the belly,
and lay strips of bacon or pork across it; broil over a **moderate** bed of coals so the inside cooks
through without drying. Small fish are better cooked fast over hot coals, heads on. When it is done,
salt and pepper it, spread butter, and hold it over the fire again until the butter melts.
With no broiler, push a sharpened green stick through the mouth into the body and keep turning it over
the coals, basting with drippings from a bit of bacon held on another stick above it.
([Kephart, p. 326](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=326))
**Frying fish:** wipe it dry or it soaks up grease, have the fat **very hot**, and put the pieces in one
at a time so the heat does not drop (same page).
**Boiled fish, for a big one** *(stove top · until a fork goes in easily)*: ¾-fill a pot with water, add
two large potatoes and about ½ cup of salt per 2-gallon pot, bring it to a boil, put the fish in, and cook
until a fork goes through the flesh easily — 2 lb of fish for every 2 potatoes
([NDSU, p. 10](lib:ndsu-wild-side-of-the-menu-1-care-and-cookery#page=10)).

**Eggs** ([Fannie Farmer, pp. 131, 134, 136](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=134)):
allow **one egg per person and one tablespoon of liquid per egg**.
- **Scrambled** *(a hot pan · 3–5 minutes)*: 5 eggs, ½ cup milk, 2 Tbsp butter, salt, pepper. Beat the
  eggs just enough to mix, add the milk and seasoning, melt the butter in a hot pan, pour it in, and cook
  only to a creamy consistency.
- **Omelet** *(a hot pan · 3–5 minutes)*: 4 eggs, 4 Tbsp milk, 2 Tbsp butter, salt, pepper, cooked the
  same way and folded over.

**A greens, bread and egg bake** *(a 350 °F oven · 40–45 minutes)* — the dish that turns a handful of
anything green into supper: 3 slices of bread cubed, 4 eggs, 1⅓ cups milk, ½ tsp each salt, pepper and
ground mustard, 1 cup cooked chopped greens (blanched nettles, chard, beet tops), ¼ cup onion or chives,
and whatever meat, fish or cheese you have.

1. Whisk the eggs, milk and seasonings. Stir in the greens and onion.
2. Spread the bread cubes in a greased 9-inch pan and scatter the meat or fish among them.
3. Pour the egg mixture over slowly and even out the greens. Sprinkle cheese on top.
4. Bake uncovered on a low rack **40–45 minutes**, until a knife put in near the middle comes out clean.
   It puffs up as it cooks. Good hot or cold; chill the leftovers within two hours.

([OSU EM 9373, p. 5](lib:osu-wild-edibles-stinging-nettle-em-9373#page=5))

**Baked custard** *(a slow oven, the dish standing in a pan of hot water · until a knife comes out
clean)* — 4 cups scalded milk, 4 to 6 eggs, ⅓ cup sugar or honey, ¼ tsp salt, a grating of nutmeg.
Beat the eggs slightly, add sugar and salt, pour the scalded milk on slowly, strain into a buttered
dish, set it in a pan of hot water, and bake in a **slow** oven. **Keep the water around the dish below
boiling** — eggs and milk together must be cooked at a low temperature, or the custard turns to whey
([Fannie Farmer, pp. 391–392](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=391)).

**Cheese, when there is cheese** ([FB 1451, pp. 12, 14](lib:making-and-using-cottage-cheese-in-the-home-usda-fb-1451-1927#page=12)):
fresh curd is mild, so it takes flavor from whatever you put with it — horseradish, onion juice,
parsley, chopped celery, ground sage; or honey, jam and dried fruit on the sweet side. A **cheese roll**
is curd mixed with cold cooked rice or fresh bread crumbs and those seasonings, packed into a buttered
dish, chilled, turned out and sliced; scraps of cooked meat or fish go in to stretch it further. Dry curd
needs seasoning well. Grated hard cheese stirred into cornmeal mush makes a dish that needs no butter
(above). Milk, butter, cheese-making, ricotta and whey are the
[Milk, Butter & Cheese guide](guide:DAIRY-GUIDE).

📚 **Go deeper:** [Kephart, p. 326](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=326) — fish over a fire, every way; [Fannie Farmer 1896, p. 131](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=131) — eggs, omelets and custards; [USDA FB 1451 *Cottage Cheese*, p. 12](lib:making-and-using-cottage-cheese-in-the-home-usda-fb-1451-1927#page=12) — making it and cooking with it.

## 🥕 Vegetables, greens and roots
<!-- fold: How long each thing needs, winter squash, greens, nettles, the boiled dinner and the hay-box rule -->

Garden and cellar vegetables need longer than most people think, and old ones longer again.

| Vegetable | Cooked on | How long |
|---|---|---|
| Beets, whole | boiling water | **1 to 4 hours** — and old beets never go tender, however long you cook them |
| Shell (fresh) beans | boiling water, barely enough to cover | **1 to 1½ hours**, salt in the last half-hour |
| String beans | boiling water | **1 to 3 hours**, salt in the last half-hour |
| Winter squash and pumpkin | a strainer over boiling water | **30 minutes**, then mash with fat, salt and pepper |
| Carrots, in dice | boiling salted water | **30 minutes** young, **45** old |
| Greens — beet tops, dandelion, turnip tops | a little boiling salted water | **1 hour**, then butter, salt, pepper and a splash of vinegar |
| Nettles | a rolling boil | **1½ to 2 minutes**, then cold water; that kills the sting |
| Anything, in a hay box | boil first, then the box | **2½ times** the stove-top time |

Sources: [Fannie Farmer, pp. 292, 299, 306](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=292);
[OSU EM 9373, p. 4](lib:osu-wild-edibles-stinging-nettle-em-9373#page=4);
[*Household Discoveries*, p. 891](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=891);
[FB 771, p. 15](lib:usda-homemade-fireless-cookers-fb771-1919#page=15).

**Nettles, start to finish** *(a big pot of boiling water · 2 minutes, plus 2 in cold water)*: wear long
sleeves and rubber gloves to pick and handle them. Bring a gallon of water and a pinch of salt to a
rolling boil, put the leaves in, **boil 1½–2 minutes**, lift them out with tongs into cold water for
**2 minutes**, drain, and squeeze the water out. From there they are a cooked green: in the bake above, in
soup, in a pan with fat and onion, or chopped fine with nuts, garlic, oil and hard cheese as a sauce for
noodles — which keeps only **4 days** in a cold place, or frozen, because greens in oil can grow
botulism. Drying them: **95–115 °F until crisp**, then airtight in the dark; best used within 6 months.
([OSU EM 9373, pp. 3–4](lib:osu-wild-edibles-stinging-nettle-em-9373#page=3))

**A boiled dinner in one kettle** *(stove top and a hay box · overnight plus the morning)*: cook a piece
of corned beef or salt pork in the box overnight; in the morning add every vegetable you have — the more
kinds the better — boil 10–15 minutes and return it to the box; put the potatoes in only **an hour and a
quarter** before the meal, and bring it back to a boil when they go in. If the salt meat was parboiled
first, the liquid makes a good soup
([FB 771, p. 15](lib:usda-homemade-fireless-cookers-fb771-1919#page=15)).

**From the cellar in late winter:** dried squash and dried corn go into soups and the winter dish under
**Beans**, above. Sprouting potatoes and soft roots are still food — rub the sprouts off and **cut away
every green part, which is toxic** ([why](wiki:Solanine)) — then boil them. Keeping it all this long is the [Root Cellar guide](guide:ROOT-CELLAR-GUIDE); mushrooms, how
to cook and dry them, are in the [Mushroom guide](guide:MUSHROOM-GUIDE).

📚 **Go deeper:** [Fannie Farmer 1896, p. 292](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=292) — every common vegetable and how long it takes; [OSU *Wild Edibles: Stinging Nettle*](lib:osu-wild-edibles-stinging-nettle-em-9373#page=1) — gathering, blanching, freezing, drying and four recipes; [*Household Discoveries*, p. 891](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=891) — plain vegetable cookery.

## 🍎 Fruit, nuts and sweet dishes
<!-- fold: Scalloped apples, steamed apple pudding, Indian and rice puddings, bread pudding, elderberries -->

Apples, pears and plums keep in a cellar or dried; grain, milk, eggs, honey and syrup make them into
puddings. A sweet dish at the end of a hard week does more good than its calories.

**Scalloped apples** *(a moderate oven · 40 minutes)* — a small stale loaf, ½ cup butter or lard, 1 quart
sliced apples, ½ cup sugar or honey, ½ tsp grated nutmeg, the grated rind and juice of half a lemon if
you have one.

1. Crumb the soft part of the loaf. Melt the fat and stir it lightly through the crumbs with a fork.
2. Cover the bottom of a greased dish with crumbs, spread half the apples over, and sprinkle with half
   the sugar and spice. Repeat, and finish with crumbs.
3. Bake **40 minutes** in a moderate oven, covered at first so the crumbs do not brown too fast.

([Fannie Farmer, p. 374](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=374))

**Steamed apple pudding — no oven needed** *(a covered tin or a five-pound lard pail in a kettle of
boiling water · 1 hour 20 minutes)* — 2 cups flour, 4 tsp baking powder, ¼ tsp salt, 2 Tbsp butter or
lard, ¾ cup milk, 4 apples cut in eighths, 1 Tbsp sugar mixed with ¼ tsp each salt and nutmeg.

1. Sift the dry things, rub in the fat with your fingertips, and add the milk gradually, mixing with a
   knife.
2. Pat and roll the dough out. Put the apples on the middle, sprinkle the sugar and spice over them, and
   bring the dough round them.
3. Lift it carefully into a buttered tin or a lard pail, cover it closely, and **steam 1 hour 20
   minutes**.
4. Quicker: cook twice as many apples with sugar until soft in a kettle on the stove, cover them with the
   dough rolled to fit, put the lid on tight, and **steam 15 minutes**. Turn it out and the apples are on
   top.

([Fannie Farmer, p. 378](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=378))
The same dough and method takes berries — a cup of berries rolled in flour with a cup of milk (same page).

**Indian pudding** *(a slow oven · 2 hours, after 20 minutes on the stove)* — 5 cups scalded milk,
⅓ cup cornmeal, ½ cup molasses, 1 tsp salt, 1 tsp ginger. Pour the milk slowly on the meal, cook it in a
double boiler **20 minutes**, add the molasses, salt and ginger, pour it into a greased dish and bake
**2 hours in a slow oven**. Serve with cream. If it is baked too fast it will not whey properly
([Fannie Farmer, p. 372](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=372)).

**Rice pudding, and poor man's pudding** *(a very slow oven · 3 hours)* — 4 cups milk, ½ cup rice,
⅓ cup sugar, ¼ tsp salt, grated lemon rind. Wash the rice, mix everything, pour it into a greased dish,
and bake **3 hours in a very slow oven**, stirring three times in the first hour so the rice does not
settle. **Poor man's pudding** is the same with ⅓ cup molasses in place of the sugar, ¼ tsp cinnamon, and
a tablespoon of butter stirred in at the last stir
([Fannie Farmer, p. 372](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=372)).

**Bread pudding, for stale bread** *(a slow oven · 1 hour)* — 2 cups stale bread crumbs, 1 quart scalded
milk, ½ cup sugar or honey, ¼ cup melted butter, 2 eggs, ¼ tsp salt, a little spice. Soak the crumbs in
the milk and let it cool; add the rest with the eggs beaten slightly; bake **1 hour** in a greased dish in
a slow oven. Leave the outside crusts out of pudding crumbs
([Fannie Farmer, p. 374](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=374)).

**Nuts:** hazelnuts and sugar pine nuts need no treatment (**Acorn flour**, above). Pounded parched nut
meal mixed with parched corn meal makes a pottage, and nut milk was used with corn the way we use dairy
milk ([Parker, p. 117](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=117)).

> ⚠️ **Elderberries are never eaten raw.** Raw berries and raw juice release cyanide as they are digested:
> nausea, vomiting, cramps and weakness, and people have been hospitalised. **Cooking removes the risk.**
> Berries that are dried or frozen raw must still be cooked before anyone eats them.
> ([OSU EM 9446, p. 4](lib:osu-play-it-safe-when-preserving-elderberries-em-9446#page=4))
> Our blue elderberry is high in acid and can be canned as juice, syrup or jam with ordinary high-acid
> recipes; the eastern kinds cannot ([p. 2](lib:osu-play-it-safe-when-preserving-elderberries-em-9446#page=2)).
> Canning times and the jam rules are in the [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE).

📚 **Go deeper:** [Fannie Farmer 1896, p. 372](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=372) — the hot-pudding chapter; [OSU *Play It Safe When Preserving Elderberries*](lib:osu-play-it-safe-when-preserving-elderberries-em-9446#page=1) — which elderberries are safe in which recipe; [OSU *Picking and Storing Apples and Pears*](lib:osu-picking-and-storing-apples-and-pears-fs-147#page=1) — when to pick and how to keep them.

## 🧂 Making plain food good
<!-- fold: White sauce, pan gravy, tomato and savory sauces, a basting mop, salting rules and flavor from scraps -->

The difference between a dull winter and a bearable one is sauce, salt and a change of flavor. The same
beans, meal and roots can be a different meal every day.

**White sauce, the one sauce to know** *(stove top · 5 minutes)* — per cup of milk: 2 Tbsp butter or
lard, ¼ tsp salt, pepper, and flour according to how thick you want it — **1½ Tbsp thin** (for soups and
creamed dishes), **2 Tbsp medium**, **3 Tbsp thick** (to bind cakes and croquettes).

1. Melt the fat in a pan until it bubbles.
2. Stir the flour and seasonings in and cook until thoroughly blended.
3. Pour the milk on gradually, about a third at a time, stirring, then beat until smooth and glossy.

([Fannie Farmer, p. 273](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=273))
It carries any cooked thing: hominy, greens, fish, eggs, scraps of meat, dried mushrooms.

**Pan gravy** *(the pot you cooked in · 5 minutes)*: pour the grease off, add a little water and salt to
what is left, and rub flour in gradually with a spoon
([Kephart, p. 301](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=301)). On bread, mush or
potatoes this is a meal in itself.

**Tomato sauce and savory sauce** (above, under **Porridge**) go on anything, not just polenta: 2 Tbsp
fat, 2 Tbsp flour and a cup of strained tomato for the first; salt pork or bacon crisped with onion and
pepper, then a cup of tomato cooked down, for the second
([FB 1236, pp. 11–12](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=11)).

**A basting mop for anything roasting over a fire** *(simmered, then brushed on)* — 1 pint vinegar, half
a can of tomatoes (about a cupful), 2 tsp red pepper (chopped pods are better), 1 tsp black pepper, 1 tsp salt, 2 Tbsp
butter, simmered together until it comes together. Tie a clean rag on a stick and keep the meat basted
the whole time it is on the fire
([Kephart, p. 300](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=300)).

**Salt, and when to add it:**
- **Do not salt meat that is broiling** until it is done; if you must, glaze the salt onto the surface
  first in the flame so it cannot draw the juice out
  ([Kephart, pp. 297, 300](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=297)).
- **Beans, greens and tough vegetables:** salt in the **last half-hour**
  ([Fannie Farmer, p. 292](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=292)).
- **Sausage and plain meat:** per 4 lb, **5 tsp salt, 4 tsp sage, 2 tsp pepper, 1 tsp sugar** is a
  seasoning that works on anything ground, not only pork
  ([FB 2138, p. 45](lib:pork-slaughtering-cutting-preserving-on-the-farm-usda-fb2138#page=45)).

**Flavor out of nothing much:**
- **Dried mushrooms** grate or powder easily and go into soups, sauces and fritters after soaking; a
  species with good body but little flavor is cooked together with one of higher flavor
  ([McIlvaine, p. 814](lib:mcilvaine-one-thousand-american-fungi#page=814)).
- **Curd and sour milk** take onion juice, horseradish, parsley, celery and sage
  ([FB 1451, p. 12](lib:making-and-using-cottage-cheese-in-the-home-usda-fb-1451-1927#page=12)).
- **Vinegar** on boiled greens, and on sliced boiled beets as a quick pickle
  ([Fannie Farmer, pp. 292, 299](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=292)).
  Homemade vinegar is fine for cooking — just never for canned pickles (**Salt, sweeteners and fat**, above).
- **Honey** replaces sugar cup for cup in baking
  ([FB 1136, p. 23](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=23)).
- **Onions, garlic, mustard and dried herbs** are the cheapest thing a garden grows for a kitchen, and
  dry easily (**Drying food** in the [Root Cellar guide](guide:ROOT-CELLAR-GUIDE)) *(rule of thumb)*.

📚 **Go deeper:** [Fannie Farmer 1896, p. 273](lib:boston-cooking-school-cook-book-fannie-farmer-1896#page=273) — the sauce chapter; [*Household Discoveries*, p. 851](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=851) — a whole chapter on making left-overs into something people want to eat.

## 🥣 Flour and fat and nothing else
<!-- fold: What to make when the stores are down to flour, grease, salt and water -->

Men who carried nothing they could do without lived on four things: **flour, bacon, baking powder and
salt** ([Kephart, p. 356](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=356)). Here is what
those four, or fewer, will make.

- **Pan bread.** Flour, baking powder, salt, cold grease and water — the bannock above. With no baking
  powder it is flat bread: flour, water, a little salt, rolled thin, cooked on a dry hot pan 30–60 seconds
  a side (**Staples**).
- **Ash cakes.** Stiff dough — flour or meal and water — in balls the size of hen's eggs, rolled in dry
  flour, laid in hot ashes and covered over
  ([Kephart, p. 356](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=356)).
- **Dumplings in salted water.** Flour, a little fat, water; dropped in boiling water and boiled 12–30
  minutes. With cornmeal, moisten with boiling water, shape cakes in your hand, and boil half an hour
  ([Parker, p. 115](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=115)).
- **Gravy on bread.** Fat, flour, water, salt — the pan gravy above. With milk instead of water it is
  better again.
- **Fried mush.** Meal, water, salt, fat: cook a thin mush, let it set, slice it and fry it
  ([FB 1236, p. 12](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=12)).
- **Hardtack.** 3 parts flour to 1 part water and nothing else, baked hard and dried (**Staples**). It
  keeps for years; to eat it, toast it until crisp, or soak it in something hot and butter or salt it
  ([Kephart, p. 196](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=196)).
- **Thin gruel** of meal or flour stirred into boiling salted water is what a sick person or a small child
  can keep down when nothing else will; so is barley water (above). Feeding someone who has gone hungry
  for a long time has rules of its own — see [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE).

A steady diet of baking-powder bread is hard on people; that is what sourdough and saved dough are for
([Kephart, p. 196](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=196), and **Leavening**, above).

📚 **Go deeper:** [Kephart, *Camping and Woodcraft*, p. 356](lib:kephart-camping-and-woodcraft-vol-1-camping-1916#page=356) — corn pone, dodgers, ash cake and johnny-cake; [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE) — rationing, nutrition and hunger diseases.

---

*Old recipes in these books are fine for **methods**; for food safety (canning, curing,
storing) follow the modern USDA guides in `Gardening-Food\`.*

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Grain: threshing, grinding, pests**
- Threshing box for small lots — [🖼️ McCormack, p. 4](lib:seed-processing-and-storage-principles-and-practices-mccormack-2010#page=4); [Threshing](wiki:Threshing); [Winnowing](wiki:Winnowing)
- Hand grain mill and metate — [🖼️ FAO, p. 17](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=17); [Quern-stone](wiki:Quern-stone)
- Homemade pipe-and-can grinder — [🖼️ Kearny, p. 83](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=83)
- Stone mill, how it is built — [🖼️ FAO, p. 72](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=72)
- Weevils and moths in stored grain — [🖼️ FAO, p. 78](lib:maize-post-harvest-operations-and-nixtamalization-fao#page=78); [Rice weevil](wiki:Rice_weevil)

**Acorns and nuts**
- Tanoak and its acorns — [🖼️ NRCS, p. 1](lib:tanoak-plant-guide-usda-nrcs#page=1); [Notholithocarpus](wiki:Notholithocarpus); [Acorn](wiki:Acorn)
- Oaks and acorns — [🖼️ Army survival manual, p. 449](lib:fm-3-05-70-survival-2002#page=449); [Quercus kelloggii](wiki:Quercus_kelloggii); [Quercus garryana](wiki:Quercus_garryana)
- Hazelnut — [🖼️ NRCS, p. 1](lib:beaked-and-california-hazelnut#page=1); [Corylus cornuta](wiki:Corylus_cornuta)
- Bay nut inside its fruit — [🖼️ UCCE, p. 3](lib:foods-from-the-tanoak-forest-acorn-processing-ucce-2013#page=3); [Umbellularia](wiki:Umbellularia)
- Sugar pine — [Pinus lambertiana](wiki:Pinus_lambertiana)

**Camas, cattail and their deadly look-alikes**
- Camas in bloom — [🖼️ NRCS, p. 1](lib:great-camas-plant-guide-usda-nrcs#page=1); [Camassia quamash](wiki:Camassia_quamash); [Camassia leichtlinii](wiki:Camassia_leichtlinii)
- Death camas: leaves, flowers, bulbs — [🖼️ PNW 104, p. 2](lib:pnw-meadow-deathcamas-in-the-pacific-northwest-pnw-104#page=2); [🖼️ Army, p. 507](lib:fm-3-05-70-survival-2002#page=507); [🖼️ Air Force, p. 347](lib:afh-10-644#page=347); [Toxicoscordion venenosum](wiki:Toxicoscordion_venenosum)
- Pit roasting — [Earth oven](wiki:Earth_oven)
- Cattail — [🖼️ Army, p. 416](lib:fm-3-05-70-survival-2002#page=416); [🖼️ NRCS photo](lib:broadleaf-cattail-plant-guide-usda-nrcs#page=1); [🖼️ Air Force, p. 362](lib:afh-10-644#page=362); [Typha latifolia](wiki:Typha_latifolia)
- Western water hemlock: chambered root, look-alikes — [🖼️ PNW 109, p. 1](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=1); [🖼️ pp. 3–4](lib:pnw-western-waterhemlock-in-the-pacific-northwest-pnw-109#page=3); [🖼️ Army, p. 519](lib:fm-3-05-70-survival-2002#page=519); [Cicuta douglasii](wiki:Cicuta_douglasii)

**Corn**
- Hominy block and stone mortar — [🖼️ USDA FB 1236, p. 9](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=9); [🖼️ Parker, p. 68](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=68); [🖼️ pounding corn, Parker, p. 107](lib:iroquois-uses-of-maize-and-other-food-plants-parker-1910#page=107)
- Inside a corn kernel (skin, germ, starch) — [🖼️ USDA FB 1236, p. 6](lib:corn-and-its-uses-as-food-hominy-and-cornbread-usda-fb-1236-1924#page=6)
- Nixtamal, masa and tortillas — [Nixtamalization](wiki:Nixtamalization); [Masa](wiki:Masa); [Corn tortilla](wiki:Corn_tortilla); [Hominy](wiki:Hominy)

**Syrup, oil, lard and butter**
- Tapping a bigleaf maple — [🖼️ OSU, p. 4](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=4); [🖼️ spoiled sap and dirty spiles, p. 6](lib:making-bigleaf-maple-syrup-osu-em-9163-2025#page=6); [Acer macrophyllum](wiki:Acer_macrophyllum)
- Hand oil presses — [🖼️ Practical Action, p. 3](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=3)
- Rendered lard and cracklings — [Lard](wiki:Lard); [Cracklings](wiki:Cracklings)
- Churning, washing and working butter — [🖼️ USDA FB 876, p. 10](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=10); [🖼️ p. 13](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13); [🖼️ p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16); [🖼️ small churn, Practical Action, p. 3](lib:butter-and-ghee-practical-action-2008#page=3); [Butter churn](wiki:Butter_churn)

**Jerky, bread and slow cooking**
- Oven-heating jerky — [🖼️ PNW 632, p. 14](lib:pnw632-making-jerky-at-home-safely#page=14); [Jerky](wiki:Jerky)
- What good rolls look like — [🖼️ USDA FB 1136, p. 17](lib:baking-in-the-home-quick-breads-and-biscuits-usda-fb-1136-1921#page=17); [Kneading](wiki:Kneading)
- Dutch-oven bread, flatbread, hardtack — [Dutch oven](wiki:Dutch_oven); [Flatbread](wiki:Flatbread); [Hardtack](wiki:Hardtack)
- Hay-box cooker — [🖼️ USDA FB 771, pp. 8–9](lib:usda-homemade-fireless-cookers-fb771-1919#page=8); [🖼️ Practical Action, p. 2](lib:practical-action-fireless-cookers-haybox-technical-brief#page=2); [Haybox](wiki:Haybox)

## 🔗 Related guides

- [Light Without the Grid](guide:LIGHTING-GUIDE) — tallow candles and lard-oil lamps
- [Pigs](guide:PIGS-GUIDE) — lard, and pigs that eat the scraps; [Cattle](guide:CATTLE-GUIDE) and [Sheep](guide:SHEEP-GUIDE) — tallow
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — frost dates, soils and the deadly wild-plant look-alikes.
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — hay-box cooker, soap from fat and ashes, food containers, pests.
- [Root Cellar Guide](guide:ROOT-CELLAR-GUIDE) — root cellars, drying, curing, fermenting and keeping eggs.
- [Seed Bank Guide](guide:SEED-BANK-GUIDE) — planting calendar, saving grain and bean seed, grafting.
- [Mushroom Guide](guide:MUSHROOM-GUIDE) — safe local edibles, drying and growing mushrooms.
- [Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE) — keeping food and water clean after fallout.
- [Medical — Read Me First](guide:Medical-READ-ME-FIRST) — food poisoning and where the medical books are.
- [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE) — acorns, camas, salmon, cordage and baskets, houses, and tending the land with fire, the way people here lived for thousands of years.
