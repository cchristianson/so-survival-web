# 🧀 Milk, Butter & Cheese Without a Fridge

How to milk cleanly, keep milk safe and cool with no power, and turn it into butter, buttermilk, ghee,
yogurt, kefir and cheese that keep for weeks or months, from goats, cows or sheep. The animal itself
(breeds, feed, kidding, udder health) is in the [Goats guide](guide:GOATS-GUIDE). The books are in `Animals\Dairy-Cheese`,
with the old USDA butter and cheese bulletins in `Homestead-Skills\Food-Crafts-Tools`, milk cooling in
`Food-Storage\Cooling-Without-Power`, milk-borne disease in `Animals\Veterinary`, and the family cow in
`Animals\Cattle-Horses-Pigs`. Where this guide works out a number it says *(arithmetic)*; check it with the
[Unit Converter](guide:UNIT-CONVERTER) or the [Practical Math guide](guide:PRACTICAL-MATH-GUIDE).

> ### The short version
> - **Raw milk can carry brucellosis, tuberculosis and Listeria.** Pasteurize: **145 °F for 30 minutes or
>   161 °F for 15 seconds** ([UMN, p. 1](lib:pasteurization-of-milk-at-home#page=1)). No thermometer? Bring
>   it **just to a boil**. Children, pregnant women, the old and the sick never get raw milk or soft
>   raw-milk cheese ([*Zoonoses*, pp. 91–92](lib:zoonoses-diseases-animals-give-people-cvm#page=91)).
> - **Cool milk below 50 °F within an hour.** Above that, bacteria multiply very fast
>   ([*Raising Healthy Cattle*, p. 13](lib:raising-healthy-cattle-cvm#page=13)). Spring water is often 65 °F
>   ([USDA FB 976, p. 15](lib:cooling-milk-and-cream-on-the-farm#page=15)). Milk you can't cool becomes
>   yogurt, cheese or ghee **the same day** *(rule of thumb)*.
> - **Scald every pail, cloth and churn.** Clean milk kept sweet two to three times as long as ordinary milk in
>   the USDA's tests ([FB 976, p. 5](lib:cooling-milk-and-cream-on-the-farm#page=5)).
> - **Pasteurized milk won't sour cleanly by itself.** Add a spoonful of last batch's yogurt, clabber or
>   buttermilk as a starter ([ILCA, p. 34](lib:rural-dairy-technology#page=34); [USDA FB 1451, p. 7](lib:making-and-using-cottage-cheese#page=7)).
> - **What keeps:** ghee **over 12 months** ([Practical Action, p. 4](lib:butter-and-ghee-practical-action#page=4));
>   butter salted to 3% **up to 4 months** cool and dark ([ILCA, p. 49](lib:rural-dairy-technology#page=49));
>   hard cheese and feta in brine for months.
> - **Make hard cheese in the cool months; age it at 40–60 °F**, turn it daily, and put cheesecloth over
>   cellar windows against the skipper fly ([USDA FB 1191, p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)).
> - **Rennet** comes from the stomach of a kid, lamb or calf that has had only milk. **Never** curdle milk with
>   milkweed sap: milkweed poisons livestock ([AIB 415, p. 71](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=71)).

---

## 🐐 Goat, cow or sheep milk

| | Goat | Cow | Sheep |
|---|---|---|---|
| Butterfat | 3.5–4.2% | 3.6% (Holstein) to 5.2% (Jersey) | about 7.9% |
| Cream | Rises very slowly, and only partly | Rises well in 24–36 hours | *(no book data)* |
| Butter | Good but pure white, like lard | Yellowest on spring pasture | Rich *(rule of thumb)* |
| Daily milk | About **1½ quarts** averaged over a 10-month lactation | **10–20 quarts** for a family cow | *(no book data)* |

*Sources: fat, [FB 920, p. 6](lib:milk-goats-usda-farmers-bulletin-920#page=6), [Practical Action, p. 3](lib:butter-and-ghee-practical-action#page=3);
goat cream and butter, [FB 920, p. 7](lib:milk-goats-usda-farmers-bulletin-920#page=7); cow cream, [ILCA, p. 38](lib:rural-dairy-technology#page=38);
butter color, [FB 876, p. 13](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13); a "fair milker" goat gives 1,000 lb in 10 months
([FB 920, p. 5](lib:milk-goats-usda-farmers-bulletin-920#page=5); *arithmetic*); cow, [*Keeping One Cow*, p. 19](lib:keeping-one-cow#page=19).*

**Goat cheese is better with a quarter to a third cow milk** mixed in ([FB 920, p. 7](lib:milk-goats-usda-farmers-bulletin-920#page=7)).
Two does bred a few months apart keep milk coming all year *(rule of thumb)*; see the [Goats guide](guide:GOATS-GUIDE).

## 🧼 Clean milking

1. **Clean, dry bedding.** A goat lying on wet straw lets bacteria in through the teat opening. **Clip the
   udder hair** so dirt doesn't fall in ([Lincoln, pp. 1–2](lib:dairy-goats-milking-the-sanitary-way-lincoln-univ#page=1)).
2. **No dust at milking time.** Feed, brush and sweep after milking, or long enough before for the dust to
   settle; sprinkle the floor ([*Book of Cheese*, p. 48](lib:the-book-of-cheese#page=48)).
3. **Wipe the udder and flank with a damp cloth**, a separate cloth for each animal, so mastitis germs don't
   travel ([*Raising Healthy Cattle*, p. 82](lib:raising-healthy-cattle-cvm#page=82); [*Book of Cheese*, p. 47](lib:the-book-of-cheese#page=47)).
   Never wash teats in the milk pail ([*Keeping One Cow*, p. 17](lib:keeping-one-cow#page=17)).
4. **Strip the first squirts into a strip cup and look for clots every milking.** Clots mean
   [mastitis](wiki:Mastitis): discard that milk and milk her last ([Lincoln, p. 2](lib:dairy-goats-milking-the-sanitary-way-lincoln-univ#page=2)).
5. **Dip the teats** in iodine, wipe them dry, and milk with dry hands, never wet with milk
   ([*Book of Cheese*, p. 48](lib:the-book-of-cheese#page=48)). Don't wring the teats; dip again after.
6. **Milk into a small-top pail**; less dirt falls in than into an open one
   ([*Book of Cheese*, p. 49](lib:the-book-of-cheese#page=49); [🖼️ pails](lib:the-book-of-cheese#page=48)).
7. **Strain at once** through several layers of cheesecloth, or sterilized cotton between two cloths
   ([FB 920, p. 29](lib:milk-goats-usda-farmers-bulletin-920#page=29)), then cool it. Lincoln's target is **38 °F within an
   hour**; kept that cold, raw milk stays fresh 12–14 days ([Lincoln, p. 2](lib:dairy-goats-milking-the-sanitary-way-lincoln-univ#page=2)).
8. **Wash the gear right away:** rinse in cold water, scrub in hot water with washing soda (soap leaves a
   film), then boil 5 minutes or scald, and let it dry by itself; no dish towel
   ([USDA FB 876, p. 6](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=6)). With no
   sanitizer, scald with water at 176 °F or hotter; three small rinses beat one big one
   ([ILCA, p. 74](lib:rural-dairy-technology#page=74)).

**Milk to keep out of the house:** the first **4–5 days after kidding** (colostrum, for the kid)
([FB 920, p. 28](lib:milk-goats-usda-farmers-bulletin-920#page=28)); clotted or bloody milk; and milk
from an animal on antibiotics until the label's withdrawal time is over (see the [Goats guide](guide:GOATS-GUIDE)).

## ☣️ Raw milk dangers: brucellosis, TB and Listeria

| Disease | How it reaches people | Signs in people | Signs in the herd |
|---|---|---|---|
| **[Brucellosis](wiki:Brucellosis)** ("undulant fever") | Raw milk and **soft raw-milk cheese**; birth fluids | Fever that goes away and comes back, sweats, weakness; can cripple for life ([*Zoonoses*, p. 30](lib:zoonoses-diseases-animals-give-people-cvm#page=30)) | **Abortions.** Goats are the classic carrier ([p. 29](lib:zoonoses-diseases-animals-give-people-cvm#page=29)); a cow sheds it in milk up to 2 years ([*Cattle*, p. 117](lib:raising-healthy-cattle-cvm#page=117)) |
| **Bovine TB** ([*M. bovis*](wiki:Mycobacterium_bovis)) | Raw milk; children were the main victims ([*Zoonoses*, p. 23](lib:zoonoses-diseases-animals-give-people-cvm#page=23)) | Swollen, draining neck glands; belly, bone and spine TB | Slow weight loss, long cough, hard lumps in the udder ([*Cattle*, p. 113](lib:raising-healthy-cattle-cvm#page=113)) |
| **[Listeria](wiki:Listeriosis)** | Raw milk, soft cheese | Worst for pregnant women (miscarriage), newborns, the old and the sick ([*Zoonoses*, p. 91](lib:zoonoses-diseases-animals-give-people-cvm#page=91)) | Circling, drooping ear and face in goats and cattle ([p. 92](lib:zoonoses-diseases-animals-give-people-cvm#page=92)) |

- "Raw unpasteurized milk from any species should never be consumed"
  ([*Zoonoses*, p. 92](lib:zoonoses-diseases-animals-give-people-cvm#page=92)). Clean farms reduce germs but
  don't guarantee milk free of them; pasteurizing does ([UMN, p. 2](lib:pasteurization-of-milk-at-home#page=2)).
- **Hard, aged cheese is safer than soft, but not safe:** TB germs lived about **5 months** in a Cheddar
  ([*Book of Cheese*, p. 393](lib:the-book-of-cheese#page=393)). Pasteurize milk for every cheese you can.
  If you must make raw-milk cheese, make it hard and age it at least 60 days *(rule of thumb)*.
- **Young children:** no raw milk. Yogurt resists contamination better and can be spoon-fed
  ([WHO, p. 16](lib:guiding-principles-for-feeding-non-breastfed-children-6-24-months-who-2005#page=16)). Animal
  milk is no food for babies under 6 months: see the [Childbirth & Children guide](guide:CHILDBIRTH-CHILDREN-GUIDE).
- **Plant poisons pass into milk.** [Lupine](wiki:Lupinus) poison in milk can cause birth defects in a pregnant
  woman's baby ([WSU, p. 15](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=15)).
- **Never feed raw milk or whey to pigs**; it is a main way TB spreads ([*Zoonoses*, p. 27](lib:zoonoses-diseases-animals-give-people-cvm#page=27)).
  Brucellosis in people needs weeks of doxycycline ([p. 31](lib:zoonoses-diseases-animals-give-people-cvm#page=31); [Medical](guide:Medical-READ-ME-FIRST)).

### After fallout

5–10% of the radioactive iodine a cow eats goes into her milk; it halves every **8 days**. Keep milking
animals in the barn on hay stored before the fallout. **Don't dump contaminated milk:** make it into butter
or cheese and store it **1–2 months** to let the iodine decay. Save clean or canned milk for babies
([USDA AH 234, p. 22](lib:protection-of-food-and-agriculture-against-nuclear-attack#page=22)). See the
[Nuclear Fallout guide](guide:NUCLEAR-FALLOUT-GUIDE).

## 🔥 Pasteurizing, with or without a thermometer

**With a thermometer** ([UMN, p. 1](lib:pasteurization-of-milk-at-home#page=1)):
1. Use a double boiler, or a pot set in a pan of water; milk heated straight over the fire scorches.
2. Heat to **145 °F and hold 30 minutes**, stirring, **or** to **161 °F for 15 seconds**. If it drops below
   145 °F, start the 30 minutes again *(rule of thumb)*. UMN's own home method has a margin: stir until an
   accurate thermometer reads **165 °F**, then cool at once. Cream needs 150 °F for 30 minutes or 166 °F for 15 seconds.
3. **Cool it at once** in cold running water. Kept refrigerator-cold it lasts 7–10 days; ILCA gives
   pasteurized milk only 2–3 days, after which it **rots instead of souring**
   ([ILCA, p. 34](lib:rural-dairy-technology#page=34)).

**With no thermometer:**
- **Bring it just to a boil**, the moment the foam climbs the pot, stirring, then take it off and cool it
  *(rule of thumb)*. Boiling milk has long been the home protection against milk-borne TB and brucellosis
  ([*Zoonoses*, p. 27](lib:zoonoses-diseases-animals-give-people-cvm#page=27); [*Cattle*, p. 118](lib:raising-healthy-cattle-cvm#page=118)).
- **Don't trust the first steam or bubbles.** In water, steam shows at about 122 °F and the first good
  bubbles at about 131 °F, both below pasteurizing heat
  ([Ciochetti & Metcalf, p. 5](lib:pasteurization-of-naturally-contaminated-water-with-solar-energy#page=5)).
- **A beeswax check:** pure beeswax melts at about 144–147 °F. A pea of it in a small capped jar standing in
  the milk turns fully liquid when the milk is near 145 °F; from then on hold the heat 30 minutes *(rule of thumb)*.
- **Solar box cooker:** on clear days from mid-March to mid-September, gallon jugs of water in an insulated
  solar box reached **149 °F** and stayed above milk-pasteurizing heat for at least an hour
  ([Ciochetti & Metcalf, p. 1](lib:pasteurization-of-naturally-contaminated-water-with-solar-energy#page=1)).
  Milk heats the same way *(rule of thumb)*. See "Solar pasteurizing" in the
  [Water Purification guide](guide:WATER-PURIFICATION-GUIDE).
- **Check a thermometer** in boiling water: at our 1,300 ft it should read about 210 °F *(rule of thumb)*.
  Pasteurizing costs only a little vitamin C and thiamine ([UMN, p. 2](lib:pasteurization-of-milk-at-home#page=2)).

## ❄️ Cooling milk with no power

**Why hurry:** milk leaves the udder a little above **90 °F**. Ordinary milk soured in **12 hours at 100 °F** and clean
milk in 36; at 40 °F they kept about **7 and 16 days** ([FB 976, p. 5](lib:cooling-milk-and-cream-on-the-farm#page=5);
[🖼️ chart](lib:cooling-milk-and-cream-on-the-farm#page=5)). In shade at 61 °F milk is still **82 °F after 3 hours**; in
running water it reaches 61 °F in 1 hour ([ILCA, p. 33](lib:rural-dairy-technology#page=33)). Keep it below 50 °F
([FB 976, p. 16](lib:cooling-milk-and-cream-on-the-farm#page=16)).

**Springhouse or spring tank** ([FB 976, pp. 9–15](lib:cooling-milk-and-cream-on-the-farm#page=9)):
1. Pipe the spring **several feet underground** to a covered tank in the shade; surface-run spring water has
   warmed 20 °F on the way. Ours runs about **52–55 °F** ([Root Cellar guide](guide:ROOT-CELLAR-GUIDE), "Cooling without power").
2. Water **in at the bottom, out near the top**, as high on the can as the milk inside; cans on cleats
   ([FB 876, pp. 7–8](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=7); [🖼️ tank](lib:cooling-milk-and-cream-on-the-farm#page=7)).
3. **Cover and insulate it** (6 in of dry sawdust, [FB 876, p. 8](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=8)):
   a covered, insulated tank in a shed lost 7.6 lb of ice in a test; an open metal tank in the sun, 168 lb
   ([FB 976, p. 12](lib:cooling-milk-and-cream-on-the-farm#page=12)).
4. **No running water or ice:** **6–10 gallons of water per gallon of milk**, changed often
   ([FB 976, p. 14](lib:cooling-milk-and-cream-on-the-farm#page=14)). Stir the milk. Even ice water needs volume: a can
   of 85 °F milk in 3 times its volume of 37 °F water only gets to about 50 °F ([p. 6](lib:cooling-milk-and-cream-on-the-farm#page=6)).

![Cross-section of two insulated concrete cooling tanks with lids: a 10-gallon can of 85 °F milk standing in 30 gallons of 37 °F ice water, and afterward milk and water both at about 50 °F; an overflow pipe and a drain](img:DAIRY-GUIDE/insulated-cooling-tank.png)
*Even three times the milk's volume of ice water only brings 85 °F milk down to about 50 °F: use plenty of water, and cover and insulate the tank ([FB 976, p. 7](lib:cooling-milk-and-cream-on-the-farm#page=7)).*

**A creek:** a lidded can tied in a cold stream works ([🖼️ *Raising Healthy Cattle*, p. 13](lib:raising-healthy-cattle-cvm#page=13)).
Our creeks and the Illinois River run warm by midsummer, so measure first, use a shaded side-channel or deep
pool, and weight and lash the lid against raccoons and bears *(rule of thumb)*.

**Evaporative cooler ("iceless refrigerator")** for butter, cheese and cooled milk
([USDA 1917, p. 3](lib:the-iceless-refrigerator#page=3)): a 42 × 16 × 14-inch screened frame, covered in
canton flannel or burlap, with cloth wicks from a pan of water on top; stand it in **shade and a breeze**.
In warm dry air it gets down to about **50 °F**; in damp weather it barely works. Our dry summer afternoons
suit it *(rule of thumb)*. Brick and charcoal versions are in the Root Cellar guide.

![An iceless refrigerator: a screened wooden cabinet with shelves, covered in wet cloth, with cloth wicks hanging from a pan of water on top and the cover hanging into a pan below, standing in the shade in a breeze](img:DAIRY-GUIDE/iceless-refrigerator.svg)
*Water wicks from the top pan into the cloth cover, and the breeze dries it and cools the inside (a diagram drawn for this guide).*

**Hold the cold:** chill milk first, then shut it in a hay-box: it "may make many hours difference"; with a
little cracked ice a quart holds **24 hours** in hot weather ([USDA FB 771, p. 17](lib:usda-homemade-fireless-cookers-fb771-1919#page=17)).
Ice and cold-water numbers: the [Storing Energy guide](guide:STORING-ENERGY-GUIDE), "Cold: storing winter for summer".
**Summer plan** *(rule of thumb)*: milk at dawn and dusk, cool at once, drink the morning's milk that day, and
turn the rest into yogurt, cheese, butter or ghee before the afternoon heat.

## 🥛 Separating cream by hand

| Method | How | Fat left in the skim milk |
|---|---|---|
| **Shallow pan** | Fresh milk in a pan 16–24 in across and **4 in deep**, in a cool place; skim with a ladle after **36 hours** | 0.5–0.6%, or more: up to a third of the butterfat lost |
| **Deep-setting** | Fresh milk in a tall narrow "shotgun" can (about 8½ × 20 in) **in ice water 12 hours** or cold water 24 hours; draw the skim milk off a bottom tap | 0.2–0.5% |
| **Hand-cranked separator** | Milk at **90 °F or warmer**, crank at the stated speed, flush with skim milk at the end | a trace |

*Sources: [ILCA, p. 38](lib:rural-dairy-technology#page=38) ([🖼️ pan and can](lib:rural-dairy-technology#page=38));
[FB 876, pp. 4–6](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=5); can size [p. 21](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=21).*

- **Cool fast for more cream:** quick chilling makes cream rise faster and more completely
  ([FB 876, p. 5](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=5)). Don't jostle the pans;
  rough handling breaks up the rising fat ([ILCA, p. 38](lib:rural-dairy-technology#page=38)).
- **Goat milk:** the cream barely rises ([FB 920, p. 7](lib:milk-goats-usda-farmers-bulletin-920#page=7)), so
  skim what you get and churn soured whole milk (below), or use a separator.
- **A separator** is the one dairy machine worth trading for ([ILCA, p. 37](lib:rural-dairy-technology#page=37)). Set it for
  cream of about **30–35%** ([FB 976, p. 17](lib:cooling-milk-and-cream-on-the-farm#page=17)): a gallon of
  30% cream makes about **3 lb of butter** ([FB 876, p. 3](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=3)).
  **Take it apart and wash it after every use**; rinsing it and washing it once a day is "a filthy practice"
  ([p. 6](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=6); [🖼️ cutaway](lib:rural-dairy-technology#page=40)).
- **Cool the cream at once** and never pour warm cream into cold; it sours the lot
  ([FB 976, p. 17](lib:cooling-milk-and-cream-on-the-farm#page=17)).

## 🧈 Butter and buttermilk

**Butter from cream** ([FB 876, pp. 8–15, 23–24](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=23)):
1. **Ripen:** warm the saved cream to **65–75 °F** and hold it until it thickens, looks glossy and is mildly
   sour, about 12 hours. Overripe (too sour) cream makes poor butter.
2. **Cool it to churning heat and hold 2 hours:** **52–60 °F in summer, 58–66 °F in winter**, set so the butter
   comes in 30–40 minutes ([p. 10](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=10)).
   Warm or cool it by standing the can in water ([🖼️ p. 7](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=7));
   never pour hot water or ice into cream.
3. **Churn** in a scalded, cold-rinsed [churn](wiki:Butter_churn) filled only **a third full**
   ([p. 12](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=12)). No churn: a jar or a closed
   can, shaken, rolled on a mat or swung from a tripod ([ILCA, p. 60](lib:rural-dairy-technology#page=60);
   [🖼️ small churns](lib:butter-and-ghee-practical-action#page=3)). Let the gas out a few times early on.
4. **Stop when the grains are the size of wheat** and drain the buttermilk through a strainer
   ([🖼️ p. 13](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13)). Churning on into a lump traps buttermilk.
5. **Wash, don't work, the buttermilk out:** twice, with clean water at the buttermilk's temperature, twice
   its volume in all; three times in hot weather ([pp. 14–15](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=14);
   [ILCA, p. 46](lib:rural-dairy-technology#page=46)). Use drinking-quality water.
6. **Salt and work:** about **½ oz salt per pound** (3%) for keeping butter; FB 876 uses ¾ oz. Press and fold
   with a wooden paddle, never your warm hands ([*Keeping One Cow*, p. 18](lib:keeping-one-cow#page=18)),
   just until the salt is even and the butter breaks "like broken steel"
   ([p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16); [🖼️ working it](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16)).

![Four jars of cream being churned: a third full at the start; thick and grainy like cornmeal mush; grains the size of wheat in thin buttermilk (stop here); one big lump of butter (too far)](img:DAIRY-GUIDE/when-to-stop-churning.svg)
*Stop when the grains are the size of wheat, before they gather into a lump (a diagram drawn for this guide).*

**Butter from soured whole milk** (goat milk, or no separator) ([ILCA, pp. 60–62](lib:rural-dairy-technology#page=60)):
collect milk over 2–3 days until it is **pleasantly sour**; fresh milk churns slowly and loses fat. Churn at
**63–66 °F** (17–19 °C), the jar a third to half full. Warmer than 68 °F churns fast but loses fat: at 79 °F as
little as 60% comes out as butter. Colder can take 5 hours ([🖼️ products chart](lib:rural-dairy-technology#page=61)).

**Keeping butter** without a fridge:
- Salted to 3% in a sealed crock, cool and dark: **up to 4 months**; more salt adds nothing
  ([ILCA, p. 49](lib:rural-dairy-technology#page=49)). Pack it firmly from one churning, in a well-glazed crock
  ([FB 876, p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16); [ILCA, p. 47](lib:rural-dairy-technology#page=47)).
- **Under brine:** rolls of butter wholly submerged in 1 lb salt to 4 lb water; or a crock topped with a wax
  seal ([FB 876, p. 20](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=20)).
- Butter for storing keeps best made from **pasteurized sweet cream**: 145–150 °F for 25–30 minutes, cooled
  below 50 °F and held 3 hours before churning ([p. 19](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=19)).
- Unsalted butter in warm weather turns rancid within days
  ([Practical Action, p. 5](lib:butter-and-ghee-practical-action#page=5)); make surplus into ghee.

**Cultured buttermilk:** skim milk heated to 203 °F, cooled to 68–77 °F, seeded with 1–2% starter, 16–20 hours
([Practical Action, p. 1](lib:soured-milk-and-yoghurt#page=1)).

📚 **Go deeper:** [USDA FB 876 *Making Butter on the Farm*](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=3) — every step and every fault; [ILCA *Rural Dairy Technology*](lib:rural-dairy-technology#page=45) — churning, overrun and keeping butter.

## 🫕 Ghee and clarified butter for storage

[Ghee](wiki:Ghee) is butterfat with the water and milk solids cooked out, so germs have nothing to grow in.
It **keeps more than 12 months at room temperature** ([Practical Action, p. 4](lib:butter-and-ghee-practical-action#page=4)).

1. Melt butter (or, the traditional way, boil cream) in a heavy pot and **boil gently and steadily**, skimming
   the scum. Don't scorch it ([ILCA, p. 49](lib:rural-dairy-technology#page=49)).
2. It is done when the water stops spitting and the milk solids on the bottom turn **golden brown**;
   color is the only test ([Practical Action, p. 4](lib:butter-and-ghee-practical-action#page=4)).
3. Let it settle; pour off through **boiled cheesecloth** until it runs clear.
4. Store **airtight, dark and cool**, in glazed crocks or glass, **not iron or copper**, which speed rancidity.
   Fill jars full; a clean, dry spoon every time *(rule of thumb)*.

**Clarified butter with less fuel:** melt butter in water at about 176 °F, let the fat set on top as in a
deep-setting can, drain the water off, then heat the fat just long enough to drive off the last moisture.
It kept well through a 5-month test ([ILCA, p. 49](lib:rural-dairy-technology#page=49)).

A pound of butter (80% fat) gives about **¾ lb of ghee** ([ILCA, p. 45](lib:rural-dairy-technology#page=45); *arithmetic*).
In fire season do the long boil on the stove indoors or before dawn, never over an open fire outside
*(rule of thumb)*.

## 🦠 Cultured milk, yogurt and kefir

Soured milk keeps where fresh milk won't: the acid stops most germs, though not mold
([ILCA, p. 34](lib:rural-dairy-technology#page=34)).

**[Yogurt](wiki:Yogurt)** ([Practical Action, pp. 1–4](lib:soured-milk-and-yoghurt#page=1)):
1. Heat milk to **176–185 °F** and hold 15–20 minutes, stirring. Cool fast to **104–113 °F**, standing the pot in cold water.
2. Stir in **20–50 g of live yogurt per liter** (about 1½–3 tablespoons per quart *(arithmetic)*).
3. Keep it at 104–113 °F for **4–6 hours**: a thermos, an insulated box (p. 4), a
   [hay-box](guide:MAKE-DO-HOUSEHOLD-GUIDE), or a cooler with jars of hot water *(rule of thumb)*. Then cool it.
4. It keeps up to 10 days cold (p. 1); in a springhouse plan on less *(rule of thumb)*.

**Clabber and soured milk:** milk soured naturally in a warm room for 1–2 days keeps 3–8 days
([p. 1](lib:soured-milk-and-yoghurt#page=1)). The ILCA way keeps longer: a vessel smoked hot with burning embers
(they used olive and acacia; a clean hardwood such as oak *(rule of thumb)*), the milk fermented slowly at
**61–64 °F** for 2–4 days, keeps **15–20 days**; warmer, it wheys off and gets gassy
([ILCA, p. 59](lib:rural-dairy-technology#page=59)). Pouring off the whey and topping up with fresh milk for up to a
week concentrates it and keeps it longer still ([p. 60](lib:rural-dairy-technology#page=60)). Pasteurized milk must be
seeded; it won't sour cleanly alone ([p. 34](lib:rural-dairy-technology#page=34)).

**[Kefir](wiki:Kefir) needs no warm box** ([ILCA, p. 59](lib:rural-dairy-technology#page=59)): heat milk to
185 °F for 30 minutes, cool it, add kefir grains (lumps in which the bacteria and yeasts live), and leave
**about 12 hours at 72 °F**. Lift the grains out with a clean spoon into the next jar of milk. They multiply;
give spares away or feed them to hens *(rule of thumb)*.

**Keeping cultures alive for years:**
- **Mother culture:** keep a small jar going from clean, freshly heated milk, use 1–3% of it to seed each day's
  batch, and start a new mother from the last of it. It runs for months until stray germs spoil it
  ([Practical Action, p. 3](lib:soured-milk-and-yoghurt#page=3)). Seeding from yesterday's yogurt works but
  spoils sooner (same page); after a collapse it may be all you have.
- **Homemade starter from nothing:** fill several **boiled pint jars** with fresh milk from different animals,
  keep them at **75 °F**, and keep the one that curdles in 24–30 hours into a firm, smooth, marble-like curd
  with no gas holes and a **clean, sharp sour** taste. Carry it on daily: a teaspoon into a quart of skim milk
  that was heated to 175 °F for 30 minutes and cooled to 75 °F
  ([FB 1451, p. 7](lib:making-and-using-cottage-cheese#page=7); [🖼️ starter jars](lib:making-and-using-cottage-cheese#page=7);
  [FB 876, pp. 9–10](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=9)).
- **Throw out any starter that tastes off.** Natural starters often pick up bad flavors that are hard to notice
  at first ([*Book of Cheese*, p. 67](lib:the-book-of-cheese#page=67)).
- **Keep two of each culture in two places**, and share with neighbors: their jar is your backup *(rule of thumb)*.

## 🧀 Soft cheeses: paneer, queso fresco, chèvre, cottage cheese

Soft cheeses are quick and need little gear, but they keep only days: about **3 days cold, 5 in brine**
([Practical Action, p. 1](lib:cheese-making-practical-action#page=1)). Make them from **pasteurized** milk.

**[Paneer](wiki:Paneer) or [queso blanco](wiki:White_cheese) (lemon or vinegar cheese, no rennet)**
([ILCA, pp. 50–52](lib:rural-dairy-technology#page=50); [Practical Action, p. 2](lib:cheese-making-practical-action#page=2)):
1. Heat milk to **180 °F**, or to a simmer for 5 minutes. This pasteurizes it too.
2. Stir in **lemon or lime juice**: Practical Action uses 1–1.5% of the milk's weight, ILCA about 3 mL per
   100 mL diluted with equal water (2 tablespoons per quart *(arithmetic)*). Add it in three parts, stopping
   when the curds clump and the whey runs clear and yellow-green. Vinegar works the same way *(rule of thumb)*.
3. Settle 15 minutes; drain in a cloth, stirring so it doesn't mat.
4. Salt (3.5–5% of the curd) and press overnight ([🖼️ step chart](lib:rural-dairy-technology#page=51)).
   A liter makes about **250 g** of moist paneer; a firm pressed queso blanco about 1 lb per gallon.

**Queso fresco** is the same fresh cheese set with rennet instead of acid: make the one-gallon rennet cheese
(hard-cheese section) up to bagging the curd, salt the curd, press it lightly a few hours, and eat it within a
few days *(rule of thumb)*.

**Chèvre-style goat cheese (soft, spreadable, a little rennet)**: FB 920 calls French goat cheese "Chevret"
([p. 7](lib:milk-goats-usda-farmers-bulletin-920#page=7)); this is the USDA rennet cottage-cheese method
([FB 1451, pp. 9–11](lib:making-and-using-cottage-cheese#page=9)):
1. Pasteurize the milk, cool it to **75 °F**, and stir in starter: **about ½ cup per gallon** (a pint per
   3½ gallons).
2. Add rennet: **about 3 drops of liquid rennet per gallon**, first stirred into a half-cup of cold water; or one
   junket tablet dissolved in a pint of cold water, using a third of it for 3½ gallons.
3. Cover and leave at 75 °F **12–15 hours** (overnight), until clear whey lies on the curd. **Don't cut or heat it.**
4. Ladle into fine cotton cloth; drain 20–30 minutes, then tie it up and hang it, or press lightly under about
   25 lb until it is like thick cream cheese ([🖼️ boards and weight](lib:making-and-using-cottage-cheese#page=10)).
5. Salt about **1 teaspoon per pound**; herbs if you like.

**[Cottage cheese](wiki:Cottage_cheese) with no bought culture** ([FB 1451, pp. 6–7](lib:making-and-using-cottage-cheese#page=6)):
let **skim milk** clabber at about **75 °F** (about 30 hours) until clean and pleasantly sour; cut it in 2-inch pieces;
set the pan in hot water to bring it to **100 °F** and hold 30 minutes, stirring gently (hotter makes it tough);
drain in a cloth bag, rinse cold, salt. A gallon makes about **1½ lb**. Keep it in glass or earthenware and eat it
soon: 36 hours at room temperature puts it off flavor ([p. 10](lib:making-and-using-cottage-cheese#page=10)).

## 🐮 Rennet from a kid or calf stomach, and from plants

[Rennet](wiki:Rennet) is an enzyme from the true (fourth) stomach, the [abomasum](wiki:Abomasum), of a
suckling calf. After weaning, the calf makes pepsin instead ([ILCA, pp. 49–50](lib:rural-dairy-technology#page=49)),
so stomachs that have digested anything but milk make weak rennet. Cheesemakers hold that kid or lamb rennet
suits goat or sheep milk ([*Book of Cheese*, p. 55](lib:the-book-of-cheese#page=55)).

**Making rennet** ([*Book of Cheese*, pp. 55–56](lib:the-book-of-cheese#page=56)):
1. Take the fourth stomach of a kid, lamb or calf that has had **nothing but milk**, butchered soon after a
   full feed. Empty it, clean it, blow it up and dry it in airy shade. Dried "rennets" keep until needed.
2. Cut it open and soak it in **3–5% salt water** (about 4–7 oz salt per gallon *(arithmetic)*), stirring and
   pounding it, 5–7 days. Wring it out and soak it again in fresh brine, **4–6 weeks** in all.
3. Filter through straw, charcoal and sand (or several cloths), add more salt, and keep it **cool and dark** in
   a stone jug or brown glass. Light destroys it, and heat kills it.
4. Good rennet is clear, with a clean salty taste. Cloudy, muddy or bad-smelling rennet taints cheese: throw it out.
5. **Quick way:** a small piece of dried stomach left in a little water overnight curdles milk
   ([Henley's, p. 176](lib:henleys-twentieth-century-formulas-recipes-and-processes-1916#page=176)).

**Test every batch**: homemade rennet varies in strength and spoils ([p. 55](lib:the-book-of-cheese#page=55)). It
works slowly below 70 °F and best at **84–94 °F**; dilute it in about 40 times its volume of cold water before
stirring it in ([pp. 95–96](lib:the-book-of-cheese#page=96)). Warm a quart of milk to 86 °F, stir in a measured
half-teaspoon of diluted rennet, and time it: aim for a curd that splits cleanly in **25–40 minutes**, then scale
up *(rule of thumb)*. Bought liquid rennet runs about 2 teaspoons per 100 lb of milk
([FB 1191, p. 6](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=6)).

**Plant rennets** ([Practical Action, p. 1](lib:cheese-making-practical-action#page=1)): papaya sap, **fig**
bark, and the stems or leaves of two tropical plants also curdle milk. Fig trees grow in valley yards; a few
drops of the milky sap from a green fig stem per quart of warm milk is the old way. The sap burns skin, so
wear gloves *(rule of thumb)*. Thistle flowers ([cardoon](wiki:Cardoon)) and nettle are traditional too *(rule of thumb)*.
- **Use plant rennets for fresh cheese.** Many plant and other enzymes turn aged cheese **bitter**
  ([ILCA, p. 50](lib:rural-dairy-technology#page=50)).
- **Never use milkweed.** Named for its "milky, sticky juice", it poisons livestock
  ([AIB 415, pp. 71, 73](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=73)).
- **No rennet at all?** Make acid cheese (paneer) or lactic cheese (cottage cheese, chèvre without the rennet).

## 🏋️ Hard cheese step by step, with a home-made press

The USDA's simple **farm Cheddar** ("granular" process) from **whole milk**: 5–6 hours, then minutes a day
([FB 1191, pp. 4–17](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=4)). Cool nights make the
best cheese; hot weather breeds gas germs (p. 4). Use milk under 12 hours old, kept at 60 °F or below (p. 5).
Pasteurize it if you can, then add ¼–½ cup of clean buttermilk or clabber per gallon as starter *(rule of thumb)*.

**For 4 gallons (about 34 lb) of milk, making about 3½ lb of cheese** *(arithmetic from p. 5)*:
1. **Warm the milk to 86 °F** in a big pot set in a tub of warm water; keep it there until the curd is cut.
2. **Rennet:** about **⅔ teaspoon** of liquid rennet (FB 1191 uses ⅓ oz, 2 teaspoons, per 100 lb *(arithmetic)*),
   stirred into a cup of cool water, then stirred through the milk 3 minutes ([p. 6](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=6)).
   Cover; **don't let it move** for 30–35 minutes.
3. **Test the set:** slide a finger in at a slant, lift, and split the curd with your thumb. When it **splits
   cleanly** with nothing left on the finger, cut it ([p. 7](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=7);
   [🖼️ trying the curd](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=7)).
4. **Cut into ⅜-inch cubes** with a long knife: lengthwise, crosswise, then give the curd a quarter turn and cut
   lengthwise again. Cut, don't crush
   ([p. 8](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=8); [🖼️ curd knives](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=8)).
5. **Stir gently 15–20 minutes**, then **heat slowly, about 2 °F every 5 minutes, to 100 °F**, still stirring.
6. **Hold at 100 °F until firm and acid:** a squeezed handful falls apart when you open your hand
   ([🖼️ firmness](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=11)), and a pinch of
   curd pressed on a clean **hot iron** draws out fine threads **¼–½ inch** long ([pp. 9–10](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=9);
   [🖼️ hot-iron test](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=12)).
7. **Drain:** dip off the whey; spread the curd on a cloth over a slatted rack, keep it covered and near 100 °F,
   and stir it every 5–10 minutes so the pieces stay hickory-nut size ([pp. 10–11](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=11);
   [🖼️ draining box](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=12)).
8. **Salt** when the hot-iron threads reach **¾–1 inch**: about **3 oz salt per 10 lb of curd**. Let it dissolve
   and the curd cool to **85 °F** ([p. 13](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=13)).
9. **Press:** into a cloth-lined hoop; light weight 30 minutes, more for an hour; take it out, dip it in warm
   water, smooth the cloth ("dressing"), and press at **full weight 24 hours**
   ([p. 14](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=14)).
10. **Cure** at **50–60 °F**, turned daily for 2 weeks, then twice a week; coat it at 2 weeks; eat it from
    **6 weeks** (mild), or keep it many months for sharp ([pp. 15–16](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)).

![Testing the curd with a finger for a clean split; cutting it lengthwise, then crosswise, seen from above; giving it a quarter turn and cutting lengthwise again; ending in cubes three-eighths of an inch on a side](img:DAIRY-GUIDE/testing-and-cutting-the-curd.svg)
*Steps 3 and 4: test the set with a finger, then cut the curd into ⅜-inch cubes (a diagram drawn for this guide).*

**Smaller batch (1 gallon, goat or cow)** ([FB 920, p. 8](lib:milk-goats-usda-farmers-bulletin-920#page=8)): a junket
tablet dissolved in a little cold water into a gallon of milk at 88 °F; cut after 30 minutes into 1-inch cubes; warm
the pot in 100 °F water so the curd reaches 98 °F in an hour; bag it 2–3 hours; press between two plates in a can
under a weight 24 hours; rub with salt two days running, then daily for a week. Ready at 10 days.

### A home-made cheese press

- **Hoop (mold):** a tube with drain holes and a loose wooden follower (disk) on top: 4-inch plastic drainpipe
  cut 4–10 in long on a wooden base ([Practical Action, p. 7](lib:cheese-making-practical-action#page=7)), or FB 1191's
  hoop, 7–8 in across and 10 in tall, for a 5–10-lb cheese ([🖼️ p. 13](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=13)).
  Use wood, food-grade plastic or stainless, not galvanized metal, which acid curd eats *(rule of thumb)*.
- **Lever press** ([FB 1191, pp. 14–15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15);
  [🖼️ press](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)): a long pole (the
  bulletin's is about 12 ft) hinged to the wall, the hoop under it about 3 ft out, and a **pail of stones
  (35–40 lb)** that slides along the pole: halfway out for light pressing, at the end for full pressure.
- **Weight press:** boards above and below and a pail of stones or water on top, about 25 lb for soft cheese
  ([FB 1451, p. 10](lib:making-and-using-cottage-cheese#page=10)), more for hard. Or a **screw press**
  ([🖼️ Practical Action, p. 5](lib:cheese-making-practical-action#page=5)).

![A home-made lever cheese press: a long board hinged to the wall, the cheese hoop on a stand under it near the wall, and a pail of stones hanging from the far end](img:DAIRY-GUIDE/lever-cheese-press.png)
*The hoop stands about 3 ft from the wall; sliding the pail of stones outward along the pole presses harder ([FB 1191, p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)).*

## 🧂 Feta and halloumi: cheese that keeps in brine

**[Feta](wiki:Feta)** needs no press and keeps for months under brine with the air kept out. Cow, sheep or goat
milk all work ([ILCA, pp. 52–56](lib:rural-dairy-technology#page=56); [🖼️ steps](lib:rural-dairy-technology#page=55)):
1. Warm the milk to **90 °F** and let it stand 1 hour (with a little starter if it was pasteurized *(rule of thumb)*).
2. Rennet at **25 mL per 100 liters**, about ¾ teaspoon for 4 gallons *(arithmetic)*. Firm in 40–50 minutes.
3. Cut into **1-inch cubes**; let the whey separate 15 minutes, stirring now and then; settle; dip off the whey.
4. Ladle curd into cloth-lined molds with lids; **turn them every half hour** for the first few hours; drain overnight.
5. Cut into blocks, sprinkle with salt, and put them in **15% brine** (about 1¼–1½ lb salt per gallon of
   boiled water *(arithmetic)*). The cheese ends near 6–8% salt.
6. **Keep the air out** (a full crock with a weighted plate, or a full sealed jar): mold grows where air
   reaches the brine. Eat after a few days or keep it for months; it softens and crumbles as it ripens.
   Yield about **1 lb per gallon** (1 kg from 9 kg of milk) *(arithmetic)*.

**[Halloumi](wiki:Halloumi)**, cooked in its own whey and kept in whey brine
([ILCA, pp. 52–53](lib:rural-dairy-technology#page=52); [🖼️ steps](lib:rural-dairy-technology#page=53)):
set whole milk with rennet at 90–95 °F; cut the curd; warm it to **104 °F** stirring 20 minutes; drain and press
**2 hours**. Meanwhile heat the whey to **176–194 °F**: the whey cheese that rises is skimmed off. Cut the pressed
curd into 4 × 4 × 1¼-inch slabs and simmer them in the hot whey until they **float and turn soft and stretchy**;
fold them, rub with dry salt and dried mint, cool, and store in cool, boiled whey brine (15% salt). Ripen
about 30 days; it keeps several months below 54 °F.

## 🕯️ Salting, waxing and aging without a fridge

**Salt** is the main preservative: it pulls out water and slows the germs that remain
([Practical Action, p. 1](lib:cheese-making-practical-action#page=1)): in the curd for hard cheese, brine for fresh.

**Where to age it:**
- **Cool:** FB 1191 calls **50–60 °F** most favorable ([p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15));
  older books want about **45 °F**, never over 50–52 °F, and **no sudden swings**
  ([Henley's, p. 177](lib:henleys-twentieth-century-formulas-recipes-and-processes-1916#page=177)). Cheddar cured at 40 °F
  scored best, at 60 °F worst; **never let it freeze** ([*Book of Cheese*, p. 282](lib:the-book-of-cheese#page=282)). At 70–80 °F it
  cures fast and goes bad more often (FB 1191, p. 16). Our cellars sit near 55 °F by midsummer (Root Cellar guide): good enough.
- **Damp:** above 85% humidity ([Practical Action, p. 4](lib:cheese-making-practical-action#page=4)). If the room dries out,
  wet the floor; open it to cool night air and close it by day ([*Book of Cheese*, p. 286](lib:the-book-of-cheese#page=286)).

**Care:** turn every cheese daily so it dries evenly and doesn't stick or mold to the shelf; if the cloth
loosens and the rind cracks, rub it with butter. **Cracks let in flies and mold**
([*Book of Cheese*, p. 284](lib:the-book-of-cheese#page=284)). Wipe mold off with a dry cloth; if it molds badly,
scrub it with strong brine and move it somewhere drier ([FB 1191, p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)).
**Cover cellar windows with cheesecloth**: the cheese-skipper fly gets through window screen (same page;
[Cheese fly](wiki:Cheese_fly)).

**Coating** cuts drying and mold. Coat once the rind is dry, 4–6 days to 2 weeks after pressing
([*Book of Cheese*, p. 286](lib:the-book-of-cheese#page=286)):
- **Beeswax** (from the [Bees guide](guide:BEES-GUIDE)) is the no-store wax: melt it in a can **set in a pot of water**, never
  over a bare flame, and dip or brush thin coats *(rule of thumb)*. The cheese must be dry or the wax blisters
  and peels ([p. 287](lib:the-book-of-cheese#page=287)).
- **Cloth and fat:** leave the pressing cloth on and rub it with butter or lard as it dries *(rule of thumb, from p. 284)*.
- **Brine** instead of a rind (feta, halloumi). Waxing and brining both cut weight loss ([ILCA, p. 56](lib:rural-dairy-technology#page=56)).

**Cut cheese:** wrap it in a cloth wrung almost dry, then paper, and keep it cool; don't shut it fully
airtight, which makes it mold faster ([*Book of Cheese*, p. 396](lib:the-book-of-cheese#page=396)).

📚 **Go deeper:** [USDA FB 1191](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=4) — farm Cheddar with home-made gear; [*The Book of Cheese*, pp. 281–293](lib:the-book-of-cheese#page=281) — curing rooms and defects (old book: raw-milk methods); [ILCA](lib:rural-dairy-technology#page=50) — queso blanco, halloumi, feta, yields.

## ♻️ Whey and buttermilk: using everything

A hard cheese leaves 8–9 lb of whey for every pound of cheese *(arithmetic)*. Whey can be a drink, become
whey cheese, or feed animals ([Practical Action, p. 2](lib:cheese-making-practical-action#page=2)).

- **[Ricotta](wiki:Ricotta) (whey cheese):** heat sweet whey to about **200 °F**; the albumin rises and is skimmed
  off; a little acid speeds it ([*Book of Cheese*, p. 319](lib:the-book-of-cheese#page=319)). Albumin is only
  about 0.7% of the milk, so expect a small amount (same page).
- **Brown whey cheese ([mysost](wiki:Brunost)):** boil the rest down, stirring as it thickens, until it is a
  brown, sweet paste; stir the skimmed albumin back in and cool it in molds. Whey is nearly 5% milk sugar
  (same page). It takes a lot of fuel; use a solar cooker or the back of a stove running anyway *(rule of thumb)*.
- **Hens:** skim milk and buttermilk make a wet mash with ground grain, and can be their only drink: about
  **4–5 gallons a day per 100 hens** ([USDA FB 1841, p. 24](lib:the-feeding-of-chickens-usda-farmers-bulletin-1841-1941#page=24)).
  Whey does the same job *(rule of thumb)*; see the [Chickens guide](guide:CHICKENS-GUIDE).
- **Pigs:** only **boiled or pasteurized** whey and milk ([*Zoonoses*, p. 27](lib:zoonoses-diseases-animals-give-people-cvm#page=27)).
  Old factories spread disease by sending whey home in the milk cans ([*Book of Cheese*, p. 49](lib:the-book-of-cheese#page=49)).
- **Buttermilk and sour milk:** drink it; bake with it (a cup plus ½ teaspoon of soda replaces sweet milk and
  baking powder: "Leavening" in the [Food From Scratch guide](guide:FOOD-FROM-SCRATCH-GUIDE)); seed the next batch.
  **Ayib curd:** heat sour buttermilk or skim milk to about **122 °F** (104–158 °F all work) until curd forms, cool
  slowly, strain: at least 1 kg from 8 liters ([ILCA, p. 62](lib:rural-dairy-technology#page=62)).
- **Waste:** don't tip whey into creeks, and keep it out of compost, which draws bears; bury it or feed it out
  *(rule of thumb; [Sanitation guide](guide:SANITATION-GUIDE))*.

## 📆 The dairy year in the valley

| Months | Milk | What to make *(rule of thumb)* |
|---|---|---|
| **Jan–Feb** | Little; kids due from February | Eat stored cheese, ghee and butter. Scald and mend gear. Make rennet from milk-fed bucklings or bull calves butchered young |
| **Mar–May** | Spring flush; cool nights; springs and cellar cold | **Hard cheese for winter** (cool nights suit it, [FB 1191, p. 4](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=4)); butter for storing; start new cultures |
| **Jun–Sep** | Steady; 90–100 °F afternoons; fire season | Milk at dawn and dusk; spring tank and evaporative cooler; yogurt, kefir, feta, halloumi and ghee **the same day**. Ghee on the stove indoors, no outdoor fires |
| **Oct–Dec** | Tapering; rains; cellar cooling | Cheeses curing in the cellar; salt butter down; dry off does and breed them (see the [Goats guide](guide:GOATS-GUIDE)) |

## ⚖️ How much milk makes how much

| Product | Milk or cream in | Comes out | Source |
|---|---|---|---|
| Butter | 1 gal of 30% cream | about **3 lb** | [FB 876, p. 3](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=3) |
| Butter | whole milk at 4% fat, all fat recovered | 1 lb from about **9 qt** (19.4 L per kg) | [ILCA, p. 48](lib:rural-dairy-technology#page=48) *(arithmetic)* |
| Butter, old rule | 1 qt a day | 1 lb a week (7 qt per lb): true for Jersey-rich milk | [*Keeping One Cow*, p. 18](lib:keeping-one-cow#page=18) |
| Ghee | 1 lb butter | about ¾ lb | *(arithmetic)* |
| Farm Cheddar | 100 lb (11⅝ gal) of 4% milk | about **10½ lb**: ~1 lb per 1⅛ gal | [FB 1191, p. 5](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=5) |
| Any rennet cheese, estimate | 100 lb milk | (2.3 × fat %) + 1.4 lb | [ILCA, p. 56](lib:rural-dairy-technology#page=56) |
| Feta, halloumi | 9 kg (about 2⅓ gal) | 1 kg (2.2 lb) | [ILCA, pp. 52, 56](lib:rural-dairy-technology#page=52) |
| Queso blanco | 8 kg | 1 kg | [ILCA, p. 52](lib:rural-dairy-technology#page=52) |
| Paneer (moist) | 1 liter | 250 g | [Practical Action, p. 2](lib:cheese-making-practical-action#page=2) |
| Cottage cheese | 1 gal skim milk | about **1½ lb** | [FB 1451, p. 6](lib:making-and-using-cottage-cheese#page=6) |

Goat milk at 3.5% fat gives a little less butter and cheese than these 4% figures; sheep milk much more
*(rule of thumb)*. Hand skimming leaves up to a third of the fat in the skim milk
([FB 876, p. 5](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=5)), so by hand expect 1 lb of
butter from **3 gallons** or more *(arithmetic)*.

**For a family** *(arithmetic, rule of thumb)*:
- A good doe gives about **1½ qt a day** averaged over the year; a family cow 10–20 qt. One farm cow's cream
  kept a family of six in butter with some to spare ([*Keeping One Cow*, p. 20](lib:keeping-one-cow#page=20)).
- A toddler (6–24 months) needs about **1–2 cups (200–500 mL) of whole milk a day**, the more when there is
  little other animal food ([WHO, p. 16](lib:guiding-principles-for-feeding-non-breastfed-children-6-24-months-who-2005#page=16)).
- **Two does in milk (about 3 qt a day):** a quart to drink, and 2 qt a day (3½ gal a week) into about
  **3 lb of hard cheese or feta** a week.
- **Food value:** an ounce of Cheddar is about one egg, a glass of milk, or 2 oz of meat
  ([*Book of Cheese*, p. 392](lib:the-book-of-cheese#page=392)).

## 🧯 What goes wrong: off flavors, spoilage, mold

| Problem | Likely cause and fix |
|---|---|
| Milk sours in hours | Warm, or dirty pails. Cool below 50 °F within an hour; scald everything ([FB 976, p. 5](lib:cooling-milk-and-cream-on-the-farm#page=5)) |
| Milk tastes "goaty" or weedy | Buck kept near the does; wild garlic or strong weeds eaten near milking time; slow cooling; late lactation ([FB 920, pp. 25, 29](lib:milk-goats-usda-farmers-bulletin-920#page=29)) |
| Ropy, slimy milk or cream | Germs from unscalded gear. Scald everything; pasteurize and use a good starter ([FB 876, p. 18](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=18)) |
| **Butter won't come** | Too cold; cream too thin, too rich or too sweet; churn too full; a late-lactation animal; hard-fat feeds. Sour the milk, warm it to the churning heat, fill ⅓ ([FB 876, pp. 18–19](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=18); [ILCA, p. 60](lib:rural-dairy-technology#page=60)). If you must add water, never over 77 °F ([ILCA, p. 46](lib:rural-dairy-technology#page=46)) |
| Butter soft, white, greasy or "leaky" | Churned too warm or too fast; overworked ([FB 876, pp. 11–12, 15](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=11)) |
| Butter streaked or mottled | Salt uneven: work it a little more ([p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16)) |
| Butter goes rancid or cheesy | Buttermilk left in, warmth, air or light ([FB 876, p. 11](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=11); [Practical Action, p. 5](lib:butter-and-ghee-practical-action#page=5)). Wash well, salt to 3%, or make ghee |
| Yogurt thin or didn't set | Too cool, or milk too hot when the starter went in ([Practical Action, p. 4](lib:soured-milk-and-yoghurt#page=4)) |
| Clabber or yogurt gassy, yeasty, wheying off | Too warm; contaminated starter. Replace the starter ([ILCA, p. 59](lib:rural-dairy-technology#page=59); [Practical Action, p. 7](lib:cheese-making-practical-action#page=7)) |
| Curd won't set | Rennet weak or old, or milk below 70 °F ([*Book of Cheese*, pp. 95–96](lib:the-book-of-cheese#page=95)) |
| Cheese sour, dry, mealy | Too much acid or starter, whey left in too long ([FB 1191, p. 9](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=9); [*Book of Cheese*, p. 290](lib:the-book-of-cheese#page=290)) |
| Cheese hard and "corky" | Curd firmed too long, cooked too hot, too much salt, cured too warm and dry ([*Book of Cheese*, p. 292](lib:the-book-of-cheese#page=292)) |
| Cheese puffs up, full of pinholes | Gas germs from dirty milk or gear, or hot weather. Clean up, use more starter, cure it cooler ([*Book of Cheese*, pp. 292–293](lib:the-book-of-cheese#page=292); [ILCA, p. 57](lib:rural-dairy-technology#page=57)) |
| Fruity, strawberry taste | Milk and whey carried in the same cans; dirty whey tubs ([*Book of Cheese*, p. 290](lib:the-book-of-cheese#page=290)) |
| Mold | Hard cheese: wipe it, scrub with strong brine, move it somewhere drier ([FB 1191, p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)); cut an inch past mold that went in. Soft cheese, yogurt or butter moldy all through: throw it out *(rule of thumb)* |
| Jumping maggots ("skippers") | Cheese skipper fly: cheesecloth on windows, no cracks in rinds ([FB 1191, p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)) |
| Feta soft, slimy or moldy | Air in the crock, or weak brine ([ILCA, p. 56](lib:rural-dairy-technology#page=56)) |
| Soft cheese smells rotten, or a sealed jar bulges | Discard it unopened. Cheese poisoning, botulism included, has killed people ([*Book of Cheese*, p. 394](lib:the-book-of-cheese#page=394)) |

**Don't can milk, butter or soft cheese in a water bath:** milk is a low-acid food that needs a pressure
canner (see the [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE)), and no tested home method exists for
canning butter *(rule of thumb)*. Keep milk fat as ghee instead.

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Pasteurize at **140 °F (60 °C) for 30 minutes** ([*Zoonoses*, p. 31](lib:zoonoses-diseases-animals-give-people-cvm#page=31)) | Too low. 145 °F for 30 minutes, 161 °F for 15 seconds, or bring to a boil |
| Add hydrogen peroxide to milk to keep it, "far preferable to milk sterilized by heat" ([Henley's, p. 477](lib:henleys-twentieth-century-formulas-recipes-and-processes-1916#page=477)) | The same page admits it doesn't kill TB. Cool and pasteurize |
| Soft cheese from raw milk ([*Book of Cheese*, p. 167](lib:the-book-of-cheese#page=167); [FB 920, p. 8](lib:milk-goats-usda-farmers-bulletin-920#page=8)) | It carries Listeria and brucellosis. Pasteurize milk for soft cheese |
| Dip cheese in **paraffin heated to 240 °F** ([FB 1191, p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15)) or 220 °F ([*Book of Cheese*, p. 287](lib:the-book-of-cheese#page=287)) | Fire and burn hazard. Melt wax in a can set in water, never unattended |
| Wrap cheese in tin foil that is **2½–8% lead** ([Henley's, p. 476](lib:henleys-twentieth-century-formulas-recipes-and-processes-1916#page=476)) | Wax, cloth and fat, or brine |
| Cheese hoop of **galvanized** sheet metal ([FB 1191, p. 13](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=13)) | Acid curd and whey eat zinc. Wood, food-grade plastic or stainless *(rule of thumb)* |
| Butter coloring, 20–35 drops a gallon, and old dairy "preservatives" ([FB 876, p. 13](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13)) | Not needed. Salt to 3%, or make ghee |
| Send whey home for the pigs in the milk cans ([*Book of Cheese*, p. 49](lib:the-book-of-cheese#page=49)) | Spreads disease. Boil whey for pigs; keep milk cans for milk |

📚 **Go deeper:** [UMN](lib:pasteurization-of-milk-at-home#page=1) — today's home pasteurizing standard; [*Zoonoses*](lib:zoonoses-diseases-animals-give-people-cvm#page=29) — brucellosis, TB and Listeria from animals.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Clean milk and cooling**
- Milking stand; small-top pails — [🖼️ FB 920, p. 28](lib:milk-goats-usda-farmers-bulletin-920#page=28); [🖼️ *Book of Cheese*, p. 48](lib:the-book-of-cheese#page=48)
- Milk can in a stream; heating milk; "never drink unboiled milk" — [🖼️ *Raising Healthy Cattle*, p. 13](lib:raising-healthy-cattle-cvm#page=13); [🖼️ p. 14](lib:raising-healthy-cattle-cvm#page=14); [🖼️ p. 117](lib:raising-healthy-cattle-cvm#page=117)
- How fast milk sours; insulated spring tank; surface cooler; ice for a can — [🖼️ FB 976, p. 5](lib:cooling-milk-and-cream-on-the-farm#page=5); [🖼️ p. 7](lib:cooling-milk-and-cream-on-the-farm#page=7); [🖼️ p. 9](lib:cooling-milk-and-cream-on-the-farm#page=9); [🖼️ p. 11](lib:cooling-milk-and-cream-on-the-farm#page=11); [Spring house](wiki:Spring_house)
- Evaporative coolers — [🖼️ charcoal cooler](lib:charcoal-coolers-and-brick-cool-chambers#page=2); [🖼️ clay-pot cooler](lib:practical-action-clay-pot-cooler#page=2); [Evaporative cooler](wiki:Evaporative_cooler); [Pot-in-pot refrigerator](wiki:Pot-in-pot_refrigerator)

**Cream, butter and ghee**
- Pan and deep-setting can; hand separator; products of churning sour milk — [🖼️ ILCA, p. 38](lib:rural-dairy-technology#page=38); [🖼️ p. 40](lib:rural-dairy-technology#page=40); [🖼️ p. 61](lib:rural-dairy-technology#page=61); [Cream separation](wiki:Cream_separation)
- Churns, separator, butter pats — [🖼️ Practical Action, p. 3](lib:butter-and-ghee-practical-action#page=3); warming cream, churning, working butter, [🖼️ FB 876, p. 7](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=7); [🖼️ p. 10](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=10); [🖼️ p. 13](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=13); [🖼️ p. 16](lib:usda-farmers-bulletin-876-making-butter-on-the-farm-1930#page=16)
- 📷 [Butter churn](wiki:Butter_churn); [Buttermilk](wiki:Buttermilk); [Ghee](wiki:Ghee); [Clarified butter](wiki:Clarified_butter)

**Cultures and soft cheese**
- Starter jars; cottage cheese gear, draining and pressing — [🖼️ FB 1451, p. 7](lib:making-and-using-cottage-cheese#page=7); [🖼️ p. 5](lib:making-and-using-cottage-cheese#page=5); [🖼️ p. 9](lib:making-and-using-cottage-cheese#page=9); [🖼️ p. 10](lib:making-and-using-cottage-cheese#page=10)
- Queso blanco step chart; curd cutters — [🖼️ ILCA, p. 51](lib:rural-dairy-technology#page=51); [🖼️ Practical Action, p. 3](lib:cheese-making-practical-action#page=3)
- 📷 [Yogurt](wiki:Yogurt); [Kefir](wiki:Kefir); [Paneer](wiki:Paneer); [Queso blanco](wiki:White_cheese); [Goat cheese](wiki:Goat_cheese)

**Hard and brined cheese**
- Trying the curd, curd knives, firmness, hot-iron test, draining box — [🖼️ FB 1191, p. 7](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=7); [🖼️ p. 8](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=8); [🖼️ p. 11](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=11); [🖼️ p. 12](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=12)
- Cheese hoop and home-made lever press; screw press — [🖼️ FB 1191, p. 13](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=13); [🖼️ p. 14](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=14); [🖼️ p. 15](lib:usda-farmers-bulletin-1191-making-american-cheese-on-the-farm-1924#page=15); [🖼️ Practical Action, p. 5](lib:cheese-making-practical-action#page=5)
- Halloumi, Domiati and feta step charts — [🖼️ ILCA, p. 53](lib:rural-dairy-technology#page=53); [🖼️ p. 54](lib:rural-dairy-technology#page=54); [🖼️ p. 55](lib:rural-dairy-technology#page=55)
- 📷 [Feta](wiki:Feta); [Halloumi](wiki:Halloumi); [Cheddar cheese](wiki:Cheddar_cheese); [Rennet](wiki:Rennet); [Cardoon](wiki:Cardoon); [Ricotta](wiki:Ricotta); [Brunost](wiki:Brunost); [Cheese fly](wiki:Cheese_fly)

## 🔗 Related guides

- The [Goats guide](guide:GOATS-GUIDE) — the dairy animal: breeds, feed, kidding, mastitis, selenium
- The [Cattle guide](guide:CATTLE-GUIDE) — a family milk cow; the [Sheep guide](guide:SHEEP-GUIDE) — milking ewes
- The [Pigs guide](guide:PIGS-GUIDE) — skim milk and whey for pigs
- The [Bees guide](guide:BEES-GUIDE) — beeswax for coating cheese; the [Chickens guide](guide:CHICKENS-GUIDE) — skim milk, buttermilk and whey for hens
- [Root Cellars & Food Storage](guide:ROOT-CELLAR-GUIDE) — springhouse, evaporative coolers, cellar temperatures for aging
- [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — ice, cold water and insulation numbers for keeping milk cold
- [Preserving Food](guide:PRESERVING-FOOD-GUIDE) and [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — pressure canning, ferments, baking with sour milk
- [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — building a hay-box for yogurt or cold milk
- [Water Purification](guide:WATER-PURIFICATION-GUIDE) — solar pasteurizing; [Water Wells & Springs](guide:WATER-WELLS-GUIDE) — protecting a spring
- [Childbirth & Children](guide:CHILDBIRTH-CHILDREN-GUIDE) and [Food Security](guide:FOOD-SECURITY-GUIDE) — milk for babies and toddlers
- [Nuclear Fallout](guide:NUCLEAR-FALLOUT-GUIDE) — dairy after fallout; [Sanitation](guide:SANITATION-GUIDE) — dairy waste and bears
