# 🧫 How Antibiotics Came To Be, and What It Would Take Again

Where penicillin, the sulfa drugs, streptomycin and insulin came from, how long each one took, what
each one rested on, and what a community would really need before it could make such things again.
This is a history guide, not a recipe. What a household can still do today — the medicines worth
stocking, the plant remedies that genuinely help, wound care without a pharmacy — is in
[Making medicines with no pharmacy](guide:MAKING-MEDICINES-GUIDE). The primary sources are in
`Medical\History-of-Medicine` (Osler's 1920 textbook, the 1917 childbed-fever report, Fleming's 1929
paper, the Toronto insulin lectures of 1923, the 1937 report on the elixir deaths, the USDA's
penicillin exhibit, a 1920 pharmacy bacteriology text), with the modern counts in
`Medical\Medicines` and `Medical\Where There Is No Doctor`.

> ### The short version
> - **Ordinary infections killed, and nothing could be done.** In 1917 pneumonia alone killed 112,821
>   Americans — 149.8 for every 100,000 ([Osler, p. 108](lib:osler-the-principles#page=108)), and
>   tuberculosis took about one death in ten ([p. 186](lib:osler-the-principles#page=186)).
> - **These medicines were not invented by clever people alone.** They took whole countries, a war,
>   and years: penicillin took **15 years** from the mould to the first factory output, and the US
>   government and industry built about **$30 million** of new plant to do it
>   ([History of penicillin](wiki:History_of_penicillin)).
> - **Making an injectable medicine at home or in a village is far more likely to poison than to
>   cure.** In 1937 one untested liquid sulfa medicine killed **93 people in 15 states**, most of
>   them children ([Elixir report, p. 7](lib:elixir-sulfanilamide#page=7)).
>   **Nothing made this way should ever be injected.** Nothing in this guide tells you how.
> - **The knowledge that matters is already written down.** Keep the books: on paper, dry, more than
>   one copy, in more than one place. A future community with a real laboratory will work from the
>   original papers, not from a summary like this one.
> - **The last antibiotics you have are a one-time inheritance.** Full course, every time; only when
>   truly needed; never for a cold; never share half a course
>   ([WTND, p. 56](lib:where-there-is-no-doctor-07-antibiotics#page=2)).
> - **Prevention is the lever you actually have.** Childbed fever was beaten by clean hands sixty
>   years before antibiotics existed: from 3 or 4 deaths in every 100 women to fewer than 1 in 400
>   ([Children's Bureau, pp. 16–17](lib:maternal-mortality-from-all#page=16)).

---

## ☠️ What it was like before

Everyone alive today grew up after antibiotics. It is hard to picture what that changed. The best
way to see it is to open a medical textbook written just before: William Osler's *Principles and
Practice of Medicine*, the standard book of its day, in its 1920 edition. It is a careful, honest
book by the best doctor of his generation, and page after page it says, in effect, *we can nurse
this person but we cannot cure them*.

| What killed people | What the books said |
|---|---|
| **Pneumonia** | "One of the most widespread and fatal of all acute diseases": 112,821 US deaths in 1917, **149.8 for every 100,000 people** ([Osler, p. 108](lib:osler-the-principles#page=108)). At Johns Hopkins, 658 cases and **200 deaths — 30.4 per cent** ([p. 128](lib:osler-the-principles#page=128)). Osler's treatment chapter opens: "Pneumonia is a self-limited disease" ([p. 131](lib:osler-the-principles#page=131)) — you waited |
| **Tuberculosis** | "His most universal scourge": "at least one-eighth of all deaths" by Osler's estimate, and about **one death in ten** in the United States. The US rate was **201.9 per 100,000 in 1900** and 116.4 in 1917 ([Osler, p. 186](lib:osler-the-principles#page=186)). The treatment was fresh air, food and rest |
| **Childbed fever** (puerperal septicemia) | A wound infection caught at birth. In hospitals before clean birth it killed **3 to 4 of every 100 women**, "sometimes it reached 10 to 20 per cent and even over 50 per cent during short periods of epidemics" ([Children's Bureau, p. 16](lib:maternal-mortality-from-all#page=16)). In 1913 it still killed about **7,000 American women in one year**, out of 15,376 deaths from childbirth ([p. 20](lib:maternal-mortality-from-all#page=20)) |
| **Blood poisoning from a wound** | Streptococcus and staphylococcus spreading from "puerperal septicaemia or in dissection wounds" along the lymph vessels ([Osler, p. 82](lib:osler-the-principles#page=82)). For infection of the heart valves, Osler wrote that treatment "is practically that of septicemia — useless and hopeless in a majority of the cases" ([p. 829](lib:osler-the-principles#page=829)) |
| **Typhoid fever** | **35.9 per 100,000 in 1900, 13.4 in 1917** ([Osler, p. 32](lib:osler-the-principles#page=32)) — a fall caused by clean water and clean food, not by medicine |
| **Type 1 diabetes** | "The younger the patient the less likely is recovery. In children the disease may run a very rapid course, and death may occur within a few weeks" ([Osler, p. 460](lib:osler-the-principles#page=460)). The only treatment was a near-starvation diet |

![Bar chart of United States deaths a year for every 100,000 people before antibiotics: tuberculosis 201.9 in 1900 and 116.4 in 1917, pneumonia 149.8 in 1917, typhoid fever 35.9 in 1900 and 13.4 in 1917, childbirth 15.8 in 1913; below, childbed fever in maternity hospitals, 3 to 4 deaths in every 100 women before clean birth, up to 50 in 100 during an outbreak, and fewer than 1 in 400 afterwards](img:MEDICINE-HISTORY-GUIDE/deaths-before-antibiotics.svg)
*What the numbers looked like before antibiotics, and what clean hands alone did to childbed fever ([Osler, pp. 32, 108, 186](lib:osler-the-principles#page=108); [Children's Bureau, pp. 16–17](lib:maternal-mortality-from-all#page=16); a chart drawn for this guide).*

**Notice the pattern in that table.** Two of the biggest killers — typhoid and childbed fever — were
already falling fast *before* any antibiotic existed, because of clean water, clean food, clean
hands and clean instruments. That is the single most useful fact in this guide, and the last
section comes back to it.

📚 **Go deeper:** [Osler's textbook](lib:osler-the-principles#page=15) — 1,200 pages of what medicine
could and could not do in 1920; [the 1917 childbed-fever report](lib:maternal-mortality-from-all#page=13).

## 🧪 The stories: who, when, and how long

### 1928–1929: Fleming's mould, and the decade it sat still
<!-- fold: A contaminated plate in London, a paper nobody acted on, and why the stuff would not keep -->

Alexander Fleming worked at St Mary's Hospital in London. In 1928 he came back to a bench of culture
plates that had been left out and "noticed that around a large colony of a contaminating mould the
staphylococcus colonies became transparent and were obviously undergoing lysis" — they were
dissolving ([Fleming 1929, p. 1](lib:fleming-on-the-antibacterial#page=1)). He named the substance
the mould made **penicillin** on 7 March 1929 and his paper was published that June
([History of penicillin](wiki:History_of_penicillin)).

![Fleming's own photograph from his 1929 paper: a culture plate, the large pale penicillium colony at the top, scattered round staphylococcal colonies below, and the ones nearest the mould dissolving away, with the three labelled by hand](img:MEDICINE-HISTORY-GUIDE/fleming-plate-1929.png)
*The picture that started it, from Fleming's own paper ([Fleming 1929, p. 10](lib:fleming-on-the-antibacterial#page=10)).*

He saw what it might be for. His own summary suggests "that it may be an efficient antiseptic for
application to, or injection into, areas infected with penicillin-sensitive microbes", and notes
that it is "non-irritant and non-toxic"
([Fleming 1929, pp. 9–10](lib:fleming-on-the-antibacterial#page=9)).

**Then nothing happened for eleven years.** The reason is in the same paper: "Penicillin loses most
of its power after 10 to 14 days at room temperature"
([p. 9](lib:fleming-on-the-antibacterial#page=9)). Broth that goes weak in a fortnight is not a
medicine. Getting the active substance out of the broth and keeping it was a chemistry problem
nobody solved for a decade, and the people who tried gave up or moved on
([History of penicillin](wiki:History_of_penicillin); [Alexander Fleming](wiki:Alexander_Fleming)).

### 1932–1937: the sulfa drugs, and the price of skipping the safety test

In Germany, **Gerhard Domagk** and the chemists Josef Klarer and Fritz Mietzsch, at the Bayer works
of IG Farben, tested dye after dye against infections in mice. In late 1932 one of them, Prontosil,
worked. Clinical testing ran from 1932 to 1934, and the results were published on 15 February 1935
([Prontosil](wiki:Prontosil)). Within months it was being used against childbed fever in London, and
the Pasteur Institute in Paris showed in November 1935 that the body breaks Prontosil down into a
much simpler substance, **sulfanilamide**, which was the part that worked and which nobody owned
([Prontosil](wiki:Prontosil); [Sulfanilamide](wiki:Sulfanilamide)). Domagk was given the Nobel Prize
in 1939. For the first time there was a medicine you could swallow that stopped a spreading bacterial
infection.

Cheap, unpatented and in demand — and in 1937 that killed people. The S. E. Massengill Company of
Bristol, Tennessee wanted sulfanilamide in a liquid a child could drink. Their chemist dissolved it
in a sweet industrial solvent — **diethylene glycol**, the stuff of antifreeze, which is a poison.
The Secretary of Agriculture's report to the Senate says it plainly:

> "During September and October of 1937 at least 73 persons died as a direct result of taking the
> drug known as 'Elixir Sulfanilamide'. Twenty other persons who took the 'elixir' died ... The 93
> deaths occurred in 15 States, as far east as Virginia, as far west as California ... Before the
> 'elixir' was put on the market, it was tested by the firm for flavor but not for its effect"
> ([Elixir report, p. 7](lib:elixir-sulfanilamide#page=7)).

Only 240 gallons were ever made. The first warning reached the government on 14 October 1937, by
telephone; the next day an inspector in Tulsa found nine deaths there, eight of them children
([pp. 7, 10](lib:elixir-sulfanilamide#page=10)). The report's judgement is the one sentence worth
carrying out of this whole guide:

> "The fatal 'elixir' was rushed onto the market without adequate test to determine whether or not
> diethylene glycol may be safely used as a solvent for sulfanilamide, despite previously published
> reports in scientific literature showing that diethylene glycol might be dangerous when taken
> internally. A few simple and inexpensive tests on experimental animals would have quickly
> demonstrated the toxic properties" ([Elixir report, p. 8](lib:elixir-sulfanilamide#page=8)).

Out of those deaths came the US Federal Food, Drug, and Cosmetic Act of 1938, which for the first
time made a maker prove a medicine was safe before selling it
([Elixir sulfanilamide](wiki:Elixir_sulfanilamide);
[the 1938 Act](wiki:Federal_Food,_Drug,_and_Cosmetic_Act)).

**This is the reason this guide is a history and not a recipe.** The people who made that elixir had
a real factory, trained chemists, a laboratory and the published literature. They still killed 93
people, because they skipped one test. A kitchen, a shed or a village workshop has none of what they
had — and the same solvents, the same guesswork, and nobody to notice for weeks.

### 1939–1941: Oxford, and the first patient
<!-- fold: A small team, a handful of money, a policeman called Albert Alexander, and penicillin recovered from his urine -->

At Oxford, **Howard Florey**, **Ernst Chain** and **Norman Heatley** went back to Fleming's paper
and took on the problem he had left: getting the substance out and keeping it. Their money was
small — the Medical Research Council gave £250 to start, plus £300 a year for salaries and £100 a
year for expenses, for three years; the Rockefeller Foundation added US$5,000 a year for five years
([History of penicillin](wiki:History_of_penicillin)).

They grew the mould in whatever would hold it, and had 500 ceramic vessels made by a pottery in
Burslem; Heatley collected the first 174 of them on 22 December 1940. Two women were hired at £2 a
week to tend them ([History of penicillin](wiki:History_of_penicillin)).

The animal test came first. On 1 July 1940 all 25 untreated mice were dead within 16 hours, while
all but one of the 25 treated mice were alive ten days later
([History of penicillin](wiki:History_of_penicillin)).

The first patient treated for an infection was **Albert Alexander**, a policeman, on 12 February
1941 — 200 mg, then 100 mg every three hours. He began to recover. Then the penicillin ran out. The
team collected his urine and took the penicillin back out of it to give him again. It was not
enough. He relapsed in early March and died on 15 March 1941. Afterwards Florey turned to treating
children, because they needed smaller amounts
([History of penicillin](wiki:History_of_penicillin); [Howard Florey](wiki:Howard_Florey);
[Norman Heatley](wiki:Norman_Heatley)).

**Hold that in mind.** A university laboratory in a rich country, working flat out for two years with
trained chemists, could not make enough of this medicine to save one policeman.

### 1941–1945: the farm laboratory, and the jump to a factory
<!-- fold: Peoria, corn steep liquor, a mould off a market cantaloupe, and what one year of wartime penicillin took -->

Britain was being bombed and had no spare factories. On 27 June 1941 Florey and Heatley flew to the
United States, and on 14 July they reached the US Department of Agriculture's Northern Regional
Research Laboratory at **Peoria, Illinois** — a farm laboratory, set up to find uses for crop
leftovers ([History of penicillin](wiki:History_of_penicillin)).

That was the turn. Three things there changed penicillin from a laboratory curiosity into an
industrial product, over about two years:

- **A better broth.** Andrew Moyer tried **corn steep liquor**, a waste liquid from milling corn
  that the laboratory had been looking for a use for. Yield went up about **tenfold**
  ([History of penicillin](wiki:History_of_penicillin)).
- **A better mould.** The laboratory collected and tested moulds from everywhere. The best came off
  a **cantaloupe melon bought in a Peoria market in 1943** — the strain the USDA's own exhibit board
  lists as *Penicillium chrysogenum* NRRL 1951.B25, alongside the two *P. notatum* strains used
  before it ([USDA exhibit, p. 8](lib:exhibit-pictures-from-the-four#page=8);
  [Penicillium chrysogenum](wiki:Penicillium_chrysogenum)).
- **Growing it in deep tanks instead of in flat trays**, which is what let a chemical works make it
  by the ton rather than a laboratory by the spoonful
  ([Industrial fermentation](wiki:Industrial_fermentation)).

Then the whole country was put behind it. Twenty-one firms made penicillin during the war. The
government built six plants for $7.6 million and industry built sixteen more for $22.6 million.
Output went from **21 billion units in 1943 to 1,663 billion in 1944 and about 6,852 billion in
1945**, and the price fell from **$200 per million units in 1943 to $6 in 1945**
([History of penicillin](wiki:History_of_penicillin)).

The USDA's own exhibit board puts one year of that in plain numbers. **Penicillin production for
1945** took, as raw materials, **5,000,000 lb of lactose (milk sugar)** and **12,000,000 lb of corn
steep liquor**, and produced **4,000 billion units of commercial-grade penicillin — "enough for
4,000,000 hospital cases"** ([USDA exhibit, p. 8](lib:exhibit-pictures-from-the-four#page=8)).

Eight and a half thousand tons of milling waste and milk sugar, for four million courses. That is
the real exchange rate between farming, industry and antibiotics, and it is why a village cannot
do this.

### 1943: streptomycin, out of the dirt

Penicillin did nothing against tuberculosis. **Selman Waksman**'s laboratory at Rutgers had spent
years working through soil organisms looking for ones that kill other germs — he is the man who
gave the word **antibiotic** its modern meaning. On **19 October 1943** his PhD student **Albert
Schatz** isolated **streptomycin** from a soil organism, and the team reported it in January 1944.
Elizabeth Bugie was second author on the paper. The laboratory found more than fifteen antibiotics
in all; only a few were ever any use in people
([Streptomycin](wiki:Streptomycin); [Selman Waksman](wiki:Selman_Waksman)).

The early patients show how rough it was: at an army hospital at the end of the war the first
patient died and the second went blind; the third recovered. Britain's Medical Research Council then
ran what is usually counted as the first properly **randomised** trial in medicine, streptomycin
against bed rest alone for tuberculosis. It worked — and it also showed, straight away, **bacteria
acquiring resistance to it** ([Streptomycin](wiki:Streptomycin);
[Randomised controlled trial](wiki:Randomized_controlled_trial)). Waksman was given the Nobel Prize
in 1952 "for his discovery of streptomycin, the first antibiotic active against tuberculosis".

Two lessons sit in that paragraph, and both still matter. **A medicine that cures can also blind or
kill** — which is why the books insist streptomycin is used only for tuberculosis and always with
other medicines ([WTND, p. 57](lib:where-there-is-no-doctor-07-antibiotics#page=3)). And **resistance
turned up in the very first proper trial**, within months of the first dose.

### 1921–1923: insulin, the fastest of them all

Insulin is the exception that shows what the other stories were missing. Before it, a child with
type 1 diabetes died, usually within weeks or months ([Osler, p. 460](lib:osler-the-principles#page=460)).

Frederick Banting, a surgeon with an idea, worked in John Macleod's physiology laboratory at the
University of Toronto with a student, Charles Best. Macleod's own account, given as two lectures in
January 1923 and published that year, records the first success: **"On July 31, 1921, the first
degenerated gland extract was injected into a diabetic dog"**. "This injection was followed by a
reduction in blood sugar from .20 to .11 in one hour", and the animal became sugar-free
([Macleod 1923, p. 68](lib:macleod-and-banting#page=68)).

What turned that into a medicine was the chemist **James Collip**, who joined "about this time,
January, 1922" and made a cleaner extract, and the **Connaught Laboratories**, which could make it in
quantity ([Macleod 1923, p. 71](lib:macleod-and-banting#page=71)). The first patient was **Leonard
Thompson, fourteen years old**, at Toronto General Hospital on **11 January 1922**
([Frederick Banting](wiki:Frederick_Banting)). Of those first ward cases Macleod wrote that "the
percentage of sugar in the blood could be reduced to normal, the urine could be rendered sugar-free,
that acetone bodies disappeared, and that patients gave evidences of marked clinical improvement"
([Macleod 1923, p. 71](lib:macleod-and-banting#page=71)).
Banting and Macleod were given the Nobel Prize for 1923, and each split his share — Banting with
Best, Macleod with Collip ([Macleod 1923, p. 10](lib:macleod-and-banting#page=10);
[Frederick Banting](wiki:Frederick_Banting)).

**From the first dog to insulin on sale took about two years.** Why so much faster than penicillin?
Because insulin is taken out of an animal that already makes it — a pancreas from a slaughterhouse —
rather than coaxed out of a living mould and then purified. The hard parts were still hard: every
batch had to be tested for strength before it could be given to a person, because the extract was
never twice the same ([Macleod 1923, p. 73](lib:macleod-and-banting#page=73)), and an injected
extract that is not clean enough causes abscesses and worse *(rule of thumb)*. Even in Toronto the
work had to stop for about three months when the move from small batches to large ones went wrong
([Macleod 1923, p. 71](lib:macleod-and-banting#page=71)).

> **⚠️ Insulin is the one people ask about, so say it plainly.** Insulin is a protein. It is destroyed
> by the gut, so it must be injected. An extract made without a laboratory cannot be made clean
> enough, cannot be measured for strength, and cannot be kept sterile. Injecting it would very likely
> kill the person faster than the diabetes. What *can* be done for someone running out of insulin is
> in [Chronic Illness](guide:CHRONIC-ILLNESS-GUIDE) ("Type 1: insulin without a fridge"), including
> how to make the supply last and how to care for someone when it is gone.

![Timeline from 1920 to 1950 showing four medicines as bars from the first finding, through the first patient, to factory supply: insulin 1921 to 1923 about two years; the sulfa drugs 1932 to 1937 about five years, with a mark for the 93 people killed in 1937 by an untested liquid; penicillin 1928 to 1945, fifteen years, with the first patient in February 1941; streptomycin 1943 to 1948, about five years](img:MEDICINE-HISTORY-GUIDE/from-discovery-to-supply.svg)
*Discovery is the short part. Getting enough of it to go round is the long part (dates from the sources cited above; a chart drawn for this guide).*

## 🏭 What it would actually take again

Each of those stories rests on a base that nobody writing the story bothers to mention, because in
1940 it was simply there. Here it is, written out.

| What it took | What that actually means | Where you can see it |
|---|---|---|
| **A country, not a village** | Twenty-one firms, six government plants at $7.6 million and sixteen private ones at $22.6 million, in the middle of a world war | [History of penicillin](wiki:History_of_penicillin) |
| **A farming surplus behind it** | 5,000,000 lb of milk sugar and 12,000,000 lb of corn milling waste, in one year, for four million courses | [USDA exhibit, p. 8](lib:exhibit-pictures-from-the-four#page=8) |
| **Years, not months** | 15 years for penicillin; about 5 for the sulfa drugs and for streptomycin; 2 for insulin, and that was the easy one | The chart above |
| **Money from outside** | Oxford ran on £250 plus £300 a year, and US$5,000 a year from a foundation — grants, not sales | [History of penicillin](wiki:History_of_penicillin) |
| **Trained people, many of them** | A surgeon, a physiologist, a student and a biochemist in Toronto; a pathologist, a biochemist and a man who could build whatever they needed at Oxford; mycologists, chemists and engineers at Peoria | The sections above |
| **Clean water, steady power and heat you can hold to a degree** | Everything in these stories was grown, filtered, dried and kept at controlled temperatures, around the clock, for weeks at a time *(rule of thumb)* | — |
| **Glass, metal and a microscope** | Oxford grew its mould in 500 ceramic vessels ordered specially from a pottery; Heatley collected the first 174 by hand | [History of penicillin](wiki:History_of_penicillin) |
| **Chemical supply** | Pure solvents and reagents, in quantity, made by somebody else, to a known strength *(rule of thumb)* | — |
| **A way to know how strong a batch is** | Insulin had to be tested batch by batch before anyone could be dosed | [Macleod 1923, p. 73](lib:macleod-and-banting#page=73) |
| **A safety test before a human being** | The one step that was skipped in 1937, and 93 people died | [Elixir report, p. 8](lib:elixir-sulfanilamide#page=8) |

> ### ⛔ The honest warning
> - **Never inject anything made outside a pharmaceutical factory.** Not a plant extract, not a mould
>   broth, not an animal extract, not a dissolved tablet of unknown age. Injection skips every defence
>   the body has. What is harmless to swallow can kill when injected.
> - **Growing a mould on bread or fruit and putting it on a wound is not penicillin**, it is a mixed
>   culture of unknown moulds and bacteria of unknown strength, going into broken skin. Fleming's own
>   broth lost most of its strength in ten to fourteen days
>   ([Fleming 1929, p. 9](lib:fleming-on-the-antibacterial#page=9)) — and he had a laboratory, a pure
>   strain and a microscope to check it with.
> - **The failure mode is not "it doesn't work", it is "it poisons them".** Sulfanilamide was a good
>   medicine; the liquid that carried it killed 93 people, most of them children
>   ([Elixir report, p. 7](lib:elixir-sulfanilamide#page=7)).
> - **This guide deliberately gives no methods.** No sterile technique, no growing media, no choosing
>   or improving strains, no extraction, no purification, no testing for strength, no scaling up and
>   no chemistry. That is not squeamishness: a half-remembered method is exactly how people get
>   poisoned. A community that one day has a real laboratory, trained people and the books will work
>   from the original papers — which is why the next section matters more than this one.

## 📚 Keeping the knowledge

A summary like this one is not the knowledge. It is a map of where the knowledge is. The job now is
to make sure the real thing survives — on paper, in more than one copy, in more than one building.

### What this library already holds

| Folder | What is in it, and why it matters |
|---|---|
| `Medical\History-of-Medicine` | [Fleming's 1929 paper](lib:fleming-on-the-antibacterial#page=1) in full, with his photograph of the plate; [Macleod and Banting's 1923 lectures](lib:macleod-and-banting#page=5) on how insulin was found and first given; [Osler's 1920 textbook](lib:osler-the-principles#page=15), the whole of medicine before antibiotics; the [1917 childbed-fever report](lib:maternal-mortality-from-all#page=13); the [1937 elixir report](lib:elixir-sulfanilamide#page=7); the [USDA's penicillin exhibit](lib:exhibit-pictures-from-the-four#page=8); and Schneider's 1920 *Pharmaceutical Bacteriology*, a pharmacist's account of [how germ theory was arrived at](lib:schneider-pharmaceutical-bacteriology#page=19), of [sterilising and disinfecting](lib:schneider-pharmaceutical-bacteriology#page=335), and of [how sera and vaccines were made in 1920](lib:schneider-pharmaceutical-bacteriology#page=272) |
| `Medical\Medicines` | The WHO Model Formulary, the WHO essential medicines lists and MSF's *Essential Drugs*: what each medicine is for, what dose, what it must not be used with. The [WHO antibiotic resistance report for 2025](lib:who-global-antibiotic-resistance#page=16) says which germs still answer to what |
| `Medical\Where There Is No Doctor` | Chapter 7, [*Antibiotics: what they are and how to use them*](lib:where-there-is-no-doctor-07-antibiotics#page=1), and the Green Pages: doses, dangers, and which antibiotic suits which illness |
| `Medical\Field-Care\Nursing-Care` | The WHO–PAHO manual on cleaning, disinfecting and sterilising instruments — and on why boiling is not sterilisation |
| The offline Wikipedia | The whole encyclopedia, including the chemistry and microbiology articles: [How to use Kiwix](guide:HOW-TO-USE-KIWIX) |

### Worth adding if you ever find them

Add them to the drive, and print the short ones: Florey and Chain's two *Lancet* papers of 1940 and
1941 (the mouse experiment and the first patients); Schatz and Waksman's 1944 streptomycin paper;
Banting and Best's own 1922 papers; a modern microbiology textbook; a clinical microbiology
laboratory manual (how to identify a germ and test which medicine it answers to); a pharmacopoeia
(the official standards a medicine must meet); and any chemistry textbook at university level.
Second-hand bookshops, closing clinics, school and college clear-outs and estate sales are where
these turn up.

### How to keep them

- **Paper beats everything.** A printed book needs no power, no screen and no file format. Print the
  short, important things: the chapter on antibiotics, the dose tables, the sterilising instructions.
  How, with what you have: [Paper & Ink](guide:PAPER-INK-GUIDE).
- **More than one copy, in more than one place.** A fire, a flood or a theft takes a single copy. Two
  copies in two buildings, ideally two households *(rule of thumb)*.
- **Dry, dark, cool, off the floor, in something a rat cannot chew.** Damp and mould destroy paper
  faster than time does. Storage that works: [Root Cellar](guide:ROOT-CELLAR-GUIDE)
  ("Keeping rats, mice and bugs out").
- **Keep a drive and a Vault too, but don't trust them alone.** Flash memory fades and devices die;
  a book does not. [The ARK Vault](guide:AMMO-CAN-COMPUTER-GUIDE), [Get the library](guide:GET-THE-LIBRARY).
- **Write down what you learn.** If anyone in your community treats infections, keep a plain log: who,
  what was given, how much, for how long, and what happened. That record is worth more to the next
  generation than any summary *(rule of thumb)*.

## 🦠 Why antibiotics stop working

Bacteria that survive a dose breed, and their offspring survive it too. "When an antibiotic is used
too often, the bacteria will get used to it instead of being killed by it. They become resistant to
the antibiotic" ([WTND, p. 58](lib:where-there-is-no-doctor-07-antibiotics#page=4)). This is not a
theory about the future; it is happening now and it is getting worse.

- In 2023, **about one in six** laboratory-confirmed bacterial infections worldwide were caused by
  bacteria resistant to the antibiotics used against them — about **one in three** urinary infections
  and **one in six** bloodstream infections
  ([WHO AMR 2025, p. 16](lib:who-global-antibiotic-resistance#page=16)).
- Resistance **rose in 40 per cent** of the germ-and-antibiotic pairs WHO tracks between 2018 and
  2023, by 5 to 15 per cent a year
  ([WHO AMR 2025, p. 17](lib:who-global-antibiotic-resistance#page=17)).
- Bacterial resistance was linked to about **1.14 million deaths in 2021**; the wider figure WHO
  works from is **4.95 million deaths associated with it in 2019**, which the world has agreed to
  try to cut by a tenth by 2030 ([WHO AMR 2025, p. 24](lib:who-global-antibiotic-resistance#page=24)).
- When the resistant ones do cause a bloodstream infection, they kill: 30-day death rates **over 50
  per cent** for some carbapenem-resistant germs, over 40 per cent for another, over 20 per cent for
  MRSA ([WHO AMR 2025, p. 48](lib:who-global-antibiotic-resistance#page=48)).

**After a collapse there will be no new antibiotics.** What is on the shelf is the whole inheritance,
and every careless dose spends a little of it for everyone, not just for the person taking it. The
rules below come straight out of the library's own books, and they are not optional.

| Rule | Why |
|---|---|
| **Finish the whole course, every time** | "Antibiotics must be taken for their full course. Stopping before you have finished all the days of treatment, even if you feel better, can make the infection return in a form that is even harder to cure" ([WTND, p. 56](lib:where-there-is-no-doctor-07-antibiotics#page=2)) |
| **Only for an infection an antibiotic is known to help** | "Antibiotics do no good for the common cold" ([WTND, p. 57](lib:where-there-is-no-doctor-07-antibiotics#page=3)). Colds, flu and most diarrhoea are not helped and may be made worse ([p. 58](lib:where-there-is-no-doctor-07-antibiotics#page=4)) |
| **Never share out half a course** | A half course for two people treats neither and breeds resistance in both *(rule of thumb; follows from the full-course rule above)* |
| **The right dose: "no more, no less"** | The dose depends on the illness and on the person's age or weight ([WTND, p. 56](lib:where-there-is-no-doctor-07-antibiotics#page=2)) |
| **The narrowest one that will do** | Don't use a broad-spectrum antibiotic where a narrow one will work (same page) |
| **By mouth unless injection is truly necessary** | "Never use injections of antibiotics if taking them by mouth is likely to work as well" (same page) |
| **Don't use one for a minor infection the body will win by itself** | Minor skin infections: soap, water and hot soaks. Minor chest colds: fluids, food and rest ([WTND, p. 58](lib:where-there-is-no-doctor-07-antibiotics#page=4)) |
| **If it isn't working in a day or two, think again** | Wrong illness, wrong dose, or the germ is already resistant — don't just carry on ([WTND, p. 57](lib:where-there-is-no-doctor-07-antibiotics#page=3)) |

Doses, which antibiotic for which illness, allergy and what to keep: [Chronic Illness](guide:CHRONIC-ILLNESS-GUIDE),
[Medical books & found medicines](guide:Medical-READ-ME-FIRST) and
[Making medicines with no pharmacy](guide:MAKING-MEDICINES-GUIDE).

## 🧼 Prevention is the lever you actually have

You cannot make penicillin. You can stop most of the infections it would have been used for, with
work you can do this week. Every one of these was proved before antibiotics existed, and each has its
own guide — this one does not repeat them.

| What to do | Why it works | Where |
|---|---|---|
| **Clean drinking water** | Typhoid fell from 35.9 to 13.4 deaths per 100,000 between 1900 and 1917 on clean water and clean food alone ([Osler, p. 32](lib:osler-the-principles#page=32)) | [Water Purification](guide:WATER-PURIFICATION-GUIDE) |
| **Wash hands, and keep human waste away from water and food** | Typhoid travels from human waste into water and food; childbed fever was a wound infection carried on hands ([Children's Bureau, p. 16](lib:maternal-mortality-from-all#page=16); [Ignaz Semmelweis](wiki:Ignaz_Semmelweis), [Joseph Lister](wiki:Joseph_Lister)) | [Sanitation](guide:SANITATION-GUIDE) |
| **Clean every wound properly, and leave a dirty one open** | Wound infection becomes blood poisoning, which Osler called "useless and hopeless" to treat ([p. 829](lib:osler-the-principles#page=829)) | [Field Care](guide:FIELD-CARE-GUIDE) |
| **Clean hands, clean instruments and clean cloth at every birth** | Hospital deaths from childbed fever fell from 3 or 4 in 100 to fewer than 1 in 400: "only 1 woman now dies as compared with 15 or 20 formerly" ([Children's Bureau, p. 17](lib:maternal-mortality-from-all#page=17)) | [Childbirth & Children](guide:CHILDBIRTH-CHILDREN-GUIDE) |
| **Keep food safe, and keep people fed** | Osler lists hardship, cold, crowding and poor food as what made pneumonia and tuberculosis fatal ([pp. 109, 190](lib:osler-the-principles#page=109)) | [Preserving Food](guide:PRESERVING-FOOD-GUIDE), [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE) |
| **Keep vaccinations up to date while you still can, and don't let a chronic illness go untreated** | In 1913 childbirth "caused more deaths among women 15 to 44 years old than any disease except tuberculosis" ([Children's Bureau, p. 13](lib:maternal-mortality-from-all#page=13)); a body already weakened loses to the infection | [Chronic Illness](guide:CHRONIC-ILLNESS-GUIDE), [Making medicines with no pharmacy](guide:MAKING-MEDICINES-GUIDE) |

**One more time, because it is the whole point:** by 1917, before any antibiotic existed, clean hands
at a birth had already cut hospital deaths from childbed fever by a factor of fifteen or twenty, and
clean water had cut typhoid deaths by more than half. Nobody needed a factory for that. They needed to
know, and then to do it every single time.

## ⚠️ Old advice in the library to ignore

The history books added for this guide were written in 1920, 1923 and 1937, and they are kept because
of what they record, not as instructions. Treat the medicine in them as history.

| The book says | Do this instead |
|---|---|
| Osler's remedies of 1920 — for smallpox, "We have no specific treatment"; what he offers is fresh air, cold drinks and "a calomel and saline purge" ([Osler, p. 359](lib:osler-the-principles#page=359)) | Use the modern books for treatment: the WHO formulary, MSF *Essential Drugs*, *Where There Is No Doctor* ([Medical books & found medicines](guide:Medical-READ-ME-FIRST)) |
| Fleming's own suggestion that mould broth "may be an efficient antiseptic for application to, or injection into" infected areas ([Fleming 1929, p. 10](lib:fleming-on-the-antibacterial#page=10)) | True of pure penicillin, written before anyone could make any. **Never put a home-grown mould on a wound or into a body.** Clean the wound instead ([Field Care](guide:FIELD-CARE-GUIDE)) |
| The insulin doses and strengths in the 1923 lectures ([Macleod 1923, p. 73](lib:macleod-and-banting#page=73)) | A unit of insulin was defined differently then. Use the modern labels and the modern books ([Chronic Illness](guide:CHRONIC-ILLNESS-GUIDE)) |
| Schneider's 1920 chapter on making sera and vaccines ([Schneider 1920, p. 272](lib:schneider-pharmaceutical-bacteriology#page=272)) | History, and a record of what a real laboratory did. Not something to attempt |
| Anything that treats a medicine as safe because it is "natural" or because it was once sold | Sulfanilamide was a real medicine, and the liquid it was sold in killed 93 people ([Elixir report, p. 7](lib:elixir-sulfanilamide#page=7)) |

## 🖼️ Pictures & diagrams

🖼️ = pictures in the books on this drive; the plain links open photos in the offline Wikipedia.

- **The discovery:** [🖼️ Fleming's own photograph of the plate, 1929](lib:fleming-on-the-antibacterial#page=10); [Alexander Fleming](wiki:Alexander_Fleming); [Penicillin](wiki:Penicillin); [Penicillium chrysogenum](wiki:Penicillium_chrysogenum)
- **Making it:** [🖼️ the USDA's penicillin exhibit board, with the three mould strains and the 1945 figures](lib:exhibit-pictures-from-the-four#page=8); [Corn steep liquor](wiki:Corn_steep_liquor); [Industrial fermentation](wiki:Industrial_fermentation); [History of penicillin](wiki:History_of_penicillin)
- **The people:** [Howard Florey](wiki:Howard_Florey); [Ernst Chain](wiki:Ernst_Chain); [Norman Heatley](wiki:Norman_Heatley); [Gerhard Domagk](wiki:Gerhard_Domagk); [Selman Waksman](wiki:Selman_Waksman); [Frederick Banting](wiki:Frederick_Banting)
- **Before antibiotics:** [🖼️ Osler on pneumonia](lib:osler-the-principles#page=108) and [on tuberculosis](lib:osler-the-principles#page=186); [🖼️ the childbed-fever tables of 1917](lib:maternal-mortality-from-all#page=20); [Tuberculosis](wiki:Tuberculosis); [Postpartum infections](wiki:Postpartum_infections); [Sepsis](wiki:Sepsis)
- **What went wrong in 1937:** [🖼️ the Secretary of Agriculture's report](lib:elixir-sulfanilamide#page=7); [Elixir sulfanilamide](wiki:Elixir_sulfanilamide); [the 1938 Act](wiki:Federal_Food,_Drug,_and_Cosmetic_Act)
- **Resistance now:** [🖼️ WHO's 2025 charts of what still works](lib:who-global-antibiotic-resistance#page=54); [Antimicrobial resistance](wiki:Antimicrobial_resistance); [Hand washing](wiki:Hand_washing)

---

## 🔗 Related guides

- [Making medicines with no pharmacy](guide:MAKING-MEDICINES-GUIDE) — what a household can actually do now: what to stock, what plants really do, what does not work
- [Medical books & found medicines](guide:Medical-READ-ME-FIRST) — which book to open first, identifying pills, expired medicines, storage
- [Chronic Illness](guide:CHRONIC-ILLNESS-GUIDE) — insulin and the other daily medicines, making a supply last, and when someone can no longer be kept well
- [Field Care](guide:FIELD-CARE-GUIDE) — wounds, infection and sepsis: the things antibiotics were invented for
- [Childbirth & Children](guide:CHILDBIRTH-CHILDREN-GUIDE) — clean birth, the single biggest win in this whole guide
- [Water Purification](guide:WATER-PURIFICATION-GUIDE) and [Sanitation](guide:SANITATION-GUIDE) — the two levers that beat typhoid without any medicine at all
- [Paper & Ink](guide:PAPER-INK-GUIDE) and [Root Cellar](guide:ROOT-CELLAR-GUIDE) — printing what matters, and keeping paper dry for decades
- [Get the library](guide:GET-THE-LIBRARY) and [The ARK Vault](guide:AMMO-CAN-COMPUTER-GUIDE) — a second and third copy of everything
- [How to use Kiwix](guide:HOW-TO-USE-KIWIX) — the offline encyclopedia, where the chemistry and microbiology articles live
