# 🦌 Hunting, Trapping & Fishing for Food

How to put wild meat and fish on the table year after year without emptying the hills and rivers: why
the rules exist, local game and its habits, clean shooting and tracking, field dressing and cooling meat
in our heat, butchering and using the whole animal, traps, snares and deadfalls, fishing, nets and fish
traps, crawfish, mussels and lamprey, and the diseases that come with wild meat. The books are in
`Hunting\` (`How-To`, `Game-Species`, `Butchering-Meat-Care`, `Disease-Safety`), `Trapping\`
(`Disease-Safety`, `Hides-Tanning`) and `Fishing\` (`How-To`, `Nets-Traps`, `Mussels-Lamprey`,
`Shellfish-Safety`), with survival manuals in `Manuals\ArmyFieldManuals`. **Seasons, hunting units,
local waters and trapping rules are on [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE).**

> ### ⚠️ Rules that prevent the worst outcomes
> - **Be sure of your target and what is beyond it.** Bullets pass through game and keep killing. Never
>   shoot at a sound, a color or movement.
> - **Cook all wild meat through.** Bear, cougar, raccoon and beaver can carry trichinella worms that
>   survive freezing, smoking and drying.
> - **Wear gloves to skin rabbits, rodents, beaver and anything with fleas** (tularemia, plague). Never shoot
>   a deer or elk that looks sick, and never eat its brain, spine, eyes or lymph nodes.
> - **Check every trap every day at first light.** Never set man-killing traps where people or pets walk.
> - **Take the surplus, never the breeding stock.** Never poison a stream, strip a mussel bed, or use mesh
>   that kills young fish.
> - **Cold rivers drown strong swimmers.** The Illinois and Rogue stay cold all year. Stay clear of logjams.

---

## 🌱 Take the surplus, never the seed

Every year a wild population has two parts. The **breeding stock** is what the land can carry through the
hard season. The **surplus** is the animals that will die anyway before next year's young are born. Take
the surplus and the land feeds you again next year. Take the breeding stock and it doesn't
([NY trapper manual, p. 13](lib:trapping-furbearers#page=13)).

Game laws were written to do exactly this, after the last time it went wrong. **While ODFW and the state
police still work, follow the rules.** If enforcement stops, the reasons don't:

- **Elk nearly vanished from our forest.** In 1910 the Forest Service called elk "very scarce" on the Siskiyou
  National Forest, and in 1932 it counted about **40**. Elk mate in October, calve in June, and have **one calf**,
  so a shot-out herd takes decades to recover
  ([Bailey 1936, p. 114](lib:mammals-and-life-zones-of-oregon#page=114); [p. 115](lib:mammals-and-life-zones-of-oregon#page=115)).
- **Deer:** "unrestricted hunting soon cleans out the deer." Keep no more than about **5 does per buck**. If does
  aren't each raising their usual two fawns, there are too few bucks or too many predators
  ([Bailey, p. 120](lib:mammals-and-life-zones-of-oregon#page=120); written for mule deer, but it holds for blacktails).
- **Spare the hens.** "Adult hens are the backbone of Oregon's forest grouse flocks." They are most exposed early
  in the season while tending chicks. Spring turkey is one bearded bird only, because hens are nesting
  ([ODFW bird regs, p. 32](lib:odfw-2026-2027-game-bird#page=32); [p. 24](lib:odfw-2026-2027-game-bird#page=24)).
- **Let small fish go.** Fit traps with **escape gaps** ([🖼️ drawing](lib:fishing-with-traps-and-pots#page=24)). A gill net's mesh should be about **0.4 × the girth of the
  fish you want**; smaller mesh kills young fish before they spawn
  ([FAO, p. 24](lib:fishing-with-traps-and-pots#page=24); [Twinework, p. 64](lib:practical-twinework#page=64)).
- **Lost gear keeps killing** for days or months, and nylon nets never rot. Mark and anchor gear, and tie one panel
  with cotton or plant twine that rots away ([FAO, p. 59](lib:fishing-with-traps-and-pots#page=59);
  [Twinework, p. 41](lib:practical-twinework#page=41)).
- **The Hupa weir.** On the Trinity River, about 70 miles south, [Hupa](wiki:Hupa) families built a salmon
  [weir](wiki:Fishing_weir) in late summer, fished it at night, and kept family fishing spots that were "always
  respected." The first high water swept it away ([Goddard 1903, p. 34](lib:life-and-culture-of-the-hupa#page=34);
  [p. 36](lib:life-and-culture-of-the-hupa#page=36)). A weir left across a whole river all season would take the
  whole run. Leave gaps, and fish only part of each night and part of the run *(general practice)*. Illinois River
  [coho](wiki:Coho_salmon) are federally threatened.

📚 **Go deeper:** [NY trapper manual, p. 13](lib:trapping-furbearers#page=13) — surplus and carrying capacity; [Bailey, p. 120](lib:mammals-and-life-zones-of-oregon#page=120) — how deer herds were shot out; [Goddard, p. 34](lib:life-and-culture-of-the-hupa#page=34) — Hupa fishing.

## 🦌 Local game and its habits

| Animal | Where to look, how to tell | Notes |
|---|---|---|
| [Black-tailed deer](wiki:Black-tailed_deer) | Thickest forest and chaparral; feed cautiously **at evening**; same home area all year | Rut Oct–Nov, fawns May–June. Wary fast once hunted ([Bailey, pp. 121–122](lib:mammals-and-life-zones-of-oregon#page=121)) |
| [Roosevelt elk](wiki:Roosevelt_elk) | Dense timber and brush in the mountains | Scarce here; see above |
| [Black bear](wiki:American_black_bear) | Wades streams for fish and crayfish | About 910 on the Siskiyou NF in 1929. Poor eyes, keen ears and nose: hunt with the wind in your face ([Bailey, p. 391](lib:mammals-and-life-zones-of-oregon#page=391)) |
| [Ruffed grouse](wiki:Ruffed_grouse) | Steep, north-facing brushy streamsides | All grouse pick grit **within an hour of dawn and dusk**; walk closed roads early and late |
| [Sooty grouse](wiki:Sooty_grouse) | Open ridgetops; fir stands later in fall | ([ODFW bird regs, p. 32](lib:odfw-2026-2027-game-bird#page=32)) |
| [Mountain quail](wiki:Mountain_quail) | Long, straight head plume | [California quail](wiki:California_quail): curved plume, scaly belly ([p. 23](lib:odfw-2026-2027-game-bird#page=23)) |
| [Western gray squirrel](wiki:Western_gray_squirrel) | Runs up a tree | Protected game mammal |
| [California ground squirrel](wiki:California_ground_squirrel), [cottontail](wiki:Cottontail_rabbit) | A ground squirrel runs for a burrow, not a tree | "Unprotected." Ground squirrel fleas carry plague (see below) |
| [Brush rabbit](wiki:Brush_rabbit) | Never far from cover | Overgrown closed logging roads, very early morning ([ODFW big game regs, p. 74](lib:odfw-2026-big-game-hunting-regulations#page=74)) |

The track guide on the drive shows eastern species only. For tracking, use
[Seton's chapter, pp. 392–412](lib:seton-the-book-of-woodcraft#page=392) — track drawings of
[🖼️ cat and dog](lib:seton-the-book-of-woodcraft#page=396) and [🖼️ rabbits](lib:seton-the-book-of-woodcraft#page=400).

📚 **Go deeper:** [Bailey *Mammals and Life Zones of Oregon*, p. 121](lib:mammals-and-life-zones-of-oregon#page=121) — every Oregon mammal's habits; [ODFW bird regs, p. 32](lib:odfw-2026-2027-game-bird#page=32) — grouse and quail ID.

## 🎯 Safe shooting, shot placement and tracking

**The four rules** ([Hunter ed, p. 40](lib:todays-hunter-in-new-york#page=40)):
1. Point the muzzle in a safe direction.
2. Treat every gun as loaded.
3. Be sure of your target and what is in front of it and **beyond** it.
4. Finger off the trigger until you are ready to shoot.

**Shot placement** ([Hunter ed, p. 61](lib:todays-hunter-in-new-york#page=61); [CT DEEP, p. 3](lib:making-a-quick-clean-kill#page=3);
[🖼️ where the organs lie in deer, elk, bear and small game](lib:making-a-quick-clean-kill#page=2)):
- Big game: heart and lungs, just behind the front shoulder, broadside. With a bow, a third of the way up the
  chest when the near leg is forward.
- **Never** take head-on, rear-end, running or straight-away shots. A wounded, stressed animal suffers, and its
  meat tastes stronger.
- [Turkey](wiki:Wild_turkey) ([🖼️ gobbler and hen](lib:todays-hunter-in-new-york#page=60)): head and neck. Rabbits and squirrels: head or chest ([Ohio DNR, p. 2](lib:introduction-to-small-game-hunting#page=2)).

**Oregon's legal minimums are also humane-kill minimums:** no .22 rimfire on deer, elk or bear; broadheads
unbarbed and at least 7/8 in wide; bows at least 40 lb draw
([ODFW big game regs, p. 22](lib:odfw-2026-big-game-hunting-regulations#page=22)). Not a law, but keep bow shots
to 40 yards or less ([Hunter ed, p. 70](lib:todays-hunter-in-new-york#page=70)).

**After the shot** ([Hunter ed, pp. 62–63](lib:todays-hunter-in-new-york#page=62)):
1. Watch every move the animal makes after the shot. Wait **30–60 minutes** unless it is down in sight.
2. Follow blood, hair, kicked leaves and broken twigs. Wounded animals often head downhill toward water. Flag the
   trail; if you lose it, search in a circle or grid.
3. Approach from **above and behind the head**. If the open eye doesn't blink when touched with a stick, it is dead.

📚 **Go deeper:** [Hunter ed manual, p. 61](lib:todays-hunter-in-new-york#page=61) — shot angles with drawings; [*Big Game Recovery*](lib:big-game-recovery-blood-trailing) — reading blood sign; [CT DEEP](lib:making-a-quick-clean-kill#page=3) — vital zones.

## 🔪 Field dressing and the gutless method

**Field dressing** ([PNW 517, pp. 7–8](lib:osu-pnw517#page=7); [Hunter ed, p. 64](lib:todays-hunter-in-new-york#page=64);
[🖼️ step drawings](lib:todays-hunter-in-new-york#page=64); [🖼️ step photos](lib:osu-pnw517#page=7)):
1. Prop the animal on its back with its head **slightly downhill**.
2. Cut the hide from the inside out, so hair stays off the meat. Open the belly without cutting the stomach (rumen).
3. Cut the diaphragm and the windpipe. Tie off the colon before you pull it through.
4. Don't touch the dark-haired glands inside the hind legs, just below the hock. They taint the meat.
5. Drain the blood. If you must drag it, sew the cavity shut.

**[Gutless method](wiki:Field_dressing_(hunting))** — best on steep ground, alone, or in hot weather
([Kentucky, p. 1](lib:field-quartering-your-deer-gutless-method#page=1); [PNW 517, pp. 9–10](lib:osu-pnw517#page=9);
[🖼️ illustrated steps](lib:field-quartering-your-deer-gutless-method#page=2)):
1. Skin the top side. Take off the front shoulder (no joint holds it on) and the hindquarter.
2. Take the backstrap and neck meat. Ease the tenderloins out last, without nicking the gut.
3. Flip the animal and repeat. You never open the body or saw the spine, which also avoids the spinal cord
   (chronic wasting disease).

Drag the gut pile at least **25 ft** from where you hang the meat ([PNW 517, p. 11](lib:osu-pnw517#page=11)).

📚 **Go deeper:** [OSU PNW 517 *Big Game from Hunt to Home*](lib:osu-pnw517#page=7) — dressing and quartering with photos; [Kentucky gutless method](lib:field-quartering-your-deer-gutless-method#page=1); [Kentucky elk quartering](lib:elk-quartering-guide#page=2).

## 🌡️ Cooling meat in our heat

**Heat is the enemy.** Cave Junction's summer average is 67 °F and Grants Pass has hit 108 °F
([Josephine soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)), and archery
deer season falls in late August and September.

- **Get the meat below 40 °F within 24 hours** ([PNW 517, p. 6](lib:osu-pnw517#page=6)).
- Hang it in a shady thicket at night. By day, wrap it in cold canvas and lay sleeping bags over it to hold the
  night's chill. Skin the carcass unless the night will freeze ([Montana State, p. 2](lib:montana-state-field-care#page=2)).
- **Don't wrap warm meat.** Game bags, canvas and paper hold heat in. Keep it in moving air until it is below
  40 °F ([PNW 517, p. 11](lib:osu-pnw517#page=11)).
- Meat from a warm day, or from an animal that ran hard or was wounded, should **not be aged**. Cut it up and
  preserve it as soon as it is chilled.
- Scrape off [blowfly](wiki:Blowfly) egg clusters. Black pepper on moist spots and flapping cloth strips keep flies and ravens off
  ([p. 12](lib:osu-pnw517#page=12)).
- **Birds:** keep them at **40 °F or below** ([NDSU game birds, p. 2](lib:ndsu-pocket-guide-care-and-handling-of-game-birds#page=2)).
- With no refrigerator, cut and preserve meat the same day: can it, cure it in winter, or make safe jerky (see the
  [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE)).

📚 **Go deeper:** [PNW 517, p. 11](lib:osu-pnw517#page=11) — cooling, game bags and flies; [Montana State *Field Care*](lib:montana-state-field-care#page=2) — keeping meat cold in warm weather.

## 🥩 Butchering, using the whole animal, and hides

**Bone it out** ([Wyoming B-884R, p. 2](lib:skinning-and-boning-big-game#page=2); [p. 4](lib:skinning-and-boning-big-game#page=4)):
- Take the shoulder off along its natural seam, then the loin. Follow the hind leg's muscle seams into the
  sirloin tip, top, bottom and eye of round ([🖼️ photos of each cut](lib:skinning-and-boning-big-game#page=3)).
- Grind the tough heel and trimmings, and preserve trimmings **the day you cut them**.
- A 349-lb field-dressed cow elk gave **148 lb** of boneless meat, about 42%.

**Use the whole animal:**
- Heart, liver, tongue and kidneys are good. Wash the heart and liver in cold water at once
  ([PNW 517, p. 12](lib:osu-pnw517#page=12)). A healthy liver is smooth, wet and deep red-purple. **Throw out a
  spotted or odd-colored liver**; the muscle meat may still be fine *(general practice)*.
- Beaver, [muskrat](wiki:Muskrat) and [raccoon](wiki:Raccoon) are good eating: the quarters and back. The rib cage is usually discarded
  ([Trapper Education Manual, p. 106](lib:trapper-education-manual-iafwa#page=106); [FM 3-05.70, p. 153](lib:fm-3-05-70#page=153)).
- Save the fat. People living on lean meat alone get sick ("rabbit starvation," *(rule of thumb)*; see the
  [Rabbits guide](guide:RABBITS-GUIDE)).

**[Brain-tanned buckskin](wiki:Buckskin_(leather)), no chemicals**
([Farnham 1916, pp. 73–74](lib:home-manufacture-of-furs-and-skins#page=73); [brain tanning](wiki:Buckskin_(leather))):
1. Soak the hide in water, or water and wood ashes, until the hair slips. Flesh it, then scrape off the hair and grain
   ([🖼️ unhairing](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=11)).
2. Boil the brains about an hour in a gallon of water. Cool until you can hold your hand in it.
3. Work the hide in it, and stretch it while it dries. Repeat until soft
   ([🖼️ softening over a stake](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=21)).
4. Smoke it over smoldering punky wood, never flame ([p. 145](lib:home-manufacture-of-furs-and-skins#page=145)).

Use brains **only from healthy animals, and wear gloves** (chronic wasting disease). Bark tanning one heavy cowhide
takes well over 100 lb of finely ground oak or hemlock bark, added 30–40 lb at a time over about 4 months
([USDA FB 1334, p. 14](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=14));
our tanoak was the old "tanbark" *(general practice)*. Full tanning steps are in the
[Clothing & Leather guide](guide:CLOTHING-LEATHER-GUIDE).

📚 **Go deeper:** [Wyoming *Skinning and Boning Big Game*](lib:skinning-and-boning-big-game#page=2) — cuts with photos; [Farnham, p. 73](lib:home-manufacture-of-furs-and-skins#page=73) — buckskin the old way; [USDA FB 1334](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=14) — bark and alum tanning.

## 🪤 Trapping, snaring and deadfalls

**Where you set matters more than the trap** ([FM 3-05.70, pp. 127–128](lib:fm-3-05-70#page=127)):
- Set on a **run** (small, used by one species) or at feeding, watering and bedding spots. A **trail** is used by
  many species.
- Funnel the run with sticks down to just wider than the animal ([🖼️ drawing](lib:afh-10-644#page=301)). Don't use freshly cut green wood, which smells of
  sap. Hide your scent with mud or smoke.
- A **squirrel pole** carries several wire nooses 2–2¼ in across, set 1 in off the pole
  ([p. 132](lib:fm-3-05-70#page=132); [🖼️ drawing](lib:fm-3-05-70#page=133)). Check current ODFW rules first:
  western gray and Douglas squirrels are protected game in Oregon.

**Traps with no store-bought gear:** the figure-4 and Paiute [deadfalls](wiki:Trapping) need only sticks and cord
([FM 3-05.70, p. 137](lib:fm-3-05-70#page=137); [🖼️ Paiute deadfall](lib:fm-3-05-70#page=138)). Harding's 1907 [*Deadfalls and Snares*](lib:deadfalls-and-snares-harding#page=137)
shows many more ([🖼️ spring-pole snare](lib:deadfalls-and-snares-harding#page=123), [🖼️ trail snares](lib:deadfalls-and-snares-harding#page=136)). A **box trap** keeps rabbits unhurt ("the best for eating") and lets you release a cat, dog or
hen unharmed ([p. 146](lib:deadfalls-and-snares-harding#page=146); [🖼️ drawing](lib:deadfalls-and-snares-harding#page=147)).

![Drawing of the three notched sticks of a figure-4 deadfall (upright, release and bait stick) and the set trap holding up a log](img:HUNTING-TRAPPING-FISHING-GUIDE/figure-4-deadfall.png)
*Figure-4 deadfall: where the notches go on the upright, release and bait sticks, and the set trap holding up a log ([FM 3-05.70, p. 137](lib:fm-3-05-70#page=137)).*

![Drawing of a Paiute deadfall: a flat rock propped on a diagonal stick held by a cord, a small catch stick and a bait stick, with a close-up of the catch](img:HUNTING-TRAPPING-FISHING-GUIDE/paiute-deadfall.png)
*Paiute deadfall: a cord and a 2-inch catch stick hold the diagonal stick; when the animal moves the bait stick, the weight falls (circles: close-ups of the catch) ([FM 3-05.70, p. 138](lib:fm-3-05-70#page=138)).*

**Check every trap every day, at first light.** Most furbearers move at night. Early checks mean less suffering,
fewer escapes and less theft by other animals. Don't set more traps than you can check, and stay away from
places where pets roam ([Trapper Education Manual, p. 99](lib:trapper-education-manual-iafwa#page=99);
[NY manual, p. 3](lib:trapping-furbearers#page=3)).

**Keeping pets out** ([AFWA body-grip guide, pp. 9, 15–16](lib:body-grip-traps-on-dry-land#page=9)):
- For raccoon, use **sweet baits** (marshmallow, molasses, corn syrup, corn) that dogs and cats ignore, not meat or fish.
- Raise body-grip cubbies **4–6 ft** up a tree ([🖼️ cubby on a tree](lib:body-grip-traps-on-dry-land#page=15)).
- Set trail traps **5–6 ft in front of** a fence crossing, not under it, so big dogs pass by
  ([🖼️ trail-set drawings](lib:body-grip-traps-on-dry-land#page=16)).

**[Beaver](wiki:North_American_beaver):** #330 body-grip traps or cable devices at slides, scent mounds and channels. Bait with fresh poplar,
willow or cottonwood sticks. Use sliding-lock sets in water so the beaver drowns quickly
([Trapper Education Manual, p. 138](lib:trapper-education-manual-iafwa#page=138)).

📚 **Go deeper:** [Trapper Education Manual](lib:trapper-education-manual-iafwa#page=99) — sets, baits and running a trapline; [Harding *Deadfalls and Snares*](lib:deadfalls-and-snares-harding#page=137) — illustrated improvised traps; [AFWA dog-friendly sets](lib:dog-friendly-strategies-for-trapping) — keeping pets safe.

## 🎣 Fishing, nets, fish traps and fish care

**While the rules are enforced** ([ODFW fishing regs, p. 19](lib:odfw-2026-oregon-sport-fishing#page=19)): one rod
per person, lines closely attended (so no unattended set lines), and no snagging. Local waters and seasons are on
[Start Here](guide:ILLINOIS-VALLEY-START-HERE).

**Nets and stream traps** ([AFH 10-644, pp. 311, 314](lib:afh-10-644#page=311)):
- Set a [gill net](wiki:Gillnetting) at a slight angle to the current so debris washes off
  ([🖼️ drawing](lib:fm-3-05-70#page=145)). **Check it at least twice a day.**
- In small streams, a brush or stake fence that funnels fish into a pen works. Leave a way through for most of
  the run *(general practice)* ([🖼️ fish-trap layouts](lib:fm-3-05-70#page=146); [🖼️ maze traps](lib:afh-10-644#page=314)).
- Nets are knotted with the **[sheet bend](wiki:Sheet_bend)**, using a netting needle ([🖼️ drawing](lib:practical-twinework#page=15))
  and mesh gauge ([🖼️ drawing](lib:practical-twinework#page=16))
  ([Twinework, p. 46](lib:practical-twinework#page=46)). A **fyke net** (a netting hoop trap with wings) is the river
  version of a [fish trap](wiki:Fish_trap) ([p. 137](lib:practical-twinework#page=137)).

![Drawing from above of a gill net strung across a stream between two banks, set at a slant to the current](img:HUNTING-TRAPPING-FISHING-GUIDE/gill-net-angled-in-stream.png)
*A gill net seen from above, set at a slant to the current (arrow) so drifting debris slides off ([FM 3-05.70, p. 145](lib:fm-3-05-70#page=145)).*

![Drawings of a basket fish trap, a stake-fence pen with its funnel mouth facing the current, and a stone tidal-flat trap](img:HUNTING-TRAPPING-FISHING-GUIDE/fish-traps.png)
*A basket trap and a stake pen whose funnel mouth faces the current; the stone tidal-flat trap is for the coast ([FM 3-05.70, p. 146](lib:fm-3-05-70#page=146)).*

**Fish care** ([NDSU, p. 2](lib:ndsu-pocket-guide-care-and-handling-of-fish#page=2); [NYSDEC, p. 4](lib:care-of-your-catch#page=4)):
1. Bleed the fish by cutting the throat. Pull the gills and guts ([🖼️ filleting drawing](lib:afh-10-644#page=360)).
2. Scrape out the dark kidney along the backbone. Wipe it and keep it cold.
3. Don't let cleaned fish sit warm more than **2 hours**.
4. Contaminants collect in fat: skin the fish and trim the fat ([🖼️ where to trim](lib:care-of-your-catch#page=5)).

**Smoke alone does not preserve fish.** Hot-smoked fish must reach 150 °F inside (160 °F better) for 30 minutes,
and still keeps only in a refrigerator ([PNW 238, pp. 1–2](lib:pnw238#page=1)). Without one, can it or salt it (see
the [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE)).

**Mercury:** Oregon has a statewide mercury advisory on bass, and **Applegate Lake** has one for resident fish.
Sea-run [salmon](wiki:Chinook_salmon) and [steelhead](wiki:Rainbow_trout) carry fewer local contaminants. Children under 6 and pregnant or nursing women should
eat the fewest resident fish ([ODFW fishing regs, p. 24](lib:odfw-2026-oregon-sport-fishing#page=24)).

📚 **Go deeper:** [*Practical Twinework*](lib:practical-twinework#page=46) — making and mending nets by hand; [FAO *Fishing with Traps and Pots*](lib:fishing-with-traps-and-pots#page=24) — funnels, doors and escape gaps; [NYSDEC *Care of Your Catch*](lib:care-of-your-catch#page=4) — cleaning and filleting.

## 🦞 Crawfish, mussels and lamprey

- **Crawfish** ([signal crayfish](wiki:Signal_crayfish)) come out at night. By day, look under stream stones. They
  grab offal tied on a string; pull them in before they let go. **Cook all freshwater shellfish and fish**
  ([FM 3-05.70, p. 118](lib:fm-3-05-70#page=118)). While the rules stand: open all year, no license, by hand, line
  with no hook, net, ring or trap, 100 a day ([ODFW fishing regs, p. 22](lib:odfw-2026-oregon-sport-fishing#page=22)).
- **Freshwater mussels are famine food only.** Some, like the [western pearlshell](wiki:Western_pearlshell)
  ([🖼️ shells](lib:freshwater-mussels-of-the-pacific-northwest#page=38)), live
  **over 100 years**. About 1 in 100,000,000 larvae becomes a young mussel, and the larvae must ride on salmon or
  trout to survive ([🖼️ life-cycle drawing](lib:freshwater-mussels-of-the-pacific-northwest#page=10)). **A bed stripped bare does not come back in a lifetime**
  ([Xerces, p. 12](lib:freshwater-mussels-of-the-pacific-northwest#page=12); [p. 18](lib:freshwater-mussels-of-the-pacific-northwest#page=18)).
  Taking them is illegal while the rules stand.
- **[Pacific lamprey](wiki:Pacific_lamprey): leave it to the tribes**
  ([🖼️ photo on the ODFW Rogue fishes poster](lib:odfw-native-fishes-of-the-rogue-river-poster#page=1)). The Hupa netted lamprey on warm spring nights
  and dried them over the fire ([Goddard, p. 35](lib:life-and-culture-of-the-hupa#page=35)). Tribes still prize it as
  food and medicine, but it is in steep decline ([PLCI fact sheet, p. 1](lib:pacific-lamprey-in-decline#page=1)), and
  Oregon allows it only by tribal or Willamette Falls permit ([ODFW, p. 22](lib:odfw-2026-oregon-sport-fishing#page=22)).

📚 **Go deeper:** [Xerces *Freshwater Mussels of the PNW*](lib:freshwater-mussels-of-the-pacific-northwest#page=12) — ID and why beds don't recover; [PLCI fact sheet](lib:pacific-lamprey-in-decline#page=1) — lamprey and the tribes.

## ☣️ Disease and safety

**[Trichinella](wiki:Trichinosis)** in bear, cougar, raccoon and beaver: wild strains survive freezing (larvae lived
**5 years** in frozen bear meat), and curing, smoking and drying don't reliably kill them. **Cook it through**
([FDA *Bad Bug Book*, p. 142](lib:fda-bad-bug-book#page=142); [NY manual, p. 26](lib:trapping-furbearers#page=26)).
Jerky is safe only if the meat reaches **160 °F** ([PNW 632, p. 8](lib:pnw632#page=8)).

**[Tularemia](wiki:Tularemia)** (rabbit fever) comes from rabbits, hares, beaver and muskrat, and from ticks and deer
flies. An infected liver and spleen have **white spots**. As few as 10 bacteria breathed in can infect you, so don't
make dust or spray while skinning. Wear gloves and cook thoroughly
([Trapper Education Manual, p. 92](lib:trapper-education-manual-iafwa#page=92); [Bad Bug Book, p. 64](lib:fda-bad-bug-book#page=64)).
It needs antibiotics for 10–21 days, depending on the drug (doxycycline 14–21)
([CDC, p. 34](lib:tickborne-diseases-of-the-united-states#page=34)).

**[Chronic wasting disease](wiki:Chronic_wasting_disease)** isn't in Oregon yet but is in California, Idaho and
Washington. Never shoot or eat a deer or elk that looks sick. Never eat the **brain, eyes, spinal cord, spleen or
lymph nodes**. Bone out the meat, and soak tools in half bleach, half water for an hour
([ODFW big game regs, p. 48](lib:odfw-2026-big-game-hunting-regulations#page=48); [Hunter ed, p. 65](lib:todays-hunter-in-new-york#page=65);
[Kentucky elk guide, p. 2](lib:elk-quartering-guide#page=2)).

**Ticks:** the [western blacklegged tick](wiki:Ixodes_pacificus) ([Lyme disease](wiki:Lyme_disease)) lives here ([🖼️ tick photos and sizes](lib:tickborne-diseases-of-the-united-states#page=5)). Soft ticks in rodent
nests in rustic cabins spread relapsing fever, in the hills above about 1,500 ft. Pull a tick with fine tweezers close
to the skin, straight up, no twisting, no heat or petroleum jelly
([🖼️ removal photos](lib:tickborne-diseases-of-the-united-states#page=50)). Treat clothing with permethrin
([CDC, p. 50](lib:tickborne-diseases-of-the-united-states#page=50); [ODFW fishing regs, p. 15](lib:odfw-2026-oregon-sport-fishing#page=15)).

![Side-view diagram of a tick with its mouthparts in the skin: fine-tipped tweezers grip it right at the skin, and an arrow shows pulling straight up; don't twist, use heat or petroleum jelly](img:HUNTING-TRAPPING-FISHING-GUIDE/pulling-a-tick.svg)
*Grip the tick right at the skin with fine tweezers and pull straight up, with no twisting, heat or petroleum jelly (a diagram drawn for this guide).*

**[Plague](wiki:Plague_(disease)):** southern Oregon is one of the two US plague regions. Its main flea lives on the California ground
squirrel, and a trapper caught plague from a cut while skinning a bobcat. Bag any flea-covered catch at once, spray
insecticide in the bag and tie it shut ([Plague in Washington, p. 4](lib:plague-surveillance-in-washington#page=4);
[Trapper Education Manual, p. 102](lib:trapper-education-manual-iafwa#page=102)).

**[Hantavirus](wiki:Hantavirus_pulmonary_syndrome)** comes from deer mice. Never sweep or vacuum droppings. Soak them
in 1 part bleach to 9 parts water for 5 minutes, then wipe up with gloves
([🖼️ cleanup steps](lib:you-can-prevent-hantavirus#page=15)). Use snap traps, not live or glue traps
([CDC 2021, pp. 11–12](lib:you-can-prevent-hantavirus#page=11)).

**Lead:** fast-expanding lead bullets threw fragments **5–14 in** from the exit hole, and lead turned up **18 in**
away. Rinsing didn't help. A solid copper bullet left few fragments, mostly within about 4 in. Trim wide, throw out
bloodshot or bone-flecked meat, and grind one animal at a time ([Minnesota DNR, p. 6](lib:bullet-fragmentation#page=6);
[PNW 517, p. 1](lib:osu-pnw517#page=1)). Give lead-shot meat to adults, not children or pregnant women
*(general practice)*.

**Coastal clams and mussels:** [paralytic shellfish](wiki:Paralytic_shellfish_poisoning) toxin and domoic acid aren't destroyed by cooking or freezing, and
there's no antidote. Numb lips or tingling hands within hours means get help. With no state testing, **leave coastal
shellfish alone** ([ODA, p. 1](lib:shellfish-biotoxin-closures#page=1); [OHA, p. 1](lib:paralytic-shellfish-poisoning-fact-sheet#page=1)).

**Cold rivers:** the Illinois and Rogue stay dangerously cold even in summer. Sudden cold water causes gasping ([cold shock](wiki:Cold_shock_response)) and
drowning, and water drains body heat **25 times faster** than air. **Strainers** (logjams, overhanging branches) pin people under
([OSMB handbook, p. 17](lib:osmb-experience-oregon-boating#page=17); [p. 14](lib:osmb-experience-oregon-boating#page=14)).

📚 **Go deeper:** [CDC *Tickborne Diseases*](lib:tickborne-diseases-of-the-united-states#page=34) — tick ID, symptoms and treatment; [Minnesota *Bullet Fragmentation*](lib:bullet-fragmentation#page=6) — the X-rays; [OHA PSP sheet](lib:paralytic-shellfish-poisoning-fact-sheet#page=1) — symptoms that mean get help now; [Field Care guide](guide:FIELD-CARE-GUIDE) — treating illness with no doctor.

## ⚠️ Old advice in the library to ignore

- **"You can eat these raw"** for sea fish caught far offshore, and "there are no poisonous freshwater fish"
  ([FM 3-05.70, p. 121](lib:fm-3-05-70#page=121)). Ocean fish commonly carry worms, and mercury advisories apply
  here. **Instead:** cook all fish.
- **Poisoning fish** with rotenone plants, lime or walnut husks ([FM 3-05.70, pp. 148–150](lib:fm-3-05-70#page=148);
  [AFH 10-644, p. 315](lib:afh-10-644#page=315)). It kills every fish, the young salmon and the insects they eat, and
  ruins a stream for years. **Never do it.**
- **Bow traps and pig-spear traps** ([FM 3-05.70, pp. 138–140](lib:fm-3-05-70#page=138)), which the manual itself
  calls deadly to people. **Instead:** snares, deadfalls and box traps, never near homes, trails or where children walk.
- **Smoked meat eaten "without further cooking," eating the brain** ([FM 3-05.70, p. 154](lib:fm-3-05-70#page=154)),
  and **sun-dried raw strips** ([p. 156](lib:fm-3-05-70#page=156)). Smoked or dried bear still carries trichinella,
  and deer and elk brain carries chronic wasting disease risk. **Instead:** cook it through; jerky reaches 160 °F.
- ***Ixodes dammini*** as the Lyme tick ([Trapper Education Manual, p. 92](lib:trapper-education-manual-iafwa#page=92)),
  an old eastern name. **Ours is the western blacklegged tick, *Ixodes pacificus***
  ([CDC, p. 4](lib:tickborne-diseases-of-the-united-states#page=4)).
- **A "minimum" 4-inch trim** around the bullet path ([PNW 517, p. 1](lib:osu-pnw517#page=1); also repeated on the
  Start Here page). **Instead:** trim much wider; fragments went 5–14 in ([Minnesota DNR, p. 6](lib:bullet-fragmentation#page=6)).
- **Aging birds at 40–45 °F** ([Wyoming waterfowl sheet, p. 1](lib:waterfowl-field-care-and-plucking#page=1)). That
  is above the danger line. **Instead:** 40 °F or below ([NDSU, p. 2](lib:ndsu-pocket-guide-care-and-handling-of-game-birds#page=2)).
- **Arsenic sprayed on hides** ([Farnham, p. 64](lib:home-manufacture-of-furs-and-skins#page=64)), plus the book's
  chrome (bichromate) and sulfuric acid tanning. These are poisons. **Instead:** brain, bark, or salt and alum.

📚 **Go deeper:** [CDC *Tickborne Diseases*, p. 4](lib:tickborne-diseases-of-the-united-states#page=4) — tick ID pictures; [USDA FB 1334](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=14) — safe tanning methods.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Game and fish to know**
- Deer, elk and bear — [Black-tailed deer](wiki:Black-tailed_deer); [Roosevelt elk](wiki:Roosevelt_elk); [American black bear](wiki:American_black_bear)
- Grouse, quail and turkey — [Ruffed grouse](wiki:Ruffed_grouse); [Sooty grouse](wiki:Sooty_grouse); [Mountain quail](wiki:Mountain_quail); [California quail](wiki:California_quail); [🖼️ gobbler vs. hen, Hunter ed p. 60](lib:todays-hunter-in-new-york#page=60)
- Tracks — [🖼️ Seton, p. 396 (cat and dog)](lib:seton-the-book-of-woodcraft#page=396); [🖼️ Seton, p. 400 (rabbits)](lib:seton-the-book-of-woodcraft#page=400)
- Coho, chinook and steelhead — [🖼️ CA Sea Grant ID sheet, p. 3](lib:california-sea-grant-identifying-adult-salmon-and-steelhead#page=3); [🖼️ ODFW Rogue fishes poster](lib:odfw-native-fishes-of-the-rogue-river-poster#page=1); [Coho salmon](wiki:Coho_salmon)

**Shooting, field dressing and butchering**
- Where the heart and lungs lie — [🖼️ CT DEEP, p. 2](lib:making-a-quick-clean-kill#page=2); [🖼️ Hunter ed, p. 61](lib:todays-hunter-in-new-york#page=61)
- Field dressing, step by step — [🖼️ Hunter ed, p. 64](lib:todays-hunter-in-new-york#page=64); [🖼️ OSU PNW 517, p. 7](lib:osu-pnw517#page=7); [🖼️ AFH 10-644, p. 358](lib:afh-10-644#page=358); [Field dressing](wiki:Field_dressing_(hunting))
- Gutless quartering — [🖼️ Kentucky, p. 2](lib:field-quartering-your-deer-gutless-method#page=2)
- Skinning big game — [🖼️ NDSU, p. 4](lib:wild-side-of-the-menu-2#page=4); [🖼️ AFH 10-644, p. 356](lib:afh-10-644#page=356); [🖼️ FM 3-05.70, p. 152](lib:fm-3-05-70#page=152)
- Skinning small game — [🖼️ FM 3-05.70, p. 153](lib:fm-3-05-70#page=153)
- Boning out the cuts — [🖼️ Wyoming, p. 2](lib:skinning-and-boning-big-game#page=2); [🖼️ Wyoming, p. 3](lib:skinning-and-boning-big-game#page=3); [🖼️ NDSU, p. 6](lib:wild-side-of-the-menu-2#page=6)
- Hide tanning tools, unhairing, staking — [🖼️ USDA FB 1334, p. 7](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=7); [🖼️ p. 11](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=11); [🖼️ p. 21](lib:home-tanning-of-leather-and-small-fur-skins-usda-fb1334#page=21); [Buckskin](wiki:Buckskin_(leather))

**Snares, deadfalls and traps**
- Funneling a run — [🖼️ AFH 10-644, p. 301](lib:afh-10-644#page=301)
- Simple and twitch-up snares — [🖼️ FM 3-05.70, p. 130](lib:fm-3-05-70#page=130); [🖼️ p. 132](lib:fm-3-05-70#page=132); [Snare](wiki:Snare)
- Squirrel pole — [🖼️ FM 3-05.70, p. 133](lib:fm-3-05-70#page=133)
- Treadle spring snare — [🖼️ FM 3-05.70, p. 136](lib:fm-3-05-70#page=136)
- Spring-pole and trail snares (1907) — [🖼️ Harding, p. 123](lib:deadfalls-and-snares-harding#page=123); [🖼️ Harding, p. 136](lib:deadfalls-and-snares-harding#page=136)
- Figure-4 and Paiute deadfalls — [🖼️ FM 3-05.70, p. 137](lib:fm-3-05-70#page=137); [🖼️ p. 138](lib:fm-3-05-70#page=138); [Deadfall trap](wiki:Trapping)
- Pole deadfall and trip triggers — [🖼️ Harding, p. 21](lib:deadfalls-and-snares-harding#page=21); [🖼️ Harding, p. 87](lib:deadfalls-and-snares-harding#page=87)
- Box trap — [🖼️ Harding, p. 147](lib:deadfalls-and-snares-harding#page=147); [🖼️ AFH 10-644, p. 303](lib:afh-10-644#page=303)
- Dog-safe raccoon sets — [🖼️ AFWA, p. 15](lib:body-grip-traps-on-dry-land#page=15); [🖼️ AFWA, p. 16](lib:body-grip-traps-on-dry-land#page=16)

**Nets and fish traps**
- Netting needle and mesh gauge — [🖼️ Twinework, p. 15](lib:practical-twinework#page=15); [🖼️ p. 16](lib:practical-twinework#page=16)
- Sheet bend, right and wrong — [🖼️ Twinework, p. 46](lib:practical-twinework#page=46); [Sheet bend](wiki:Sheet_bend)
- Knitting and setting a gill net — [🖼️ FM 3-05.70, p. 144](lib:fm-3-05-70#page=144); [🖼️ p. 145](lib:fm-3-05-70#page=145); [🖼️ AFH 10-644, p. 312](lib:afh-10-644#page=312); [Gillnet](wiki:Gillnetting)
- Mending a torn net — [🖼️ Twinework, p. 152](lib:practical-twinework#page=152)
- Stream traps, weirs and fyke nets — [🖼️ FM 3-05.70, p. 146](lib:fm-3-05-70#page=146); [🖼️ AFH 10-644, p. 314](lib:afh-10-644#page=314); [🖼️ Twinework, p. 137](lib:practical-twinework#page=137); [Fishing weir](wiki:Fishing_weir)
- Trap funnels and escape gaps — [🖼️ FAO, p. 23](lib:fishing-with-traps-and-pots#page=23); [🖼️ FAO, p. 24](lib:fishing-with-traps-and-pots#page=24)
- Filleting and trimming the fat — [🖼️ AFH 10-644, p. 360](lib:afh-10-644#page=360); [🖼️ NYSDEC, p. 5](lib:care-of-your-catch#page=5)

**Shellfish and disease**
- Mussel life cycle and western pearlshell — [🖼️ Xerces, p. 10](lib:freshwater-mussels-of-the-pacific-northwest#page=10); [🖼️ Xerces, p. 38](lib:freshwater-mussels-of-the-pacific-northwest#page=38); [Signal crayfish](wiki:Signal_crayfish)
- Ticks and tick removal — [🖼️ CDC, p. 5](lib:tickborne-diseases-of-the-united-states#page=5); [🖼️ CDC, p. 50](lib:tickborne-diseases-of-the-united-states#page=50); [Ixodes pacificus](wiki:Ixodes_pacificus)
- Cleaning up after mice — [🖼️ CDC hantavirus, p. 15](lib:you-can-prevent-hantavirus#page=15)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — seasons, hunting units, local waters, trapping rules
- [Preserving Food](guide:PRESERVING-FOOD-GUIDE) — canning, curing, jerky and smoking the meat and fish
- [Clothing & Leather](guide:CLOTHING-LEATHER-GUIDE) — tanning hides and making buckskin clothes
- [Field Care guide](guide:FIELD-CARE-GUIDE) — wounds, ticks, hypothermia and sickness with no doctor
- [Food Security guide](guide:FOOD-SECURITY-GUIDE) — fitting wild meat into a ration
- [Chickens](guide:CHICKENS-GUIDE) and [Rabbits](guide:RABBITS-GUIDE) — dependable meat you raise instead of hunt
- [Navigation & Weather](guide:NAVIGATION-WEATHER-GUIDE) — finding your way in the backcountry
- [Knots, Rope & Cordage](guide:KNOTS-ROPE-GUIDE) — the knots that do nearly every job, lashing, blocks and tackle, making cord
- [Dams, Weirs, Ditches & Ponds](guide:DAMS-DITCHES-GUIDE) — beaver and muskrat damage to dams; salmon passage
- [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE) — acorns, camas, salmon, cordage and baskets, houses, and tending the land with fire, the way people here lived for thousands of years.
