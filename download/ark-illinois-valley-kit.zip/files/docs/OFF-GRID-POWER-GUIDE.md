# ☀️ Off-Grid Power: Solar, Batteries & Creek Hydro

Making and storing electricity with no grid: what you really need, sizing solar for our dark winters,
salvaging panels, controllers and inverters, keeping lead-acid and lithium batteries alive and safe,
wiring, charging from a generator or car, and creek hydro, which is strongest when solar is weakest.
The books are in `Off-Grid-Power\` (`Solar-PV`, `Batteries`, `Electrical-Basics`, `Micro-Hydro`), with
homemade generators in `Engines-Motors\Motors-as-Generators`, solar well pumps in
`Water-Wells-Pumps\Pumps-No-Grid`, and Practical Action's battery and lighting briefs in
`Homestead-Skills\Household-Make-Do`. The short version is in
[Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE).

> ### ⚠️ Rules that prevent the worst outcomes
> - **Batteries give off hydrogen, which explodes at just 4% in air**
>   ([DOE-HDBK-1084, p. 22](lib:doe-primer-on-lead-acid#page=22)). Vent the top of the room, and never
>   mount a controller, switch or relay in or above a battery box
>   ([IEA, p. 53](lib:iea-pvps-recommended-practices-for-charge#page=53)).
> - **A shorted battery can explode.** One golf-cart battery can push about **8,000 amps**
>   ([Sandia, p. 15](lib:sandia-pv-systems#page=15)). Fuse at the + terminal, connect the battery last,
>   and if a tool shorts it, **don't grab it: get away** ([IEA, p. 22](lib:iea-pvps-lead-acid#page=22)).
> - **Never plug a generator into a wall outlet.** Backfeeding can kill line workers and neighbors.
>   Generators run outdoors only ([CPSC, p. 1](lib:cpsc-portable-generator#page=1)).
> - **Panels are live whenever light hits them.** Cover them with an opaque tarp before touching wiring
>   ([fire FAQ, p. 3](lib:home-lithium-ion-battery-fire#page=3)).
> - **Lithium: never charge below 32 °F, never "equalize" it, and never cover or pick up a burning
>   pack**; soak it with water from a distance ([FAA SAFO 09013](lib:faa-safo#page=1)).
> - **Battery acid blinds.** Goggles and rubber gloves; flush skin or eyes with water **at least 15
>   minutes** ([NEETS 1, p. 96](lib:neets-module-01#page=96)).

---

## 📋 Start with a load list

For each thing you'll run, multiply **watts × hours a day = watt-hours (Wh) a day**, and add them up
([Sandia, p. 16](lib:sandia-sizing-small#page=16)). Take watts from the nameplate or a plug-in watt
meter. An example *(use your own numbers)*:

| Item | Watts | Hours a day | Wh a day |
|---|---|---|---|
| 4 LED bulbs | 40 | 5 | 200 |
| Laptop | 50 | 4 | 200 |
| Radio and phone charging | 20 | 5 | 100 |
| Fridge or freezer (watt-meter reading) | — | — | 450 |
| Inverter idling | 10 | 5 | 50 |
| **Total** | | | **1,000 Wh = 1 kWh** |

- **Kill hidden loads.** [Standby "phantom" loads](wiki:Standby_power) can add up to **100 W around the clock**
  ([NRCan, p. 14](lib:nrcan-micro-hydropower-systems-a-buyers#page=14)): 2.4 kWh a day. An idling
  inverter uses 10–50 W; switch it off *(rule of thumb)*.
- **Skip the inverter** for 12 V lights, fans, pumps and USB chargers
  ([Arizona, p. 5](lib:univ-of-arizona-extension#page=5); [🖼️ 12 V loads pictured](lib:univ-of-arizona-extension#page=6)).
- **Motors need about 6 times their running current to start**: a 1 hp motor may need 6 kW for a
  moment ([DOE Microhydro, p. 67](lib:doe-microhydropower-handbook-vol-1-part-1#page=67)).
- **Store water, not electricity.** A solar pump run from its panels through its own controller,
  filling a raised tank, needs no battery: the tank is the storage
  ([NRCS, pp. 9, 27](lib:design-of-small-solar-powered-water-pump#page=27); [🖼️ a solar pump layout](lib:solar-photovoltaic-water-pumping-practical-action#page=3)). Keep 3–5 days of
  water in the tank ([Practical Action, p. 2](lib:solar-photovoltaic-water-pumping-practical-action#page=2)).

**Pick the system voltage** ([Arizona, p. 5](lib:univ-of-arizona-extension#page=5)):

| Daily load | Battery voltage |
|---|---|
| Under 1 kWh | 12 V |
| 1–4 kWh | 24 V |
| Over 4 kWh | 48 V |

Keep steady current under 100 A ([NRCS, p. 31](lib:design-of-small-solar-powered-water-pump#page=31)).

📚 **Go deeper:** [Sandia *Sizing Small Off-Grid Solar Systems*](lib:sandia-sizing-small#page=16) — the load worksheet; [Arizona Extension *Stand-Alone PV Components*](lib:univ-of-arizona-extension#page=2) — every part, in plain words. Pictures: [🖼️ how the parts connect, Arizona p. 1](lib:univ-of-arizona-extension#page=1), [🖼️ PA *Solar PV* p. 4](lib:practical-action-solar-photovoltaic#page=4), [Photovoltaic system](wiki:Photovoltaic_system).

## ☀️ Our sun, month by month

Average "peak sun hours" a day at Medford, the nearest station, for a panel facing south tilted at our
latitude, 42° ([NREL Redbook, p. 181](lib:nrel-solar-radiation#page=181)):

| Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Year |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2.3 | 3.5 | 4.6 | 5.6 | 6.2 | 6.5 | 7.1 | 6.9 | 6.4 | 4.8 | 2.4 | 1.9 | 4.9 |

- **A panel makes 3½–4 times more in July than in December.** The worst December on record averaged
  only 1.2.
- The county has "persistent cloudiness in winter"
  ([Soil Survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)). Plan on
  Medford's numbers or a little less at Cave Junction, and expect wildfire smoke to cut output in August
  and September *(rule of thumb)*.
- **Tilt steeply for winter** ([🖼️ the sun's path through the year](lib:design-of-small-solar-powered-water-pump#page=14)). At latitude + 15° (about 57°) a panel gets 2.0 in December; laid flat, only
  1.2 (Redbook, p. 181). If your mount adjusts, go steeper in winter and flatter in summer, and never
  below 10°, so rain washes the glass ([Practical Action, p. 3](lib:practical-action-solar-photovoltaic#page=3)).
- **Snow:** Cave Junction averages 24 in a season (Soil Survey, p. 5). Steep panels shed it; brush off the
  rest with a soft broom *(rule of thumb)*.
- **Winter shade:** the December sun is low, so a ridge or tree to the south can shade a panel all day.
  Check the site in December *(rule of thumb)*.

![A solar panel seen from the side, tilted about 57 degrees for winter, 42 degrees year-round and never flatter than 10 degrees, facing the low December sun in the south](img:OFF-GRID-POWER-GUIDE/panel-tilt-for-winter.svg)
*Tilt steeply for our dark Decembers: about 57° in winter, 42° year-round, never below 10° (a diagram drawn for this guide).*

📚 **Go deeper:** [NREL *Solar Radiation Data Manual*](lib:nrel-solar-radiation#page=181) — Medford, every tilt, every month; [Practical Action *Solar PV*](lib:practical-action-solar-photovoltaic#page=3) — tilt and sizing basics. Pictures: [🖼️ setting up a panel, PA *Solar PV* p. 1](lib:practical-action-solar-photovoltaic#page=1), [Solar panel](wiki:Solar_panel).

## 🧮 A worked example

**Panels:** panel kW = (kWh a day ÷ sun hours) × 1.2 for losses
([Sandia, p. 20](lib:sandia-sizing-small#page=20)). For the 1 kWh load above:
- **December:** 1 ÷ 1.9 × 1.2 ≈ **630 W of panels**.
- **July:** 1 ÷ 7.1 × 1.2 ≈ **170 W**.

Check: each rated panel watt gives about 0.85 Wh per sun hour
([Practical Action, p. 4](lib:practical-action-solar-photovoltaic#page=4)), and 630 × 0.85 × 1.9 ≈ 1,020 Wh.

**Batteries:** only **40% of a lead-acid label** is usable
([IEA, p. 17](lib:iea-pvps-lead-acid#page=17)), so label Wh needed = daily Wh × days of backup ÷ 0.4.
Above 40° latitude the IEA suggests **7–9 days** of backup for solar alone (same page): 17,500–22,500 Wh of
label for 1 kWh a day. Four 6 V, 220 Ah golf-cart batteries in series ([🖼️ drawing](lib:doe-primer-on-lead-acid#page=19)) make 24 V × 220 Ah =
5,280 Wh, about **2 days** at 40% *(arithmetic)*.

**The cheaper fix:** use less in winter, add panels (salvaged ones are plentiful), and fill the gap with
creek hydro or a generator. When either more panels or more batteries would do, **add panels**; don't put a
new battery into an aged bank ([IEA, p. 38](lib:iea-pvps-recommended-practices-for-charge#page=38)).

**Controller:** at 24 V with an MPPT controller, 630 W ÷ 24 V × 1.25 ≈ 33 A, so a 40 A controller
([Arizona, p. 4](lib:univ-of-arizona-extension#page=4)).

📚 **Go deeper:** [Sandia, p. 20](lib:sandia-sizing-small#page=20) — a full worked example; [IEA *Lead-Acid Battery Guide*, p. 17](lib:iea-pvps-lead-acid#page=17) — battery sizing. Pictures: [🖼️ 2 V cells wired into a 24 V bank, Arizona p. 5](lib:univ-of-arizona-extension#page=5).

## 🔍 Salvaging and testing panels

**Count the cells:** 36 cells is a "12 V" panel; 60 cells give about 30 V, and 72 cells about 36 V
([Arizona, p. 2](lib:univ-of-arizona-extension#page=2); [🖼️ reading a panel's label](lib:univ-of-arizona-extension#page=3)). House-roof panels are 60- or 72-cell; they charge
a 12 or 24 V bank well only through an MPPT controller *(rule of thumb)*.

**Rooftop grid-tie systems go dead when the grid does.** A [grid-tied inverter](wiki:Grid-tie_inverter) "cannot operate disconnected
from the grid" ([Navy NWC TP 6563, p. 23](lib:maintenance-of-photovoltaic#page=23); [🖼️ grid-tied system](lib:maintenance-of-photovoltaic#page=13)); modern string and
micro-inverters shut down the same way, by design *(rule of thumb)*. The panels are fine: rewire them
through a charge controller to batteries.

**Testing a used panel** ([Navy, pp. 26, 50–51](lib:maintenance-of-photovoltaic#page=50)):
1. Look for cracked glass and peeling layers (delamination).
2. In clear sun, face the panel squarely at the sun.
3. **Open-circuit voltage** (nothing connected): within 10% of the label, allowing for heat (hot panels
   read lower) ([🖼️ drawing](lib:maintenance-of-photovoltaic#page=47)).
4. **Short-circuit current** ([🖼️ drawing](lib:maintenance-of-photovoltaic#page=52)): [meter](wiki:Multimeter) on its 10 A range across the leads, one panel at a time *(rule of
   thumb)*: within 20% of the label.

![Testing a used solar panel: first a meter on DC volts across the leads with nothing else connected, then the meter on its 10 amp range with the red lead in the 10 A jack](img:OFF-GRID-POWER-GUIDE/testing-a-used-panel.svg)
*Open-circuit volts first, then short-circuit amps on the 10 A range, one panel at a time (a diagram drawn for this guide).*

A 20-year-old panel usually still makes 80–90% of its label *(rule of thumb)*. Wash panels with plain water
**early in the morning**, so cold water can't crack hot glass (p. 26). **Bypass diodes** let current flow
around a dead module; a **blocking diode** stops the battery draining back through the panels at night
(p. 19).

📚 **Go deeper:** [Navy *Maintenance of Photovoltaic Power Systems*](lib:maintenance-of-photovoltaic#page=50) — testing and troubleshooting with only a voltmeter. Pictures: [🖼️ a stand-alone system, Navy p. 11](lib:maintenance-of-photovoltaic#page=11), [Solar cell](wiki:Solar_cell).

## 🎛️ Charge controllers and inverters

| | [PWM](wiki:Charge_controller) | [MPPT](wiki:Maximum_power_point_tracking) |
|---|---|---|
| Panels | Must match the battery (36-cell for 12 V) | Any higher-voltage string, including 60/72-cell house panels |
| Wire | Heavier | Thinner, at higher voltage |
| Size it at | Panel short-circuit amps × parallel strings × 1.25 | Array watts ÷ battery volts × 1.25 |

([Arizona, pp. 3–4](lib:univ-of-arizona-extension#page=3); [🖼️ PWM controllers](lib:univ-of-arizona-extension#page=4);
[🖼️ MPPT controllers](lib:univ-of-arizona-extension#page=5).) The IEA uses × 1.3, because sun off cloud edges
can reach 1,300 W/m² ([IEA, p. 41](lib:iea-pvps-recommended-practices-for-charge#page=41)).

**A good controller has** ([IEA, p. 21](lib:iea-pvps-lead-acid#page=21)):
- an equalize mode and a charge display;
- battery temperature compensation, about −5 mV per °C per cell ([IEA, p. 26](lib:iea-pvps-recommended-practices-for-charge#page=26));
- a **low-voltage load disconnect**, typically off at 12.0 V and back on at 13.2 V for a 12 V battery
  ([p. 36](lib:iea-pvps-recommended-practices-for-charge#page=36));
- a fuse and lightning protection.

**[Inverters](wiki:Power_inverter):** use **pure sine-wave** for electronics and radios
([Arizona, p. 7](lib:univ-of-arizona-extension#page=7)), and size for the motor-start surge. Keep a spare
controller and inverter in a [Faraday can](wiki:Faraday_cage) ([EMP guide](guide:EMP-GUIDE)).

📚 **Go deeper:** [IEA *Recommended Practices for Charge Controllers*](lib:iea-pvps-recommended-practices-for-charge#page=36) — set points and features; [Arizona, p. 7](lib:univ-of-arizona-extension#page=7) — inverter types. Pictures: [🖼️ how controllers switch the charge, IEA p. 15](lib:iea-pvps-recommended-practices-for-charge#page=15), [🖼️ AC and DC loads with an inverter, Arizona p. 6](lib:univ-of-arizona-extension#page=6).

## 🔋 Choosing batteries and reading their charge

Batteries wear out. For storing energy without them (a high water tank, hot water, stone and ice), see
[Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE).

**Best to worst for solar:** solar batteries; then leisure, golf-cart and traction batteries; then truck
starting batteries. **Avoid [car batteries](wiki:Automotive_battery)** ([IEA, p. 13](lib:iea-pvps-lead-acid#page=13)). A car battery
survives about **20 deep discharges**. A [deep-cycle](wiki:Deep-cycle_battery) battery emptied 80% each
time lasts about 800 cycles; emptied 20%, about 6,000
([Practical Action *Batteries*, p. 5](lib:practical-action-batteries#page=5)).

**Count on 40% of the label:** a battery is worn out at 80% of new capacity, and should give at most
half of that a day: 0.8 × 0.5 = 0.4 ([IEA, p. 17](lib:iea-pvps-lead-acid#page=17)). Series adds volts;
parallel adds amp-hours ([🖼️ drawing](lib:practical-action-batteries#page=1)). No more than 3–4 strings in parallel, all the same age and size, with equal
cables ([p. 18](lib:iea-pvps-lead-acid#page=18)).

![Four 6-volt, 220 amp-hour batteries in series make 24 volts and 220 amp-hours; two 12-volt, 100 amp-hour batteries in parallel make 12 volts and 200 amp-hours; one fuse at the bank's positive post](img:OFF-GRID-POWER-GUIDE/series-and-parallel-batteries.svg)
*Series adds volts, parallel adds amp-hours; the main fuse goes right at the bank's + post (a diagram drawn for this guide).*

**How full is it?**
- **Voltage at rest:** a 12 V [lead–acid battery](wiki:Lead–acid_battery) reads 12.0 V empty to 12.9 V
  full ([IEA, p. 26](lib:iea-pvps-lead-acid#page=26)). Half-full is about 12.2 V, and 12.4 V is about three-quarters *(typical flooded-battery tables)*.
- **Under load,** never below about **10.8 V** ([p. 15](lib:iea-pvps-lead-acid#page=15)).
- **[Hydrometer](wiki:Hydrometer)** ([🖼️ how to read one](lib:neets-module-01#page=95)): full is about 1.280; recharge below 1.250
  ([Navy CE, p. 68](lib:us-navy-construction-electrician#page=68)). In cycled solar batteries it reads true
  only after an equalizing charge ([IEA, p. 26](lib:iea-pvps-lead-acid#page=26)).

![Three battery hydrometers: the scale is read where the acid's surface meets the float, 1.150 in a weak cell and 1.270 in a nearly full one](img:OFF-GRID-POWER-GUIDE/hydrometer.png)
*Draw acid in with the bulb and read the float at the acid's surface: 1.150 is run down, 1.270 nearly full ([NEETS 1, p. 95](lib:neets-module-01#page=95)).*

**Heat and cold:** at 14 °F a battery gives only 60% of its capacity, and every 18 °F above 68 °F doubles
plate corrosion ([IEA, pp. 18–19](lib:iea-pvps-lead-acid#page=18)). A **discharged battery can freeze and
crack**; protect it below about 19 °F ([IEA controllers, p. 31](lib:iea-pvps-recommended-practices-for-charge#page=31)).
Here: shade batteries from 100 °F summer heat and insulate them for January cold snaps (the record low is
−6 °F) *(rule of thumb)*.

**Storage:** recharge stored lead-acid batteries every 3–6 months ([IEA, p. 23](lib:iea-pvps-lead-acid#page=23)),
sealed ones every 3 ([Practical Action, p. 6](lib:practical-action-batteries#page=6)).

📚 **Go deeper:** [IEA *Lead-Acid Battery Guide for Stand-Alone PV*](lib:iea-pvps-lead-acid#page=13) — choosing, sizing and care; [Practical Action *Batteries*](lib:practical-action-batteries#page=5) — plain-language basics. Pictures: [🖼️ inside a lead-acid battery, Navy p. 20](lib:maintenance-of-photovoltaic#page=20), [🖼️ parts of a cell, DOE-HDBK-1084 p. 17](lib:doe-primer-on-lead-acid#page=17).

## 💧 Keeping lead-acid alive

**Watering:** use **[distilled water](wiki:Distilled_water), added after charging**, up to the fill line. In freezing weather add
water only if a charge follows, or it may freeze before it mixes
([DOE-HDBK-1084, p. 44](lib:doe-primer-on-lead-acid#page=44)). If the plates show, top up at once; clean
rainwater will do now and then ([IEA, p. 25](lib:iea-pvps-lead-acid#page=25)). **Adding acid doesn't
recharge a battery** ([NEETS 1, p. 97](lib:neets-module-01#page=97)).

**Equalizing** is a deliberate overcharge that brings every cell up and stirs the acid
([IEA, p. 27](lib:iea-pvps-recommended-practices-for-charge#page=27); [🖼️ gassing vs. voltage chart](lib:iea-pvps-recommended-practices-for-charge#page=25)):
- **Flooded:** hold about 2.45–2.50 V per cell (**14.7–15.0 V** on 12 V) for about 5 hours.
- **AGM:** only about 2.35 V per cell (**14.1 V**) for about 8 hours
  ([p. 46](lib:iea-pvps-recommended-practices-for-charge#page=46)). Gel or AGM higher only if the maker
  allows ([p. 21](lib:iea-pvps-recommended-practices-for-charge#page=21)).
- Remove catalytic recombiner caps first (p. 27).
- **With a hydrometer:** charge at about 5 A until specific gravity stays steady for 4 hours, easing
  off if the acid reaches 110 °F ([Navy CE, p. 67](lib:us-navy-construction-electrician#page=67)).
- **How often:** monthly, or when cells drift apart *(rule of thumb)*. **Never equalize lithium.**

**"Desulfators":** plate sulfate from sitting deeply discharged "can never be recovered"
([IEA, p. 23](lib:iea-pvps-lead-acid#page=23)); equalizing restores cells that were only undercharged
([p. 20](lib:iea-pvps-lead-acid#page=20)). Treat pulse gadgets as unproven: equalize, then time the
battery under a known load before trusting it *(rule of thumb)*.

**Cleaning:** neutralize spilled acid with about 1 kg [baking soda](wiki:Sodium_bicarbonate) in 4 L water (2 lb per gallon), then
rinse ([DOE-HDBK-1084, pp. 44–45](lib:doe-primer-on-lead-acid#page=44)). Grease the terminals
([IEA, p. 25](lib:iea-pvps-lead-acid#page=25)).

📚 **Go deeper:** [DOE *Primer on Lead-Acid Storage Batteries*](lib:doe-primer-on-lead-acid#page=44) — watering, charging and care; [IEA controllers, p. 46](lib:iea-pvps-recommended-practices-for-charge#page=46) — charge set points. Pictures: [🖼️ voltage and specific gravity through a charge, DOE-HDBK-1084 p. 29](lib:doe-primer-on-lead-acid#page=29).

## 💥 Battery safety

**Hydrogen** ([DOE-HDBK-1084, pp. 22, 46](lib:doe-primer-on-lead-acid#page=46)):
- Overcharging makes about 0.42 L of hydrogen per amp-hour **in each cell** — about 2.5 L for a
  6-cell 12 V battery, 5 L for a 12-cell 24 V bank *(arithmetic)* — and 4% in air can explode.
- Many explosions follow **long, unregulated charging of a battery out of its vehicle**: moving it vents
  gas, and a spark sets it off.
- Vent from the **highest point** of the room; hydrogen collects under the ceiling
  ([IEA, p. 24](lib:iea-pvps-lead-acid#page=24)). Put conduit openings below the battery tops
  ([Sandia, p. 51](lib:sandia-pv-systems#page=51)).
- Check water with a flashlight, **never a flame** ([Practical Action, p. 6](lib:practical-action-batteries#page=6)).

**Shorts:** put the main fuse right at the battery's + terminal ([🖼️ fuse and disconnect](lib:sandia-pv-systems#page=48)), and connect the battery last, after all
wiring is checked ([IEA, p. 28](lib:iea-pvps-lead-acid#page=28)). Take off rings and
watches, and tape wrench handles *(rule of thumb)*.

**Acid and gases:** goggles and rubber gloves; flush for 15 minutes. Overcharged batteries can also give
off toxic arsine and stibine; the venting that keeps hydrogen low keeps them low too
([DOE-HDBK-1084, p. 46](lib:doe-primer-on-lead-acid#page=46)).

**Where batteries go:** out of living areas and not under electrical panels. A lockable polyethylene
tool box holds four L-16 batteries ([Sandia, p. 52](lib:sandia-pv-systems#page=52)). Up to
about 20 six-volt batteries in a large, drafty room may not need forced venting (p. 51).

📚 **Go deeper:** [DOE-HDBK-1084](lib:doe-primer-on-lead-acid#page=22) — hydrogen, acid and toxic gases; [Sandia, p. 51](lib:sandia-pv-systems#page=51) — battery rooms and boxes. Pictures: [🖼️ a stationary battery bank, DOE-HDBK-1084 p. 36](lib:doe-primer-on-lead-acid#page=36), [Goggles](wiki:Goggles).

## 🔥 Lithium, LiFePO4 and salvaged packs

**Types** ([Lighting Global, pp. 3, 10](lib:lighting-global#page=3); [🖼️ cylindrical, prismatic and pouch cells](lib:lighting-global#page=4)):
- **[LiFePO4 (LFP)](wiki:Lithium_iron_phosphate_battery)**, 3.2 V per cell: the safest and longest-lived
  (1,000+ full cycles), but bulkier.
- **Phone, laptop, tool and e-bike cells** pack more energy but are less stable.
- **Every pack needs a [battery management system (BMS)](wiki:Battery_management_system).**

**Charging rules** ([Lighting Global, pp. 6–8](lib:lighting-global#page=6)):
- Overcharge tolerance can be **50 mV or less** per cell, and cells in series must be balanced.
- **Never charge below 32 °F (0 °C)** or above about 113 °F: cold charging grows metal "dendrites" that
  short the cell and start fires. NFPA says 32–105 °F ([NFPA, p. 1](lib:nfpa-lithium#page=1)).
- Draining a cell below 2.5–3 V can ruin it. **Store at 20–40% charge** near room temperature.
- A 12.8 V LiFePO4 bank charges at about 14.2–14.6 V and needs no equalizing; follow the maker's datasheet
  *(rule of thumb)*. In our winters, keep it where it stays above freezing, or use a BMS with a cold-charge
  cutoff *(rule of thumb)*.

**Salvaged e-bike and tool packs:** stop using one that smells, changes color, heats, swells, leaks or
makes odd noises. Charge it with its own charger, never on a bed or couch, and not after it's full
([NFPA, p. 1](lib:nfpa-lithium#page=1)). Discard swollen, dented or long-dead packs; never build packs from
mixed salvaged cells without a balancing BMS; in fire season, charge in a detached shed, on stone
*(rule of thumb)*.

**If one burns** ([FAA SAFO 09013](lib:faa-safo#page=1)): one cell's
[thermal runaway](wiki:Thermal_runaway) sets off the next, and the fire flares again and again.
1. Put out the flames with water or any extinguisher.
2. **Soak the pack with water to cool it.** Don't cover it, use ice, or pick it up.
3. Get out of a room with a burning battery bank: the gas is toxic and flammable, and a pack can reignite
   hours or days later ([fire FAQ, pp. 2–3](lib:home-lithium-ion-battery-fire#page=2)).

📚 **Go deeper:** [Lighting Global *Lithium-ion Batteries*](lib:lighting-global#page=6) — types, charging and storage; [Home Lithium-Ion Battery Fire Safety FAQ](lib:home-lithium-ion-battery-fire#page=2) — fire behavior. Pictures: [🖼️ lithium batteries for solar, Arizona p. 5](lib:univ-of-arizona-extension#page=5), [Lithium-ion battery](wiki:Lithium-ion_battery).

## 🔌 Wiring, fuses and grounding

**[Voltage drop](wiki:Voltage_drop):** volts lost = 2 × one-way feet × amps × (ohms per 1,000 ft) ÷ 1,000. Aim for 3–5% loss
between array and battery ([IEA, p. 53](lib:iea-pvps-recommended-practices-for-charge#page=53)).
**Longest one-way run for a 3% drop at 10 amps** (copper; halve it for 20 A, double it for 5 A), from
[NEETS 4, p. 20](lib:neets-module-04#page=20) *(arithmetic)*:

| [Wire](wiki:American_wire_gauge) | Ohms per 1,000 ft | 12 V | 24 V | 48 V |
|---|---|---|---|---|
| 10 AWG | 1.02 | 18 ft | 35 ft | 71 ft |
| 8 AWG | 0.641 | 28 ft | 56 ft | 112 ft |
| 6 AWG | 0.403 | 45 ft | 89 ft | 179 ft |
| 4 AWG | 0.253 | 71 ft | 142 ft | 285 ft |
| 2 AWG | 0.159 | 113 ft | 226 ft | 453 ft |

- Example: 240 W at 12 V (20 A) over 50 ft of 10 AWG loses 2 V, about 17%. At 24 V it loses 1 V, about 4%
  *(arithmetic)*.
- Hot wire loses more: Sandia figures **11.2 V lost** in 400 ft of 8 AWG at 36 A
  ([p. 102](lib:sandia-pv-systems#page=102)). Round up a size.
- Minimum: 14 AWG on a 10 A fuse, 12 AWG on a 20 A fuse ([IEA, p. 33](lib:iea-pvps-lead-acid#page=33)).

**[Fuses](wiki:Fuse_(electrical)) must be DC-rated.** Car blade and glass fuses are made for 32 V or less and can't safely stop the huge current of a
battery short; keep them off battery and array circuits ([Sandia, p. 42](lib:sandia-pv-systems#page=42)). Protect the
battery cable with a current-limiting DC fuse (class T or RK5) close to the battery (p. 45). Use
time-delay fuses where motors start ([NEETS 3, p. 94](lib:neets-module-03#page=94)).

![Wiring of a small solar system: panels through a DC fuse to the charge controller, the controller's load terminals through a 10 amp fuse to 12-volt lights, and the battery bank with a fuse right at the positive post for each wire, a main class T or RK5 fuse to the inverter, and the DC negative bonded to a ground rod at one point](img:OFF-GRID-POWER-GUIDE/system-wiring-with-fuses.svg)
*Every wire leaving the battery's + post gets its own DC-rated fuse right at the post; connect the battery last (a diagram drawn for this guide).*

**[Grounding](wiki:Ground_(electricity)):** bond the DC negative to ground at **one point only**
([Sandia, p. 31](lib:sandia-pv-systems#page=31); [🖼️ example grounding system](lib:sandia-pv-systems#page=35)). Drive ground rods 8 ft deep with #6 copper
([FM 5-424, p. 49](lib:us-army-fm-5-424#page=49)), about 6 ft apart if you use several (p. 117). For
lightning, use one ground electrode, bond all metal frames, and run + and − wires side by side so they
don't form loops ([IEA *Lightning*, pp. 7, 13](lib:iea-pvps-lightning#page=7); [🖼️ bad and good module wiring](lib:iea-pvps-lightning#page=14)).

![A ground rod driven 8 feet down into moist soil, with number 6 copper wire wrapped and clamped at its top](img:OFF-GRID-POWER-GUIDE/ground-rod.png)
*A ground rod driven 8 ft deep into moist soil, with #6 copper wire to it ([FM 5-424, p. 49](lib:us-army-fm-5-424#page=49)).*

📚 **Go deeper:** [Sandia *PV Systems and the NEC*](lib:sandia-pv-systems#page=42) — fuses, disconnects, grounding; [Army FM 5-424](lib:us-army-fm-5-424#page=49) — ground rods. Pictures: [🖼️ crimpers and terminals, Sandia p. 21](lib:sandia-pv-systems#page=21), [🖼️ wire on terminals, FM 5-424 p. 24](lib:us-army-fm-5-424#page=24), [Crimp](wiki:Crimp_(joining)).

## ⛽ Generators, cars and backfeed

- **Never backfeed.** A generator plugged into a wall outlet sends power out onto the lines and can
  electrocute line workers and neighbors on the same transformer
  ([CPSC, p. 1](lib:cpsc-portable-generator#page=1)). Use a [transfer switch](wiki:Transfer_switch) ([🖼️ diagram](lib:emergency-power-systems-for-critical-facilities#page=125)), or
  plug appliances straight into the generator. **Outdoors only**: [carbon monoxide](wiki:Carbon_monoxide_poisoning).
- **Run a generator under full load:** charge batteries while it does other work
  ([IEA, p. 46](lib:iea-pvps-recommended-practices-for-charge#page=46); [🖼️ solar-plus-generator layout](lib:iea-pvps-recommended-practices-for-charge#page=44)). Violent gassing means the charge
  rate is too high ([Navy CE, p. 67](lib:us-navy-construction-electrician#page=67)).
- A generator's small "12 V DC" outlet is a weak, unregulated charger; a proper multi-stage charger on its
  AC is better *(rule of thumb)*.
- **From a car:** connect + to +, − to − ([*Alternator and Regulator Servicing*, p. 48](lib:alternator-and-regulator#page=48)).
  Disconnect a car's battery before putting a fast charger on it, or you can burn out the car's diodes
  (p. 47). A car [alternator](wiki:Alternator_(automotive)) rarely fills a deep-cycle bank, and idling for hours wastes fuel and makes CO
  *(rule of thumb)*.

![Wrong: a generator plugged into a wall outlet sends power back through the house panel and out onto the power line, where it can kill a line worker. Right: a transfer switch connects the house panel to either the grid or the generator, never both](img:OFF-GRID-POWER-GUIDE/never-backfeed.svg)
*A generator in a wall outlet sends power out onto the lines; a transfer switch connects the house to the grid or the generator, never both (a diagram drawn for this guide).*

📚 **Go deeper:** [CPSC *Portable Generator Hazards*](lib:cpsc-portable-generator#page=1) — CO and backfeed; [*Alternator and Regulator Servicing*](lib:alternator-and-regulator#page=47) — charging and testing. Pictures: [🖼️ how an alternator works, p. 8](lib:alternator-and-regulator#page=8), [Engine-generator](wiki:Engine–generator).

## 🌊 Creek hydro, and why not wind

*While Oregon's water laws are enforced,* most Illinois Valley creeks are closed to hydro by state rule
(see [Start Here](guide:ILLINOIS-VALLEY-START-HERE)).

**Measure the drop (head)** ([🖼️ what head means](lib:nrcan-micro-hydropower-systems-a-buyers#page=9)): run a hose full of water downhill with a pressure gauge at the bottom;
**psi × 2.31 = feet of head** ([NCAT, p. 6](lib:ncat-attra-micro-hydro#page=6)).

**Measure the flow:** time how long the creek takes to fill a container: a 55-gal drum in 40 seconds is
82.5 gallons a minute (gpm) ([NCAT, p. 3](lib:ncat-attra-micro-hydro#page=3)). For a bigger creek: width × average
depth (sq ft) × float speed (ft per second) × 0.25 for a shallow rocky bed, up to 0.75 for a smooth one,
gives cubic feet per second (cfs); 1 cfs = 449 gpm (p. 4; [🖼️ measuring a stream's cross-section](lib:ncat-attra-micro-hydro#page=3)).

**Power from a creek ≈ gpm × feet of head ÷ 10 watts** ([NCAT, pp. 8–9](lib:ncat-attra-micro-hydro#page=8)). A real
case: 100 gpm with 35 ft of head left at the turbine (15 psi) gives **about 200 W around the clock**,
nearly 5 kWh a day, to a 24 V bank ([NRCan, p. 29](lib:nrcan-micro-hydropower-systems-a-buyers#page=29)).
The rule predicts 350 W: small systems often fall short.

![Measuring creek hydro: a hose full of water runs from the intake down the hill to a pressure gauge, and the drop is psi times 2.31 feet; flow is timed by how long the creek takes to fill a 55-gallon drum](img:OFF-GRID-POWER-GUIDE/measuring-head-and-flow.svg)
*Head from a hose and a pressure gauge, flow from a drum and a watch (a diagram drawn for this guide).*

**Pipe size matters.** Head lost per 100 ft of PVC ([NCAT, p. 7](lib:ncat-attra-micro-hydro#page=7)):

| Flow | 2-in | 3-in | 4-in |
|---|---|---|---|
| 25 gpm | 1.3 ft | 0.2 ft | 0.04 ft |
| 50 gpm | 4.7 ft | 0.7 ft | 0.2 ft |
| 100 gpm | 16.8 ft | 2.3 ft | 0.6 ft |
| 200 gpm | 60.6 ft | 8.4 ft | 2.0 ft |

- **Size for late-summer low flow** ([NCAT, p. 2](lib:ncat-attra-micro-hydro#page=2);
  [NRCan, p. 12](lib:nrcan-micro-hydropower-systems-a-buyers#page=12)). Only about 15% of the county's rain
  falls April–September ([Soil Survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)),
  and small creeks shrink sharply or dry up. Measure yours in September and in winter *(rule of thumb)*.
- **Hydro is strongest in winter, when solar is weakest.** A 400 W turbine with batteries and an inverter
  can still supply 5 kW peaks ([NRCan, p. 28](lib:nrcan-micro-hydropower-systems-a-buyers#page=28)).
- **Salvaging a generator** for the turbine (standard or inverter type), belts and speed matching: see
  "Reusing a generator for water or wind power" in the [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE).
- Use a **dump-load (diversion) controller**, not a solar controller ([NCAT, p. 18](lib:ncat-attra-micro-hydro#page=18);
  [🖼️ how a load controller is wired](lib:nrcan-micro-hydropower-systems-a-buyers#page=15)).
  See [micro hydro](wiki:Micro_hydro) and the [Pelton wheel](wiki:Pelton_wheel) ([🖼️ a small Pelton runner](lib:nrcan-micro-hydropower-systems-a-buyers#page=23)).
- **Screen the intake** ([🖼️ a wooden intake screen](lib:nrcan-micro-hydropower-systems-a-buyers#page=20)): openings no larger than 3/32 in; passive screen area (sq ft) = flow (cfs) ÷ 0.2,
  ([ODFW, p. 1](lib:oregon-odfw-fish#page=1)). For 100 gpm, about 1.1 sq ft
  *(arithmetic)*.

**[Small wind](wiki:Small_wind_turbine) is usually poor here.** An off-grid wind system needs an average
of at least **9 mph** ([DOE *Small Wind*, p. 20](lib:doe-small-wind#page=20)). Medford averages **4.7 mph**,
and 3.6 in December ([Redbook, p. 181](lib:nrel-solar-radiation#page=181)). Power rises with the cube of
wind speed, so half the wind gives one-eighth the power ([p. 11](lib:doe-small-wind#page=11)), and the
rotor must sit 30 ft above anything within 300 ft ([p. 7](lib:doe-small-wind#page=7)). Only exposed
ridgetops are worth testing; put money into solar and hydro first *(rule of thumb)*.

📚 **Go deeper:** [NCAT *Micro-Hydro Power*](lib:ncat-attra-micro-hydro#page=3) — measuring and sizing; [NRCan *Buyer's Guide*](lib:nrcan-micro-hydropower-systems-a-buyers#page=28) — battery systems; [DOE *Small Wind*](lib:doe-small-wind#page=20). Pictures: [🖼️ parts of a micro-hydro system, NRCan p. 6](lib:nrcan-micro-hydropower-systems-a-buyers#page=6), [🖼️ high- and low-head layouts, NCAT p. 13](lib:ncat-attra-micro-hydro#page=13), [🖼️ a battery-based hydro system, NRCan p. 28](lib:nrcan-micro-hydropower-systems-a-buyers#page=28), [Penstock](wiki:Penstock), [Weir](wiki:Weir).

## ⚠️ Old advice in the library to ignore

- **MPPT called "less important" and a risk to reliability** ([IEA, p. 21](lib:iea-pvps-lead-acid#page=21)),
  worth only 5–10% ([IEA controllers, p. 39](lib:iea-pvps-recommended-practices-for-charge#page=39)). It
  is now standard and reliable, and essential for salvaged house panels on a 12 or 24 V bank.
- **Equalizing weekly at 2.5–2.6 V per cell** ([IEA, p. 20](lib:iea-pvps-lead-acid#page=20)) or every 2
  weeks ([IEA controllers, p. 26](lib:iea-pvps-recommended-practices-for-charge#page=26)). Modern makers say
  monthly, or when cells drift *(rule of thumb)*; never past the limit on AGM or gel; never on lithium.
- **LEDs at 25–50 lumens per watt** ([Practical Action *Rural Lighting*, p. 3](lib:practical-action-rural-lighting#page=3)).
  Modern LEDs give about 80–150, so a 9–10 W LED replaces a 60 W bulb.
- **The 1983 appliance table** of 300 W fridges and tube radios
  ([DOE Microhydro, p. 66](lib:doe-microhydropower-handbook-vol-1-part-1#page=66)). Measure your own.
- **"Waking up" NiCd cells by fully discharging them** ([Practical Action *Batteries*, p. 4](lib:practical-action-batteries#page=4)).
  Only for old sealed NiCd, never NiMH or lithium. (Its warning that a flat series pack can
  reverse-charge its weakest cell still holds.)
- **Car batteries for lighting** ([*Rural Lighting*, p. 5](lib:practical-action-rural-lighting#page=5)).
  About 20 deep cycles: a stopgap only.
- **Sandia's NEC section numbers** ([Sandia](lib:sandia-pv-systems#page=15)) are from the 1999 code;
  the principles still hold.
- **1930s–70s wind and generator books** ([*Homemade Six-Volt Wind-Electric Plants*](lib:homemade-six-volt),
  [*Wind Power for Farms*](lib:wind-power-for-farms)) predate modern charge control. Add a dump-load
  controller and a fused battery.
- **"Water is useless on lithium fires."** It won't stop the chemistry, but it is the best way to cool
  the cells and stop the spread ([FAA](lib:faa-safo#page=1); [Lighting Global, p. 8](lib:lighting-global#page=8)).
  Use lots, from a distance, outdoors if you can, and expect flare-ups.

📚 **Go deeper:** [Lighting Global](lib:lighting-global#page=10) — modern battery chemistries compared; [Arizona Extension](lib:univ-of-arizona-extension#page=5) — today's MPPT controllers and solar batteries, pictured; [LED lamp](wiki:LED_lamp).

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**How a system fits together**
- Block diagrams of a solar system — [🖼️ Arizona, p. 1](lib:univ-of-arizona-extension#page=1), [🖼️ PA *Solar PV*, p. 4](lib:practical-action-solar-photovoltaic#page=4); [Photovoltaic system](wiki:Photovoltaic_system)
- A simple system, and panels wired in series — [🖼️ Arizona, p. 2](lib:univ-of-arizona-extension#page=2), [🖼️ p. 3](lib:univ-of-arizona-extension#page=3)
- AC and DC loads with an inverter — [🖼️ Arizona, p. 6](lib:univ-of-arizona-extension#page=6)
- Stand-alone and grid-tied systems — [🖼️ Navy, p. 11](lib:maintenance-of-photovoltaic#page=11), [🖼️ p. 13](lib:maintenance-of-photovoltaic#page=13); [Grid-tie inverter](wiki:Grid-tie_inverter)
- The sun's path through the year — [🖼️ NRCS, p. 14](lib:design-of-small-solar-powered-water-pump#page=14); [Solar panel](wiki:Solar_panel)
- A solar pump filling a tank — [🖼️ PA *Solar Pumping*, p. 3](lib:solar-photovoltaic-water-pumping-practical-action#page=3)

**Panels, controllers and inverters**
- Reading a panel's label — [🖼️ Arizona, p. 3](lib:univ-of-arizona-extension#page=3), [🖼️ Sandia, p. 19](lib:sandia-pv-systems#page=19)
- Testing a panel's voltage and current — [🖼️ Navy, p. 47](lib:maintenance-of-photovoltaic#page=47), [🖼️ p. 52](lib:maintenance-of-photovoltaic#page=52); [Multimeter](wiki:Multimeter)
- PWM and MPPT controllers — [🖼️ Arizona, p. 4](lib:univ-of-arizona-extension#page=4), [🖼️ p. 5](lib:univ-of-arizona-extension#page=5); [Charge controller](wiki:Charge_controller)
- How controllers switch the charge — [🖼️ IEA, p. 15](lib:iea-pvps-recommended-practices-for-charge#page=15)
- Inverters and a battery monitor — [🖼️ Arizona, p. 7](lib:univ-of-arizona-extension#page=7); [Power inverter](wiki:Power_inverter)

**Batteries**
- Series and parallel — [🖼️ PA *Batteries*, p. 1](lib:practical-action-batteries#page=1), [🖼️ DOE-HDBK-1084, p. 19](lib:doe-primer-on-lead-acid#page=19)
- Inside a lead-acid battery — [🖼️ Navy, p. 20](lib:maintenance-of-photovoltaic#page=20), [🖼️ DOE-HDBK-1084, p. 17](lib:doe-primer-on-lead-acid#page=17); [Lead–acid battery](wiki:Lead–acid_battery)
- Reading a hydrometer — [🖼️ NEETS 1, p. 95](lib:neets-module-01#page=95); [Hydrometer](wiki:Hydrometer)
- Gassing rises with charge voltage — [🖼️ IEA, p. 25](lib:iea-pvps-recommended-practices-for-charge#page=25)
- Lithium cell types — [🖼️ Lighting Global, p. 4](lib:lighting-global#page=4); [Lithium iron phosphate battery](wiki:Lithium_iron_phosphate_battery)

**Wiring, fuses and grounding**
- Crimpers and terminals — [🖼️ Sandia, p. 21](lib:sandia-pv-systems#page=21), [🖼️ FM 5-424, p. 24](lib:us-army-fm-5-424#page=24)
- Car fuses vs. DC-rated fuses; battery fuse and disconnect — [🖼️ Sandia, p. 42](lib:sandia-pv-systems#page=42), [🖼️ p. 48](lib:sandia-pv-systems#page=48); [Fuse](wiki:Fuse_(electrical))
- Grounding — [🖼️ Sandia, p. 35](lib:sandia-pv-systems#page=35), [🖼️ FM 5-424, p. 49](lib:us-army-fm-5-424#page=49)
- Wiring without loops — [🖼️ IEA *Lightning*, p. 14](lib:iea-pvps-lightning#page=14)
- A transfer switch — [🖼️ FEMA P-1019, p. 125](lib:emergency-power-systems-for-critical-facilities#page=125); [Transfer switch](wiki:Transfer_switch)

**Creek hydro and wind**
- Parts of a micro-hydro system — [🖼️ NRCan, p. 6](lib:nrcan-micro-hydropower-systems-a-buyers#page=6); [Micro hydro](wiki:Micro_hydro)
- Head; high- and low-head layouts — [🖼️ NRCan, p. 9](lib:nrcan-micro-hydropower-systems-a-buyers#page=9), [🖼️ NCAT, p. 13](lib:ncat-attra-micro-hydro#page=13)
- Measuring flow: a stream's cross-section and a weir — [🖼️ NCAT, p. 3](lib:ncat-attra-micro-hydro#page=3), [🖼️ p. 5](lib:ncat-attra-micro-hydro#page=5); [Weir](wiki:Weir)
- An intake screen and a Pelton runner — [🖼️ NRCan, p. 20](lib:nrcan-micro-hydropower-systems-a-buyers#page=20), [🖼️ p. 23](lib:nrcan-micro-hydropower-systems-a-buyers#page=23); [Pelton wheel](wiki:Pelton_wheel)
- Load controller; a battery-based hydro system — [🖼️ NRCan, p. 15](lib:nrcan-micro-hydropower-systems-a-buyers#page=15), [🖼️ p. 28](lib:nrcan-micro-hydropower-systems-a-buyers#page=28)
- Parts of a small wind system — [🖼️ DOE *Small Wind*, p. 7](lib:doe-small-wind#page=7); [Small wind turbine](wiki:Small_wind_turbine)

---

## 🔗 Related guides

- [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — when batteries are gone: water tanks, hot water from the dump load, heat and cold stores
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — the short version and the closed-creek list
- [EMP Guide](guide:EMP-GUIDE) — spare controllers and inverters in a Faraday can
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — generator repair, motors as generators, dump loads
- [Fuel Guide](guide:FUEL-GUIDE) — keeping generator fuel good
- [Water Wells, Pumps, Springs & Cisterns](guide:WATER-WELLS-GUIDE) — the well pump, solar and ram pumps
- [Radio Guide](guide:RADIO-GUIDE) — what you'll most want to power
- [Heat into Work and Power](guide:HEAT-INTO-POWER-GUIDE) — electricity from a stove or fire: thermoelectric generators, steam, hot-air engines
- [Floods, Ice Storms & Heat Waves](guide:FLOODS-STORMS-HEAT-GUIDE) — the first hour of a flood, cleaning up, ice storms, frozen pipes, carbon monoxide, heat waves
- [Chronic Illness With No Pharmacy](guide:CHRONIC-ILLNESS-GUIDE) — diabetes, blood pressure, asthma, seizures and other daily medicines when the pharmacy is gone
- [Salvage: Useful Things From Broken Things](guide:SALVAGE-GUIDE) — what to take from dead washers, freezers and cars, and what to make with it
- [How the Power Grid Works](guide:POWER-GRID-GUIDE) — the grid from plant to plug, its dangers, and running a neighborhood grid
- [Dams, Weirs, Ditches & Ponds](guide:DAMS-DITCHES-GUIDE) — measuring a creek with a weir, intakes, races and water wheels
- [Vehicles, Tractors & Heavy Equipment](guide:VEHICLES-EQUIPMENT-GUIDE) — a vehicle as a power source, and charging an electric car
