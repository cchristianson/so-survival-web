# 📖 Stories, Games and Fun for Long Evenings

How to keep spirits up and children learning when the power is gone and the winter evenings are long: why
stories, play and a steady routine matter so much in hard times, how to open the library's books and e-books,
what to read aloud at each age, teaching reading and numbers at the kitchen table, telling stories with no book,
games that need no power (cards, board games you can scratch on a plank, group and outdoor games, string figures,
pencil-and-paper and word games), toys to make, songs, home-made books and plays, safe light to read by, and a
simple evening routine. The activity books are in `Stories\Games-and-Things-to-Make`; the classic stories are in
`Stories\Picture-Books-and-Rhymes`, `Stories\Read-Aloud-and-Early-Readers`, `Stories\Ages-9-to-13` and
`Stories\Teens-and-Adults`; the McGuffey readers and Ray's arithmetic are in `Children-Learning`; the books on
stress and children are in `Community-Barter\Wellbeing` (all under `Southern-Oregon\`; the download list is
local/library-files.txt). Page numbers are the PDF page numbers, so they match the links.

> ### The short version
> - **Give every day the same shape:** meals, chores, play, a story, bed at the same time. "Children feel safest
>   when there is order and predictability" ([SPR, p. 101](lib:skills-for-psychological-recovery#page=101);
>   [FEMA, p. 189](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=189)).
> - **Read aloud every evening, teens included.** A flame "smaller than that of a birthday candle" is enough to read
>   by with foil behind it ([Kearny, p. 104](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=104)).
> - **Play is how children tell you what scared them.** Disaster or violent play is normal; name the feelings with
>   them. The **same upsetting scene over and over** means they need more help ([PFA, p. 140](lib:psychological-first-aid-field-operations-guide#page=140)).
> - **Fun needs almost nothing:** one deck of cards, a **6-ft string tied into a loop** ([Jayne, p. 36](lib:string-figures-a-study#page=36)),
>   stones on a board scratched into a plank, beans, corn husks, a handkerchief.
> - **Plan one thing to do alone and one with others each day**, and don't let anyone sit alone doing nothing for
>   long ([SPR, pp. 99, 101](lib:skills-for-psychological-recovery#page=99)). Grown-ups too.
> - **Older children can teach and mind younger ones, but not near water:** many child drownings happen "in the
>   company of other children" ([WHO, p. 90](lib:world-report-on-child-injury-prevention#page=90)).
> - **Lamps and matches out of reach of children** ([*Where There Is No Doctor*, p. 22](lib:where-there-is-no-doctor-10-first-aid#page=22));
>   **never fall asleep with a lamp burning** ([FM 21-76, p. 182](lib:fm-21-76-army-survival-manual#page=182)).
> - **Skip the old books' fire balloons, fireworks, gunpowder, melted lead, arsenic and acids.** See "Old advice in
>   the library to ignore".

---

## 🧠 Why stories, play and routine matter

- **Children copy the grown-ups.** They "look to adults for cues about safety" ([PFA, p. 35](lib:psychological-first-aid-field-operations-guide#page=35)),
  and their reactions "are influenced by the behavior, thoughts, and feelings of adults" ([FEMA, p. 189](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=189)).
  A calm evening of cards and a story tells them more than any speech.
- **Routine gives back a sense of control.** Disasters "disrupt normal routines and activities that provide a sense
  of purpose, control, and pleasure"; planning pleasant activities helps mood and control come back
  ([SPR, p. 31](lib:skills-for-psychological-recovery#page=31)). FEMA's list: hug and touch your children, spend
  extra time with them "such as at bedtime", "re-establish your daily routine for work, school, play, meals, and
  rest", and give them real chores so they feel they are helping ([FEMA, p. 189](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=189)).
- **What helps, according to the disaster workers' handbook:** toys, playing cards, board games, balls, paper,
  crayons and books; building blocks, play dough, cut-outs and team games are calming; older children reading to
  younger ones; and for teens, music, games, "making up and telling stories, or making a scrapbook"
  ([PFA, p. 36](lib:psychological-first-aid-field-operations-guide#page=36)). For children it also recommends
  "reading out loud, doing a joint art activity, and playing cards, board games, or sports" ([p. 35](lib:psychological-first-aid-field-operations-guide#page=35)).
- **Singing pulls a group together.** "A short time devoted to singing will do more to unify the people and bring
  them into a neighborly and co-operative spirit than anything else possible" ([*Golden Book*, p. 122](lib:golden-book-of-favorite-songs#page=122)).
- **Join in.** "Nothing can more quickly gain the respect and affection of a child" than a grown-up who plays
  ([Bancroft, p. 40](lib:games-for-the-playground#page=40)).
- **Babies and toddlers learn by play and talk.** From age 2: "Teach your child stories, songs and games. Talk about
  pictures or books" ([WHO/UNICEF cards, p. 2](lib:care-for-child-development#page=2)). With no toys: "Use any
  household objects that are clean and safe. Make simple toys. Play with the child" ([p. 3](lib:care-for-child-development#page=3)).
  The age-by-age table is in "Keeping children learning at home" in the [Childbirth & Children guide](guide:CHILDBIRTH-CHILDREN-GUIDE).
- **Grown-ups need it too.** The SPR worksheet: pick two or three activities, at least one alone and one with
  someone else, and write them on a calendar ([SPR, p. 98](lib:skills-for-psychological-recovery#page=98)).

📚 **Go deeper:** [PFA, pp. 140–141](lib:psychological-first-aid-field-operations-guide#page=140) — parent tip sheets by age; [SPR, pp. 99–101](lib:skills-for-psychological-recovery#page=99) — choosing things to do, for children and parents; [*Care for Child Development*](lib:care-for-child-development#page=2) — play and talk from birth.

## 📱 Opening the books on the library computer or a phone

- **Find them:** in the library, open the **📚 Books** tab and then **📖 Stories & fun**. The activity books in this
  guide and the classic e-books are there; the search box at the top finds a title fast. The McGuffey readers and
  Ray's arithmetic are on the **🩹 Health & medicine** shelf under "Children Learning".
- **E-books open as web pages** on the library computer and on any phone or tablet connected to it, with no reader
  app: a contents page with **Start reading**, then one part at a time with **‹ Prev / Next ›**, **Contents** to jump
  around, and **A− / A+** for smaller or bigger text.
- **It remembers where you stopped.** The contents page shows **Continue where you left off**. The place is kept in
  each phone's own browser, so one child's reading doesn't move another's bookmark.
- **For an e-book app,** tap **save the e-book file** at the bottom of the contents page.
- **PDF books** (the activity books, McGuffey, Ray's) open in the browser's PDF viewer. The page numbers in this
  guide are the viewer's page numbers, not the number printed on the old page.
- **Save power:** one screen, turned dim, read aloud to everyone uses far less battery than a screen each
  *(rule of thumb)*; charging is in the [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE). Setting up the
  library on a phone or another device: [Use on a phone](guide:USE-ON-PHONE) and [Start on any device](guide:START-ON-ANY-DEVICE).

## 📚 Reading aloud by age

**How to read aloud** *(rule of thumb unless cited)*:
- Same time and place every evening, one lamp, everyone close. Little ones on a lap or beside you.
- Read a little slower than you talk, and do the voices. Stop at an exciting moment so they beg for tomorrow.
- **Let them hear favorites again.** Children love "some degree of repetition", along with "action, in close
  sequence" and familiar things "tinged with mystery" ([Bryant, p. 76](lib:how-to-tell-stories-to-children#page=76)).
- Ask "what do you think happens next?" and let a child who can read take a page or a part.
- Don't stop reading aloud when they can read alone: a chapter a night of a long book holds a family together, and
  teens will listen to books that are too hard for them to read yet.
- **Old books, old attitudes.** About 50 of the classics are marked "Some words and attitudes are of its time" in
  their library description. That is a good thing to talk about while reading aloud: how people saw things then,
  and why we see them differently now. With little ones, change a word or skip a page.

The library has 265 classics, all free public-domain e-books in the `Stories\` folders (📚 Books → 📖 Stories & fun).
Each age band below picks a dozen or so to start with; the library description of every book gives its age range and says
whether it has pictures.

### Ages 2–6: picture books and rhymes

- [The Tale of Peter Rabbit](lib:the-tale-of-peter-rabbit) — Peter squeezes under the gate into Mr. McGregor's garden.
  Start here: there are 20 Beatrix Potter picture books, among them [Jemima Puddle-Duck](lib:the-tale-of-jemima-puddle-duck)
  and the charming fox.
- [The Real Mother Goose](lib:the-real-mother-goose) — hundreds of nursery rhymes with color pictures; learn a few by heart.
- [A Apple Pie](lib:a-apple-pie) — Kate Greenaway's alphabet, A to Z: a first letter book.
- [Denslow's Three Bears](lib:denslows-three-bears) and [The Golden Goose Book](lib:the-golden-goose-book) — Goldilocks,
  the Three Little Pigs and Tom Thumb, the first stories to learn to tell.
- [The Little Small Red Hen](lib:the-little-small-red-hen) — who will help plant the wheat? A good one at chore time.
- [The Aesop for Children](lib:the-aesop-for-children) — over 100 short fables with pictures, one a night.
- [A Child's Garden of Verses](lib:a-childs-garden-of-verses) — Stevenson's poems of bedtime, swings and shadows.
- [When We Were Very Young](lib:when-we-were-very-young) — A. A. Milne's poems about Christopher Robin.
- [Millions of Cats](lib:millions-of-cats) — an old man goes out for one pretty cat and comes home with millions.
- [Johnny Crow's Garden](lib:johnny-crows-garden) — a silly rhyming parade of animals.
- [The Hole Book](lib:the-hole-book) — one runaway shot makes a hole through every page, and comic chaos.
- [The Velveteen Rabbit](lib:the-velveteen-rabbit) — how a child's love makes a toy Real.
- [The Baby's Opera](lib:the-babys-opera) — old nursery songs with simple music, for singing together.

The other picture books are in `Stories\Picture-Books-and-Rhymes` (51 in all).

### Ages 5–9: read-aloud chapter books and early readers

- [Winnie-the-Pooh](lib:winnie-the-pooh) and [The House at Pooh Corner](lib:the-house-at-pooh-corner) — Pooh, Piglet
  and Eeyore in the Hundred Acre Wood.
- [The Wonderful Wizard of Oz](lib:the-wonderful-wizard-of-oz) — and 13 more Oz novels after it, a whole winter's
  reading. [Little Wizard Stories of Oz](lib:little-wizard-stories-of-oz) are bedtime-sized.
- [The Box-Car Children](lib:the-box-car-children) — four orphans make a home in an old boxcar in the woods and learn
  to take care of themselves.
- [The Adventures of Buster Bear](lib:the-adventures-of-buster-bear) — one of seven Burgess animal storybooks; the
  [Burgess Bird Book](lib:the-burgess-bird-book-for-children) teaches the birds around the house.
- [Grimm's Fairy Tales](lib:grimms-fairy-tales), [The Blue Fairy Book](lib:the-blue-fairy-book) and
  [English Fairy Tales](lib:english-fairy-tales) — Hansel and Gretel, Cinderella, Jack and the Beanstalk.
- [Just So Stories](lib:just-so-stories) — how the elephant got his trunk (of its time in places).
- [The Wind in the Willows](lib:the-wind-in-the-willows) — Mole, Rat, Badger and boastful Mr. Toad.
- [Pinocchio](lib:pinocchio) — a puppet learns the hard way that lies make his nose grow.
- [Alice's Adventures in Wonderland](lib:alices-adventures-in-wonderland) — down the rabbit hole.
- [The Story of Doctor Dolittle](lib:the-story-of-doctor-dolittle) — the doctor who talks to animals (of its time in places).
- [Uncle Wiggily's Adventures](lib:uncle-wiggilys-adventures) — short bedtime stories of an old rabbit gentleman.
- [Fifty Famous Stories Retold](lib:fifty-famous-stories-retold) — short, easy stories (William Tell, King Alfred)
  for a child's first reading alone.

The rest are in `Stories\Read-Aloud-and-Early-Readers` (55 in all).

### Ages 9–13: chapter books

- [Treasure Island](lib:treasure-island) — Jim Hawkins, a treasure map and Long John Silver.
- [Heidi](lib:heidi) — an orphan girl, her gruff grandfather and the goats in the Alps.
- [Little Women](lib:little-women) — four sisters through hard times, home-made plays and first loves.
- [Anne of Green Gables](lib:anne-of-green-gables) — a talkative orphan sent by mistake to a farm.
- [The Secret Garden](lib:the-secret-garden) — a lonely girl brings a forgotten garden back to life.
- [Understood Betsy](lib:understood-betsy) — a timid city girl learns to think and do for herself on a farm.
- [Black Beauty](lib:black-beauty) — a horse tells his own life story; good for any family with animals.
- [The Jungle Book](lib:the-jungle-book) — Mowgli, the wolves, and Rikki-Tikki-Tavi.
- [The Adventures of Tom Sawyer](lib:the-adventures-of-tom-sawyer) — the fence, the cave and the graveyard (of its time).
- [Hans Brinker](lib:hans-brinker) — a poor Dutch boy dreams of the great skating race.
- [Wild Animals I Have Known](lib:wild-animals-i-have-known) — Seton's true-to-life stories of Lobo the wolf and others.
- [Paul Bunyan](lib:paul-bunyan) — tall tales told by a Pacific Northwest lumberjack.
- [Poems Every Child Should Know](lib:poems-every-child-should-know) — poems to learn and recite on show night.
- [The Handbook of Conundrums](lib:the-handbook-of-conundrums) — hundreds of riddles for guessing games by the fire.

The rest, including Nancy Drew, the Hardy Boys and Jules Verne, are in `Stories\Ages-9-to-13` (58 in all).

### Teens and adults

- [The Adventures of Sherlock Holmes](lib:the-adventures-of-sherlock-holmes) — twelve short cases, one an evening; Agatha
  Christie's [The Murder of Roger Ackroyd](lib:the-murder-of-roger-ackroyd) for a family guessing game.
- [The Count of Monte Cristo](lib:the-count-of-monte-cristo) — prison, escape, buried treasure and justice.
- [Great Expectations](lib:great-expectations) and [A Christmas Carol](lib:a-christmas-carol) — Dickens at his best aloud.
- [Pride and Prejudice](lib:pride-and-prejudice) — Elizabeth Bennet and proud Mr. Darcy.
- [Adventures of Huckleberry Finn](lib:adventures-of-huckleberry-finn) — Huck and Jim on the Mississippi; much to talk
  about (of its time).
- [Les Misérables](lib:les-miserables) — Jean Valjean rebuilds his life, hunted by Javert.
- [O Pioneers!](lib:o-pioneers) — a woman makes a hard Nebraska homestead thrive.
- [The Odyssey](lib:the-odyssey) — the long voyage home, in plain prose.
- [The Complete Works of William Shakespeare](lib:the-complete-works-of-william-shakespeare) — read the plays aloud in parts.
- [The Spell of the Yukon](lib:the-spell-of-the-yukon) and [Collected Poems of Robert Frost](lib:collected-poems-of-robert-frost) — poems to recite.
- [Three Men in a Boat](lib:three-men-in-a-boat) — when everyone needs a laugh.
- [The Canterbury Puzzles](lib:the-canterbury-puzzles) — over 100 logic and number puzzles, with answers.

The rest are in `Stories\Teens-and-Adults` (101 in all).

### Survival stories for older children and adults

People in hard times have always liked stories of others who made it through *(rule of thumb)*. Read these for
courage and ideas, not as instructions: check anything practical against the guides.

- [Robinson Crusoe](lib:robinson-crusoe) — alone on an island for 28 years, he builds, farms and survives (of its time).
- [The Swiss Family Robinson](lib:the-swiss-family-robinson) — a shipwrecked family builds a treehouse and a farm.
- [The Mysterious Island](lib:the-mysterious-island) — five castaways rebuild everything from scratch (ages 10 and up).
- [The Call of the Wild](lib:the-call-of-the-wild) and [White Fang](lib:white-fang) — Jack London's dogs of the Yukon.
- Jack London's [Lost Face](lib:lost-face), with *To Build a Fire*, a man alone at 75 below, and
  [Love of Life](lib:love-of-life-and-other-stories), a starving man's crawl across the Arctic.
- [South](lib:south-ernest) — true: Shackleton's ship is crushed by the ice, and every man must be brought home.
- [Two Years Before the Mast](lib:two-years-before-the-mast) — true: a student sails round Cape Horn as a common sailor.
- [Walden](lib:walden) — Thoreau's two years living simply in a cabin he built himself.
- [Boy Scouts Handbook (1911)](lib:boy-scouts-handbook-boy-scouts-of-america-1911) — camping, knots, tracking and outdoor
  games; for first aid use the [Field Care guide](guide:FIELD-CARE-GUIDE), not a 1911 book *(rule of thumb)*.

## 🔤 Teaching reading and numbers at the kitchen table

**Reading with McGuffey** ([McGuffey Readers](wiki:McGuffey_Readers)):
1. **Start with the [Primer](lib:mcguffeys-eclectic-primer#page=7):** "Only about six new words are to be mastered in
   each lesson", and you can teach by sounds (phonics), by whole words, by the alphabet, or a mix. The script
   lessons and "slate exercises" at the back teach writing too ([p. 7](lib:mcguffeys-eclectic-primer#page=7)).
2. **Then the [First Reader](lib:mcguffeys-first-eclectic-reader#page=6).** Phonics way: teach the sounds of the letters
   in the lesson, then put them together into words; words way: learn the words at the top of the lesson by sight
   and read without stopping; best is both, words first, then sounds and spelling. Teach writing letters along with
   their names ([p. 6](lib:mcguffeys-first-eclectic-reader#page=6)).
3. **Second and Third Readers** for children reading on their own; the Third has a lesson on reading with
   expression to practise aloud ([Third Reader, p. 14](lib:mcguffeys-third-eclectic-reader#page=14)).

**Numbers with Ray's:**
1. **Count real things first.** "Movable objects are better for exercises in counting than pictures": marbles,
   beans, kernels of corn, or pebbles ([Ray's Primary, p. 11](lib:rays-new-primary-arithmetic#page=11)).
2. **Then the sums to 20,** written out on a slate so they don't count on their fingers. "Teach one thing at a
   time, and teach it thoroughly" (same page). Lesson 1: point to each ball and count, then write the figure
   ([p. 12](lib:rays-new-primary-arithmetic#page=12)).
3. **Mental arithmetic** in [Ray's Intellectual](lib:rays-new-intellectual-arithmetic#page=9) needs no paper and teaches
   a child "to reason, to analyze, to think for himself" (p. 9). Written arithmetic goes on in
   [Ray's Practical](lib:rays-new-practical-arithmetic#page=9); worked answers for parents are in the [Key](lib:key-to-rays-new-arithmetics#page=9).

**Older children teach younger ones.** Structured tutoring works better than now-and-then help; short runs (up to
about four weeks) on basic skills give the best results, math most of all, then reading
([*Peer Tutoring*, p. 18](lib:multigrade-classroom-book-7#page=18)). A child a few years older often sees what a
learner doesn't understand better than an adult does ([p. 19](lib:multigrade-classroom-book-7#page=19)). But
untrained tutors "may resort to threats of punishment and scornful put-downs": show them how to be kind first
([p. 21](lib:multigrade-classroom-book-7#page=21)).

**Games that teach** *(each from the books below)*: Buzz for the 7-times table, Take Fourteen for adding, cribbage
for counting by fifteens, Beast, Bird or Fish for quick naming. Keep lessons short, **15–20 minutes** for young
children, and stop while it is still going well *(rule of thumb)*. Slates, chalk and home-made pencils: "Pencils,
charcoal, chalk and slates" in the [Paper & Ink guide](guide:PAPER-INK-GUIDE).

## 🗣️ Telling stories with no book

From Sara Cone Bryant's *How to Tell Stories to Children* (1905):

1. **Pick a story with action, a little mystery and some repetition**, like *The Three Bears* or *The Three Little
   Pigs* ([p. 76](lib:how-to-tell-stories-to-children#page=76)).
2. **"Know your story."** Don't learn it word for word: memorizing "utterly destroys the freedom" of telling. Tell it
   over and over out loud to an imaginary listener until it flows, keeping only the best phrases of the original
   ([pp. 118–121](lib:how-to-tell-stories-to-children#page=118)).
3. **Seat little children close, in a half-circle,** with you opposite the middle and no child behind another:
   "Little children have to be physically close in order to be mentally close" ([p. 122](lib:how-to-tell-stories-to-children#page=122)).
4. **Be natural.** No sugary voice ([p. 125](lib:how-to-tell-stories-to-children#page=125)); "short, familiar, vivid
   words"; keep the story moving and end it "with a snap" ([p. 127](lib:how-to-tell-stories-to-children#page=127)).
   There's "no need to speak loudly" ([p. 136](lib:how-to-tell-stories-to-children#page=136)).
5. **Tired of the story?** "Make believe" you enjoy it; the real interest usually comes back ([p. 133](lib:how-to-tell-stories-to-children#page=133)).
6. **Afterwards let them retell it, draw it, or play it:** "Who would like to be Red Ridinghood?" ([p. 144](lib:how-to-tell-stories-to-children#page=144)).

The book's second half is stories ready to tell, sorted by age: for the youngest *The Cooky*, *The Pied Piper*,
*The Star Dollars*; for 7–8 *The Cat and the Parrot*, *The Fire-Bringer*, *Little Daylight*; for 9–10 *Arthur and
the Sword*, *Why the Sea is Salt*, *The Little Hero of Haarlem* ([contents, pp. 16–17](lib:how-to-tell-stories-to-children#page=16)).

**Your own stories count most.** Tell how grandparents lived, how the family came to the valley, what you did as a
child; let children make up endings and tell the next part *(rule of thumb)*. A child who can't talk about what
happened may "draw a picture or tell a story of what happened" ([FEMA, p. 189](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=189)).

## 🃏 Card games and board games

One deck of 52 cards is a whole winter of evenings. Rules are in [*Foster's Complete Hoyle*](lib:fosters-complete-hoyle#page=9)
(1914). **Play for beans or matchsticks, never for food, tools or trade goods**: losses of real things start real
fights *(rule of thumb)*.

| Game | Players | Good for | Where |
|---|---|---|---|
| **Old Maid** | Any number | Little ones: take out one queen, pair up cards, draw from your neighbor; whoever is left with the odd queen is the Old Maid | [pp. 537–538](lib:fosters-complete-hoyle#page=537) |
| **Authors** | Any number | Like Go Fish: ask a named player for a named card to collect all four of a kind; needs a good memory | [p. 536](lib:fosters-complete-hoyle#page=536) |
| **Take Fourteen** | 1 | Adding practice: deal 12 piles, take off any two top cards that make 14 (Jack 11, Queen 12, King 13) | [p. 548](lib:fosters-complete-hoyle#page=548) |
| **Klondike** | 1 | The usual solitaire | [p. 548](lib:fosters-complete-hoyle#page=548) |
| **Cassino** | 2–4 | Adding; "unhesitatingly admitted to the domestic circle" | [p. 514](lib:fosters-complete-hoyle#page=514) |
| **Rum** | 2–4 | Sets of three of a kind or three in a row of one suit; 10 cards each for 2 players, 7 for 3, 6 for 4 | [p. 722](lib:fosters-complete-hoyle#page=722) |
| **[Cribbage](wiki:Cribbage)** | 2–4 | Counting: each fifteen is 2 points (5 with a ten or face card, 9 and 6, 8 and 7); "no effort of the memory" | [pp. 478, 484](lib:fosters-complete-hoyle#page=484) |
| **Hearts**, **Euchre** | 4 | Older children and adults | [p. 385](lib:fosters-complete-hoyle#page=385); [p. 300](lib:fosters-complete-hoyle#page=300) |

**Boards you can make** from a plank, a cardboard box lid or the dirt *(rule of thumb)*:
- **Checkers:** 64 squares, **12 men each** on the dark squares, a light square at each player's right
  ([p. 609](lib:fosters-complete-hoyle#page=609)). Chess is on [p. 577](lib:fosters-complete-hoyle#page=577).
- **[Nine men's morris](wiki:Nine_men's_morris):** 9 stones each on a board of three squares; three in a line lets you
  take one of the other player's stones; down to two stones and you lose ([pp. 636–637](lib:fosters-complete-hoyle#page=636)).
- **Go-Bang ([Gomoku](wiki:Gomoku)):** take turns placing stones; first to get **five in a row** in any direction wins
  ([p. 636](lib:fosters-complete-hoyle#page=636)). It works on squared paper.
- **Dominoes:** the standard double-six set has **28 pieces** ([p. 637](lib:fosters-complete-hoyle#page=637)); cut
  them from thin wood and burn or paint the spots *(rule of thumb)*.

![Nine men's morris board: three squares one inside another, joined at the middle of each side, with 24 dots where stones go. Three dark stones in a row along the top are a mill; an arrow shows a stone moving one step along a line](img:STORIES-GAMES-GUIDE/nine-mens-morris.svg)
*Stones go on the 24 dots; three in a line is a mill ([Hoyle, pp. 636–637](lib:fosters-complete-hoyle#page=637); a diagram drawn for this guide).*

## 🏃 Group and outdoor games

**Pick games for the age** ([Bancroft, pp. 27–28](lib:games-for-the-playground#page=27)): about **6 years**, games
with lots of repetition, pretending to be animals or farmers, and one chaser after one runner; **two or three years
later**, catching a whole group, daring, choosing sides; from **11–12**, harder races and team play.

**How to run a game** ([Bancroft, pp. 41–42](lib:games-for-the-playground#page=41)):
- Explain the whole game before anyone plays; walk a few players through it slowly. "Never try to teach and play a
  game at the same time."
- Too many players means bored players: split into smaller groups, and make the rowdiest older children the group
  leaders. Let the players vote on the game.
- Have a new game ready when interest fades, but "children like quiet" too: don't keep them at games all day.

| Game | Where | What | Page |
|---|---|---|---|
| **Hide and Seek** | In or out | Simplest form, for little ones | [p. 125](lib:games-for-the-playground#page=125) |
| **Sardines** | In or out | One hides; whoever finds him squeezes in too | [p. 206](lib:games-for-the-playground#page=206) |
| **Hide the Thimble** | Indoors | Clap or sing louder as the hunter gets closer | [p. 126](lib:games-for-the-playground#page=126) |
| **Drop the Handkerchief** | Circle | Chase round the ring to the empty place | [p. 100](lib:games-for-the-playground#page=100) |
| **Duck on a Rock** | Outdoors | Knock a stone the size of a baseball off a big rock from a line **25 ft** away, then get your stone back without being tagged | [p. 101](lib:games-for-the-playground#page=101) |
| **Pom Pom Pullaway** | Outdoors | Run across the 30–50 ft between two lines when your name is called; whoever is caught helps catch the rest | [p. 179](lib:games-for-the-playground#page=179) |
| **Prisoner's Base** | Outdoors | Team chase for children starting to care about teams | [p. 186](lib:games-for-the-playground#page=186) |
| **Simon Says** | At a table | Thumbs up, down or wiggle only when the leader says "Simon says" first | [p. 275](lib:games-for-the-playground#page=275) |

**Singing games for the little ones:** *Farmer in the Dell* ([p. 309](lib:games-for-the-playground#page=309)),
*London Bridge* ([p. 324](lib:games-for-the-playground#page=324)), *Looby Loo* ([p. 326](lib:games-for-the-playground#page=326)),
*Mulberry Bush* ([p. 329](lib:games-for-the-playground#page=329)), *Oats, Peas, Beans* ([p. 333](lib:games-for-the-playground#page=333)).

**Bean bags** suit little children and indoor games, where a dropped ball rolls away: heavy closely woven cloth
(ticking, duck, denim) **6–12 inches square**,
stitched twice and filled with dried beans or peas; a square of cloth with dried leaves tied up in it will do
([Bancroft, pp. 345–346](lib:games-for-the-playground#page=345)).

**Outdoors safely** *(rule of thumb)*: in Duck on a Rock nobody throws until everyone is behind the line; play in
sight of the house and in groups; everyone in by dusk, when cougars and bears move; no child under 5 near the river,
a pond or a tank unless an adult is right there ([WHO, p. 90](lib:world-report-on-child-injury-prevention#page=90)).

## 🧶 String figures: cat's cradle and more

**The string:** about **6 ft** long, ends tied to make a loop about **3 ft** long. A woven cord kinks less than a
twisted one; tie the ends in a small square knot ([Jayne, p. 36](lib:string-figures-a-study#page=36)). Most figures
start with the hands in the "usual position": **palms facing each other, fingers pointing up** (same page).

**First Position** ([p. 42](lib:string-figures-a-study#page=42)):
1. Put both little fingers in the loop and pull the hands apart.
2. Turn the palms away from you, put each thumb into the little-finger loop from below, pick up the near string on
   the back of the thumb, turn the palms to face each other again and pull tight.

**Opening A**, which starts more than half of all string figures ([pp. 43–44](lib:string-figures-a-study#page=43)):
1. First Position.
2. Put the right index finger up under the string that crosses the left palm, and pull the hands apart (Fig. 12).
3. Put the left index finger up under the string crossing the right palm, between the strings on the right index,
   and pull apart (Fig. 13). Now there is a loop on each thumb, index and little finger (Fig. 14). Always right
   first, then left ([p. 44](lib:string-figures-a-study#page=44)).

![Three drawings of hands in string: the right index finger picking up the string across the left palm, the left index picking up the string across the right palm, and the finished Opening A with loops on both thumbs, index fingers and little fingers](img:STORIES-GAMES-GUIDE/string-opening-a.png)
*Opening A: right index first (Fig. 12), then left (Fig. 13), and the finished opening (Fig. 14) ([Jayne, pp. 43–44](lib:string-figures-a-study#page=43)).*

**Osage Diamonds, also called Jacob's Ladder** ([pp. 60, 63–65](lib:string-figures-a-study#page=60)):
1. Opening A.
2. Drop the thumb loops and pull the hands apart.
3. Each thumb goes away from you **under** all the strings and picks up the far little-finger string from below.
4. Each thumb goes away from you **over** the near index string and picks up the far index string from below.
5. Drop the little-finger loops and pull apart.
6. Each little finger goes toward you over the near index string and picks up the far thumb string from below.
7. Drop the thumb loops.
8. Each thumb goes away from you over the index loop and picks up the near little-finger string from below.
9. With the other hand, lift the near index string of each hand and put it over that thumb. Pull apart.
10. Slip the lower loop on each thumb off over the upper one, keeping the upper loop on.
11. Put each index finger down into the little triangle by the thumb, turn the palms down, drop the little-finger
    loops, pull apart and turn the palms away from you: the diamonds appear (Fig. 50).

![The finished Osage Diamonds (Jacob's Ladder) string figure: a row of diamonds stretched between two hands](img:STORIES-GAMES-GUIDE/string-osage-diamonds.png)
*The finished figure; turn the palms away from you to pull it tight ([Jayne, p. 65](lib:string-figures-a-study#page=65)).*

**Two-player [cat's cradle](wiki:Cat's_cradle):** two people take the string off each other's hands in turn,
through eight named figures: Cradle, Soldier's Bed, Candles, Manger, Diamonds, Cat's Eye, Fish in a Dish, Clock
([p. 386](lib:string-figures-a-study#page=386)). The book has **97 figures** in all ([p. 36](lib:string-figures-a-study#page=36)),
from fish spears to an Apache door: a teen can work through them all winter.

## ✏️ Pencil, paper and word games

All from [Bancroft](lib:games-for-the-playground#page=249) unless noted; most need only voices.

- **Buzz:** count around the circle, but say "Buzz" for 7, any multiple of 7, and any number with a 7 in it;
  a mistake starts it again at one ([p. 254](lib:games-for-the-playground#page=254)).
- **Beast, Bird or Fish:** throw a knotted handkerchief at someone, call "Bird!" and count to ten; they must name a
  bird not named before ([p. 253](lib:games-for-the-playground#page=253)).
- **What Is My Thought Like?** One person thinks of a thing, everyone guesses what it is "like", then each must say
  why the thought is like their answer, however silly ([p. 280](lib:games-for-the-playground#page=280)).
- **Crambo:** everyone writes a question on one slip and a noun on another; mix them, draw one of each, and write
  a verse that answers the question and uses the word ([p. 256](lib:games-for-the-playground#page=256)).
- **Naughts and Crosses** ([tic-tac-toe](wiki:Tic-tac-toe)) on a slate, paper or the ground ([p. 269](lib:games-for-the-playground#page=269)).
- **What Will You Take to the Picnic?** Only the host knows the secret rule (the food must start with the guest's
  initial); the others must work it out ([Girls' Handy Book, p. 178](lib:american-girls-handy-book#page=178)).
- **Shadow Verbs:** act out a verb as a shadow on a sheet lit from behind, and the others guess it
  ([Girls' Handy Book, p. 180](lib:american-girls-handy-book#page=180)). Keep the lamp on a steady base well away
  from the sheet *(rule of thumb)*.
- **Twenty questions, I spy, word chains, riddles and spelling bees** need no book at all *(rule of thumb)*.

## ✂️ Things to make

**Corn-husk dolls** ([*Mother Nature's Toy-Shop*, pp. 166–168](lib:mother-natures-toy-shop#page=166)):
1. Use the soft inner husks, about two per doll; soak brittle ones in water.
2. Lay one husk partly over the other, fold across the middle, fold the sides to the back, and wind soft string
   round for the neck and head (Fig. 186), then lower down for the waist (Fig. 187).
3. For arms, roll a husk lengthwise, trim the ends, and tie it at the middle and near each end (Fig. 188).
4. An adult pushes a small knife blade through the shoulders; slide the arms in along the flat of the blade.
5. For a boy doll, split the skirt and tie each half into a leg (Fig. 189).

![Corn-husk doll steps: husks folded and tied at the neck, then at the waist; a rolled husk tied at the middle and ends for arms; the finished doll with arms through the shoulders and the skirt split and tied into legs](img:STORIES-GAMES-GUIDE/corn-husk-doll.png)
*Head and neck, waist, arms, and the finished doll ([*Mother Nature's Toy-Shop*, pp. 167–168](lib:mother-natures-toy-shop#page=167)).*

**More to make** (the books have the drawings):
- **Daisy crowns** woven stem over stem ([*Toy-Shop*, pp. 18–20](lib:mother-natures-toy-shop#page=18)); **burr houses**
  ([p. 124](lib:mother-natures-toy-shop#page=124)); **walnut-shell toys** ([p. 133](lib:mother-natures-toy-shop#page=133)).
- **A handkerchief doll** ([Boys' Handy Book, p. 378](lib:american-boys-handy-book#page=378)) and **whirligigs**
  ([p. 383](lib:american-boys-handy-book#page=383)).
- **A string telephone:** two tins with the bottoms off, wet strong paper tied over one end of each and dried tight
  as a drum, and a waxed string knotted through the middle of each paper ([Girls' Handy Book, p. 246](lib:american-girls-handy-book#page=246)).
- **Music from the field:** a blade of grass stretched between the thumbs ([Boys', p. 185](lib:american-boys-handy-book#page=185)),
  a **corn-stalk fiddle** ([p. 186](lib:american-boys-handy-book#page=186)), a **pumpkin-vine fife** ([p. 187](lib:american-boys-handy-book#page=187)).
- **Kites:** a frame of light sticks, tissue paper stuck on with **flour-and-water paste boiled thick like starch**
  ([Boys', p. 27](lib:american-boys-handy-book#page=27)), a breast-band (bridle) of two strings crossing, and a tail
  ([pp. 28–29](lib:american-boys-handy-book#page=28)); the Japanese square kite is bent back a little and flies two
  tails ([p. 41](lib:american-boys-handy-book#page=41)). Fly them in open fields, never near power lines: lines
  can come live again without warning *(rule of thumb)*.
- **Bean bags, rag balls and dolls** from scraps; see "Group and outdoor games" above.

**Safety and thrift** *(rule of thumb unless cited)*: an adult does the knife work for young children. **Foxglove is
poisonous fresh, dried or boiled** ([WSU, p. 28](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=28)),
so skip the *Toy-Shop*'s foxglove toys ([p. 97](lib:mother-natures-toy-shop#page=97)) with toddlers, and wash hands
after any plant craft. The book also makes toys from lima beans, peas, radishes, apples and oranges: when food is
short, use husks, shells, burrs, seed pods and leaves instead.

## 🎵 Songs

*The Golden Book of Favorite Songs* has 202 songs, 192 of them with the music ([p. 1](lib:golden-book-of-favorite-songs#page=1)). You don't need to read
music: one person who knows the tune leads, and the rest follow. A song leader "need not be a great musician but must
possess qualities of leadership and a strong sense of rhythm" ([p. 122](lib:golden-book-of-favorite-songs#page=122)).

- **Rounds** (one group starts, the next joins a line later): *Row, Row, Row Your Boat* ([p. 50](lib:golden-book-of-favorite-songs#page=50)),
  *Three Blind Mice* ([p. 115](lib:golden-book-of-favorite-songs#page=115)), *Are You Sleeping?* ([p. 117](lib:golden-book-of-favorite-songs#page=117)),
  *Little Tom Tinker* ([p. 120](lib:golden-book-of-favorite-songs#page=120)), *Merrily, Merrily* ([p. 121](lib:golden-book-of-favorite-songs#page=121)).
- **For small children:** *Twinkle, Little Star* ([p. 80](lib:golden-book-of-favorite-songs#page=80)), *The Farmer in the Dell*
  ([p. 88](lib:golden-book-of-favorite-songs#page=88)), *Old MacDonald*, going on "indefinitely" with more animals
  ([p. 122](lib:golden-book-of-favorite-songs#page=122)), *The Tree in the Wood*, which adds a line each verse
  ([p. 123](lib:golden-book-of-favorite-songs#page=123)), *Alouette* ([p. 124](lib:golden-book-of-favorite-songs#page=124)).
- **Lullabies:** *Sweet and Low* ([p. 42](lib:golden-book-of-favorite-songs#page=42)), Brahms' *Cradle Song*
  ([p. 77](lib:golden-book-of-favorite-songs#page=77)), *I Will Sing a Lullaby* ([p. 81](lib:golden-book-of-favorite-songs#page=81)).
  Even feeding time is a time to "look at the child, and talk or sing to the child" ([WHO/UNICEF cards, p. 3](lib:care-for-child-development#page=3)).
- **Old favorites for everyone:** *Home, Sweet Home* ([p. 24](lib:golden-book-of-favorite-songs#page=24)), *Hard Times
  Come Again No More* ([p. 28](lib:golden-book-of-favorite-songs#page=28)), *Loch Lomond* ([p. 36](lib:golden-book-of-favorite-songs#page=36)),
  *Auld Lang Syne* ([p. 37](lib:golden-book-of-favorite-songs#page=37)), *Jingle Bells* ([p. 116](lib:golden-book-of-favorite-songs#page=116)),
  *My Bonnie* ([p. 117](lib:golden-book-of-favorite-songs#page=117)).
- **A "vocal combat":** two groups sing *The Spanish Cavalier* and *Solomon Levi* at the same time ([p. 119](lib:golden-book-of-favorite-songs#page=119)).
- A few 1800s minstrel songs in the book (such as *Massa's in the Cold Ground*, [p. 30](lib:golden-book-of-favorite-songs#page=30))
  are written in the mocking dialect of their day; most families will skip them *(rule of thumb)*.

Work songs, hymns your family knows and songs you make up about the chores count just as much. Singing while
working makes the work go faster *(rule of thumb)*.

## 🎭 Making your own books, plays and newspapers

- **Books:** paper, ink, pens, slates and keeping books dry are in the [Paper & Ink guide](guide:PAPER-INK-GUIDE).
  For little hands, a cloth book of strong linen or colored cambric lasts ([Girls' Handy Book, p. 417](lib:american-girls-handy-book#page=417));
  for any home-made book, two pieces of heavy cardboard with three holes near the edge, laced or tied through
  matching holes in the pages ([p. 423](lib:american-girls-handy-book#page=423)).
- **Children's own books:** each child writes and draws a story, a record of the year, the family tree, or a guide
  to the plants and birds around the house; read them aloud on a show night *(rule of thumb)*.
- **Play the story:** after a story is told, hand out the parts and act it; in a little company "it is an all-star
  cast, and no one realizes any indignity in a subordinate role" ([Bryant, p. 144](lib:how-to-tell-stories-to-children#page=144)).
- **A puppet theater:** an old picture frame about **2 ft by 18 in** with white muslin tacked on the back makes the
  stage ([Boys' Handy Book, p. 347](lib:american-boys-handy-book#page=347)), and the book has a whole puppet play of
  *Puss in Boots* ([p. 358](lib:american-boys-handy-book#page=358)). Put the light on a steady base, well back from
  the cloth *(rule of thumb)*.
- **A family "paper" or club:** the Literary Sketch Club picks a subject; members bring a song, a sketch, a poem or an
  essay about it, and an editor puts out a paper ([Boys' Handy Book, pp. 334–335](lib:american-boys-handy-book#page=334)).
  A hand-written neighborhood news sheet also carries real news *(rule of thumb)*; see the [Community & Barter guide](guide:COMMUNITY-BARTER-GUIDE).

## 🕯️ Light for reading, and fire safety around children

- **One small light, everyone close:** with aluminum foil on three sides and the bottom of a small lamp, hung
  between you and the book, a flame "smaller than that of a birthday candle" is enough to read by, and shelter
  families "will appreciate having someone read aloud to them" ([Kearny, p. 104](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=104)).
  Do crafts and lessons by daylight near a window and save lamp fuel for story time *(rule of thumb)*.
- **Where the lamp sits:** a safe lamp is short and heavy with flat sides so it won't roll; never at the edge of a
  table; don't hang lamps on walls; never add fuel to a burning lamp ([WHO, p. 106](lib:world-report-on-child-injury-prevention#page=106)).
  "Keep lamps and matches out of reach of children" ([*Where There Is No Doctor*, p. 22](lib:where-there-is-no-doctor-10-first-aid#page=22)).
- **Before sleep, every flame out.** Carbon monoxide has no color or smell; "unconsciousness and death can occur
  without warning" ([FM 21-76, p. 182](lib:fm-21-76-army-survival-manual#page=182)).
- **No flame inside paper or cloth:** no candles in paper lanterns, tents, puppet screens or blanket forts
  *(rule of thumb)*. No outdoor fires for fun in fire season, June to October; see the [Wildfire guide](guide:WILDFIRE-GUIDE).
- **A small burn:** clean cool water (not ice) right away, for no longer than 20 minutes; "Never put ice, grease,
  fat" on a burn ([*Where There Is No Doctor*, p. 22](lib:where-there-is-no-doctor-10-first-aid#page=22)). Bigger burns:
  the [Field Care guide](guide:FIELD-CARE-GUIDE).

Making candles and lamps, getting more light from a little flame, and kerosene and children: the
[Lighting guide](guide:LIGHTING-GUIDE), especially "Getting more light from a little flame" and "Fire, fumes, burns and children".

## 🌙 A simple evening routine

A plan that works in most homes *(rule of thumb, built on [FEMA, p. 189](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=189)
and [SPR, p. 101](lib:skills-for-psychological-recovery#page=101): routine, meals together, time at bedtime)*.
Move it earlier in winter, when it is dark by 5.

1. **Before dark:** evening chores done together: water, wood, animals shut in, lamps filled by an adult.
2. **Supper together**, at the table, same time each day. Each person tells one good thing from the day.
3. **Game time, 30–45 minutes:** cards, a board game, string figures, or a quiet game everyone can play.
4. **A song or two**, a round if there are enough voices.
5. **Story time:** a chapter read aloud by the one lamp, or a told story for the little ones.
6. **Bed:** a few minutes with each child; this is when worries come out. Then every flame out.

Once a week, a **show night**: a puppet show, a play, poems recited from McGuffey, a reading from someone's own
book, a song from each person. In summer, play outside until dusk and save lamp fuel *(rule of thumb)*.

## 🆘 If this goes wrong

| Problem | What to do |
|---|---|
| A small child keeps playing out the disaster, or plays violently | It can be "their way of telling us how crazy things were". Name the feelings, hold them, stay close. If they play the **same upsetting scene over and over**, or space out, calm them, help them feel safe, and get help ([PFA, p. 140](lib:psychological-first-aid-field-operations-guide#page=140)) |
| A child has gone back to wetting the bed or baby talk | Common after a fright. Don't criticize or force; as the child feels safer the skill comes back ([PFA, p. 140](lib:psychological-first-aid-field-operations-guide#page=140)) |
| A child is "hyper" and can't sit still for a story | Burn off the energy first: stretching, running, slow deep breathing; then sit and do something together, like throwing a ball or drawing ([PFA, p. 140](lib:psychological-first-aid-field-operations-guide#page=140)) |
| A child or teen withdraws, won't play, sleeps all day | Keep the routines and meals together; don't let them spend long hours alone or doing nothing; get them outdoors, even a walk with a brother or sister ([SPR, p. 101](lib:skills-for-psychological-recovery#page=101)) |
| Games end in fights | Settle the rules before you start *(rule of thumb)*; let the players vote on the game, and give the rowdiest older child the job of leading the little ones ([Bancroft, p. 42](lib:games-for-the-playground#page=42)) |
| The grown-ups are too worn out to play | Find one person to talk to about how you feel, and ask others to help with the child or the chores ([WHO/UNICEF cards, p. 3](lib:care-for-child-development#page=3)); trade evenings with a neighbor family *(rule of thumb)* |
| Things get worse instead of better over weeks | Talk to a doctor, someone who knows children, or clergy ([FEMA, p. 189](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=189)); see "Grief, stress and psychological first aid" in the [Community & Barter guide](guide:COMMUNITY-BARTER-GUIDE) |
| The library computer or phone is dead | Tell stories, sing, play cards and string figures: none of it needs power. Keep a few paper books and a printed copy of this guide *(rule of thumb)* |

## ⚠️ Old advice in the library to ignore

The old activity books are full of good ideas, and a few that hurt children or start fires.

| Book says | Do this instead |
|---|---|
| **Paper hot-air balloons** lifted by a ball of lamp wick soaked in alcohol and lit, sent up to sail "out of sight" ([Boys' Handy Book, p. 165](lib:american-boys-handy-book#page=165)), carrying fire-crackers ([p. 167](lib:american-boys-handy-book#page=167)) and powder from a Roman candle ([p. 170](lib:american-boys-handy-book#page=170)) | **Never.** A burning balloon comes down where the wind takes it; in our dry summers that is a wildfire. Fly kites by day |
| A paper lantern on a kite's tail, "the Moving Star", which "the motion of the kite is apt to set fire to" ([Boys', p. 41](lib:american-boys-handy-book#page=41)) | No flame on a kite, ever |
| Candles inside paper lanterns hung on wires and trees, and in cloth or paper "illuminated tents" ([Girls' Handy Book, p. 133](lib:american-girls-handy-book#page=133)) | No flame in paper or cloth. Outdoors, no flames at all June–October *(rule of thumb)* |
| "Small flashes of gunpowder" for lightning in the puppet show ([Boys', p. 357](lib:american-boys-handy-book#page=357)) | No powder. Shake a sheet of tin for thunder *(rule of thumb)* |
| "War kites" with broken bottle glass tied on the tail to cut other kites' strings ([Boys', pp. 45–46](lib:american-boys-handy-book#page=45)) | Skip it: glass cuts hands and falls on people |
| **Melted lead** poured into an eggshell for a roly-poly toy ([Girls' Handy Book, p. 67](lib:american-girls-handy-book#page=67)) and into water to tell fortunes at Halloween ([p. 212](lib:american-girls-handy-book#page=212)) | Lead poisons children, and hot metal burns. Weight the toy with a pebble set in clay *(rule of thumb)* |
| Litharge (a lead oxide) in aquarium cement ([Boys', p. 82](lib:american-boys-handy-book#page=82)) | Leave it out |
| **Arsenical soap** for stuffing birds ([Boys', pp. 260, 263](lib:american-boys-handy-book#page=263)) | Arsenic poisons. Draw or press specimens instead |
| Insect-killing jars with ether, benzine, creosote or chloroform ([Boys', p. 266](lib:american-boys-handy-book#page=266)) | Draw the insects and let them go |
| Muriatic (hydrochloric) acid to polish shells ([Girls', p. 126](lib:american-girls-handy-book#page=126)) | Scrub with sand and water *(rule of thumb)* |
| Blow-guns that shoot tacks ([Boys', p. 226](lib:american-boys-handy-book#page=226)) and a "spring shot-gun" that rattles bird-shot off a neighbor's windows ([p. 229](lib:american-boys-handy-book#page=229)) | Eyes are lost this way, and there is no eye doctor. Bean bags and targets instead |
| Foxglove "fairy-caps" to play with ([*Toy-Shop*, p. 97](lib:mother-natures-toy-shop#page=97)) | Foxglove is poisonous in every form ([WSU, p. 28](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=28)); not with small children |

## 🖼️ Pictures & diagrams

🖼️ = drawings in the books on this drive.

- Opening A and First Position for string figures — [🖼️ Jayne, p. 43](lib:string-figures-a-study#page=43); [🖼️ p. 44](lib:string-figures-a-study#page=44); [String figure](wiki:String_figure)
- Osage Diamonds (Jacob's Ladder), every step — [🖼️ Jayne, p. 63](lib:string-figures-a-study#page=63); [🖼️ p. 65](lib:string-figures-a-study#page=65); [Cat's cradle](wiki:Cat's_cradle)
- Nine men's morris board — [🖼️ Hoyle, p. 636](lib:fosters-complete-hoyle#page=636); checkers set up, [🖼️ p. 609](lib:fosters-complete-hoyle#page=609); [Nine men's morris](wiki:Nine_men's_morris)
- Duck on a Rock layout — [🖼️ Bancroft, p. 101](lib:games-for-the-playground#page=101); naughts and crosses, [🖼️ p. 269](lib:games-for-the-playground#page=269)
- Corn-husk dolls — [🖼️ *Toy-Shop*, pp. 166–168](lib:mother-natures-toy-shop#page=166); [🖼️ Girls' Handy Book, p. 193](lib:american-girls-handy-book#page=193); [Corn husk doll](wiki:Corn_husk_doll)
- Kites: man kite, Chinese dragon, Japanese square frame — [🖼️ Boys' Handy Book, p. 25](lib:american-boys-handy-book#page=25); [🖼️ p. 40](lib:american-boys-handy-book#page=40); [🖼️ p. 41](lib:american-boys-handy-book#page=41); [Kite](wiki:Kite)
- Handkerchief doll — [🖼️ Boys', p. 378](lib:american-boys-handy-book#page=378); corn-stalk fiddle, [🖼️ p. 186](lib:american-boys-handy-book#page=186); puppet stage, [🖼️ p. 347](lib:american-boys-handy-book#page=347)
- String telephone — [🖼️ Girls' Handy Book, p. 246](lib:american-girls-handy-book#page=246); home-made book covers, [🖼️ p. 423](lib:american-girls-handy-book#page=423)
- Daisy crown — [🖼️ *Toy-Shop*, p. 19](lib:mother-natures-toy-shop#page=19); burr house, [🖼️ p. 124](lib:mother-natures-toy-shop#page=124)

## 🔗 Related guides

- [Childbirth & Children guide](guide:CHILDBIRTH-CHILDREN-GUIDE) — play and talk for babies and toddlers, child accidents, keeping children learning
- [Community & Barter guide](guide:COMMUNITY-BARTER-GUIDE) — grief, stress and psychological first aid; children, elders and neighbors who need help
- [Lighting guide](guide:LIGHTING-GUIDE) — candles and lamps to read by, and fire, fumes and burns around children
- [Paper & Ink guide](guide:PAPER-INK-GUIDE) — paper, ink, pens and slates for home-made books and lessons
- [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — glue, patching and scraps for toys
- [Practical Math guide](guide:PRACTICAL-MATH-GUIDE) — the arithmetic children will need for real work
- [Field Care guide](guide:FIELD-CARE-GUIDE) — burns, cuts and the other injuries of play
- [Wildfire guide](guide:WILDFIRE-GUIDE) — fire season, and why no flames go up in the air
- [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE) — keeping the library computer and phones charged
- [Use on a phone](guide:USE-ON-PHONE) and [Start on any device](guide:START-ON-ANY-DEVICE) — reading the library on whatever still works
