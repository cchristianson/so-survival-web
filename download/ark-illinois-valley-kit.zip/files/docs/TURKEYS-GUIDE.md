# 🦃 Turkeys: Meat for a Household

How to keep a small flock of turkeys that breeds itself and puts big birds on the table with no feed store, hatchery, vet or
electricity: breeds that still mate on their own, shelter and range, the protein poults need, hatching and brooding under hens,
blackhead (why turkeys and chickens must not share ground), predators, health, butchering, and a year's plan for the Illinois Valley.
Turkeys are harder than chickens: poults are fragile for 8–12 weeks, and one disease can wipe them out. The main book is USDA *Turkey
Raising* (Farmers' Bulletin 1409, 1952) in `Animals\Poultry`; disease books are in `Small-Livestock\Chickens` and `Animals\Veterinary`
(all under `Southern-Oregon\`; the download list is local/library-files.txt). Where the work is the same as for chickens,
this guide sends you to the [Chickens guide](guide:CHICKENS-GUIDE). *(arithmetic)* marks numbers worked out here ([Calculator](guide:CALCULATOR)).

> ### The short version
> - **Keep heritage (standard) turkeys:** Bourbon Red, Narragansett, Black, Slate, standard Bronze, White Holland, Royal Palm.
>   **Broad-Breasted** store turkeys are often **too heavy to mate** and need artificial insemination — a dead end after collapse
>   ([Practical Poultry Raising, pp. 195–196](lib:practical-poultry-raising-peace-corps#page=196)).
> - **Never let turkeys onto ground that chickens use, or onto chicken manure.** Chickens carry **blackhead** without looking sick, the
>   germ lasts in the soil for years inside worm eggs, it kills poults at **6–18 weeks**, and there is **no cure**
>   ([FB 1409, p. 68](lib:turkey-raising#page=68); [FB 1652, p. 51](lib:diseases-and-parasites-of-poultry#page=51)).
> - **Move the flock to clean ground every week or two** and use any patch only **1 year in 3**; feed and water where droppings
>   can't get in ([FB 1409, pp. 66–67](lib:turkey-raising#page=66)).
> - **A broody turkey hen is your incubator and brooder:** she covers **15–18 eggs**, hatches them on **day 28** and broods **up to
>   20 poults** with no fuel ([FB 1409, pp. 33, 37](lib:turkey-raising#page=33)).
> - **Poults need 24–28% protein** — grain alone starves them — and must be **taught to eat**. They **drown** in deep water and smother
>   in corners ([FB 1409, p. 45](lib:turkey-raising#page=45); [Raising Healthy Poultry, pp. 124–125](lib:raising-healthy-poultry-cvm#page=124)).
> - **Shut them in every night and until well after dawn.** Dogs, coyotes and foxes take turkeys, owls take birds roosting in the
>   open, and only an electric fence stops a bear ([FB 1409, pp. 56–57](lib:turkey-raising#page=56); [ODFW, p. 2](lib:raising-chickens-in-bear-country-odfw#page=2)).
> - **Butcher at 26–30 weeks, in cold weather.** A 19-lb tom is hard to keep without refrigeration: kill one at a time and
>   **pressure-can** the rest ([FB 1409, p. 75](lib:turkey-raising#page=75); [Raising Healthy Poultry, p. 125](lib:raising-healthy-poultry-cvm#page=125)).
> - **The 1952 bulletin's lice, mite and crop cures are poisons** (sodium fluoride, nicotine, DDT, crankcase oil, bluestone). See
>   "Old advice in the library to ignore".

---

## 🦃 Choosing turkeys that breed on their own

**Every future turkey has to hatch from your own flock**, so the birds must mate, lay and sit by themselves. In 1952 the standard
varieties were Bronze, White Holland, Bourbon Red, Narragansett, Black and Slate, with Royal Palm, Jersey Buff and Beltsville Small
White as newer ones ([FB 1409, p. 7](lib:turkey-raising#page=7)); today such old varieties are sold as **[heritage turkeys](wiki:Heritage_turkey)**
*(rule of thumb)*. The **Broad Breasted Bronze**, new to the U.S. about 1935, has more breast meat but "in reproductive ability… is
inferior to most other varieties": fewer eggs, less fertile, less hatchable ([p. 15](lib:turkey-raising#page=15)). Its modern
descendants, sold as "Bronze" and "White", "have difficulty in reproducing because of the heavy weight of the males and their poor
fertility" ([Raising Healthy Poultry, p. 124](lib:raising-healthy-poultry-cvm#page=124)); very large turkeys "must be inseminated
artificially", while birds "closer to the wild cousin" have less breast "and thus, can breed more easily"
([Practical Poultry Raising, pp. 195–196](lib:practical-poultry-raising-peace-corps#page=195)).

| Type | Size at butchering age | Notes |
|---|---|---|
| **Standard Bronze** | Heaviest standard variety; a tom of **21½ lb at 6½ months** ([p. 7](lib:turkey-raising#page=7)) | Dark pinfeathers show on the skin; dark birds get "blueback" ([p. 71](lib:turkey-raising#page=71)) |
| **Narragansett, Black, Slate, [Bourbon Red](wiki:Bourbon_Red), White Holland** | Medium: toms about **19–20 lb**, hens about **12 lb** at 28 weeks ([pp. 10–11, 18](lib:turkey-raising#page=18)) | The core of a self-renewing flock; Bourbon Red and Slate dress out cleaner ([p. 78](lib:turkey-raising#page=78)) |
| **[Royal Palm](wiki:Royal_Palm_turkey), Jersey Buff, [Beltsville Small White](wiki:Beltsville_Small_White)** | Small: Small White toms **13–16 lb**, hens about **8–9 lb** at about 24 weeks ([pp. 14–15](lib:turkey-raising#page=14)) | Ready 2–4 weeks sooner; a fifth to a quarter more birds in the same space ([p. 15](lib:turkey-raising#page=15)); a small carcass is easier to use up without a freezer |
| **Broad-Breasted Bronze or [White](wiki:Broad_Breasted_White)** | Largest | Eat them; don't plan a future on them |

**The strain matters more than the variety:** pick birds from a flock that hatches and lives well ([p. 19](lib:turkey-raising#page=19)).
Start with eggs, poults or grown birds from a flock free of pullorum disease; check grown birds for lice and keep them apart **2–3
weeks** before they join yours ([p. 18](lib:turkey-raising#page=18)).

![A Narragansett tom in full display: a heritage variety, black barred with gray, that mates and raises young on its own](img:TURKEYS-GUIDE/narragansett-tom.png)
*A Narragansett tom, 19 lb at 28 weeks — a medium heritage variety that mates naturally ([FB 1409, p. 10](lib:turkey-raising#page=10)).*

📚 **Go deeper:** [FB 1409, pp. 6–19](lib:turkey-raising#page=6) — every variety, weights by age and choosing breeders; [Wikipedia: Domestic turkey](wiki:Domestic_turkey).

## 🏡 Housing, range and roosts

After about **12 weeks**, turkeys "can be raised with very little protection, even in cold climates" ([FB 1409, p. 37](lib:turkey-raising#page=37)).
What they need is **clean, drained ground**, shade, a roof over the roosts and a night shelter predators can't enter.

- **Ground:** sloping and drained, **no stagnant water**; an orchard makes a good yard ([p. 20](lib:turkey-raising#page=20)).
  Poorly drained ground "should be avoided at all costs" ([p. 51](lib:turkey-raising#page=51)) — here, the low, soggy winter spots.
- **Breeding yard:** **100–150 sq ft of range per bird**, best as **two yards used a week each in turn**; a flock of 30 needs a
  **12 × 16 ft** shed ([p. 20](lib:turkey-raising#page=20)), so 6 breeders need about **600–900 sq ft** a yard *(arithmetic)*. Toms
  in neighboring pens fight through the wire: keep pens **10 ft apart** or board the shared fence **3½ ft** up (same page).
- **Shelter:** face it south, boards on the storm sides, wire-covered openings **2–2½ ft** wide at roost height
  ([pp. 57–58](lib:turkey-raising#page=57)); "in moderate climates… the roof being sufficient" ([p. 62](lib:turkey-raising#page=62)).
  Here: a good roof over roosts and feed, boards on the side the winter rains come from *(rule of thumb)*. Built-up straw or
  shaving litter, cleaned out once a season ([p. 22](lib:turkey-raising#page=22)).
- **Roosts:** poles about **2½ in** across, **19–24 in** apart, all at one height, **6–12 in** up on skids ([p. 28](lib:turkey-raising#page=28);
  p. 21 says 14 in); **12–15 in** of pole per bird; for heavy broad-breasted birds, tops only **4–6 in** up ([p. 63](lib:turkey-raising#page=63)).
  Wire over or under the poles gives better footing and keeps birds out of the droppings ([p. 28](lib:turkey-raising#page=28)).
  Narrow strips and wide flat boards dent the breastbone ([pp. 70–71](lib:turkey-raising#page=70)); heavy birds that jump down more
  than about **1 ft** onto hard ground get bumblefoot and breast blisters ([pp. 71–72](lib:turkey-raising#page=72)). High roosts save
  them at night "but not in the early morning hours" ([p. 57](lib:turkey-raising#page=57)), so use **a low rack inside a closed
  shelter** *(rule of thumb)*.

![End view of a low roost rack on skids: four poles 19 to 24 inches apart and 6 to 12 inches up, with wire over them](img:TURKEYS-GUIDE/roost-rack.svg)
*A low roost rack on skids that can be dragged to clean ground (a diagram drawn for this guide).*

- **Nests:** about **16 × 20 in and 20 in high**, entrance about **8 × 9 in**, one for every **4 hens** ([pp. 28–29](lib:turkey-raising#page=28));
  a barrel on its side works ([p. 33](lib:turkey-raising#page=33)). Hens hunt for hidden places to lay: keep the yard **short-grassed
  and free of bushes** and find hidden nests ([p. 32](lib:turkey-raising#page=32)).
- **Fences and flying:** **5-ft** fence for young medium and small turkeys, **6-ft** for breeders ([p. 58](lib:turkey-raising#page=58)),
  tight and close to the ground ([p. 20](lib:turkey-raising#page=20)). Hens and the lighter toms fly well: **clip the flight feathers
  of one wing** — but **never a breeding tom's** before the season; it throws him off balance for mating ([p. 66](lib:turkey-raising#page=66)).
- **Range:** **½–2 acres per 100 turkeys** of good green range, "possibly doubled or trebled" on dry range ([p. 55](lib:turkey-raising#page=55)) —
  which is what our summer hills become. With feed and water in one spot they stay within a few hundred yards ([p. 52](lib:turkey-raising#page=52)).
  Good range: alfalfa, clovers, orchard grass, ryegrass, kale, rape, vetch; rows of **sunflowers, corn or Sudan grass** give feed and
  shade ([p. 56](lib:turkey-raising#page=56)). **Shade is a necessity** in hot, sunny weather ([p. 51](lib:turkey-raising#page=51)).
  Turkeys flock tightly and "can be driven about… in much the same manner as sheep" ([p. 56](lib:turkey-raising#page=56)).
- **Water:** clean, pans washed daily; creek or pond water "may carry disease germs or parasites" ([p. 30](lib:turkey-raising#page=30)).

📚 **Go deeper:** [FB 1409, pp. 20–29](lib:turkey-raising#page=20) — breeding yards, roosts and nests; [pp. 51–58](lib:turkey-raising#page=51) — range, shelters and fences.

## 🌾 Feeding with no feed store

The 1952 bulletin feeds bought mashes of soybean meal, meat scrap, fish meal and vitamin oils. After collapse those become **milk,
eggs, insects, meat and fish scraps, fresh greens and sunshine**, and protein is the hard part. Feed goes in hoppers or troughs, never
on the ground ([FB 1409, p. 49](lib:turkey-raising#page=49)), covered from rain ([p. 59](lib:turkey-raising#page=59)). For calcium,
grit, storing grain, maggot and worm beds, sprouted oats and poisonous plants, see the Chickens guide, "Feeding without a feed store".

### Protein for poults
- **How much:** a starter of **24–26% protein** ([FB 1409, p. 45](lib:turkey-raising#page=45)); three books give **28%**
  ([p. 46](lib:turkey-raising#page=46); [Raising Healthy Poultry, p. 125](lib:raising-healthy-poultry-cvm#page=125);
  [Practical Poultry Raising, p. 196](lib:practical-poultry-raising-peace-corps#page=196)). Then about **20%** for growing birds and
  **15–16%** from about 16 weeks ([Raising Healthy Poultry, p. 125](lib:raising-healthy-poultry-cvm#page=125); [FB 1409, p. 46](lib:turkey-raising#page=46)).
  Chicks get by on 18–20% (Chickens guide), so **poults need far more "meat food" than chicks.**
- **First feed within 24 hours.** Poults live 24–72 hours on the yolk, but kept from feed much longer than a day they learn to eat
  "with difficulty". Heap feed on boards or pie plates with **oatmeal or finely chopped greens** scattered on top ([p. 44](lib:turkey-raising#page=44)).
  **Tap a finger** on the board like a pecking bird; **red** draws them to feed and water; otherwise they "may starve"
  ([Raising Healthy Poultry, p. 124](lib:raising-healthy-poultry-cvm#page=124)).
- **A home-made starter** *(rule of thumb: the bulletin's ingredients in farm form)* — rolled or finely ground grain, plus all of
  these you can spare:
  - **Milk:** sweet or slightly sour **skim milk or buttermilk** to drink, never in galvanized pans, one pan of water to three or four
    of milk, pans cleaned daily ([FB 1409, pp. 41, 47](lib:turkey-raising#page=47)); curds of soured milk are the same protein, solid.
  - **Eggs:** chopped hard-boiled eggs, such as clear ones taken out at candling. **Bugs:** insects, worms, maggots grown on plant
    waste — **never maggots from carcasses** (botulism; Chickens guide).
  - **Meat and fish scraps,** cooked and minced. **No fish in the last 10 weeks** before butchering, or the meat tastes fishy
    ([FB 1409, pp. 49–50](lib:turkey-raising#page=49)).
  - **Greens** chopped very fine (alfalfa, clover, onion tops, young grass, sprouted grain), fresh once or twice a day; never leave
    wilted greens ([p. 45](lib:turkey-raising#page=45)). Long clippings pack the crop ([p. 73](lib:turkey-raising#page=73)).
  - **Grit:** coarse sand or fine gravel, not needed on sand litter ([p. 45](lib:turkey-raising#page=45)).
- **Short of protein?** Rough feathers and a **white bar across the wing** of dark poults ([p. 74](lib:turkey-raising#page=74)).

### Growing turkeys on range
- **From 8 weeks**, mash and grain are kept in front of them ([p. 47](lib:turkey-raising#page=47)). Where range feed is plentiful,
  from **8–10 weeks** feed **once a day** all they will eat, and skip the grain while they glean stubble ([p. 50](lib:turkey-raising#page=50)).
  On range they eat insects, "great quantities of succulent green feed", waste grain and weed seeds ([p. 5](lib:turkey-raising#page=5)).
- **Grain:** corn, wheat, barley, oats, spelt, emmer, proso millet or sorghum — all worth about the same, best two to four kinds in
  separate hoppers; **crack corn** until about 18 weeks; rye and buckwheat only a little ([pp. 47–49](lib:turkey-raising#page=47)).
  **Oats** fatten well ([p. 47](lib:turkey-raising#page=47)), and oats as about **half the grain** helps prevent feather picking
  ([p. 74](lib:turkey-raising#page=74)). Turkeys harvest **proso and grain sorghum** standing in the field ([p. 50](lib:turkey-raising#page=50)).
- **Milk:** after 8 weeks, birds on good range with whole grain and all the skim milk they want need no water ([p. 49](lib:turkey-raising#page=49)),
  but **no liquid milk in hot weather** — it brings on pendulous crop ([p. 73](lib:turkey-raising#page=73)).
- **Finishing:** full feed to the end; cool fall weather speeds it ([p. 75](lib:turkey-raising#page=75)). No long moves or sharp feed
  changes in the **last 6 weeks** ([p. 49](lib:turkey-raising#page=49)).

### Feeding the breeders
- **Fall and winter:** grain and a simple mash with **sunshine and fresh greens**; a third of the grain corn or barley
  ([FB 1409, p. 25](lib:turkey-raising#page=25)). **Laying season:** a **21–24%** mash fed with equal grain, about **15–17%** overall,
  grit and oyster shell always out ([pp. 25–26](lib:turkey-raising#page=25)); hay can't replace fresh greens for hatching eggs
  ([p. 27](lib:turkey-raising#page=27)). Standard varieties eat about **0.45 lb a day**, 10% more without range ([p. 28](lib:turkey-raising#page=28)).
  **Summer:** about **¼ lb of grain per hen a day** on good range, toms twice that ([p. 24](lib:turkey-raising#page=24)).
- **Store feed where bears can't get it** ([ODFW, p. 1](lib:raising-chickens-in-bear-country-odfw#page=1)).
- **Selenium:** "crazy chick" disease (wobbling, falling over backward) hits poults under 2 months short of vitamin E or selenium
  ([Raising Healthy Poultry, p. 70](lib:raising-healthy-poultry-cvm#page=70)). Selenium-shortage disease was first found in Oregon,
  yet selenium is toxic in excess and must be labeled in Oregon feeds ([OSU EM 9094, p. 1](lib:selenium-supplementation-strategies-for-livestock-in-oregon#page=1)):
  use only a labeled poultry mineral, exactly as the label says *(rule of thumb)*.

📚 **Go deeper:** [FB 1409, pp. 44–50](lib:turkey-raising#page=44) — starting and growing feeds, grains and milk; [*Raising Healthy Poultry*, pp. 38–55](lib:raising-healthy-poultry-cvm#page=38) — poultry nutrition; [Seed Bank guide](guide:SEED-BANK-GUIDE) — growing grain, sunflowers and kale.

## 🥚 Eggs, broody hens and hatching

Young hens lay their first egg at about **34–36 weeks** old ([FB 1409, p. 17](lib:turkey-raising#page=17)), **2–3 weeks after mating**;
the natural season runs from late winter or early spring to about June 1. Without lamps, young hens averaged about **40 eggs** — when
broodiness was broken each time ([pp. 30, 32](lib:turkey-raising#page=30)); a hen left to sit lays far fewer *(rule of thumb)*. Turkey
eggs eat like chicken eggs, **two for every three** ([p. 32](lib:turkey-raising#page=32)). **Hatching eggs:** collect at least daily,
store **on their sides or small end down at 45–65 °F** (best about 55 °F), and set within **a week** — two weeks if turned daily
([p. 33](lib:turkey-raising#page=33)).

**Setting a turkey hen** ([FB 1409, p. 33](lib:turkey-raising#page=33)):
1. **Wait until she has sat steadily for 4–5 days,** then give her **15–18 eggs**.
2. **Nest:** a box about **2 ft square** or a barrel on its side, **flat and shallow** (deep nests crush eggs and poults), on **damp
   sod** with a little straw, out of the rain and safe from rats and crows.
3. **Rid her of lice first** — the ash-and-sulfur dust in the Chickens guide, not the bulletin's sodium fluoride.
4. **Every day** let her off to eat, drink and stretch (or give her a small run), with water, grain and fresh greens; see that each
   hen goes back to her own nest.
5. **Keep the tom away:** gobblers "often try to break the eggs" ([Practical Poultry Raising, p. 196](lib:practical-poultry-raising-peace-corps#page=196)).
6. **Candle** at about **day 7–9** and near **day 24**: clear eggs are infertile; a red spider-web of veins is a live one
   ([FB 1409, p. 35](lib:turkey-raising#page=35)).
7. **The hatch is done by the morning of day 28** ([p. 36](lib:turkey-raising#page=36)); Practical Poultry Raising says 26–28 days.

**A chicken hen** can hatch **7–10 turkey eggs** ([FB 1409, p. 33](lib:turkey-raising#page=33)), but the eggs "must be hand turned"
([Practical Poultry Raising, p. 196](lib:practical-poultry-raising-peace-corps#page=196)), and poults raised by hens, "especially
chicken hens, are likely to contract disease" ([FB 1409, p. 33](lib:turkey-raising#page=33)). If you must, set her in a clean pen
away from the chickens and move the poults to turkey ground at hatching (see "Blackhead"). **Without any hen**, incubator heat is the
same as for chicken eggs, for 28 days, turning eggs at least **three times a day** until day 23–24 ([pp. 34–35](lib:turkey-raising#page=34));
"Hatching and brooding turkeys artificially is a difficult business" ([Practical Poultry Raising, p. 196](lib:practical-poultry-raising-peace-corps#page=196)).
Plan on hens. **Too many broody hens?** Four days in a slat-floored broody coop sets one laying again ([FB 1409, p. 32](lib:turkey-raising#page=32)).

## 🐣 Raising poults with no power

Hen brooding is "a never-failing source of heat"; its faults are disease and parasites from the hen, and poults that wander off and
die in storms or to predators ([FB 1409, p. 36](lib:turkey-raising#page=36)). Both can be managed.

**With the hen** ([FB 1409, pp. 36–37](lib:turkey-raising#page=36)):
1. When the hatch is done, move hen and brood to a **coop about 5 ft long, 3 ft wide and 3 ft high** with a **raised, rat-proof
   floor** and screened openings rain can't beat into — one per hen, set apart on short grass, best with a **wire-floored porch**.
2. **For the first day or so** keep the poults in with her, with plenty of light, so they learn to eat and drink.
3. Then open the porch or a small yard. **Keep poults out of long wet grass and heavy rain; shut them in every night.**
4. With no wire floor, **move the coop to fresh ground every few days** and clean it weekly; **clean sand** is the best litter.
5. After about a week the hen may go out with them; make sure every bird comes back at evening.
6. **Feed and water always in front of the poults;** after 2–3 days put their feed where the hen can't reach, and give her grain and greens.
7. A turkey hen broods **up to 20 poults, 25 in warm weather.** Move the poults at **8 weeks** to clean rearing ground with a shelter.

![Side view of a coop about 5 feet long and 3 feet high with a raised floor, screened vents under the eaves and a wire-floored porch](img:TURKEYS-GUIDE/hen-and-poults-coop.svg)
*A coop for a turkey hen and her poults, sized from [FB 1409, pp. 36–37](lib:turkey-raising#page=36) (a diagram drawn for this guide).*

**What kills poults:**
- **Cold and damp** until about **12 weeks** old ([FB 1409, p. 37](lib:turkey-raising#page=37)).
- **Panic:** they run into fences and break their necks, pile up and suffocate, **drown in a low dish** or jump into a bucket
  ([Raising Healthy Poultry, p. 124](lib:raising-healthy-poultry-cvm#page=124)). Round off inside corners; start them on small
  jar-and-saucer waterers ([FB 1409, p. 41](lib:turkey-raising#page=41)).
- **Lice from the hen** cause "high mortality" ([p. 69](lib:turkey-raising#page=69)): treat her before she sits.
- **Bad litter** they eat: hay, oat or bearded-barley straw, sawdust, splintery shavings ([p. 39](lib:turkey-raising#page=39)).
- **Not a sickness:** red fleshy growths on head and neck at 5–7 weeks ("shooting the red") are normal ([p. 64](lib:turkey-raising#page=64)).

**Without a hen** the bulletin keeps **95–105 °F under the hover** and **70–75 °F** on the floor around it for 8 weeks
([FB 1409, pp. 37, 40](lib:turkey-raising#page=40)) — a great deal of heat to make without power, and lamp brooders with no stovepipe
"do not give best results" ([p. 43](lib:turkey-raising#page=43)). For fuel-heated brooders and their carbon-monoxide and fire dangers,
see the Chickens guide, "Raising chicks with no heat lamp"; brood only in warm weather *(rule of thumb)*. Buying a neighbor's poults
at **6–8 weeks** old skips the hardest part ([Practical Poultry Raising, p. 196](lib:practical-poultry-raising-peace-corps#page=196)).

## 🐓 Toms, mating and keeping the line going

**Hens per tom — the books differ:** **4–5** ([Raising Healthy Poultry, p. 125](lib:raising-healthy-poultry-cvm#page=125)); **10**
([Practical Poultry Raising, p. 196](lib:practical-poultry-raising-peace-corps#page=196)); for young toms, **13–20** depending on size,
but only 9–10 for Broad-Breasted ([FB 1409, p. 22](lib:turkey-raising#page=22)). A household flock is small anyway: **one young tom
for up to about 10 heritage hens, plus a spare young tom** — the bulletin keeps extra toms "as a safety precaution" (same page)
*(rule of thumb)*.

- **Raise a new tom every year** *(rule of thumb)*: toms past their first season show "a rather high percentage of sterility". Hens
  also do less well after their first year, but a proven good hen is worth a second or third ([FB 1409, p. 22](lib:turkey-raising#page=22)).
- **Put the tom in well before laying;** cold weather makes toms inactive ([pp. 22–23](lib:turkey-raising#page=22)). Heavy hens mated
  to heavy toms need **canvas saddles** over the back; small and standard-weight birds don't. Clip toms' toenails short (not into the
  quick) and blunt sharp spurs ([p. 23](lib:turkey-raising#page=23)).
- **Pick breeders in October–November** from your best birds near butchering age ([p. 19](lib:turkey-raising#page=19)): straight keel,
  broad back, full breast, **upright carriage** and a free, easy walk with no waddle or limp; straight legs not too short to mate;
  bright eyes. Skip families with pendulous crop, twisted legs or crooked backs ([pp. 19, 71–72](lib:turkey-raising#page=71)).
  Unlike the bulletin, **also keep the hens that sat and raised poults well** *(rule of thumb)*.
- **Telling sexes apart:** toms strut, even as poults; the **beard** shows at **3–4 months**; toms have broader hocks and a bigger
  snood (the fleshy finger over the beak); at about 12 weeks Bronze and Narragansett toms show all-black breast feathers and hens
  white-edged ones ([p. 64](lib:turkey-raising#page=64)).
- **Avoid inbreeding.** The bulletin's "systematic intercrossing" keeps three or more pens: daughters stay in their mother's pen and
  sons move on one pen each year, so no outside blood is needed ([pp. 23–24](lib:turkey-raising#page=23)). With one small flock,
  **trade toms with an unrelated neighbor's flock every year or two**, quarantined first *(rule of thumb)*. Mark families with leg
  bands or punched toe webs ([pp. 65–66](lib:turkey-raising#page=65)).

## 🦠 Blackhead: why turkeys and chickens don't mix

**Blackhead** is caused by a one-celled parasite, *[Histomonas meleagridis](wiki:Histomonas)*, that attacks the two blind
guts (ceca) and the liver ([FB 1409, p. 68](lib:turkey-raising#page=68)).
- **Signs:** droopiness, no appetite, weight loss, sometimes **sulfur-yellow droppings**; death is often sudden, and the dark head
  is not always there ([FB 1652, p. 51](lib:diseases-and-parasites-of-poultry#page=51)). Worst in poults of **6–18 weeks**
  ([FB 1409, p. 68](lib:turkey-raising#page=68)).
- **Inside a dead bird:** ceca swollen with a yellow cheesy core; a liver spotted with **round, sunken dark-red, gray or yellow
  patches** ([FB 1652, p. 51](lib:diseases-and-parasites-of-poultry#page=51)).
- **Treatment:** none that works ([FB 1409, p. 68](lib:turkey-raising#page=68); [FB 1652, p. 51](lib:diseases-and-parasites-of-poultry#page=51)).

![Photograph of a turkey liver with blackhead: dark liver covered with round, ring-shaped pale spots](img:TURKEYS-GUIDE/blackhead-liver.png)
*A blackhead liver: round, sunken spots ([FB 1652, p. 52](lib:diseases-and-parasites-of-poultry#page=52)).*

**How it spreads.** Chickens catch it mildly and stay **carriers**, passing "vast numbers" in their droppings; grouse and quail get it
too ([FB 1652, p. 50](lib:diseases-and-parasites-of-poultry#page=50)). On its own the parasite seldom lives a day outside a bird, but
inside the eggs of the **cecal worm** it survives in soil **from one year to the next** unless exposed to 0 °F weather
([p. 51](lib:diseases-and-parasites-of-poultry#page=51)) — cold that valley winters seldom reach *(rule of thumb)*. Flies, blowing dust and soil
on the keeper's boots carry it as well ([FB 1409, p. 68](lib:turkey-raising#page=68)).

![Diagram: chickens carry blackhead, it lasts in the ground inside cecal-worm eggs, turkey poults pick it up; break the chain by keeping them apart, moving to clean ground and guarding the poults](img:TURKEYS-GUIDE/blackhead-cycle.svg)
*How blackhead travels, and the three ways to stop it (a diagram drawn for this guide).*

**The books don't fully agree:**

| Source | What it says |
|---|---|
| [Raising Healthy Poultry, p. 125](lib:raising-healthy-poultry-cvm#page=125); [WTINAD, p. 318](lib:where-there-is-no-animal-doctor-cvm-2024#page=318) | "Never raise turkeys and chickens together"; the cecal worm usually carries it |
| [FB 1652, p. 51](lib:diseases-and-parasites-of-poultry#page=51) | Keep turkeys "completely away from chickens or land ranged by chickens or fertilized with chicken manure" |
| [FB 1409, pp. 67–68](lib:turkey-raising#page=67) | Separation from "chickens and other poultry at all times is essential", and old turkeys from young; it spreads "without the aid of the cecal worm" too, so killing worms is no guarantee |
| [FB 1409, p. 69](lib:turkey-raising#page=69) | In dry, well-drained places, cleanliness and keeping away from *old* chickens and turkeys "may suffice" — but the well-watered Pacific Coast is not such a place |
| [Practical Poultry Raising, p. 196](lib:practical-poultry-raising-peace-corps#page=196); [FB 1409, p. 33](lib:turkey-raising#page=33) | Raise them apart "unless the farmer has much experience with both", yet a chicken hen can hatch turkey eggs — with more disease risk |

**How this guide settles it for the valley:** our wet winters, and the bulletin's warning that blackhead is "harder to control in
sections where rainfall is abundant" ([FB 1409, p. 68](lib:turkey-raising#page=68)), put us on the cautious side.
1. **Separate ground, no exceptions:** never on chicken ground, never on beds spread with chicken-coop compost; keep ducks, geese and
   other poultry off turkey ground too.
2. **A chicken hen may hatch turkey eggs** in a clean pen away from the chickens, but the poults go straight to turkey ground and
   never follow her back to the chicken yard *(rule of thumb)*.
3. **Do turkey chores first,** or keep one pair of boots for the turkey yard *(rule of thumb, from the boots warning above)*.
4. **Don't count on worming:** the bulletin's phenothiazine is "only a stopgap" ([p. 69](lib:turkey-raising#page=69)), and you won't have it.

**Prevention** ([FB 1409, pp. 66–67](lib:turkey-raising#page=66)): range on drained ground with **no poultry manure for 2–3 years**;
move the growing flock and its gear to **clean ground every week or two**, using any patch only **1 year in 3 or 4**; feed and water on
**wire or slat platforms** with no damp spots; **old turkeys away from young**; no stock but horses and cattle on turkey range in the
2–3 years before. Put poults on range at **8 weeks** with a shelter, or **11–12 weeks** if blackhead is about ([p. 51](lib:turkey-raising#page=51)).

**If blackhead breaks out** ([FB 1409, p. 68](lib:turkey-raising#page=68)):
1. **Shortly after daybreak,** take out every bird that looks sick and keep them on wire or slats.
2. **Move the well birds** to wire- or slat-floored pens — or to clean ground **daily for 2 weeks, twice a week for 3 weeks, then weekly**.
3. **Bury, burn or drop into a deep pit** every bird that dies.
4. **Abandon that ground for at least 3 years.**

## 🦝 Predators

"Dogs, foxes, and coyotes cause heavy losses among turkeys"; great horned owls and big hawks take turkeys roosting in the open
([FB 1409, pp. 56–57](lib:turkey-raising#page=56)). Bears, cougars, bobcats and raccoons live here too. The "who did it" table, hardware
cloth for young birds and the bear fence are in the Chickens guide, "Predators of the Illinois Valley".

1. **Shut them in all night and through the early morning,** and feed and water them inside then ([FB 1409, pp. 56–57](lib:turkey-raising#page=56)).
   A high roost saves them at night "but not in the early morning hours when turkeys are off the roosts" ([p. 57](lib:turkey-raising#page=57)).
2. **Build to stop dogs:** **16–18 gauge** wire, tightly nailed; **1½-in mesh** of 16 gauge over openings near the ground
   ([p. 56](lib:turkey-raising#page=56)). Well-fenced yards "seldom are entered", but a determined dog, coyote or fox must be trapped
   or watched for ([p. 57](lib:turkey-raising#page=57)).
3. **Dogs and night pens:** a watchdog tied near the roost gives good protection ([p. 57](lib:turkey-raising#page=57)); for small
   operations a night pen is rated effective against coyotes, lions, bears, foxes and bobcats ([UC ANR 8598, p. 5](lib:livestock-protection-tools-for-california-ranchers#page=5)).
   Guardian dogs are covered in the [Dogs guide](guide:DOGS-GUIDE).
4. **Hawks and owls are federally protected** — don't shoot or trap them, whatever the 1952 bulletin says
   ([Kentucky ID-245, p. 5](lib:predator-management-for-small-scale-poultry#page=5)). Shut birds in; cover small runs.
5. **Bears** break coops and chicken wire; an **electric fence** powered day and night stops them; keep feed locked up
   ([ODFW, pp. 1–2](lib:raising-chickens-in-bear-country-odfw#page=2)).
6. **Cougars:** "Fence and shelter livestock. Move them to sheds or barns at night." Oregon law lets a landowner kill a cougar that is
   damaging livestock ([ODFW, p. 2](lib:oregon-is-cougar-country-odfw#page=2)).
7. **Night panics:** turkeys stampede, "especially on moonlit nights", piling up, breaking limbs and straying to predators; avoid any
   disturbance near the roost ([p. 74](lib:turkey-raising#page=74)). A hen sitting out in the brush is easy prey: move her to a
   sheltered nest box *(rule of thumb)*.

## 🩺 Health with no vet

"Very few diseases and parasites can be controlled successfully by medication. Prevention is the more practicable"
([FB 1409, p. 67](lib:turkey-raising#page=67)): clean ground, moving the flock, old and young apart, and **2–3 weeks' quarantine** for
any newcomer ([p. 18](lib:turkey-raising#page=18)). Turkeys "catch cold easily" and get more diseases than chickens
([Practical Poultry Raising, p. 196](lib:practical-poultry-raising-peace-corps#page=196)). The books give no turkey medicine doses you
could use, so this guide gives none; for medicines in general see [Medical — read me first](guide:Medical-READ-ME-FIRST).

| Sign | Likely cause | What you can do |
|---|---|---|
| Droopy, off feed, yellow droppings, 6–18 weeks old | **Blackhead** | No cure: see "Blackhead" |
| Poults 1–12 weeks listless, stilted walk, watery or foamy droppings; many die at 3–5 weeks | **Hexamitiasis**, carried by grown turkeys and quail ([FB 1652, p. 60](lib:diseases-and-parasites-of-poultry#page=60)) | Poults far from older turkeys; clean ground |
| Bloody droppings, droopy young birds | **Coccidiosis**, prevented as in chickens ([Raising Healthy Poultry, p. 125](lib:raising-healthy-poultry-cvm#page=125)) | Dry litter, fresh ground — Chickens guide |
| Head shaking, foamy eyes, **swollen sinuses** below the eyes | **Sinusitis ("swellhead")** ([FB 1652, p. 16](lib:diseases-and-parasites-of-poultry#page=16)) | Isolate; no drafts; greens for vitamin A; old and young apart ([FB 1409, p. 67](lib:turkey-raising#page=67)); cull chronic cases |
| Scabs on head, sores in mouth | **Fowl pox**, any age ([FB 1409, p. 67](lib:turkey-raising#page=67)) | The only control was a vaccine; without one, see the Chickens guide |
| Crop hangs like a soft, sour bag in hot weather | **Pendulous crop** ([pp. 72–73](lib:turkey-raising#page=72)) | Shade, cool water, no milk in heat; kill bad cases — eat them if the crop lining isn't rotting |
| Hard, packed crop; poults dying | **Impaction** from long grass, wilted greens, stringy litter; nails or wire pierce the gizzard ([p. 73](lib:turkey-raising#page=73)) | No cure: chop greens short, safe litter, pick up nails and wire |
| Swollen hock, leg twisted out | **Perosis**: short of manganese or choline, too much bone meal, or inherited ([p. 72](lib:turkey-raising#page=72)) | Varied feed; don't breed from that family |
| Swollen foot with a hard callus | **Bumblefoot**, from rough floors or high roosts ([p. 72](lib:turkey-raising#page=72)) | Low roosts, smooth floors; treat as in the Chickens guide |
| Wobbling, falling backward, under 2 months | **Vitamin E or selenium shortage** ([Raising Healthy Poultry, p. 70](lib:raising-healthy-poultry-cvm#page=70)) | Greens; labeled mineral (see "Feeding the breeders") |

**Lice and mites.** Lice kill hen-brooded poults, and toms carry them: look around a tom's vent and in his long thigh feathers
([FB 1409, p. 69](lib:turkey-raising#page=69)). Red mites hide in roosts and nests, seen as grayish deposits ([p. 70](lib:turkey-raising#page=70)).
Treat both as in the Chickens guide, "Health with no vet" — ash-and-sulfur dust, a dust bath, scrubbed roosts — never the bulletin's chemicals.

**Feather picking** gets serious mainly in birds kept shut up. Prevent it with room, **3½–4 in of feeder space per growing bird**,
enough protein, oats as half the grain, **legume hay or corn fodder** to pick at, and not shutting birds in late in the morning;
"seriously picked birds should be slaughtered and the meat utilized" ([FB 1409, pp. 73–74](lib:turkey-raising#page=73)).

**Heat, smoke and the dead.** Shade and cool water always ([FB 1409, p. 51](lib:turkey-raising#page=51)); in wildfire smoke keep water
fresh, mist down dust and put off moving or handling ([PNW 783, p. 10](lib:wildfires-smoke-and-livestock-pnw783#page=10)). Bury, burn
or deep-pit the dead ([FB 1409, p. 68](lib:turkey-raising#page=68)); never eat or trade a bird that died of disease (Chickens guide).
To put a big bird down, one strong blow to the top of the head is acceptable ([AVMA, p. 77](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=77)).

📚 **Go deeper:** [FB 1409, pp. 66–74](lib:turkey-raising#page=66) — diseases, deformities and bad habits (ignore its chemicals); [USDA FB 1652](lib:diseases-and-parasites-of-poultry#page=50) — blackhead, swellhead and other turkey diseases; [*Where There Is No Animal Doctor*, p. 312](lib:where-there-is-no-animal-doctor-cvm-2024#page=312) — poultry health with no vet.

## 🔪 Butchering and plucking

**When:** standard turkeys are best at **26–30 weeks**, about **28**; hens may be ready at 24 and toms at 26; **small types at 22–26**.
Birds killed early are thin and full of short pinfeathers; cool weather speeds finishing ([FB 1409, p. 75](lib:turkey-raising#page=75)).
**Is it ready?** Hang a bird by the legs: many **short pinfeathers** on shoulders, breast and drumsticks mean it won't pick clean — wait.
Pull a few breast feathers and roll the skin: **thick as blotting paper and white or yellowish** is well fattened; **paper-thin and
see-through** is not ([pp. 75–76](lib:turkey-raising#page=75)).

**Before:** take feed away **at dusk the day before**, no grain within about **18 hours**, never more than **24 hours** without feed (or
they eat litter and droppings), **water to the end**; catch them gently in a small pen so they don't pile and bruise ([p. 76](lib:turkey-raising#page=76)).

**Killing:**
1. **Hang the bird by its feet** from a shackle, or a cord through a hole in a 2-in block of wood ([FB 1409, p. 76](lib:turkey-raising#page=76)),
   or head-down in a **killing funnel** about **22 in long, 12 in across the top and 5 in at the bottom** for birds up to 17 lb live,
   **30 × 15 × 6 in** for bigger ones ([p. 77](lib:turkey-raising#page=77)).
2. **Stun it:** one strong blow to the top of the head knocked out turkeys of up to 35 lb; neck-pulling is only for birds small
   enough to do it surely ([AVMA, p. 77](lib:avma-guidelines-for-the-euthanasia-of-animals-2020#page=77)).
3. **Bleed at once:** holding the head by its sides, cut the **jugular veins** far back in the throat just below the skull through the
   open mouth with a narrow 4-in blade — or simply cut the throat, as most plants did. **Let the wings flop;** gripping them breaks
   wing bones ([FB 1409, pp. 76–77](lib:turkey-raising#page=77)). The bulletin's extra "stick" into the brain loosens feathers but
   takes practice; scalding does the same job *(rule of thumb)*.

**Plucking:**
- **Dry picking:** start right after bleeding — tail and big wing feathers first, then legs, back and body, then breast, wings and
  neck. Pull briskly, a few at a time; **don't rub**, it tears the skin ([FB 1409, p. 77](lib:turkey-raising#page=77)).
- **Semi-scald:** when flapping stops, dunk and swish the bird **30–40 seconds at 126–128 °F**, or **1–1½ minutes at 124 °F**, then
  pick; these limits "must be observed carefully" (same page).
- **The books differ on heat:** CVM says turkeys need "hotter water than chickens" and dry picking "may also be desirable"
  ([Slaughter and Preservation of Meat, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84)); Minnesota scalds old chickens
  near 140 °F and warns that hotter water strips the outer skin and tears it ([UMN EB 385, p. 2](lib:home-processing-of-poultry#page=2)).
  **Start at 124–128 °F with a thermometer; if tail and wing feathers still won't pull, as on an old tom, dip again briefly a few
  degrees hotter** *(rule of thumb)*.
- **Pinfeathers:** pull what you can grip; digging out short ones does more harm. White, Buff, Royal Palm, Slate and Bourbon Red
  pinfeathers hardly show ([FB 1409, p. 78](lib:turkey-raising#page=78)).

**Dressing:** squeeze droppings from the vent; take the crop out through a slit at the back of the neck, cut well above and below so
nothing spills ([FB 1409, p. 78](lib:turkey-raising#page=78)). Then **gut it like a chicken**, only bigger — see the Chickens guide,
"Humane slaughter and butchering" ([🖼️ step by step, UMN p. 5](lib:home-processing-of-poultry#page=5)) — and wash it in cool water
([CVM, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84)).

**Cooling and keeping:** hang the bird by its legs **12 hours or more at 30–36 °F** (up to 45 °F for meat eaten soon); "in mild weather,
it is not possible to cool the carcasses properly without the use of refrigeration or ice water". A dairy thermometer in the vent shows
when it is chilled through ([FB 1409, p. 79](lib:turkey-raising#page=79)). The size "has limited carcass storage without refrigeration"
([Raising Healthy Poultry, p. 125](lib:raising-healthy-poultry-cvm#page=125)), so **butcher on cold days, one bird at a time**, cut it
into legs, wings and breast ([CVM, p. 84](lib:slaughter-and-preservation-of-meat-cvm#page=84)), and **pressure-can** what you can't
eat in a few days by the USDA chicken procedure, chilling the bird 6–12 hours first ([USDA canning guide 5, p. 5](lib:usda-complete-guide-to-home-canning-2015-guide-5#page=5);
[Preserving Food guide](guide:PRESERVING-FOOD-GUIDE)).

**What a bird yields** ([FB 1409, p. 78](lib:turkey-raising#page=78)): fasting, killing, picking and chilling take off about **14½%**
of a medium or small turkey's live weight (13% for standard Bronze); drawing (head, feet and guts out, giblets and neck kept) takes
**15%** more. The picked carcass is about **10% bone and 46% raw lean meat**. So a **19-lb Narragansett tom** gives about **16 lb**
picked, **14 lb** ready to cook and **7½ lb** of lean meat; a **12½-lb Black hen** about **10½, 9 and 5 lb** *(arithmetic)*.

**Using the whole bird:** cook legs and thighs slowly; **wing bones make turkey calls** ([Ohio DNR, p. 2](lib:introduction-to-wild-turkey-hunting-ohio-dnr#page=2));
big wing feathers make quill pens ([Paper & Ink guide](guide:PAPER-INK-GUIDE)); neck, back and giblets make broth *(rule of thumb)*.
Turkeys fertilize the ground they range for the crops of its rest years ([FB 1409, p. 52](lib:turkey-raising#page=52)); compost
cleaned-out litter as for chickens and spread it where turkeys won't range for 2–3 years.

## 🗓️ The turkey year in the Illinois Valley

Hatching in **late April or May** gives poults past their tender **12 weeks** by late July ([FB 1409, p. 37](lib:turkey-raising#page=37)),
growing through the dry months, and **26–30 weeks** old in **November** ([p. 75](lib:turkey-raising#page=75)), when cold weather
finishes them and keeps the meat *(arithmetic and rule of thumb)*.

| Months | Flock work |
|---|---|
| **Jan–Feb** | Breeding pen made up: young tom in with the hens well before laying ([p. 22](lib:turkey-raising#page=22)); saddles, toenails. Breeder feed with greens and sun. Butcher the last of last year's birds on cold days. |
| **Mar–Apr** | Hens start to lay ([p. 32](lib:turkey-raising#page=32)). Collect daily; store hatching eggs cool, on their sides. Find hidden nests. Set hens that have sat 4–5 days. Sow range crops: sunflowers, kale, corn. |
| **May–Jun** | Hatches; hens and poults in coops on fresh short grass, out of the rain. Laying ends about June 1: eat breeders you won't keep — it "breaks the disease and parasite cycle" ([p. 24](lib:turkey-raising#page=24)). |
| **Jul–Aug** | Poults to clean range at **8 weeks** ([p. 37](lib:turkey-raising#page=37)); move weekly. Heat and smoke: shade, cool water, no milk. Range dries: more grain, or 2–3 times the range ([p. 55](lib:turkey-raising#page=55)). Fire plan ready — see the [Wildfire guide](guide:WILDFIRE-GUIDE). |
| **Sep–Oct** | Full feed for finishing; glean stubble. **Choose next year's breeders** ([p. 19](lib:turkey-raising#page=19)). Clip wings of birds that fly. Rains return: move to the winter yard on drained ground. |
| **Nov–Dec** | **Butcher in the cold**, one or two at a time; can the surplus. Rest this year's range for 2 years. |

## 👪 How many turkeys for a family

- **Breeding flock:** **one young tom, 4–8 hens and a spare young tom** *(rule of thumb, from the ratios above)*. A turkey hen sits on
  **15–18 eggs** and broods up to **20 poults** ([FB 1409, pp. 33, 37](lib:turkey-raising#page=33)); with incubators the bulletin
  expected **25 grown young per hen** a season (p. 33), but under hens plan on **one clutch per hen** *(rule of thumb)*.
- **Feed is the limit.** On range, standard Bronze ate **86.6 lb** of feed each to reach **18½ lb** at 28 weeks; Small Whites ate
  **52.6 lb** to reach **12 lb** at 24 weeks ([FB 1409, p. 51](lib:turkey-raising#page=51)). Plan on **60–90 lb of feed per bird** —
  **12 birds eat about 720–1,080 lb** — and 6 breeders eating **0.45 lb a day** ([p. 28](lib:turkey-raising#page=28)) eat about
  **320 lb** over a 120-day laying season *(arithmetic)*. Range, milk, scraps and stubble stretch it, but grain fed to turkeys is grain
  people don't eat: **size the flock to the grain you can grow.**
- **Range:** ½–2 acres per 100 birds ([p. 55](lib:turkey-raising#page=55)) is **⅛–½ acre for 25 birds** *(arithmetic)*; double or
  triple it for our dry summer, and keep **three such patches** so each rests 2 years *(rule of thumb, from the 1-year-in-3 rule)*.
- **Meat:** 12 medium heritage birds, half toms and half hens, give about **75 lb of lean meat** plus fat, broth and giblets; **one bird
  a week from mid-November through February is about 15 birds** *(arithmetic)*.
- **A workable plan** *(rule of thumb)*: 1 tom and 5 hens; two hens each hatch a clutch; raise about 20 poults; butcher about 15 from
  November to February; keep 4 young hens and a young tom for next year and eat the old tom.

## 🧯 If this goes wrong

| Problem | Likely cause | What to do |
|---|---|---|
| Many clear eggs at candling | Tom too old, too heavy or put in late; cold early weather ([FB 1409, pp. 22–23](lib:turkey-raising#page=22)) | A young, active tom with the hens weeks before laying; a spare tom |
| Eggs start but don't hatch | Stored too long, too warm or too cold ([p. 33](lib:turkey-raising#page=33)) | 50–60 °F, on their sides, set within a week |
| Eggs lost to crows and skunks | Hens lay in hidden spots ([p. 32](lib:turkey-raising#page=32)) | Short grass, no bushes, dark nest boxes, look every day |
| Poults die the first week | Never learned to eat; chilled; drowned; smothered in a corner | Feed within 24 h, tap and red, shallow guarded water, round corners, dry |
| Too much meat at once, or grain runs out | Too many birds; butchering in warm weather | Hatch later, kill in the cold one at a time, can the rest; eat young birds as roasters at 22–24 weeks |

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| **Sodium fluoride** pinched into the feathers of setting hens and poults, or a sodium fluoride dip — [FB 1409, pp. 69–70](lib:turkey-raising#page=69) | A poison. Ash-and-sulfur dust and a dust bath (Chickens guide) |
| **Nicotine sulfate** painted on roosts; **DDT** powder — [FB 1409, p. 69](lib:turkey-raising#page=69) | Scrub and sun the roosts; dust baths |
| **Anthracene oil, crude oil, crankcase oil or coal-tar disinfectant** on roosts for mites and ticks — [FB 1409, p. 70](lib:turkey-raising#page=70) | Scrub with hot water, take roosts apart, move them to clean ground |
| **Bluestone (copper sulfate)** in the only drinking water for crop disease — [FB 1409, p. 73](lib:turkey-raising#page=73) | Clean water; cull sick birds |
| **Phenothiazine** in the mash for cecal worms — [FB 1409, p. 69](lib:turkey-raising#page=69); [FB 1652, p. 51](lib:diseases-and-parasites-of-poultry#page=51) | "Only a stopgap", says its own book: clean ground and rotation |
| **Needle out a swollen sinus and inject silver nitrate** — [FB 1652, p. 16](lib:diseases-and-parasites-of-poultry#page=16) | Takes skill and a caustic: isolate, keep warm and out of drafts; cull chronic cases |
| **Steel traps on poles for owls and hawks; shoot them** — [FB 1409, p. 57](lib:turkey-raising#page=57) | Illegal: they are federally protected ([Kentucky ID-245, p. 5](lib:predator-management-for-small-scale-poultry#page=5)). Shut birds in |
| Hatching and brooding under hens **"not recommended"** — [FB 1409, pp. 33, 36](lib:turkey-raising#page=33) | Written for hatcheries with power. Without power, hens are the way: treat lice, use clean ground |

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings and photos in the books on this drive; the other links open the offline Wikipedia.

- **Varieties** — standard Bronze tom, [🖼️ FB 1409 p. 7](lib:turkey-raising#page=7); White Holland, [🖼️ p. 8](lib:turkey-raising#page=8); Narragansett, [🖼️ p. 10](lib:turkey-raising#page=10); Black hen, [🖼️ p. 11](lib:turkey-raising#page=11); Beltsville Small White, [🖼️ p. 12](lib:turkey-raising#page=12); Broad Breasted Bronze hen and carcasses, [🖼️ p. 16](lib:turkey-raising#page=16); [Domestic turkey](wiki:Domestic_turkey); [Heritage turkey](wiki:Heritage_turkey); [Bourbon Red](wiki:Bourbon_Red); [Royal Palm turkey](wiki:Royal_Palm_turkey); [Wild turkey](wiki:Wild_turkey); wild gobbler and hen, [🖼️ Today's Hunter p. 60](lib:todays-hunter-in-new-york#page=60)
- **Nests, feeders and shelters** — trap-nest, [🖼️ FB 1409 p. 30](lib:turkey-raising#page=30); trough feeder, [🖼️ p. 31](lib:turkey-raising#page=31); poult feeders for each age, [🖼️ p. 42](lib:turkey-raising#page=42); covered range feeder and range house, [🖼️ p. 53](lib:turkey-raising#page=53); open roosts in a storm semicircle, [🖼️ p. 54](lib:turkey-raising#page=54); portable range shelter, [🖼️ p. 55](lib:turkey-raising#page=55); small rearing shelter, [🖼️ p. 62](lib:turkey-raising#page=62)
- **Hatching** — size of the air cell in turkey eggs at 6, 12, 18 and 24 days, [🖼️ FB 1409 p. 34](lib:turkey-raising#page=34)
- **Disease** — blackhead liver, [🖼️ FB 1652 p. 52](lib:diseases-and-parasites-of-poultry#page=52); crop with trichomoniasis, [🖼️ p. 59](lib:diseases-and-parasites-of-poultry#page=59); [Histomonas meleagridis](wiki:Histomonas)
- **Gutting a bird** — [🖼️ UMN EB 385, p. 5](lib:home-processing-of-poultry#page=5)

## 🔗 Related guides

- [Chickens guide](guide:CHICKENS-GUIDE) — the methods this guide borrows: lice dust, coccidiosis, the predator table, the bear fence, gutting
- The [Ducks](guide:DUCKS-GUIDE) and [Geese](guide:GEESE-GUIDE) guides — the other poultry; keep them off turkey ground too ([FB 1409, p. 67](lib:turkey-raising#page=67))
- The [Dogs guide](guide:DOGS-GUIDE) — guardian dogs and watchdogs for the flock
- [Milk, Butter & Cheese guide](guide:DAIRY-GUIDE) and [Goats guide](guide:GOATS-GUIDE) — skim milk and curds for poults
- [Seed Bank guide](guide:SEED-BANK-GUIDE) — growing feed grain, sunflowers and kale
- [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE) — pressure-canning; [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — rendering fat
- [Food Security guide](guide:FOOD-SECURITY-GUIDE) — fitting meat and feed grain into a ration
- [Wildfire guide](guide:WILDFIRE-GUIDE) — smoke, evacuation and clearing around pens; [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE) — a solar charger for the bear fence
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — wild turkeys, and trapping the one raccoon that gets in
- [Paper & Ink guide](guide:PAPER-INK-GUIDE) — quill pens from wing feathers
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — animal vital signs, euthanasia, wildfire evacuation
