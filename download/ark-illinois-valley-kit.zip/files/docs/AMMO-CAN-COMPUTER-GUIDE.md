# 🧰 ARK Vault: the Ammo-Can Library Computer

<img src="img:AMMO-CAN-COMPUTER-GUIDE/ark-vault-logo.svg" alt="The ARK Vault logo: ARK in stencil letters inside a crate-label frame, with VAULT cut out of a solid bar below, its V drawn as an open book" width="260">

The **ARK Vault** is this whole library, ready for the day the power and the internet are gone, packed
in one steel ammo can you can carry. Inside is everything it needs: a small computer (a Raspberry Pi)
with the library and the offline AI, a battery, a wall charger, a solar charge controller kept for
later, a small printer, a crank radio, and an **old phone to read it on**.

Most of the time it sits **sealed**: lid shut and taped, nothing switched on, the steel shielding
everything inside from an EMP or a solar storm. When you need it, **open the lid and flip the red power
switch on**: the Pi starts and makes its own Wi-Fi, and the phone from the can (or any phone nearby)
opens the library and the AI in its web browser, with **no screen, keyboard or internet**. **Flip the
switch off** when you're done. Close the lid, tape it, and it's protected again.

> ### The short version
> - **Switch on, switch off.** A plain red power switch, in front of the printer, turns everything on
>   and off. The Pi's memory card is **read-only**, so cutting the power is always safe: nothing is ever
>   half-written, and nothing draws from the battery while it's off.
> - **Hold the little red button to check the battery.** The meter beside the switch shows the volts
>   and the amps the library is drawing.
> - **Shut = protected, open = in use.** The can only shields while the lid is closed and taped.
>   Never run it with the lid shut: it overheats, and phones can't reach it.
> - **The phone is the screen, and it lives in the can.** An old phone with no SIM card or phone plan
>   is fine. Any other phone nearby can join too.
> - **Charge it from the wall, lid open.** The wall charger lives in the can. The **solar charge
>   controller** is stored in the can too, not wired: after an event, take it out and wire it to the
>   battery and a panel. The panel stays outside, **not connected to anything**.
> - **No TV or keyboard needed to set it up.** Write Raspberry Pi OS onto the memory card, let the
>   library installer **finish the card**, plug everything in and switch on. It sets itself up.
> - **Steel can only.** Plastic ammo cans block nothing. The lid seam gets taped over bare metal
>   (see the [EMP guide](guide:EMP-GUIDE)).
> - **Practice now.** Build it, test it on the battery with the internet off, and check it every
>   few months.

---

## 🧰 The idea

**What lives inside the can, sealed:**
- the **Raspberry Pi** on the underside of the **lid**, beside the hinge, with its **library drive** (a
  small thumb drive) in a USB port
- the **battery** (LiFePO4, the safe lithium kind)
- the **wall charger**, lying on the **solar charge controller** (stored, not wired)
- a printed **riser** at the hinge end holding the **receipt printer**, the **power switch**, the
  **volt/amp meter** and its button, and on the inside of one leg the **5 V converter** and the **fuse**
- a **crank radio** and an **old phone** (the screen; the model has an iPhone XR), about half charged
- the **Wi-Fi card** taped in the lid, and a spare roll of **foil tape** for the seal

**What stays outside:** the **solar panel**, with **nothing plugged into it**. A panel is too big for
the can, and it doesn't need shielding: tests in the library found panels hit with a strong pulse
came through with only very minor change
([Sandia, p. 39](lib:hemp-testing-of-photovoltaic-modules#page=39)). The danger is the **wires**: a pulse
gathers on long wires and travels down them into whatever they're plugged into, which is the charge
controller ([EMP guide](guide:EMP-GUIDE)). So the panel sits unplugged in the shed or under the bed.

**Why the charge controller is stored in the can:** it's the electronic part a surge would damage, so
it waits inside the shield, not wired to anything. After an event, take it out and wire it between the
battery and the panel (see [Power and charging](#power-and-charging)). It's what makes solar charging
safe: it feeds the battery exactly what a lithium battery needs and stops when it's full. **Never
connect a panel straight to the battery.**

| | What you do | What's happening |
|---|---|---|
| **Stored** (most of the time) | Lid shut and taped, power switch off, panel outside | Nothing is on or connected. The steel can shields everything inside |
| **In use** | Open the lid, flip the power switch on, take out the phone | The Pi makes its own Wi-Fi; phones open the library in the browser |
| **Charging** | Lid open: plug the wall charger into the wall. After an event: wire up the solar controller and the panel | The battery fills while the Vault sits open (it can be in use at the same time) |
| **Back to storage** | Flip the switch off, unplug the charger, put the phone back, close and tape the lid | Shielded again. Do this right away if a solar-storm warning comes |

---

## 🧊 See it in 3D

Turn it, open the lid, look through the can, take a close-up of the Pi, or lift the printer's riser
out. **Tap a part's name** under the model to hide or show it; to see one part on its own, tap **Hide
all**, then that part. It works offline. Every wire is in it too.

<iframe src="AMMO-CAN-MODEL.html?embed" title="The ARK Vault in 3D" loading="lazy" style="width:100%;height:760px;max-height:92vh;border:0;border-radius:12px;background:#e6ebf2"></iframe>

[Open the 3D model full size](guide:AMMO-CAN-MODEL)

![Two views of the ARK Vault from its 3D model. Left: the lid swung right over past the hinge, with the Raspberry Pi lying face-up on it just beyond the can's end, the meter and power switch on the riser at the hinge end, and the battery at the latch end. Right: see-through, with the printer on its riser at the hinge end, the radio and the phone along the front wall, the battery along the back at the latch end, and the wall charger on the solar controller in front of it](img:AMMO-CAN-COMPUTER-GUIDE/the-build.png)
*Lid open (left) and see-through (right): pictures of the 3D model.*

---

## 🧭 How it works

| | Lid **shut** and taped (storage) | Lid **open**, switch **on** (in use) |
|---|---|---|
| Shielded from EMP? | **Yes**: a closed metal shell keeps the pulse out ([EMP guide](guide:EMP-GUIDE)) | No, but an EMP lasts seconds to minutes. Solar storms come with hours of warning |
| Running? | No: the power switch is off, and nothing passes through the can | Yes: the Pi, the printer and the Wi-Fi to the phones |
| Heat | None | The Pi gets warm; its fan comes on when it needs to. The open lid lets the heat out |

**Why not run it sealed?** A computer that's on needs Wi-Fi going out and a way to shed heat, and
every cable or hole through the can breaks the shield. The government guidance is plain: **no wires
through, no holes drilled**
([🖼️ right and wrong ways through a shield](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)).
So the can is the computer's **storage box and shield**, not its case while it runs. Charging is the
same: lid open, cables in from the top, never through the wall.

**The power switch.** Flip it on and the Pi starts by itself (2–3 minutes). Flip it off and the power
is simply cut. That's safe because the Pi's memory card and the library drive are **read-only**: the
Pi keeps anything that changes in memory and forgets it when the power goes, so nothing can be left
half-written. The other side of that: settings changed on the Pi while it runs don't stick (see
[Changing a setting later](#changing-a-setting-later)).

**The meter.** It sits in the power line and measures everything the library draws. It's dark most of
the time; **hold the little red button** beside the switch and it shows the battery's **volts** (top
row) and the **amps** being drawn (bottom row). Let go and it goes dark again, so it never drains the
battery.

**What the phones see:** the Pi makes its **own Wi-Fi network**. Phones join it and open the
library in the browser, the same way as [sharing with phones nearby](guide:START-ON-ANY-DEVICE).
Several phones can use it at once. Search and the books answer instantly. The AI answers one person
at a time, in about a minute.

---

## 🛒 What to buy

| Part | What to get | Why |
|---|---|---|
| **The can** | A **steel .50 cal ammo can** (inside about 279 × 140 mm, 179 mm deep; 11 × 5½ × 7 in) | Holds everything with the lid shut. Measure yours: cans vary a little |
| **Battery** | **12.8 V LiFePO4** (lithium iron phosphate), **20 Ah**, about 182 × 77 × 170 mm, and **rubber boots** for its two terminals | Runs the Pi for a day or two. LiFePO4 is the safe, long-lived lithium kind |
| **Computer** | **Raspberry Pi 4** (4 GB or more) or **Raspberry Pi 5** (8 GB) | A Pi 4 runs the small AI and is easy on the battery. A Pi 5 runs a bigger AI. Same size, same holes, same base on the lid: swap later |
| **Cooler** | A low heatsink with a small fan, **no taller than 16 mm** over the board (the model has a **GeeekPi Armor Lite**) | The AI works the chip hard. On a Pi 4 its fan goes on pins 4, 6 and 8; the setup switches it for you |
| **Memory card** (the Pi's own) | A **small** microSD card, **32 GB or more** | Holds only the Pi's own system. It goes in the Pi's card slot. **Not** the library: see [Two separate pieces](#two-separate-pieces-the-pis-card-and-the-library-drive) |
| **Library drive** | A **small USB 3 thumb drive**, **256 GB or more**, formatted **exFAT**, that sticks out **no more than about 19 mm (¾ in)** from the port | The full library is about 170 GB; see [How big a drive?](guide:GET-THE-LIBRARY). The Pi rides on the lid, so there's no room for an SSD |
| **Power for the Pi** | A **12 V to 5 V step-down converter, 5 A** (the model has a **TOBSUN EA25-5V**, 52 × 48 × 19 mm, screw terminals: the "5V 5A" one), about **80 cm of 18 AWG red/black pair**, and **two female jumper housings** for the Pi's pins (right-angle ones if you can get them) | Powers the Pi straight on its 5 V pins: thick wire all the way, and no USB-C plug to work loose. 5 A is enough for a Pi 5 too |
| **Switch, meter and fuse** | A **rocker switch** (21 × 15 mm face, snaps into its hole); a **DC volt/amp meter** with thick and thin wires (48 × 29 mm face, snaps in; the common 100 V, 10 A kind); a **microswitch** with its lever taken off (20 × 10 × 6.4 mm, the meter's button); an **inline blade fuse holder** with a **7.5 A** fuse | The switch turns it all on and off, the meter checks the battery, the fuse protects the wiring |
| **Wire and screws** | About 1.5 m each of **16 AWG red and black wire**, ring terminals for the battery's bolts, crimp connectors; 4 × M2.5 × 8 mm screws (the Pi), 2 × M2 screws (the microswitch), 2–4 short self-tapping screws for the converter (**M3 × 6 mm** or #4 × ¼ in, no longer), zip ties, **double-sided foam tape** (the strong kind, such as VHB) | |
| **Printer** (optional) | **DFRobot Embedded Thermal Printer (DFR0503)**, and **57 × 30 mm thermal paper** | Prints guides and answers ([printing](#printing-on-paper)) |
| **Radio** | A small **crank radio**, about 128 × 60 × 46 mm or smaller | News and weather with no grid ([Radio guide](guide:RADIO-GUIDE)) |
| **Wall charging** | A small **LiFePO4 charger**, 12 V, about 2 A, with a lithium setting (the model has a **MOTOPOWER MP00207A**, 175 × 60 × 45 mm) | Lies flat on the solar controller |
| **Solar, for later** | **Victron BlueSolar MPPT 75/15** (100 × 113 × 40 mm), a **20 A fuse**, and a 12 V solar panel (50–100 W) | Stored in the can, not wired. Charges the battery right ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE)) |
| **Seal** | Copper or aluminum **foil tape with conductive glue** | Closes the gap the rubber gasket leaves ([EMP guide](guide:EMP-GUIDE)) |
| **Screen** | An **old phone** (or small tablet) with a web browser, and its charging cable | It lives in the can. Any phone works, iPhones too; no SIM card or plan needed |
| **For setup** | Your regular computer with a **memory-card reader**, a **multimeter**, and a USB-C power supply (5 V, 3 A) for a first test on the bench | No TV, keyboard or mouse needed |

**Plastic cans don't work.** Plastic and fiberglass cans let the pulse straight through. Buy
steel ([Ammunition box](wiki:Ammunition_box)).

---

## 📐 The parts to print and etch

**[⬇️ Download the parts (ark-can-parts.zip)](https://cchristianson.github.io/so-survival-web/download/ark-can-parts.zip)** (from the
website). Its **READ-ME-FIRST.txt** has every size, the wiring and the settings in one place, and
**ARK-Vault-assembly.3dm** is the whole build to scale, for checking the fit in Rhino.

- **printed/**: three simple parts, about 42 cm³ of plastic in all. None needs supports.
  - The **printer riser** (96 × 91 × 153 mm): a table with one flat leg. The printer drops into its
    top; the walled strip in front of the printer holds the meter, the power switch and the meter's
    button; the converter screws to the raised frame on the inside of the leg, and the fuse holder
    sticks on below it.
  - The **wall cleat** (27 × 77 × 3 mm): a small strip that sticks to the can's hinge-end wall. The
    riser's other end hooks onto it, and its shallow V keeps the riser from sliding sideways.
  - The **Pi's base** (57 × 66 × 5 mm): a thin plate with four posts, which sticks under the lid.

  ![The three printed parts as they sit on the printer's bed: the riser upside down with its deck on the bed and its one leg standing up, the Pi's base flat with its four posts up, and the wall cleat flat](img:AMMO-CAN-COMPUTER-GUIDE/printed-parts.png)
  *The files open in the slicer the way they print: the riser deck-down, the other two flat.*

  Print in **ABS** (it stands the heat of a car better than PLA *(rule of thumb)*) with **no supports**.
  The riser's leg is a 1.2 mm wall, so set **3 walls** with a 0.4 mm nozzle (2 with a 0.6) and it
  prints solid; layers of 0.2 to 0.28 mm are fine. These are a first fit for this layout: print the
  Pi's base first, then the riser, and check them against your can and your parts.
- **laser/**: the **ARK Vault logo** for both long sides of the can, and **bare-metal strips** all the
  way round the lid seam, for the foil tape. For a laser that burns through paint.

![The ammo can after etching: the ARK Vault logo on a long side, and two bare-metal strips along the lid seam, the same on both long sides, with foil tape over the closed seam](img:AMMO-CAN-COMPUTER-GUIDE/can-plan.png)
*The long sides: the same file on each. No laser? Scrape the paint off the same strips by hand.*

![The two ends after etching: on each end a bare band at the same height as the lower strip on the long sides, on the hinge plate under the hinge at one end and around the latch at the other; taped, one band of foil tape runs right round the can, over the hinge and over the closed latch](img:AMMO-CAN-COMPUTER-GUIDE/can-plan-ends.png)
*The ends: the lower strip carries on round at the same height, and one band of tape goes right round
the can, over the hinge and the latch.*

---

## 🔧 Build it, step by step

### 1. Get the can ready

1. **Bare metal all round the seam.** Etch with a laser, or scrape the paint off by hand. On **both long
   sides**: a strip on the lid's edge and one on the body just below it (the logo goes on both long
   sides too). On **each end**: the body's strip carried on round at the same height, on the hinge plate
   under the hinge at one end and, with the latch flipped up out of the way, across the other. The foil
   tape goes over these, metal to metal. See the EMP guide's [Faraday containers](guide:EMP-GUIDE) section.
2. **Nothing lines the can.** Every part is in its own case or on the riser. Keep bare wire ends and
   bolts covered (rubber boots, heat-shrink, tape) so nothing metal can touch the steel.

### 2. The battery

Stand the battery at the **latch end**, straight on the raised panel in the can's floor, against the
**back** wall, terminals toward the back. Put the ring terminals on its bolts: the main **+** lead (to the fuse), the
main **−** lead (to the meter) and the wall charger's leads. Then push the **rubber boots** over both
terminals: they keep the bolts off the lid.

### 3. The chargers

In front of the battery, against the latch wall: stand the **solar controller** on its long, narrow
edge (100 × 40 mm) on the floor, terminals toward the hinge end. It's stored, not wired. Lay the **wall
charger** flat on top of it, coil its mains cord on top and lay the plug on the coil. The quick-connect
plug of its battery leads sits beside the coil.

### 4. The printer riser

1. Snap the **meter** and the **rocker switch** into their holes in the riser's front strip. Set the
   **microswitch** in its slot, red button up, flush with the top, and screw it to the rib beside it
   (2 × M2).
2. Both small parts go on the inside of the riser's **leg**. Hold the **converter** on the raised frame,
   its screw terminals toward the front, and fix it through its mounting holes with short self-tapping
   screws (**M3 × 6 mm** or #4 × ¼ in; anything longer comes out the other side, against the battery). The
   frame is thick all the way round, so the screws can go wherever the holes are. Stick the **fuse holder**
   across the leg below it, about 1 cm (⅜ in) above the bottom, with double-sided foam tape.
3. Drop the **printer** into the top: its face rests on the riser.
4. Stick the **wall cleat** to the inside of the can's **hinge-end wall** with foam tape: thick edge up, its
   sloped face toward the wall, the low point of its V in the middle. Its two top corners go about
   **29 mm (1⅛ in) below the top of the can's rim**, and its back end about 6 mm (¼ in) from the back wall,
   where the corner's curve ends.
5. Wire the riser (next steps; it has one leg, so lay it on its side while you work), then lower it into
   the **hinge end** of the can, against the back wall: its leg stands on the floor beside the battery, and
   the lip under its other end drops in behind the cleat and settles into the V. Check the deck sits
   level. It lifts straight out again for repairs and to change the fuse, with the lid open all the way.

### 5. The Pi on the lid

1. Fit the **cooler** on the Pi, and plug its fan onto **pins 4, 6 and 8** (red, black, blue), as its
   leaflet shows (diagram below).
2. Screw the Pi onto its printed **base** (4 × M2.5 screws; the base is shorter than the board, so the USB
   end overhangs it), and stick the base under the **lid** at the **hinge end**, over the printer, with
   double-sided foam tape. Point the Pi's **USB ports toward the front** of the can, with the base's edges
   about **13 mm (½ in)** in from the inside of the hinge wall and **9 mm (⅜ in)** in from the back wall:
   the 5 V wires run in the gap at the hinge end.
   Opened all the way, the lid swings right over past the hinge and the Pi lies face-up just beyond the
   can's end. The latch lever hangs from the lid's far end and can flop onto the inside of the open lid:
   it reaches about 11 cm, and the Pi is about 21 cm away, so it can't touch it.
3. Plug the **library drive** into a **blue** USB port and the printer's **USB lead** into a black one.

### 6. Wiring

![The ARK Vault wiring. Battery plus goes through a 7.5 amp fuse and the power switch to the printer and the 5 volt converter. Battery minus goes through the volt/amp meter's thick wires (black in, red out) to the printer and the converter. The meter's thin black wire goes to battery minus, its thin yellow wire to plus after the fuse, and its thin red wire through the meter button to plus after the fuse, so it lights only while the button is held. The converter's 5 volt output goes to the Pi's pin 2 (plus) and pin 14 (ground); the fan is on pins 4, 6 and 8; the printer's USB lead goes to a Pi USB port](img:AMMO-CAN-COMPUTER-GUIDE/wiring.svg)
*The whole wiring (a diagram drawn for this guide). The 3D model shows where each wire runs.*

- **Battery +** → **7.5 A fuse** → **power switch** → the converter's **Input +** and the printer's +.
- **Battery −** → the meter's **thick black** wire; the meter's **thick red** wire → the converter's
  **Input −** and the printer's −. Everything the library draws goes through the meter.
- **The meter's thin wires:** **black** → battery −. **Yellow** → + after the fuse (it reads the
  battery's volts). **Red** → the meter button (the microswitch's **COM** and **NO**) → + after the fuse,
  so the meter lights only while you hold the button. Check your meter's own wiring sheet: some put
  the thick wires the other way round.
- **The converter's Output +** → Pi **pin 2** (5 V); **Output −** → Pi **pin 14** (ground). **Before** you
  plug this lead onto the Pi, switch on and check it with a multimeter: **5.0 to 5.25 V**, + and − the
  right way round. The 5 V pins skip the Pi's own input protection, so a mistake here can kill it.
- **The fan** → pins **4** (red, 5 V), **6** (black, ground), **8** (blue, GPIO 14).
- **The printer's USB lead** → a USB port on the Pi.
- **The route:** the 5 V pair and the printer's lead go together up the gap between the battery and
  the riser, along the front wall (over the phone) to the hinge corner, and loop up into the lid there
  (leave about **6 cm (2½ in)** in the loop, so the lid opens freely). On the lid, the printer's lead runs
  a few centimetres along the front to its USB port, and the 5 V pair runs along the hinge end, between
  the Pi's base and the lid's rim, to its pins.
- **The fuse** is on the riser's leg beside the battery, so only about 23 cm (9 in) of wire runs from
  battery + to the fuse with no fuse on it. Tie that wire down along its route, away from sharp edges. (The battery's own protection
  is the back-up.)

![The Raspberry Pi pins the ARK Vault uses, at the end of the 40-pin row farthest from the USB ports, all on the row along the board's edge: pin 2 (5 volts) takes the converter's plus wire, pins 4, 6 and 8 take the cooler fan's red, black and blue wires (5 volts, ground, GPIO 14), and pin 14 (ground) takes the converter's minus wire](img:AMMO-CAN-COMPUTER-GUIDE/pi-pins-ark.svg)
*All five wires go on the row along the board's edge. Pin 2 is the corner pin at the end farthest from the USB ports (a diagram drawn for this guide).*

Bend the wires off the jumper housings toward the board's edge: with the lid shut, the printer sits
just below them. **A Pi 5's** cooler plugs into the Pi 5's own fan socket instead, and its power lead
goes on the same pins 2 and 14.

### 7. The rest

- The **radio** stands in front of the riser, partly under the meter, straight on the floor in the
  hinge-end corner, up against the phone. The
  **phone** stands on its end against the front wall beside it. To take the radio out: lift the phone
  out, slide the radio toward the front wall, then lift it.
- **Solar:** the controller stays stored, its terminals empty (see
  [Power and charging](#power-and-charging)).
- **Nothing should touch bare metal.** Loose metal can short things out, and the EMP guidance is to
  keep items off the walls ([CISA, p. 45](lib:emp-protection-and-resilience-guidelines#page=45)).

---

## 💾 Set up the Pi (no TV or keyboard)

The library installer prepares the Pi's memory card so the Pi **sets itself up the first time it
starts**. The steps are the same for a Pi 4 and a Pi 5.

### Two separate pieces: the Pi's card and the library drive

The Vault needs **two** storage pieces, and they must not be the same one:

![The Raspberry Pi seen from the side: a small memory card in the card slot underneath holds the Pi's own system; the library drive, a USB stick, a small SSD or a big microSD card in a USB card reader, plugs into a blue USB port](img:AMMO-CAN-COMPUTER-GUIDE/two-pieces.svg)
*The Pi's own card in its slot; the library on a USB drive (a diagram drawn for this guide).*

| | **The Pi's memory card** | **The library drive** |
|---|---|---|
| What it holds | Only the Pi's own system (Raspberry Pi OS) | The whole library, the AI, and the programs |
| What it is | A **small microSD card**, 32 GB or more | A **USB** drive, 256 GB or more. In the Vault: a **small thumb drive** (no more than about 19 mm long beyond the port) |
| Where it goes | The card slot **under** the Pi | A **blue** USB port |
| Filled by | **Raspberry Pi Imager**, then the library installer's **Finish a Raspberry Pi memory card** | The library **installer** (the same kit) |

- **Never point Raspberry Pi Imager at the library drive.** Imager **erases** the whole card or drive it
  writes to. When you pick the storage in Imager, check its size: about 32 GB is the Pi's card;
  256 GB is your library.
- **The library can't go on the Pi's card.** The Pi has one card slot, and its own system has to be
  there, so the library always comes in through USB. (Outside the Vault, a USB SSD or a big microSD
  card in a USB card reader works too.)
- Keeping them separate also means the library drive stays readable by any computer or phone: pull it
  out of the Vault and it works anywhere, like any copy of the library.

### The steps

1. **Fill the library drive** with the installer:
   **[⬇️ Download the installer kit (ark-illinois-valley-kit.zip)](https://cchristianson.github.io/so-survival-web/download/ark-illinois-valley-kit.zip)**. It's the
   same kit for every computer and for the ARK Vault; see [Get the whole library](guide:GET-THE-LIBRARY). Keep the drive **exFAT**, and keep **Offline AI** and
   **Works on every kind of device** ticked (that one puts the Raspberry Pi version on the drive).
2. **Write Raspberry Pi OS onto the Pi's own small memory card** (not the library) with **Raspberry Pi
   Imager** (free, from raspberrypi.com) on your regular computer. Unplug the library drive first, so
   you can't pick it by mistake.
   - Device: your Pi (**Raspberry Pi 4** or **5**).
   - Operating system: **Raspberry Pi OS (other)** → **Raspberry Pi OS Lite (64-bit)**.
   - Storage: the **small** card (check the size). When it asks about **customisation**, choose
     **No**. Write it.
   - When it's finished, take the card out and plug it back in.
3. **Finish the card with the library installer.** Start **INSTALL** again (the same kit you filled
   the drive with) and press **Finish a Raspberry Pi memory card** on its first page. Pick the card
   (it's called **bootfs**), keep or change the Wi-Fi name and password, leave **It's in the ARK
   ammo can, with an on/off switch** ticked, and press **Finish the memory card**. **Write down the
   Wi-Fi name and password** it shows.
4. **Eject the card** and put it in the Pi's card slot (underneath). Plug the **library drive** into
   a **blue** USB port.
5. **Switch it on.** On the bench: a USB-C power supply (5 V, 3 A or more) in the Pi's USB-C port. In
   the can: the red power switch. (Never both at once.) Its green light **beats like a heart** while it
   sets itself up (about 5–10 minutes). Then it restarts by itself. 2–3 minutes after that, its Wi-Fi
   appears (a bit longer the first time, while the AI times itself and picks its size).

What the setup does: the Pi makes its **own Wi-Fi** every time it starts, **starts the library by
itself** and shares it, mounts the library drive in the same place every time, lets the library use
the printer, opens any USB drive of **photos and videos** (read-only) for the library's **Photos**
page, runs the cooler's **fan** on a Pi 4 (pins 4, 6 and 8: on at 60 °C, off at 50 °C), and makes
the Pi's memory card and the library drive **read-only**: the Pi keeps changes in memory and forgets
them when the power goes, so flipping the power switch off is always safe. It also saves
**`PI-WIFI-CARD.html`** at the top of the library drive with the Wi-Fi name, password and address:
print it later on any computer and tape it inside the lid.

**If the green light keeps blinking fast instead**, it got stuck. Switch it off, put the memory card
in your computer and open **ark** → **setup-log.txt**: the last lines say why (usually the library
drive wasn't plugged in). Fix it, put the card back and switch on again. It tries again at every
start until it has worked.

**Updating later** (a new version of the library or its programs): run the installer again on the
**library drive** (pick the same drive; it only adds what's new), then **finish the Pi's card again**
(step 3) and switch on: it sets itself up again with the new version. Finishing the card turns its
read-only mode off for that, and the setup turns it back on when it's done.

**Moving to a Pi 5 later:** finish the same card again with the installer (step 3), then put it in
the Pi 5. Finishing the card makes it set itself up again for the new Pi.

### Changing a setting later

The card is read-only, so a change made on the running Pi is gone at the next start.
- **The Wi-Fi name or password:** finish the card again with the installer (step 3), with the new
  ones, and switch on.
- **Anything else** (with a screen and keyboard): log in and type
  `bash /mnt/emergency-library/OfflineLibrary/SETUP-Raspberry-Pi.sh --writable`, restart, make the
  change, then run `bash /mnt/emergency-library/OfflineLibrary/SETUP-Raspberry-Pi.sh` again to make it
  read-only again.

**The Pi's own login** is only needed for repairs with a screen and keyboard: user name **ark**,
password the same as the Wi-Fi password.

### Test it the way you'll use it

1. Flip the **power switch** on and wait **2–3 minutes**.
2. On the phone, open **Settings → Wi-Fi**, join the Pi's Wi-Fi (**Emergency-Library** unless you
   changed it) with the password. If it says *no internet*, tap **Stay connected** / **Keep**.
3. Open the phone's browser (on an iPhone, **Safari**) and type the address **exactly**: `http://192.168.4.1:8096`.
   To keep it one tap away, add it to the home screen (**Share → Add to Home Screen**).
4. Search for something, open a guide, ask the AI a question, and print something. Plug a USB drive
   of photos into a free USB port and open **🔧 Tools → 🖼️ Family photos & videos**.
5. **Hold the meter's button:** it shows the battery's volts and the amps being drawn.
6. **Flip the switch off.** Everything goes dark at once; that's fine.
7. Do it all again with the home internet switched off.

---

## 🆘 Using it

1. **Open the lid** all the way (it swings right over and rests past the hinge) and **flip the red power
   switch on**. Keep the can in the shade.
2. **Take out the phone** and switch it on. **Wait 2–3 minutes** for the Pi.
3. **On the phone** (and any others): join the Pi's Wi-Fi, open the browser, type the address from
   the card in the lid. Save it as a bookmark on the can's phone so it's one tap next time.
4. **To turn it off:** **flip the switch off**, any time. Close the lid and **tape the seam** again.

**Is it safe to have it out?** A nuclear EMP is over in seconds to minutes. A solar storm comes with
18–72 hours' warning. If a warning comes, switch off and seal the can (see
[when a solar-storm warning comes](guide:EMP-GUIDE)). Use it the rest of the time.

**Save the battery:** switch off when nobody needs it, and check the battery now and then with the
meter's button. Searching and reading use little power; the AI uses the most.

**Family photos and videos:** plug a USB drive of them into a free USB port on the Pi, any time.
They show under **🔧 Tools → 🖼️ Family photos & videos**, folder by folder, full screen or as a
slideshow. The drive opens read-only, so nothing on it can change.

---

## 🖨️ Printing on paper

The **receipt printer** on the riser lets anyone on the Pi's Wi-Fi print a guide section, an AI answer
or a book page, to take to the garden, the barn or a neighbor. It's a thermal printer: heat-sensitive
paper, **no ink or ribbon** to run out of. It gets its power from the battery with everything else,
so it's on whenever the power switch is.

**Paper:** **thermal rolls 57 × 30 mm** (2¼ inches wide, no more than 30 mm across the roll), plain,
not sticker paper. A roll is about **8.5 m (28 ft)**. Only one side prints: if the paper comes out
blank, turn the roll over.

**Printing:**
- **🖨️ Print** is at the top of every guide and every other page of the library, in an e-book's
  top bar, and at the bottom right of encyclopedia articles. Under each AI answer there's
  **🖨️ Print this answer**. Every book has a **🖨️** of its own: next to it in the **Books** tab, and
  next to each book in an answer's sources (**🖨️ page**, already set to the page the answer used).
- For a guide, choose **this section** (the one you're reading), the **whole page**, or text you
  selected first.
- The **preview** shows exactly what will come out, and how much paper it takes.
  **Save the picture** keeps it on the phone instead.

**Printing from a book.** A whole book page shrunk onto 2¼-inch paper can't be read, so there are two
ways to print one. Choose a page, or a run of pages (up to 20 at a time), then:
- **The words, re-flowed to fit the paper:** the page's text set out again in the size you choose,
  one strip for all the pages, with "page 13" between them. The least paper, and easy to read.
- **A picture of each page,** for drawings, tables and diagrams. The phone draws the page itself (with
  PDF.js, the PDF reader in Firefox), so this works on the Vault with no internet.
  - **Bigger** prints the page 2, 3 or 4 strips wide, so small print comes out large enough to read.
  - **Cut each strip into** 2–4 pieces turns long strips into shorter ones.
  - Each piece prints on its own, labelled **A1, A2 … B1** with a little map: lay the columns (A, B …)
    left to right and the pieces (1, 2 …) top to bottom, and tape them together on the back.

| One page as a picture | Paper it takes *(about)* |
|---|---|
| Whole page | 2½ in (6 cm) |
| 2 strips across | 10 in (25 cm) |
| 3 strips across | 22 in (56 cm) |
| 4 strips across | 3¼ ft (1 m) |

| Size | Characters a line | A typical guide section | Good for |
|---|---|---|---|
| **Tiny** | 76 | about **2–3 inches** | the most on the least paper; read it close up |
| **Small** | 64 | about 3 inches | everyday use |
| **Medium** | 48 | about 4–5 inches | easier reading |
| **Large** | 38 | about 7 inches | weak eyes, signs and notes |

*(Lengths measured with the library's own preview.)* In **Tiny** the letters are about 1 mm tall.
The preview warns when a print has **doses or measurements** in it: in Tiny, check every number on
the paper, or print those in Small or Medium.

**To save paper and power:** print one section at a time, use Tiny, and leave **Pictures** and
**Book page references** off (both are off unless you tick them). Dark pictures take the most power
*(rule of thumb)*.

**Looking after prints:** thermal prints fade with heat, sunlight and time. Keep them out of the
sun and away from the stove, and copy anything you'll need for years in pencil *(rule of thumb)*.
Keep spare rolls sealed in a bag, cool and dark.

Another printer: other 58 mm receipt printers with USB that understand standard "ESC/POS" commands
should work too *(rule of thumb)*; they need **9–24 volts** and up to 2.5 amps while printing, so a
USB power bank won't run them. A printer on the Pi's serial pins needs the library started with
`-printer /dev/serial0` (and then the fan needs a different pin than GPIO 14).

---

## 🔋 Power and charging

The Pi 4 uses roughly **3–4 watts** while it sits waiting and around **7 watts** while the AI
writes an answer; a Pi 5 a bit more *(rule of thumb)*. The 20 Ah battery holds about 250 watt-hours,
so it runs the Pi for **about 30–40 hours** of normal use: a long day of use for a week, switched off
in between *(rule of thumb)*.

**Checking the battery:** hold the meter's button. A resting LiFePO4 battery reads about **13.3 V full**,
**13.0 V** at half, and **12.0 V** nearly empty: charge it then *(rule of thumb)*. The bottom row shows
the amps the library draws: well under 1 A while the Pi just runs, more while the AI works or the
printer prints.

**From the wall:** plug the charger in with the lid open, set it to **lithium** (LiFePO4). At 2 A it
takes **about 10 hours** from empty. Unplug it when its **Full** light comes on. Its leads stay on the
battery (with their own 7.5 A fuse), so you only plug it in.

**From the sun (after an event):** the Victron controller is stored in the can with its terminals empty.
To charge from a panel:
1. Take the controller out (or work with the lid open), and set it up once in the **VictronConnect**
   phone app: battery type **LiFePO4**, maximum charge current about **10 A** (check your battery's
   manual). The BlueSolar model has no Bluetooth of its own: it talks to the app through a Victron
   **VE.Direct** Bluetooth dongle or USB cable (the SmartSolar model has Bluetooth built in).
2. Wire the **battery first**: BATT+ to battery + through the **20 A fuse**, BATT− to battery −.
3. Then the **panel**: PV+ and PV−. A plug-and-socket pair on the panel lead (an SAE or Anderson
   connector) makes this a five-second job.
4. When you're done, unplug the **panel first**, then the battery, and store the panel outside the can
   with nothing connected to it (see [The idea](#the-idea)).

A 100 W panel fills the battery in about a sunny day; much less in winter. More about panels and
batteries: [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE).

**The phone:** charge it from any phone charger, or from one of the Pi's USB ports while the Vault is
running (slowly; if the Pi ever restarts, unplug the phone). Keep it about half charged in storage.

**Never charge with the lid shut**, and never run a cable through a hole in the can. **Never connect the
panel straight to the battery:** always through the controller.

---

## 📦 Packing and sealing

1. **Flip the power switch off.** Unplug the wall charger and the solar panel if they're connected,
   and put the phone back in its place.
2. **Charge the battery to about half or a bit more** for long storage *(rule of thumb)*, then
   top it up every few months.
3. **Close the lid, latch it,** and tape it shut over the bare metal, so the tape touches bare metal on
   the lid and on the body: **one band of 2-inch foil tape right round the can** (about 1 m, 40 in), over
   the seam on the long sides, over the hinge at one end and over the closed latch at the other,
   overlapping where it meets itself. Press it down well on the bare strips
   ([🖼️ why seams matter](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275)).
   Keep a spare roll of tape in the can.
4. **Test the seal** with the phone-and-radio test in the [EMP guide](guide:EMP-GUIDE): tape the can
   shut with a phone inside and call it, then a battery AM radio tuned to a station. Silence means no
   big leaks.

Store it somewhere cool and dry, not in a hot car or shed.

---

## 🛠️ If something goes wrong

| Problem | Try this |
|---|---|
| The first setup: the green light **blinks fast** and keeps blinking | It got stuck. Switch off, put the memory card in your computer and read **ark/setup-log.txt**. Usually: plug in the library drive, then switch on again |
| The first setup: nothing happens at all, no light | Check the power: the fuse, the battery's charge (hold the meter's button) and the switch. Check the converter gives **5.0–5.25 V** at the plug on pins 2 and 14. Was the card written with Raspberry Pi Imager **and** finished by the installer? |
| The Wi-Fi name doesn't show up on the phone | Wait the full 3 minutes. Is the lid open? Switch off, wait 10 seconds, switch on and wait again |
| Joined the Wi-Fi, but the page won't open | On an **iPhone**, use **Safari**: Chrome and other browsers can't reach the Pi until you turn on **Settings → (the browser) → Local Network**. Type the address exactly, including `http://` and `:8096`. Turn on **airplane mode**, then turn **Wi-Fi** back on (some phones use mobile data instead of a Wi-Fi with no internet). Right after power-up, wait another minute |
| The page opens but the AI says it isn't ready | It's still loading. Give it a minute or two. Search and the books work meanwhile |
| The AI is very slow | It picks a size to suit the Pi. On a Pi 4 it uses the small AI. Searching and reading the books stay fast |
| The Pi keeps restarting, or the drive disappears | Not enough power. Check the converter's output while the Pi runs (5.0–5.25 V), that the 5 V wires are 18 AWG and well crimped, and the battery's charge |
| The meter stays dark when I hold the button | Its thin red wire must go through the microswitch's **COM** and **NO** (not NC). Check the fuse |
| The meter shows no amps, or odd ones | Its thick wires may be the wrong way round: check the meter's wiring sheet |
| The fan never runs | It only runs above 60 °C, so it's off much of the time. Check its blue wire is on pin 8, and that **It's in the ARK ammo can** was ticked when the card was finished |
| A setting I changed was gone after switching off | That's the read-only card doing its job: see [Changing a setting later](#changing-a-setting-later) |
| The printer: *No printer found* | Is its USB lead in the Pi, and is the printer's power lead on? Close the print window and open it again |
| The printer: *not allowed to use the printer* | Finish the card again, switch on and let it set itself up again |
| The printer feeds blank paper | The roll is in upside down: only one side of thermal paper prints. Turn it over |
| The print is faint or stops partway | The battery is low. Charge it |
| Forgot the Wi-Fi password | Plug the library drive into any computer and open **`PI-WIFI-CARD.html`** |
| No phone can connect at all, or there's no phone | Use a **TV or computer monitor** instead: plug it into the Pi (the micro-HDMI port next to the power socket) with a USB keyboard, log in (user **ark**, the Wi-Fi password) and make the card writable (see [Changing a setting later](#changing-a-setting-later)), then type `bash /mnt/emergency-library/OfflineLibrary/SETUP-Raspberry-Pi.sh --screen`. Say **y** to restart. Lite has no desktop, so for a screen use **Raspberry Pi OS (64-bit)**, the desktop version, from the start |
| Want home internet on the Pi again (for updates) | Plug in a network cable. Or log in and run the setup with `--undo` (twice: the first time makes the card writable and restarts). Running the setup again later keeps the same Wi-Fi name and password |

**Running the setup by hand** (with a screen and keyboard): log in, then type
`bash /mnt/emergency-library/OfflineLibrary/SETUP-Raspberry-Pi.sh` (or the path to wherever your
library is) and press Enter. It asks the same questions the installer did. On a read-only card it
tells you to run it with `--writable` first.

---

## 🖐️ Other ways to build it

- **A touchscreen on the Pi** (a 7-inch screen, say) shows the library right on the Pi, with no phone.
  It needs **Raspberry Pi OS (64-bit)**, the desktop version, not Lite, and the **touchscreen** box
  ticked when you finish the card. It won't fit in the can: it's for a bigger box.
- **No power switch** (a Pi on a shelf, or in a bigger box): untick **It's in the ARK ammo can** when
  you finish the card, and power it from a USB-C supply or power bank (5 V, 3 A or more; a 27 W
  Raspberry Pi supply for a Pi 5). Then shut it down before unplugging it: a **Pi 5** has a **power
  button** (press once, wait for the red light, unplug). A **Pi 4** gets one on **pins 5 and 6**: a
  spring-back push button on two female jumper wires.

![A Raspberry Pi 4 seen from above, with the USB ports at the right end; the push button's two wires go onto the third pair of pins counted from the left end of the 40-pin row, pins 5 and 6](img:AMMO-CAN-COMPUTER-GUIDE/pi4-power-button-pins.svg)
*No power switch, on a Pi 4: a push button on pins 5 and 6 shuts it down safely (a diagram drawn for this guide).*

---

## 🔄 Every few months

- **Check the battery** with the meter's button, and top it and the phone up to about half or a bit
  more.
- **Flip the switch on** and run through the test above. Then switch off, close the lid and re-tape
  the seam.
- **Updating the library:** plug the drive into your regular computer and run the installer again
  (it adds what's new). If the programs changed, finish the Pi's card again too (see
  [Updating later](#the-steps)).
- Swap the foil tape if it's torn or stops sticking.

---

## 🖼️ Pictures & diagrams

- The Raspberry Pi itself — [Raspberry Pi](wiki:Raspberry_Pi)
- Steel ammunition cans — [Ammunition box](wiki:Ammunition_box)
- How a closed metal box blocks a pulse — [Faraday cage](wiki:Faraday_cage); [Electromagnetic shielding](wiki:Electromagnetic_shielding)
- Why a wire through the box ruins it — [🖼️ MIL-HDBK-419A Vol 2, p. 315](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)
- How fields leak through seams and slots — [🖼️ MIL-HDBK-419A Vol 1, p. 275](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275)
- What 10, 20 and 30 dB of shielding buys — [🖼️ CISA, p. 77](lib:emp-protection-and-resilience-guidelines#page=77)
- The battery kind — [Lithium iron phosphate battery](wiki:Lithium_iron_phosphate_battery); solar chargers — [Maximum power point tracking](wiki:Maximum_power_point_tracking)

## 🔗 Related guides

- [EMP, Solar Storms & Faraday Cages](guide:EMP-GUIDE): building and testing the shield
- [Start the Library on Any Device](guide:START-ON-ANY-DEVICE): sharing with phones, and other devices
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE): batteries and solar to keep it running
- [Get the Whole Library](guide:GET-THE-LIBRARY): filling the library drive
- [Emergency Radio Guide](guide:RADIO-GUIDE): another thing worth keeping in a sealed can
