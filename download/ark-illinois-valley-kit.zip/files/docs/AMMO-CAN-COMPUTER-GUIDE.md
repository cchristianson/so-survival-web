# 🧰 Ammo-Can Library Computer

How to build a steel ammo can that holds this whole library, the offline AI, a battery, a small
printer and a crank radio. **Open the lid and pull the Raspberry Pi up**: it switches on and makes its
own Wi-Fi, and any phone nearby uses the library and the AI in its web browser, with **no screen,
keyboard or internet**. **Push it back down**: it shuts itself down and everything switches off.
Close and tape the lid, and the steel can shields it all from an EMP or a solar storm.

> ### The short version
> - **Pull up = on, push down = off.** The Pi rides on a slide. Two small switches and a relay
>   turn the power on, shut the Pi down safely and then cut the power, so nothing drains the battery.
> - **Shut = protected, open = in use.** The can only shields while the lid is closed and taped.
>   Never run it with the lid shut: it overheats, and phones can't reach it.
> - **The phone is the screen.** An old phone with no SIM card or phone plan is fine.
> - **No TV or keyboard needed to set it up.** Write Raspberry Pi OS onto the memory card, let the
>   library installer **finish the card**, plug everything in and pull the Pi up. It sets itself up.
> - **Steel can only.** Plastic ammo cans block nothing. The lid seam gets taped over bare metal
>   (see the [EMP guide](guide:EMP-GUIDE)).
> - **Practice now.** Build it, test it on the battery with the internet off, and check it every
>   few months.

---

## 🧊 See it in 3D

Turn it, open the lid, take the lid off, raise the Pi or lift the whole rack out. It works offline.

<iframe src="AMMO-CAN-MODEL.html?embed" title="The ammo-can computer in 3D" loading="lazy" style="width:100%;height:620px;max-height:90vh;border:0;border-radius:12px;background:#e6ebf2"></iframe>

[Open the 3D model full size](guide:AMMO-CAN-MODEL)

![Two views of the ammo can. Left: lid off, the Raspberry Pi pulled up on its slide above the printed rack, with the receipt printer beside it and the battery behind. Right: see-through, showing the battery at one end, the radio and wall charger lying in front of it, and the solar controller standing inside the rack under the printer](img:AMMO-CAN-COMPUTER-GUIDE/the-build.png)
*Lid off with the Pi pulled up (left), and see-through (right): pictures of the 3D model.*

---

## 🧭 How it works

| | Lid **shut** and taped (storage) | Lid **open**, Pi **up** (in use) |
|---|---|---|
| Shielded from EMP? | **Yes**: a closed metal shell keeps the pulse out ([EMP guide](guide:EMP-GUIDE)) | No, but an EMP lasts seconds to minutes. Solar storms come with hours of warning |
| Running? | No: the relay has cut the power, and nothing passes through the can | Yes: the Pi, the printer and the Wi-Fi to the phones |
| Heat | None | The Pi gets warm. The open lid lets the heat out |

**Why not run it sealed?** A computer that's on needs Wi-Fi going out and a way to shed heat, and
every cable or hole through the can breaks the shield. The government guidance is plain: **no wires
through, no holes drilled**
([🖼️ right and wrong ways through a shield](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)).
So the can is the computer's **storage box and shield**, not its case while it runs. Charging is the
same: lid open, cables in from the top, never through the wall.

**The slide.** The Pi sits on a printed carrier that slides up and down inside a printed rack.
- **Pulling it up** (about 2 inches, until it clicks) lets go of switch A, which turns the power on.
  The Pi starts, and its Wi-Fi antenna ends up above the rim of the can.
- **Pushing it down** (until it clicks) presses both switches. Switch B tells the Pi to shut down.
  While it shuts down, a relay held on by the Pi keeps the power on; once the Pi is off, the relay
  lets go (you hear a click, about 30 seconds later) and everything is off.

**What the phones see:** the Pi makes its **own Wi-Fi network**. Phones join it and open the
library in the browser, the same way as [sharing with phones nearby](guide:START-ON-ANY-DEVICE).
Several phones can use it at once. Search and the books answer instantly. The AI answers one person
at a time, in about a minute.

---

## 🛒 What to buy

| Part | What to get | Why |
|---|---|---|
| **The can** | A **steel .50 cal ammo can** (inside about 282 × 144 mm, 179 mm deep; 11 × 5¾ × 7 in) | Holds everything with the lid shut. Measure yours: cans vary a little |
| **Battery** | **12.8 V LiFePO4** (lithium iron phosphate), **20 Ah**, about 182 × 77 × 170 mm | Runs the Pi for a day or two. LiFePO4 is the safe, long-lived lithium kind |
| **Computer** | **Raspberry Pi 4** (4 GB or more) or **Raspberry Pi 5** (8 GB) | A Pi 4 runs the small AI and is easy on the battery. A Pi 5 runs a bigger AI. Same size, same holes, same carrier: swap later |
| **Cooler** | A **stick-on heatsink** set, **under 16 mm tall** (no fan case) | The AI works the chip hard. A tall case won't fit on the carrier |
| **Memory card** | microSD card, **32 GB or more** | Holds the Pi's own system |
| **Library drive** | A **small USB SSD**, 256 GB or more, formatted **exFAT**; the thumb-drive kind that plugs straight into the Pi | The full library is about 170 GB; see [How big a drive?](guide:GET-THE-LIBRARY). It rides up and down with the Pi |
| **Power for the Pi** | A **12 V to USB-C adapter**, **5 V 5 A** (USB-C PD), and a short **right-angle USB-C lead** (30 cm, 5 A) | 5 A is enough for a Pi 5 too |
| **The slide's electrics** | **2 × KW12-3 roller micro switches**; a **5 V 1-channel relay module**, 10 A contacts, **high-level trigger** (its H/L jumper on H); **5 female-female jumper wires** (30 cm); a **7.5 A inline fuse** | Switch A turns the power on, switch B shuts the Pi down, the relay cuts the power after |
| **Screws** | 4 × M2.5 × 8 mm (the Pi), 2 × M2 × 20 mm with nuts (the switches), 1 × M3 × 12 mm with nut (the slide's top stop), zip ties | |
| **Printer** (optional) | **DFRobot Embedded Thermal Printer (DFR0503)**, and **57 × 30 mm thermal paper** | Prints guides and answers ([printing](#printing-on-paper)) |
| **Radio** | A small **crank radio**, up to 132 × 51 × 66 mm (5.2 × 2 × 2.6 in) | News and weather with no grid ([Radio guide](guide:RADIO-GUIDE)) |
| **Solar charging** | **Victron SmartSolar MPPT 75/15** (100 × 113 × 50 mm), a **20 A fuse**, and a 12 V solar panel (50–100 W) | Stands inside the rack. Charges the battery right ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE)) |
| **Wall charging** | A small **LiFePO4 charger**, 12 V, about 2 A, with a lithium setting (the model has a MOTOPOWER MP00207A, 175 × 60 × 45 mm) | Lies in the can on the radio |
| **Lining** | **2 mm cardboard** (laser cut, or by hand from the drawings) and double-sided tape | Keeps everything off the bare steel |
| **Seal** | Copper or aluminum **foil tape with conductive glue** | Closes the gap the rubber gasket leaves ([EMP guide](guide:EMP-GUIDE)) |
| **Screen** | An **old phone or tablet** with a web browser | Any phone works, iPhones too |
| **For setup** | Your regular computer with a **memory-card reader** | No TV, keyboard or mouse needed |

**Plastic cans don't work.** Plastic and fiberglass cans let the pulse straight through. Buy
steel ([Ammunition box](wiki:Ammunition_box)).

---

## 📐 The parts to print, cut and etch

**[⬇️ Download the parts (ark-can-parts.zip)](https://cchristianson.github.io/so-survival-web/download/ark-can-parts.zip)** (from the
website). Its **READ-ME-FIRST.txt** has every size, the wiring and the settings in one place.

- **printed/**: the **rack**, the **Pi carrier**, the **printer plate** and two **battery spacers**.
  Print in **ABS** (it stands the heat of a car better than PLA *(rule of thumb)*), **no supports**,
  3 walls, 15–20% infill, each the way round it comes.
- **cardboard/**: the lining (floor, two long walls, two end walls, a sheet for under the lid), at
  real size. Red lines are cuts.
- **laser/**: the **logo** for the side of the can, and two **bare-metal strips** along the lid
  seam on both long sides, for the foil tape. For a laser that burns through paint.

![The ammo can after etching: the logo on one long side, and two bare-metal strips along the lid seam on both long sides, with foil tape over the closed seam](img:AMMO-CAN-COMPUTER-GUIDE/can-plan.png)
*Where the logo and the bare-metal strips go. No laser? Scrape the paint off the same strips by hand.*

---

## 🔧 Build it, step by step

### 1. Get the can ready

1. **Bare metal at the seam.** Etch the two strips with a laser, or scrape the paint off by hand:
   a strip on the lid's edge and one on the body just below it, on both long sides. The foil tape
   goes over these, metal to metal. See the EMP guide's [Faraday containers](guide:EMP-GUIDE) section.
2. **Line it.** Lay the cardboard floor (its hole fits over the raised panel in the can's floor),
   then the walls. Tape the lid sheet under the lid with double-sided tape: it keeps the battery's
   bolts off the steel.

### 2. The battery

Stand the battery at the **hinge end**, terminals up, and slip the two printed **spacers** in to hold
it still. Fit its leads now (ring terminals on the bolts), with the **7.5 A fuse** in the plus lead,
close to the battery.

### 3. The rack

1. Screw the two **switches** onto the block under the slide, on the two M2 screws, nuts on the
   battery side. Leave them loose for now.
2. Stand the **solar controller** inside the rack, against the latch end, its screw terminals
   facing the open front (its wires need about an inch there).
3. Put the **printer** into the **printer plate** and drop the plate onto its ledges.
4. Fit the **relay** module and the **12 V to USB-C adapter** in the rack, then stand the rack at the
   **latch end** of the can.

### 4. The Pi on its slide

1. Stick the heatsinks on the Pi. Screw the Pi onto the **carrier** (4 × M2.5 screws).
2. Plug the **library drive** into a **blue** USB port, and the right-angle **USB-C lead** into the
   Pi's power socket.
3. Slide the bare carrier into the rails first: it should move freely. If it's tight, sand its two
   edges lightly.
4. With the carrier resting down on its shelves, slide the switches up until **both click**, then
   1 mm more, and tighten them.
5. Fit the **M3 stop screw** last (head inside, nut outside). It stops the carrier at the top. Take
   it out to lift the Pi out for repairs.
6. Zip-tie the USB-C lead and the printer's USB lead to the carrier's loops, leaving a 3-inch loop so
   the Pi can travel up and down.

### 5. Wiring

![Wiring diagram: battery plus goes through a 7.5 amp fuse to switch A and the relay, side by side, then on to the 12 volt to USB-C adapter and the printer. Battery minus goes to the adapter and the printer. The relay's IN, VCC and GND go to Pi pins 1, 2 and 9. Switch B goes to pins 5 and 6. The adapter's USB-C lead and the printer's USB lead go to the Pi](img:AMMO-CAN-COMPUTER-GUIDE/wiring.svg)
*The whole wiring. Switch A and the relay sit side by side: either one gives power (a diagram drawn for this guide).*

- **Battery +** → 7.5 A fuse → **switch A** (COM and NC) **and** the **relay** (COM and NO), side by
  side → the adapter's + and the printer's +.
- **Battery −** → the adapter's − and the printer's −.
- **Relay module** (jumper wires): **IN** → Pi **pin 1** (3.3 V), **VCC** → **pin 2** (5 V),
  **GND** → **pin 9**.
- **Switch B** (COM and NO) → Pi **pins 5 and 6**, either way round.
- The adapter's **USB-C** → the Pi. The printer's **USB** → the Pi.

![The five Pi pins the slide uses, at the end of the 40-pin row farthest from the USB ports: pin 2 (5 volts) to the relay VCC and pin 6 to switch B on the row along the board's edge; pin 1 (3.3 volts) to the relay IN, pin 5 to switch B and pin 9 to the relay GND on the inner row](img:AMMO-CAN-COMPUTER-GUIDE/pi-pins-slide.svg)
*Pin 1 is at the end farthest from the USB ports, on the inner row. The even pins are along the board's edge (a diagram drawn for this guide).*

**Why it works:** while the Pi runs, its 3.3-volt pin holds the relay on, so the power stays on after
switch A opens. Switch B makes the Pi shut down. Once it's off, its 3.3-volt pin goes off too, the
relay lets go, and nothing draws from the battery. (The Pi has to be told to switch that pin off at
shutdown: the setup below does it.)

### 6. The rest

- The **radio** lies on the floor in front of the battery; the **wall charger** lies on its side on
  top of the radio.
- **Solar:** the controller's battery terminals go to the battery through the **20 A fuse**. Its
  panel terminals stay empty until you charge (see [Power and charging](#power-and-charging)).
- **Nothing should touch bare metal.** Loose metal can short things out, and the EMP guidance is to
  keep items off the walls ([CISA, p. 45](lib:emp-protection-and-resilience-guidelines#page=45)).

---

## 💾 Set up the Pi (no TV or keyboard)

The library installer prepares the Pi's memory card so the Pi **sets itself up the first time it
starts**. The steps are the same for a Pi 4 and a Pi 5.

1. **Fill the library drive** with the installer, as described in
   [Get the whole library](guide:GET-THE-LIBRARY). Keep the drive **exFAT** and keep **AI** ticked.
2. **Write Raspberry Pi OS onto the memory card** with **Raspberry Pi Imager** (free, from
   raspberrypi.com) on your regular computer:
   - Device: your Pi (**Raspberry Pi 4** or **5**).
   - Operating system: **Raspberry Pi OS (other)** → **Raspberry Pi OS Lite (64-bit)**.
   - Storage: the memory card. When it asks about **customisation**, choose **No**. Write it.
   - When it's finished, take the card out and plug it back in.
3. **Finish the card with the library installer.** Start **INSTALL** again (the same kit you filled
   the drive with) and press **Finish a Raspberry Pi memory card** on its first page. Pick the card
   (it's called **bootfs**), keep or change the Wi-Fi name and password, leave **It's in the ARK
   ammo can, on the slide** ticked, and press **Finish the memory card**. **Write down the Wi-Fi
   name and password** it shows.
4. **Eject the card** and put it in the Pi. Make sure the **library drive** is in a blue USB port.
5. **Pull the Pi up.** Its green light **beats like a heart** while it sets itself up (about
   5 minutes, sometimes longer). Then it restarts by itself. 2–3 minutes after that, its Wi-Fi
   appears (a bit longer the first time, while the AI times itself and picks its size).

What the setup does: the Pi makes its **own Wi-Fi** every time it starts, **starts the library by
itself** and shares it, mounts the library drive in the same place every time, lets the library use
the printer, turns **pins 5 and 6 into the shut-down switch**, and tells the Pi to **switch
everything off once it has shut down** (so the relay lets go). It also saves **`PI-WIFI-CARD.html`**
at the top of the library drive with the Wi-Fi name, password and address: print it later on any
computer and tape it inside the lid.

**If the green light keeps blinking fast instead**, it got stuck. Push the Pi down (or unplug the
battery lead), put the memory card in your computer and open **ark** → **setup-log.txt**: the last
lines say why (usually the library drive wasn't plugged in). Fix it, put the card back and pull the
Pi up again. It tries again at every start until it has worked.

**Moving to a Pi 5 later:** finish the same card again with the installer (step 3), then put it in
the Pi 5. The new Pi needs its own shut-down settings, and finishing the card makes it set itself up
again.

**The Pi's own login** is only needed for repairs with a screen and keyboard: user name **ark**,
password the same as the Wi-Fi password.

### Test it the way you'll use it

1. Pull the Pi up and wait **2–3 minutes**.
2. On the phone, open **Settings → Wi-Fi**, join the Pi's Wi-Fi (**Emergency-Library** unless you
   changed it) with the password. If it says *no internet*, tap **Stay connected** / **Keep**.
3. Open the phone's browser and type the address **exactly**: `http://192.168.4.1:8096`.
4. Search for something, open a guide, ask the AI a question, and print something.
5. **Push the Pi down.** Its green light flickers, then stays off; about **30 seconds** later the
   relay **clicks** and the printer's light goes out. That's the whole thing off.
6. Do it all again with the home internet switched off.

---

## 🆘 Using it

1. **Open the lid** and **pull the Pi up** until it clicks. Keep the can in the shade.
2. **Wait 2–3 minutes.**
3. **On each phone:** join the Pi's Wi-Fi, open the browser, type the address from the card in the
   lid.
4. **To turn it off:** **push the Pi down** until it clicks. Wait for the relay's click (about
   30 seconds). Close the lid and **tape the seam** again.

**Is it safe to have it out?** A nuclear EMP is over in seconds to minutes. A solar storm comes with
18–72 hours' warning. If a warning comes, push the Pi down and seal the can (see
[when a solar-storm warning comes](guide:EMP-GUIDE)). Use it the rest of the time.

**Save the battery:** push the Pi down when nobody needs it. Searching and reading use little power;
the AI uses the most.

---

## 🖨️ Printing on paper

The **receipt printer** in the rack lets anyone on the Pi's Wi-Fi print a guide section, an AI answer
or a book page, to take to the garden, the barn or a neighbor. It's a thermal printer: heat-sensitive
paper, **no ink or ribbon** to run out of. It gets its power from the battery with everything else,
so it's on whenever the Pi is up.

**Paper:** **thermal rolls 57 × 30 mm** (2¼ inches wide, no more than 30 mm across the roll), plain,
not sticker paper. A roll is about **8.5 m (28 ft)**. Only one side prints: if the paper comes out
blank, turn the roll over.

**Printing:**
- **🖨️ Print** is at the top of every guide and every other page of the library, in an e-book's
  top bar, and at the bottom right of encyclopedia articles. Under each AI answer there's
  **🖨️ Print this answer**, and next to each book in its sources, **🖨️ page** prints that book page.
- Choose **this section** (the one you're reading), the **whole page**, or text you selected
  first. A book page prints as **its words**, or **as a picture** for drawings (bigger in 2 or 3
  strips, which takes more paper).
- The **preview** shows exactly what will come out, and how much paper it takes.
  **Save the picture** keeps it on the phone instead.

| Size | Characters a line | A typical guide section | Good for |
|---|---|---|---|
| **Tiny** | 76 | about **2–3 inches** | the most on the least paper; read it close up |
| **Small** | 64 | about 3 inches | everyday use |
| **Medium** | 48 | about 4–5 inches | easier reading |
| **Large** | 38 | about 7 inches | weak eyes, signs and notes |

*(Lengths measured with the library's own preview.)* In **Tiny** the letters are about 1 mm tall.
The preview warns when a print has **doses or measurements** in it: in Tiny, check every number on
the paper, or print those in Small or Medium.

**To save paper and power:** print one section at a time, use Tiny, and leave **Pictures** and
**Book page references** off (both are off unless you tick them). Dark pictures take the most power
*(rule of thumb)*.

**Looking after prints:** thermal prints fade with heat, sunlight and time. Keep them out of the
sun and away from the stove, and copy anything you'll need for years in pencil *(rule of thumb)*.
Keep spare rolls sealed in a bag, cool and dark.

Another printer: other 58 mm receipt printers with USB that understand standard "ESC/POS" commands
should work too *(rule of thumb)*; they need **9–24 volts** and up to 2.5 amps while printing, so a
USB power bank won't run them. A printer on the Pi's serial pins needs the library started with
`-printer /dev/serial0`.

---

## 🔋 Power and charging

The Pi 4 uses roughly **3–4 watts** while it sits waiting and around **7 watts** while the AI
writes an answer; a Pi 5 a bit more *(rule of thumb)*. The 20 Ah battery holds about 250 watt-hours,
so it runs the Pi for **about 30–40 hours** of normal use: a long day of use for a week, with the
Pi pushed down in between *(rule of thumb)*.

**Solar** (Victron SmartSolar MPPT 75/15): open the lid, lay the panel in the sun and connect it to
the controller's panel terminals, with the cable coming in over the top. Set it up once in the
**VictronConnect** phone app (it talks over Bluetooth): battery type **LiFePO4**, maximum charge
current about **10 A** (check your battery's manual). A 100 W panel fills the battery in about a
sunny day; much less in winter. More about panels and batteries:
[Off-Grid Power](guide:OFF-GRID-POWER-GUIDE).

**From the wall:** plug the charger in with the lid open, set it to **lithium** (LiFePO4). At 2 A it
takes **about 10 hours** from empty. Unplug it when its **Full** light comes on. Its leads can stay on
the battery (with their own 7.5 A fuse) so you only plug it in.

**Never charge with the lid shut**, and never run a cable through a hole in the can.

---

## 📦 Packing and sealing

1. **Push the Pi down** and wait for the relay's click.
2. **Charge the battery to about half or a bit more** for long storage *(rule of thumb)*, then
   top it up every few months.
3. **Close the lid** and run the **foil tape** all the way around the seam, over the bare-metal strips,
   so it touches bare metal on the lid and on the body
   ([🖼️ why seams matter](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275)).
   Keep a spare roll of tape in the can.
4. **Test the seal** with the phone-and-radio test in the [EMP guide](guide:EMP-GUIDE): tape the can
   shut with a phone inside and call it, then a battery AM radio tuned to a station. Silence means no
   big leaks.

Store it somewhere cool and dry, not in a hot car or shed.

---

## 🛠️ If something goes wrong

| Problem | Try this |
|---|---|
| The first setup: the green light **blinks fast** and keeps blinking | It got stuck. Push the Pi down, put the memory card in your computer and read **ark/setup-log.txt**. Usually: plug in the library drive, then pull the Pi up again |
| The first setup: nothing happens at all, no light | Check the power: the fuse, the battery's charge, and that switch A clicks free when the Pi is up. Was the card written with Raspberry Pi Imager **and** finished by the installer? |
| The Wi-Fi name doesn't show up on the phone | Wait the full 3 minutes. Is the lid open and the Pi all the way up? Push it down, wait for the click, pull it up and wait again |
| Joined the Wi-Fi, but the page won't open | Type the address exactly, including `http://` and `:8096`. Turn on **airplane mode**, then turn **Wi-Fi** back on (some phones use mobile data instead of a Wi-Fi with no internet). Right after power-up, wait another minute |
| The page opens but the AI says it isn't ready | It's still loading. Give it a minute or two. Search and the books work meanwhile |
| The AI is very slow | It picks a size to suit the Pi. On a Pi 4 it uses the small AI. Searching and reading the books stay fast |
| Pushed down, the Pi shut down, but the relay never clicks | The Pi wasn't told to switch everything off at shutdown. Finish the card again with the installer (slide ticked) and let it set itself up again. For now: unplug the battery lead once the Pi's green light has stayed off for 20 seconds |
| Pushed down, but the Pi keeps running | Switch B isn't pressed or isn't on pins 5 and 6. With the carrier down, both switches must click: loosen them, slide them up 1 mm and tighten |
| Pulled up, but it won't start | Switch A isn't letting go: check it clicks when the carrier lifts. If the Pi ever doesn't start, push it down, wait half a minute, pull it up again |
| The Pi keeps restarting, or the drive disappears | Not enough power: the adapter must give **5 V 5 A**, and its lead must be a 5 A one. Check the battery's charge |
| The carrier sticks | Sand its two edges lightly. ABS shrinks a little as it cools, so the first print may be snug |
| The printer: *No printer found* | Is its USB lead in the Pi, and is the printer's power lead on? Close the print window and open it again |
| The printer: *not allowed to use the printer* | Finish the card again (or run the setup again), then restart |
| The printer feeds blank paper | The roll is in upside down: only one side of thermal paper prints. Turn it over |
| The print is faint or stops partway | The battery is low. Charge it |
| Forgot the Wi-Fi password | Plug the library drive into any computer and open **`PI-WIFI-CARD.html`** |
| No phone can connect at all, or there's no phone | Use a **TV or computer monitor** instead: plug it into the Pi (the micro-HDMI port next to the power socket) with a USB keyboard, log in (user **ark**, the Wi-Fi password) and type `bash /mnt/emergency-library/OfflineLibrary/SETUP-Raspberry-Pi.sh --screen`. Say **y** to restart. Lite has no desktop, so for a screen use **Raspberry Pi OS (64-bit)**, the desktop version, from the start |
| Want home internet on the Pi again (for updates) | Plug in a network cable. Or log in and run the setup with `--undo`, then restart. Running the setup again later keeps the same Wi-Fi name and password |

**Running the setup by hand** (with a screen and keyboard): log in, then type
`bash /mnt/emergency-library/OfflineLibrary/SETUP-Raspberry-Pi.sh` (or the path to wherever your
library is) and press Enter. It asks the same questions the installer did.

---

## 🖐️ Other ways to build it

- **A touchscreen on the Pi** (a 7-inch screen, say) shows the library right on the Pi, with no phone.
  It needs **Raspberry Pi OS (64-bit)**, the desktop version, not Lite, and the **touchscreen** box
  ticked when you finish the card. It won't fit on the slide: it's for a bigger box.
- **No slide** (a Pi on a shelf, or in a bigger box): untick **on the slide** when you finish the card,
  and power it from a USB-C supply or power bank (5 V, 3 A or more; a 27 W Raspberry Pi supply for a
  Pi 5). A **Pi 5** has a **power button**: press once to shut down, wait for the red light, unplug. A
  **Pi 4** gets one on **pins 5 and 6**: a spring-back push button on two female jumper wires.

![A Raspberry Pi 4 seen from above, with the USB ports at the right end; the push button's two wires go onto the third pair of pins counted from the left end of the 40-pin row, pins 5 and 6](img:AMMO-CAN-COMPUTER-GUIDE/pi4-power-button-pins.svg)
*No slide on a Pi 4: a push button on pins 5 and 6 shuts it down safely (a diagram drawn for this guide).*

---

## 🔄 Every few months

- **Top up** the battery (and the phone) to about half or a bit more.
- **Pull the Pi up** and run through the test above. Then push it down, wait for the click, close the
  lid and re-tape the seam.
- **Updating the library:** plug the drive into your regular computer and run the installer again
  (it adds what's new). Nothing needs to change on the Pi.
- Swap the foil tape if it's torn or stops sticking.

---

## 🖼️ Pictures & diagrams

- The Raspberry Pi itself — [Raspberry Pi](wiki:Raspberry_Pi)
- Steel ammunition cans — [Ammunition box](wiki:Ammunition_box)
- How a closed metal box blocks a pulse — [Faraday cage](wiki:Faraday_cage); [Electromagnetic shielding](wiki:Electromagnetic_shielding)
- Why a wire through the box ruins it — [🖼️ MIL-HDBK-419A Vol 2, p. 315](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)
- How fields leak through seams and slots — [🖼️ MIL-HDBK-419A Vol 1, p. 275](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275)
- What 10, 20 and 30 dB of shielding buys — [🖼️ CISA, p. 77](lib:emp-protection-and-resilience-guidelines#page=77)
- The battery kind — [Lithium iron phosphate battery](wiki:Lithium_iron_phosphate_battery); solar chargers — [Maximum power point tracking](wiki:Maximum_power_point_tracking)
- How the relay works — [Relay](wiki:Relay); the switches — [Miniature snap-action switch](wiki:Miniature_snap-action_switch)

## 🔗 Related guides

- [EMP, Solar Storms & Faraday Cages](guide:EMP-GUIDE): building and testing the shield
- [Start the Library on Any Device](guide:START-ON-ANY-DEVICE): sharing with phones, and other devices
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE): batteries and solar to keep it running
- [Get the Whole Library](guide:GET-THE-LIBRARY): filling the library drive
- [Emergency Radio Guide](guide:RADIO-GUIDE): another thing worth keeping in a sealed can
