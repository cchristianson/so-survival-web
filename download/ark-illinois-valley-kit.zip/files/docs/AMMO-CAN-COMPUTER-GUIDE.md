# 🧰 ARK Vault: the Ammo-Can Library Computer

<img src="img:AMMO-CAN-COMPUTER-GUIDE/ark-vault-logo.svg" alt="The ARK Vault logo: ARK in stencil letters inside a crate-label frame, with VAULT cut out of a solid bar below, its V drawn as an open book" width="260">

The **ARK Vault** is the whole library packed in one steel ammo can: a small computer (a Raspberry
Pi), a battery, a charger, a little printer, a crank radio and an old phone to read it on.

**Most of the time it sits sealed**, lid taped shut, protected from an EMP or solar storm. **When you
need it,** open the lid and flip the red switch on. The phone joins the Vault's own Wi-Fi and opens
the library and the AI in its web browser. No internet, screen or keyboard needed.

> ### The short version
> - **Switch on, switch off.** Flipping the switch off is always safe.
> - **Lid shut and taped = protected. Lid open = in use.** Never run it with the lid shut.
> - **The phone in the can is the screen.** Any other phone nearby can join too.
> - **Hold the little red button** to see how much battery is left.
> - **Charge it from the wall with the lid open.** Solar is for after an emergency (see
>   [Power and charging](#power-and-charging)).
> - **Steel can only.** Plastic ammo cans don't block anything.
> - **Practice now.** Build it, test it with the internet off, and check it every few months.

<div class="jump">
<a href="#using-it"><b>Use it</b><span>Switch on, join its Wi-Fi, charge it, seal it</span></a>
<a href="#the-idea"><b>Look inside</b><span>What's in the can, in 3D, and how it works</span></a>
<a href="#what-to-buy"><b>Build one</b><span>Buy, print, wire and set up, step by step</span></a>
</div>

<p class="part">Use it</p>

## 🆘 Using it

![Using it in five steps: 1, open the lid all the way (mesh radio fitted? screw its antenna on first); 2, flip the red switch on; 3, take out the phone and wait 2 to 3 minutes; 4, join the Vault's Wi-Fi and open its address; 5, when done, switch off, close the lid and tape the seam](img:AMMO-CAN-COMPUTER-GUIDE/using-it.svg)

1. **Open the lid** all the way. *Mesh radio fitted?* **Screw its antenna on now**, before the
   switch.
2. **Flip the red switch on**. Keep it in the shade.
3. **Take out the phone** and wait **2–3 minutes**.
4. **Join the Pi's Wi-Fi** and open the address from the card in the lid.
5. **When you're done,** flip the switch off, close the lid and **tape the seam** again.

If a **solar-storm warning** comes, switch off and seal it right away (see the
[EMP guide](guide:EMP-GUIDE)). Switch off when nobody's using it to save the battery; the AI uses
the most power.

**The map:** **Tools → Map** shows roads, topo lines, property lines and satellite photos on any phone on the
Vault's Wi-Fi. For sharp satellite photos close up, download them onto the library drive first, on a
computer with internet: **More → Offline & downloads → Sharp satellite photos**. **📍** shows where you are (the phone warns once; the map says what to tap), and **🖨️**
prints the part on screen in strips. See [Offline maps](guide:HOW-TO-VIEW-MAPS).

**Family photos:** plug a USB drive of photos into a free USB port. They show under **Tools →
🖼️ Family photos & videos**. Nothing on that drive can be changed.

**Drawings:** **Tools → CAD** draws a plan, a part or a pattern to scale, on any phone or
laptop on the Vault's Wi-Fi. To keep drawings **on the Vault**, where everyone can open them:

1. On any computer, make a folder named **`ARK-Saved`** on a small thumb drive (any size will do).
2. Plug it into a free USB port on the Pi, then switch on.

That folder is how the Vault knows it may save there. It is the **only** drive the Vault ever writes
to; the library drive and a photo drive can't be changed. With no such drive, a drawing is saved to
the phone or laptop you are using instead. *A Vault set up before November 2026 has to learn this:
finish the Pi's card again ([The steps](#the-steps), step 3).*

## 🔋 Power and charging
<!-- fold: How long it runs, how full it is, and charging it from the wall or the sun -->

**How long it runs:** a full battery runs the Pi for about **30–40 hours** of use: a long day of
use every day for a week *(rule of thumb)*.

**Checking the battery:** hold the meter button. About **13.3 V** is full, **13.0 V** half, and
**12.0 V** nearly empty: charge it then *(rule of thumb)*.

**From the wall:** with the lid open, plug the wall charger in (set to **lithium**). About **10
hours** from empty. Unplug it when the **Full** light comes on.

**From the sun (after an event):**
1. Set the controller up once in the **VictronConnect** phone app (battery type **LiFePO4**, charge
   current about **10 A**). The BlueSolar needs a Victron **VE.Direct** Bluetooth dongle or USB
   cable to talk to the app.
2. Wire the **battery first**, in **12 AWG**: BATT+ → battery + through the **20 A fuse** (the fuse
   close to the battery), BATT− → battery −.
3. Then the **panel**: PV+ and PV−, with the panel's own leads.
4. When done, unplug the **panel first**, then the battery, and store the panel outside with
   nothing plugged in.

A 100 W panel fills it in about a sunny day. More in [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE).

**The phone:** charge it from any phone charger, or from the Pi's USB port while it runs. Keep it
about half charged in storage.

> ⚠️ Never charge with the lid shut, never run a cable through a hole in the can, and **never
> connect the panel straight to the battery**.

## 🖨️ Printing on paper
<!-- fold: Print a guide, an AI answer or a book page on the little printer -->

Anyone on the Vault's Wi-Fi can print a guide section, an AI answer or a book page on the little
receipt printer. It uses heat-sensitive paper: **no ink** to run out.

- **🖨️ Print** is at the top of every guide and page, and under each AI answer
  (**🖨️ Print this answer**). Every book has a **🖨️** button too.
- **Pick a size:** **Tiny** fits the most on the paper; **Small** or **Medium** are easier to read;
  **Large** for weak eyes. The preview shows how much paper it will take.
- **Book pages:** print the **words** (re-flowed to fit, least paper) or a **picture** of the page
  (for drawings and tables). A picture can be printed **bigger**, in strips you tape together; each
  strip is labelled (A1, A2, B1…) so you know where it goes.
- **Doses and measurements:** in **Tiny**, check every number, or print in Small.

**Paper:** **57 × 30 mm** thermal rolls (2¼ in wide). If the paper comes out blank, the roll is in
upside down. Prints fade in heat and sun, so copy anything important in pencil. Keep spare rolls
cool and dark.

## 📡 The mesh radio (optional)
<!-- fold: Texting with no cell service, and what to set up now, while there's internet -->

A **mesh radio** sends short **text messages** and **positions** from one radio to another, with
no cell service and no internet. Every radio in range passes messages along. It needs no license.
The software is **Meshtastic**, which is free.

- **One radio stays with the Vault,** under the lid. The Vault powers it whenever the switch is on.
- **The pocket radio** (the card) goes with whoever leaves, along with the **second phone**.
- **Each radio talks to its own phone** by Bluetooth, through the **Meshtastic app**. You type and
  read messages in the app. The Vault's library page does **not** show mesh messages yet.

> ⚠️ **Antenna first, every time.** Screw the antenna on **before** you flip the switch. A radio
> that sends with no antenna can burn itself out.

**Do these now, while there is internet:**
1. Put the **Meshtastic app** on both phones.
2. Check each radio has Meshtastic on it and set its region to **US** (the app asks). The pocket
   card comes with it. The Vault's board may need it put on first, from a computer, at
   **flasher.meshtastic.org**.
3. Pair each radio with its phone, give both radios the **same channel**, and send a test message
   each way.

**How far it reaches** *(rule of thumb)*: through thick forest or hills, ¼ to 1 mile; around
town, 1 to 3 miles; with a clear view across a valley, 5 miles or more. A ridge in between often
blocks it. **Height helps most:** after an event, raise the Vault's antenna as high as you can.

**Stored, everything is inside the sealed can:** the radio, its antenna (unscrewed), the pocket
radio and both phones. Nothing goes through the can's wall.

Setting the radios up, private channels, range, relays and a neighborhood mesh: the
[Mesh radio guide](guide:MESH-RADIO-GUIDE). The project's own manual and the Android app are on the
library drive, in `Comms-Signals\Mesh-Radio`.

## 📦 Packing and sealing
<!-- fold: Switch off, charge it to half, tape the seam and test the seal -->

1. **Switch off,** unplug the chargers, and put the phone back. *Mesh radio fitted?* Unscrew its
   antenna and stand it back in its corner, and put the pocket radio and second phone back.
2. **Charge the battery to about half** for storage, and top it up every few months.
3. **Close and latch the lid,** then run **one band of foil tape right round the can** over the bare
   strips (about 1 m), over the hinge and the latch, overlapping at the end. Press it down well
   ([🖼️ why seams matter](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-1#page=275)).
4. **Test the seal:** tape a phone inside and call it. If it doesn't ring, the seal is good. (More
   in the [EMP guide](guide:EMP-GUIDE).)

Store it somewhere cool and dry, not in a hot car or shed.

## 🔄 Every few months
<!-- fold: The battery, a test run, an update and the tape -->

- **Check the battery** with the meter button, and top it and the phone up to about half. The
  second phone and the pocket mesh radio too, if you have them.
- **Switch on and run the [test](#test-it).** Then switch off and re-tape the seam.
- **Update the library:** run the installer on the library drive again, then finish the Pi's card
  again (see [The steps](#the-steps)).
- Replace the foil tape if it's torn or loose.

## 🛠️ If something goes wrong
<!-- fold: Problems and their fixes, from no lights at all to a slow AI -->

| Problem | Fix |
|---|---|
| First setup: the green light **blinks fast** and keeps blinking | It got stuck. Read **ark/setup-log.txt** on the card. Usually: plug in the library drive and switch on again |
| Nothing lights up | Check the fuse, the battery (hold the meter button) and the switch. Check the converter gives **5.0–5.25 V** |
| The Wi-Fi doesn't show up | Wait the full 3 minutes with the lid open. Switch off, wait 10 seconds, switch on |
| Joined the Wi-Fi, but the page won't open | On an iPhone, use **Safari**. Type the address exactly, with `http://` and `:8096`. Try **airplane mode** on, then Wi-Fi back on |
| The AI says it isn't ready | Give it a minute or two. Search works meanwhile |
| An answer sits on **Writing…** and goes no further | It picks up again by itself. If it doesn't, press **Stop**, then **Try again**: that's quick, because the AI keeps what it already read |
| **⚠️ Power too weak**, the AI takes minutes, or the Pi keeps restarting | The Pi isn't getting enough power. See [below](#power-too-weak-or-the-ai-takes-minutes) |
| The meter stays dark | Its thin red wire must go to the microswitch's **COM** and **NO** (not NC) |
| The fan never runs | It only runs when the Pi is hot (above 60 °C). Check the blue wire is on pin 8 |
| A setting I changed was gone | That's normal: see [Changing a setting later](#changing-a-setting-later) |
| Printer: *No printer found* | Check its USB cable is in the Pi. Close the print window and open it again |
| Printer: *not allowed to use the printer* | Finish the card again and let it set itself up again |
| Printer feeds blank paper | Turn the paper roll over |
| Print is faint or stops | The battery is low. Charge it |
| Forgot the Wi-Fi password | Plug the library drive into any computer and open **`PI-WIFI-CARD.html`** |
| No phone at all | Plug a TV (micro-HDMI) and keyboard into the Pi, log in (user **ark**, the Wi-Fi password), and run **SETUP-Raspberry-Pi.sh** with `--screen` (make the card writable first: see [Changing a setting later](#changing-a-setting-later)). This needs the desktop version of Raspberry Pi OS, not Lite |
| Want home internet on the Pi (for updates) | Plug in a network cable |
| The lid won't shut since adding the mesh radio | Something is under it. Move the wall charger's cord and plug toward the latch end, and take the antenna off |
| The mesh radio's screen stays dark | Check its USB cable at both ends. It only has power while the switch is on |

### "Power too weak", or the AI takes minutes

The Pi isn't getting a full 5 volts. It can then slow itself down to about a third of its speed, and
the AI suffers most: an answer can take 10 minutes instead of one or two. Weak power can also make the
Pi or its drive misbehave, so fix it even if the AI seems fine.

**Quick test:** switch off, unplug the Pi's power plugs from pins 2 and 14, and run the Pi from an
**official Raspberry Pi USB-C power supply** instead (never both at once). If the warning goes away,
the can's power wiring is the problem.

To see what the Pi is doing, open **More → Vault system status** on the phone, while the AI is
answering. It shows the power, the temperature and how fast the processor is running.

1. **Check the battery:** hold the meter button. Under about 12.5 V, charge it.
2. **Check the converter:** ask the AI a question, and **while it's working**, touch a multimeter to
   the converter's two **output** screws. It should read **5.1 to 5.25 V**. Lower than that? If the
   converter has a small adjusting screw, turn it up to about 5.2 V; if not, replace it.
3. **Check the wires to the Pi:** if the converter reads fine, the power is lost on the way to the
   Pi. The usual weak spot is the two little plugs on **pins 2 and 14** and the joints to them: the
   18 AWG must be **soldered** to the jumper leads' short wires, not crimped into the plugs (see
   [Wiring](#7-wiring)). Redo any joint that wiggles, and keep the wires as short as the route allows.
4. **Switch off and on again** so the old warning clears, and ask the same question. A healthy Pi
   should start writing within a minute or two.

<p class="part">Look inside</p>

## 🧰 The idea
<!-- fold: What's inside the can, what stays outside, and when it's sealed -->

**Inside the can:**
- the **Raspberry Pi** stuck under the **lid**, with the **library drive** (a small thumb drive)
  plugged in
- the **battery**
- the **wall charger**, and a **solar charge controller** stored for later (not wired)
- a printed stand (the **riser**) holding the **printer**, the **power switch** and the **battery
  meter**
- a **crank radio** and an **old phone**, about half charged
- *optional:* a **mesh radio** under the lid beside the Pi, for texting with no cell service, with
  its antenna, and a **pocket mesh radio** taped to a **second phone**, packed beside the battery (see
  [The mesh radio](#the-mesh-radio-optional))
- a card with the Wi-Fi name and password, and a spare roll of **foil tape**

**Outside the can:** the **solar panel**, with **nothing plugged into it**. Panels survive a pulse
fine ([Sandia, p. 39](lib:hemp-testing-of-photovoltaic-modules#page=39)); the danger is a pulse
running down the wires into whatever they're plugged into ([EMP guide](guide:EMP-GUIDE)). So the
charge controller waits inside the can, and you wire it up only after an event. **Never connect a
panel straight to the battery.**

| | What you do |
|---|---|
| **Stored** (most of the time) | Lid shut and taped, switch off, panel outside |
| **In use** | Open the lid, flip the switch on, take out the phone. (Mesh radio fitted? Screw its antenna on first) |
| **Charging** | Lid open, wall charger plugged in (or, after an event, the solar panel) |
| **Back to storage** | Switch off, unplug, put the phone back, close and tape the lid |

## 🧊 See it in 3D

Turn it with a finger, and pick **Closed**, **See-through** or **Lid open**. **Parts and views** hides or shows each part, lifts out the printer riser and shows the Pi close up. Every wire is in it too.

<iframe src="AMMO-CAN-MODEL.html?embed" title="The ARK Vault in 3D" loading="lazy" style="display:block;width:100%;height:440px;border:0;border-radius:12px;background:transparent"></iframe>

[Open the 3D model full size](guide:AMMO-CAN-MODEL)

![Two views of the ARK Vault from its 3D model. Left: the lid swung right over past the hinge, with the Raspberry Pi lying face-up on it just beyond the can's end and the small mesh radio beside it, the meter and power switch on the riser at the hinge end, and the battery at the latch end. Right: see-through, with the printer on its riser at the hinge end, the radio and the phone along the front wall, the battery along the back at the latch end, and the wall charger on the solar controller in front of it, with the mesh antenna standing in the latch-end corner](img:AMMO-CAN-COMPUTER-GUIDE/the-build.png)
*Lid open (left) and see-through (right).*

## 🧭 How it works
<!-- fold: Why it's sealed, and what the switch, the meter and the phone do -->

- **Lid shut and taped:** the steel can acts as a shield (a Faraday cage) and keeps an EMP out.
  Nothing is switched on.
- **Lid open, switch on:** the Pi starts in 2–3 minutes and makes its own Wi-Fi. Phones join it and
  use the library. An EMP lasts only seconds, and solar storms come with hours of warning, so having
  it open is fine the rest of the time.
- **Why not run it sealed?** It would overheat, phones couldn't reach it, and any wire or hole
  through the can ruins the shield
  ([🖼️ right and wrong ways through a shield](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)).
- **The power switch** just cuts the power. That's safe because the Pi is set to **read-only**: it
  never writes anything that could be left half-done. (The catch: a setting changed on the running
  Pi is forgotten. See [Changing a setting later](#changing-a-setting-later).)
- **The meter** stays dark. **Hold the little red button** and it shows the battery's **volts**
  (top) and the **amps** being used (bottom).
- **The phone is the screen.** Several phones can use it at once. The AI answers one person at a
  time, in about a minute.

<p class="part">Build one</p>

## 🛒 What to buy
<!-- fold: Every part, with its size and the model used here -->

| Part | What to get |
|---|---|
| **The can** | A **steel .50 cal ammo can** (inside about 11 × 5½ in, 7 in deep). Not plastic |
| **Battery** | **12.8 V LiFePO4**, **20 Ah** (about 182 × 77 × 170 mm), with **rubber boots** for its terminals |
| **Computer** | **Raspberry Pi 4** (4 GB or more) or **Raspberry Pi 5** (8 GB). A Pi 5 runs a bigger AI |
| **Cooler** | A low heatsink with a fan, no taller than 16 mm (the model has a **GeeekPi Armor Lite**) |
| **Pi's memory card** | A small **microSD card**, 32 GB or more. Holds only the Pi's system |
| **Library drive** | A **small USB 3 thumb drive**, **256 GB or more**, sticking out no more than ¾ in (19 mm) |
| **Pi power** | A **12 V to 5 V, 5 A step-down converter** (the model has a **TOBSUN EA25-5V**, and the riser is shaped for it), about 60 cm each of **18 AWG** red and black wire, and two **female jumper leads** (a short wire with a little female plug on its end) for the Pi's pins |
| **Switch, meter, fuse** | A **rocker switch** (21 × 15 mm), a **DC volt/amp meter** (48 × 29 mm, 100 V 10 A kind), a small **microswitch** (20 × 10 mm, lever removed) for the meter button, an **inline blade fuse holder** with a **7.5 A** fuse |
| **Wire** | About 1.5 m each of **16 AWG** red and black (the 12 V power); about 30 cm each of **22 AWG** red and yellow (the meter's thin wires); **ring terminals** for the battery's bolts, **blue female spades** (16–14 AWG) for the power switch, **butt splices**, **heat-shrink**. For the solar controller later: about 1 m each of **12 AWG** red and black, and a **20 A** inline fuse |
| **Inserts and screws** | Brass **heat-set inserts**: 4 × **M2.5** (3.5 mm across, 4 mm long) and 2 × **M3** (4.6 mm across, 5.6 mm long, sold as "M3 × 5.7 × 4.6"; the fatter M3s in most mixed kits don't fit these holes). **Socket-head screws:** 4 × M2.5 × 6 mm with 2 washers, 2 × M2.5 × 8 mm, 2 × M3 × 6 mm, 2 × M2 × 8 mm (microswitch). A mixed kit of each covers them. Also a **soldering iron** for the inserts, zip ties, and strong **double-sided foam tape** (VHB) |
| **Printer** (optional) | **DFRobot DFR0503 V2.0**, the **USB** one (runs on 9–24 V), and **57 × 30 mm** thermal paper rolls. Not the older serial-only DFR0503: it takes 5–9 V, and 12 V would ruin it |
| **Radio** | A small **crank radio**, about 128 × 60 × 46 mm or smaller |
| **Wall charger** | A **12 V LiFePO4 charger**, about 2 A (the model has a **MOTOPOWER MP00207A**) |
| **Solar, for later** | **Victron BlueSolar MPPT 75/15**, a **20 A fuse**, and a 12 V panel (50–100 W) |
| **Seal** | **Foil tape with conductive glue** (copper or aluminum), 2 in wide |
| **Screen** | An **old phone** and its charging cable. No SIM card or plan needed |
| **Mesh radio** (optional) | **Heltec WiFi LoRa 32 V4**, **915 MHz**, with its screen and with the pin strips **not** soldered on; a **915 MHz antenna** with its thin lead (most kits include both); a short **USB-A to USB-C cable** (30 cm / 1 ft). Its two M3 inserts and screws are in the list above |
| **Pocket mesh radio** (optional) | **SenseCAP T1000-E**, and a **second old phone** to carry with it |
| **For setup** | Your regular computer, a **memory-card reader**, a **multimeter**, and a USB-C power supply (5 V, 3 A) for testing |

## 📐 The parts to print and etch
<!-- fold: Four printed parts, and the bare strips for the tape -->

**[⬇️ Download the parts (ark-can-parts.zip)](https://theofflineark.com/download/ark-can-parts.zip)**. It has every
measurement and the wiring in one file (**READ-ME-FIRST.txt**), and the whole Vault to scale as a
Rhino file (**ARK-Vault-assembly.3dm**).

- **printed/**: four parts to 3D-print in **ABS**, **no supports**, **3 walls** (0.4 mm nozzle):
  - the **printer riser**: a stand that holds the printer, switch and meter, and the converter on
    the inside of its leg (two M2.5 inserts)
  - the **wall cleat**: a small strip the riser hooks onto
  - the **Pi's base**: a thin plate that sticks under the lid, with four posts (two take M2.5
    inserts, two take long screws from underneath)
  - the **mesh radio's base** (only if you add the mesh radio): a thin plate with two rails and a
    tab for the antenna's socket (two M3 inserts). It also sticks under the lid

  ![The four printed parts as they sit on the printer's bed: the riser upside down with its deck on the bed and its one leg standing up, the Pi's base flat with its four posts up, the mesh radio's base flat with its two rails and its tab up, and the wall cleat flat](img:AMMO-CAN-COMPUTER-GUIDE/printed-parts.png)
  *The parts as they print.*

- **laser/**: the **ARK Vault logo**, and **bare-metal strips** around the lid seam for the foil
  tape. No laser? Scrape the paint off the same strips by hand.

![The ammo can after etching: the ARK Vault logo on a long side, and two bare-metal strips along the lid seam, the same on both long sides, with foil tape over the closed seam](img:AMMO-CAN-COMPUTER-GUIDE/can-plan.png)
*The long sides (both the same).*

![The two ends after etching: on each end a bare band at the same height as the lower strip on the long sides, on the hinge plate under the hinge at one end and around the latch at the other; taped, one band of foil tape runs right round the can, over the hinge and over the closed latch](img:AMMO-CAN-COMPUTER-GUIDE/can-plan-ends.png)
*The ends: one band of tape goes right round the can, over the hinge and the latch.*

## 🔧 Build it, step by step

![The ammo can seen from above with its lid swung open, and where everything goes: the battery at the latch end against the back wall, the wall charger lying on the solar controller in front of it, the printer riser at the hinge end with the printer on top and the meter, switch and button in its front strip, the radio and the phone along the front wall, and on the open lid the Raspberry Pi and the mesh radio](img:AMMO-CAN-COMPUTER-GUIDE/where-things-go.png)
*Where everything goes. The steps say **hinge end**, **latch end**, **front** and **back** as in this picture.*

Tap a step to open it. The [3D model](#see-it-in-3d) shows each part from any side.

### 1. Get the can ready
<!-- fold: Bare metal round the lid's seam, and nothing bare inside -->

1. **Bare metal around the seam:** etch or scrape the paint off a strip on the lid's edge and one on
   the body just below it, all the way round (see the pictures above). The foil tape sticks here,
   metal to metal.
2. **Cover every bare wire end and bolt** (rubber boots, heat-shrink or tape) so nothing metal
   touches the can.

### 2. Fit the inserts
<!-- fold: Six brass inserts, melted into the printed parts with a soldering iron -->

The screws go into brass **heat-set inserts**, melted into the printed parts with a soldering iron,
so they can go in and out many times. Every insert hole has a small **bevel** at its mouth to start
the insert straight.

| Part | Where | Insert |
|---|---|---|
| Printer riser | the two holes in the raised frame inside the leg (under the converter's ears) | 2 × **M2.5** |
| Pi's base | the two posts with a **blind** hole (the other two have a hole right through) | 2 × **M2.5** |
| Mesh radio's base | the two round posts at the USB end | 2 × **M3** |

1. Heat the iron to about **230 °C** (ABS). A pointed or conical tip works; an insert tip is better.
2. Set the insert on the hole's bevel, **small end down**, standing straight.
3. Rest the iron's tip in the insert and let it sink in under its own weight with light pressure.
   Keep it straight. Stop when it is **flush** with the surface.
4. Lift the iron away and, while the plastic is still soft, press the insert flat with something
   cool and flat (the side of a screwdriver). Let it cool for a minute.

![Fitting a heat-set insert in four pictures: 1, the soldering iron at 230 °C; 2, the insert standing on the hole's bevel, small end down; 3, the iron's tip in the insert, which sinks in straight until it is flush; 4, the insert pressed flat with the side of a screwdriver while the plastic is soft](img:AMMO-CAN-COMPUTER-GUIDE/fit-insert.svg)

### 3. The battery
<!-- fold: At the latch end, against the back wall -->

Stand it at the **latch end**, against the **back** wall, terminals toward the back. Bolt on the
main **+** and **−** leads and the wall charger's leads, then push the **rubber boots** over both
terminals.

### 4. The chargers
<!-- fold: The solar controller on its edge, the wall charger on top -->

In front of the battery: stand the **solar controller** on its long edge, terminals toward the hinge
end (stored, not wired). Lay the **wall charger** flat on top, with its cord coiled on top of it.

### 5. The printer riser
<!-- fold: Meter, switch, button, converter and fuse on the riser; the printer on top -->

1. Snap the **meter** and **power switch** into their holes in the riser's front strip. Screw the
   **microswitch** into its slot, button up (2 × M2).
2. On the inside of the riser's **leg**: set the **converter** on the raised frame, **terminals
   toward the front**, its two ears over the two inserts. Put an **M2.5 × 6 mm** screw with a washer
   through each ear. (The ears' holes are a little bigger than the screws, so there's room to line
   them up.) Stick the **fuse holder** across the leg below it, about 1 cm up from the bottom.
3. Drop the **printer** into the top.
4. Stick the **wall cleat** inside the can's **hinge-end wall**, thick edge up, its top corners about
   **29 mm (1⅛ in) below the rim** and about 6 mm from the back wall.
5. Wire it (step 7), then lower the riser into the **hinge end**: its leg stands beside the battery
   and its other end hooks onto the cleat. It lifts straight out for repairs.

![The printer riser lifted out of the can: the printer on top; in the front strip the volt/amp meter, the red power switch and the meter button; on the inside of the leg the 5 V converter and, low down, the fuse holder; the wall cleat stays on the can's hinge-end wall](img:AMMO-CAN-COMPUTER-GUIDE/the-riser.png)
*The riser lifted out, with everything it holds.*

### 6. The Pi on the lid
<!-- fold: The cooler on the Pi, the Pi on its base, the base under the lid -->

1. Put the **cooler**'s thermal pads on and set the cooler on the Pi, but **leave its two little
   screws out**: longer ones take their place. Plug its fan onto **pins 4, 6 and 8** (red, black,
   blue).
2. Set the Pi, cooler up, on its printed **base**: the two posts with a hole right through go under
   the cooler's two screw holes (diagonal corners).
3. Turn the stack over. From the base's flat side, put an **M2.5 × 8 mm** screw through each of
   those two holes, through the Pi, into the cooler. Their heads sink into the base. Snug, not tight:
   these two hold the cooler on the Pi and the Pi on the base.
4. Turn it back. Put an **M2.5 × 6 mm** screw from the top into each of the other two posts (their
   inserts). If the one at the memory-card end is hard to reach under the cooler's edge, leave it
   out: three screws are plenty.
5. Stick the base under the **lid** at the **hinge end**, **USB ports toward the front**, about
   **13 mm** in from the hinge wall and **9 mm** in from the back wall.
6. Plug the **library drive** into a **blue** USB port and the printer's cable into a black one.

![The underside of the open lid: the Raspberry Pi on its printed base at the hinge end, USB ports toward the front, about 13 mm from the hinge wall and 9 mm from the back wall, with the library drive in a blue port; the mesh radio in its own base beside it on the latch side](img:AMMO-CAN-COMPUTER-GUIDE/under-the-lid.png)
*Under the lid: the Pi, and the mesh radio beside it.*

### 7. Wiring
<!-- fold: Every wire, with its size, and the wiring diagram -->

[![The ARK Vault wiring, every part drawn as it looks with all of its terminals. The battery from above, its plus and minus bolts also taking the wall charger's leads. Plus: battery, run 1 to the inline fuse holder (7.5 A), run 2 to the rocker switch's input pin, whose one spade also takes the meter's thin yellow wire (run 11) and the microswitch's NO tab (run 13); the switch's output pin, run 3, to a splice, then run 4 to the converter's Input plus and run 5 to the printer's power plug. Minus: battery, run 6 to the meter's thick black wire, where the meter's thin black wire (run 10) joins; the meter's thick red wire, run 7, to a splice, then run 8 to the converter's Input minus and run 9 to the printer. The meter's thin red wire, run 12, to the microswitch's C tab; its NC tab not used. The converter's four screw terminals as printed: Input plus, Input minus, Output minus, Output plus; Output plus to the Pi's pin 2 and Output minus to pin 14 (runs 14 and 15, 18 AWG). The printer's sockets: power, USB (to a black Pi USB port, run 17), TTL serial and 485 not used. The Raspberry Pi 4 from above with every port: the library drive in the lower blue USB port, the mesh radio in the upper blue one (run 18), the fan on pins 4, 6 and 8 (run 16); USB-C power, HDMI and audio not used. The 40 pins enlarged, every pin named. Later, the solar controller's terminals](img:AMMO-CAN-COMPUTER-GUIDE/wiring.svg)](img:AMMO-CAN-COMPUTER-GUIDE/wiring.svg)
*Every part with all of its terminals, and each wire's size. **Tap the picture** to open it full size and zoom in. The 3D model shows where each wire runs.*

**Every run, with its wire.** Lengths include some spare; cut to fit as you go.

| # | From | To | Wire | About |
|---|---|---|---|---|
| 1 | Battery **+** | Fuse holder (either end) | **16 AWG** red | 30 cm |
| 2 | Fuse holder (other end) | Power switch, **input** terminal | **16 AWG** red | 30 cm |
| 3 | Power switch, **output** terminal | a splice | **16 AWG** red | 10 cm |
| 4 | that splice | Converter **IN +** | **16 AWG** red | 12 cm |
| 5 | that splice | Printer **+** (its power lead) | **16 AWG** red | 8 cm |
| 6 | Battery **−** | Meter, **thick black** wire | **16 AWG** black | 40 cm |
| 7 | Meter, **thick red** wire | a splice | the meter's own wire | |
| 8 | that splice | Converter **IN −** | **16 AWG** black | 10 cm |
| 9 | that splice | Printer **−** | **16 AWG** black | 10 cm |
| 10 | Meter, **thin black** | the joint of runs 6 and the thick black (battery − side) | the meter's own, or **22 AWG** | |
| 11 | Meter, **thin yellow** | Power switch, **input** terminal | **22 AWG** yellow | 10 cm |
| 12 | Meter, **thin red** | Microswitch **COM** | **22 AWG** red | 10 cm |
| 13 | Microswitch **NO** | Power switch, **input** terminal | **22 AWG** red | 10 cm |
| 14 | Converter **OUT +** | Pi **pin 2** | **18 AWG** red, then a female jumper lead | 60 cm |
| 15 | Converter **OUT −** | Pi **pin 14** | **18 AWG** black, then a female jumper lead | 60 cm |
| 16 | Cooler fan | Pi pins **4** (red), **6** (black), **8** (blue) | its own lead | |
| 17 | Printer | a **black** Pi USB port | the printer's USB cable | |
| 18 | Mesh radio (if fitted) | the **upper blue** Pi USB port | USB-A to USB-C cable | 30 cm |

- **Why these sizes:** everything on 12 V draws at most about **4.5 A** (the Pi through the
  converter, plus the printer while it prints), so **16 AWG** runs cool and the **7.5 A** fuse
  protects it. The Pi's **5 V** pair carries up to **3 A**: **18 AWG** keeps the voltage up over its
  length. The meter's thin wires carry almost nothing, so **22 AWG** is plenty.
- **Ends:** **ring terminals** on the battery's bolts. **Blue female spades** on the power switch: its
  **input** terminal takes three wires (runs 2, 11 and 13), so crimp them into one spade together,
  or use a piggyback spade. **Butt splices** (crimped) or solder at the two splices. Cover every
  joint with heat-shrink, so nothing bare can touch the can.
- **The Pi's two plugs:** 18 AWG is too thick for the little pin plugs. Run the 18 AWG most of the
  way, and **solder** it to a female jumper lead's short wire about 5 cm from the Pi, with heat-shrink
  over each joint.
- **Check your meter's own wiring sheet:** some put the thick wires the other way round.
- **Before plugging runs 14 and 15 onto the Pi**, switch on and check them with a multimeter:
  > ⚠️ It must read **5.0 to 5.25 V**, with + and − the right way round. A mistake here can kill the
  > Pi.
- **Route:** run the Pi's power pair and the printer cable together along the front wall to the
  hinge corner, and up into the lid. Leave a loop of about **6 cm (2½ in)** so the lid opens freely.
  Tie the short wire from battery + to the fuse down, away from sharp edges.

![The Raspberry Pi pins the ARK Vault uses, at the end of the 40-pin row farthest from the USB ports, all on the row along the board's edge: pin 2 (5 volts) takes the converter's plus wire, pins 4, 6 and 8 take the cooler fan's red, black and blue wires (5 volts, ground, GPIO 14), and pin 14 (ground) takes the converter's minus wire](img:AMMO-CAN-COMPUTER-GUIDE/pi-pins-ark.svg)
*All five wires go on the outer row. Pin 2 is the corner pin farthest from the USB ports.*

**Pi 5:** its cooler plugs into its own fan socket instead; the power still goes on pins 2 and 14.

### 8. The rest
<!-- fold: The radio, the phone, and the spare parts -->

- The **radio** stands on the floor in front of the riser, and the **phone** stands on its end
  against the front wall beside it.
- *If you add them:* tape the **pocket mesh radio** to the back of the **second phone**, clear of
  the camera. The pair lies on its long edge in the slot between the solar controller and the
  battery, screen toward the controller (lift the wall charger to reach it). The mesh radio's
  **antenna**, folded at its joint, stands in the corner between the battery and the latch end.
  These are packed for storage and come out after an event.
- Keep loose metal off the can's walls
  ([CISA, p. 45](lib:emp-protection-and-resilience-guidelines#page=45)).

### 9. The mesh radio (optional)
<!-- fold: The board in its base, beside the Pi -->

> ⚠️ This part is new and has **not been built or tried yet**. Check the printed base against
> your own board before you stick it down.

1. **Leave the pin strips off** the board. With pins soldered on, it won't slide into its base.
2. **Slide the board into the base** from its USB end, screen up, until it stops. Put an
   **M3 × 6 mm** screw into the insert in each post at the USB end: its head rests on the board's
   corner and holds it in.
3. **The antenna's socket:** push the screw-on socket of the thin lead through the hole in the
   tab, and tighten its nut on the outside. Clip the lead's small end onto the board's antenna
   end. Tuck the spare loop flat.
4. **Stick the base under the lid beside the Pi**, on the latch side: about **5 mm** from the Pi's
   base, the antenna end about **10 mm** in from the front wall, the USB end toward the back.
5. **Plug it into the Pi:** the short USB cable goes from the board to the **blue** USB port above
   the library drive. Run it along the lid between the Pi and the base, and tape the slack flat.
6. Keep the wall charger's **coiled cord and plug toward the latch end**, so nothing sits under
   the radio when the lid shuts.

## 💾 Set up the Pi (no TV or keyboard)
<!-- fold: The Pi's own card and the library drive, set up from your computer -->

The library installer prepares the Pi's memory card, and the Pi **sets itself up** the first time
it starts.

### Two separate pieces: the Pi's card and the library drive

![The Raspberry Pi seen from the side: a small memory card in the card slot underneath holds the Pi's own system; the library drive, a USB stick, a small SSD or a big microSD card in a USB card reader, plugs into a blue USB port](img:AMMO-CAN-COMPUTER-GUIDE/two-pieces.svg)

| | **The Pi's memory card** | **The library drive** |
|---|---|---|
| What it holds | Only the Pi's own system | The whole library and the AI |
| What it is | A small microSD card (32 GB+) | A USB thumb drive (256 GB+) |
| Where it goes | The card slot under the Pi | A blue USB port |

Outside the Vault, the library drive can also be a small SSD, or a big microSD card in a USB card
reader. It just can't share the Pi's own card slot.

> ⚠️ **Never point Raspberry Pi Imager at the library drive.** It erases whatever it writes to.
> Check the size before you write: about 32 GB is the Pi's card; 256 GB is the library.

### The steps

![Setting up the Pi in four steps: 1, fill the library drive with the installer kit on your computer; 2, write the Pi's small card with Raspberry Pi Imager (Raspberry Pi OS Lite, 64-bit); 3, finish the card with the installer and write down the Wi-Fi name and password; 4, the card in the Pi, the drive in a blue port, switch on: the green light flickers for 5 to 10 minutes, then the Wi-Fi appears](img:AMMO-CAN-COMPUTER-GUIDE/setup-steps.svg)

1. **Fill the library drive** with the installer kit, like any library drive:
   **[⬇️ Download the installer kit (ark-illinois-valley-kit.zip)](https://theofflineark.com/download/ark-illinois-valley-kit.zip)**
   (see [Get the whole library](guide:GET-THE-LIBRARY)). Keep **Offline AI** and **Works on every
   kind of device** ticked.
   *Want maps beyond the local area?* With the drive still in your computer, start the library and use
   **More → Offline & downloads → Detailed offline map** (see [Offline maps](guide:HOW-TO-VIEW-MAPS)).
2. **Write the Pi's own small card** with **Raspberry Pi Imager** (free, from raspberrypi.com).
   Unplug the library drive first.
   - Device: your Pi. Operating system: **Raspberry Pi OS (other)** → **Raspberry Pi OS Lite
     (64-bit)**. Storage: the **small** card.
   - When it asks about **customisation**, choose **No**.
   - When it's done, take the card out and put it back in.
3. **Finish the card:** start the installer again and press **Finish a Raspberry Pi memory card**.
   Pick the card (called **bootfs**), keep **It's in the ARK ammo can** ticked, and press **Finish the
   memory card**. **Write down the Wi-Fi name and password** it shows.
4. **Put the card in the Pi** and plug the **library drive** into a **blue** USB port.
5. **Switch on.** The green light **flickers like a heartbeat** while it sets itself up (5–10
   minutes), then it restarts. A few minutes later its Wi-Fi appears.

It also saves **`PI-WIFI-CARD.html`** on the library drive with the Wi-Fi details. Print it and tape
it inside the lid.

**If the green light keeps blinking fast,** it got stuck. Switch off, put the card in your computer
and open **ark → setup-log.txt** to see why (usually the library drive wasn't plugged in). Fix it and
switch on again.

**Updating later, or moving to a Pi 5:** run the installer on the library drive again, then finish
the Pi's card again (step 3) and switch on.

### Changing a setting later

The Pi forgets changes made while it runs (that's what makes switching off safe).
- **To change the Wi-Fi name or password:** finish the card again (step 3) with the new ones.
- **Anything else** needs a screen and keyboard: log in (user **ark**, password = the Wi-Fi
  password), type `bash /mnt/emergency-library/OfflineLibrary/SETUP-Raspberry-Pi.sh --writable`,
  restart, make the change, then run the same line **without** `--writable` to lock it again.

### Test it

1. Flip the switch on and wait **2–3 minutes**.
2. On the phone, join the Pi's Wi-Fi (**Emergency-Library** unless you changed it). If it says *no
   internet*, tap **Stay connected**.
3. In the browser (Safari on an iPhone), type **`http://192.168.4.1:8096`**. Add it to the home
   screen.
4. Search, open a guide, ask the AI, print something, and hold the meter button.
5. Switch off. Then do it all again with your home internet off.

## 🖐️ Other ways to build it
<!-- fold: With a touchscreen, or a Pi on a shelf -->

- **With a touchscreen** (for a bigger box): use the desktop version of **Raspberry Pi OS (64-bit)**,
  not Lite, and tick **touchscreen** when you finish the card.
- **No power switch** (a Pi on a shelf): untick **It's in the ARK ammo can** when you finish the card,
  and power it with a normal USB-C supply. Shut it down before unplugging: a **Pi 5** has a power
  button; on a **Pi 4**, add a push button on **pins 5 and 6**.

![A Raspberry Pi 4 seen from above, with the USB ports at the right end; the push button's two wires go onto the third pair of pins counted from the left end of the 40-pin row, pins 5 and 6](img:AMMO-CAN-COMPUTER-GUIDE/pi4-power-button-pins.svg)
*A push button on pins 5 and 6 shuts a Pi 4 down safely.*

---

## 🖼️ Pictures & diagrams

- The Raspberry Pi itself — [Raspberry Pi](wiki:Raspberry_Pi)
- Steel ammunition cans — [Ammunition box](wiki:Ammunition_box)
- How a closed metal box blocks a pulse — [Faraday cage](wiki:Faraday_cage); [Electromagnetic shielding](wiki:Electromagnetic_shielding)
- Why a wire through the box ruins it — [🖼️ MIL-HDBK-419A Vol 2, p. 315](lib:mil-hdbk-419a-grounding-bonding-and-shielding-vol-2#page=315)
