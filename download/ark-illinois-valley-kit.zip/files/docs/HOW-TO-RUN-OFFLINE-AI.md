# 🤖 How to Run the Offline AI

The library comes with an AI that runs on the computer itself. It needs **no internet**, and
nothing you type leaves the computer.

> ### ⭐ Easiest: use the Library Assistant
> Double-click **START-Windows**, **START-Mac** or **START-Linux.sh** in the **OfflineLibrary**
> folder (other devices: see [Start on Any Device](guide:START-ON-ANY-DEVICE)). Type a question.
> It searches every book, guide and encyclopedia on the drive, and the AI writes an answer with
> links to the exact pages.
>
> - It picks the right AI size for your computer. To change it, open **More → Offline AI settings**.
> - Search results show up in a second. The written answer takes **30 seconds to a few minutes**.
> - **Search in** (under the question box) picks where it looks: **Guides**, **Books**, **Wikipedia**.
>   Guides alone gives short, plain answers from the library's own guides; on a phone it also skips
>   loading every book page, so the first answer comes much sooner. For a quicker written answer,
>   set **Sources** to 4: the AI then has less to read.
> - Keep the black window open while you use it.

**Most people can stop reading here.** The rest is for chatting with the AI on its own, without
the library search.

> ### ⚠️ Remember
> - **The AI can be wrong or make things up.** Check anything about health or safety in the books.
> - **It can't look anything up online.** Its knowledge stops when it was made.

---

## 💬 Just chat with the AI (Windows)

1. On the drive, open **OfflineLibrary → AI-Offline**.
2. Double-click **CHAT-3B-light**. A black window opens.
3. When it's ready, type a question and press **Enter**. Close the window to quit.

| Double-click | When to use it |
|---|---|
| **CHAT-3B-light** | Almost any computer. Fast |
| **CHAT-8B-smart** | Computers with 8 GB+ of memory. Smarter, slower |
| **CHAT-GPU-Qwen7B** | Gaming computers with a graphics card. Much faster |
| **WEB-UI** | Chat in your web browser: wait until it says **server listening**, then go to **http://127.0.0.1:8080** |

The **8B** and **GPU** ones are only on bigger drives (about 64 GB or more).

## 🍎🐧 Mac or Linux

Open a terminal in the **AI-Offline** folder (Mac: open **Terminal**, type `cd `, drag the folder
in, press Enter. Linux: right-click in the folder → **Open in Terminal**). Then type:

```
./chat-3B-light.sh
```

(or `./chat-8B-smart.sh`, or `./web-ui.sh` for the browser). If it says *permission denied*, type
`chmod +x *.sh` first. These files are only on drives made on a Mac or Linux computer.

---

## 🔧 If something goes wrong

| Problem | Fix |
|---|---|
| **Windows protected your PC** | Click **More info**, then **Run anyway** |
| The black window flashes and closes | A model file may be missing. Run the installer again to fetch it |
| *Out of memory*, or it crashes | Use **CHAT-3B-light** and close other programs |
| It's very slow | Normal on older computers. Use the **3B** one |
| The web page won't open | Check the **WEB-UI** window says **server listening**, and type exactly **http://127.0.0.1:8080** |

---

## 📋 For helpers: what's in the folder

- **Models** (in `AI-Offline\models`): Qwen 2.5 1.5B (Quick), Llama 3.2 3B (Standard),
  Llama 3.1 8B (Smart) and Qwen 2.5 7B (Graphics card). Free open-weight models.
- **Engine** (in `AI-Offline\engine`): llama.cpp, for Intel/AMD, ARM and graphics cards.
- **To copy the AI to another computer,** copy the whole **AI-Offline** folder. Nothing needs
  installing.
- **To run it by hand** (to see an error), in Command Prompt, with your drive letter:

  ```
  "E:\OfflineLibrary\AI-Offline\engine\x64\llama-cli.exe" -m "E:\OfflineLibrary\AI-Offline\models\Llama-3.2-3B-Instruct-Q4_K_M.gguf" -c 4096 -cnv
  ```
