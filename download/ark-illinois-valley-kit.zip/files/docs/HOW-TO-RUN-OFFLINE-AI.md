# 🤖 How to Run the Offline AI

The **AI-Offline** folder on the drive holds an AI that runs on the computer itself, from an old
laptop to a gaming PC. It needs **no internet**, and nothing you type leaves the computer.

> ### ⭐ Easiest: use the Library Assistant
> On a computer, double-click **START-Windows**, **START-Mac** or **START-Linux.sh** in the
> **OfflineLibrary** folder (Android and other devices: see
> [Start on Any Device](guide:START-ON-ANY-DEVICE)). Your web browser opens one page that
> **searches the whole library at once**: every PDF manual and guide, the Illinois Valley pack,
> the walking routes, **and** Wikipedia, WikiMed, iFixit, Appropedia and the survival archives.
> Then the AI writes an answer with numbered sources you can click to open the exact page.
>
> - **The AI size is picked for you:** **Quick** (Qwen 2.5 1.5B) on phones, tablets and older
>   laptops, **Standard** (Llama 3.2 3B) on most laptops. It times a test answer and steps down if
>   the device is too slow. To change it, use **⚙️ Settings**: **Off** (search only), **Quick**,
>   **Standard**, **Smart** (8B, about 3× slower) or **Graphics card** (Qwen 7B, 6 GB+ card only).
> - Search results appear in a second or two; the written answer takes **30 seconds to a few
>   minutes** without a graphics card. Untick **AI writes an answer** for search only.
> - Keep the black window open while you use it. Close it to stop.

**Most people can stop reading here.** The rest of this page is for chatting with the AI directly,
without the library search.

> ### ⚠️ Please remember
> - **The AI can be wrong or make things up.** Treat it as a knowledgeable helper, not an
>   authority. Check anything medical, electrical, legal or life-and-death against the books.
> - **Its knowledge is frozen** at the time it was trained. It can't look anything up online.

---

## 💬 Just chat with the AI (Windows)

1. On the drive, open **OfflineLibrary → AI-Offline**.
2. Double-click **CHAT-3B-light**. It works on almost any computer.
3. A black window opens. Wait a few seconds while the AI loads.
4. When it stops printing and waits for you, type a question and press **Enter**. Keep chatting.
5. To quit, close the window.

Other choices in the same folder:

| Double-click | When to use it |
|---|---|
| **CHAT-3B-light** | Almost any computer (about 4 GB of memory). Fast |
| **CHAT-8B-smart** | Computers with 8 GB+ of memory. Smarter, but slower |
| **CHAT-GPU-Qwen7B** | Computers with a graphics card that has 6 GB+ of its own memory. Much faster. If it says *out of memory*, use one of the two above instead |
| **WEB-UI** | To chat in your web browser instead. Wait until the window says **server listening**, then open **http://127.0.0.1:8080** in your browser (it's a page served by your own computer, not the internet) |

**CHAT-8B-smart** and **CHAT-GPU-Qwen7B** need the large AI models, which are only on drives where
the large AI was ticked (it's picked automatically on drives of about 64 GB or more).

---

## 🍎🐧 On a Mac or Linux

The chat shortcuts match the computer that **made** the drive: `.bat` files if it was made on
Windows, `.sh` files if it was made on a Mac or Linux. (The START file above works on every kind of
computer either way.)

If your **AI-Offline** folder has `.sh` files, open a terminal (a window where you type commands)
in that folder:

- **Mac:** open the **Terminal** app, type `cd ` (with a space after it), drag the **AI-Offline**
  folder into the window, and press Enter.
- **Linux:** right-click an empty spot in the **AI-Offline** folder → **Open in Terminal**.

Then type one of these and press Enter.

The fast, light AI:

```
./chat-3B-light.sh
```

The smarter AI (large models only):

```
./chat-8B-smart.sh
```

Chat in your web browser (then open **http://127.0.0.1:8080**):

```
./web-ui.sh
```

Linux only, with a graphics card (large models only):

```
./chat-GPU-Qwen7B.sh
```

If it says *permission denied*, type `chmod +x *.sh`, press Enter, and try again. On a Mac the AI
uses the Mac's graphics chip automatically. **Intel Macs** need macOS 13.3 or newer to run the AI.

---

## 🧠 Which model should I use?

Up to **four** AI models are in the `models` folder. The two small ones are on every drive with the
AI; the two large ones only where the large AI was ticked.

| Model | Size | Good for | Started by |
|---|---|---|---|
| Qwen 2.5 1.5B | 1.0 GB | Phones, tablets and old laptops. Quick, simple answers | Library Assistant: **Quick** |
| Llama 3.2 3B | 1.9 GB | Almost any computer (about 4 GB of memory) | **Standard**; **CHAT-3B-light** |
| Llama 3.1 8B *(large)* | 4.6 GB | About 8 GB of memory to chat (the Library Assistant wants 16 GB). Smarter, slower | **Smart**; **CHAT-8B-smart** |
| Qwen 2.5 7B *(large)* | 4.4 GB | A graphics card with about 6 GB of its own memory. Fastest there | **Graphics card**; **CHAT-GPU-Qwen7B** |

The small models need **no** graphics card. A slow computer only means slower answers; it still
works. If the graphics-card model won't fit your card, nothing breaks: use one of the others.

---

## 🔧 If something goes wrong

| What happens | What to do |
|---|---|
| **Windows protected your PC** | Click **More info**, then **Run anyway**. It appears because the files came from the internet |
| The black window flashes and closes | A model file may be missing or only partly downloaded: check the `models` folder against the sizes above. To see the error, run it by hand (*For helpers* below) |
| The graphics-card one says *out of memory* | Your graphics card is too small. Use **CHAT-3B-light** or **CHAT-8B-smart** instead |
| *Not enough memory*, or it crashes while loading | Use the **3B** model and close other programs (web browsers especially) |
| It's very slow | Normal on older computers, especially with 8B. Use the 3B model |
| The web page won't open | Check the **WEB-UI** window is still open and says **server listening**. Type exactly **http://127.0.0.1:8080** (not https) |

---

## 🛠️ For helpers: run it by hand

Useful if a shortcut fails, or to read an error. Press the **Windows key**, type `cmd` and press
Enter to open **Command Prompt**. Paste one of these, change `E:` to your drive's letter, and press
Enter.

Normal Intel/AMD computer:

```
"E:\OfflineLibrary\AI-Offline\engine\x64\llama-cli.exe" -m "E:\OfflineLibrary\AI-Offline\models\Llama-3.2-3B-Instruct-Q4_K_M.gguf" -c 4096 -cnv
```

ARM computer (Surface Pro X, Snapdragon laptop):

```
"E:\OfflineLibrary\AI-Offline\engine\arm64\llama-cli.exe" -m "E:\OfflineLibrary\AI-Offline\models\Llama-3.2-3B-Instruct-Q4_K_M.gguf" -c 4096 -cnv
```

With a graphics card (NVIDIA, AMD or Intel):

```
"E:\OfflineLibrary\AI-Offline\engine\vulkan-x64\llama-cli.exe" -m "E:\OfflineLibrary\AI-Offline\models\Qwen2.5-7B-Instruct-Q4_K_M.gguf" -c 4096 -ngl 99 -cnv
```

Browser chat by hand (then open **http://127.0.0.1:8080**):

```
"E:\OfflineLibrary\AI-Offline\engine\x64\llama-server.exe" -m "E:\OfflineLibrary\AI-Offline\models\Llama-3.2-3B-Instruct-Q4_K_M.gguf" -c 4096 --host 127.0.0.1 --port 8080
```

**What the options mean:**

- `-m "...gguf"`: which model file to load.
- `-c 4096`: how much of the conversation it remembers. Use `2048` if memory runs low.
- `-cnv`: chat mode (back-and-forth).
- `-ngl 99`: (graphics card only) how much of the model goes on the card; 99 means all. On an
  out-of-memory or device error, lower it (e.g. `-ngl 20`); to change the shortcut, edit the number
  in **CHAT-GPU-Qwen7B.bat** with Notepad.
- `-t 4`: (optional) use 4 processor cores; set it to your core count for best speed.

The engine picks the right processor build (`ggml-cpu-*.dll`) by itself.

---

## 📁 What's in the folder

```
OfflineLibrary\AI-Offline\
├─ Library-Assistant\    <- the search-everything assistant (started by the START files)
├─ CHAT-3B-light.bat     <- chat: small, fast model        (.sh versions on Mac/Linux-made drives)
├─ CHAT-8B-smart.bat     <- chat: bigger, smarter model
├─ CHAT-GPU-Qwen7B.bat   <- chat: on a graphics card (6 GB+)
├─ WEB-UI.bat            <- chat in your web browser
├─ engine\               <- the program that runs the AI (llama.cpp), one folder per kind of computer
├─ models\               <- the AI models themselves (.gguf files; see the table above)
├─ DocReader-GPT4All\    <- optional app that answers questions from your PDFs
└─ HOW-TO-RUN-OFFLINE-AI <- this guide
```

**To copy it to another computer,** copy the whole **AI-Offline** folder to a USB stick or drive.
Nothing needs installing. The 3B model and the engine alone fit on an 8 GB stick.

---

## 📋 Technical summary

- **Engine:** llama.cpp, the newest release when the drive was made. CPU builds (Windows x64 and
  ARM64, Mac, Linux) need no graphics card; the Vulkan build (`engine\vulkan-x64`) uses NVIDIA,
  AMD or Intel cards with no CUDA install.
- **Format:** GGUF, Q4_K_M (4-bit): small files, good quality.
- **Models:** Qwen 2.5 1.5B, Llama 3.2 3B, Llama 3.1 8B and Qwen 2.5 7B (all Instruct): free
  open-weight models from Meta and Alibaba. The `.gguf` files were made by the community
  (bartowski) from the official models.
- **Sources** (only needed to download them again):
  - Engine: https://github.com/ggml-org/llama.cpp/releases
  - 1.5B: https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF
  - 3B: https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF
  - 8B: https://huggingface.co/bartowski/Meta-Llama-3.1-8B-Instruct-GGUF
  - 7B: https://huggingface.co/bartowski/Qwen2.5-7B-Instruct-GGUF

This kit is designed to keep working when nothing else does.
