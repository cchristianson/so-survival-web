# 💊 Chronic Illness When the Pharmacy Is Empty

For anyone who lives on a daily medicine or device (insulin, heart pills, inhalers, seizure or thyroid
medicine, psychiatric medicines, oxygen, dialysis, glasses, hearing aids, dentures) when no pharmacy or
doctor is coming for months or years: stocking up now, what happens as each medicine runs out, the usual
doses the books give, what food and care can still do, the medicines that are dangerous to stop, and what
to do when someone can no longer be kept well. The books are in `Medical\Medicines` (WHO Model Formulary
and the one for children, MSF *Essential Drugs*, WHO essential medicines lists), `Medical\Manuals-PDF`
(MSF *Clinical Guidelines*, *Ship's Medicine Chest*, *Emergency War Surgery*, *Where There Is No
Dentist*), `Medical\Where There Is No Doctor` (WTND, whose green pages give uses and doses),
`Medical\Where Women Have No Doctor` (WWHND), `Medical\Field-Care` (*Hospital Corpsman*, WHO-ICRC
*Basic Emergency Care*), `Medical\Rehab-Physical-Therapy` (CDC STEADI) and
`Southern-Oregon\Community-Barter\Wellbeing`. Found and expired medicines:
[Medical books & found medicines](guide:Medical-READ-ME-FIRST).

> ### The short version
> - **Now, while you can:** ask your doctor and pharmacist for a bigger supply (aim for 90 days or
>   more *(rule of thumb)*), a written list, and a written plan for what to do if it runs out.
>   "Keep an emergency supply of important medicines on hand at all times"
>   ([WTND, p. 332](lib:where-there-is-no-doctor-23-the-medicine-kit#page=2)).
> - **Never stop these suddenly:** steroid pills, beta-blockers, seizure medicines, benzodiazepines
>   and some psychiatric medicines; heavy daily drinkers must not stop alcohol alone. Step them down
>   the way the table below shows.
> - **Opened insulin keeps at most 4 weeks below 25 °C (77 °F), out of the light. Never freeze it**
>   ([MSF, p. 426](lib:msf-essential-drugs#page=426)).
> - **Diabetic, acting drunk or confused, can't tell if sugar is high or low? Give sugar.**
>   "Brain damage develops very quickly" when it is low ([Hospital Corpsman, p. 207](lib:hospital-corpsman#page=207)).
> - **Seizure: put nothing in the mouth.** Move hard things away, time it; over 5 minutes is an
>   emergency ([MSF, p. 22](lib:msf-clinical-guidelines#page=22)).
> - **Food and habits still work:** less salt for blood pressure and heart failure, diet and hard work
>   for type 2 diabetes, clean air for asthma.
> - **Keep spare glasses, hearing-aid batteries and a clean denture**: they are work, talk and food.
> - **Some people cannot be kept well without what is gone.** Talk with them early and honestly, and
>   keep them comfortable.

> ### ⚠️ Before you give any dose
> - The doses here are **the usual doses printed in the library's medical books**, for when no doctor or
>   pharmacist can be reached. They are not a prescription. Where two books differ, both are shown.
> - **Be sure what the pill is first:** the label, or the Pill Identifier under Tools (on a drive:
>   `Medical\Pill-Identifier\PILL-IDENTIFIER.html`). Read the strength in mg on the label: the same
>   medicine comes in different strengths ([WTND, p. 60](lib:where-there-is-no-doctor-08-how-to-measure#page=2)).
> - **Start low and watch closely.** Doses are lower for the old, the small, and anyone with kidney or
>   liver disease ([WHO Formulary, pp. 16](lib:who-model-formulary-2008#page=16), [622](lib:who-model-formulary-2008#page=622)).
>   Children's doses go by weight (the *WHO Model Formulary for Children*, in `Medical\Medicines`). When a
>   book gives only the adult dose, WTND gives a child ½ of it at 8–13 years, ¼ at 4–7 years, ⅛ at 1–3 years
>   ([WTND, p. 62](lib:where-there-is-no-doctor-08-how-to-measure#page=4)).
> - **Check what the person must not take** (the last column of each table), pregnancy, and their other
>   medicines: the WHO formulary lists interactions in Appendix 1
>   ([p. 513](lib:who-model-formulary-2008#page=513)).
> - **Write down every dose given, the time, and what happened.**
> - **If anyone with training can be reached,** by radio or in person, ask them.

---

## 🚨 The first minutes

### Low blood sugar

Anyone on insulin or sugar pills, or a starving or very sick person, can go low fast.
**Signs:** hunger, tiredness, shaking, fast heartbeat, pale, sweating, anxious, blurred vision,
trouble speaking, confusion, convulsions, then coma. For someone with diabetes, low is under
"3.9 mmol/litre (< 70 mg/dl)" on a meter ([MSF, p. 32](lib:msf-clinical-guidelines#page=32)).
It is often mistaken for drunkenness ([Hospital Corpsman, p. 207](lib:hospital-corpsman#page=207)).

| Situation | What the books give |
|---|---|
| **Awake, can swallow: adult** | "15 to 20 g of sugar (3 or 4 cubes) or sugar water, fruit juice, soda, etc." ([MSF, p. 32](lib:msf-clinical-guidelines#page=32)). WHO: "glucose, 10–20 g", or "granulated sugar (2 teaspoons) or sugar lumps (3 lumps)", "repeated after 10–15 minutes" if needed ([WHO Formulary, p. 390](lib:who-model-formulary-2008#page=390)) |
| **Awake, can swallow: child** | "a teaspoon of powdered sugar in a few ml of water or 50 ml of fruit juice" ([MSF, p. 32](lib:msf-clinical-guidelines#page=32)) |
| **Can't swallow or unconscious** | Nothing to drink. Inside the cheek: "2–5 ml of 50% dextrose", or "1 level teaspoon of sugar moistened with water every 10–20 minutes" ([WHO-ICRC, p. 204](lib:who-icrc-basic-emergency-care#page=204)); MSF puts granulated sugar under the tongue ([p. 185](lib:msf-clinical-guidelines#page=185)). Lay them on their side |

- They should improve in about 15 minutes. Then give a starchy meal or snack and watch them for a few
  hours ([MSF, p. 32](lib:msf-clinical-guidelines#page=32)). A low caused by a sulfonylurea pill (glibenclamide
  and others) "may persist for many hours" ([WHO Formulary, p. 391](lib:who-model-formulary-2008#page=391)): keep feeding and watching.
- **High or low? If you can't tell, give sugar.** If they turn out to be high, "the extra sugar will
  do no appreciable harm" ([Hospital Corpsman, p. 207](lib:hospital-corpsman#page=207)).

### A seizure

**During it** ([MSF, p. 22](lib:msf-clinical-guidelines#page=22); [WTND, p. 178](lib:where-there-is-no-doctor-13-some-very-common#page=28)):
1. **Note the time.** Call for help.
2. Move hard and sharp things away; loosen tight clothing.
3. **Put nothing in the mouth**: "no food, drink, medicine, nor any object to prevent biting the tongue"
   (WTND).
4. When the jerking stops, roll them onto their side ([recovery position](wiki:Recovery_position)).
   Check for low sugar; if you can't measure it, give sugar once they can swallow.
5. Afterwards they are confused and sleepy, usually for 30–60 minutes. Let them rest.

![The recovery position: a person lying on the left side, the top leg bent forward, the head resting on the straight lower arm with the face turned down, and a helper kneeling behind steadying the hip](img:CHRONIC-ILLNESS-GUIDE/recovery-position.png)
*On the side once the jerking stops: top leg bent forward, head on the straight lower arm so the mouth drains ([WHO-ICRC, p. 190](lib:who-icrc-basic-emergency-care#page=190)).*

**Over 5 minutes, or a second seizure before they wake, is an emergency** ("status epilepticus"): the
longer it lasts, the harder it is to stop and the greater the risk of brain damage and death
([MSF, p. 22](lib:msf-clinical-guidelines#page=22)). The rescue medicine is **diazepam into the back
passage**: draw up the injection liquid in a syringe with the needle taken off, or grind a tablet into
water, and squirt it into the rectum ([WTND, p. 391](lib:where-there-is-no-doctor-24-green-pages#page=53));
lay them on their side and hold the buttocks together a minute ([MSF, p. 24](lib:msf-clinical-guidelines#page=24)).

| Diazepam in the rectum | Dose the books give | Repeat |
|---|---|---|
| WTND ([p. 391](lib:where-there-is-no-doctor-24-green-pages#page=53)) | "adults and children over 12 years: 5 to 10 mg"; "children 6 to 12 years: 3 to 5 mg"; "children under 6 years: 1 to 3 mg" | Once, if not controlled after 15 minutes. "Do not repeat more than once" |
| MSF ([pp. 23–25](lib:msf-clinical-guidelines#page=24)) | 12 years and over (40 kg and over): "2 to 4 ml" of the 5 mg/ml solution; 65 and over, "do not exceed 2 ml (= 10 mg) per dose". Children by weight in its Table 1 | Once more if still seizing after 5 minutes; "do not administer more than 2 doses" |
| WHO ([p. 83](lib:who-model-formulary-2008#page=83)) | "ADULT and CHILD over 10 kg, 500 micrograms/kg; ELDERLY, 250 micrograms/kg" | |

**Watch for:** "Too much diazepam can slow down or stop breathing" ([WTND, p. 391](lib:where-there-is-no-doctor-24-green-pages#page=53)).

### An asthma attack

Wheezing, the skin between the ribs sucking in, lips or nails turning blue
([WTND, p. 167](lib:where-there-is-no-doctor-13-some-very-common#page=17)):
1. Sit them half up. Get them out of smoke to the cleanest air. Stay calm and gentle.
2. **Rescue inhaler (salbutamol, also called albuterol)**, through a spacer if you have one. WTND: "For an
   emergency, use 2 to 4 puffs every 20 minutes" ([p. 385](lib:where-there-is-no-doctor-24-green-pages#page=47)).
   MSF: "2 to 10 puffs every 20 minutes during the first hour"; with a child, one puff at a time and 4 or
   5 breaths from the spacer before the next ([MSF, pp. 104–105](lib:msf-clinical-guidelines#page=105)).
3. Prednisolone tablets go with it (MSF gives them in every attack, WTND in a severe one): doses under
   Asthma and COPD, below.
4. Plenty to drink. With no medicine at all, **strong coffee or black tea** can help (WTND, p. 167).
   Can't finish a sentence in one breath: a severe attack. Drowsy or confused, exhausted, blue, or a
   silent chest: life-threatening ([MSF, p. 104](lib:msf-clinical-guidelines#page=104)).

### Chest pain

A crushing pain that does not go away with rest is probably a heart attack; in women it may feel like
indigestion, nausea, clammy skin or jaw pain. **Rest very quietly in a cool place**; stay in bed while
there is pain or shock, then move slowly and stay quiet for a month or more
([WTND, p. 325](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=3)). Severe chest pain or trouble
breathing can also be panic: help them stay calm, but treat it as an emergency
([WWHND, p. 420](lib:where-women-have-no-doctor-27-mental-health#page=9)).

| Medicine | Dose the books give | Don't use if |
|---|---|---|
| **Aspirin, chewed,** for a suspected heart attack | WHO: "150–300 mg by mouth (preferably chewed or dispersed in water) is given immediately" ([p. 299](lib:who-model-formulary-2008#page=299)). *Emergency War Surgery*: "Aspirin 81 mg PO, chewed as quickly as possible and daily thereafter" ([p. 168](lib:emergency-war-surgery#page=168)) | Allergic to aspirin (including asthma from it), under 16, active stomach ulcer, bleeding disorder ([WHO, p. 301](lib:who-model-formulary-2008#page=301)) |
| **Nitroglycerin** (glyceryl trinitrate) under the tongue, for angina | MSF: "0.5 to 1 mg sublingually, to be repeated 1 to 3 times at 3-4 minute intervals"; "Do not exceed 3 mg daily" ([MSF *Essential Drugs*, p. 157](lib:msf-essential-drugs#page=157)). WHO: "0.5–1 mg, repeated as required" ([p. 276](lib:who-model-formulary-2008#page=276)) | Low blood pressure or shock; anyone who took sildenafil or another erection drug ([MSF, p. 158](lib:msf-essential-drugs#page=158)) |

Pain that nitroglycerin does not ease is more likely a heart attack than angina
([Hospital Corpsman, p. 208](lib:hospital-corpsman#page=208)).

## 🗓️ Plan now, while the pharmacy is open
<!-- fold: What to ask the doctor, how much to stock, rotating it, and writing it all down -->

### Ask your doctor and pharmacist now

While there is still someone to ask, ask. Take these questions to the next visit *(rule of thumb)*:
- **"Can I have a 90-day supply, and early refills? How long does each medicine keep?"**
- **"Which of mine are dangerous to stop? If supplies end, how do I step down, and how fast?"** Get it
  **in writing**, in plain numbers, for this person's own medicines and doses.
- **"Is there an older, cheaper generic?"** Generics are often much cheaper and no worse
  ([WTND, p. 333](lib:where-there-is-no-doctor-23-the-medicine-kit#page=3)). The WHO essential list names
  the plain, widely made ones: amlodipine, bisoprolol and enalapril for blood pressure
  ([WHO EML 2025, p. 45](lib:who-model-list-of-essential-medicines-24th#page=45)); human insulin, gliclazide
  and metformin for diabetes ([p. 54](lib:who-model-list-of-essential-medicines-24th#page=54)). MSF chooses
  seizure medicine partly by how likely it is to stay available ([MSF, p. 384](lib:msf-clinical-guidelines#page=384)).
- **"What do I do if I get sick, can't eat, or work hard?"** Insulin needs change with all three (Diabetes,
  below); steroid needs rise with illness and injury ([WHO Formulary, p. 366](lib:who-model-formulary-2008#page=366)).
- **"What can I learn to do myself?"** Blood pressure, sugar tests, a spacer, rescue seizure medicine.

### Build a stock and keep it rotating

- Disaster lists are short: the Red Cross list for seniors says a 7-day supply of medications, and
  2 weeks of food and water at home ([Red Cross *Seniors*, p. 5](lib:disaster-preparedness-for-seniors#page=5)).
  For a long collapse, build toward **3 months and more** of every daily medicine *(rule of thumb)*.
- Put medicines and **glasses** in every kit ([FEMA *Are You Ready?*, p. 21](lib:fema-are-you-ready-citizen-preparedness-guide-2020#page=21)).
  Plan for medicines that need a fridge, and keep spare batteries, oxygen and catheters, with **the type and
  model number of every device** ([FEMA 2004, p. 30](lib:fema-are-you-ready-citizen-preparedness-guide-2004#page=30)).
- **Rotate:** new stock at the back, old in front, use the oldest first
  ([FEMA, p. 22](lib:fema-are-you-ready-citizen-preparedness-guide-2020#page=22)); every six months,
  replace expiring medicines and batteries ([Red Cross, p. 13](lib:disaster-preparedness-for-seniors#page=13)).
- Keep them labeled, with their directions, in a clean, dry, cool place away from children and rats
  ([WTND, p. 332](lib:where-there-is-no-doctor-23-the-medicine-kit#page=2)). Storage and old medicines:
  [Medical books & found medicines](guide:Medical-READ-ME-FIRST).
- **Oregon's lists:** *Be 2 Weeks Ready* adds extra eyeglasses, contact lens solution and hearing-aid
  batteries to the kit ([p. 22](lib:oregon-be-2-weeks-ready-complete-toolkit#page=22)). *Living on Shaky
  Ground* says to write down each person's needs, "Include medications and special equipment such as
  ventilators and oxygen tanks", and keep duplicate prescriptions and glasses where they can be reached
  ([p. 17](lib:living-on-shaky-ground#page=17)).

### Write it down

- **A card for each person:** illness, each medicine with its strength and times, allergies, the doctor.
  One copy with the medicines, one in the grab bag ([Red Cross, p. 5](lib:disaster-preparedness-for-seniors#page=5);
  [FEMA, p. 22](lib:fema-are-you-ready-citizen-preparedness-guide-2020#page=22)); picture cards for people
  who can't read ([📋 WTND dosage blanks](lib:where-there-is-no-doctor-29-dosage-blanks#page=1)).
- **Wear a medical ID** (bracelet or tag): rescuers look for one in any sudden illness
  ([Hospital Corpsman, p. 206](lib:hospital-corpsman#page=206); [Medical ID](wiki:Medical_identification_tag)).
- **Keep a log:** blood pressure, sugar, weight, seizures, pills left, every dose given *(rule of thumb)*.
  When you find help, the [📋 patient report form](lib:where-there-is-no-doctor-29-dosage-blanks#page=5)
  says what to tell them.

![A blank medicine card to copy, with lines for the person's name and illness, a table with columns for each medicine, its strength in mg and the times to take it, and lines for allergies and the doctor](img:CHRONIC-ILLNESS-GUIDE/medicine-card.svg)
*A card to copy for each person: one with the medicines, one in the grab bag (a form drawn for this guide).*

### Tools worth having

| Tool | For |
|---|---|
| Blood pressure cuff with a gauge, and a stethoscope (no batteries) | How to use it: [WTND, pp. 412–413](lib:where-there-is-no-doctor-25-additional#page=12) |
| Sugar meter and strips, or urine sugar strips | Urine strips are less exact but easier and cheaper; test daily ([WHO Formulary, p. 390](lib:who-model-formulary-2008#page=390)) |
| Bathroom scale | A weight chart for heart failure ([MSF, p. 401](lib:msf-clinical-guidelines#page=401)) |
| Insulin syringes that match the insulin | "only syringes calibrated for the particular concentration" ([WHO Formulary, p. 388](lib:who-model-formulary-2008#page=388)) |
| Iodized salt; a spacer for inhalers | Thyroid and Asthma, below |
| A thermometer in the medicine store | Insulin must stay below 25 °C and never freeze ([MSF, p. 426](lib:msf-essential-drugs#page=426)) |

## ⛔ Medicines you must never stop suddenly

**Don't just stop when the bottle is empty.** The books step these down gradually. Where a book gives
the pace, it is here; where none does, the table says so.

| Medicine | Stopped suddenly | How the books step it down |
|---|---|---|
| **Steroid tablets** (prednisone, prednisolone, hydrocortisone, dexamethasone) | "acute adrenal insufficiency, hypotension or even death" after long use ([WHO, p. 365](lib:who-model-formulary-2008#page=365)). Illness or injury needs a temporary higher dose ([p. 366](lib:who-model-formulary-2008#page=366)) | "reduced rapidly down to the physiological dosage (equivalent to 7.5 mg prednisolone daily) and then reduced more slowly". A sudden stop only after 3 weeks or less, and not after more than 40 mg a day, evening doses or repeated courses ([WHO, p. 368](lib:who-model-formulary-2008#page=368)). No book gives the slow part in numbers |
| **Beta-blockers** ("-olol": atenolol, metoprolol, bisoprolol, propranolol) | Angina attacks; heart failure gets suddenly worse ([WHO, p. 274](lib:who-model-formulary-2008#page=274); [MSF, p. 400](lib:msf-clinical-guidelines#page=400)) | "withdrawn gradually" (WHO); "reduce the dose ... or gradually stop" (MSF). No book gives a schedule |
| **Clonidine** (a blood pressure pill) | Blood pressure can shoot back up *(rule of thumb; not in the library's books)* | No book gives one |
| **Seizure medicines** | "Immediate stopping can cause more and severe seizures" ([WTND, p. 390](lib:where-there-is-no-doctor-24-green-pages#page=52)), even status epilepticus ([WHO, p. 78](lib:who-model-formulary-2008#page=78)) | MSF: "slowly tapered (e.g. by 10% every 2 weeks) over a period of at least 3 months" ([p. 385](lib:msf-clinical-guidelines#page=385)). WHO: over "several months", one medicine at a time ([p. 78](lib:who-model-formulary-2008#page=78)) |
| **Benzodiazepines** (diazepam/Valium, alprazolam/Xanax, clonazepam/Klonopin, lorazepam) taken for weeks | "confusion, toxic psychosis, convulsions, or a condition resembling delirium tremens", up to 3 weeks after a long-acting one ([WHO, p. 478](lib:who-model-formulary-2008#page=478)) | "gradual reduction of the dose over a period of weeks or months" (same page). No book gives a schedule |
| **Barbiturates** (phenobarbital and others) | "Barbiturate withdrawal is LIFE THREATENING!" ([Hospital Corpsman, p. 231](lib:hospital-corpsman#page=231)) | "tapering the dose slowly over several days" (same page) |
| **Antidepressants** | Dizziness, nausea, anxiety, headaches, tingling, poor sleep ([WHO, p. 473](lib:who-model-formulary-2008#page=473)); stopped too soon, "symptoms are likely to recur" ([p. 471](lib:who-model-formulary-2008#page=471)) | "stopped gradually over a 4-week period" ([MSF, p. 368](lib:msf-clinical-guidelines#page=368)) |
| **Lithium** | "avoid abrupt withdrawal" ([WHO, p. 476](lib:who-model-formulary-2008#page=476)) | "reduced gradually over about 4 weeks", "6 months in patients who have been on long-term maintenance treatment" ([WHO, p. 471](lib:who-model-formulary-2008#page=471)) |
| **Antipsychotics** | Withdrawal effects and relapse, which "may be delayed for several weeks" ([WHO, p. 465](lib:who-model-formulary-2008#page=465)) | After a first episode, stable 3 months: "stop the treatment gradually over 4 weeks, monitoring for potential relapse" ([MSF, p. 371](lib:msf-clinical-guidelines#page=371)) |
| **Opioids** (morphine, oxycodone, hydrocodone, methadone) | Days of misery, worst at about 72 hours, "rarely life-threatening" ([Ship's, p. 113](lib:ships-medicine-chest#page=113); [Hospital Corpsman, p. 228](lib:hospital-corpsman#page=228)) | "tapering the dose over several days" ([Hospital Corpsman, p. 228](lib:hospital-corpsman#page=228)). No book gives numbers |
| **Alcohol** (heavy daily drinkers) | Shakes, sweats, seizures; DTs 24–72 hours after the last drink. "Untreated, DT's have a 20% fatality rate" ([Ship's, pp. 108](lib:ships-medicine-chest#page=108), [110](lib:ships-medicine-chest#page=110)) | With diazepam, below |

**Alcohol withdrawal** (shaking, sweating, irritable, unwell). The books' plan:
- MSF: "diazepam PO (10 mg every 6 hours for 1 to 3 days, then reduce and stop over 7 days) + oral
  hydration (3 litres of water daily)", plus thiamine by injection ([MSF, p. 363](lib:msf-clinical-guidelines#page=363);
  the same in [MSF *Essential Drugs*, p. 115](lib:msf-essential-drugs#page=115)).
- WWHND, for someone far from help: 10 mg of diazepam by mouth, another 10 mg 6 hours later if the signs are
  not getting better, repeated every 6 hours ([WWHND, p. 442](lib:where-women-have-no-doctor-28-alcohol#page=9)).
- *Ship's Medicine Chest* uses chlordiazepoxide instead but gives no dose ([p. 109](lib:ships-medicine-chest#page=109)).
- **Never leave them alone.** Keep the room evenly lit and talk calmly ([Ship's, pp. 109–110](lib:ships-medicine-chest#page=109)).
  Emergency signs: confusion, seeing or hearing things, a very fast heartbeat, seizures
  ([WWHND, p. 442](lib:where-women-have-no-doctor-28-alcohol#page=9)).

### Making a supply last

- **Step down early rather than stop on the last day.** The books stop these medicines gradually; if the
  supply will end, start the step-down early enough to finish it with the last tablet *(rule of thumb;
  the pace is the book's, in the table above)*.
- **Half doses or every-other-day doses** to stretch a supply are *(rule of thumb)*, no book backs them. For
  the medicines above, a lower dose *is* a step-down: go at the table's pace and watch for its signs. For
  others, watch what the medicine controls: the blood pressure readings, the sugar, the seizures, the
  breathing.
- **Never split, crush or chew extended-release tablets** (marked ER, XR, XL, SR, CR, LA, "retard" or
  "prolonged-release"): "Sustained-release tablets should not be crushed" ([WHO Formulary, p. 48](lib:who-model-formulary-2008#page=48)).
  They hold many hours of medicine meant to come out slowly; broken, much of it can come at once
  *(rule of thumb)*. Plain tablets can be cut: WTND cuts a regular aspirin into four
  ([p. 60](lib:where-there-is-no-doctor-08-how-to-measure#page=2)).
- **After opioids are stopped,** the old dose can stop the breathing of someone who has lost their
  tolerance: never restart at the old dose *(rule of thumb)*. Keep naloxone
  ([Medical guide](guide:Medical-READ-ME-FIRST)).

## 🩸 Diabetes
<!-- fold: Insulin without a fridge and its doses, ketoacidosis, and type 2 pills, food and work -->

Signs of diabetes: always thirsty, passing a lot of urine, hungry, tired, losing weight, blurred sight,
numb feet, sores that won't heal ([WTND, p. 127](lib:where-there-is-no-doctor-11-nutrition#page=21)).
**Type 1** usually starts young; the body makes no insulin, and "Patients require administration of
insulin" for life. **Type 2** usually starts after 40 and "may be controlled by diet alone"
([WHO Formulary, p. 388](lib:who-model-formulary-2008#page=388); [WTND, p. 127](lib:where-there-is-no-doctor-11-nutrition#page=21)).

### Type 1: insulin without a fridge

**Keeping it** ([MSF, pp. 425–426](lib:msf-essential-drugs#page=425); [p. 429](lib:msf-essential-drugs#page=429)):

| Insulin | Keep it |
|---|---|
| **Unopened** | In a fridge, 2–8 °C (36–46 °F) |
| **Opened** (in use) | **4 weeks at most, below 25 °C (77 °F), out of the light** |
| **Any** | **Never frozen.** Let it reach room temperature before use |

- **No fridge:** the coolest place that never freezes, checked with a thermometer: a cellar, a
  springhouse, or a clay-pot cooler, which holds 13–22 °C inside on 30–45 °C days in dry heat
  ([Practical Action, p. 1](lib:practical-action-clay-pot-cooler#page=1); written for vegetables, so using
  it for insulin is *(rule of thumb)*). More: [Root Cellar](guide:ROOT-CELLAR-GUIDE) ("Cooling without power"). Here both ends matter: Grants Pass has hit **108 °F**, and Cave Junction's winter nights average
**32 °F**, with a record of -6 °F ([Josephine soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)),
so a shed or attic is too hot in summer and freezes in winter. Never leave insulin in a parked car, which
can reach 50–60 °C; freezing spoils solutions and cracks vials ([MSF, p. 647](lib:msf-essential-drugs#page=647)).

![A clay-pot cooler cut open: a small clay pot inside a bigger one with wet sand between and a wet cloth over the top, an insulin vial and a thermometer standing in the inner pot, and heat leaving as water dries off the outer pot; below, the numbers: 13 to 22 °C inside on 30 to 45 °C days in dry heat, and opened insulin kept below 25 °C (77 °F), out of the light, 4 weeks at most, never frozen](img:CHRONIC-ILLNESS-GUIDE/clay-pot-cooler-for-insulin.svg)
*A clay-pot cooler with insulin and a thermometer inside ([Practical Action, pp. 1–2](lib:practical-action-clay-pot-cooler#page=1); insulin: [MSF, p. 426](lib:msf-essential-drugs#page=426); a diagram drawn for this guide).*

- Insulin can't be swallowed: the gut destroys it ([MSF, p. 423](lib:msf-essential-drugs#page=423)).
- **Match the syringe to the vial.** Insulin comes as "40 IU/ml" and "100 IU/ml"
  ([WHO Formulary, p. 393](lib:who-model-formulary-2008#page=393)); use "only syringes calibrated for the particular
  concentration" ([p. 388](lib:who-model-formulary-2008#page=388)). The wrong syringe gives the wrong dose.
- **Test every day,** blood or urine ([WHO, p. 390](lib:who-model-formulary-2008#page=390)). Aim for
  "4–7 mmol/litre before meals and less than 9 mmol/litre after meals", and work hard to stay above
  4 ([WHO, p. 389](lib:who-model-formulary-2008#page=389)). Stock strips.
- **Lows get more likely** with hard work, missed meals and alcohol. Extra carbohydrate may be needed for
  hard work. Beta-blockers can hide the warning signs ([WHO, p. 390](lib:who-model-formulary-2008#page=390);
  [MSF, p. 33](lib:msf-clinical-guidelines#page=33); alcohol: [MSF *Essential Drugs*, p. 423](lib:msf-essential-drugs#page=423)).

**How much insulin.** Be honest about this: **insulin is set person by person.** WHO's dose is "according
to individual requirements" for adults and children alike ([WHO Formulary, p. 394](lib:who-model-formulary-2008#page=394)).
What the books do give:

| | What the books give |
|---|---|
| **Kinds** | Short-acting (soluble, "regular") is clear and works for "7 to 8 hours"; intermediate-acting is cloudy and lasts "around 24 hours" ([MSF *Essential Drugs*, p. 422](lib:msf-essential-drugs#page=422)). Long-acting analogues (glargine and others) come as a "solution", not a cloudy suspension ([WHO EML, p. 54](lib:who-model-list-of-essential-medicines-24th#page=54)): read the label, not the colour *(rule of thumb)* |
| **How it is split** | New, very ill: "soluble insulin given 3 times daily with medium-acting insulin at bedtime"; less ill: premixed "30% soluble insulin and 70% isophane insulin" "given twice daily" ([WHO, p. 389](lib:who-model-formulary-2008#page=389)). Short-acting goes in "15 to 30 minutes before a meal" ([MSF *Essential Drugs*, p. 428](lib:msf-essential-drugs#page=428)) |
| **Daily totals** | No book here gives a starting total for type 1. For type 2 adding insulin, MSF starts intermediate-acting at bedtime at "0.2 IU/kg"; "Doses of 1 IU/kg/day or more may be necessary"; over "0.5 IU/kg/day", split it into 2 injections ([MSF, p. 392](lib:msf-clinical-guidelines#page=392)) |
| **Adjusting** (MSF's table, for bedtime insulin in type 2, by the morning sugar, keeping each dose 4 days) | Under 4 mmol/litre (< 70 mg/dl): treat the low and "Reduce daily dose of insulin by 2 to 4 units". 4 to 7.2 (70–130 mg/dl): "Do not change dose". 7.2 to 11 (130–200 mg/dl): "Increase daily dose of insulin by 2 units". 11 or more (≥ 200 mg/dl): "Increase daily dose of insulin by 4 units" ([MSF, p. 392](lib:msf-clinical-guidelines#page=392)) |
| **Sick days** | No book gives sick-day numbers. Infection, stress and injury raise the need, kidney failure lowers it ([MSF *Essential Drugs*, p. 423](lib:msf-essential-drugs#page=423)), and ketoacidosis "commonly occurs when adjustments to insulin dosage fail to compensate" in "severe infection" ([WHO, p. 391](lib:who-model-formulary-2008#page=391)). **In type 1, never stop the long-acting (background) insulin, even when not eating;** test more often *(rule of thumb)* |

**Watch for:** lows (above); pain, redness or lumps of fat where it goes in: "Rotate injection sites
systematically" ([MSF *Essential Drugs*, p. 423](lib:msf-essential-drugs#page=423)).

### High sugar and ketoacidosis

Too little insulin, or a missed dose, lets sugar climb. Then the body burns fat and the blood turns
acid: **diabetic ketoacidosis (DKA)** ([Hospital Corpsman, p. 206](lib:hospital-corpsman#page=206);
[Diabetic ketoacidosis](wiki:Diabetic_ketoacidosis)).
- **Signs:** deep or fast breathing, sweet, fruity (acetone) breath, passing a lot of urine, dry and
  dehydrated, warm dry skin, then confusion, stupor and coma
  ([WHO-ICRC, p. 112](lib:who-icrc-basic-emergency-care#page=112); [Hospital Corpsman, pp. 206–207](lib:hospital-corpsman#page=207)).
- **Two questions:** "Has the victim eaten today? Has he taken the prescribed insulin?" Ate but no insulin
  means DKA is likely ([p. 207](lib:hospital-corpsman#page=207)).
- **What helps:** fluids against shock ([Hospital Corpsman, p. 207](lib:hospital-corpsman#page=207)) and
  insulin. The books treat DKA in hospital with insulin through a drip ("0.1 IU/kg" then "0.1 IU/kg/hour",
  [MSF *Essential Drugs*, p. 428](lib:msf-essential-drugs#page=428)); no book gives a dose for DKA at home.

**When the insulin runs out:** without insulin, a person with type 1 diabetes goes into ketoacidosis
and dies, usually within days to a few weeks *(rule of thumb)*. No diet or herb replaces insulin.
This is the hardest case in this guide: see "When someone can no longer be kept well", below.

### Type 2: food and work are medicine

- **Eat:** plenty of vegetables and high-fiber foods; beans, whole grains and brown rice; protein. Less
  rice, white flour and potatoes. **Cut out sugary drinks and sweets.** "The diet for a person with
  diabetes is very important and must be followed for life"
  ([WTND, p. 127](lib:where-there-is-no-doctor-11-nutrition#page=21); [WHO Formulary, p. 388](lib:who-model-formulary-2008#page=388)).
  MSF: no sugared foods and drinks "(but no excessive restriction of carbohydrates)" ([MSF, p. 391](lib:msf-clinical-guidelines#page=391)).
- **Work:** "Emphasis should be placed on exercise and increased activity" ([WHO, p. 388](lib:who-model-formulary-2008#page=388)).
- **Feet:** always wear shoes and keep the skin clean; for poor circulation, rest
  with the feet up ([WTND, p. 127](lib:where-there-is-no-doctor-11-nutrition#page=21)). Sores heal slowly:
  keep them clean and change the bandage often ([p. 324](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=2)).
- **When food runs short and lows appear,** the sulfonylurea is the pill that causes them; metformin
  "does not usually cause hypoglycaemia" ([WHO, pp. 392–393](lib:who-model-formulary-2008#page=393)). Cutting
  back the sulfonylurea first is *(rule of thumb)*: watch the sugar.

| Medicine | Usual adult dose (book, page) | Children | Watch for / don't use if |
|---|---|---|---|
| **Metformin** | WHO: "initially 500 mg with breakfast for at least 1 week then 500 mg with breakfast and evening meal for at least 1 week, then 500 mg with breakfast, lunch, and evening meal or 850 mg every 12 hours"; "usual maximum, 2 g daily" ([p. 395](lib:who-model-formulary-2008#page=395)). MSF: "The usual dose is 1 to 2 g daily" ([p. 391](lib:msf-clinical-guidelines#page=391)) | Over 10 years, as adults ([WHO, p. 395](lib:who-model-formulary-2008#page=395)) | Stomach upset, diarrhea. Not with kidney trouble, ketoacidosis, heavy drinking; switch to insulin in severe infection or injury ([WHO, p. 394](lib:who-model-formulary-2008#page=394)) |
| **Glibenclamide** (glyburide) | WHO: "initially 5 mg once daily with or immediately after breakfast (2.5 mg in the elderly)", "maximum, 15 mg daily" ([p. 393](lib:who-model-formulary-2008#page=393)). MSF, only "In patients under 60": "The usual dose is 5 mg 2 times daily", starting at 2.5 mg ([p. 391](lib:msf-clinical-guidelines#page=391)) | No dose given | **Lows, lasting hours.** Not over 60 ([MSF](lib:msf-clinical-guidelines#page=391); [EML, p. 54](lib:who-model-list-of-essential-medicines-24th#page=54)); not when breastfeeding ([WHO, p. 393](lib:who-model-formulary-2008#page=393)) |
| **Gliclazide** (plain, not slow-release) | MSF, for those over 60: "The usual dose is 40 to 80 mg 2 times daily", starting at 40 mg once daily; "max. 240 mg daily" ([p. 391](lib:msf-clinical-guidelines#page=391)) | No dose given | Lows, as above |

## ❤️ Blood pressure and heart disease
<!-- fold: Measuring it, salt, the usual pills and their doses, angina and heart failure -->

### High blood pressure

- **"High blood pressure at first causes no signs."** Late signs: frequent headaches, pounding heart and
  breathlessness with mild work, dizziness, chest pain. It leads to heart disease, kidney disease and
  stroke ([WTND, p. 125](lib:where-there-is-no-doctor-11-nutrition#page=19)).
- **Measure it** sitting, after 5 minutes' rest ([WTND, p. 412](lib:where-there-is-no-doctor-25-additional#page=12)).
  Around 120/80 is typical, 100/60 to 140/90 healthy; a top number over 160 or a bottom number over 100
  needs attention; 160/110 is "seriously high"; a sudden drop, especially below 60/40, is a danger sign
  ([p. 413](lib:where-there-is-no-doctor-25-additional#page=13)). MSF's targets: under 140/90, under 140/80
  with diabetes, top number under 150 over age 80 ([MSF, p. 395](lib:msf-clinical-guidelines#page=395)).
- **Without pills:** less salt, less weight, little alcohol, no tobacco, plenty of vegetables, regular
  exercise. "These measures alone may be sufficient in mild hypertension"
  ([WHO Formulary, p. 286](lib:who-model-formulary-2008#page=286)).
- **Salt-cured foods** (salt pork, salt fish, jerky, sauerkraut) carry a lot of it: soak or rinse them
  *(rule of thumb)*.
- **When food is short and weight falls, the old dose may become too strong.** Dizziness on standing,
  worse in the morning or after a big meal: get up slowly, hold on, and "Ask if any of your medicines
  should be reduced or stopped" ([CDC STEADI, p. 2](lib:postural-hypotension#page=2)). No book gives a
  step-down plan for blood pressure pills. If readings stay well under the target and the person is dizzy,
  cut back one medicine at a time and watch the readings for a week or two *(rule of thumb)*; never stop a
  beta-blocker suddenly.
- **Careful with painkillers:** ibuprofen and similar can raise blood pressure, hold water, and even bring
  on heart failure or kidney failure in older people ([WHO Formulary, pp. 44–45](lib:who-model-formulary-2008#page=45)).

MSF starts with one medicine, then adds a second after 4 weeks if pressure is still high
([MSF, p. 396](lib:msf-clinical-guidelines#page=396)).

| Medicine | Usual adult dose (book, page) | Children | Watch for / don't use if |
|---|---|---|---|
| **Hydrochlorothiazide** (water pill) | WHO: "12.5 mg daily, increased to 25–50 mg daily if necessary" ([p. 291](lib:who-model-formulary-2008#page=291)). MSF: "12.5 to 25 mg once daily in the morning (max. 25 mg daily)" ([p. 396](lib:msf-clinical-guidelines#page=396)) | By weight: [WHO Children, p. 372](lib:who-model-formulary-for-children#page=372) | Thirst, cramps, weakness, dizziness on standing; gout; raises sugar. Not in severe kidney or liver failure ([WHO, pp. 291–292](lib:who-model-formulary-2008#page=291)) |
| **Amlodipine** | "initially 5 mg once daily, increased if necessary; maximum 10 mg once daily" ([WHO, p. 288](lib:who-model-formulary-2008#page=288)); elderly or liver disease "start with 2.5 mg once daily" ([MSF, p. 396](lib:msf-clinical-guidelines#page=396)) | — | Swollen ankles, flushing, headache ([WHO, p. 288](lib:who-model-formulary-2008#page=288)) |
| **Enalapril** (an ACE inhibitor) | WHO: "initially 5 mg once daily (lower if used in addition to a diuretic or in renal impairment)"; "usual maintenance dose, 20 mg once daily; maximum, 40 mg once daily" ([p. 290](lib:who-model-formulary-2008#page=290)). MSF: elderly, on a water pill or with kidney trouble, "start with 2.5 mg once daily" ([p. 396](lib:msf-clinical-guidelines#page=396)) | By weight: [WHO Children, p. 332](lib:who-model-formulary-for-children#page=332) | Dry cough, dizziness; swelling of the face or lips. **Not in pregnancy** ([WHO, pp. 289–290](lib:who-model-formulary-2008#page=289)) |
| **Atenolol** (beta-blocker) | Blood pressure: "50 mg once daily (higher doses rarely necessary)" ([WHO, p. 289](lib:who-model-formulary-2008#page=289)). Angina: "50 mg once daily, increased if necessary to 50 mg twice daily or 100 mg once daily" ([p. 275](lib:who-model-formulary-2008#page=275)) | — | **Not with asthma.** Slow pulse; hides low-sugar signs ([WHO, p. 288](lib:who-model-formulary-2008#page=288)). Never stop suddenly |
| **Bisoprolol** (beta-blocker) | "5 to 10 mg once daily in the morning" ([MSF, p. 396](lib:msf-clinical-guidelines#page=396)) | — | As atenolol: "contra-indicated in patients with asthma" (same page) |

### Heart trouble and heart failure

**Signs of heart trouble** ([WTND, p. 325](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=3)):
breathless after work; breathing attacks that are worse lying down; tiredness, weakness, dizziness; chest,
shoulder or arm pain with work that goes with rest (angina); a fast, weak or uneven pulse; swollen feet,
worse in the afternoon.
- Regular exercise, but never to chest pain or breathlessness; no greasy food, tobacco or alcohol. With
  swollen feet or breathing attacks, **"little or no salt for the rest of his life"** (same page), and feet
  up whenever possible ([p. 323](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=1)).
- **Heart failure:** reduce salt to limit fluid build-up, "Normal fluid intake except in cases of very
  severe oedema", activity to what the person can manage, and a **weight chart**: weight going up fast
  usually means water *(rule of thumb)* ([MSF, pp. 399–401](lib:msf-clinical-guidelines#page=399)).
- **A bad night:** sudden, severe breathlessness may be acute heart failure. Sit them up, legs down
  ([MSF, p. 402](lib:msf-clinical-guidelines#page=402)).
- **To prevent another heart attack or stroke:** aspirin "75–100 mg daily" ([WHO, p. 301](lib:who-model-formulary-2008#page=301));
  WTND says "75 to 81 mg" ([p. 325](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=3)). Angina
  and heart attack doses: The first minutes, above. Nitroglycerin weakens once opened:
  [Medical guide](guide:Medical-READ-ME-FIRST).
- **After a stroke:** [Rehab guide](guide:REHAB-GUIDE) ("Stroke and spine injuries: the basics");
  [WTND, p. 327](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=5).

| Medicine | Usual adult dose (book, page) | Children | Watch for / don't use if |
|---|---|---|---|
| **Furosemide** (water pill) | WHO: "initially 40 mg daily on rising; usual maintenance dose, 20–40 mg daily; may be increased to 80 mg daily or more in resistant oedema" ([p. 340](lib:who-model-formulary-2008#page=340)). MSF: "start with 20 mg once daily", some need "80 mg 1 to 2 times daily", "then reduce once oedema decrease (20 to 40 mg once daily)"; "Lifelong treatment with diuretics is not always necessary" ([p. 400](lib:msf-clinical-guidelines#page=400)) | "1–3 mg/kg daily (maximum, 40 mg daily)" ([WHO, p. 340](lib:who-model-formulary-2008#page=340)) | Dehydration, low potassium and salt (cramps, weakness); reduce in the elderly ([WHO, pp. 340–341](lib:who-model-formulary-2008#page=341)). Not when no urine is being made |
| **Enalapril** for heart failure | Start low: "2.5 mg once daily for 3 days then 5 mg"; the effective dose "is usually 20 mg once daily"; top number should stay above 90 ([MSF, p. 400](lib:msf-clinical-guidelines#page=400)) | — | As above |
| **Bisoprolol** for heart failure | Added once stable on enalapril for 2 weeks: from "1.25 mg once daily", slowly up to "10 mg daily" at most ([MSF, p. 400](lib:msf-clinical-guidelines#page=400)) | — | Worse breathing, slow pulse: MSF lowers the dose or stops it gradually (same page) |

## 🫁 Asthma and COPD
<!-- fold: Inhaler and tablet doses, spacers, smoke, and oxygen when the power is off -->

**Asthma** ([WTND, p. 167](lib:where-there-is-no-doctor-13-some-very-common#page=17)):
- **Smoke brings on attacks:** cigarettes, **indoor cooking fires**, burning fields. Wildfire smoke brings
  asthma attacks, COPD flare-ups and heart attacks, worst in children and people over 65
  ([EPA, p. 41](lib:epa-wildfire-smoke-guide#page=41); [Wildfire guide](guide:WILDFIRE-GUIDE), "Smoke, heat and people").
- Keep the house clean and animals outside; drink at least 8 glasses of water a day.
- **Two kinds of inhaler.** The rescue inhaler (salbutamol) opens the airways; start it "at the first
  sign of wheeze or chest tightness". The **controller** (a steroid inhaler such as beclomethasone), used
  every day, prevents attacks, so "use salbutamol less"; it takes 3–7 days to work
  ([WTND, pp. 385–386](lib:where-there-is-no-doctor-24-green-pages#page=47)).
- **Use a spacer,** or most of the medicine lands on the tongue. Both books agree on a plastic bottle with
  the inhaler pushed into a hole cut in the bottom ([WTND, p. 386](lib:where-there-is-no-doctor-24-green-pages#page=48);
  MSF uses a 500 ml bottle, [p. 106](lib:msf-clinical-guidelines#page=106)). WTND also suggests two cups
  taped together; MSF says "The use of a plastic cup instead of a spacer is not recommended (ineffective)".

![A homemade spacer: a plastic bottle lying on its side with an inhaler's mouthpiece pushed into a hole cut in its bottom, the puff of medicine spreading inside, and the person's lips sealed round the bottle's neck to breathe in and out from it](img:CHRONIC-ILLNESS-GUIDE/bottle-spacer.svg)
*A bottle spacer: one puff into the bottle, then breathe from it; with a child, 4 or 5 breaths before the next puff ([MSF, pp. 104–106](lib:msf-clinical-guidelines#page=105); a diagram drawn for this guide).*

- **Don't** use eucalyptus or Vaporub: "They make it worse"
  ([WTND, p. 168](lib:where-there-is-no-doctor-13-some-very-common#page=18)). People with asthma should not
  take "-olol" heart pills (beta-blockers): they "may precipitate asthma"
  ([WHO Formulary, p. 274](lib:who-model-formulary-2008#page=274); [WTND, p. 385](lib:where-there-is-no-doctor-24-green-pages#page=47)).

| Medicine | Usual adult dose (book, page) | Children | Watch for / don't use if |
|---|---|---|---|
| **Salbutamol inhaler** (100 micrograms a puff) | Mild wheeze: "1 to 2 inhalations, every 4 to 6 hours" ([WTND, p. 385](lib:where-there-is-no-doctor-24-green-pages#page=47)). Attack: "2 to 4 puffs every 20 minutes" (WTND) or "2 to 10 puffs every 20 minutes during the first hour", then "2 to 4 puffs every 4 to 6 hours" for 24 to 48 hours ([MSF, p. 105](lib:msf-clinical-guidelines#page=105)) | MSF gives children the same puffs, with a spacer, and a face mask under 3 years (same page). WHO: "100 micrograms (1 puff) increased to 200 micrograms (2 puffs) if necessary" ([p. 494](lib:who-model-formulary-2008#page=494)) | Shaking, fast heartbeat, headache. Using it very often means it works less well: add the controller ([WTND, p. 385](lib:where-there-is-no-doctor-24-green-pages#page=47)) |
| **Salbutamol tablets or syrup** (when there is no inhaler) | Tablets: "2–4 mg, 3–4 times daily" ([WHO, p. 494](lib:who-model-formulary-2008#page=494)). Syrup (2 mg in 5 ml): "10 ml 3 times a day" ([WTND, p. 385](lib:where-there-is-no-doctor-24-green-pages#page=47)) | WHO tablets: "CHILD 2–6 years, 1–2 mg 3–4 times daily; CHILD 6–12 years, 2 mg 3–4 times daily". WTND syrup: "1 to 12 years: 5 ml 3 times a day"; "babies: 2 ½ ml 3 times a day" | As above; by mouth it "is less effective and causes more adverse effects" ([WHO, p. 489](lib:who-model-formulary-2008#page=489)) |
| **Prednisolone** (bad attack) | WTND: "30 to 60 mg" every morning for 3 to 7 days, "Do not give more than 60 mg a day" ([p. 386](lib:where-there-is-no-doctor-24-green-pages#page=48)). MSF: "one dose of 1 to 2 mg/kg (max. 50 mg)", then once daily "to complete 5 days" ([p. 105](lib:msf-clinical-guidelines#page=105)) | WTND: "children 3 to 7 years: 20 to 40 mg"; "children under 3: 10 to 20 mg" (over 8, as adults). MSF: 1 to 2 mg/kg for children over 5 | "only ... for severe asthma attacks"; lowers defenses, anxiety, poor sleep ([WTND, p. 386](lib:where-there-is-no-doctor-24-green-pages#page=48)). WTND and MSF simply stop after the short course; WHO would consider a gradual stop after more than 40 mg a day ("Never stop suddenly", above) |
| **Beclomethasone** (controller) | "2 to 4 puffs 2 times each day of the 50 mcg inhaler" ([WTND, p. 386](lib:where-there-is-no-doctor-24-green-pages#page=48)) | Same (children and adults) | Thrush in the mouth: rinse the mouth after each use (same page) |

**COPD** (chronic bronchitis, emphysema): a cough for months or years, worst in old heavy smokers; with
emphysema, hard breathing and a "barrel" chest ([WTND, p. 170](lib:where-there-is-no-doctor-13-some-very-common#page=20)).
- **Stop smoking**: it slows the damage ([WHO Formulary, p. 489](lib:who-model-formulary-2008#page=489)).
- Infections make it worse; flu shots help prevent them. Inhalers as for asthma; for a flare-up WHO gives "a
  short course of an oral corticosteroid" and antibiotics for infection, but no dose for COPD (same page).
  The asthma prednisolone doses above are the closest. Found antibiotics: [Medical guide](guide:Medical-READ-ME-FIRST).
- **Ipratropium inhaler** (20 micrograms a puff): "ADULT, 20–40 micrograms, 3–4 times daily"
  ([WHO, p. 493](lib:who-model-formulary-2008#page=493)).
- **Sticky phlegm:** drink plenty, breathe steam, then pound the back lightly with a cupped
  hand ([WTND, pp. 168–169](lib:where-there-is-no-doctor-13-some-very-common#page=19)).
  Breathing exercises: [Rehab guide](guide:REHAB-GUIDE) ("After long bed rest").

**Oxygen** helps people with severe COPD live longer ([WHO Formulary, p. 489](lib:who-model-formulary-2008#page=489)).
A concentrator "Cannot store oxygen: provides only when power supply is on"; cylinders store it but need
refilling ([WHO *Surgical Care*, p. 364](lib:surgical-care-at-the-district-hospital#page=364)), and a
falling cylinder can kill: store them lying down, strap them upright in use
([p. 366](lib:surgical-care-at-the-district-hospital#page=366)). Powered equipment fails "if the power is
out for more than a few days" ([FEMA *Power Outage Annex*, p. 21](lib:power-outage-incident-annex#page=21)):
plan the power now ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE), "Start with a load list").

## ⚡ Epilepsy
<!-- fold: Seizure medicines and their doses, stepping down, and living safely -->

- Epilepsy brings seizures to people who otherwise seem healthy; it can't be caught. Medicines "do not
  cure epilepsy; they help prevent seizures", often for life, at the lowest dose that works
  ([WTND, p. 178](lib:where-there-is-no-doctor-13-some-very-common#page=28)). Start low and raise slowly until
  the seizures stop ([WTND, p. 390](lib:where-there-is-no-doctor-24-green-pages#page=52); [MSF, p. 387](lib:msf-clinical-guidelines#page=387)).
- **Missed doses bring seizures back:** "Abruptly stopping or reducing an ASM dose is likely to provoke
  seizures" ([MSF, p. 384](lib:msf-clinical-guidelines#page=384)). Stepping down: "Never stop suddenly", above.
- **Living safely:** normal lives are possible with care, such as "not swimming alone, not cooking over
  open flames" ([MSF, p. 385](lib:msf-clinical-guidelines#page=385)). Off-grid life means open fires, axes,
  ladders and creeks: give them jobs away from these *(rule of thumb)*.
- **When the medicine runs out,** expect seizures back. Teach everyone the first aid and rescue doses in
  "The first minutes", keep a seizure log, and let them sleep low *(rule of thumb)*.
- **Pregnancy:** valproate "must not be prescribed in pregnant women and girls"
  ([MSF, p. 386](lib:msf-clinical-guidelines#page=386)).

| Medicine | Usual adult dose (book, page) | Children | Watch for / don't use if |
|---|---|---|---|
| **Phenobarbital** | WTND: "50 to 100 mg, 2 or 3 times a day" ([p. 390](lib:where-there-is-no-doctor-24-green-pages#page=52)). MSF: start "1 mg/kg (max. 60 mg) once daily at bedtime for 2 weeks", up to "3 mg/kg once daily if needed (max. 180 mg daily)" ([p. 387](lib:msf-clinical-guidelines#page=387)). WHO: "60–180 mg at night" ([p. 86](lib:who-model-formulary-2008#page=86)) | WTND: "6 to 12 years: 25 to 50 mg by mouth, 2 times a day"; "under 6 years: 3 to 5 mg/kg/day" | "Too much phenobarbital can slow down or stop breathing" (WTND). It is also a barbiturate: never stop suddenly |
| **Carbamazepine** | WTND: "200 mg by mouth, 2 times a day", raised weekly until seizures stop ([p. 390](lib:where-there-is-no-doctor-24-green-pages#page=52)). MSF: start "100 to 200 mg once daily", "up to 400 mg 2 or 3 times daily if necessary (max. 2 g daily)" ([p. 387](lib:msf-clinical-guidelines#page=387)) | WTND: "6 to 12 years: 100 mg by mouth, 2 times a day"; "under 6 years: 5 mg/kg/day, or 50 mg by mouth 2 times a day" | Dizziness, unsteady walking or vomiting means too much; a rash 2–8 weeks after starting means change medicine (WTND). Not with valproate ([WTND, p. 391](lib:where-there-is-no-doctor-24-green-pages#page=53)) |
| **Valproate** (valproic acid) | WTND: "300 mg by mouth, 2 times a day" ([p. 391](lib:where-there-is-no-doctor-24-green-pages#page=53)). MSF: start "500 to 600 mg once daily", "up to 500 mg to 1 g 2 times daily if necessary (max. 2.5 g daily)" ([p. 387](lib:msf-clinical-guidelines#page=387)) | WTND: "6 to 12 years: 200 mg by mouth, 2 times a day"; "under 6 years: 10mg/kg/day, or 100 mg by mouth, 2 times a day"; never over "60 mg/kg/day" | Weight gain, liver trouble. **Not for anyone who could get pregnant** (WTND; MSF, p. 386) |
| **Phenytoin** | WTND: "100 mg by mouth, 2 times a day", never more than "300 mg in a day" ([p. 391](lib:where-there-is-no-doctor-24-green-pages#page=53)). MSF: up to "200 to 400 mg once daily or 100 to 250 mg 2 times daily" ([p. 387](lib:msf-clinical-guidelines#page=387)) | WTND: "6 to 12 years: 75 mg by mouth, 2 times a day"; "less than 6 years old: 3 to 5 mg/kg/day, or 25 mg by mouth 2 times a day" | "The difference between not enough and too much can be very small" (WTND). Swollen gums. Not for anyone who could get pregnant (WTND) |
| **Levetiracetam** | "start with 250 mg 2 times daily; increase to 500 mg 2 times daily after 2 to 4 weeks", at most "1.5 g 2 times daily" ([MSF, p. 387](lib:msf-clinical-guidelines#page=387)) | By weight in the same table | MSF's first choice for most people (p. 385) |

## 🦋 Thyroid
<!-- fold: Levothyroxine doses, the signs that come back when it runs out, and iodized salt -->

- **Underactive thyroid** is treated with levothyroxine. Its effects "may persist for several weeks after
  withdrawal" ([WHO Formulary, p. 398](lib:who-model-formulary-2008#page=398)), so a missed day is not an
  emergency; weeks without it are *(rule of thumb)*.
- **Signs that come back:** tired all the time, slow thinking, weight gain, slow heart, hardly sweating
  ([Hospital Corpsman, p. 53](lib:hospital-corpsman#page=53)); feeling cold
  ([WHO, p. 476](lib:who-model-formulary-2008#page=476)).
- **Iodine:** most goiters (a swelling on the throat) come from too little. **Use iodized salt**; seafood
  and seaweed help; WTND makes iodine water from povidone iodine when there is no iodized salt
  ([WTND, p. 130](lib:where-there-is-no-doctor-11-nutrition#page=24)). Iodine does not replace thyroid
  pills *(rule of thumb)*.
- **Overactive thyroid:** a goiter with a lot of trembling, nervousness and bulging eyes is a different kind
  ([WTND, p. 130](lib:where-there-is-no-doctor-11-nutrition#page=24)); no book here gives a home dose for it.

| Medicine | Usual adult dose (book, page) | Children | Watch for / don't use if |
|---|---|---|---|
| **Levothyroxine** (thyroxine) | "initially 50–100 micrograms daily (25–50 micrograms for those over 50 years) before breakfast, increased by 25–50 micrograms every 3–4 weeks"; "usual maintenance dose, 100–200 micrograms daily"; with heart disease "initially 25 micrograms daily or 50 micrograms on alternate days" ([WHO, pp. 399–400](lib:who-model-formulary-2008#page=400)) | Born without a working thyroid: "5 micrograms/kg daily in infants and children over 1 month" ([WHO, p. 400](lib:who-model-formulary-2008#page=400)) | Too much: chest pain, a fast or uneven heart, shaking, sweating, sleeplessness, weight loss (same page) |

## 🫘 Kidney disease
<!-- fold: Dialysis without power, the kidney diet, and medicines that build up -->

- **Dialysis needs power, water and supplies.** "Dialysis centers generally do not have backup
  generators" ([FEMA *Power Outage Annex*, p. 21](lib:power-outage-incident-annex#page=21)). The books in
  this library cannot teach dialysis at home.
- **Diet for failing kidneys:** low in protein, salt and potassium, because the kidneys can't clear them;
  in some chronic cases protein is kept at 40–60 g a day ([Hospital Corpsman, p. 327](lib:hospital-corpsman#page=327)).
- **Medicines build up** when kidneys fail. WHO's rules: prescribe as few as possible, and avoid
  medicines that harm the kidneys ([WHO Formulary, pp. 621–622](lib:who-model-formulary-2008#page=622)).
  Examples: ibuprofen and similar ([pp. 44–45](lib:who-model-formulary-2008#page=45)), metformin
  ([p. 393](lib:who-model-formulary-2008#page=393)), lithium ([p. 476](lib:who-model-formulary-2008#page=476)).
  Insulin needs fall ([MSF, p. 423](lib:msf-essential-drugs#page=423)); enalapril starts at "2.5 mg once
  daily" ([MSF, p. 396](lib:msf-clinical-guidelines#page=396)). WHO's Appendix 4 lists the medicines that
  need a smaller dose ([p. 621](lib:who-model-formulary-2008#page=621)).

## 🧠 Mental illness and psychiatric medicines
<!-- fold: Depression, suicide, psychosis, medicine doses, lithium poisoning, and stopping slowly -->

- **First, rule out the body.** Strange behavior can come from "Physical illness, chemical or pesticide
  poisoning, side effects of medicines, or alcohol or drug use" ([WWHND, p. 413](lib:where-women-have-no-doctor-27-mental-health#page=2)).
  Check for low sugar, fever, dehydration and withdrawal.
- **Depression** is more than a bad day: sad, hopeless or empty most of the time, sleeping badly or too
  much, no pleasure, slow, no energy, thinking about death ([WWHND, p. 419](lib:where-women-have-no-doctor-27-mental-health#page=8)).
- **Suicide: ask.** "Asking someone if she wants to kill herself does not make her more likely to do so."
  Ask whether she has a plan and the means. If talking doesn't help, someone stays with her at all times,
  and dangerous things are removed ([WWHND, p. 431](lib:where-women-have-no-doctor-27-mental-health#page=20)).
- **Hand out a week's tablets at a time** in the first weeks, or give them to someone close to give out
  ([MSF, p. 368](lib:msf-clinical-guidelines#page=368)), and keep the rest locked away *(rule of thumb)*.
- **Psychosis** (voices, false beliefs, not caring for oneself): "any person with a mental illness should
  be treated with kindness, respect, and dignity". Family care at home is common; medicines "should never
  be the only treatment" ([WWHND, p. 432](lib:where-women-have-no-doctor-27-mental-health#page=21)).
- **Antipsychotics** make the body handle heat and cold badly ([WHO Formulary, p. 466](lib:who-model-formulary-2008#page=466)):
  watch them in heat waves and cold snaps. Relapse after stopping may come weeks later
  ([p. 465](lib:who-model-formulary-2008#page=465)).
- **Lithium turns dangerous when water or salt changes.** Keep both steady; the book cuts or stops it in
  diarrhea, vomiting or illness with heavy sweating. Too much: blurred vision, weakness, vomiting,
  diarrhea, drowsiness, unsteady walking, coarse shaking, slurred speech; then fits, collapse, coma
  ([WHO, pp. 476–477](lib:who-model-formulary-2008#page=476)).

| Medicine | Usual adult dose (book, page) | Stopping | Watch for / don't use if |
|---|---|---|---|
| **Fluoxetine** | MSF: "20 mg on alternate days for one week, then once daily for 3 weeks", "(max. 40 mg daily)" ([p. 368](lib:msf-clinical-guidelines#page=368)). WHO: "initially 20 mg once daily", "maximum of 80 mg daily (60 mg daily in the elderly)" ([p. 473](lib:who-model-formulary-2008#page=473)) | "gradually over a 4-week period" ([MSF, p. 368](lib:msf-clinical-guidelines#page=368)) | More anxiety and suicide risk in the first weeks (MSF); children and teenagers (WHO) |
| **Amitriptyline** | "start with 25 mg once daily at bedtime and gradually increase over 8 to 10 days to 75 mg once daily (max. 150 mg daily)"; "in older patients, reduce the dose by half" ([MSF, p. 368](lib:msf-clinical-guidelines#page=368)) | As above | "The therapeutic dose is close to the lethal dose" (MSF). Not after a recent heart attack or with heart rhythm trouble ([WHO, p. 471](lib:who-model-formulary-2008#page=471)) |
| **Lithium** | "0.6–1.2 g daily (300–900 mg daily in the elderly)" to prevent mania and depression; doses differ by brand, and blood levels are checked by a lab ([WHO, p. 476](lib:who-model-formulary-2008#page=476)) | Over about 4 weeks; 6 months after long use ([WHO, p. 471](lib:who-model-formulary-2008#page=471)) | Poisoning signs above. Not with kidney disease or heart failure ([WHO, p. 476](lib:who-model-formulary-2008#page=476)) |
| **Haloperidol** (for mania) | "5 mg once daily for 3 days, then 7.5 mg for one week"; "max. 15 mg daily" ([MSF, p. 374](lib:msf-clinical-guidelines#page=374)) | "stopped gradually, monitoring for possible relapse" (same page) | Stiffness, shaking, restlessness ([WHO, p. 466](lib:who-model-formulary-2008#page=466)); falls and chilling in older people |

**What helps without pills:** time alone, hard work when angry, writing or drawing feelings, light, fresh
air and some beauty ([WWHND, p. 422](lib:where-women-have-no-doctor-27-mental-health#page=11)); a helping
friend or group; sleep ([WTND, p. 328](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=6)).
More: [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) ("Grief, stress and psychological first aid").

## 👓 Glasses, hearing aids and dentures
<!-- fold: Spare glasses, hearing-aid batteries and ear wax, and looking after false teeth -->

**Glasses.**
- Put glasses in the kit ([FEMA, p. 21](lib:fema-are-you-ready-citizen-preparedness-guide-2020#page=21)):
  a spare pair and the old pair *(rule of thumb)*.
- After 40, "Reading glasses often help. Pick glasses that let you see clearly about 40 cm (15 inches)
  away" ([WTND, p. 223](lib:where-there-is-no-doctor-16-the-eyes#page=7)).

**Hearing aids.**
- Gradual hearing loss after 40 is usually permanent, "though a hearing aid may help"
  ([WTND, p. 327](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=5)). Keep it in a container
  fixed to the bedside table ([Red Cross, p. 12](lib:disaster-preparedness-for-seniors#page=12)). Stock
  batteries, or a solar charger for rechargeable aids *(rule of thumb)*.
- **Hard wax** can block hearing: soften it with a few drops of warm vegetable oil, lie ear-up 15
  minutes, then wash out with warm water, or squirt with a needleless syringe. Stop if dizzy
  ([WTND, p. 407](lib:where-there-is-no-doctor-25-additional#page=7)).

**Dentures** (*Where There Is No Dentist*):
- **Brush false teeth every day,** like real ones ([p. 188](lib:where-there-is-no-dentist#page=188)).
- **A sore under a denture:** leave it out 2 or 3 days and rinse with warm salt water, 4 cups a day; a
  denture that doesn't fit should be remade ([p. 116](lib:where-there-is-no-dentist#page=116)).
- **White patches that bleed when wiped** are thrush: clean the denture and leave it out a while
  ([p. 115](lib:where-there-is-no-dentist#page=115)).
- A poor fit makes the corners of the mouth crack and sore ([p. 117](lib:where-there-is-no-dentist#page=117)).
  Without teeth people can't chew enough to stay healthy ([p. 174](lib:where-there-is-no-dentist#page=174)):
  cook soft food for them ([p. 115](lib:where-there-is-no-dentist#page=115)).

## 👵 Older people and the frail
<!-- fold: Thirst, dizziness and falls, medicines that build up, confusion, and checking on elders -->

- **Water:** older people may lose their sense of thirst and drink less to avoid getting up at night.
  About 2 liters (8 cups) a day ([WWHND, p. 126](lib:where-women-have-no-doctor-08-growing-older#page=5)).
- **Food:** "they will become even weaker if they do not eat well"
  ([WTND, p. 323](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=1)): a fair share of the
  ration ([Food When It's Scarce](guide:FOOD-SECURITY-GUIDE)).
- **Dizzy on standing** makes falls likely. Sit up first, sit on the bed edge, then stand; something to
  hold; no walking while dizzy; sit to wash and cook ([CDC STEADI, p. 2](lib:postural-hypotension#page=2)).
  Leg strength: the chair-rise exercise ([STEADI](lib:chair-rise-exercise#page=1)); more in
  [Rehab](guide:REHAB-GUIDE) ("Balance and walking again"; "Children and older people").
- **Medicines hit harder.** By 80 the kidneys work at about half, so "assume at least a mild degree of
  renal impairment" ([WHO Formulary, p. 622](lib:who-model-formulary-2008#page=622)). The books start the
  old on smaller doses: amlodipine and enalapril at 2.5 mg ([MSF, p. 396](lib:msf-clinical-guidelines#page=396)),
  amitriptyline at half ([p. 368](lib:msf-clinical-guidelines#page=368)), rectal diazepam not over 10 mg
  ([p. 25](lib:msf-clinical-guidelines#page=25)). Sugar pills cause more lows
  ([WHO, p. 392](lib:who-model-formulary-2008#page=392)); antipsychotics bring falls and chilling
  ([p. 466](lib:who-model-formulary-2008#page=466)).
- **Sudden confusion is not old age.** It may be too much medicine, infection, hunger, dehydration, a
  bladder infection or depression, and often clears when these are treated. Dementia comes slowly: keep
  routines, familiar things, a calm slow voice, yes-or-no questions, and share the caregiving
  ([WWHND, p. 135](lib:where-women-have-no-doctor-08-growing-older#page=14); [Dementia](wiki:Dementia)).
- **Someone checks on each elder** ([Red Cross, p. 8](lib:disaster-preparedness-for-seniors#page=8);
  [Community & Barter](guide:COMMUNITY-BARTER-GUIDE), "Children, elders and neighbors who need help").
  Heat, cold and the bedridden: [Field Care](guide:FIELD-CARE-GUIDE) ("Heat and cold"; "Nursing a
  bedridden person for days and weeks").

## 🕯️ When someone can no longer be kept well
<!-- fold: Honest talk, comfort and pain medicines at the end, and looking after the family -->

Some illnesses are held off only by things that may not come back: **type 1 diabetes without insulin,
kidney failure without dialysis, severe lung disease without oxygen, some heart failure.** When those are
gone, the work changes from curing to caring.
- **Talk early, while the person can still decide.** Let them make their own decisions, talk about death
  if they want, and say what they are grateful for or worried about. "It does not help to act as if the
  person is not dying" ([WWHND, p. 309](lib:where-women-have-no-doctor-17-hiv#page=28)).
- **Tell the truth gently.** "If a person who is dying asks for the truth, tell her, but tell her gently,
  and leave some room for hope." "In the last hours, love and acceptance will do far more good than
  medicines" ([WTND, p. 330](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=8)).
- **Their wishes count.** Some ask to be allowed to die rather than see their family go hungry to keep them
  alive, "and there are times when this may be the wise decision" (same page).
- **Near the end** they may be unconscious, stop eating, breathe very slowly or fast and unevenly, and stop
  passing urine ([WWHND, p. 309](lib:where-women-have-no-doctor-17-hiv#page=28)). Family and friends sit
  with them.
- **Scarce medicine** (the last insulin, the last oxygen) is a decision for the whole group, made openly
  and early, not by whoever holds the key *(rule of thumb)*: [Community & Barter](guide:COMMUNITY-BARTER-GUIDE)
  ("Meetings and fair decisions").
- **Then look after the carers** and the grieving ([Community & Barter](guide:COMMUNITY-BARTER-GUIDE),
  "Grief, stress and psychological first aid").

### Comfort and pain medicines

"Pain medicines work best if you take them before the pain gets very bad". Without medicine: distraction,
music, raising swollen parts, soft bedding, a dark quiet room for headache
([WWHND, p. 308](lib:where-women-have-no-doctor-17-hiv#page=27)); turning, mouth care and washing
([Field Care](guide:FIELD-CARE-GUIDE), "Nursing a bedridden person for days and weeks"). WWHND's ladder:
paracetamol, aspirin or ibuprofen first, codeine if stronger is needed, "morphine if the pain is very bad"
(same page).

| Medicine | Usual adult dose (book, page) | Children | Watch for / don't use if |
|---|---|---|---|
| **Paracetamol** (acetaminophen) | WTND: "500 mg to 1 g" 4 times a day; "Do not take more than 4000 mg (8 tablets) a day" ([p. 380](lib:where-there-is-no-doctor-24-green-pages#page=42)). WHO: "0.5–1 g every 4–6 hours, maximum 4 g daily" ([p. 45](lib:who-model-formulary-2008#page=45)) | WTND, each dose: "children 8 to 12 years: 375 mg"; "3 to 7 years: 250 mg"; "1 year to 2 years: 125 mg"; "under 1 year: 62 mg" | Too much poisons the liver; count every product that contains it (WTND; [Medical guide](guide:Medical-READ-ME-FIRST)) |
| **Ibuprofen** | WTND: "200 to 400 mg" every 6 to 8 hours, not more than "3200 mg a day" ([p. 381](lib:where-there-is-no-doctor-24-green-pages#page=43)). WHO: "1.2–1.8 g daily in 3–4 divided doses", "maximum 2.4 g daily" ([p. 44](lib:who-model-formulary-2008#page=44)) | Not more than "40 mg/kg a day" (WTND) | With food. Not if allergic to aspirin, not in pregnancy (WTND); stomach bleeding, kidney and heart failure in the old ([WHO, pp. 44–45](lib:who-model-formulary-2008#page=45)) |
| **Morphine** by mouth (plain tablets or liquid) | "5–20 mg regularly every 4 hours; dose may be increased according to need" ([WHO, p. 48](lib:who-model-formulary-2008#page=48)); an extra dose for breakthrough pain is "about one sixth of the total daily dose" ([p. 46](lib:who-model-formulary-2008#page=46)) | By weight: [WHO Children, pp. 42–43](lib:who-model-formulary-for-children#page=42) | Slow breathing; constipation. "reduce dose or avoid in elderly and debilitated patients" ([WHO, p. 47](lib:who-model-formulary-2008#page=47)). Never crush slow-release tablets ([p. 48](lib:who-model-formulary-2008#page=48)) |

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| In a fit, "Insert in the mouth something that he cannot swallow, such as a stick, or a pocket-knife wrapped in handkerchief" ([Kephart 1916, p. 439](lib:kephart-camping-and-woodcraft-vol-2#page=439)) | **Nothing in the mouth**: "no food, drink, medicine, nor any object" ([WTND, p. 178](lib:where-there-is-no-doctor-13-some-very-common#page=28); [MSF, p. 22](lib:msf-clinical-guidelines#page=22)) |
| "In the event of convulsions, put padded material between the teeth" ([WHO *Vector Control* 1997, p. 408](lib:vector-control-methods#page=408)) | The same: nothing in the mouth; on the side when it stops |
| "Asthma Cigarettes" of belladonna, stramonium and digitalis leaves, one with sodium arseniate ([Henley's 1916, p. 103](lib:henleys-twentieth-century#page=103)) | Jimsonweed (stramonium) is poisonous ([WSU, p. 30](lib:wsu-selected-poisonous-plants#page=30)), and smoke brings on attacks ([WTND, p. 167](lib:where-there-is-no-doctor-13-some-very-common#page=17)). Use the rescue inhaler with a spacer |
| For a heavy drinker, "Give him some liquor at judicious intervals"; "inject strychnine"; for DTs "trional, veronal, or a bromide" ([Kephart, pp. 438–439](lib:kephart-camping-and-woodcraft-vol-2#page=438)) | Alcohol withdrawal can kill: never leave them alone, keep the room lit, and use the diazepam plan under "Never stop suddenly" ([MSF, p. 363](lib:msf-clinical-guidelines#page=363); [Ship's, pp. 108–110](lib:ships-medicine-chest#page=108)) |
| "Hysteria.—Do nothing. Appear quite indifferent. A show of sympathy will only make matters worse" ([Kephart, p. 439](lib:kephart-camping-and-woodcraft-vol-2#page=439)) | Listen and help the person feel calm ([WHO PFA, p. 28](lib:psychological-first-aid-guide-for-field-workers#page=28)); first rule out illness, poisoning and withdrawal ([WWHND, p. 413](lib:where-women-have-no-doctor-27-mental-health#page=2)) |
| A spacer made of two plastic cups taped together ([WTND, p. 386](lib:where-there-is-no-doctor-24-green-pages#page=48)) | "The use of a plastic cup instead of a spacer is not recommended (ineffective)": use a plastic bottle ([MSF, p. 106](lib:msf-clinical-guidelines#page=106)) |

## 🖼️ Pictures & diagrams

🖼️ = drawings in the books on this drive; 📋 = forms to copy; the plain links open photos in the offline Wikipedia.

- **Records and doses:** [📋 dosage cards for people who can't read](lib:where-there-is-no-doctor-29-dosage-blanks#page=1); [📋 patient report to send for help](lib:where-there-is-no-doctor-29-dosage-blanks#page=5); cutting tablets and children's share of an adult dose — [🖼️ WTND, pp. 60](lib:where-there-is-no-doctor-08-how-to-measure#page=2), [🖼️ 62](lib:where-there-is-no-doctor-08-how-to-measure#page=4); [Medical ID tag](wiki:Medical_identification_tag)
- **Blood pressure:** the three kinds of cuff — [🖼️ WTND, p. 412](lib:where-there-is-no-doctor-25-additional#page=12); [Sphygmomanometer](wiki:Sphygmomanometer); signs of heart trouble — [🖼️ p. 325](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=3); habits that cause heart disease — [🖼️ p. 326](lib:where-there-is-no-doctor-22-health-and-sicknesses#page=4)
- **Diabetes:** [Insulin pen](wiki:Injector_pen); [Glucose meter](wiki:Glucose_meter); a clay-pot cooler — [🖼️ how it works, Practical Action p. 2](lib:practical-action-clay-pot-cooler#page=2), [🖼️ pot sizes, p. 3](lib:practical-action-clay-pot-cooler#page=3)
- **Breathing:** sitting up to breathe — [🖼️ WTND, p. 167](lib:where-there-is-no-doctor-13-some-very-common#page=17); homemade spacers — [🖼️ p. 386](lib:where-there-is-no-doctor-24-green-pages#page=48); draining the chest — [🖼️ p. 169](lib:where-there-is-no-doctor-13-some-very-common#page=19); [Metered-dose inhaler](wiki:Metered-dose_inhaler); [Oxygen concentrator](wiki:Oxygen_concentrator)
- **Seizures and thyroid:** [Epilepsy](wiki:Epilepsy); [Goitre](wiki:Goitre); [Iodised salt](wiki:Iodised_salt)
- **Ears and teeth:** washing out ear wax — [🖼️ WTND, p. 407](lib:where-there-is-no-doctor-25-additional#page=7); [Hearing aid](wiki:Hearing_aid); a poorly fitting denture — [🖼️ *Where There Is No Dentist*, p. 117](lib:where-there-is-no-dentist#page=117); why false teeth help — [🖼️ p. 174](lib:where-there-is-no-dentist#page=174); [Dentures](wiki:Dentures)
- **Older people:** the chair rise — [🖼️ CDC STEADI](lib:chair-rise-exercise#page=1); caring for someone with dementia — [🖼️ WWHND, p. 135](lib:where-women-have-no-doctor-08-growing-older#page=14); helping someone who wants to die — [🖼️ p. 431](lib:where-women-have-no-doctor-27-mental-health#page=20)
- **Old remedies to avoid:** [Jimsonweed](wiki:Datura_stramonium)

## 🔗 Related guides

- [Medical books & found medicines](guide:Medical-READ-ME-FIRST) — identifying pills, expired medicines, storage, measuring doses, naloxone
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local hospitals, clinics and pharmacies
- [Field Care](guide:FIELD-CARE-GUIDE) — "Nursing a bedridden person for days and weeks", "Heat and cold", "Knowing when someone can't be saved"
- [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE) — "Setting and running a fair ration", "Hunger diseases: spot them, prevent them"
- [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) — "Grief, stress and psychological first aid", "Children, elders and neighbors who need help"
- [Rehab](guide:REHAB-GUIDE) — "After long bed rest", "Balance and walking again", "Stroke and spine injuries: the basics"
- [Root Cellar](guide:ROOT-CELLAR-GUIDE) ("Cooling without power"), [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) — keeping insulin cool, powering oxygen
- [Wildfire](guide:WILDFIRE-GUIDE) — "Smoke, heat and people" for asthma, COPD and heart disease
