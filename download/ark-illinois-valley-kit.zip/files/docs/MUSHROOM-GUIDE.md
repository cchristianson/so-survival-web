# 🍄 Mushroom Guide

How to identify, use, preserve and grow mushrooms in the Illinois Valley — and how not to die
doing it. The field guides, poisoning reports and growing manuals are in `Mushrooms\`
(`Identification`, `Poisoning-Safety`, `Uses-Growing-Preserving`). `Wild-Plants\` also has the
Forest Service *Wild Edible Mushrooms of the Pacific Northwest* and death cap ID sheets.

> ### ⚠️ The rules that keep foragers alive
> 1. **Only eat a mushroom you have identified with complete certainty** — every feature,
>    including the spore print and the base of the stem. "Pretty sure" is how people die.
> 2. **No folk test works.** Silver turning dark, a peeling cap, animals or insects eating it,
>    soaking in salt water, cooking — none of these tell you anything. **Cooking, drying,
>    freezing and canning do not destroy the deadly toxins.**
>    ([FDA *Bad Bug Book*, p. 218](lib:fda-bad-bug-book#page=218))
> 3. **The deadliest ones taste fine and make you sick late** — 6 to 24 hours or more after
>    eating. By then the toxin is already in your liver or kidneys.
> 4. **Dig up the whole mushroom** — the cup or bulb at the base is what tells you it's a deadly
>    Amanita. Never eat unopened "buttons" of gilled mushrooms; nobody can tell a deadly button
>    from a safe one. ([USDA FB 796, pp. 3, 6](lib:usda-farmers-bulletin-796#page=3))
> 5. **Cook every wild mushroom thoroughly. Try a small amount of any new kind**, eat in
>    moderation, and **keep one uncooked specimen** in the fridge in case someone gets sick.
>    ([PNW/BC *White Paper*, p. 10](lib:pnw-and-bc-white-paper#page=10))

---

## 🔎 How to identify a mushroom

> 📷 **Have a photo?** The [plant and mushroom identifier](guide:PLANT-ID) (🔧 Tools tab) suggests names and flags deadly groups. Never eat a mushroom on its word: confirm every feature below, with a spore print.

Check **all** of these, every time:

- **Underside:** gills (thin blades), pores (a sponge of tubes — [boletes](wiki:Bolete)), teeth or spines
  (hedgehogs), or blunt ridges (chanterelles). (See [gills](wiki:Lamella_(mycology)); [🖼️ labeled drawing of the parts](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=10); [🖼️ gills, pores, ring and cup](lib:usda-farmers-bulletin-796#page=4).)
- **Stem base:** dig it up. A **cup (volva)** or bulb at the base, plus a **ring** on the stem
  and **white gills**, means **Amanita — leave all of them alone.** (FB 796) (See
  [volva](wiki:Volva_(mycology)) and [ring](wiki:Annulus_(mycology)); [🖼️ a death cap dug up, showing both](lib:bc-forests-death-cap#page=1); [🖼️ the "egg" the cup comes from](lib:gussow-and-odell#page=47).)
- **Spore print:** cut off the stem of a mature cap, lay the cap gills-down on half white,
  half dark paper, cover with a glass, and wait a few hours. The color (white, pink, brown,
  rusty, purple-black) places the mushroom in its family.
  ([Thomas *Field Book*](lib:thomas-field-book#page=29); [Atkinson, p. 373](lib:atkinson-studies-of-american-fungi#page=373); pictures: [Spore print](wiki:Spore_print); [🖼️ a spore print](lib:hard-the-mushroom-edible-and-otherwise#page=35))
- **Where it grows:** on wood or soil, under which trees ([oak](wiki:Oak), [tanoak](wiki:Notholithocarpus), [Douglas-fir](wiki:Douglas_fir), pine), alone
  or in clumps, and the season.
- **Flesh, smell and bruising:** does it stain when cut? Is the flesh brittle or stringy?

![Labeled drawing of a mushroom: cap with scales, gills underneath, a ring (annulus) on the stem, and a cup (volva) at the very base](img:MUSHROOM-GUIDE/parts-of-a-mushroom.png)
*The parts to check every time; the cup (volva) sits at the very base and stays in the ground if you snap the stem ([GTR-309, p. 10](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=10)).*

![Four steps of a spore print: cut off the stem, lay the cap gills-down on half white and half dark paper, cover it with a glass for a few hours, then lift it and read the color](img:MUSHROOM-GUIDE/making-a-spore-print.svg)
*Half white, half dark paper shows a print of any color; the color points to the family in the table below (a diagram drawn for this guide).*

**Spore print colors and what they point to:**

| Print color | Examples here | Note |
|---|---|---|
| **White** | Deadly Amanitas, oyster, shiitake, matsutake, false chanterelle | White alone proves nothing — the death cap is white-spored ([Hard, p. 40](lib:hard-the-mushroom-edible-and-otherwise#page=40); [GTR-576, p. 35](lib:usfs-pnw-gtr-576#page=35)) |
| **Yellowish white** | Pacific golden chanterelle | ([GTR-576, p. 38](lib:usfs-pnw-gtr-576#page=38)) |
| **Pink to salmon** | [Pluteus](wiki:Pluteus), [Entoloma](wiki:Entoloma) | ([Hard, p. 255](lib:hard-the-mushroom-edible-and-otherwise#page=255)) |
| **Rusty to brown** | **Deadly Galerina**, [Cortinarius](wiki:Cortinarius) webcaps, poison pax | **A brown print on a "shiitake" means Galerina** ([Cornell-UVM, p. 41](lib:cornell-uvm-best-management#page=41)) |
| **Purple-brown** | Agaricus ([meadow mushroom](wiki:Agaricus_campestris) family) | ([Hard, p. 327](lib:hard-the-mushroom-edible-and-otherwise#page=327)) |
| **Black** | Inky caps | ([Hard, p. 351](lib:hard-the-mushroom-edible-and-otherwise#page=351)) |

**Collecting, step by step:**

1. Carry a basket, a knife, a trowel and **paper bags or wax paper**. Plastic makes mushrooms
   sweat and rot. ([Thomas, p. 29](lib:thomas-field-book#page=29))
2. **Dig out the whole mushroom** — don't snap the stem — so the base stays attached.
3. **Keep each kind in its own bag.** Some poisons sicken people even from a sauce the mushroom
   was cooked in ([*Bad Bug Book*, p. 218](lib:fda-bad-bug-book#page=218)), so one stray deadly
   cap in a basket of edibles is a real danger.
4. Note the tree, the ground, the date. Take a photo of the spot.
5. At home, sort on a clean table, make spore prints, and **throw out anything you can't
   name with certainty** — and wash your hands.
6. **Learn from someone who knows.** CDC's advice after the 2016 California outbreak: have wild
   mushrooms checked by an experienced mycologist before eating
   ([CDC MMWR 2017, p. 4](lib:cdc-mmwr-amanita-phalloides#page=4)). In Switzerland, where
   trained checkers inspect foragers' baskets, none of the checked mushrooms caused a
   hospitalization in 15 years ([*White Paper*, p. 11](lib:pnw-and-bc-white-paper#page=11)).

📚 **Go deeper:** [*Wild Edible Mushrooms of the PNW* (USFS PNW-GTR-309)](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=10) — labeled drawing of mushroom parts and the life cycle; [Thomas *Field Book*](lib:thomas-field-book#page=29) — how to collect, and a key by spore color; [Atkinson](lib:atkinson-studies-of-american-fungi#page=373) — making spore prints, many photos. Pictures: [Mushroom](wiki:Mushroom).

## ☠️ The killers that grow around here

| Mushroom | What it looks like | What it does |
|---|---|---|
| **[Death cap](wiki:Amanita_phalloides)** (*Amanita phalloides*) | Greenish-olive to yellowish or white cap, white gills, white ring, **bulb in a cup at the base**. Under **oaks and filberts (hazelnuts)**, wet season. | **Liver failure.** One cap can kill an adult. Poisoned 5 Oregonians in 1988; 4 needed liver transplants (Pinson et al., *Am J Surg* 1990). |
| **[Western destroying angel](wiki:Amanita_ocreata)** (*Amanita ocreata*) | All-white, cup at the base, under oaks. Oregon cases on record ([NAMA registry, p. 5](lib:nama-thirty-plus-years#page=5)). | Liver and kidney failure. |
| **[Deadly Galerina](wiki:Galerina_marginata)** (*Galerina marginata*) | Small, brown, on rotting wood, rusty-brown spore print, often a thin ring. Easily mistaken for "little brown" edibles ([🖼️ photo](lib:cornell-uvm-best-management#page=41)). | Same toxin as death cap. |
| **Deadly parasols** (small *Lepiota*, e.g. [*L. subincarnata*](wiki:Lepiota_subincarnata)) | Small, scaly-capped, white gills, on soil. | Same toxin as death cap. |
| ***[Amanita smithiana](wiki:Amanita_smithiana)*** | White, shaggy; grows right next to **matsutake** in our tanoak forests. Brittle flesh. | Kidney failure, 2–5 days later ([*White Paper*, p. 6](lib:pnw-and-bc-white-paper#page=6)). |
| **Deadly webcaps** (*Cortinarius*, orellanine; e.g. [*C. rubellus*](wiki:Cortinarius_rubellus)) | Orange to red-brown, dry, fibrous cap, rusty gills, under conifers ([🖼️ photos](lib:nama-deadly-cortinarius-rubellus#page=12)). | **Kidney failure, 3–14 days later.** |
| **False morels** (*[Gyromitra](wiki:Gyromitra_esculenta)*) | Brain-like or saddle-shaped cap, **not pitted**, chambered stem ([🖼️ photo](lib:michigan-health-dept#page=1)). | Vomiting, seizures, liver damage; fumes from cooking can poison the cook. |

([CDC 2017 death-cap report](lib:cdc-mmwr-amanita-phalloides#page=3); [NAMA poisoning registry](lib:nama-thirty-plus-years#page=5); [PNW/BC *White Paper*](lib:pnw-and-bc-white-paper#page=5); [USFS reports](lib:usfs-pnw-gtr-412#page=13))

**Death cap checklist** ([BC Forests profile, pp. 5–7](lib:bc-forests-death-cap#page=7); [🖼️ color photos](lib:bc-forests-death-cap#page=4); [🖼️ young and open caps](lib:bc-forests-death-cap#page=5); [🖼️ old photo: cup, ring, scaly stem](lib:hard-the-mushroom-edible-and-otherwise#page=42)): cap
**4–16 cm (1½–6 in)**, usually olive or greenish but can be pale brown, yellow or white, with a
satiny sheen when dry · white gills · a skirt-like ring · a loose, **sac-like cup at the base,
often below ground** · near hardwoods, especially planted ones. Fruits in fall, but **in summer
where lawns or orchards are watered** ([BCCDC briefing, p. 8](lib:bccdc-death-cap-mushrooms-in-city#page=8)).

![Old photographs of death caps: a whole "egg" and young and grown death caps dug up whole, each with a sac-like cup around the base of the stem](img:MUSHROOM-GUIDE/death-cap-egg-and-cup.png)
*Death caps dug up whole: the egg stage, and the loose cup that stays around the base, often below ground ([Gussow & Odell, p. 47](lib:gussow-and-odell#page=47)).*

- **How little it takes:** a lethal dose can be as low as 0.1 mg per kg of body weight, and one
  mushroom can hold up to 15 mg ([CDC MMWR 2017, p. 3](lib:cdc-mmwr-amanita-phalloides#page=3)).
  **Half a cap can kill a small child** ([*White Paper*, p. 8](lib:pnw-and-bc-white-paper#page=8)).
- **Boiling and pouring off the water doesn't help** ([BCCDC, p. 5](lib:bccdc-death-cap-mushrooms-in-city#page=5)).
- **Young death caps look like puffballs** — see the puffball slice test below ([🖼️ sliced side by side](lib:bc-forests-death-cap#page=6); [🖼️ more look-alikes](lib:bccdc-death-cap-mushrooms-in-city#page=7)).
- **Dogs die from it too** — puppies especially ([BC Forests, p. 8](lib:bc-forests-death-cap#page=8)).

![Old drawing of an Amanita growing from its egg: eggs in the ground, an egg cut open showing the cap and gills already formed inside, and grown mushrooms with a veil on the stem and the cup labeled "poison cup" at the base](img:MUSHROOM-GUIDE/amanita-growing-from-its-egg.png)
*An Amanita breaks out of its egg and leaves the cup at the base; cut open, the egg already shows a cap and gills, while a puffball is solid white all through ([Thomas, p. 43](lib:thomas-field-book#page=43)).*

**Poisoning timeline — deadly Amanita, Galerina, Lepiota:** nothing for **6–24 hours**, then
violent vomiting and diarrhea, then a **false recovery** around day 1–2, then liver (and kidney)
failure at **day 3–5**. 10–20% die even with hospital care.
([CDC MMWR 2017, p. 3](lib:cdc-mmwr-amanita-phalloides#page=3)) *Sources differ on the death
rate:* BC public health says 10–30% even with treatment
([BCCDC, p. 5](lib:bccdc-death-cap-mushrooms-in-city#page=5)); NAMA's records show about 11% of
people who got sick ([NAMA 2018–20, p. 3](lib:nama-mushroom-poisoning-reports-summary-2018#page=3));
FDA says 50–90% for people who reach care late, about 10% for those treated almost at once
([*Bad Bug Book*, p. 219](lib:fda-bad-bug-book#page=219)). Without a hospital, expect the worst.

**When did the symptoms start? A quick guide** ([*Bad Bug Book*, pp. 219–221](lib:fda-bad-bug-book#page=219);
[*White Paper*, p. 6](lib:pnw-and-bc-white-paper#page=6)):

| Symptoms begin | Likely cause | Usual outcome |
|---|---|---|
| **15 min – 2 hours:** nausea, cramps, diarrhea | Many "stomach upset" mushrooms | Recover in hours to 2–3 days; replace fluids |
| **15–30 min:** heavy sweating, tears, drooling | Muscarine (*[Clitocybe](wiki:Clitocybe)*, *[Inocybe](wiki:Inocybe)*) | Recover in about 2 hours |
| **1–2 hours:** drowsy, confused, excited | [Fly agaric](wiki:Amanita_muscaria) ([🖼️ old photo](lib:hard-the-mushroom-edible-and-otherwise#page=45)), [panther cap](wiki:Amanita_pantherina) | Recover after several hours |
| **About 6 hours:** bloated, bad headache, vomiting | False morel (gyromitrin), *Verpa* | Recover in 2–6 days; some deaths from liver failure |
| **6–24+ hours:** violent vomiting and watery diarrhea | **[Amatoxin](wiki:Amatoxin) — death cap, Galerina, small Lepiota** | False recovery, then liver failure; often fatal |
| **2–5 days:** kidney trouble | *Amanita smithiana* | Kidney failure |
| **2 days – 3 weeks:** burning thirst, peeing a lot, then kidney failure | **[Orellanine](wiki:Orellanine) — deadly webcaps** | Months to recover, or death |
| **½–2 hours after drinking alcohol**, within 3 days of eating: flushing, racing heart | [Inky cap](wiki:Coprinopsis_atramentaria) (coprine) | Passes in a few hours |

**The rule this table teaches: if symptoms start 6 hours or more after the meal, treat it as
deadly until proven otherwise** *(rule of thumb from the table above)*.

📚 **Go deeper:** [FDA *Bad Bug Book*, mushroom chapter](lib:fda-bad-bug-book#page=218) — each poison type, onset and outcome; [PNW/BC *White Paper*](lib:pnw-and-bc-white-paper#page=5) — color photos of our six deadliest; [BC Forests death cap profile](lib:bc-forests-death-cap#page=5) — death cap photos, look-alikes and host trees; [NAMA *Cortinarius rubellus* report](lib:nama-deadly-cortinarius-rubellus#page=6) — the kidney-destroying webcap.

## 🚑 If someone may have eaten a bad mushroom

- **Get medical help immediately, even if they feel fine** — the dangerous ones are delayed.
  Poison Control: **1-800-222-1222**.
- **Bring the mushroom** — leftovers, the uncooked ones, even scraps from the trash — in a
  **paper bag** (they rot in plastic). A photo is far less useful than a sample.
  ([*White Paper*, p. 6](lib:pnw-and-bc-white-paper#page=6); [Michigan sheet, p. 2](lib:michigan-health-dept#page=2))
- **The main hospital treatment for amatoxin is aggressive IV fluids** — NAMA calls it "by far
  the best single intervention" ([NAMA 2018–20, p. 4](lib:nama-mushroom-poisoning-reports-summary-2018#page=4);
  [CDC MMWR 2017, p. 3](lib:cdc-mmwr-amanita-phalloides#page=3)). Liver drugs such as silibinin
  (from [milk thistle](wiki:Silybum_marianum)) are tried, but proof is thin. *Sources disagree on activated charcoal:* FDA
  lists it as part of prompt treatment ([*Bad Bug Book*, p. 229](lib:fda-bad-bug-book#page=229)),
  CDC says it has no proven benefit for amatoxin, and NAMA says it's useless more than about
  **1 hour** after eating. **With no hospital:** replace fluids constantly ([oral rehydration
  solution](wiki:Oral_rehydration_therapy) — see the Medical guides), give [activated charcoal](wiki:Activated_carbon) only if they ate the mushroom
  within the last hour or so, and rest. Survival odds are much worse without a hospital — which
  is why rule 1 matters so much.
- **Don't be fooled by the false recovery.** In the 2016 California outbreak, people sent home
  with "stomach flu" came back in liver failure
  ([CDC MMWR 2017, p. 3](lib:cdc-mmwr-amanita-phalloides#page=3)). One Québec man with orellanine
  poisoning put up with mild symptoms for **18 days** before his kidneys failed
  ([NAMA 2021, p. 2](lib:nama-deadly-cortinarius-rubellus#page=2)).
- **Write down** *(rule of thumb)*: what was eaten and how much, raw or cooked, the time of the
  meal, the time symptoms started, who else ate it, and any alcohol. Check everyone who shared
  the dish — and any pets.

📚 **Go deeper:** [CDC MMWR 2017 death cap outbreak](lib:cdc-mmwr-amanita-phalloides#page=1) — 14 real cases, hour by hour; [NAMA 2018–2020 summary](lib:nama-mushroom-poisoning-reports-summary-2018#page=3) — what treatments work and which don't; [BCCDC *Wild Mushrooms May Be Poisonous*](lib:bccdc-wild-mushrooms-may-be-poisonous#page=1) — one-page symptoms and what to do.

## 🧺 Good edibles and their look-alikes

> 📷 **Have a photo?** The [plant and mushroom identifier](guide:PLANT-ID) (🔧 Tools tab) suggests names and flags deadly groups. Never eat a mushroom on its word: confirm every feature below, with a spore print.

| Edible | How to tell it | Watch out for |
|---|---|---|
| **[Chanterelle](wiki:Cantharellus_formosus)** (late summer–fall, under Douglas-fir and tanoak) | Golden; **blunt, shallow, forked ridges** that don't scrape off, running down a **solid** stem; grows from soil ([🖼️ photo](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=18)). | **[False chanterelle](wiki:Hygrophoropsis_aurantiaca)** (thin, crowded true gills that scrape off, white spore print); **[jack-o'-lantern](wiki:Omphalotus_olivascens)** (sharp true gills, big clumps on wood or buried roots, poisonous; [🖼️ picture](lib:gussow-and-odell#page=71)); [poison pax](wiki:Paxillus_involutus) (gills stain brown, poisonous); [scaly vase chanterelle](wiki:Turbinellus_floccosus) (hollow, scaly, red-orange vase — stomach upset; [🖼️ photo](lib:usfs-pnw-gtr-576#page=46)). ([USFS PNW-GTR-576, p. 35](lib:usfs-pnw-gtr-576#page=35); [GTR-309, p. 18](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=18)) |
| **[Hedgehog](wiki:Hydnum_repandum)** (fall through late spring) | Soft **spines/teeth** underneath instead of gills ([🖼️ photo](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=22)). No poisonings reported. | Nothing dangerous looks like it once you turn it over. ([GTR-309, p. 22](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=22)) |
| **[King bolete](wiki:Boletus_edulis) / [spring king](wiki:Boletus_rex-veris)** | Fat stem, **sponge of pores** underneath that peels away from the cap; pores white when young and **don't bruise blue** ([🖼️ photo](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=17)). | Avoid boletes with red or orange pores (like the [red-pored bolete](wiki:Rubroboletus_pulcherrimus)) or that bruise blue fast; eat small amounts at first. ([GTR-309, p. 17](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=17)) |
| **[Morels](wiki:Morchella)** (spring; **burn areas the year after a fire**) | **Pitted, honeycomb cap** joined to the stem, **hollow from top to bottom** when sliced lengthwise ([🖼️ true vs. false morel vs. Verpa](lib:usfs-pnw-gtr-710#page=35)). | **[False morels](wiki:Gyromitra_esculenta)** (*Gyromitra*, brain-like, stuffed stem; [🖼️ photo](lib:michigan-health-dept#page=1)) and **[Verpa](wiki:Verpa_bohemica)** (cap hangs free like a thimble, attached only at the top). **Always cook morels thoroughly** — raw or undercooked morels killed 2 people in Montana in 2023. ([USFS PNW-GTR-710, p. 69](lib:usfs-pnw-gtr-710#page=69); [CDC 2024, p. 1](lib:cdc-mmwr-outbreak-linked-to-morel#page=1)) |
| **[Oyster](wiki:Pleurotus_ostreatus)** | Shell-shaped caps, white gills running down to a short side stem, on dead hardwood (cottonwood, alder) ([🖼️ photo](lib:hard-the-mushroom-edible-and-otherwise#page=173)). | Pale **[angel wings](wiki:Pleurocybella_porrigens)** on conifer wood — skip them. |
| **[Chicken of the woods](wiki:Laetiporus)** | Bright sulfur-yellow to orange shelves, pores not gills, on oak and other trunks. | Upsets some people's stomachs — cook well, eat a little the first time. |
| **[Matsutake](wiki:Tricholoma_murrillianum)** | White to tan, spicy-cinnamon smell, **stringy flesh that peels like string cheese** ([🖼️ photo](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=27); [🖼️ more](lib:usfs-pnw-gtr-412#page=37)). | ***[Amanita smithiana](wiki:Amanita_smithiana)*** grows beside it — brittle flesh, no spicy smell ([🖼️ photo, Fig. 1E](lib:pnw-and-bc-white-paper#page=5)). ([USFS PNW-GTR-412, p. 13](lib:usfs-pnw-gtr-412#page=13)) |
| **[Puffballs](wiki:Puffball)** | Round, no stem or gills. **Slice top to bottom: must be pure white and solid like marshmallow** ([🖼️ giant puffball](lib:hard-the-mushroom-edible-and-otherwise#page=553); [giant puffball photos](wiki:Calvatia_gigantea)). | Any outline of a cap and gills inside = an Amanita button ([🖼️ sliced puffball vs. sliced death-cap button](lib:bc-forests-death-cap#page=6); [🖼️ death-cap "egg"](lib:gussow-and-odell#page=47)). Yellow, brown or purple inside = discard (e.g. an [earthball](wiki:Scleroderma_citrinum)). ([BC Forests, p. 6](lib:bc-forests-death-cap#page=6)) |
| **[Lobster mushroom](wiki:Hypomyces_lactifluorum)** | Bright orange-red crust over a deformed mushroom ([🖼️ photo](lib:hard-the-mushroom-edible-and-otherwise#page=519)). | Must be cooked. |

**More on the tricky ones:**

- **True morel or not?** In a true morel the cap joins the stem at the bottom of the cap or no
  more than halfway up, and the inside is one hollow space. A *Verpa* cap hangs free like a
  thimble; a *Gyromitra* is wrinkled like a brain, never pitted
  ([Michigan sheet, pp. 1–2](lib:michigan-health-dept#page=1); [🖼️ Verpa and true-morel photos](lib:michigan-health-dept#page=2)).
- **Gyromitra fumes:** its toxin boils off at about **190 °F**, so the cook breathing the steam
  can be poisoned, and it lingers in the cooking water. It builds up in the body — one meal can
  hit hard even if earlier meals didn't ([GTR-710, p. 69](lib:usfs-pnw-gtr-710#page=69)).
- **Morels can turn on you:** some people become sensitized and react after years of eating them
  without trouble ([Michigan sheet, p. 2](lib:michigan-health-dept#page=2)).
- **Matsutake country is right here:** the Forest Service maps a matsutake habitat — tanoak,
  Douglas-fir and [golden chinkapin](wiki:Chrysolepis_chrysophylla), 1,800–3,000 ft — in the **Illinois Valley from the Elk Creek
  to the Deer Creek drainages**, best on ridges and north-to-northeast slopes, fruiting in the
  hardwood-leaf duff ([GTR-412, p. 26](lib:usfs-pnw-gtr-412#page=26); [🖼️ Klamath matsutake habitat](lib:usfs-pnw-gtr-412#page=40); [🖼️ a button in tanoak litter, SW Oregon](lib:usfs-pnw-gtr-412#page=41)). That is also *Amanita
  smithiana* country.

**Season calendar** (timing shifts with rain and elevation):

| Season | What to look for | Source |
|---|---|---|
| **Early spring** | Morels; on burns, the **first spring after a fall fire**, fewer the second year | [GTR-710, pp. 26, 28](lib:usfs-pnw-gtr-710#page=26) |
| **Spring** | Spring king bolete | [*White Paper*, p. 13](lib:pnw-and-bc-white-paper#page=13) |
| **Late summer – fall** | Chanterelles (timing follows the rain) | [GTR-309, p. 18](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=18) |
| **Fall rains** | Matsutake (soon after the rains start), king bolete at low elevation | [GTR-309, pp. 17, 27](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=27) |
| **Fall – late spring** | Hedgehogs | [GTR-309, p. 22](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=22) |
| **Late Aug – early Nov** (earlier where watered; BC data) | **Death cap** season | [BCCDC, p. 8](lib:bccdc-death-cap-mushrooms-in-city#page=8) |

**Burn morels after a wildfire:** in western Oregon's mountains, morels fruit the first year after
logging or wildfire ([GTR-710, p. 102](lib:usfs-pnw-gtr-710#page=102)). Skip spots stained with
**orange fire-retardant** and **ground near highways** — morels soak up metals, and one batch picked
1,500 feet from a highway held worrying lead ([GTR-710, pp. 70–71](lib:usfs-pnw-gtr-710#page=70)).
Wild mushrooms also took up radioactive fallout after Chernobyl ([GTR-710, p. 70](lib:usfs-pnw-gtr-710#page=70)) — see the Nuclear Fallout guide.

📚 **Go deeper:** [*Chanterelle Mushrooms* (USFS PNW-GTR-576)](lib:usfs-pnw-gtr-576#page=35) — key separating true chanterelles from look-alikes; [*Morels of Western North America* (PNW-GTR-710)](lib:usfs-pnw-gtr-710#page=68) — morels, false morels, toxins and drying; [*American Matsutake* (PNW-GTR-412)](lib:usfs-pnw-gtr-412#page=13) — our tanoak matsutake and its deadly neighbor; [PNW/BC *White Paper* edible list](lib:pnw-and-bc-white-paper#page=13) — which PNW species are widely eaten and their known risks.

## 🫙 Cooking, drying and storing

- **Cook all wild mushrooms** — never raw, and morels especially well done. Don't mix alcohol
  with morels the first time (some people react).
- **Eat a few mouthfuls, not a plateful,** of any wild mushroom, and not several days running
  — big servings cause reactions even with "safe" kinds like morels
  ([*White Paper*, pp. 10–11](lib:pnw-and-bc-white-paper#page=10)). In 1991, 77 of 483 guests at a
  Vancouver banquet got sick from morels served raw ([p. 10](lib:pnw-and-bc-white-paper#page=10)).
- **Fresh storage:** in the refrigerator (40 °F or colder) **in a paper bag** — CDC's advice
  for morels ([CDC 2024, p. 5](lib:cdc-mmwr-outbreak-linked-to-morel#page=5)). Don't freeze them raw —
  bacteria keep growing ([NAMA 2018–20, p. 2](lib:nama-mushroom-poisoning-reports-summary-2018#page=2)).
- **Dry** slices about ½ inch thick at about **120 °F** with good airflow ([dehydrator](wiki:Food_dehydrator)) until crisp; morels
  lose about 90% of their weight. Store airtight. Rehydrate in hot water. Ventilate while drying —
  spores can trigger asthma. ([OSU SP 50-919, p. 2](lib:sp-50-919#page=2); [USFS PNW-GTR-710, pp. 66–67](lib:usfs-pnw-gtr-710#page=66))
- **No dehydrator?** In warm, dry weather, dry on screens, threaded on fishing line, or in a
  single layer on a tarp, turning them; or use the warm air near a wood stove with a fan. **Moving
  dry air matters more than heat — don't go over 120 °F** ([GTR-710, pp. 66–67](lib:usfs-pnw-gtr-710#page=66)).
  Shiitake dried in sunlight gain vitamin D; 7 lb fresh makes about 1 lb dried
  ([Agroforestry Note 13, p. 4](lib:agroforestry-note-13#page=4)).
- **Freeze** after sautéing (best) or steam-blanching. To steam: soak 5 minutes in 1 teaspoon
  lemon juice per pint of water, then steam **whole 5 minutes, quarters 3½, slices 3**, cool in
  ice water, pack and freeze ([OSU SP 50-919, p. 2](lib:sp-50-919#page=2)).
- **Never can wild mushrooms** — only store-type button mushrooms have tested canning times
  ([OSU SP 50-919, p. 1](lib:sp-50-919#page=1)). Improperly canned chanterelles gave diners
  **[botulism](wiki:Botulism)** in Vancouver in 1987 ([*White Paper*, p. 10](lib:pnw-and-bc-white-paper#page=10)).
- **Recipes from the old books** — fine for cooking ideas once the mushroom is safely identified:
  McIlvaine's 15-page recipe chapter ([p. 813](lib:mcilvaine-one-thousand-american-fungi#page=813)),
  Mrs. Rorer's recipes in Atkinson ([p. 379](lib:atkinson-studies-of-american-fungi#page=379)),
  Gibson ([p. 321](lib:gibson-our-edible-toadstools#page=321)) and Thomas
  ([p. 381](lib:thomas-field-book#page=381)). **Skip their raw-mushroom salads** and anything
  about canning.

📚 **Go deeper:** [OSU *Preserving Mushrooms* SP 50-919](lib:sp-50-919#page=1) — freezing, drying and why only button mushrooms can be canned; [*Morels of Western North America*](lib:usfs-pnw-gtr-710#page=66) — drying with and without power; [McIlvaine recipe chapter](lib:mcilvaine-one-thousand-american-fungi#page=813) — old-time cooking and drying methods.

## 🪵 Growing your own

- **Shiitake on logs:** fresh hardwood logs (oak is among the best) **4–6 inches across**, cut
  in the dormant season while the bark is tight. Drill holes **7/16 inch wide, 1¼ inches deep,
  3 inches apart** in a diamond pattern, plug with spawn, seal with wax ([🖼️ drill, plug, wax](lib:cornell-uvm-best-management#page=20)). Keep shaded and moist.
  Mushrooms start in **6–18 months**; after that, **soak a log 24 hours** and it fruits about a
  week later. Rest logs 8–12 weeks between soaks.
  ([UVM/Cornell, p. 20](lib:cornell-uvm-best-management#page=20); [USDA Agroforestry Note 13, p. 3](lib:agroforestry-note-13#page=3))
- **Oysters on straw:** chop straw 4–5 inches, soak overnight, **pasteurize at 165 °F for 1–2
  hours**, mix in 5–10% spawn, pack into bags with holes, keep warm and humid. Fruits in weeks.
  ([UF IFAS SS662, p. 2](lib:uf-ifas-ss662#page=2); [🖼️ step-by-step photos](lib:uf-ifas-ss662#page=2))
- **Keep your strain going:** a piece of a fruiting log or colonized straw can start the next
  batch, so you don't need to buy spawn again.

**Shiitake details:**

- **Logs:** 3–8 inches across and 2–4 feet long. A 4-foot, 8-inch log can weigh 80 lb. Cut from
  **live** trees roughly **Thanksgiving to St. Patrick's Day**, and inoculate within two weeks
  ([Agroforestry Note 13, pp. 2–3](lib:agroforestry-note-13#page=2)).
- **Hole spacing:** *the sources differ* — Cornell says 3 inches apart with as many rows as the log
  has inches of diameter ([p. 20](lib:cornell-uvm-best-management#page=20)); the USDA note says
  6 inches apart with one row fewer ([p. 3](lib:agroforestry-note-13#page=3)). Either way, stagger
  the rows in a diamond pattern.
- **Spawn:** one 5-lb bag of sawdust spawn does about **20–25 logs** 4–6 inches by 3 feet
  ([Cornell-UVM, p. 21](lib:cornell-uvm-best-management#page=21)).
- **Laying yard** ([🖼️ ways to stack logs](lib:agroforestry-note-13#page=3)): **75–100% shade** all year — under conifers is best; the north side of a house
  or shed works for a few logs. Keep logs above **30% moisture**; in a dry spell soak them a few
  hours or sprinkle them ([Cornell-UVM, p. 23](lib:cornell-uvm-best-management#page=23)).
- **Harvest** when caps are 60–75% open, edge still slightly curled under
  ([Agroforestry Note 13, p. 4](lib:agroforestry-note-13#page=4); [Cornell-UVM, p. 39](lib:cornell-uvm-best-management#page=39)).
  Logs keep producing for **up to 6 years**; **about 10 logs** feed a family.
- **Check every brown mushroom on your logs.** Deadly Galerina can pop up on shiitake logs. Make a
  spore print: **shiitake is white, Galerina brown**; shiitake never has a ring
  ([Cornell-UVM, p. 41](lib:cornell-uvm-best-management#page=41); [🖼️ Galerina photo](lib:cornell-uvm-best-management#page=41); [Galerina](wiki:Galerina_marginata) vs. [shiitake](wiki:Shiitake) photos).

![A shiitake log seen from the side with holes in staggered rows making diamonds, a cut-open hole filled with spawn and sealed with wax, and the end of a 4-inch log with four rows around it](img:MUSHROOM-GUIDE/shiitake-log-drilling.svg)
*Cornell's spacing: holes 7/16 in wide and 1¼ in deep, 3 in apart, rows staggered into diamonds, one row per inch of log width; the USDA note spaces them 6 in (a diagram drawn for this guide).*

![Three old drawings of shiitake logs stacked in a shady laying yard: criss-cross, lean-to and X pattern](img:MUSHROOM-GUIDE/stacking-shiitake-logs.png)
*Three ways to stack logs in the shady laying yard ([Agroforestry Note 13, p. 3](lib:agroforestry-note-13#page=3)).*

**Oyster details** ([UF SS662, pp. 2–4](lib:uf-ifas-ss662#page=3); [🖼️ bags as they colonize and fruit](lib:uf-ifas-ss662#page=3)): incubate filled bags in the dark
at **75–77 °F** and 80–90% humidity until white all through ([mycelium](wiki:Mycelium), 2–3 weeks); then give them light,
about **68 °F**, 90% humidity and fresh air. Pick clusters by twisting. Expect **2–4 more flushes**.

**If this goes wrong:**

| Problem | What to do |
|---|---|
| Logs haven't fruited after 18 months | Check the log ends for white mycelium. Force with a 24-hour cold soak once nights average above 50 °F ([Cornell-UVM, p. 32](lib:cornell-uvm-best-management#page=32)). |
| First flush was tiny | Normal. Try again about two months later ([p. 32](lib:cornell-uvm-best-management#page=32)). |
| Slugs eating the crop | Pick slugs by flashlight at night, let chickens into the yard by day, put gravel under fruiting logs ([p. 38](lib:cornell-uvm-best-management#page=38)). |
| Green or black mold on logs | Competing fungi. Logs often still fruit; pull out badly infected ones so spores don't spread ([p. 28](lib:cornell-uvm-best-management#page=28)). |
| Mold in an oyster bag | Throw out badly contaminated bags; a partly contaminated one may still give one flush ([UF SS662, p. 4](lib:uf-ifas-ss662#page=4)). |
| Oyster bag is white but won't fruit | It needs a cooler spot, light, high humidity and fresh air ([UF SS662, p. 3](lib:uf-ifas-ss662#page=3)). |

📚 **Go deeper:** [Cornell-UVM *Log-Based Shiitake*](lib:cornell-uvm-best-management#page=16) — every step from cutting logs to harvest, with growers' tips; [USDA Agroforestry Note 13](lib:agroforestry-note-13#page=2) — shiitake, oyster and lion's mane on logs in a woodlot; [UF *Grow Your Own Oyster Mushrooms*](lib:uf-ifas-ss662#page=2) — oysters on straw in bags.

## 🌿 Medicinal mushrooms

**[Turkey tail](wiki:Trametes_versicolor), [reishi](wiki:Ganoderma_lucidum), [lion's mane](wiki:Hericium_erinaceus) and [shiitake](wiki:Shiitake)** have real research behind them as *add-ons*
to treatment — turkey-tail extract (PSK) is a prescribed cancer add-on in Japan — but most
evidence is from lab and animal studies. They are **not cures**. Turkey tail and reishi are
traditionally simmered for hours as tea. ([VA *Mycomedicinals*, pp. 1–3](lib:va-whole-health-mycomedicinals#page=1))

- **Making the tea:** simmering or boiling in water for **20 minutes to 2 hours** breaks down the
  tough cell walls and releases the active compounds
  ([VA, p. 1](lib:va-whole-health-mycomedicinals#page=1)).
- **Who should be careful:** people with leukemia or lymphoma, after a bone-marrow transplant,
  or on drugs that suppress the immune system — these mushrooms act on the immune system
  ([VA, p. 3](lib:va-whole-health-mycomedicinals#page=3)).
- **No panacea:** in one mouse study a reishi extract made tumors grow *faster*
  ([GTR-309, p. 31](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=31)).

📚 **Go deeper:** [VA *Mycomedicinals*](lib:va-whole-health-mycomedicinals#page=1) — what the research shows for turkey tail, reishi, lion's mane and shiitake; [Agroforestry Note 13](lib:agroforestry-note-13#page=1) — growing lion's mane on logs.

---

*The old mushroom books here (1895–1928) are great for pictures, descriptions and recipes, but
some of their safety advice is wrong and has killed people: Marshall's* Mushroom Book *lists
false morels as edible, Thomas says the parasol has no poisonous look-alike, and USDA FB 796
recommends raw mushrooms and old first aid. Hard (1908) also calls a brown false morel edible
([p. 517](lib:hard-the-mushroom-edible-and-otherwise#page=517)), and the poisoning treatments in
Atkinson and McIlvaine are long outdated. They also miss most western killers. **Use the
modern files in `Poisoning-Safety` and this guide for anything about safety.***

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia. The old books (Hard, Gussow & Odell, Thomas, Atkinson, USDA FB 796) are here for their **pictures only** — see the warning above.

**Mushroom parts and spore prints**
- Parts and life cycle of a mushroom — [🖼️ USFS GTR-309, p. 10](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=10); [Mushroom](wiki:Mushroom)
- Gills, pores, ring and cup, labeled — [🖼️ USDA FB 796, p. 4](lib:usda-farmers-bulletin-796#page=4); [Lamella](wiki:Lamella_(mycology)); [Annulus](wiki:Annulus_(mycology))
- Section through a gilled mushroom — [🖼️ Thomas, p. 42](lib:thomas-field-book#page=42)
- How an Amanita grows from its "egg" — [🖼️ Thomas, p. 43](lib:thomas-field-book#page=43); [Universal veil](wiki:Universal_veil); [Volva](wiki:Volva_(mycology))
- A spore print — [🖼️ Hard, p. 35](lib:hard-the-mushroom-edible-and-otherwise#page=35); [Spore print](wiki:Spore_print)

**The killers**
- Death cap, dug up to show ring and cup — [🖼️ BC Forests, p. 1](lib:bc-forests-death-cap#page=1); [🖼️ cap colors, pp. 4–5](lib:bc-forests-death-cap#page=4); [Amanita phalloides](wiki:Amanita_phalloides)
- Death cap in the old books — [🖼️ Hard, p. 42](lib:hard-the-mushroom-edible-and-otherwise#page=42); [🖼️ USDA FB 796, p. 5](lib:usda-farmers-bulletin-796#page=5); [🖼️ Atkinson, p. 94](lib:atkinson-studies-of-american-fungi#page=94)
- Death cap "egg" with the cup around it — [🖼️ Gussow & Odell, p. 47](lib:gussow-and-odell#page=47)
- What people mistake death caps for — [🖼️ BCCDC, p. 7](lib:bccdc-death-cap-mushrooms-in-city#page=7)
- Six western killers in color — [🖼️ PNW/BC *White Paper*, p. 5](lib:pnw-and-bc-white-paper#page=5)
- Western destroying angel — [Amanita ocreata](wiki:Amanita_ocreata)
- Deadly Galerina — [🖼️ Cornell-UVM, p. 41](lib:cornell-uvm-best-management#page=41); [Galerina marginata](wiki:Galerina_marginata)
- Deadly webcap — [🖼️ NAMA, p. 12](lib:nama-deadly-cortinarius-rubellus#page=12); [Cortinarius rubellus](wiki:Cortinarius_rubellus)
- Fly agaric and panther cap — [🖼️ Hard, p. 45](lib:hard-the-mushroom-edible-and-otherwise#page=45); [Amanita muscaria](wiki:Amanita_muscaria); [Amanita pantherina](wiki:Amanita_pantherina)

**Edibles beside their look-alikes**
- Chanterelle ↔ false chanterelle, jack-o'-lantern, scaly vase — [🖼️ GTR-309, p. 18](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=18); [🖼️ jack-o'-lantern, Gussow & Odell, p. 71](lib:gussow-and-odell#page=71); [🖼️ scaly vase, GTR-576, p. 46](lib:usfs-pnw-gtr-576#page=46); [Cantharellus formosus](wiki:Cantharellus_formosus); [Hygrophoropsis aurantiaca](wiki:Hygrophoropsis_aurantiaca); [Omphalotus olivascens](wiki:Omphalotus_olivascens)
- Hedgehog — [🖼️ GTR-309, p. 22](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=22); [🖼️ Hard, p. 453](lib:hard-the-mushroom-edible-and-otherwise#page=453); [Hydnum repandum](wiki:Hydnum_repandum)
- King bolete ↔ red-pored bolete — [🖼️ GTR-309, p. 17](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=17); [🖼️ Hard, p. 375](lib:hard-the-mushroom-edible-and-otherwise#page=375); [Boletus edulis](wiki:Boletus_edulis); [Rubroboletus pulcherrimus](wiki:Rubroboletus_pulcherrimus)
- Morel ↔ false morel ↔ Verpa — [🖼️ GTR-710, p. 35](lib:usfs-pnw-gtr-710#page=35); [🖼️ Michigan sheet, p. 1](lib:michigan-health-dept#page=1); [🖼️ p. 2](lib:michigan-health-dept#page=2); [Morchella](wiki:Morchella); [Gyromitra esculenta](wiki:Gyromitra_esculenta); [Verpa bohemica](wiki:Verpa_bohemica)
- Oyster ↔ angel wings — [🖼️ Hard, p. 173](lib:hard-the-mushroom-edible-and-otherwise#page=173); [Pleurotus ostreatus](wiki:Pleurotus_ostreatus); [Pleurocybella porrigens](wiki:Pleurocybella_porrigens)
- Matsutake ↔ *Amanita smithiana* — [🖼️ GTR-309, p. 27](lib:usfs-wild-edible-mushrooms-of-the-pacific-northwest#page=27); [🖼️ GTR-412, p. 37](lib:usfs-pnw-gtr-412#page=37); [🖼️ *White Paper*, p. 5](lib:pnw-and-bc-white-paper#page=5); [Tricholoma murrillianum](wiki:Tricholoma_murrillianum); [Amanita smithiana](wiki:Amanita_smithiana)
- Puffball ↔ death-cap button — [🖼️ BC Forests, p. 6](lib:bc-forests-death-cap#page=6); [🖼️ Hard, p. 553](lib:hard-the-mushroom-edible-and-otherwise#page=553); [Puffball](wiki:Puffball); [Calvatia gigantea](wiki:Calvatia_gigantea); [Scleroderma citrinum](wiki:Scleroderma_citrinum)
- Lobster mushroom — [🖼️ Hard, p. 519](lib:hard-the-mushroom-edible-and-otherwise#page=519); [Hypomyces lactifluorum](wiki:Hypomyces_lactifluorum)
- Chicken of the woods — [Laetiporus](wiki:Laetiporus)
- Inky cap (sickens with alcohol) — [🖼️ Hard, p. 353](lib:hard-the-mushroom-edible-and-otherwise#page=353); [Coprinopsis atramentaria](wiki:Coprinopsis_atramentaria)
- Meadow mushroom (purple-brown print) — [🖼️ Hard, p. 327](lib:hard-the-mushroom-edible-and-otherwise#page=327); [Agaricus campestris](wiki:Agaricus_campestris)

**Matsutake country**
- Klamath matsutake habitat; a button in tanoak litter — [🖼️ GTR-412, p. 40](lib:usfs-pnw-gtr-412#page=40); [🖼️ p. 41](lib:usfs-pnw-gtr-412#page=41); [Notholithocarpus](wiki:Notholithocarpus); [Chrysolepis chrysophylla](wiki:Chrysolepis_chrysophylla)

**Growing and medicinal mushrooms**
- Drilling, plugging and waxing shiitake logs — [🖼️ Cornell-UVM, p. 20](lib:cornell-uvm-best-management#page=20); [Shiitake](wiki:Shiitake)
- Stacking logs in the laying yard — [🖼️ Agroforestry Note 13, p. 3](lib:agroforestry-note-13#page=3)
- Oysters on straw, step by step — [🖼️ UF SS662, p. 2](lib:uf-ifas-ss662#page=2); [🖼️ p. 3](lib:uf-ifas-ss662#page=3)
- Turkey tail, reishi, lion's mane — [Trametes versicolor](wiki:Trametes_versicolor); [Ganoderma lucidum](wiki:Ganoderma_lucidum); [Hericium erinaceus](wiki:Hericium_erinaceus)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — poison-center number and the deadly wild-plant look-alikes
- [Medical guides](guide:Medical-READ-ME-FIRST) — dehydration and oral rehydration when someone is poisoned
- [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — drying, storing and cooking what you gather
- [Root Cellar guide](guide:ROOT-CELLAR-GUIDE) — storing dried mushrooms and other food without power
- [Seed Bank guide](guide:SEED-BANK-GUIDE) — keeping your own stock going year to year, like a mushroom strain
- [Nuclear Fallout guide](guide:NUCLEAR-FALLOUT-GUIDE) — why wild foods, mushrooms included, need care after fallout
- [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE) — acorns, camas, salmon, cordage and baskets, houses, and tending the land with fire, the way people here lived for thousands of years.
