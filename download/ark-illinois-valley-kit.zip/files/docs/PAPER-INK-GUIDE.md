# 📜 Paper, Ink & Toilet Paper

How to make the paper, ink and toilet paper a household goes through once the stores are gone: paper by hand
from rags, plants and scrap paper; iron-gall and soot inks; pens, pencils and slates; keeping paper and books
from mold; and what to use instead of toilet paper, tissues and paper towels, and where each may go. The two
papermaking and ink books are in `Homestead-Skills\Paper-Ink`: Watt's *The Art of Paper-Making* (1890), whose
chapter "Making Paper by Hand" covers the vat, mould and sizing, and the Bureau of Standards' *Inks* (Circular
426, 1940). The old recipe books are in `Homestead-Skills\Household-Make-Do` and the toilet books in
`Sanitation-Hygiene\Latrines-Toilets`. Where no book covers a step, this guide says *(rule of thumb)*.

> ### The short version
> - **Rags make the best paper.** Linen and cotton, cooked soft in weak lye or lime and pounded to pulp;
>   there is "no better material" than linen ([Watt, p. 20](lib:watt-the-art-of-paper-making#page=20)).
> - **Lye burns skin and can blind.** Gloves, goggles, no aluminum pots, children away; flush splashes
>   with lots of water ([Practical Action *Soapmaking*, p. 1](lib:practical-action-soap-making#page=1)).
> - **Scrap paper is the easy win:** soak, pound, form again ([Leland, p. 159](lib:leland-a-manual-of-mending#page=159)).
> - **Iron-gall ink is tannin + iron + a little gum:** oak galls, tanoak bark or sumac leaves, with rusty nails
>   in vinegar ([Practical Action *Natural Dyeing*, p. 4](lib:natural-dyeing-of-textiles#page=4)). Keep tannin
>   and iron about **equal by weight**; too much iron eats paper ([NBS *Inks*, p. 35](lib:nbs-circular-426#page=35)).
> - **Soot ink never fades** and doesn't harm paper ([NBS, p. 37](lib:nbs-circular-426#page=37)): use it for records that must last.
> - **Never add mercury ("corrosive sublimate") or chromates** as old recipes do. A few cloves or a little alcohol
>   stop mold ([*Household Discoveries*, p. 422](lib:household-discoveries#page=422)).
> - **Washing with water is the cleanest toilet paper**, **2 cups to 3 quarts** a time
>   ([Compendium, p. 10](lib:compendium-of-sanitation#page=10)). Cloth wipes belong to **one person** and are
>   washed hot. **Only toilet paper** goes into a septic or flush toilet ([EPA, p. 6](lib:septicsmart#page=6)).
> - **Learn poison oak and stinging nettle before you wipe with any leaf. Wipe front to back** and wash your
>   hands ([*Where There Is No Doctor*, ch. 18, p. 10](lib:where-there-is-no-doctor-18#page=10)).

---

## 🧺 What paper is, and fibers that work

Paper is "a composition of linen, cotton, or other vegetable fibre reduced to powder and then combined with
size, which is a kind of glue" ([Leland, p. 112](lib:leland-a-manual-of-mending#page=112)). Beaten fiber spread
thin on a screen felts into a sheet; the **size** (glue) lets it take ink.

| Fiber | How good | Notes |
|---|---|---|
| **Linen rags**, flax waste, hemp, old rope | The best: long, strong, flexible ([Watt, p. 20](lib:watt-the-art-of-paper-making#page=20)) | Already retted and boiled, so it needs "but little chemical treatment" (same page) |
| **Cotton rags** | "Strong and flexible", a little spongy (p. 20) | Worn-out sheets, shirts, flour sacks |
| **Straw** (wheat, oats, rye, barley) | Short; "cannot of itself make a strong paper" (p. 20) | Cut 1–2 in ([p. 99](lib:watt-the-art-of-paper-making#page=99)); mix with rag pulp *(rule of thumb)* |
| **Corn stalks and husks, reeds, bean stalks, hop vines, poplar, willow** | On Watt's list of paper materials ([p. 26](lib:watt-the-art-of-paper-making#page=26)) | Long cooking; try a small batch *(rule of thumb)* |
| **Cattail, milkweed** | Ithaca Hours were printed on "locally made … cattail (marsh reed) paper" ([FRB Cleveland, p. 2](lib:private-money-local-currencies#page=2)); milkweed used "to some extent" ([Saunders, p. 256](lib:useful-wild-plants-of-the-united-states#page=256)) | Cut cattail only from clean water; learn waterhemlock first ([Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE)) |
| **Waste paper** | The easiest ([Watt, p. 104](lib:watt-the-art-of-paper-making#page=104)) | See "Recycling" below |
| **Wool** | No: mills sold woollen rags for reused wool ("shoddy") ([p. 27](lib:watt-the-art-of-paper-making#page=27)) | Synthetics won't pulp either *(rule of thumb)* |

**Rags:** remove buttons, hooks, rubber and pins; open seams, hems and knots; cut **2- to 4-inch squares**; keep
dark rags apart from white ([Watt, pp. 36, 38](lib:watt-the-art-of-paper-making#page=38)). Old rags spread
disease ([p. 27](lib:watt-the-art-of-paper-making#page=27)), so **boil a sick person's rags before handling
them** *(rule of thumb)*. **Stalks:** ret, break and scutch them like flax ("Linen, nettle and native fibers" in
the [Clothing & Leather guide](guide:CLOTHING-LEATHER-GUIDE)).

## 🔥 Cooking fiber soft

Boiling in alkali removes grease, dirt and the "cementing substances" around the fibers; linen rags lose a fifth
to a third of their weight ([Watt, p. 45](lib:watt-the-art-of-paper-making#page=45)). ⚠️ **Lye "can cause
blindness if splashed into the eye"** ([Practical Action, p. 1](lib:practical-action-soap-making#page=1)):
gloves, long sleeves, goggles, children away, no aluminum ([CAWST, p. 2](lib:cawst-soap-making#page=2)); flush
splashes with plenty of **water**. Wet lime is caustic too *(rule of thumb)*.

1. **Liquor:** **wood-ash lye** ("Soap from fat and ashes" in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE));
   potash "affects but slightly" the fiber itself ([Watt, p. 19](lib:watt-the-art-of-paper-making#page=19)). Or
   **slaked lime**, gentler on fine rags ([p. 50](lib:watt-the-art-of-paper-making#page=50)), which helps pulp
   "felt together better" ([Lime circular, p. 25](lib:lime-its-properties-and-uses#page=25)).
2. **How much:** mills used about **5 lb of lime and 3 lb of soda ash per 100 lb of rags**
   ([Watt, p. 49](lib:watt-the-art-of-paper-making#page=49)), under 1 oz of lime and ½ oz of washing soda per
   pound *(arithmetic)*. For ash lye, thin egg-floating lye with about 4 parts water *(rule of thumb)*.
3. **Simmer until a fiber pulls apart easily in your fingers**, the old test for "tender" rags
   ([Watt, p. 147](lib:watt-the-art-of-paper-making#page=147)). Mills boiled 2–6 hours under steam pressure
   ([p. 49](lib:watt-the-art-of-paper-making#page=49)); an open pot takes half a day or more *(rule of thumb)*.
4. **Rinse until the water runs clear** and the fiber stops feeling slippery, "until free of soda"
   ([Lime circular 337, p. 92](lib:manufacture-of-lime-circular-337#page=92)). Gloves on until then.
5. **No fuel?** Old mills **retted** rags, piling them damp until tender, with "considerable loss of fibre" to
   rot ([Watt, p. 147](lib:watt-the-art-of-paper-making#page=147)).

## 🔨 Beating fiber into pulp

- **It is slow.** Stamping rods took "forty pairs of stamps for twenty-four hours to produce one hundredweight of
  paper" ([Watt, pp. 147–148](lib:watt-the-art-of-paper-making#page=148)). Pound wet fiber with a wooden mallet
  on a hardwood block, or in a mortar as Leland does ([p. 159](lib:leland-a-manual-of-mending#page=159)); plan
  on an hour or more for a few dozen sheets *(rule of thumb)*.
- **Don't chop fibers short:** cut fiber makes paper that "will be tender" (weak). Long pulp makes strong paper,
  shorter pulp fine writing paper; grasses beat in half the time of rags ([Watt, p. 129](lib:watt-the-art-of-paper-making#page=129)).
- **Ready when** a pinch shaken in a jar of water makes an even cloud *(rule of thumb)*: "a fine paste, not …
  lumpy and stringy, but soft" ([Leland, p. 113](lib:leland-a-manual-of-mending#page=113)).

## 🪟 The mould, deckle and vat

In Watt ([pp. 147–149](lib:watt-the-art-of-paper-making#page=148)) the **mould** is a wooden frame "neatly joined
at the corners", with ribs a little over an inch apart and fine wires along it, "about fifteen or twenty in an
inch". The **deckle**, a loose frame on top, "must fit very neatly or the edges of the paper will be rough". The
**vat** was a warmed tub "about 5 feet square and 4 feet deep"; **felts** of wool cloth go between wet sheets.

**Build a small one** *(rule of thumb, after Watt)*:
1. Make **two identical frames** of straight, dry 1×2 wood, a bit bigger inside than your sheet (about 9 × 12 in for letter paper), corners glued and pegged square.
2. On one (the mould), fit thin ribs about 1 inch apart, flush with the top, and tack **fine window screen**
   tight over them (fiberglass, brass or bronze; steel rusts and stains).
3. The other frame is the **deckle**; it must sit snugly on the screen. Oil or wax all the wood.
4. **Vat:** a washtub or tote longer than the mould. **Felts:** two dozen pieces of wool blanket or flannel.

![A papermaking mould (a wooden frame with ribs about an inch apart and fine screen on top) beside its deckle (the same frame, empty, about 9 by 12 inches inside), and a cut-through view of the deckle sitting on the mould](img:PAPER-INK-GUIDE/mould-and-deckle.svg)
*Two matching frames: the mould carries the ribs and tight screen; the deckle sits snugly on top and makes the sheet's edges (a diagram drawn for this guide).*

## 📄 Forming, couching, pressing and drying

1. **Charge the vat** with clean water and pulp, and stir before every sheet to keep it "uniformly mixed"
   ([Watt, p. 148](lib:watt-the-art-of-paper-making#page=148)). More pulp, thicker sheets *(rule of thumb)*.
2. **Dip** the mould with its deckle and lift "as much of the pulp as will form a sheet of paper" (same page).
3. **Hold it level** as it drains, "otherwise … the sheet of paper would be thicker on one part than another".
   **Shake gently** front to back, then side to side, "propelling the pulp in four directions"
   ([p. 149](lib:watt-the-art-of-paper-making#page=149)). Lift off the deckle.
4. **Couch** (say "cooch"): turn the mould face down onto a damp felt, press, and lift it away. Lay another felt on top; keep stacking felt, sheet, felt (same page).
5. **Press hard**: the mill used "a very powerful press" (same page); at home, boards above and below and a car
   jack under a beam, a cider press or heavy stones *(rule of thumb)*. Then take the sheets off the felts, press
   them gently to remove felt marks, and next day separate and press once more (same page).
6. **Dry slowly**, hung over lines; cow-hair ropes "do not stain the paper" ([p. 150](lib:watt-the-art-of-paper-making#page=150)),
   and slow loft drying was thought best ([p. 145](lib:watt-the-art-of-paper-making#page=145)). In wet winters,
   dry indoors away from direct stove heat *(rule of thumb)*.
7. **Smooth:** mills "hot-pressed" sheets between pasteboards with hot iron plates ([p. 150](lib:watt-the-art-of-paper-making#page=150));
   a warm flatiron over a cloth does the same *(rule of thumb)*.

![Four steps of forming paper: dipping the mould and deckle into a vat of pulp, shaking it level, turning it face down onto a damp felt, and pressing a stack of felts and sheets between boards](img:PAPER-INK-GUIDE/forming-and-couching.svg)
*Dip, shake level, couch onto a damp felt, then stack felt, sheet, felt and press hard (a diagram drawn for this guide).*

| Problem | Likely cause |
|---|---|
| Thick and thin patches | Mould not held level ([Watt, p. 149](lib:watt-the-art-of-paper-making#page=149)) |
| Rough, ragged edges | Deckle too loose ([p. 148](lib:watt-the-art-of-paper-making#page=148)) |
| Weak paper that tears | Fibers chopped too short ([p. 129](lib:watt-the-art-of-paper-making#page=129)) |
| Ink spreads like on a blotter | Not sized yet ([p. 136](lib:watt-the-art-of-paper-making#page=136)) |
| Sheet sticks to the screen | Pulp too thin, or mould not pressed firmly onto the felt *(rule of thumb)* |

📚 **Go deeper:** [Watt, ch. XII "Making Paper by Hand", pp. 147–150](lib:watt-the-art-of-paper-making#page=147) — vat, mould, couching, pressing, drying and sizing; [ch. IV, p. 45](lib:watt-the-art-of-paper-making#page=45) — boiling rags.

## 🧴 Sizing: making paper take ink

On unsized paper a pen stroke "would spread in all directions" ([Watt, p. 136](lib:watt-the-art-of-paper-making#page=136)).
Starch stirred into the pulp won't fix it: blotting paper is made "with starch alone" ([p. 199](lib:watt-the-art-of-paper-making#page=199)).
Hand-made paper was **dipped in gelatine size after drying** ([p. 150](lib:watt-the-art-of-paper-making#page=150)).

- **Size from hide scraps:** cover clean skin clippings with water and hold at **180–190 °F**, "very important
  that the liquid should not actually boil", for 12–16 hours ([pp. 140–141](lib:watt-the-art-of-paper-making#page=140)).
  Skim, strain, and stir in dissolved **alum**, which "greatly improves its sizing property, besides preserving
  it" ([p. 141](lib:watt-the-art-of-paper-making#page=141)); more in warm weather ([p. 143](lib:watt-the-art-of-paper-making#page=143)).
  Hide scraps and alum: [Clothing & Leather guide](guide:CLOTHING-LEATHER-GUIDE).
- **Quicker:** boil "clean parchment cuttings until they form a clear solution" and strain through muslin
  ([Henley's, p. 508](lib:henleys-twentieth-century#page=508)), or use "1 ounce of good glue in 1 pint of hot
  water" ([*Household Discoveries*, p. 271](lib:household-discoveries#page=271)).
- **Sizing:** warm the size to **lukewarm** ([Watt, p. 143](lib:watt-the-art-of-paper-making#page=143)); lay dry
  sheets in **one at a time**, each evenly wet; press out the extra, separate, press again, **dry slowly** ([p. 150](lib:watt-the-art-of-paper-making#page=150)).
- **Thin paper needs stronger size.** Sizing is "one of the most difficult and uncertain" jobs, upset by heat and
  damp ([p. 143](lib:watt-the-art-of-paper-making#page=143)): test a few sheets first.
- **Starch brushed on the surface helps:** bond paper was surface-sized with starch, "an additional barrier
  against the penetration of the ink" ([NBS *Inks*, p. 39](lib:nbs-circular-426#page=39)). Brush thin cooked starch onto dry sheets *(rule of thumb)*.
- **Size and starch feed silverfish** ([Leland, p. 144](lib:leland-a-manual-of-mending#page=144)); a few drops of
  clove or other essential oil keep paste from molding ([*Household Discoveries*, p. 59](lib:household-discoveries#page=59)).

## ♻️ Recycling scrap paper, cardboard and mending

**Re-pulping:** tear scraps small and **soak them a long time**, changing the water now and then; pound the soft
mass in a mortar, boil it, and "to give it consistency, add flour-paste or gum" ([Leland, p. 159](lib:leland-a-manual-of-mending#page=159)).
- **Handwritten paper is easier than print:** "a little soda-ash will discharge ordinary writing ink", but
  printer's ink is carbon and leaves grey pulp ([Watt, p. 104](lib:watt-the-art-of-paper-making#page=104)), fine
  for wrapping, card and the outhouse. Mills used **10–20 lb of soda ash per 100 lb** of paper, boiled 12–24
  hours ([p. 105](lib:watt-the-art-of-paper-making#page=105)). Washing soda: "Laundry" in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE).
- **Cardboard:** paste sheets together with size, or lay several wet sheets on each other as you couch
  ([Watt, p. 200](lib:watt-the-art-of-paper-making#page=200)). Leland's paste for it has "a little alum and glue
  and a few drops of oil of cloves" to stop souring ([p. 151](lib:leland-a-manual-of-mending#page=151)).
  **Papier-mâché:** newspaper strips in flour paste, several layers, dried in the sun
  ([*A Book for Midwives*, ch. 25, p. 6](lib:a-book-for-midwives-25#page=6)).
- **Mending:** fill holes with pulp worked to a fine paste ([Leland, p. 113](lib:leland-a-manual-of-mending#page=113));
  patch tears with thin paper and a paste of ½ tsp each starch and flour cooked thick with boiling water, which
  "will not mold or discolor paper" ([Lee's, p. 204](lib:lees-priceless-recipes#page=204)).
- **Waxed paper:** rub paper on a hot iron plate with beeswax ([Henley's, pp. 507–508](lib:henleys-twentieth-century#page=507)).
  **Dirty pages:** rub with stale bread ([*Household Discoveries*, p. 60](lib:household-discoveries#page=60)).

## ✒️ Iron-gall ink

Iron and tannin from galls make a pale ink that the air turns black ([NBS *Inks*, p. 7](lib:nbs-circular-426#page=7));
it "turned black on the paper" ([*Household Discoveries*, p. 416](lib:household-discoveries#page=416)), darkest in about a week ([NBS, p. 26](lib:nbs-circular-426#page=26)).

- **Tannin:** **oak galls** (the old imported kind held 60–70% tannic acid); crush, steep "in hot, not boiling, water", and strain
  ([*Household Discoveries*, p. 416](lib:household-discoveries#page=416)). Also **sumac leaves**
  ([Practical Action, p. 4](lib:natural-dyeing-of-textiles#page=4)), **tanoak bark**, "high tannin content"
  ([Tanoak guide, p. 2](lib:tanoak-plant-guide#page=2)), and **walnut hulls or maple bark**
  ([Trapper manual, p. 46](lib:trapper-education-manual#page=46)). Local tribes blackened basket material with
  fresh oak bark, water and rusty nails ([Chesnut, p. 354](lib:chesnut-1902#page=354)).
- **Iron:** "rusty nails and a cupful of vinegar" in a bucket of water for "a couple of weeks"
  ([Practical Action, p. 4](lib:natural-dyeing-of-textiles#page=4)), or iron filings in ½ gallon of vinegar for
  several days, some always left undissolved ([USDA FB 1334, p. 19](lib:usda-fb1334#page=19)).
- **Copperas** (green vitriol) is iron sulfate and "contains no copper"; **blue vitriol** (bluestone) is copper
  sulfate. Don't mix them up ([NBS, p. 36](lib:nbs-circular-426#page=36)). Good copperas is pale green; rusty
  means air has spoiled it, so keep it tightly closed ([p. 20](lib:nbs-circular-426#page=20)).

**The balance matters.** Government record ink has about 31 g of tannin (tannic plus gallic acid) to 30 g of iron
sulfate per liter ([NBS, p. 13](lib:nbs-circular-426#page=13)), about **1 oz of each per quart** *(arithmetic)*.
With too little tannin, writing "may become rusty in a comparatively few years" ([p. 26](lib:nbs-circular-426#page=26));
iron sulfate "caused decided weakening of the paper", tannin did not ([p. 35](lib:nbs-circular-426#page=35)), and
some old manuscripts have crumbled to their margins ([p. 34](lib:nbs-circular-426#page=34)). **When unsure, use less iron.**

**With galls and copperas** ([*Household Discoveries*, p. 417](lib:household-discoveries#page=417)): **2 oz crushed
galls, 1 oz gum arabic, 1 oz copperas, 16 oz soft water**; stand 2 weeks, shaking often. That is about 1.3 oz
tannin to 1 oz copperas, close to the government balance *(arithmetic)*. **Leave out** the "5 grains of corrosive sublimate" the book adds: it is mercury. Use a few cloves.

**No-store recipe** *(rule of thumb, from the parts above)*:
1. Start the **iron water** weeks ahead.
2. **Tannin tea:** 2 oz crushed galls (or a double handful of chopped tanoak bark or dried sumac leaves) steeped
   overnight in 1 pint of hot, not boiling, rain water; strain through cloth.
3. In a glass jar, add iron water **a spoonful at a time**, testing a stroke on paper after each; stop when the
   strokes dry dark and stop improving. "Some experiments will be required" ([*Household Discoveries*, p. 417](lib:household-discoveries#page=417)).
4. Stir in a little gum or **thin hide-glue size**, which keeps the black from settling and fastens it to the
   paper ([NBS, p. 8](lib:nbs-circular-426#page=8)). Add a few cloves and bottle it.

- **Rain water** (distilled is best); hard water uses up the ink's acid ([NBS, p. 18](lib:nbs-circular-426#page=18)).
  **Glass or a glazed crock:** "avoid the use of metal vessels … Iron, especially" ([p. 77](lib:nbs-circular-426#page=77)).
- **It "corrodes steel pens"** ([*Household Discoveries*, p. 416](lib:household-discoveries#page=416)): wipe nibs.
  **Don't blot**; blotted writing lasts less well ([NBS, p. 27](lib:nbs-circular-426#page=27)).
- **Ink powder keeps:** "Powdered nutgalls 4 ounces, copperas 3 ounces, logwood 1 ounce, gum arabic ½ ounce;
  sufficient for 1 quart of water" ([Lee's, p. 61](lib:lees-priceless-recipes#page=61)). Travelers pressed such
  powders into "ink stones" ([Henley's, p. 409](lib:henleys-twentieth-century#page=409)).

## 🖤 Soot ink and other inks

**Carbon ink** is the oldest: lampblack (soot) or charcoal held in glue, gelatin or gum; India-ink cakes are that
paste dried, then rubbed with water ([NBS *Inks*, p. 7](lib:nbs-circular-426#page=7)). Carbon "cannot be bleached
by any amount of exposure to intense light" ([p. 37](lib:nbs-circular-426#page=37)) and is unlikely to harm paper ([p. 38](lib:nbs-circular-426#page=38)).

**Homemade India ink** ([*Household Discoveries*, p. 419](lib:household-discoveries#page=419)): boil an old kid glove
(or a clean hide scrap) "until it forms a thick size"; hold a cold plate in a candle flame and, while it is still
warm, mix the soot with the size. **Test:** let lines dry bone dry and sponge them. "If the ink runs, it is of poor quality."
- **Grind it fine** and stir before each dip; coarse carbon settles ([NBS, pp. 37–38](lib:nbs-circular-426#page=38)).
  **Never mix it with iron-gall ink**: acid makes the carbon settle (p. 38).
- **A tenth part glycerine** keeps India ink liquid ([Henley's, p. 409](lib:henleys-twentieth-century#page=409));
  it works better with a brush than a steel pen ([p. 408](lib:henleys-twentieth-century#page=408)).
- **Printing ink** is carbon in boiled linseed or nut oil ([*Household Discoveries*, p. 422](lib:household-discoveries#page=422)).
  The Wintu and other tribes "used the soot from burnt oak galls to make tattoos" ([Tanoak guide, p. 2](lib:tanoak-plant-guide#page=2)).
- **Sumac ink:** "The berries and leaves of red or staghorn sumac boiled together in water make a permanent black
  ink" ([Seton, p. 334](lib:seton-the-book-of-woodcraft#page=334)). The Navajo dyed black with three-leaved sumac
  ([*Navajo Native Dyes*, p. 67](lib:navajo-native-dyes#page=67)), but three leaflets is also poison oak: **pick no
  three-leaflet shrub** unless someone who knows both shows you *(rule of thumb)*.
- **Berry juice fades:** dyes "have the unfortunate habit of fading" ([NBS, p. 7](lib:nbs-circular-426#page=7)), fine
  for children's pictures. **Invisible ink:** fresh milk shows when gently heated ([*Household Discoveries*, p. 420](lib:household-discoveries#page=420)).

## 🧊 Keeping ink, and bringing back faded writing

- **Mold:** "a little alcohol or a few drops of any essential oil or a few cloves will prevent mold"; thin
  thickened ink with water or strained strong coffee ([*Household Discoveries*, p. 422](lib:household-discoveries#page=422)).
- **Air spoils ink:** keep bottles **nearly full**, corked and dark ([NBS, pp. 23–24](lib:nbs-circular-426#page=23)).
  Make **small batches**; a two-year supply may end up "too full of sediment" ([p. 24](lib:nbs-circular-426#page=24)).
- **Freezing:** a little alcohol prevents it ([*Household Discoveries*, p. 422](lib:household-discoveries#page=422)).
  Inks frozen solid at about 0 °F came back when thawed and shaken, and no bottle broke; they were about ⅚ full
  ([NBS, p. 25](lib:nbs-circular-426#page=25); *arithmetic*). Leave headroom and keep ink indoors in frost *(rule of thumb)*.

**Restoring faded iron-gall writing.** It leaves rust in the strokes, so it can be brought back (faded dye ink
leaves "literally nothing behind", [NBS, pp. 32–33](lib:nbs-circular-426#page=33)). "A 2- or 3-percent solution of
tannic acid", or gall tea, turns the rust black: "by far the best treatment" (p. 33;
[*Household Discoveries*, p. 422](lib:household-discoveries#page=422)).
1. Brush it on softly, or trace the letters with a pen dipped in it; rinse briefly in clean water and dry, or the whole sheet darkens in time (p. 33).
2. Try a corner first. For a treasured paper, think twice: NBS advised against treating the Declaration of Independence ([p. 34](lib:nbs-circular-426#page=34)).

📚 **Go deeper:** [NBS Circular 426 *Inks*](lib:nbs-circular-426#page=7) — how iron-gall ink works, aging, freezing and restoring; [*Household Discoveries*, pp. 416–422](lib:household-discoveries#page=416) — dozens of old ink recipes (skip the poisons; see the last section).

## 🪶 Pens: reed, quill and brush

**Reed or bamboo pen** ([VITA, p. 360](lib:village-technology-handbook#page=360)):
1. Take dry bamboo or stiff reed about **6 in × ⅜ in**. Whittle one end to width and shave it thin so it flexes, keeping the tip on the **hard outer** side.
2. Cut the tip straight across, then shape it "by gently writing on the sandpaper with the dry pen".
3. For an ink hole, rest the knife point at least **⅛ in** up from the tip and twist to drill a hole about 3/32 in.
4. For a **reservoir pen**, bind a thin bamboo cover plate on with a rubber band or fine wire ([p. 361](lib:village-technology-handbook#page=361)).

![A bamboo reservoir pen from the side and from above: the shaved tip from the hard outer fibers, a fill hole, and a thin notched cover plate bound on to hold extra ink](img:PAPER-INK-GUIDE/reed-reservoir-pen.png)
*The reservoir pen: the tip cut from the hard outer side of the bamboo, and a thin notched cover plate bound on to hold more ink ([VITA, p. 361](lib:village-technology-handbook#page=361)).*

**Quill pen** *(rule of thumb; no book here shows how)*: take a big goose or turkey wing feather; soak the barrel,
harden it in hot sand for a minute, strip the lower barbs and scrape off the outer skin and inner pith. Cut a long
scoop on the underside, a short slit up the point, and trim the tip square and thin. Recut it as it wears.

**Brush:** India ink "applies well with a brush" ([Henley's, p. 408](lib:henleys-twentieth-century#page=408)). A gold
nib "cannot be rusted" by any ink ([NBS, p. 18](lib:nbs-circular-426#page=18)).

## ✏️ Pencils, charcoal, chalk and slates

- **Hoard pencils.** An 1871 traveler gave up ink (it dries, clogs and corrodes pens) and "trusted simply to the
  powers of a good HH. pencil" ([*Shifts and Expedients*, pp. 31–32](lib:shifts-and-expedients#page=32)). Pencil
  "lead" is graphite and clay, "not lead (the metal)" ([Kuphaldt, p. 97](lib:electric-circuits-vol-6#page=97)).
- **Don't make real lead pencils** from melted lead in reeds, as an old book does ([*Shifts*, p. 217](lib:shifts-and-expedients#page=217)).
  Lead fumes poison: never melt lead indoors, and keep children away ([ODFW, p. 27](lib:odfw-2026-oregon-sport-fishing#page=27)).
- **Sharpener:** a block with coarse sandpaper on one side and fine on the other ([*Household Discoveries*, p. 62](lib:household-discoveries#page=62)).
- **Charcoal:** a burnt stick marks well enough to lay out a tepee ([Seton, p. 467](lib:seton-the-book-of-woodcraft#page=467)).
  For drawing sticks, char peeled willow twigs in a tin with a nail hole, like char cloth ("Fire and light without
  stores" in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)), in the stove during fire season *(rule of thumb)*.
- **Soapstone, chalk and slate pencils** mark iron ([ICS, p. 55](lib:ics-blacksmith-shop#page=55)). **Stop smudging**
  with "a light wash of gum of any kind, diluted varnish, or even milk" ([Leland, p. 259](lib:leland-a-manual-of-mending#page=259)).

**Slates save paper.** Children learned their tables "upon their slates or on the blackboard"
([Ray's Primary, p. 11](lib:rays-new-primary-arithmetic#page=11)); a "stick or chalk board" is a toddler's toy
([WHO/UNICEF, p. 2](lib:care-for-child-development#page=2)); a kitchen slate keeps the list of supplies running low
([*Household Discoveries*, p. 69](lib:household-discoveries#page=69)).
- **Blackboard paint:** 1 lb shellac in 1 gal alcohol, with 4 oz each of fine lampblack, powdered emery and
  ultramarine ([Henley's, p. 491](lib:henleys-twentieth-century#page=491)). Lacking those, a smooth dark board or flat stone takes chalk or soapstone *(rule of thumb)*.
- **Wax tablet:** a shallow tray of beeswax, written on with a point and smoothed to erase *(rule of thumb)*; beeswax
  takes "any sharp-pointed instrument" ([*Household Discoveries*, p. 421](lib:household-discoveries#page=421)).
- **Birch bark:** no book here covers it, and paper birch is not a valley tree *(rule of thumb)*. Smooth bark or
  leaves take scratched letters, as India's palm leaves did ([*Shifts*, p. 504](lib:shifts-and-expedients#page=504)).

## 📚 Keeping paper and books from mold

- **Damp breeds "molds and fungi".** Keep books on "open, airy, well-lighted shelves"; after a wet spell wipe the
  covers and set them "in the sun or before a fire for a few hours"; camphor, wrapped in paper, in closed boxes
  ([Henley's, p. 127](lib:henleys-twentieth-century#page=127)). In our wet winters, check monthly *(rule of thumb)*.
- **Light and damp age writing; mold destroys "both ink and paper"** ([NBS, p. 27](lib:nbs-circular-426#page=27)).
  Store records dry and dark, off the floor and away from outside walls *(rule of thumb)*.
- **Insects:** oil of lavender or cedar on the shelves; silverfish "loves starch" ([*Household Discoveries*, p. 59](lib:household-discoveries#page=59)).
- **Records that must last:** soot ink or balanced iron-gall ink on rag paper, never berry or dye ink ([NBS, pp. 7, 37](lib:nbs-circular-426#page=37)).

## 🧻 Toilet paper alternatives: water, cloth, leaves, cobs

There are two ways: **wash** ("typically … 0.5–3 litres", about **2 cups to 3 quarts**) or **wipe** with "paper,
leaves, corncobs, rags or stones" ([Compendium, p. 10](lib:compendium-of-sanitation#page=10); *arithmetic*). Agree as
a household what you'll use, and plan a supply that lasts ([Sphere, p. 143](lib:sphere-handbook-2018#page=143)).

**Water:** pour from a squeeze bottle or jug with one hand and wash with the other, then wash your hands with soap
*(rule of thumb)*. The wash water carries feces: keep it **out of the urine bucket**; small amounts may soak into
the soil ([EcoSanRes, p. 38](lib:safe-use-of-urine-and-faeces#page=38)). Pour-flush toilets suit water-washers ([Hesperian ch. 7, p. 35](lib:building-toilets#page=35)).

**Cloth wipes ("family cloth")** belong to **one person each**: shared towels spread disease
([*Ship's Medicine Chest*, p. 153](lib:ships-medicine-chest#page=153); pink eye,
[*Where There Is No Doctor*, ch. 16, p. 3](lib:where-there-is-no-doctor-16#page=3)). Cut soft cotton (flannel, old
T-shirts) 6–8 inches square, a day's worth plus spares each; many families use cloth for urine only
*(rule of thumb)*. Used cloths go in a **lidded bucket** ("Toilet paper alternatives" in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)).

**Wash them like cloth diapers:**
1. Rinse in cold water, then wash with soap ("Menstrual pads and diapers" in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE)).
2. **Wash above 140 °F, or soak in 0.05% bleach** (about **2 Tbsp of 6% bleach per gallon**): "Dishes, laundry and
   periods" and the bleach-strength table in the [Sanitation guide](guide:SANITATION-GUIDE).
3. A little vinegar in the last rinse, as for diapers ([*Where There Is No Doctor*, ch. 15, p. 23](lib:where-there-is-no-doctor-15#page=23)). **Dry in full sun.**
4. Wash water goes to the latrine or wastewater system, **not the garden** ([Oregon DEQ, p. 12](lib:oregon-deq-reusing-graywater#page=12)),
   and **never into a creek**. Wash a sick person's cloths separately, with bleach *(rule of thumb)*.

**Leaves:** **no book in the library recommends any particular leaf for wiping.** Leaves are a normal choice
([Compendium, p. 29](lib:compendium-of-sanitation#page=29)), but which leaf is up to you. Rub a new one on your inner arm and wait a day before trusting it *(rule of thumb)*.
- ⚠️ **Poison oak:** "leaves of three, let it be"; vine or shrub, "all over low elevation in western Oregon"; "the
  roots and stems also contain the oil" ([OSU EM 9184, p. 24](lib:osu-em-9184#page=24)). "All parts, at all times of
  the year" cause the rash, **bare winter stems too** ([FM 3-05.70, p. 514](lib:fm-3-05-70#page=514)). Rash care: [Injuries guide](guide:FIELD-CARE-GUIDE).
- ⚠️ **Stinging nettle** grows on moist forest floors and riverbanks; its hairs sting "for hours or cause blisters"
  ([OSU EM 9373, p. 2](lib:stinging-nettle-em-9373#page=2)).
- **Thimbleberry** *(rule of thumb)*: big soft leaves on "a thornless, wideleaved shrub, 3 to 8 feet high, with showy
  white flowers" ([Chesnut, p. 369](lib:chesnut-1902#page=369)), in forest shade ([OSU EC 1306, p. 4](lib:ec-1306#page=4)).
- **Mullein** *(rule of thumb)*: first-year rosettes of "wooly basal leaves" on roadsides and dry open ground
  ([USFS PNW-GTR-513, p. 131](lib:pnw-gtr-513#page=131)); gentle enough to put on wounds ([AFH 10-644, p. 90](lib:afh-10-644#page=90)), but the hairs bother some people *(rule of thumb)*.

**Other wipes:** dried **corncobs** ([Compendium, p. 10](lib:compendium-of-sanitation#page=10)); **paper scraps**
crumpled soft *(rule of thumb)*; **stones**, kept in a separate pile, not in a dry toilet ([EcoSanRes, p. 38](lib:safe-use-of-urine-and-faeces#page=38)).
**Sore bottom** from diarrhea: petroleum jelly or zinc oxide cream after each stool ([*Where Women Have No Doctor*, ch. 17, p. 18](lib:where-women-have-no-doctor-17#page=18)).

## 🚽 What can go where

| Toilet | Goes in | Keep out |
|---|---|---|
| **Septic system** | "human waste and toilet paper" only ([EPA, p. 6](lib:septicsmart#page=6)) | Cloth, cobs, leaves, newspaper, homemade paper, wipes, pads |
| **Flush toilet** | Toilet paper | "Coarse dry cleansing materials may clog the water seal" ([Compendium, p. 35](lib:compendium-of-sanitation#page=35)) |
| **Twin buckets** | Paper in the poo bag; shredded paper as cover ([OSU, p. 3](lib:twin-bucket-toilet#page=3)) | Paper in the pee bucket: bag it (same page) |
| **Urine-diverting toilet** | Wipers and washers; wash water to a third basin ([Compendium, p. 30](lib:compendium-of-sanitation#page=30)) | Pouring water to clean it: use a damp cloth ([p. 31](lib:compendium-of-sanitation#page=31)) |
| **Composting toilet** | Paper and leaves help aeration ([EcoSanRes, p. 37](lib:safe-use-of-urine-and-faeces#page=37)) | Stones; with lime treatment, bin the paper separately ([p. 38](lib:safe-use-of-urine-and-faeces#page=38)) |
| **Pit latrine** | Any of these | Size the pit for wipes or water ([Sphere, p. 145](lib:sphere-handbook-2018#page=145)) |

**RV toilet paper breaks down best** in buckets ([OSU, p. 3](lib:twin-bucket-toilet#page=3)). **Don't flush at all**
if sewer lines may be broken: "Toilets when the water is off" in the [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE).

## 🧼 Wiping, handwashing and children

- **Wipe from front to back:** "Wiping forward can spread germs, amebas, or worms into the urinary opening and
  vagina" ([*Where There Is No Doctor*, ch. 18, p. 10](lib:where-there-is-no-doctor-18#page=10); [*Where Women Have No Doctor*, ch. 10, p. 7](lib:where-women-have-no-doctor-10#page=7)).
- **Teach children** "to wipe or wash carefully, and to wash their hands after using the toilet. Girls especially
  should be taught to wipe from front to back"; wash babies after they defecate ([Hesperian ch. 7, p. 11](lib:building-toilets#page=11)).
- **Wash hands** after the toilet and after cleaning up anyone else ([OSU, p. 4](lib:twin-bucket-toilet#page=4)), with
  soap "or an alternative such as ash" ([Sphere, p. 143](lib:sphere-handbook-2018#page=143)). Put a tippy tap by every
  toilet ("Handwashing and water for hygiene" in the [Sanitation guide](guide:SANITATION-GUIDE)).

## 🧣 Handkerchiefs, towels and reusing paper

- **Handkerchiefs, not tissues.** Someone with a cold "should cover his nose and mouth when he coughs or sneezes,
  and wash his hands often", and should not blow but "just wipe" the nose ([*Where There Is No Doctor*, ch. 13, p. 13](lib:where-there-is-no-doctor-13#page=13)).
  Each person keeps their own, washed hot like cloth wipes *(rule of thumb)*.
- **Flour sacks** make dish towels and dishcloths ([*Household Discoveries*, p. 68](lib:household-discoveries#page=68)); hem old sheets into napkins *(rule of thumb)*.
- **Paper bags** wrap things, then wipe up milk or grease and go in the fire; waxed box liners wrap cheese and lunches
  ([p. 67](lib:household-discoveries#page=67)). **Newspaper** goes under carpets, wraps woolens against moths and
  covers plants on frosty nights ([p. 68](lib:household-discoveries#page=68)); damp, it polishes windows ([p. 275](lib:household-discoveries#page=275)).
- **Paper too far gone:** shred it for the bucket toilet, or burn clean paper in the cooking fire, **never in the
  open June to October** ("Garbage, sickroom and birth waste" in the [Sanitation guide](guide:SANITATION-GUIDE)).

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| "5 grains of corrosive sublimate" (mercury) in ink "to prevent mold" ([*Household Discoveries*, p. 417](lib:household-discoveries#page=417); also pp. 418–419) | A few cloves, a little alcohol or essential oil ([p. 422](lib:household-discoveries#page=422)) |
| Corrosive sublimate in paste ([Lee's, p. 204](lib:lees-priceless-recipes#page=204)) and book varnish ([Henley's, p. 127](lib:henleys-twentieth-century#page=127)) | The starch paste on the same Lee's page; dry, airy shelves |
| Bichromate of potash in logwood inks ([*Household Discoveries*, p. 418](lib:household-discoveries#page=418); [Lee's, p. 59](lib:lees-priceless-recipes#page=59)) | Iron-gall or soot ink; logwood-chrome inks "offer no advantage" ([NBS, p. 37](lib:nbs-circular-426#page=37)). Chromium causes cancer ([Clothing & Leather guide](guide:CLOTHING-LEATHER-GUIDE)) |
| Carbolic acid (phenol), hydrochloric and sulfuric acid in the government formulas ([NBS, pp. 13, 16](lib:nbs-circular-426#page=13)) | Leave them out; sulfuric acid "is extremely harmful to paper" ([p. 35](lib:nbs-circular-426#page=35)) |
| Oxalic-acid blotting paper to lift ink ([Henley's, p. 505](lib:henleys-twentieth-century#page=505)), and as ink eraser ([NBS, p. 36](lib:nbs-circular-426#page=36)) | It is poisonous; tartaric plus citric acid is "much safer", and lemon juice lifts iron rust (same page) |
| Nitrate of silver marking inks ([*Household Discoveries*, p. 419](lib:household-discoveries#page=419)) | Stains and burns skin *(rule of thumb)*; use soot ink |
| Pencils and inscription plates of melted lead ([*Shifts*, p. 217](lib:shifts-and-expedients#page=217)) | Graphite, charcoal, chalk or slate; lead fumes poison ([ODFW, p. 27](lib:odfw-2026-oregon-sport-fishing#page=27)) |
| Glass crayons of copper sulfate ([Henley's, p. 376](lib:henleys-twentieth-century#page=376)) and red lead | Plain chalk or soapstone *(rule of thumb)* |
| Ammonium sulfide fumes to restore writing ([NBS, p. 33](lib:nbs-circular-426#page=33)) | Tannin or gall tea (same page) |
| Chlorine bleaching ([Watt, ch. IX, p. 107](lib:watt-the-art-of-paper-making#page=107)) and sulfuric-acid "parchment paper" ([Watt, p. 199](lib:watt-the-art-of-paper-making#page=199)) | Keep homemade paper off-white; use waxed paper for jar covers *(rule of thumb)* |

## 🖼️ Pictures & diagrams

- Hand papermaking, mould and deckle (no drawing in the library) — [Papermaking](wiki:Papermaking); [Deckle](wiki:Deckle); [Laid paper](wiki:Laid_paper)
- A beating engine — [🖼️ Watt, Fig. 21, p. 123](lib:watt-the-art-of-paper-making#page=123); [Hollander beater](wiki:Hollander_beater)
- Reed pen and its ink hole — [🖼️ VITA, p. 360](lib:village-technology-handbook#page=360); reservoir plate, [🖼️ p. 361](lib:village-technology-handbook#page=361); [Reed pen](wiki:Reed_pen); [Quill](wiki:Quill)
- Field journal with pencil and carbon paper — [🖼️ *Shifts and Expedients*, p. 32](lib:shifts-and-expedients#page=32)
- Inks and writing — [Iron gall ink](wiki:Iron_gall_ink); [Oak apple](wiki:Oak_apple) (oak galls); [India ink](wiki:India_ink); [Wax tablet](wiki:Wax_tablet); [Papier-mâché](wiki:Papier-mâché)
- Wiping front to back, YES and NO — [🖼️ *Where There Is No Doctor*, ch. 18, p. 10](lib:where-there-is-no-doctor-18#page=10)
- Toilets "for wipers" and "for washers" — [🖼️ Compendium, p. 30](lib:compendium-of-sanitation#page=30); pour-flush toilet, [🖼️ Hesperian ch. 7, p. 35](lib:building-toilets#page=35); pit size for wipes vs water, [🖼️ VITA, p. 156](lib:village-technology-handbook#page=156)
- Poison oak — [🖼️ OSU EM 9184 photos, p. 24](lib:osu-em-9184#page=24); [🖼️ FM 3-05.70 drawing, p. 514](lib:fm-3-05-70#page=514); [Poison oak](wiki:Toxicodendron_diversilobum); [Stinging nettle](wiki:Urtica_dioica)
- Mullein — [🖼️ AFH 10-644, p. 91](lib:afh-10-644#page=91); [🖼️ USFS, p. 131](lib:pnw-gtr-513#page=131); thimbleberry, [🖼️ OSU EC 1306, p. 4](lib:ec-1306#page=4); cattail, [🖼️ USDA, p. 1](lib:broadleaf-cattail#page=1)

## 🔗 Related guides

- [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — ash lye and its safety ("Soap from fat and ashes"), flour paste, char cloth, toilets when the water is off
- [Sanitation](guide:SANITATION-GUIDE) — hot washing, the bleach-strength table, septic systems, handwashing stations
- [Clothing & Leather](guide:CLOTHING-LEATHER-GUIDE) — preparing flax and nettle fiber, hide scraps for size, tannin-and-iron black dye
- [Childbirth & Children](guide:CHILDBIRTH-CHILDREN-GUIDE) — teaching reading and sums with slates and homemade paper
- [Signals & Morse](guide:SIGNALS-MORSE-GUIDE) — written messages and message forms
- [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) — paper, ink and pencils as trade goods; local scrip
- [Food from Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — cattail, and the deadly waterhemlock beside it
