# 🪢 Knots, Rope & Cordage

The dozen or so knots that do nearly every job, step by step, and the rope itself: what it can hold, what weakens it,
keeping it sound, lifting with blocks and tackle, and making cord. The Army's rigging manual (FM 5-125) and survival
manual (FM 3-05.70) are in `Manuals\ArmyFieldManuals`; the USDA's *Rope on the Farm* (1964) in
`Southern-Oregon\Homestead-Skills\Food-Crafts-Tools`; *Military Mountaineering* (TC 3-97.61) and Kephart's *Camping and
Woodcraft* in `Southern-Oregon\Travel-On-Foot`; the Air Force survival handbook (AFH 10-644) and the 1911 Scout handbook
in `Southern-Oregon\Comms-Signals\Visual-Sound-Signals`; picket lines and pack hitches (FM 25-7) in
`Southern-Oregon\Horses-Draft-Animals\Packing-Travel`.

> ### The short version
> - **Learn a few knots well.** "It is better to learn a few knots perfectly" than a long list
>   ([*Bluejackets' Manual*, p. 258](lib:bluejackets-manual#page=258)).
> - **The square knot is for bundles, not loads:** it "will not hold if the ropes are wet or if they are of different
>   sizes" ([FM 5-125, p. 46](lib:fm-5-125#page=46)). Join ropes with a sheet bend.
> - **Every knot weakens rope.** A splice keeps 80–90% of its strength, a knot 50–60%
>   ([*Rope on the Farm*, p. 6](lib:rope-on-the-farm#page=6)).
> - **Load rope to a quarter of its breaking strength or less.** Fiber rope, rule of thumb: safe load in tons =
>   (diameter in inches)², so ½ inch carries ¼ ton ([FM 5-125, p. 20](lib:fm-5-125#page=20)).
> - **Don't trust rope you can't vouch for:** "A rope of unknown history or construction should not be used for any
>   application" ([TC 3-97.61, p. 170](lib:tc-3-97-61#page=170)).
> - **Stay out of its way.** Never stand in a loop of loaded rope *(rule of thumb)*, never wrap rope round your hand
>   ([4-H PNW 587, p. 51](lib:the-4-h-horse-project#page=51)), and never hold a hanging load by hand alone — take a turn
>   round a post ([*Mounted Instruction*, p. 222](lib:mounted-instruction-for-field-artillery#page=222)).
> - **Round an animal's neck, only a bowline** (same 4-H page).
> - **Store rope dry, off the ground, out of the sun** ([*Rope on the Farm*, pp. 12, 14](lib:rope-on-the-farm#page=12)).

---

## 🧭 Which knot for which job

| The job | The knot |
|---|---|
| Tie a bundle, a sack, a bandage (never a load) | [Square knot](#square-knot-bundles-not-loads) |
| A loop that won't slip: round a post, a person, an animal's neck | [Bowline](#bowline-a-loop-that-wont-slip-or-jam) |
| Join two ropes, even of different sizes or wet | [Sheet bend](#sheet-bend-joining-two-ropes) |
| Quick tie to a post; start a lashing | [Clove hitch](#clove-hitch-quick-tie-to-a-post) |
| Tie off to a tree or ring under load and leave it | [Round turn and two half hitches](#two-half-hitches-and-the-round-turn) |
| A tent or guy line you can tighten later | [Taut-line hitch](#taut-line-hitch-a-line-you-can-tighten) |
| Cinch a load down; stretch a picket line | [Trucker's hitch](#truckers-hitch-pulling-a-load-down-tight) |
| Drag or lift a log or pole | [Timber hitch](#timber-hitch-dragging-logs-and-poles) plus a half hitch |
| Stop an end slipping through; the strongest fixed loop | [Figure eight](#figure-eight-the-stopper-and-the-loop) |
| Grip another rope; hold what you've hauled | [Prusik](#prusik-a-grip-that-slides-then-holds) |
| Poles crosswise; an A-frame | [Square and shear lashings](#lashing-poles-together) |
| Stop fraying; join or make an eye for good | [Whipping and splices](#whipping-and-splicing) |
| Tie up a horse or cow | [Quick-release knot](#tying-out-animals-and-lashing-loads) |

**Rope words** ([FM 5-125, pp. 41–42](lib:fm-5-125#page=41)): the **standing part** is the long, idle part; the
**running end** is the end you tie with; a **bight** is a U-bend; a **loop** crosses itself; a **turn** goes once round a
post; a **round turn** goes round and a half.

## 🪢 The knots, step by step

Practise with rope at least ⅛ inch thick, not string ([Kephart, p. 275](lib:kephart-camping-and-woodcraft-vol-2#page=275)).
**Dress** every knot — parts lying neatly side by side, slack pulled out. A sloppy knot can lose another 50% of its
strength ([FM 3-05.70, p. 640](lib:fm-3-05-70#page=640)).

### Square knot: bundles, not loads
<!-- fold: Two ends of the same size joined flat; never trust it with weight -->

For two ends of the **same size** where nothing hangs on it ([AFH 10-644, p. 262](lib:afh-10-644#page=262);
[🖼️ square, granny and thief knots](lib:afh-10-644#page=263); [Square knot](wiki:Reef_knot)):
1. Cross the right end over the left and tuck it under.
2. Cross the left end over the right and tuck it under.
3. Check: each end lies beside its own standing part. If not, it's a **granny**, which "will slip under strain".
4. To untie, push the two bends toward each other.

![Three drawings of a square knot: 1, the right end crossed over the left and tucked under, with arrows showing the two ends about to cross again; 2, the left end crossed over the right and tucked under; 3, the finished flat knot, each end lying beside its own standing part](img:KNOTS-ROPE-GUIDE/square-knot.png)
*Right over left and under, then left over right and under ([FM 5-125, p. 48](lib:fm-5-125#page=48)).*

On a rope that matters, tie an overhand knot in each tail — and use it only "when it is impossible to tie a more secure
joining knot" ([TC 3-97.61, p. 189](lib:tc-3-97-61#page=189); [🖼️ with safety knots](lib:fm-3-05-70#page=643)).

### Bowline: a loop that won't slip or jam
<!-- fold: A fixed loop at the end of a rope that won't slip, tighten or jam -->

"The best knot for forming a single loop that will not tighten or slip under strain"
([FM 5-125, p. 49](lib:fm-5-125#page=49); [🖼️ drawing](lib:fm-5-125#page=50); [Bowline](wiki:Bowline)).
1. Leave enough end for the loop. On the standing part make a small loop, the end side lying **on top**.
2. Bring the end **up through** the small loop,
3. **round behind** the standing part,
4. and **back down** through the small loop, beside itself.
5. Hold the end against the big loop and pull the standing part to set it
   ([AFH 10-644, pp. 264–265](lib:afh-10-644#page=264); [Kephart, p. 286](lib:kephart-camping-and-woodcraft-vol-2#page=286)).
6. **Back it up** with an overhand knot in the tail round the loop's side, leaving about 4 inches
   ([TC 3-97.61, p. 191](lib:tc-3-97-61#page=191); [🖼️ drawing](lib:tc-3-97-61#page=191)).

![Four photos of tying a bowline in red rope: 1, a small loop made in the standing part, the end beside it; 2, the end brought up through the small loop; 3, the end taken round behind the standing part; 4, the end back down through the small loop and the knot pulled snug, leaving a loop that will not slip](img:KNOTS-ROPE-GUIDE/bowline.png)
*Steps 1 to 4: up through the small loop, round behind, back down ([AFH 10-644, p. 265](lib:afh-10-644#page=265)).*

It unties easily even after a heavy pull. For lifting a person, use a figure-eight loop (below).

### Sheet bend: joining two ropes
<!-- fold: Joins two ropes, even of different thickness; the double one holds wet rope -->

([FM 5-125, p. 47](lib:fm-5-125#page=47); [🖼️ single and double](lib:fm-5-125#page=48); [Sheet bend](wiki:Sheet_bend))
1. Bend the **thicker** rope into a U.
2. Pass the thinner rope's end **up through** the U,
3. **round behind** both legs of the U,
4. and **under itself** (not under the U). Pull snug ([AFH 10-644, p. 263](lib:afh-10-644#page=263)).

![Three photos of a sheet bend joining a thick white rope and a thin red one: 1, the thick rope bent into a U, the thin end coming up through it; 2, the thin end taken round behind both legs of the U; 3, the thin end tucked under itself and the knot pulled snug](img:KNOTS-ROPE-GUIDE/sheet-bend.png)
*The thin rope goes up through the thick one's U, round behind it, and under itself ([AFH 10-644, p. 264](lib:afh-10-644#page=264)).*

It can loosen when slack. For wet rope or heavy loads take the thin end round a second time before tucking: the
**double sheet bend** "will not slip or draw tight under heavy loads" ([AFH 10-644, p. 264](lib:afh-10-644#page=264)).

### Clove hitch: quick tie to a post
<!-- fold: Ties a rope to a post or pole in seconds and starts every lashing -->

([FM 5-125, p. 61](lib:fm-5-125#page=61); [🖼️ drawing](lib:fm-5-125#page=62); [🖼️ end of a rope](lib:tc-3-97-61#page=201);
[Clove hitch](wiki:Clove_hitch))
- **Round a pole:** take the end round once, crossing over the standing part; round again the same way; tuck the end
  under that second turn. End and standing part leave on opposite sides ([AFH 10-644, p. 268](lib:afh-10-644#page=268);
  [Kephart, p. 283](lib:kephart-camping-and-woodcraft-vol-2#page=283)).
- **Over a post top:** twist two loops the same way, lay the second behind the first, drop both over the post
  ([Kephart, p. 282](lib:kephart-camping-and-woodcraft-vol-2#page=282)).

![Six photos of the clove hitch in red rope. Top row, over a post top: 1a, two loops twisted the same way; 1b, the second laid behind the first; 1c, both dropped over a post, here a metal snap link. Bottom row, round a pole: 2a, the end taken once round the pole; 2b, round again beside the first turn; 2c, the end tucked under the second turn and pulled snug](img:KNOTS-ROPE-GUIDE/clove-hitch.png)
*Top row: over a post top. Bottom row: round a pole ([AFH 10-644, p. 269](lib:afh-10-644#page=269)).*

It slips when the pull comes and goes: "tension must remain on the knot or it will slip"
([FM 3-05.70, p. 643](lib:fm-3-05-70#page=643)). Add a half hitch round the standing part.

### Two half hitches and the round turn
<!-- fold: The everyday way to tie off to a ring, tree or post and leave it -->

**Two half hitches:** pass the end round the post, round the standing part and back under itself; do it again beside
the first ([AFH 10-644, p. 269](lib:afh-10-644#page=269); [🖼️ drawing](lib:fm-5-125#page=60)).

**Round turn and two half hitches** — for a real load. It "does not jam" ([FM 5-125, p. 60](lib:fm-5-125#page=60)); it is
the Army's "main anchor knot" where "high loads would make other knots jam" ([FM 3-05.70, p. 642](lib:fm-3-05-70#page=642);
[Round turn and two half-hitches](wiki:Round_turn_and_two_half-hitches)):
1. Take the end round the post **twice**. These turns take the strain.
2. Tie two half hitches round the standing part. Seize the tail to it for more security
   ([AFH 10-644, p. 269](lib:afh-10-644#page=269)).

### Taut-line hitch: a line you can tighten
<!-- fold: An adjustable loop for tent, tarp and guy lines that grips under load -->

No book here draws it. It is a **rolling hitch** tied round the rope's own standing part, and a rolling hitch "grips
tightly but is easily moved along a rope or pole when the strain is relieved" ([FM 5-125, p. 61](lib:fm-5-125#page=61);
[🖼️ rolling hitch](lib:fm-5-125#page=63); [Taut-line hitch](wiki:Taut-line_hitch)). Steps *(rule of thumb)*:
1. Pass the end round the stake or through the grommet.
2. Wrap it **twice** round the standing part, working back toward the stake, inside the loop.
3. Then one **half hitch** round the standing part, beyond those two wraps (away from the stake).
4. Snug it. Slide the knot to tighten or slacken; under load it holds.

![Drawing of a taut-line hitch: the line comes from the tent, goes round a stake and comes back; its end wraps twice round the standing part inside the loop, working toward the stake, then goes back over the wraps and makes one half hitch round the standing part outside the loop, its end tucked under itself. Sliding the knot toward the tent tightens the line](img:KNOTS-ROPE-GUIDE/taut-line-hitch.svg)
*Two wraps inside the loop, one half hitch outside; drawn loose so the rope's path shows (a diagram drawn for this guide).*

Slacken guy lines before rain: wet rope shrinks "and may break" ([FM 5-125, p. 21](lib:fm-5-125#page=21)).

### Trucker's hitch: pulling a load down tight
<!-- fold: A rope-only pulley for cinching loads and stretching picket lines -->

The Army's pack manual stretches picket lines with it (a "pullback"), giving "a two-to-one mechanical advantage"
([FM 25-7, p. 156](lib:pack-transportation-war-dept-fm-25-7#page=156)); the Air Force ties packs with it
([AFH 10-644, p. 451](lib:afh-10-644#page=451); [Trucker's hitch](wiki:Trucker%27s_hitch)).
1. Tie one end to the load or the far anchor.
2. A few feet short of the near anchor, make a **fixed loop** in the standing part. FM 25-7 uses a sheepshank
   ([🖼️ sheepshank](lib:fm-5-125#page=66)); a figure-eight loop works too *(rule of thumb)*.
3. Pass the end round the near anchor (hook, ring, stake) and **back through the loop**.
4. **Pull it back toward the anchor.**
5. Pinch it at the loop and tie off with two half hitches, or a slipped half hitch "directly behind the pullback" that
   one tug releases (FM 25-7, p. 156).

![Drawing of a trucker's hitch: the rope comes down from the load into a figure-eight loop tied in it, the loop hanging toward the hook; the rest of the rope runs down the side, round the hook or rail, back up through the loop, and down again, to be pulled hard, pinched at the loop and tied off with two half hitches](img:KNOTS-ROPE-GUIDE/truckers-hitch.svg)
*A figure-eight loop, the end round the hook and back up through the loop; pull, pinch and tie off (a diagram drawn for this guide).*

The rope rubs on itself in the loop: don't lift loads with it *(rule of thumb)*.

### Timber hitch: dragging logs and poles
<!-- fold: Grips a log or pole harder the harder you pull, and falls off when slack -->

"The more tension applied, the tighter the hitch becomes"; it loosens when the strain comes off
([FM 5-125, p. 60](lib:fm-5-125#page=60); [🖼️ drawing](lib:fm-5-125#page=61); [Timber hitch](wiki:Timber_hitch)).
1. Pass the end round the log and round the standing part.
2. Twist it **round itself** three or more times. The twists must go round the end's own part "or the knot will not
   tighten against the pull" ([AFH 10-644, p. 268](lib:afh-10-644#page=268)).
3. **To drag or lift, add a half hitch** farther along the log toward the pulling end: it takes the strain, and the
   timber hitch keeps it from slipping (same page). Alone, a timber hitch "may become untied when the rope is slack or
   when a sudden strain is put on it" ([FM 5-125, p. 60](lib:fm-5-125#page=60)).

![Three photos on an upright pole: 1, a half hitch; 2, a timber hitch, the end twisted round itself several times; 3, the two together for dragging, the half hitch toward the pulling end and the timber hitch farther along the pole](img:KNOTS-ROPE-GUIDE/timber-hitch.png)
*A half hitch, a timber hitch, and the two together for dragging or lifting ([AFH 10-644, p. 268](lib:afh-10-644#page=268)).*

### Figure eight: the stopper and the loop
<!-- fold: A knob that stops the end slipping through, and the strongest fixed loop -->

**Stopper:** make a loop in the standing part, take the end round behind the standing part and back down through the
loop ([AFH 10-644, p. 262](lib:afh-10-644#page=262); [🖼️ drawing](lib:fm-5-125#page=45); [Figure-eight knot](wiki:Figure-eight_knot)).
It stops an end slipping through a pulley or ring and is easy to untie ([FM 5-125, p. 45](lib:fm-5-125#page=45)).

**Figure-eight loop:** "the main rescue knot in use today", stronger than the bowline and easier to check, though harder
to untie when wet after a load ([FM 3-05.70, p. 647](lib:fm-3-05-70#page=647)). Double the rope into a bight as long as
the loop, tie a figure eight with it, and check the two ropes run side by side without crossing
([TC 3-97.61, p. 180](lib:tc-3-97-61#page=180); [🖼️ drawing](lib:tc-3-97-61#page=180)). To tie it round a tree, tie a loose
single eight, pass the end round, and trace it back through ([🖼️ retraced](lib:tc-3-97-61#page=181)).

![Three drawings of a figure-eight loop: 1, the rope doubled into a bight and a loop formed with it; 2, the bight passed round and through, making a figure eight in the doubled rope; 3, the knot dressed and pulled tight, the two ropes side by side, with a fixed loop above](img:KNOTS-ROPE-GUIDE/figure-eight-loop.png)
*The figure-eight loop tied in a doubled rope ([TC 3-97.61, p. 180](lib:tc-3-97-61#page=180)).*

### Prusik: a grip that slides, then holds
<!-- fold: A loop of thinner cord that slides along a rope loose and grips it under load -->

It "will slide ... if no tension is applied, and will hold if tension is applied" ([FM 3-05.70, p. 645](lib:fm-3-05-70#page=645);
[Prusik](wiki:Prusik)): a handhold or foot loop on a fixed rope, or a catch that holds a hauled load while you reset.
1. **The cord:** about 6 ft (1.8 m) tied into a loop with a double fisherman's knot
   ([TC 3-97.61, p. 170](lib:tc-3-97-61#page=170)), about 3 mm thinner than the main rope ([p. 194](lib:tc-3-97-61#page=194)).
2. Lay the loop behind the main rope. Pass the far end through the near end, round the rope, **three times**, each wrap
   inside the last.
3. Dress it: six neat, parallel wraps with one bar across them ([p. 196](lib:tc-3-97-61#page=196);
   [🖼️ drawing](lib:tc-3-97-61#page=195)).
4. **Test that it grips** before you load it ([p. 194](lib:tc-3-97-61#page=194)).

![Six drawings of a prusik tied in the middle of a doubled cord on a horizontal rope: the cord laid over the rope, its ends passed through its own bight, round again and through, three times, until there are six neat wraps with a bar across them and the two strands hanging down from the middle](img:KNOTS-ROPE-GUIDE/prusik.png)
*Six neat wraps and one bar across them ([TC 3-97.61, p. 195](lib:tc-3-97-61#page=195)).*

## 🪵 Lashing poles together

Lashings start and end with clove hitches; **frapping turns**, wound between the poles round the wraps, pull everything
tight ([FM 3-05.70, p. 640](lib:fm-3-05-70#page=640); [Lashing](wiki:Lashing_(ropework))).

### Square lashing
<!-- fold: Joins two poles crossing at a right angle: fences, racks, frames -->

([FM 5-125, p. 67](lib:fm-5-125#page=67); [🖼️ drawing](lib:fm-5-125#page=68); [🖼️ AFH](lib:afh-10-644#page=271))
1. Clove hitch on the upright, just below the crosspiece.
2. Wrap over the crosspiece, behind the upright, over the crosspiece's other side, behind the upright. Each turn lies
   **outside** the last on the crosspiece and **inside** it on the upright ([AFH 10-644, p. 271](lib:afh-10-644#page=271)).
3. **At least four** tight turns ([FM 5-125, p. 67](lib:fm-5-125#page=67)).
4. Two or three frapping turns, pulled hard.
5. Finish with a clove hitch (FM 5-125 puts it on the other pole, AFH 10-644 on the first; either holds if tight).

![Four drawings of a square lashing on a crosspiece and an upright: 1, a clove hitch on the upright just below the crosspiece; 2, the rope wrapped over the crosspiece and behind the upright; 3, four turns, then two or three frapping turns between the poles; 4, finished with a clove hitch](img:KNOTS-ROPE-GUIDE/square-lashing.png)
*Clove hitch, four turns, frapping turns, clove hitch ([FM 5-125, p. 68](lib:fm-5-125#page=68)).*

### Shear lashing
<!-- fold: Ties two poles side by side so they spread into an A-frame -->

For an A-frame to lift or hang things ([FM 5-125, p. 67](lib:fm-5-125#page=67); [🖼️ drawing](lib:fm-5-125#page=68)):
1. Two poles side by side, butts together, a third of a pole's thickness apart.
2. Clove hitch on one pole a little below the top; **eight** tight turns round both.
3. At least two frapping turns between the poles; clove hitch on the other pole. Spread the butts.

For legs that must spread wide, wind more loosely ([Kephart, p. 296](lib:kephart-camping-and-woodcraft-vol-2#page=296)).
Three poles make a tripod ([🖼️ tripod lashing](lib:fm-3-05-70#page=649)).

## 🧵 Whipping and splicing

"Use splices instead of knots whenever possible" ([*Rope on the Farm*, p. 6](lib:rope-on-the-farm#page=6)).

### Whipping a rope's end
<!-- fold: Binding a cut end with twine so it can't fray -->

([AFH 10-644, p. 260](lib:afh-10-644#page=260); [🖼️ drawing](lib:afh-10-644#page=261); [Whipping knot](wiki:Whipping_knot))
1. Bend strong twine into a long, narrow U; lay it along the rope, the U poking ½ inch past the rope's end.
2. From the inner end, wrap the twine tightly round rope and U, **the same way the rope is twisted**, to within ½ inch
   of the end.
3. Slip the twine's end through the U. Pull the other end until the U drags it under the wraps. Trim both close.

![Six photos of whipping a white rope's end with dark twine: 1, the twine laid along the rope in a long U; 2, wrapping begun at the inner end; 3, wrapped toward the end, the twine's end slipped through the U; 4, the other end pulled to draw the U under the wraps; 5, finished and trimmed; 6, a rope whipped in two places being cut between them](img:KNOTS-ROPE-GUIDE/whipping.png)
*Whipping an end, and (6) whipping twice before cutting ([AFH 10-644, p. 261](lib:afh-10-644#page=261)).*

Wrap about as long as the rope is thick ([*Rope on the Farm*, p. 6](lib:rope-on-the-farm#page=6)). **Before cutting**,
whip twice 1–2 inches apart and cut between ([FM 5-125, p. 42](lib:fm-5-125#page=42)). Synthetic rope: melt only the
cut end ([TC 3-97.61, p. 209](lib:tc-3-97-61#page=209)).

### Short splice
<!-- fold: Joins two three-strand ropes for good, nearly as strong as the rope -->

Joins two ropes of the same size for good; it's fatter than the rope, so not for pulleys
([*Rope on the Farm*, p. 7](lib:rope-on-the-farm#page=7); [🖼️ steps](lib:rope-on-the-farm#page=7); [Rope splicing](wiki:Rope_splicing)).
Open strands with a smooth, tapered hardwood pin about a foot long ([p. 6](lib:rope-on-the-farm#page=6)).
1. Untwist each end several turns; tape each strand end.
2. Push the ends together so each strand lies between two strands of the other rope.
3. Working across the twist, take each strand **over** its neighbour and **under** the next. Do the same from the other
   rope.
4. Tuck every strand **at least twice more**. Trim, and roll the splice underfoot to even it.

If two strands go under one, redo them (p. 6). For pulleys, use the slimmer **long splice**
([🖼️ steps](lib:rope-on-the-farm#page=8)).

### Eye splice
<!-- fold: A permanent loop in the end of a rope, better than any knot -->

"As a permanent loop or eye, no knot can compare with this splice" ([FM 5-125, p. 70](lib:fm-5-125#page=70);
[🖼️ steps](lib:rope-on-the-farm#page=11); [Eye splice](wiki:Eye_splice)).
1. Untwist the end 5 or 6 turns (put it through any ring now).
2. Bend it back to the eye size. Tuck the **middle** strand under the nearest strand of the rope, against the twist.
3. Take the next strand over that one and under the next.
4. Turn it over; tuck the last strand under the remaining one. The ends now stick out evenly round the rope.
5. Tuck each at least twice more, over one, under one ([*Rope on the Farm*, p. 11](lib:rope-on-the-farm#page=11)).

![Three photos of an eye splice in three-strand rope, one strand dark: A, the end untwisted and its middle strand tucked under the nearest strand of the rope; B, the next strand tucked under the next strand; C, all three tucked and woven in, over one and under one](img:KNOTS-ROPE-GUIDE/eye-splice.png)
*First tuck (A), second (B), and the finished splice (C) ([*Rope on the Farm*, p. 11](lib:rope-on-the-farm#page=11)).*

A metal **thimble** inside the eye saves wear ([FM 5-125, p. 70](lib:fm-5-125#page=70)).

## ⚖️ How strong is a rope?

### Working load and breaking strength
<!-- fold: How much weight a rope may carry, by rule of thumb and by its condition -->

**Breaking strength** is the pull that parts it; the **safe working load** is "considerably less"
([Navy *Construction Electrician*, p. 12](lib:construction-electrician-basic#page=12)). Safe load = breaking strength ÷ a
**safety factor**: a new 1-inch manila rope breaks at 9,000 lb, so with a factor of 4 it may carry 2,250 lb. With no
table, safe tons = (diameter in inches)², which allows a factor of about 4 ([FM 5-125, p. 20](lib:fm-5-125#page=20)).

| Rope | Safety factor ([Navy, p. 12](lib:construction-electrician-basic#page=12)) |
|---|---|
| New | 4 |
| Used, in good shape | 6 |
| Worked hard: pulleys, daily use | 8 |

The factor should "NEVER be less than 3" (same page). Jerks, knots and sharp bends can cut strength "as much as
50 percent" ([FM 5-125, p. 20](lib:fm-5-125#page=20)). Nylon is nearly three times as strong as manila
([p. 19](lib:fm-5-125#page=19)); cotton is "not satisfactory for general farm use"
([*Rope on the Farm*, p. 4](lib:rope-on-the-farm#page=4)).

### Knots weaken rope
<!-- fold: How much strength each knot costs -->

| Knot | Strength left ([TC 3-97.61, p. 177](lib:tc-3-97-61#page=177), nylon) |
|---|---|
| Figure eight | 75–80% |
| Bowline | 70–75% |
| Two half hitches | 60–70% |
| Clove hitch, overhand | 60–65% |

A plain overhand knot cuts a straight rope's strength by 55% ([FM 5-125, p. 44](lib:fm-5-125#page=44)). A pulley block for fiber
rope should be about 8 times as long as the rope is thick ([*Rope on the Farm*, p. 11](lib:rope-on-the-farm#page=11)).

### Wet, rotten and sun-damaged rope
<!-- fold: What water, frost, heat, sun, rot and chemicals do, and how to check inside -->

- **Wet:** natural rope shrinks — slacken lines before rain. **Frozen:** thaw it fully first, or "the frozen fibers will
  break". **Heat** or boiling water cuts strength about 20% ([FM 5-125, p. 21](lib:fm-5-125#page=21)). Wet nylon loses
  little ([Navy, p. 13](lib:construction-electrician-basic#page=13)).
- **Sun:** keep natural rope out of it ([*Rope on the Farm*, p. 12](lib:rope-on-the-farm#page=12)); months of sun weaken
  nylon ([TC 3-97.61, p. 209](lib:tc-3-97-61#page=209)).
- **Chemicals:** acids, drying oils, fumes, paint and linseed oil ([*Rope on the Farm*, pp. 4, 12](lib:rope-on-the-farm#page=4)),
  lime ([Navy, p. 12](lib:construction-electrician-basic#page=12)) and petroleum ([TC 3-97.61, p. 210](lib:tc-3-97-61#page=210)).
- **Rot hides inside.** Untwist the strands and look: mildewed rope smells musty, its inner fibers dark and stained;
  sawdust-like powder means chafing. Pull two fibers — sound ones resist breaking. Cut bad rope into short pieces so no one
  hoists with it ([FM 5-125, pp. 22–23](lib:fm-5-125#page=22)).

## 🦺 Safe around a loaded rope
<!-- fold: Where to stand, holding loads, sharp edges and slings -->

- **Never stand in a bight or a coil** of rope that is running or about to take a load, never step across a loaded rope,
  and stand aside from its line of pull *(rule of thumb)*: overloaded rope breaks "with ... serious injury to personnel"
  ([FM 5-125, p. 22](lib:fm-5-125#page=22)), and stretchy nylon snaps back.
- **Never wrap rope round your hand or body**, and keep slack away from your feet
  ([4-H PNW 587, p. 51](lib:the-4-h-horse-project#page=51)).
- **Never hold a hanging weight by hand alone:** "always take a turn around some object", and "keep what they gain"
  ([*Mounted Instruction*, p. 222](lib:mounted-instruction-for-field-artillery#page=222)).
- **Steady a raised load** with a guy rope, and **pad sharp edges** with sacking or wood
  ([*Mounted Instruction*, p. 218](lib:mounted-instruction-for-field-artillery#page=218)): "Rope is cut more easily when
  under tension" ([TC 3-97.61, p. 209](lib:tc-3-97-61#page=209)).
- **Slings:** the wider the legs spread, the harder each is pulled — "stay above the critical angle"
  ([FM 5-125, pp. 100–102](lib:fm-5-125#page=100); [🖼️ sling angles](lib:fm-5-125#page=105)).

## 🏗️ Lifting and hauling: block and tackle
<!-- fold: Counting pulleys, friction, how much people can pull, and anchors -->

- **Count the ropes holding up the moving block** (the one on the load): three ropes, 3 to 1. Count the pulling end too
  if it leaves from the moving block ([FM 5-125, p. 110](lib:fm-5-125#page=110); [🖼️ simple tackles](lib:fm-5-125#page=112);
  [Block and tackle](wiki:Block_and_tackle)).
- **A pulley tied to a tree only turns the rope**, "without affecting" the advantage ([FM 5-125, p. 106](lib:fm-5-125#page=106)).
  Two tackles in a row multiply: 4:1 on 4:1 gives 16:1 ([p. 111](lib:fm-5-125#page=111)).
- **You pay in rope:** at 5:1 you pull 5 ft for each foot the load moves; use the least advantage that will do
  ([TC 3-97.61, p. 323](lib:tc-3-97-61#page=323)).
- **Friction:** about **10% of the load per pulley**. 5,000 lb on a 4:1 over four pulleys needs (5,000 + 2,000) ÷ 4 =
  1,750 lb of pull ([FM 5-125, pp. 114–115](lib:fm-5-125#page=114)).
- **People:** about 100 lb each pulling down, 60 lb each pulling sideways, but more people fit along a level line; lead
  the rope out through a pulley ([FM 5-125, p. 115](lib:fm-5-125#page=115)).
- **Hold what you gain** with a prusik on the load rope ([TC 3-97.61, p. 324](lib:tc-3-97-61#page=324)). No pulleys? A
  trucker's hitch pulls with rope alone: the Army calls it "a two-to-one mechanical advantage"
  ([FM 25-7, p. 156](lib:pack-transportation-war-dept-fm-25-7#page=156)). Rope dragging on rope eats much of it, so
  count on less than the arithmetic says *(rule of thumb)*.
- **Anchors:** a stake 3 inches thick and 5 ft long, driven 3 ft and leaning 15° away from the pull, holds about **700 lb**
  in loamy soil; two lashed together, about 1,400 lb ([FM 5-125, pp. 125–126](lib:fm-5-125#page=125);
  [🖼️ lashing two stakes](lib:fm-5-125#page=127)).

## 🧺 Caring for rope
<!-- fold: Opening, coiling, drying, storing and inspecting rope so it lasts -->

- **New coil:** pull the end up through the middle, unwinding counterclockwise ([FM 5-125, p. 22](lib:fm-5-125#page=22)).
- **Kinks:** unwind them, don't pull them out ([*Rope on the Farm*, p. 12](lib:rope-on-the-farm#page=12)). Coil ordinary
  rope clockwise; to clear kinks, coil it counterclockwise and pull the bottom end up through the middle
  ([Navy, p. 12](lib:construction-electrician-basic#page=12)).
- **Grit cuts fibers:** don't drag rope through sand or dirt ([FM 5-125, p. 21](lib:fm-5-125#page=21)).
- **Dry before storing,** or it gets dry rot ([*Rope on the Farm*, p. 14](lib:rope-on-the-farm#page=14)). Hang it in the
  shade to dry ([p. 12](lib:rope-on-the-farm#page=12)), in loose loops, never by heat ([TC 3-97.61, p. 209](lib:tc-3-97-61#page=209)).
- **Store it airy:** loose coils on wooden pegs or slats 6 inches off the floor, dry and unheated, away from chemicals
  ([Navy, p. 12](lib:construction-electrician-basic#page=12)). Unused rope: uncoil, dry and stretch it every six months
  ([*Mounted Instruction*, p. 218](lib:mounted-instruction-for-field-artillery#page=218)).
- **Look over every foot** of it regularly ([Navy, p. 11](lib:construction-electrician-basic#page=11)), and keep a life
  rope for that only ([TC 3-97.61, p. 210](lib:tc-3-97-61#page=210)). To carry it, a butterfly coil is quickest
  ([🖼️ drawing](lib:tc-3-97-61#page=211)).

## 🌿 Making cordage from plants and hide
<!-- fold: Testing a fiber, twisting it into cord, and sinew and rawhide lashings -->

**Plant fiber, in short.** Pull it, twist it, then tie an overhand knot: "If the knot does not break, the material is
usable" ([FM 3-05.70, p. 201](lib:fm-3-05-70#page=201); [🖼️ making lines](lib:fm-3-05-70#page=201)). Try inner bark of
linden, elm, hickory, white oak, mulberry or cedar (same page), dogbane stems cut in autumn
([NRCS dogbane guide, p. 3](lib:indian-hemp-dogbane#page=3); poisonous to eat and to stock, [pp. 1–2](lib:indian-hemp-dogbane#page=1)),
or mature nettle stems ([OSU EM 9373, p. 1](lib:osu-wild-edibles-stinging-nettle#page=1)). Twist even strands clockwise,
then lay two or three together counterclockwise so they lock ([AFH 10-644, p. 274](lib:afh-10-644#page=274);
[🖼️ the twists](lib:afh-10-644#page=275)). A one-inch bark rope may hold 200–1,500 lb: "the lowest figure should always be
regarded as the tensile strength" ([p. 273](lib:afh-10-644#page=273)). Retting nettle and spinning:
[Clothing & Leather](guide:CLOTHING-LEATHER-GUIDE), "Linen, nettle and native fibers". More, with the valley's own plants: [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE) ("Fibers, cordage and nets").


**From animals** ([FM 3-05.70, pp. 201–202](lib:fm-3-05-70#page=201)):
- **Sinew** for small lashings: dry deer tendons, smash them into fibers, moisten and twist. It needs no knots and
  hardens as it dries.
- **Rawhide strips** for big ones: cut the dry, cleaned hide into one ¼-inch strip spiralling out from the middle, soak
  it 2–4 hours, and stretch it on wet; it dries hard and tight. Making rawhide: [Clothing & Leather](guide:CLOTHING-LEATHER-GUIDE),
  "Tanning hides".

## 🐴 Tying out animals and lashing loads
<!-- fold: Tying a horse or cow safely, picket lines, a rope halter, and loads on carts and pack animals -->

**Tying an animal** ([4-H PNW 587, pp. 51–52](lib:the-4-h-horse-project#page=51); [🖼️ quick-release knot](lib:the-4-h-horse-project#page=51);
[Halter hitch](wiki:Halter_hitch)):
- A **quick-release knot** on the lead, about 3 ft of rope, no lower than the withers, to a post set in the ground — not
  a fence rail. Never by the reins, never with a chain.
- Round the neck, a **bowline**: "Never use a slip knot around the horse's neck." A tightening knot can choke a
  struggling animal ([*Where There Is No Animal Doctor*, p. 35](lib:where-there-is-no-animal-doctor#page=35)).

**A rope halter** for a horse or cow: 14 ft of ½- or ⅝-inch three-strand rope, a tuck splice 18–22 inches from one end,
and an eye splice in the short end ([*Rope on the Farm*, p. 16](lib:rope-on-the-farm#page=16); [🖼️ drawing](lib:rope-on-the-farm#page=16)).

**Picket lines:** a rope stretched tight on the ground between two pins, or 4–5 ft up between trees, tightened with a
trucker's hitch. Tie animals 24 inches apart, alternate sides, short enough that they can't get a leg over
([FM 25-7, pp. 155–156](lib:pack-transportation-war-dept-fm-25-7#page=155)).

**Pack and cart loads:** balance the load, keep ropes away from the animal's feet and legs, and make every part as tight
as possible ([FM 25-7, p. 66](lib:pack-transportation-war-dept-fm-25-7#page=66)). Cinch cart loads with trucker's hitches.
Pack saddles and the diamond hitch: [Horses](guide:HORSE-GUIDE). Carts, trailers and packboards:
[Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE).

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Square knot for ropes "under a heavy strain", with "a tapered metal or wood rod through the center" ([*Rope on the Farm*, p. 10](lib:rope-on-the-farm#page=10)); it "Never slips or jams" ([1911 Scout handbook, p. 78](lib:boy-scouts-handbook-for-boys#page=78)) | It "will not hold if the ropes are wet or if they are of different sizes" ([FM 5-125, p. 46](lib:fm-5-125#page=46)). Use a double sheet bend |
| Blackwall hitch: "apply the load ... so that the rope jams firmly on the hook" ([*Rope on the Farm*, p. 15](lib:rope-on-the-farm#page=15)) | "Human life and breakable equipment should never be entrusted to the blackwall hitch" ([FM 5-125, pp. 62–63](lib:fm-5-125#page=62)). Use an eye splice or a cat's-paw ([p. 53](lib:fm-5-125#page=53)) |
| Bowline "Used in lowering a person from a burning building" ([1911 Scout handbook, p. 78](lib:boy-scouts-handbook-for-boys#page=78)); the bowline on a bight "is the sling for hoisting a man" ([Kephart, p. 291](lib:kephart-camping-and-woodcraft-vol-2#page=291)) | The figure eight has replaced it for rescue: stronger, easier to check ([FM 3-05.70, pp. 646–647](lib:fm-3-05-70#page=646)) |
| Safe load "one-third to one-half the breaking weight" ([*Mounted Instruction*, p. 218](lib:mounted-instruction-for-field-artillery#page=218)) | A quarter for new rope, an eighth for hard-used rope ([Navy, p. 12](lib:construction-electrician-basic#page=12)) |
| Two half hitches "will not slip under any strain" ([1911 Scout handbook, p. 79](lib:boy-scouts-handbook-for-boys#page=79)) | A half hitch "is not a very secure knot" ([AFH 10-644, p. 267](lib:afh-10-644#page=267)). For a load, a round turn and two half hitches |
| The clove hitch "will not slip on itself nor along the pole" ([Kephart, p. 282](lib:kephart-camping-and-woodcraft-vol-2#page=282)) | "Tension must remain on the knot or it will slip" ([FM 3-05.70, p. 643](lib:fm-3-05-70#page=643)) |
| A running noose with a stopper, "a simple way of picketing a horse" ([Kephart, pp. 289–290](lib:kephart-camping-and-woodcraft-vol-2#page=289)) | Only a bowline round an animal's neck ([4-H PNW 587, p. 51](lib:the-4-h-horse-project#page=51)) |
| "A whip tackle doubles the power" ([*Mounted Instruction*, p. 222](lib:mounted-instruction-for-field-artillery#page=222)) | Only if the pulley rides on the load; one tied to a beam just turns the rope ([FM 5-125, p. 106](lib:fm-5-125#page=106)) |

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; the other links are photos in the offline Wikipedia.

- Rope words, the parts of a knot — [🖼️ FM 5-125, p. 41](lib:fm-5-125#page=41)
- Square, granny and thief knots — [🖼️ AFH 10-644, p. 263](lib:afh-10-644#page=263); [🖼️ FM 5-125, p. 48](lib:fm-5-125#page=48); [Square knot](wiki:Reef_knot); [Granny knot](wiki:Granny_knot)
- Bowline — [🖼️ FM 5-125, p. 50](lib:fm-5-125#page=50); [🖼️ AFH 10-644, p. 265](lib:afh-10-644#page=265); [🖼️ 1911 Scout handbook, p. 78](lib:boy-scouts-handbook-for-boys#page=78); [Bowline](wiki:Bowline)
- Sheet bend — [🖼️ FM 5-125, p. 48](lib:fm-5-125#page=48); [🖼️ AFH 10-644, p. 264](lib:afh-10-644#page=264); [🖼️ *Rope on the Farm*, p. 13](lib:rope-on-the-farm#page=13); [Sheet bend](wiki:Sheet_bend)
- Clove hitch — [🖼️ FM 5-125, p. 62](lib:fm-5-125#page=62); [🖼️ TC 3-97.61, p. 200](lib:tc-3-97-61#page=200); [🖼️ FM 3-05.70, p. 644](lib:fm-3-05-70#page=644); [Clove hitch](wiki:Clove_hitch)
- Half hitches, round turn — [🖼️ FM 5-125, p. 60](lib:fm-5-125#page=60); [🖼️ AFH 10-644, p. 269](lib:afh-10-644#page=269); [Round turn and two half-hitches](wiki:Round_turn_and_two_half-hitches)
- Rolling hitch (taut-line) — [🖼️ FM 5-125, p. 63](lib:fm-5-125#page=63); [🖼️ Kephart's magnus hitch, p. 280](lib:kephart-camping-and-woodcraft-vol-2#page=280); [Taut-line hitch](wiki:Taut-line_hitch)
- Trucker's hitch: the sheepshank loop; the baker bowline, its cousin for cargo — [🖼️ FM 5-125, p. 66](lib:fm-5-125#page=66); [🖼️ p. 57](lib:fm-5-125#page=57); [Trucker's hitch](wiki:Trucker%27s_hitch)
- Timber hitch — [🖼️ FM 5-125, p. 61](lib:fm-5-125#page=61); [🖼️ AFH 10-644, p. 268](lib:afh-10-644#page=268); [🖼️ *Rope on the Farm*, p. 14](lib:rope-on-the-farm#page=14); [Timber hitch](wiki:Timber_hitch)
- Figure eight and its loop — [🖼️ FM 5-125, p. 45](lib:fm-5-125#page=45); [🖼️ TC 3-97.61, p. 180](lib:tc-3-97-61#page=180); [🖼️ FM 3-05.70, p. 647](lib:fm-3-05-70#page=647); [Figure-eight knot](wiki:Figure-eight_knot)
- Prusik — [🖼️ TC 3-97.61, p. 195](lib:tc-3-97-61#page=195); [🖼️ FM 3-05.70, p. 646](lib:fm-3-05-70#page=646); [🖼️ AFH 10-644, p. 457](lib:afh-10-644#page=457); [Prusik](wiki:Prusik)
- Square, shear and tripod lashings — [🖼️ FM 5-125, p. 68](lib:fm-5-125#page=68); [🖼️ AFH 10-644, p. 271](lib:afh-10-644#page=271); [🖼️ p. 272](lib:afh-10-644#page=272); [🖼️ FM 3-05.70, p. 648](lib:fm-3-05-70#page=648); [🖼️ p. 649](lib:fm-3-05-70#page=649)
- Whipping; short, long, eye and crown splices — [🖼️ AFH 10-644, p. 261](lib:afh-10-644#page=261); [🖼️ *Rope on the Farm*, p. 7](lib:rope-on-the-farm#page=7); [🖼️ p. 8](lib:rope-on-the-farm#page=8); [🖼️ p. 11](lib:rope-on-the-farm#page=11); [🖼️ p. 12](lib:rope-on-the-farm#page=12); [🖼️ FM 5-125, p. 71](lib:fm-5-125#page=71); [Eye splice](wiki:Eye_splice)
- Block and tackle — [🖼️ FM 5-125, p. 107](lib:fm-5-125#page=107); [🖼️ p. 112](lib:fm-5-125#page=112); [🖼️ TC 3-97.61, p. 325](lib:tc-3-97-61#page=325); [🖼️ *Rope on the Farm*, p. 15](lib:rope-on-the-farm#page=15); [Block and tackle](wiki:Block_and_tackle)
- Sling angles; stake anchors — [🖼️ FM 5-125, p. 105](lib:fm-5-125#page=105); [🖼️ p. 125](lib:fm-5-125#page=125); [🖼️ p. 127](lib:fm-5-125#page=127)
- Coiling rope — [🖼️ FM 5-125, p. 22](lib:fm-5-125#page=22); [🖼️ TC 3-97.61, p. 211](lib:tc-3-97-61#page=211); [Rope](wiki:Rope)
- Tying a horse; a rope halter — [🖼️ 4-H PNW 587, p. 51](lib:the-4-h-horse-project#page=51); [🖼️ p. 52](lib:the-4-h-horse-project#page=52); [🖼️ *Rope on the Farm*, p. 16](lib:rope-on-the-farm#page=16); [Halter hitch](wiki:Halter_hitch)
- Twisting cord; dogbane — [🖼️ AFH 10-644, p. 275](lib:afh-10-644#page=275); [🖼️ NRCS dogbane guide, p. 1](lib:indian-hemp-dogbane#page=1); [Apocynum cannabinum](wiki:Apocynum_cannabinum); [Rawhide](wiki:Rawhide)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — the local picture and where everything is on the drive
- [Horses](guide:HORSE-GUIDE) — tying up, "Travel and packing" (pack saddles, the diamond hitch), harness
- [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE) — loading and lashing trailers, handcarts and packboards
- [Clothing & Leather](guide:CLOTHING-LEATHER-GUIDE) — "Linen, nettle and native fibers", "Tanning hides" (rawhide)
- [Firewood](guide:FIREWOOD-GUIDE) — felling and moving logs
- [Shelter & Building](guide:SHELTER-BUILDING-GUIDE) — poles, frames and raising heavy pieces
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — snares, nets and fishing knots
- [Water Wells](guide:WATER-WELLS-GUIDE) — rope pumps and windlasses
- [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — mending and making what you need
