# 💧 Water Wells, Pumps, Springs & Cisterns

How to keep water coming when the power is out for good: understanding your well, running the well
pump from a generator or solar, getting water up by hand, moving creek water uphill with no fuel
(ram pumps), developing a spring, catching rain in a cistern, and keeping it all clean. The manuals are
in `Water-Wells-Pumps\` (`Wells`, `Pumps-No-Grid`, `Hand-Ram-Rope-Pumps`, `Springs-Cisterns`,
`Water-Quality`, `Oregon`) and `Water\`. **Making water safe to drink** is in the
[Water Purification guide](guide:WATER-PURIFICATION-GUIDE).

> ### ⚠️ Rules that prevent the worst problems
> - **Never pour outside water into a well** and never leave a well open — one bucket of creek
>   water or a drowned animal can contaminate it ([OWRD *Wells and Drought*](lib:water-wells-and-drought)).
> - **Well pumps run on 240 volts.** Shut off the breaker before touching the pressure switch or
>   wiring, and connect a generator **only through a [transfer switch](wiki:Transfer_switch)** — never backfeed.
> - **Don't run a flooded pump** until it's dry and checked ([EPA](lib:what-to-do-after-the-flood-private-wells)).
> - **Test the water** — clear, cold water can still carry bacteria or arsenic.

---

## 🕳️ Know your well

**Three kinds of wells** ([USGS *Ground Water and the Rural Homeowner*, pp. 16–17](lib:ground-water-and-the-rural-homeowner#page=16); [🖼️ all three drawn side by side, p. 15](lib:ground-water-and-the-rural-homeowner#page=15)):
- **Dug wells:** wide and shallow, often lined with rock or concrete rings. Easy to contaminate and the first
  to go dry in drought — but you can **lower a bucket into them** ([🖼️ a lined dug well](lib:farmstead-water-supply#page=20)).
- **Driven wells (sand points):** a pipe with a screened tip driven into shallow sand or gravel. Cheap,
  shallow, easily contaminated ([🖼️ a well point](lib:wells-construction-hand-dug#page=185); [🖼️ driving one by hand](lib:farmstead-water-supply#page=22)).
- **Drilled wells:** a steel or plastic casing (usually 6 in) sealed into the ground, often hundreds of feet
  deep, with an electric **[submersible pump](wiki:Submersible_pump)** at the bottom ([🖼️ OWRD drawing of a drilled well's parts](lib:water-well-owners-handbook#page=7); [borehole](wiki:Borehole)). Most valley homes have this kind. About **5 gallons
  a minute** is a normal household supply.

![Three ways a well is made: a wide dug well dug by hand, a driven well with a pointed pipe pounded into the ground, and a deep drilled well bored by a truck rig](img:WATER-WELLS-GUIDE/dug-driven-drilled-wells.png)
*Dug wells are wide and shallow, driven wells narrow and shallow, drilled wells narrow and deep ([USGS, p. 15](lib:ground-water-and-the-rural-homeowner#page=15)).*

**Find your well's records.** Oregon has driller's reports for most wells drilled since 1955 — Josephine County
well IDs start with **"JOSE"**. The report gives the **depth, where water was found, the static water level and
the tested yield** — all things you need to plan a hand pump or generator ([OWRD *Water Well Owner's Handbook*,
pp. 27, 30](lib:water-well-owners-handbook#page=27); [🖼️ a filled-in sample report, p. 28](lib:water-well-owners-handbook#page=28)). **Print it and keep it with this drive.** Look it up on
OWRD's Well Log Query (by owner, location or well ID) while the internet works *(rule of thumb)*.

**What the ground here gives** (Grants Pass area, the nearest USGS study; [🖼️ how aquifers hold water](lib:ground-water-and-the-rural-homeowner#page=11); [aquifer](wiki:Aquifer)): river gravels 5–50 gpm but easily
polluted when shallow; weathered granite up to 50 gpm, solid granite under 5; **[serpentine](wiki:Serpentinite) rock — common around the
Illinois Valley — gives few if any good wells, and high-magnesium water**
([USGS HA-480 Plate 1](lib:grants-pass-area-plate-1); [Plate 2](lib:grants-pass-area-plate-2)). In summer a household
uses several times its winter water.

**Measure your water level** ([water table](wiki:Water_table); [🖼️ how pumping draws it down](lib:water-well-owners-handbook#page=8); [cone of depression](wiki:Cone_of_depression)) twice a year (spring and fall), from the same point on the casing, after the pump has
rested several hours, and keep a log. A **¾-in slotted PVC measuring tube** taped to the pump pipe lets a tape get
past the wires ([OWRD Handbook, pp. 15–16](lib:water-well-owners-handbook#page=15); [🖼️ measuring-tube diagram](lib:water-well-owners-handbook#page=15)). A chalked weighted tape shows
the wet line *(rule of thumb)*.

**Rules worth knowing:** household use up to **15,000 gallons a day**, livestock water and up to ½ acre of garden
need no water right ([OWRD *Exempt Uses*](lib:exempt-water-uses-in-oregon)). Wells must be at least 50 ft from
[septic tanks](wiki:Septic_tank) and 100 ft from drain fields, with the top at least 12 in above ground
([OWRD Handbook, pp. 23–24](lib:water-well-owners-handbook#page=23); [🖼️ setback diagram, p. 24](lib:water-well-owners-handbook#page=24)).

📚 **Go deeper:** [OWRD *Water Well Owner's Handbook*](lib:water-well-owners-handbook) — Oregon's complete owner guide; [USGS *Ground Water and the Rural Homeowner*](lib:ground-water-and-the-rural-homeowner); [Wikipedia: water well](wiki:Well).

## 🔌 Running the well pump without the grid

**From a generator** ([Franklin Electric *AIM Manual*, pp. 8–9](lib:aim-manual-submersible#page=8); [generator photos](wiki:Engine–generator)) — a well pump
needs **far more power to start than to run**:

| Pump size | Minimum generator — 2-wire pump | 3-wire pump (has a control box) |
|---|---|---|
| ½ hp | 3 kW | 2 kW |
| ¾ hp | 4.5 kW | 3 kW |
| 1 hp | 6 kW | 4 kW |
| 1½ hp | 7.5 kW | 5 kW |

- Example: a ½ hp pump runs on about 670 watts but draws **over 6 times that** for a moment when it starts
  ([AIM, p. 41](lib:aim-manual-submersible#page=41)). The pump's size is on the control box or the well report.
- **Start the generator first, then the pump; switch the pump off before stopping the generator.** Never let the
  generator run out of fuel with the pump on ([AIM, p. 8](lib:aim-manual-submersible#page=8)).
- **Pump into storage** — run the generator an hour or two and fill tanks, instead of running it all day.

**From solar:** a **DC solar well pump** with its own panels pumps whenever the sun shines ([🖼️ NRCS system drawing, p. 9](lib:solar-powered-water-pump#page=9); [🖼️ set up on a well, p. 35](lib:solar-powered-water-pump#page=35); [photos](wiki:Solar-powered_pump)). **Store water, not
electricity** — a tank holding about 3 days' water beats batteries for cost and upkeep
([NRCS *Solar-Powered Water Pump Systems*, pp. 27, 29](lib:solar-powered-water-pump#page=27)). Choose a
**brushless** pump; brushed ones need new brushes about every 2 years
([Practical Action, p. 4](lib:solar-photovoltaic-water-pumping#page=4)).

**Pressure tank and switch** ([UNL G2152, pp. 2–3](lib:pumps-and-pressure-tanks#page=2); [🖼️ well-to-house layout, p. 1](lib:pumps-and-pressure-tanks#page=1); [🖼️ inside a bladder tank, p. 3](lib:pumps-and-pressure-tanks#page=3); [pressure switch](wiki:Pressure_switch)): the switch starts the pump
at a low pressure (often 30 or 40 psi) and stops it at a high one (50 or 60). A bladder tank's air charge should be
**2 psi below the start pressure**, checked with the tank empty and power off.

| Problem | Usual cause ([AIM, p. 28](lib:aim-manual-submersible#page=28)) |
|---|---|
| Pump starts and stops every few seconds | **Waterlogged tank** (low air charge), leak, stuck [check valve](wiki:Check_valve) |
| Pump runs and won't stop | Water level below the pump, worn pump, clogged screen, broken pipe |
| No water, pump silent | Breaker, pressure switch contacts, control box, wiring |
| Sputtering, air in the water | Water level dropping to the pump — rest the well, use less |

📚 **Go deeper:** [Franklin Electric *AIM Manual*](lib:aim-manual-submersible) — the pump-maker's troubleshooting bible; [UNL *Pumps and Pressure Tanks*](lib:pumps-and-pressure-tanks); [NRCS solar pump design](lib:solar-powered-water-pump); [Engines guide — generators](guide:ENGINES-AND-MOTORS-GUIDE).

## ✋ Getting water up by hand

**The suction limit:** a pump at the top of a well doesn't "lift" water — air pressure pushes it up. In practice
**a pitcher pump or any suction pump stops working at about 20–22 ft** of lift, a little less at our elevation
([USDA FB 1448, p. 27](lib:farmstead-water-supply#page=27); [Peace Corps *Wells Construction*, p. 262](lib:wells-construction-hand-dug#page=262); [🖼️ how a piston pump works](lib:wells-construction-hand-dug#page=260)).
**Deeper than that, the pumping part must be down in the water** — there's no limit on *pushing* water up from below.

![Two wells side by side: a pump on top reaches water 15 ft down; for water 35 ft down, the pump's cylinder sits down in the water, worked by rods from above](img:WATER-WELLS-GUIDE/suction-limit.svg)
*A pump on top can lift water only about 20–22 ft; below that, put the pumping part in the water (a diagram drawn for this guide).*

| Water level | Options |
|---|---|
| **Under ~20 ft** | [Pitcher pump](wiki:Hand_pump) ([🖼️ drawing](lib:farmstead-water-supply#page=31)); rope pump; bucket and [windlass](wiki:Windlass) on a dug well ([🖼️ drawing](lib:farmstead-water-supply#page=18)) |
| **20–150 ft** | **Rope pump** (to about 115 ft); deep-well lift handpumps (Afridev, India Mark II up to about 160 ft) |
| **Deeper** | Generator or solar on the existing submersible; well bucket (below) |

- **Rope pump:** an endless rope with small pistons every meter runs up a pipe over a hand wheel. About **35 liters a
  minute at 33 ft, 10 at 115 ft**; fits a 3-in borehole; can be built from local materials
  ([Practica *Rope Pump Handbook*, pp. 8–9](lib:rope-pump-technical#page=8); [🖼️ assembly drawing, p. 48](lib:rope-pump-technical#page=48); [🖼️ older bucket and chain pumps](lib:wells-construction-hand-dug#page=269)).
- **Deep-well handpumps:** a cylinder set below the water on rods. Set the cylinder below the lowest water level you've
  measured while pumping ([Afridev manual, p. 26](lib:afridev#page=26); [India Mark II manual](lib:india-mark-ii); [🖼️ a deep-well pump on a borehole](lib:who-wedc-technical-notes#page=8); [🖼️ suction, force and deep-well pump parts](lib:farmstead-water-supply#page=29)).
  Commercial deep-well hand pumps can be fitted beside the electric pump in a 6-in casing *(rule of thumb)*.
- **Well bucket (bailer):** a narrow tube about 3 in wide with a flap valve in the bottom fits **down a 4–6 in casing
  beside the pump pipe** and brings up 1–2 gallons a trip on a rope and pulley. You must open the well cap and keep
  everything clean — sanitize the bucket and rope, and close the well between uses *(rule of thumb; no manual found)*.

📚 **Go deeper:** [Practical Action *Human-Powered Handpumps*, p. 5](lib:human-powered-handpumps#page=5) — which pump for which depth; [Practica *Rope Pump Handbook*](lib:rope-pump-technical) — building one; [Peace Corps *Wells Construction*](lib:wells-construction-hand-dug) — digging and lining a well by hand; [Wikipedia: rope pump](wiki:Chain_pump).

## 🔁 Ram pumps: creek water uphill with no fuel

A **hydraulic ram** uses the force of falling water in a long pipe ([water hammer](wiki:Hydraulic_shock)) to push **part** of that water much higher — day
and night, with no fuel ([Practical Action *Hydraulic Ram Pumps*](lib:hydraulic-ram-pumps-practical); [🖼️ how it works, p. 2](lib:hydraulic-ram-pumps-practical#page=2); [🖼️ step-by-step drawings](lib:clemson-extension-homemade#page=2)).

- **Rule of thumb:** water delivered ≈ water going in × **fall ÷ lift** × about 0.5, with both measured from the ram.
  Example: 10 gallons a minute falling 20 ft into the ram can push about **0.8 gpm — roughly 1,200 gallons a day — to a
  tank 100 ft above the source** (120 ft above the ram)
  ([Peace Corps *Hydrams*, p. 66](lib:hydrams-design-construction#page=66)). Another: 3 gpm with a 12-ft fall lifts
  about 780 gallons a day to 48 ft ([USDA FB 1448, pp. 24–25](lib:farmstead-water-supply#page=24)).
- **The drive pipe** from the source to the ram must be **straight, rigid (steel is best) and long** — about 3–7 times
  the fall, and at least 100 times its own width ([Practical Action, p. 3](lib:hydraulic-ram-pumps-practical#page=3); [🖼️ layout of a ram installation](lib:farmstead-water-supply#page=24)).
- **You need:** a reliable flow and a few feet of fall — a creek with a small dam or a spring above the ram. The
  water that doesn't get pumped flows back out the waste valve.
- **Tune** the waste valve's stroke for the best output; build one from pipe fittings with the Peace Corps manual ([🖼️ a homemade ram from plumbing parts](lib:clemson-extension-homemade#page=9)).
- Oregon water law and fish screens apply to diverting creek water — see the [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE)
  creek-power section.

![A ram installation from the side: a spring or dammed creek, a long straight drive pipe down to the ram, the waste valve spilling water, and a delivery pipe up the hill to a tank](img:WATER-WELLS-GUIDE/ram-pump-layout.svg)
*Measure the fall and the lift from the ram; it sends only part of the water up (a diagram drawn for this guide).*

📚 **Go deeper:** [Peace Corps *Hydrams* workshop manual](lib:hydrams-design-construction) — build and repair one; [USDA FB 1448 — rams and windmills](lib:farmstead-water-supply#page=24); [Wikipedia: hydraulic ram](wiki:Hydraulic_ram).

## 🌬️ Windmills

Wind power rises with the **cube** of wind speed (twice the wind = 8 times the power); a water-pumping windmill ([🖼️ photo](lib:wind-pumping#page=5); [photos](wiki:Windpump)) pays
off where the average wind is above about **7 mph**, and needs a storage tank for calm days
([Practical Action *Wind Pumping*, p. 2](lib:wind-pumping#page=2)). Sheltered valley floors here may be too calm —
ridges and open ground are better *(rule of thumb)*.

📚 **Go deeper:** [Practical Action *Wind Pumping*](lib:wind-pumping); [USDA FB 1448 — windmills](lib:farmstead-water-supply); [Wikipedia: windpump](wiki:Windpump).

## ⛲ Springs

A **spring box** collects spring water before animals and surface runoff can foul it
([Virginia Tech *Spring Development*, p. 5](lib:spring-development-and-protection#page=5); [🖼️ spring box drawings, p. 5](lib:spring-development-and-protection#page=5); [springs](wiki:Spring_(hydrology))):
- Dig back to where the water comes out of the ground and lay a **gravel-packed collection pipe or trench** ([🖼️ cross-section, p. 3](lib:spring-development-and-protection#page=3); [🖼️ a seep spring, p. 4](lib:spring-development-and-protection#page=4)).
- A concrete box **at least 4 ft deep, sticking up 1 ft above ground**, with a **tight overlapping lid**, an outlet
  pipe, a **screened overflow** (so animals and insects can't crawl in) and a drain for cleaning.
- **Dig a ditch upslope** to steer surface runoff away, and **fence livestock out** of the area above the spring;
  keep outhouses and corrals at least 100 ft away ([🖼️ a protected spring, 1933](lib:farmstead-water-supply#page=10)).
- **Measure flow** with a bucket and a watch; test the water and shock-chlorinate a new box
  ([Virginia Tech *Shock Chlorination*](lib:shock-chlorination-disinfecting)).
- Spring water runs by **gravity** to the house or garden — no pump at all if the spring is uphill.

![Plan and side view of a protected spring: a perforated pipe in water-bearing gravel feeds a concrete box with a locked, overlapping lid, a screened overflow, a pipe to storage and a cleanout drain, with a diversion ditch and fence uphill](img:WATER-WELLS-GUIDE/spring-box.png)
*The ditch and fence uphill keep runoff and animals off the spring; the lid overlaps the box and locks ([EPA *Manual of Individual Water Supply Systems*, p. 70](lib:manual-of-individual-and-non-public-water-supply#page=78)).*

📚 **Go deeper:** [Virginia Tech *Spring Development and Protection*](lib:spring-development-and-protection); [EPA *Manual of Individual Water Supply Systems*](lib:manual-of-individual-and-non-public-water-supply) — springs, wells and cisterns.

## 🛢️ Cisterns and rainwater

Our winters are wet: **every square foot of roof catches about 0.6 gallons per inch of rain**
([Texas *Rainwater Harvesting*, p. 34](lib:texas-manual-on-rainwater#page=34); [🖼️ a whole system, p. 10](lib:texas-manual-on-rainwater#page=10); [rainwater harvesting](wiki:Rainwater_harvesting)). A 1,500 sq ft roof in a 10-inch rain
month could fill a 9,000-gallon tank *(rule of thumb arithmetic)*.

- **First-flush diverter:** dump the first dirty water off the roof — about 13–49 gallons per 1,000 sq ft
  ([Texas, p. 13](lib:texas-manual-on-rainwater#page=13); [🖼️ standpipe diverter, p. 14](lib:texas-manual-on-rainwater#page=14); [🖼️ its parts, OSU](lib:harvesting-rainwater-for-use-in-the-garden#page=5)). A standpipe of 4-in pipe holds about 1 gallon per 18 in.
- **Size the tank for summer:** almost no rain falls June–September, so store enough to carry you through
  ([🖼️ ferrocement tank](lib:texas-manual-on-rainwater#page=19); [🖼️ 1933 cistern and filter plans](lib:farmstead-water-supply#page=14); [cistern](wiki:Cistern); [rain tanks](wiki:Rainwater_tank)).
- **Opaque, covered, screened** tanks; clean [gutters](wiki:Rain_gutter); treat roof water before drinking
  ([Water Purification guide](guide:WATER-PURIFICATION-GUIDE)). Oregon rules for rain tanks:
  [OSU EM 9448](lib:rainwater-harvesting-in-tanks-or-cisterns) ([🖼️ system diagram, p. 4](lib:rainwater-harvesting-in-tanks-or-cisterns#page=4)).

![A standpipe first-flush diverter: the downspout feeds a tee; the first dirty roof water fills a capped pipe below it, then cleaner water flows on to a covered tank](img:WATER-WELLS-GUIDE/first-flush-diverter.svg)
*The capped pipe catches the dirtiest first water; empty it after each rain (a diagram drawn for this guide).*

📚 **Go deeper:** [Texas *Manual on Rainwater Harvesting*](lib:texas-manual-on-rainwater); [OSU *Harvesting Rainwater for the Garden*](lib:harvesting-rainwater-for-use-in-the-garden).

## 🧪 Keeping well water clean

- **Test yearly** for [coliform bacteria](wiki:Coliform_bacteria) and nitrate, and **at least once for [arsenic](wiki:Arsenic_contamination_of_groundwater)** (treat at 10 ppb or more)
  ([OWRD Handbook, p. 34](lib:water-well-owners-handbook#page=34)). Without a lab, a home H₂S bacteria test helps —
  see the [Water Purification guide](guide:WATER-PURIFICATION-GUIDE).
- **Shock chlorination** after repairs, floods or a bad test: for 5.25% bleach, about **2½ quarts for a 4-in well with
  100 ft of water, 4 quarts for a 6-in well with 100 ft, 1½ gallons for 6-in with 200 ft**. Run every tap until you smell
  chlorine, leave it 12–24 hours, flush it away from the septic system, and retest in 1–2 weeks. Today's bleach is
  often stronger (6–8.25%): the same amounts just make it stronger. Oregon's OHA bulletin uses 1 cup of 8.25% bleach
  per 100 gallons of water standing in the well, left at least 8 hours
  ([Virginia Tech *Shock Chlorination*, p. 3](lib:shock-chlorination-disinfecting#page=3);
  [OHA bulletin](lib:well-disinfection-technical-bulletin); [🖼️ pouring and circulating the chlorine](lib:shock-chlorination-disinfecting#page=3)).
- **After a flood:** wells under 50 ft deep or over 10 years old are probably contaminated
  ([EPA, p. 1](lib:what-to-do-after-the-flood-private-wells#page=1); [🖼️ cleaning out a flooded dug well](lib:who-wedc-technical-notes#page=59)).
- **After a wildfire:** check the wellhead, wiring and pipes, and test before drinking
  ([OWRD after wildfire](lib:maintaining-your-well-after-wildfire)).
- **"Dry" well?** Often the water only dropped below the pump — lower the pump (not to the very bottom) and fit a
  pump-saver switch ([OWRD *Wells and Drought*](lib:water-wells-and-drought); [🖼️ how a well "goes dry"](lib:ground-water-and-the-rural-homeowner#page=19)).
- **Protect the wellhead:** tight sanitary cap, ground sloping away, no fuel, manure or chemicals nearby
  ([OSU *Twelve Simple Things*](lib:twelve-simple-things); [🖼️ two wellhead types, p. 4](lib:twelve-simple-things#page=4); [🖼️ how wells and springs get polluted](lib:farmstead-water-supply#page=7); [🖼️ sealing the top of a dug well](lib:who-wedc-technical-notes#page=4)).

📚 **Go deeper:** [OWRD Handbook — testing schedule, p. 34](lib:water-well-owners-handbook#page=34); [Virginia Tech *Shock Chlorination*](lib:shock-chlorination-disinfecting); [OSU *Twelve Simple Things to Protect Your Well Water*](lib:twelve-simple-things).

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Kinds of wells and their parts**
- Dug, driven and drilled wells side by side — [🖼️ USGS, p. 15](lib:ground-water-and-the-rural-homeowner#page=15); [Well](wiki:Well)
- Aquifers and the water table — [🖼️ USGS, p. 11](lib:ground-water-and-the-rural-homeowner#page=11); [Aquifer](wiki:Aquifer); [Water table](wiki:Water_table)
- A dug well lined with concrete pipe — [🖼️ USDA FB 1448, p. 20](lib:farmstead-water-supply#page=20)
- Head wall and apron on top of a dug well — [🖼️ Peace Corps, p. 45](lib:wells-construction-hand-dug#page=45)
- Driven well point, and driving it by hand — [🖼️ Peace Corps, p. 185](lib:wells-construction-hand-dug#page=185); [🖼️ USDA FB 1448, p. 22](lib:farmstead-water-supply#page=22)
- A drilled well, every part labeled — [🖼️ OWRD, p. 7](lib:water-well-owners-handbook#page=7); [Borehole](wiki:Borehole)
- Water-level measuring tube — [🖼️ OWRD, p. 15](lib:water-well-owners-handbook#page=15)
- Pumping draws the water down around the well — [🖼️ OWRD, p. 8](lib:water-well-owners-handbook#page=8); [🖼️ USGS, p. 17](lib:ground-water-and-the-rural-homeowner#page=17); [Cone of depression](wiki:Cone_of_depression)
- Setbacks from septic, manure and fuel — [🖼️ OWRD, p. 24](lib:water-well-owners-handbook#page=24); [Septic tank](wiki:Septic_tank)
- What a well report looks like — [🖼️ OWRD sample, p. 28](lib:water-well-owners-handbook#page=28)

**Power, pumps and pressure**
- Well, pitless adapter, pressure tank and house — [🖼️ UNL, p. 1](lib:pumps-and-pressure-tanks#page=1); [Submersible pump](wiki:Submersible_pump)
- Inside a bladder pressure tank — [🖼️ UNL, p. 3](lib:pumps-and-pressure-tanks#page=3); [Pressure switch](wiki:Pressure_switch)
- Solar pump on a well with a storage tank — [🖼️ NRCS, p. 9](lib:solar-powered-water-pump#page=9); [🖼️ NRCS, p. 35](lib:solar-powered-water-pump#page=35); [Solar-powered pump](wiki:Solar-powered_pump)
- Generator and transfer switch — [Engine-generator](wiki:Engine–generator); [Transfer switch](wiki:Transfer_switch)

**Getting water up by hand**
- How a piston (pitcher) pump works — [🖼️ Peace Corps, p. 260](lib:wells-construction-hand-dug#page=260); [🖼️ USDA FB 1448, p. 31](lib:farmstead-water-supply#page=31); [Hand pump](wiki:Hand_pump)
- Suction, force and deep-well pumps compared — [🖼️ USDA FB 1448, p. 29](lib:farmstead-water-supply#page=29); [🖼️ WHO/WEDC, p. 8](lib:who-wedc-technical-notes#page=8)
- Rope pump, long-leg and dug-well models — [🖼️ Practica, p. 48](lib:rope-pump-technical#page=48); [🖼️ Practica, p. 49](lib:rope-pump-technical#page=49); [Chain pump](wiki:Chain_pump)
- Afridev deep-well hand pump — [🖼️ Afridev manual, p. 5](lib:afridev#page=5)
- Bucket and windlass — [🖼️ USDA FB 1448, p. 18](lib:farmstead-water-supply#page=18); [Windlass](wiki:Windlass)

**Ram pumps and windmills**
- How a ram pump works, step by step — [🖼️ Practical Action, p. 2](lib:hydraulic-ram-pumps-practical#page=2); [🖼️ Clemson, pp. 2–4](lib:clemson-extension-homemade#page=2); [Hydraulic ram](wiki:Hydraulic_ram)
- Ram installation: drive pipe, ram, delivery pipe — [🖼️ USDA FB 1448, p. 24](lib:farmstead-water-supply#page=24)
- A homemade ram from plumbing fittings — [🖼️ Clemson, p. 9](lib:clemson-extension-homemade#page=9); [Water hammer](wiki:Hydraulic_shock)
- Water-pumping windmills — [🖼️ Practical Action, p. 5](lib:wind-pumping#page=5); [🖼️ rotor types, p. 4](lib:wind-pumping#page=4); [Windpump](wiki:Windpump)

**Springs and rain catchment**
- Spring box — [🖼️ Virginia Tech, p. 5](lib:spring-development-and-protection#page=5); [🖼️ curbed spring, USDA FB 1448, p. 10](lib:farmstead-water-supply#page=10); [Spring](wiki:Spring_(hydrology))
- Developing a concentrated spring and a seep — [🖼️ Virginia Tech, p. 3](lib:spring-development-and-protection#page=3); [🖼️ Virginia Tech, p. 4](lib:spring-development-and-protection#page=4)
- A whole rain-catchment system — [🖼️ Texas, p. 10](lib:texas-manual-on-rainwater#page=10); [🖼️ OSU EM 9448, p. 4](lib:rainwater-harvesting-in-tanks-or-cisterns#page=4); [Rainwater harvesting](wiki:Rainwater_harvesting)
- First-flush diverter — [🖼️ Texas, p. 14](lib:texas-manual-on-rainwater#page=14); [🖼️ OSU EM 9101, p. 5](lib:harvesting-rainwater-for-use-in-the-garden#page=5); [Rain gutter](wiki:Rain_gutter)
- Tanks and cisterns — [🖼️ ferrocement tank, Texas, p. 19](lib:texas-manual-on-rainwater#page=19); [🖼️ USDA FB 1448, p. 14](lib:farmstead-water-supply#page=14); [Cistern](wiki:Cistern); [Rainwater tank](wiki:Rainwater_tank); [Ferrocement](wiki:Ferrocement)

**Keeping it clean**
- How wells and springs get polluted — [🖼️ USDA FB 1448, p. 7](lib:farmstead-water-supply#page=7); [Coliform bacteria](wiki:Coliform_bacteria)
- Wellhead inspection points — [🖼️ OSU, p. 4](lib:twelve-simple-things#page=4); [🖼️ what to keep away, OSU, p. 2](lib:twelve-simple-things#page=2)
- Concrete pump platforms that shed spilled water — [🖼️ Afridev manual, pp. 13–15](lib:afridev#page=13)
- Shock-chlorinating a well — [🖼️ Virginia Tech, p. 3](lib:shock-chlorination-disinfecting#page=3)
- Sealing and cleaning a dug well — [🖼️ WHO/WEDC, p. 4](lib:who-wedc-technical-notes#page=4); [🖼️ WHO/WEDC, p. 59](lib:who-wedc-technical-notes#page=59)
- How a well "goes dry" — [🖼️ USGS, p. 19](lib:ground-water-and-the-rural-homeowner#page=19); [Arsenic in groundwater](wiki:Arsenic_contamination_of_groundwater)

---

## 🔗 Related guides

- [Water Purification](guide:WATER-PURIFICATION-GUIDE) — making any water safe to drink
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — generators, motors, creek power
- [Fuel Guide](guide:FUEL-GUIDE) — fuel for the generator
- [EMP, Solar Storms & Faraday Cages](guide:EMP-GUIDE) — protect a spare pump controller
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — water section and off-grid power
