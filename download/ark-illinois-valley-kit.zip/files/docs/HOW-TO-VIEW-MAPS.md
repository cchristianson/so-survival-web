# 🗺️ Offline Maps — How to View Them (PC or Phone)

The **OsmAnd** folder on the drive has detailed maps (roads, towns and place search) that work with
**no internet**. Which area you have was picked when
the drive was made: **the whole USA**, **Oregon and California**, or **Oregon only**. To change it, run the installer again.

There are two kinds of map on the drive:

- **The map in the web browser** (below): nothing to install. Roads, trails, topo lines and, where the
  area's library has them, property lines. It covers the Illinois Valley.
- **OsmAnd**, an app for phones: bigger areas, and it gives directions.

---

## 🗺️ Easiest: the map in the web browser

In the library, open **🔧 Tools → 🗺️ Map**. It works on a phone, tablet or computer, and on any phone
using the library over Wi-Fi (the ARK Vault's too). No app, no signal.

- **What it shows:** roads, forest roads and trails, creeks, peaks and towns, with **topo lines**
  (heights in feet) and shaded hills.
- **Property lines and public land:** thin orange lines are tax lots. Colors show who manages the
  land (BLM, National Forest, state, county); private land has no color. Turn them on and off under
  **Layers**.
- **Tap anywhere** for the height, the position (latitude and longitude), the tax lot and its acres.
- **Find a place:** type part of a name (a creek, a peak, a road) in the box at the top.
- **📍 Where am I:** shows your position as a blue dot. This works when the map is open from the
  **library website** (saved on the phone), or on the device the library itself runs on. A phone
  using someone else's library over Wi-Fi can't show it: phones only share their position with a
  secure page.

**To carry the map on a phone:** while you have internet, open the library website, go to
**⚙️ Offline** and tap **Also save the map** (about 50 MB). Then it works anywhere, with the dot.

> ⚠️ Property lines come from the county assessor's tax-lot map. They can be off by many feet and are
> **not a survey**. Don't use them to settle where a boundary is.

---

## 🤖 Android phone or tablet

1. Install **OsmAnd** from the drive's **Phone-Apps** folder (see
   [Use the library on a phone](guide:USE-ON-PHONE)).
2. Copy your area's map files (in the **OsmAnd** folder, ending in `.obf.zip`) to the phone. For
   Oregon, that's the files starting with `Us_oregon`.
3. Open **OsmAnd** → **Menu** → **Download maps → Import** and pick the files.

## 🍏 iPhone or iPad

1. **While you have internet,** install **OsmAnd Maps** (free) from the App Store.
2. Copy the map files onto the iPhone and open them in OsmAnd (see
   [Use the library on a phone](guide:USE-ON-PHONE)).

---

## 🪟 Windows computer

Nothing to install.

1. On the drive, open **OfflineLibrary → OsmAnd → MapViewer-Desktop**.
2. Double-click **`VIEW-MAPS-ON-PC`**.
3. **The first time only,** it unpacks the maps, which takes several minutes. Leave the black
   window open.
4. The map viewer opens. Use its menus to open a map, then zoom and search.

The first time uses a lot of free space (about **30 GB** for the whole USA, much less for
Oregon). The installer left that space empty on purpose.

## 🍎 Mac or 🐧 Linux computer

1. Open **Terminal** (Mac: press **Command + Space**, type `Terminal`, press **Return**).
2. Type `bash ` (with a space), drag **`VIEW-MAPS-ON-PC.sh`** (in **OsmAnd → MapViewer-Desktop**)
   into the window, and press **Return**.

This file is only on drives that were made on a Mac or Linux computer.

---

## 🧰 For helpers: maps of other places

The point-and-click installer offers only the USA, Oregon and California, or Oregon. For anywhere
else, run the installer script from the kit's `files` folder with a region:

```
# Windows (PowerShell)
./Get-OfflineLibrary.ps1 -Destination "E:\" -Region France
# Mac / Linux
./get-offline-library.sh -d /Volumes/MYDRIVE --region France
```

A region can be a country, a continent (`Europe`), part of a country (`US_texas`) or `world`. Add
`-ListRegions` (Windows) or `--list-regions` (Mac/Linux) to see the names.

Keep a **paper map** as a backup too. Electronics fail.
