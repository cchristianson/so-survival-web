# 🗺️ Offline Maps — How to View Them (PC or Phone)

The **OsmAnd** folder on the drive has detailed maps (roads, towns and place search) that work with
**no internet**. Which area you have was picked when
the drive was made: **the whole USA**, **Oregon and California**, or **Oregon only**. To change it, run the installer again.

**A phone is best:** the OsmAnd app finds places and gives directions. The computer viewer is
plainer, but fine for looking things up.

---

## 🤖 Android phone or tablet

1. Install **OsmAnd** from the drive's **Phone-Apps** folder (see
   [Use the library on a phone](guide:USE-ON-PHONE)).
2. Copy your area's map files (in the **OsmAnd** folder, ending in `.obf.zip`) to the phone. For
   Oregon, that's the files starting with `Us_oregon`.
3. Open **OsmAnd** → **Menu** → **Download maps → Import** and pick the files.

## 🍏 iPhone or iPad

1. **While you have internet,** install **OsmAnd Maps** (free) from the App Store.
2. Copy the map files onto the iPhone and open them in OsmAnd (see
   [Use the library on a phone](guide:USE-ON-PHONE)).

---

## 🪟 Windows computer

Nothing to install.

1. On the drive, open **OfflineLibrary → OsmAnd → MapViewer-Desktop**.
2. Double-click **`VIEW-MAPS-ON-PC`**.
3. **The first time only,** it unpacks the maps, which takes several minutes. Leave the black
   window open.
4. The map viewer opens. Use its menus to open a map, then zoom and search.

The first time uses a lot of free space (about **30 GB** for the whole USA, much less for
Oregon). The installer left that space empty on purpose.

## 🍎 Mac or 🐧 Linux computer

1. Open **Terminal** (Mac: press **Command + Space**, type `Terminal`, press **Return**).
2. Type `bash ` (with a space), drag **`VIEW-MAPS-ON-PC.sh`** (in **OsmAnd → MapViewer-Desktop**)
   into the window, and press **Return**.

This file is only on drives that were made on a Mac or Linux computer.

---

## 🧰 For helpers: maps of other places

The point-and-click installer offers only the USA, Oregon and California, or Oregon. For anywhere
else, run the installer script from the kit's `files` folder with a region:

```
# Windows (PowerShell)
./Get-OfflineLibrary.ps1 -Destination "E:\" -Region France
# Mac / Linux
./get-offline-library.sh -d /Volumes/MYDRIVE --region France
```

A region can be a country, a continent (`Europe`), part of a country (`US_texas`) or `world`. Add
`-ListRegions` (Windows) or `--list-regions` (Mac/Linux) to see the names.

Keep a **paper map** as a backup too. Electronics fail.
