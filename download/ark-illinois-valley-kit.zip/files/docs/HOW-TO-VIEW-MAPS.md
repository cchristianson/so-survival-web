# 🗺️ Offline Maps — How to View Them (PC or Phone)

The **OsmAnd** folder on the drive has detailed maps (roads, towns and place search) that work with
**no internet**. Which area you have was picked when
the drive was made: **the whole USA**, **Oregon and California**, or **Oregon only**. To change it, run the installer again.

There are two kinds of map on the drive:

- **The map in the web browser** (below): nothing to install. Roads, trails, topo lines and, where the
  area's library has them, property lines. It covers the Illinois Valley and the country around it, west to the coast and south to the Klamath River.
- **OsmAnd**, an app for phones: bigger areas, and it gives directions.

---

## 🗺️ Easiest: the map in the web browser

In the library, press **Maps**. It works on a phone, tablet or computer, and on any phone
using the library over Wi-Fi (the ARK Vault's too). No app, no signal.

- **The small row at the top:** **Routes** opens the walking routes to other towns, and the box
  beside it finds a place or a street address.
- **Walking routes to a town:** under **Routes**, type the town (or tap one of the nearest) for how
  far it is and how long it takes on foot, by bicycle and by car, and the roads it goes by. **Show on
  the map** draws that town's routes all the way there: back roads in purple, the highway way in
  orange, the bicycle route in blue dashes, each with its own switch. Typing a town in the map's own
  search box does the same (**Walking route to ...**).
- **Full:** the last button on the right gives the map the whole screen. **Exit** brings the
  buttons back.

- **What it shows:** roads, forest roads and trails, creeks, peaks and towns, with **topo lines**
  (heights in feet) and shaded hills.
- **Property lines and public land:** thin orange lines are tax lots. Colors show who manages the
  land (BLM, National Forest, state, county); private land has no color.
- **On a phone,** each panel that slides up has a small handle at its top: drag it up to make the
  panel taller, down to see more of the map, or right down to close it.
- **Layers:** switch on what you need, and tap anything on the map to see what it is. Under each
  layer that is on, the **Opacity** slider makes it fainter or more solid, so one layer can show
  through another; ↺ puts it back. Which layers there are depends on the area's library:

  | Group | Layers |
  |---|---|
  | **Water** | Creeks that run all year or only part of it, springs, wells and how deep they are, dams |
  | **Food and growing** | Good growing ground, sightings of wild food plants and mushrooms, salmon and trout streams, frost pockets (low ground where frost comes early and stays late) |
  | **Hunting** | Where deer and elk live and gather by season, sightings of game animals and birds, the state's hunting units |
  | **Materials** | Timber (which trees grow where), rock types and what each is good for, mines, quarries and mineral sites |
  | **Hazards** | Past wildfires, flood zones, old landslides |
  | **Places and getting around** | Medical, fuel, food and hardware, fire stations, bridges and their weight limits, camps, escape routes, walking routes, trails and trailheads, forest and BLM roads (the number on the sign, and whether you can drive it), gates and road blocks, radio towers and fire lookouts |
  | **Base map and land** | Satellite photo, steep ground, sunny (south-facing) slopes, the township and section grid |

- **Satellite photo:** **Layers → Satellite photo** shows the ground as it looks from the air
  (photos from the US Department of Agriculture), with the roads, names and property lines drawn
  over it. Switch off **Who manages the land** to see the photos plainly. From far out the photos
  are saved with the map and work anywhere. Close up they are sharp enough to see houses, tracks and
  single trees while there is a signal; with no signal they are blurry close up, unless the sharp
  ones are on the drive (below).
- **Trails:** **Layers → Trails** shows the Forest Service, BLM and park trails, colored by who may
  use them (on foot only, horses too, bicycles too, motorbikes too), with the trail's number as on the
  sign and 🥾 at trailheads. Tap one for how rough it is, its surface and its length. Smaller paths
  from the street map are always there as brown dots, layer or not.
- **Measure:** tap points along a way for the distance over the ground (the climbs and drops
  counted, not just the flat distance on the map), the ups and downs, and about how long it takes
  on foot, there and back. With two points it also says whether one can see the other, which is
  what a radio link needs.
- **Pins:** tap the map, then **Save as a pin**, to mark your own places. Pins are kept on that
  phone or computer only; **Save my pins to a file** carries them to another.
- **Shared pins:** on a library shared over Wi-Fi (an ARK Vault, say), tick **Share it with everyone
  using this library** when you save a pin. Every phone on that Wi-Fi then sees it, marked 📍. Anyone
  can add or remove one, so use them like a notice board: a meeting place, a spring, a blocked road.
- **Tap anywhere** for the height, the position (latitude and longitude), the tax lot, its acres and,
  where the county publishes it, the recorded owner.
- **Find a place or an address:** in the box at the top, type part of a name (a creek, a peak, a
  road), or a house number and street (**1800 White Schoolhouse Rd**), or a position
  (**42.1634, -123.6479**). Addresses are the county's own, so a new house may be missing.
- **📍 Where am I:** shows your position as a blue dot. From the **library website** (saved on the
  phone) it just works. On a phone using a library over Wi-Fi (the ARK Vault's too), tap 📍 and follow
  the steps: the phone warns once that the connection is "not private", because the library makes its
  own security certificate. Accept it, tap 📍 again, and allow location.
- **Print:** prints the part of the map on the screen, north up, with a scale bar. On the library's
  receipt printer it comes out in black and white, in one to four strips to tape side by side; on an
  ordinary printer, as one color page.
- **How far it reaches:** the map covers the Illinois Valley and the country around it, west to the coast and south to the Klamath River. Property lines, owners, house numbers and
  some layers come from one county or one state and stop at its edge. Beyond that the map still has
  roads, trails, topo lines, public land and the nationwide layers (creeks and springs, forest roads,
  timber, rock types, past wildfires, flood zones, wild food and game). Where the library's website
  keeps a bigger map online, the map there also reaches further while the phone has a signal (the
  bottom of the Layers panel says how far); with no signal it is the saved map, as before.
- **A detailed map of a far wider area (on a drive):** start the library on a computer with internet, open
  **More → Offline & downloads**, find **Detailed offline map** and press **Download it**. It adds roads and topo lines for a far
  wider area, in three levels: full detail at home, every street and trail in the country round it,
  and main roads, towns and topo lines beyond that. The Settings page says what it covers and how
  big it is (several GB, and some hours). If it stops part way, press **Download it** again and it
  carries on. Do this before the drive goes into an ARK Vault. It has no turn-by-turn directions:
  for those, use OsmAnd (below).
- **Sharp satellite photos with no internet (on a drive):** in the same place, find **Sharp
  satellite photos** and press **Download them** (about 3 GB for Illinois Valley, an hour or more).
  Then the Satellite photo switch is sharp close up with no signal, on the drive and on an ARK
  Vault. **Remove them** gives the room back.

**To carry the map on a phone:** while you have internet, open the library website, go to
**More → Offline & downloads** and tap **Save** beside **Illinois Valley map** (about 140 MB). Then it works anywhere, with the dot.

**If the map goes blank:** a phone sometimes takes the map's memory for something else, most often
while you are in another app. The map starts itself again where it was, in a second or two. If it
says **The map stopped drawing**, press **Start the map again**. Your layers and pins are kept.

> ⚠️ **A map is not a promise.** A wild-food sighting says someone saw the plant there once: check any
> plant or mushroom in the guides before eating it. Old mines are dangerous: stay out of shafts and
> tunnels. Wells are from old drilling reports and may be dry or gone. Road, gate and timber records
> are the agencies' own and can be years old: a road shown open may be washed out or gated. Frost
> pockets are worked out from the shape of the ground, as a guide.
>
> Property lines and owners come from the county assessor's tax-lot map. The lines can be off by
> many feet and are **not a survey**: don't use them to settle where a boundary is. Owners are as
> recorded when the map was made; land changes hands.

---

## 🤖 Android phone or tablet

1. Install **OsmAnd** from the drive's **Phone-Apps** folder (see
   [Use the library on a phone](guide:USE-ON-PHONE)).
2. Copy your area's map files (in the **OsmAnd** folder, ending in `.obf.zip`) to the phone. For
   Oregon, that's the files starting with `Us_oregon`.
3. Open **OsmAnd** → **Menu** → **Download maps → Import** and pick the files.

## 🍏 iPhone or iPad

1. **While you have internet,** install **OsmAnd Maps** (free) from the App Store.
2. Copy the map files onto the iPhone and open them in OsmAnd (see
   [Use the library on a phone](guide:USE-ON-PHONE)).

---

## 🪟 Windows computer

Nothing to install.

1. On the drive, open **OfflineLibrary → OsmAnd → MapViewer-Desktop**.
2. Double-click **`VIEW-MAPS-ON-PC`**.
3. **The first time only,** it unpacks the maps, which takes several minutes. Leave the black
   window open.
4. The map viewer opens. Use its menus to open a map, then zoom and search.

The first time uses a lot of free space (about **30 GB** for the whole USA, much less for
Oregon). The installer left that space empty on purpose.

## 🍎 Mac or 🐧 Linux computer

1. Open **Terminal** (Mac: press **Command + Space**, type `Terminal`, press **Return**).
2. Type `bash ` (with a space), drag **`VIEW-MAPS-ON-PC.sh`** (in **OsmAnd → MapViewer-Desktop**)
   into the window, and press **Return**.

This file is only on drives that were made on a Mac or Linux computer.

---

## 🧰 For helpers: maps of other places

The point-and-click installer offers only the USA, Oregon and California, or Oregon. For anywhere
else, run the installer script from the kit's `files` folder with a region:

```
# Windows (PowerShell)
./Get-OfflineLibrary.ps1 -Destination "E:\" -Region France
# Mac / Linux
./get-offline-library.sh -d /Volumes/MYDRIVE --region France
```

A region can be a country, a continent (`Europe`), part of a country (`US_texas`) or `world`. Add
`-ListRegions` (Windows) or `--list-regions` (Mac/Linux) to see the names.

Keep a **paper map** as a backup too. Electronics fail.
