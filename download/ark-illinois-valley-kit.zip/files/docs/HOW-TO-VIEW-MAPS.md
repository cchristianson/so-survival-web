# 🗺️ Offline Maps — How to View Them (PC or Phone)

The **OsmAnd** folder on the drive holds detailed maps (roads, towns, terrain and place search)
that work with **no internet**, on a phone or on a computer. Which area you have was picked when
the drive was made: **the whole USA**, **Oregon and California**, or **Oregon only**. To change it,
run the installer again ([Get the whole library](guide:GET-THE-LIBRARY)).

**A phone is best for finding your way:** the OsmAnd app gives directions. The computer viewer is
plain, but fine for finding places, roads and coordinates.

---

## 🤖 Android phone or tablet

1. Install OsmAnd from the drive's **Phone-Apps** folder (the `OsmAnd-….apk` file). Step-by-step
   help: [Use the library on a phone](guide:USE-ON-PHONE).
2. Copy your area's map files (in the **OsmAnd** folder, ending in `.obf.zip`) to the phone. For
   Oregon, that's the files starting with `Us_oregon`.
3. Open **OsmAnd** → **Menu** → **Configure map / Download maps → Import** and pick the files.
   Maps, search and directions now work offline.

**If that didn't work:** copy the map files into the phone's
`Android/data/net.osmand.plus/files/` folder instead.

## 🍏 iPhone or iPad

Apple doesn't allow installing apps from a file, so the drive's app won't work on an iPhone.

1. **While you still have internet,** install **OsmAnd Maps** (free) from the **App Store**.
2. Copy the map files onto the iPhone and open them in OsmAnd (see
   [Use the library on a phone](guide:USE-ON-PHONE)). Or, while online, download your area inside
   the OsmAnd app.

---

## 🪟 Windows computer

Everything the viewer needs, Java included, is on the drive. Nothing to install. (It's only on
drives made on a Windows computer.)

1. On the drive, open **OfflineLibrary** → **OsmAnd** → **MapViewer-Desktop**.
2. Double-click **`VIEW-MAPS-ON-PC`** (the `.bat` file).
3. A black window opens. **The first time only,** it unpacks the maps, which can take several
   minutes. Leave the window open.
4. The map viewer (**OsmAndMapCreator**) opens. Your maps are the `.obf` files in the
   `OsmAnd\obf` folder. Use its menus to open a map, then zoom and search.

> ### ⚠️ The computer viewer needs free space
> Unpacking takes about **30 GB** for the whole USA (much less for Oregon). The installer left
> that space **empty on purpose**, so keep it free if you want maps on a computer. Phones use the
> map files as they are and don't need it. Short on space later? Delete the `OsmAnd\obf` folder;
> the viewer makes it again next time.

## 🍎 Mac or 🐧 Linux computer

The Mac/Linux viewer, **`VIEW-MAPS-ON-PC.sh`**, is only on drives made on a Mac or Linux computer.

1. **Mac:** open **Terminal** (press **Command + Space**, type `Terminal`, press **Return**).
   **Linux:** open a terminal.
2. Type `bash ` (with a space), drag **`VIEW-MAPS-ON-PC.sh`** (in **OsmAnd** →
   **MapViewer-Desktop**) into the window, and press **Return**.
3. As on Windows, the first time it unpacks the maps, then the viewer opens.

---

## 🧰 For helpers: maps of other countries or regions

The point-and-click installer offers only the USA, Oregon and California, or Oregon. For anywhere
else, run the installer script from the kit's `files` folder with a region:

```
# Windows (PowerShell)
./Get-OfflineLibrary.ps1 -Destination "E:\" -Region France
# Mac / Linux
./get-offline-library.sh -d /Volumes/MYDRIVE --region France
```

A region can be a country (`France`), several (`"Germany,Austria"`), a continent (`Europe`), part
of a country (`US_texas`) or `world`. To list the names, run it with just `-ListRegions`
(Windows) or `--list-regions` (Mac/Linux). Sizes vary: the whole USA is about 17 GB, a small
country can be under 1 GB, and `world` is hundreds of GB. The viewer and phone apps work with any
region.

Keep a **paper map** as a backup too. Electronics fail.
