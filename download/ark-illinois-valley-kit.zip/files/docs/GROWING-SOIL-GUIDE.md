# 🌱 Building Soil: Permaculture, Hugelkultur & Growing More With Less

How to build soil in the Illinois Valley that holds water and feeds crops with less digging, watering and bought fertilizer:
compost at every scale, mulch and no-dig beds, cover crops, biochar, animals that work the ground, hugelkultur beds,
catching rain on the contour, ponds, food forests and mixed plantings, with a plain word on what the research backs.
Most of the books are in `Southern-Oregon\Gardening-Food\Soil-Permaculture`: SARE's *Building Soils for Better Crops*
and *Managing Cover Crops Profitably*, the NRCS composting and pond handbooks, FAO's small-farm composting methods, the
WOCAT water-harvesting guide, a Forest Service biochar sheet, and four old classics: *Tree Crops* (1929), *Farmers of
Forty Centuries* (1911), Buffalo Bird Woman's garden (1917) and Widtsoe's *Dry-Farming* (1911). The Extension booklets
on organic matter, compost and gardening with less water are in the rest of `Southern-Oregon\Gardening-Food`. The county soil survey, which says what each of the valley's soils is like, is there too.

> ### The short version
> - **Organic matter is the lever.** Every 1% of organic matter lost from the top foot means about **16,500 gallons
>   less water** held per acre ([*Building Soils*, p. 279](lib:building-soils-for-better-crops#page=279)). Keep the
>   ground covered and dig as little as you can: plowing speeds the loss ([p. 254](lib:building-soils-for-better-crops#page=254)).
> - **Mulch 3–4 inches deep** ([UC ANR, p. 1](lib:food-gardening-with-less-water#page=1)). About a third of the water
>   lost from watered fields goes straight up from bare soil, and a surface mulch cuts that greatly
>   ([*Building Soils*, p. 138](lib:building-soils-for-better-crops#page=138)).
> - **Compost every year, but not by the foot:** ¼–1 inch a year on beds already made
>   ([EM 9308, p. 2](lib:how-to-use-compost-in-gardens#page=2)). Heavy yearly doses overload the soil
>   ([*Building Soils*, p. 223](lib:building-soils-for-better-crops#page=223)).
> - **Grow your nitrogen.** Sow a legume cover crop early, before the winter rains
>   ([*Managing Cover Crops*, p. 18](lib:managing-cover-crops-profitably#page=18)); a strong one can supply all the
>   nitrogen the next crop needs ([*Building Soils*, p. 124](lib:building-soils-for-better-crops#page=124)).
> - **Hugelkultur is half proven.** Buried wood holds water, but fine woody stuff ties up nitrogen for months
>   ([*Building Soils*, pp. 139–141](lib:building-soils-for-better-crops#page=139)). Build it **at least 30 ft from the
>   house** in fire country.
> - **Catch rain on the level.** Behind a level bank, rain soaked **four feet** deep instead of six inches
>   ([*Tree Crops*, p. 330](lib:tree-crops-a-permanent-agriculture#page=330)). Not on clay, and not on steep ground that
>   stays wet ([WOCAT, p. 128](lib:water-harvesting-guidelines-to-good-practice#page=128);
>   [*Building Soils*, p. 93](lib:building-soils-for-better-crops#page=93)).
> - **Trees are slow:** chestnuts take 5–7 years to bear, walnuts 10–12
>   ([EC 819, p. 3](lib:growing-tree-fruits-and-nuts#page=3)). Plant them now, beside the annual beds, not instead of them.

---

## 🧭 The ideas, and what the research backs
<!-- fold: Where permaculture comes from, a table of which practices hold up, and where the books disagree -->

"Permaculture" grew out of the words **permanent agriculture**, the subtitle of both King's 1911 tour of farms in East
Asia kept fertile for thousands of years ([King](lib:farmers-of-forty-centuries)) and *Tree Crops*, which wanted crop
trees on the hills the plow was washing away ([*Tree Crops*, p. 39](lib:tree-crops-a-permanent-agriculture#page=39)).
The later permaculture handbooks are under copyright and not in this library. The core idea is simple: **copy a forest.**
Keep the soil covered, feed it, keep living roots in it, catch the rain where it falls, and mix many plants together.

| Practice | What the books show | Verdict |
|---|---|---|
| **Mulch, compost, more organic matter** | More water held, less lost to the air, fewer weeds, steadier soil temperature ([*Building Soils*, pp. 136–138](lib:building-soils-for-better-crops#page=136), [p. 279](lib:building-soils-for-better-crops#page=279)) | **Holds up** |
| **Less digging (no-dig, no-till)** | After 13–33 years of no-till, soils held up to **34% more** plant-available water ([p. 280](lib:building-soils-for-better-crops#page=280)) | **Holds up**, slowly |
| **Cover crops, green manure** | Nitrogen, organic matter, less erosion ([p. 124](lib:building-soils-for-better-crops#page=124)); but they drink water a dry year can't spare ([*Managing Cover Crops*, p. 62](lib:managing-cover-crops-profitably#page=62)) | **Holds up** if timed to the rains |
| **Trees over field crops** | A two-story farm "got about a 75 per cent crop of each, making a total of 150 per cent" ([*Tree Crops*, p. 39](lib:tree-crops-a-permanent-agriculture#page=39)); but trees take years and compete for water ([*Building Soils*, pp. 186–187](lib:building-soils-for-better-crops#page=186)) | **Holds up**, slow |
| **Catching water on the contour** | Trees on a level row "were distinctly the largest in the orchard" ([*Tree Crops*, p. 329](lib:tree-crops-a-permanent-agriculture#page=329)) | **Holds up** on the right soil and slope |
| **Companion planting** | Trap crops and flower strips work ([*Building Soils*, p. 124](lib:building-soils-for-better-crops#page=124)); most "friends and enemies" charts have no tests behind them *(rule of thumb)* | **Partly** |
| **Biochar** | "many times increases in yield", but "sometimes yields suffer" ([p. 31](lib:building-soils-for-better-crops#page=31)) | **Mixed** |
| **Hugelkultur** | No book here tests it. Buried wood holds water and ties up nitrogen ([pp. 139–141](lib:building-soils-for-better-crops#page=139)) | **Mixed** |

**Where the books disagree.** The old dry-farming books stirred the top inches into dust to save water (see "Old
advice"); the modern ones leave residue on top and dig as little as possible. *Building Soils* also says its tillage
and water gains "have the most significant impact in humid regions" ([p. 280](lib:building-soils-for-better-crops#page=280)):
where summers are long and rainless, mulch and organic matter stretch the water you have but don't replace it. Adding
organic matter "will not eliminate the need for watering" in dry summer weather ([EC 1561, p. 15](lib:improving-garden-soils#page=15)).

## 🪱 Organic matter: the heart of it
<!-- fold: Why organic matter matters, how fast it builds and burns away, and checking your own soil -->

Farm topsoil usually holds **1–6% organic matter**; one study found about **12% more yield for each 1% more**
([*Building Soils*, p. 32](lib:building-soils-for-better-crops#page=32)). It holds water, feeds soil life and slowly
releases nutrients ([EC 1561, p. 4](lib:improving-garden-soils#page=4)).

- **It builds slowly.** About **half** of what you add is still there after two seasons
  ([EC 1561, p. 7](lib:improving-garden-soils#page=7)). Plan in years.
- **It burns away with digging.** Plowed fields suffer "higher organic matter decomposition" and more erosion
  ([*Building Soils*, p. 254](lib:building-soils-for-better-crops#page=254)). Burning residue loses it too
  ([p. 136](lib:building-soils-for-better-crops#page=136)).
- **Check by hand** ([EC 1561, p. 4](lib:improving-garden-soils#page=4)): dark color; water soaks in instead of
  puddling; it crumbles into "crumbs"; it smells rich, not foul.

## ♻️ Compost from a bucket to a farm
<!-- fold: The mix, pit and heap methods with no machines, farm windrows, and how much to use -->

Household piles, worm bins, manure safety and what to keep out: [Sanitation](guide:SANITATION-GUIDE), "Composting food,
yard waste and manure".

**The mix.** About **25–40 parts carbon to 1 part nitrogen** ([*Building Soils*, p. 217](lib:building-soils-for-better-crops#page=217));
manure with straw, wood chips or bark composts "as is" (p. 218). A tested backyard mix: **100 lb grass clippings,
130 lb leaves, 80 lb food scraps** (p. 217). Rapid composting needs **40–60% moisture**, damp as a wrung sponge
([NRCS *Composting*, p. 62](lib:composting-engineering-handbook#page=62)). **Never** coal ash or chips of
pressure-treated lumber ([*Building Soils*, p. 218](lib:building-soils-for-better-crops#page=218)).

**Methods with no machines** ([FAO, p. 19](lib:fao-on-farm-composting-methods#page=19)):

| Method | How | Ready in |
|---|---|---|
| **Pit** (Indore) | Pit 3 ft deep, 5–6 ft wide; 4–6 in layers of mixed residue and dung, each wetted; turn at 15, 30 and 60 days ([pp. 21–22](lib:fao-on-farm-composting-methods#page=21)) | 4 months |
| **Covered pit** (Bangalore) | Layers in a 3-ft trench, sealed with earth, no turning; "suitable for areas with scanty rainfall" ([p. 20](lib:fao-on-farm-composting-methods#page=20)) | 6–8 months |
| **Heap** (Indore) | 6 ft wide, 5 ft high, 6 ft long; in rainy seasons, under a roof ([p. 22](lib:fao-on-farm-composting-methods#page=22)) | 4 months |
| **Fast pile** | Chop everything small, turn daily ([p. 12](lib:fao-on-farm-composting-methods#page=12)) | 2–3 weeks |

So: a pit in the dry season, a roofed heap in the wet one ([FAO, p. 20](lib:fao-on-farm-composting-methods#page=20), [p. 22](lib:fao-on-farm-composting-methods#page=22)).

**Farm scale.** Manure piles need **at least equal volumes of bedding and manure**, and a pile that is never turned
must stay **under about 6½ ft high and 13 ft wide** ([FAO, p. 21](lib:fao-on-farm-composting-methods#page=21)). Turned
windrows run **6–10 ft high and 15–20 ft wide**, finish in **3–9 weeks** and cure 30 days more; shape the top to shed
rain in a wet climate, dish it to catch water in a dry one ([NRCS *Composting*, p. 46](lib:composting-engineering-handbook#page=46)).
To kill germs, hold a windrow at **131 °F for 15 days with at least five turnings** ([p. 42](lib:composting-engineering-handbook#page=42)).
Big, hot, dry piles can catch fire on their own ([*Building Soils*, p. 217](lib:building-soils-for-better-crops#page=217)):
keep them damp and away from buildings and dry grass.

**How much to use.** 1–2 inches into a new bed ([EC 1561, p. 7](lib:improving-garden-soils#page=7)), then **¼–1 inch
a year** ([EM 9308, p. 2](lib:how-to-use-compost-in-gardens#page=2)). Compost is low in quick nitrogen, so feeding
crops on compost alone piles up phosphorus and potassium ([*Building Soils*, p. 224](lib:building-soils-for-better-crops#page=224)):
get the rest of the nitrogen from legumes, manure or urine. Half-made compost (above 25:1) ties up nitrogen for months
([EC 1561, p. 10](lib:improving-garden-soils#page=10)).

## 🍂 Mulch, sheet mulching and no-dig beds
<!-- fold: What mulch does, how deep, wood chips and nitrogen, and building a no-dig bed on top of sod or weeds -->

**Mulch** gives the crop more water, fewer weeds, steadier soil temperature, cleaner fruit and fewer potato beetles;
in a cold spring it slows warming and feeds slugs ([*Building Soils*, pp. 136–138](lib:building-soils-for-better-crops#page=136)).

- **Depth:** 3–4 inches of straw, leaves, hulls, shredded bark, grass clippings or newspaper; coarser stuff deeper;
  **2 inches back from stems**; pull it aside when hand watering ([UC ANR, p. 1](lib:food-gardening-with-less-water#page=1)).
  Under trees and shrubs, 2–4 inches of coarse compost, chips or bark ([EC 1561, p. 14](lib:improving-garden-soils#page=14)).
- **Wood and nitrogen.** Fresh sawdust is about **400 parts carbon to 1 of nitrogen**, straw 80, green rye 36
  ([*Building Soils*, p. 140](lib:building-soils-for-better-crops#page=140)). Mixed *into* soil, anything over about
  40:1 starves the crop of nitrogen for a while; large chips do it far less than sawdust, and chips mixed in hold
  more water ([pp. 140–141](lib:building-soils-for-better-crops#page=140)). Dig sawdust in only with extra nitrogen
  ([EC 1561, p. 6](lib:improving-garden-soils#page=6)); on top, around trees, chips are fine ([p. 14](lib:improving-garden-soils#page=14)).
- **No plastic sheeting** ([UC ANR, p. 1](lib:food-gardening-with-less-water#page=1)): it breaks into bits that stay in
  the soil ([*Building Soils*, p. 140](lib:building-soils-for-better-crops#page=140)).

**A no-dig ("sheet mulch") bed.** "Apply a layer of organic amendment on the soil surface and simply plant into it.
This method avoids work, soil disturbance and provides a mulch"; it builds organic matter more slowly than digging in
([EC 1561, p. 12](lib:improving-garden-soils#page=12)). One way *(rule of thumb)*:

1. In fall, cut weeds or sod short and leave them. Soak the ground.
2. Lay cardboard or 6–8 sheets of newspaper, edges overlapped 6 inches, no tape or glossy print. Wet it.
3. Add 2–3 inches of compost or old manure, then 4–6 inches of straw or leaves.
4. In spring, part the mulch, plant transplants or big seeds into the compost, and tuck it back. Top up every year.

It is also how to garden where you must not dig: ground with old lead or pesticides
([*Building Soils*, p. 102](lib:building-soils-for-better-crops#page=102)), or serpentine ("Fitting it to your land").

## 🌾 Cover crops and green manures
<!-- fold: When to sow, which ones, how much nitrogen, ending them with hand tools, and the water they use -->

A cover crop feeds and shields the soil; its roots often build structure better than its tops
([EC 1561, p. 12](lib:improving-garden-soils#page=12)).

- **Sow early, before the winter rains.** Even 40% ground cover going into winter cuts erosion a lot
  ([*Managing Cover Crops*, p. 18](lib:managing-cover-crops-profitably#page=18)). Mild, wet winters suit covers that
  grow all winter and flower in May or June ([PNW 548, p. 11](lib:winter-vegetable-production#page=11)).
- **For nitrogen, grow legumes:** hairy vetch, crimson clover, winter peas or fava (bell) beans, mixed with rye or oats
  ([*Managing Cover Crops*, p. 144](lib:managing-cover-crops-profitably#page=144); [*Building Soils*, p. 154](lib:building-soils-for-better-crops#page=154)).
  Hairy vetch can supply the nitrogen for many vegetables ([*Managing Cover Crops*, p. 144](lib:managing-cover-crops-profitably#page=144)).
- **How much nitrogen?** Weigh the fresh vetch cut from a **4 × 4 ft** square: pounds × 12 ≈ pounds of nitrogen per acre
  the next crop can use (p. 144).
- **Cereal rye** smothers weeds and its residue holds back small weed seeds ([p. 34](lib:managing-cover-crops-profitably#page=34)),
  and small crop seeds too: after killing rye, wait **3–4 weeks** before sowing carrots or onions; transplants and big
  seeds mind less ([p. 105](lib:managing-cover-crops-profitably#page=105)).
- **Ending it with hand tools:** cut or roll it **at flowering or later**, when rolling works best
  ([p. 56](lib:managing-cover-crops-profitably#page=56)). Leave it as mulch, dig it in or compost it, and plant **2–3 weeks later** ([EC 1561, p. 12](lib:improving-garden-soils#page=12);
  [*Managing Cover Crops*, p. 57](lib:managing-cover-crops-profitably#page=57)).
- **Water.** In dry years covers take water the next crop needs, and their residue keeps a cool spring soil cooler
  ([p. 62](lib:managing-cover-crops-profitably#page=62)): end them before they draw the soil dry. Killed vetch left on
  top then helped hold summer moisture ([p. 144](lib:managing-cover-crops-profitably#page=144)).

## ⚫ Biochar
<!-- fold: What biochar is, when it helps, how much, and making it safely -->

Biochar is charcoal made for the soil: wood or crop waste heated with little air, then quenched with water
([Forest Service *Biochar FAQ*, p. 1](lib:biochar-faqs#page=1)). You can make it "in your fire pit, a 50-gallon barrel,
or any other metal container that can limit the oxygen" (p. 2).

- **What it does:** holds nutrients, sweetens acid soil, feeds soil life and lasts for centuries; yields often rise, but
  **"sometimes yields suffer"**: grasses may go short of nitrogen for a while, legumes do well
  ([*Building Soils*, p. 31](lib:building-soils-for-better-crops#page=31)). Much of the quick effect is the ash (same page).
- **Where it helps most:** coarse, sandy soils low in organic matter ([*Biochar FAQ*, p. 3](lib:biochar-faqs#page=3)).
  On a good garden soil, compost does more.
- **How much:** **1–10 tons an acre** to help plants start; "More is not always better" (p. 3). That is about
  ½–4½ lb per 100 sq ft.
- **Load it first.** Mixed into compost it becomes "an enriched soil amendment" ([p. 2](lib:biochar-faqs#page=2)); or
  soak it a few weeks in diluted urine *(rule of thumb)*. Then it carries nutrients instead of taking them.
- **Fire:** make it only in the wet season, on bare ground, with water at hand: "Burning on purpose: wet season only" in
  [Wildfire](guide:WILDFIRE-GUIDE).

## 🐖 Animals that work the ground
<!-- fold: Pigs, chickens, rabbits, ducks and goats as tillers, weeders and fertilizer -->

Animals can do the digging and spreading; grazing a cover crop "still cycles much of the carbon and nutrients"
([*Building Soils*, p. 168](lib:building-soils-for-better-crops#page=168)).

- **Pigs** plow stalks in and spread their droppings: "Rooting: the problem and the plow" in [Pigs](guide:PIGS-GUIDE).
  Under fruit trees "pigs gladly pick up the fruit themselves" ([*Tree Crops*, p. 117](lib:tree-crops-a-permanent-agriculture#page=117)).
- **Chickens** in a movable pen scratch a bed clear between crops *(rule of thumb)*: "Manure, litter and feathers" in
  [Chickens](guide:CHICKENS-GUIDE). **Rabbits**: "Manure for the garden" in [Rabbits](guide:RABBITS-GUIDE).
- **Ducks** eat the slugs that mulch feeds ([Ducks](guide:DUCKS-GUIDE)); **goats** clear brush for new beds
  ([Goats](guide:GOATS-GUIDE)).

Keep animals off wet winter soil, and give raw manure time before it touches food crops ([Sanitation](guide:SANITATION-GUIDE)).

## 🪵 Hugelkultur beds
<!-- fold: What a wood-cored mound can and can't do, how to build one, which wood, and fire safety -->

A **hugelkultur** ("hill culture") bed is a long mound with logs and branches buried in its core, covered with sod,
manure, compost and soil ([Hügelkultur](wiki:Hügelkultur)). No book in this library tests whole beds. What the soil
books say about wood in soil:
- **Water:** wood chips mixed into soil "can also improve water retention"
  ([*Building Soils*, p. 141](lib:building-soils-for-better-crops#page=141)). Rotting logs soak up winter rain and give
  it back in summer *(rule of thumb)*.
- **Nitrogen:** wood is 100 or more parts carbon to one of nitrogen, and microbes rotting it take nitrogen from the crop
  ([pp. 139–141](lib:building-soils-for-better-crops#page=139)); **big logs tie up much less than chips or sawdust**
  (p. 141). So the logs go deep, the crop's roots grow in compost and manure on top, and the first year is slow:
  feed it with manure, urine or a legume *(rule of thumb)*.

### Building one
*(rule of thumb, the usual practice)*
1. Pick a spot **at least 30 ft from any building** (below); on a slope, run it on the contour so it catches runoff.
2. Dig a trench 1–2 ft deep and 3–5 ft wide; set the sod aside.
3. Lay the biggest logs in the bottom, then branches; fill gaps with twigs, leaves and old hay. **Soak the wood**.
4. Lay the sod upside down on top, then manure or green stuff, then 4–6 inches of compost and topsoil.
5. Make it 3–4 ft high; it sinks as the wood rots. Mulch it and plant: squash, potatoes, beans, strawberries.

### Which wood
Use wood that rots fast. Alder, cottonwood, willow, maple, birch, true firs and most pines are "slightly or
nonresistant" to decay; cedars, junipers, white oaks, old-growth redwood and black walnut are "resistant", and black
locust and Pacific yew "very resistant" ([Wood Handbook, p. 316](lib:wood-handbook-wood-as-an-engineering-material#page=316)).
- **Not** cedar, juniper or redwood: they last too long (same page).
- **Not black walnut:** its [juglone](wiki:Juglone) stunts tomatoes and other crops *(rule of thumb)*.
- **Never treated or painted wood:** treated wood carries metals and phenols, old paint lead
  ([*Building Soils*, p. 218](lib:building-soils-for-better-crops#page=218), [p. 359](lib:building-soils-for-better-crops#page=359)).

### Fire safety in a dry summer
A hugelkultur bed is a buried woodpile. Keep the first **5 ft** from the house noncombustible and the **5–30 ft** zone
"lean, clean and green", with no build-up of dead material ([EM 9247, pp. 3–4](lib:osu-em-9247-home-ignition-zone#page=3));
large dry spreads of bark mulch are a risk too ([p. 4](lib:osu-em-9247-home-ignition-zone#page=4)). So build it
**beyond 30 ft** and never against a fence, shed or woodpile; keep all the wood under at least 6 inches of soil and
its mulch damp or green in fire season *(rule of thumb)*. More in [Wildfire](guide:WILDFIRE-GUIDE).

## 💧 Water: swales, ponds and keeping the soil wet
<!-- fold: Level ditches and banks, keyline, planting pits for trees, farm ponds, and holding winter rain into summer -->

West of the Rocky Mountains rain comes "chiefly in winter and spring, leaving the summers rainless"
([Widtsoe, p. 72](lib:dry-farming-a-system#page=72)). Here only **5–7 inches** of the year's rain falls April through September
([Josephine soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)). The job is to store winter rain in the soil
"within reach of the roots", and keep it there ([Widtsoe, p. 37](lib:dry-farming-a-system#page=37)).

### Swales on contour
A **swale** here is a ditch dug exactly level across a slope, its soil heaped on the downhill side as a bank
([Swale](wiki:Swale_(landform))). Runoff stops in it and soaks in.
- **It works.** An orchardist laid one tree row "on the absolute level" and found those trees "distinctly the largest";
  with level terraces above every row he had no runoff for years ([*Tree Crops*, pp. 329–330](lib:tree-crops-a-permanent-agriculture#page=329)).
  On gullied land, rain went six inches deep without water pockets and **four feet** with them (p. 330).
- **How:** dig a channel on the contour, throw the soil **downhill** as a bank, and leave **cross ties** (small dams)
  so water can't run along it and break through; plant the thirstiest crops where water gathers, just above or below
  the bank ([WOCAT, p. 128](lib:water-harvesting-guidelines-to-good-practice#page=128)). Such banks are also used to
  start trees (same page).
- **Level it** with an A-frame or water level: "Slope, grade, pitch and stairs" in [Practical Math](guide:PRACTICAL-MATH-GUIDE).
  A swale that isn't level runs to its low end and cuts a gully; give each one a level, grassed or rocked spillway onto
  ground that can take the overflow *(rule of thumb)*.
- **Where not:** contour banks are "not on clays"; they suit slopes of 1–25% ([WOCAT, p. 128](lib:water-harvesting-guidelines-to-good-practice#page=128)).
  Landslides start where soil is "supersaturated from prolonged rains", especially where water gathers from upslope
  ([*Building Soils*, p. 93](lib:building-soils-for-better-crops#page=93)). With wet winters, **no swales on steep or
  slumping slopes, or above a house, road, well or septic field**: use mulch, grass strips and trees there *(rule of thumb)*.

### Keyline
Keyline ripping runs just off the contour so runoff is led from the wet hollows out toward the dry ridges
([Keyline design](wiki:Keyline_design)). No book here covers it; on a small place, level swales and ground cover do
the job with hand tools *(rule of thumb)*.

### Planting pits and half-moons for trees
Each young tree gets the runoff from bare ground around it ([WOCAT, pp. 124–126](lib:water-harvesting-guidelines-to-good-practice#page=124)):
- **Planting pits** 8–12 inches wide and deep, the dug soil heaped downhill (p. 124).
- **Half-moons:** banks 1–1½ ft high, tips on the contour facing uphill, staggered so each row catches what slips past
  the one above; earth ones rarely on slopes over 5% (p. 126). On steeper ground, a small level **eyebrow terrace**
  for each tree (same page).
- **Diamond basins** with the tree at the low point, for apricots, almonds, olives, grapes and pomegranates (p. 125).

### Ponds
- **Permits first:** the owner "is responsible for obtaining permits" ([NRCS *Ponds*, p. 2](lib:ponds-planning-design-construction#page=2)). In Oregon a pond needs a water right: storing water is not on the state's list of uses exempt from a permit. Stock
  water is exempt only "from a permitted reservoir", while "collection and use of rainwater from an artificial
  impervious surface (like a building's roof)" is ([OWRD *Exempt Water Uses*, p. 2](lib:exempt-water-uses-in-oregon#page=2)).
  Ask the local watermaster before you dig. On serpentine, ponds are limited by "the shallow depth to bedrock"
  ([soil survey, p. 49](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=49)).
- **Siting:** never where a broken dam could hurt people, livestock, homes or roads; keep runoff from barns, corrals and
  septic lines out; avoid wide shallow edges, which lose water and grow weeds ([NRCS *Ponds*, p. 20](lib:ponds-planning-design-construction#page=20)).
  The handbook covers dams under 35 ft that can't endanger life ([p. 12](lib:ponds-planning-design-construction#page=12)).
- **Depth:** from 5 ft in wet country to 8–10 ft in dry, deeper if seepage tops 3 inches a month
  ([pp. 21–22](lib:ponds-planning-design-construction#page=21)).
- **Will it hold?** Soil with **10% or more clay** and mixed particle sizes can be sealed by packing alone: loosen
  16–18 inches, then compact it to a seal at least 12 inches thick ([p. 73](lib:ponds-planning-design-construction#page=73)).
- A pond is also fire water: "Water with no power" in [Wildfire](guide:WILDFIRE-GUIDE).

### Keeping water in the soil through a dry summer
- **Fill it in winter:** on bare, packed ground only a tenth of a big storm soaked in, on stubble about 60%
  ([Widtsoe, p. 130](lib:dry-farming-a-system#page=130)). Keep the ground covered.
- **Deep roots:** break hardpans so roots reach stored water ([*Building Soils*, p. 280](lib:building-soils-for-better-crops#page=280)).
- **Mulch** all summer, and weed hard: weeds drink the same water ([UC ANR, p. 2](lib:food-gardening-with-less-water#page=2)).
- **Water when it counts:** beans at bloom and pod set, corn at tasseling and silking, peas at pod filling, squash,
  melons, tomatoes and peppers at flowering and fruiting; tomatoes need less once set (p. 2).
- **Dry farming** (no watering) works only when winter rain filled the soil; after a dry winter, don't count on it
  ([p. 1](lib:food-gardening-with-less-water#page=1)). Roof water and tanks: "Cisterns and rainwater" in [Water Wells](guide:WATER-WELLS-GUIDE).

## 🌳 Food forests and guilds
<!-- fold: Layers of trees, shrubs and ground plants, nitrogen fixers, how long it takes, and trees for a dry-summer, cold-winter valley -->

A **food forest** copies a forest edge: nut trees, smaller fruit trees, berry bushes, herbs, ground covers and vines,
all yielding ([Agroforestry](wiki:Agroforestry)). *Tree Crops* called it "two-story agriculture (trees above and
annual crops below)" ([p. 36](lib:tree-crops-a-permanent-agriculture#page=36)); it also spreads the risk: "If frost
kills the almond, it probably will not injure the wheat" ([p. 39](lib:tree-crops-a-permanent-agriculture#page=39)). A
**guild** is one tree with its helpers: a nitrogen fixer, flowers for good insects, a ground cover *(rule of thumb)*.

**The costs.** Trees "often don't produce income for several years, or even for decades"
([*Building Soils*, p. 186](lib:building-soils-for-better-crops#page=186)), and they compete with the crops beneath for
"sun, moisture and nutrients" ([p. 187](lib:building-soils-for-better-crops#page=187)). Years to first crop
([EC 819, p. 3](lib:growing-tree-fruits-and-nuts#page=3)):

| Tree | Years to bearing | Needs a second variety? |
|---|---|---|
| Apple (by rootstock) | 2–10 | Yes |
| Hazelnut | 5–6 | Yes |
| Chestnut | 5–7 | Yes |
| Walnut, black or English | 10–12 | No |
| Hickory | 10–14 | Yes |

- So **plant the slow trees first**, with berries and annual beds to feed you meanwhile.
- **Roots need at least 3 ft** of rootable soil ([EC 819, p. 1](lib:growing-tree-fruits-and-nuts#page=1)).
- **Mulch, not grass, under trees:** trees in sod need "much more nitrogen" ([p. 17](lib:growing-tree-fruits-and-nuts#page=17)).
  Clovers, vetch or peas underneath give nitrogen the first years ([*Building Soils*, p. 124](lib:building-soils-for-better-crops#page=124)).
- **Water the first few summers** until roots are deep *(rule of thumb)*; plant in pits or half-moons (above).
- **Crops for animals:** mulberries and persimmons that pigs and chickens pick up themselves, acorns and chestnuts,
  and honey locust pods: one tree filled a wagon with about ten bushels
  ([*Tree Crops*, p. 40](lib:tree-crops-a-permanent-agriculture#page=40), [p. 95](lib:tree-crops-a-permanent-agriculture#page=95)).
- **Fire:** keep its canopy and dead wood out of the 30 ft around the house ("The zones around the house" in
  [Wildfire](guide:WILDFIRE-GUIDE)).

**Trees and shrubs for the valley.** OSU puts southwest Oregon in its Area 1, "a warmer, drier climate with frequent
spring frosts" ([EC 819, p. 2](lib:growing-tree-fruits-and-nuts#page=2)). Area 1 suits apples, pears, plums, sour
and sweet cherries, peaches, figs, persimmons, almonds, chestnuts, hazelnuts, and black and English walnuts; apricots
are listed only for Area 2, east of the mountains, with warmer summers and colder winters ([pp. 2–3](lib:growing-tree-fruits-and-nuts#page=3)). Late frosts take
blossoms in the valley-floor hollows, so put apricots, almonds and peaches on the slopes above them *(rule of thumb)*.

The valley's own food plants belong at the edges of a food forest and on ground too poor or dry for fruit trees:
- **Oaks.** Forest rangers measured 500–600 lb of acorns from single **Oregon white oaks**, but a crop only every 3–4
  years and "frequently killed by frosts"; **black oak** gave up to about 225 lb, usually two crops in three years
  ([*Tree Crops*, p. 174](lib:tree-crops-a-permanent-agriculture#page=174)). White oak grows as a shrub on serpentine
  ([plant guide, p. 1](lib:oregon-white-oak-plant-guide-quercus-garryana-usda-nrcs#page=1)). Black oak "should not be
  irrigated except in years of unusually low rainfall": keep watered beds and thirsty plants out from under old oaks
  ([plant guide, p. 2](lib:california-black-oak-plant-guide-acorns-usda-nrcs-2002#page=2)). Acorn flour: [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE).
- **Native hazelnut** for nuts ([plant guide, p. 1](lib:beaked-and-california-hazelnut-plant-guide-usda-nrcs-2006#page=1)).
- **Blue elderberry**, planted for its "ease of establishment" but "important as browse for mule deer"
  ([plant guide, p. 1](lib:blue-elderberry-plant-guide-sambucus-nigra-cerulea-usda-nrcs#page=1)): cage it.
- **Whiteleaf manzanita**, which grows on serpentine ([plant guide, p. 1](lib:whiteleaf-manzanita-plant-guide-usda-nrcs-2024#page=1)).

Plant oaks from acorns where they are to grow, water them deeply the first summer, weed around them for several
years and protect them from animals ([black oak plant guide, p. 2](lib:california-black-oak-plant-guide-acorns-usda-nrcs-2002#page=2)).

Grafting and berries from cuttings: "Fruit trees and berries" in [Your Seed Bank](guide:SEED-BANK-GUIDE). Pollination:
[Bees](guide:BEES-GUIDE).

## 🌽 Polycultures, companion planting and the three sisters
<!-- fold: What mixed planting really does, trap crops and flower strips, and how a corn-bean-squash garden was laid out -->

**What holds up** ([*Building Soils*, pp. 123–124](lib:building-soils-for-better-crops#page=123)):
- **Mixed varieties** of one crop: a high-yielding one blended with a hardy one gave more in total.
- **Trap crops:** Blue Hubbard squash around a summer squash patch draws the striped cucumber beetles to itself.
- **Flower strips** in and around beds shelter the insects that eat pests ([PNW 550](lib:encouraging-beneficial-insects)).
- **Relay planting:** "three crops growing upon the same field at one time, but in different stages of maturity"
  ([King, p. 33](lib:farmers-of-forty-centuries#page=33)).

The long charts of plant "friends" and "enemies" are another matter (see the table at the top).

**The three sisters, as one gardener really grew them.** Buffalo Bird Woman, a Hidatsa gardener, described her
family's field ([pp. 48–49](lib:agriculture-of-the-hidatsa-indians#page=48), [p. 110](lib:agriculture-of-the-hidatsa-indians#page=110)):
- **Corn** in hills about **4 ft apart**, rows about 4 ft apart, a little wider when beans went between.
- **Beans** "commonly planted between corn rows", in their own hills.
- **Squash** in **its own rows**, one row between each block of 8–10 corn rows, hills about 4 ft apart.
- **Sunflowers** first, in early spring, around the field's edge, hills eight or nine paces apart ([p. 40](lib:agriculture-of-the-hidatsa-indians#page=40)).

Other gardens put all three in one mound ([Three Sisters](wiki:Three_Sisters_(agriculture))). Either way, grow a flour
or flint corn and beans to eat dry: calories and protein that keep.

## 🥔 More calories for less work and water
<!-- fold: Staple crops, water-wise choices, perennials and nuts, and saving work -->

Calories come from potatoes, dry beans, winter squash, flour corn and grain: "Filling the calorie gap" in
[Your Seed Bank](guide:SEED-BANK-GUIDE); how much a family needs: [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE);
keeping it: [Root Cellars](guide:ROOT-CELLAR-GUIDE).

- **Fewer, better beds:** "plant two beds of vegetables instead of six", of what the family will eat
  ([UC ANR, p. 1](lib:food-gardening-with-less-water#page=1)); in deep, compost-rich soil, plant closer (p. 2).
- **Water-wise crops:** beans, chard, mustard, squash, tomatoes, peppers, eggplant and amaranth give a lot for the water;
  cabbage-family crops, lettuce, roots, celery, leeks and onions need steady water, so grow them in spring and fall
  (p. 1). Short-season varieties need fewer waterings (p. 2).
- **Perennials save digging:** rotations with perennials cut tillage and organic-matter loss
  ([*Building Soils*, p. 176](lib:building-soils-for-better-crops#page=176)).
- **Nuts are dense food:** a mature hazelnut gives **15–20 lb** of dry nuts ([EC 819, p. 13](lib:growing-tree-fruits-and-nuts#page=13));
  one oak can drop hundreds of pounds of acorns ([*Tree Crops*, p. 173](lib:tree-crops-a-permanent-agriculture#page=173)).
  Acorn flour: [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE).
- **Let animals harvest** mast and fallen fruit ([*Tree Crops*, p. 40](lib:tree-crops-a-permanent-agriculture#page=40)).
- **Mulch instead of hoeing:** no-dig beds avoid work ([EC 1561, p. 12](lib:improving-garden-soils#page=12)); cut weeds
  and covers and drop them where they grew *(rule of thumb)*.
- **Keep fertility at home:** compost, manure, urine and legumes; humanure only by the rules in [Sanitation](guide:SANITATION-GUIDE).

## 🗺️ Fitting it to your land
<!-- fold: Deer, gophers, serpentine and clay soils, frost pockets, old orchard soils and fire near the house -->

**Soils in the Illinois Valley** ([Josephine County soil survey](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=7)):
- **Along the rivers** (Newberg, Camas, Evans): deep sandy and gravelly loams; the limits are flooding and
  "droughtiness" ([p. 7](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=7)).
- **Low stream terraces** (Takilma, Kerby, Foehlin): Takilma is cobbly loam that dries out; Foehlin is gravelly clay
  loam that drains slowly and shrinks and swells ([p. 8](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=8)).
- **High terraces and hillsides** of the Illinois River valley (Pollard, Abegg): deep, well-drained loam and gravelly
  loam (same page).
- **Serpentine** (Pearsoll, Dubakella, Eightlar): stony clay loam and clay, "very high in content of magnesium and
  very low in calcium" ([p. 11](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=11)); Pearsoll is
  only 10–20 inches to bedrock and holds 1 to 2½ inches of water ([p. 49](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=49)).

On the dry terraces, mulch and organic matter count most; on serpentine, build up, don't dig.

- **Deer and gophers** take a food forest before you do: fence and wire as in "Growing it here" in
  [Your Seed Bank](guide:SEED-BANK-GUIDE), and cage young trees *(rule of thumb)*.
- **Serpentine soils** are high in magnesium and heavy metals, low in calcium, shallow, stony and quick to dry
  ([UC ANR Pub 8400, pp. 1–2](lib:trees-and-shrubs-for-serpentine#page=1)). The rock can hold asbestos: **don't dig it
  dry**; water first, avoid windy days, and cover beds with **3–6 inches of mulch or clean soil**
  ([p. 2](lib:trees-and-shrubs-for-serpentine#page=2)). Grow food in no-dig beds of brought-in soil and compost; get a
  soil test ([EC 1478](lib:soil-test-interpretation)).
- **Clay** packs when worked wet: dig with a fork, never till it wet ([EC 1561, p. 12](lib:improving-garden-soils#page=12));
  build no-dig beds on top; no swales on heavy clay ([WOCAT, p. 128](lib:water-harvesting-guidelines-to-good-practice#page=128));
  it may hold a pond ([NRCS *Ponds*, p. 73](lib:ponds-planning-design-construction#page=73)).
- **Frost pockets:** cold air pools in hollows; put tender and early-flowering trees
  on the slope above *(rule of thumb)*. The map has a frost-pocket layer: [Offline maps](guide:HOW-TO-VIEW-MAPS). On the valley floor, spring frost can come late in May: see the planting calendar in
  [Your Seed Bank](guide:SEED-BANK-GUIDE). The record low at Cave Junction is −6 °F
  ([soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)).
- **Old orchards and old houses:** lead arsenate and lead paint can stay in the soil ([*Building Soils*, p. 358](lib:building-soils-for-better-crops#page=358));
  no root crops in lead soil ([p. 359](lib:building-soils-for-better-crops#page=359)); use raised beds of clean soil
  and compost ([p. 102](lib:building-soils-for-better-crops#page=102)).
- **Fire:** mulch, wood-cored beds and food-forest brush are fuel. Keep the zones in [Wildfire](guide:WILDFIRE-GUIDE)
  and put compost, hugelkultur and the food forest farther out.

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Keep the soil "covered continually with a deep layer of dry loose soil" by cultivating ([Widtsoe, p. 189](lib:dry-farming-a-system#page=189)); "earth mulches" by hoeing ([King, p. 30](lib:farmers-of-forty-centuries#page=30)) | Stirring burns organic matter and invites erosion ([*Building Soils*, p. 254](lib:building-soils-for-better-crops#page=254)); mulch with residue or straw ([p. 138](lib:building-soils-for-better-crops#page=138)) |
| "Clean fallowing" is "one of the oldest and safest practices of dry-farming" ([Widtsoe, p. 155](lib:dry-farming-a-system#page=155)) | Bare, tilled ground packs and sheds rain (Widtsoe's own figures, [p. 130](lib:dry-farming-a-system#page=130)); keep it covered with residue or a cover crop timed to the rains |
| Paris green (an arsenic poison) on potatoes and fruit trees ([*Household Discoveries*, pp. 319–320](lib:household-discoveries#page=319)) | Never; test old garden and orchard ground for arsenic and lead before growing food ([*Building Soils*, p. 358](lib:building-soils-for-better-crops#page=358)) |
| Fresh night soil carried straight to the fields ([King, p. 41](lib:farmers-of-forty-centuries#page=41)) | Compost it first: "Composting toilets, humanure and urine" in [Sanitation](guide:SANITATION-GUIDE) |
| Night soil and refuse layered in a pit, ready in 6–8 months ([FAO, p. 20](lib:fao-on-farm-composting-methods#page=20)) | After 8–10 days that pit rots slowly without air (same page); follow the times and rules in [Sanitation](guide:SANITATION-GUIDE) |

## 🖼️ Pictures & diagrams

- Nitrogen tied up or released — [🖼️ *Building Soils*, p. 139](lib:building-soils-for-better-crops#page=139); C:N of common materials — [🖼️ p. 140](lib:building-soils-for-better-crops#page=140); a farm composting yard — [🖼️ p. 218](lib:building-soils-for-better-crops#page=218)
- A pile and a turned windrow — [🖼️ NRCS *Composting*, p. 45](lib:composting-engineering-handbook#page=45), [🖼️ p. 46](lib:composting-engineering-handbook#page=46); a layered heap — [🖼️ FAO, p. 24](lib:fao-on-farm-composting-methods#page=24)
- Walnuts with wheat between — [🖼️ *Building Soils*, p. 186](lib:building-soils-for-better-crops#page=186); a two-story farm — [🖼️ *Tree Crops*, p. 28](lib:tree-crops-a-permanent-agriculture#page=28); hogs in a mulberry orchard — [🖼️ p. 116](lib:tree-crops-a-permanent-agriculture#page=116)
- A level water-holding terrace with trees below — [🖼️ *Tree Crops*, p. 333](lib:tree-crops-a-permanent-agriculture#page=333); planting pits — [🖼️ WOCAT, p. 124](lib:water-harvesting-guidelines-to-good-practice#page=124); diamond basins — [🖼️ p. 125](lib:water-harvesting-guidelines-to-good-practice#page=125); half-moons, eyebrow terrace — [🖼️ p. 126](lib:water-harvesting-guidelines-to-good-practice#page=126); contour banks — [🖼️ p. 128](lib:water-harvesting-guidelines-to-good-practice#page=128)
- A pond's dam cut through — [🖼️ NRCS *Ponds*, p. 12](lib:ponds-planning-design-construction#page=12); the Hidatsa garden plan — [🖼️ Buffalo Bird Woman, p. 49](lib:agriculture-of-the-hidatsa-indians#page=49)
- With photos — [Hügelkultur](wiki:Hügelkultur); [Sheet mulching](wiki:Sheet_mulching); [Swale](wiki:Swale_(landform)); [Agroforestry](wiki:Agroforestry); [Biochar](wiki:Biochar); [Green manure](wiki:Green_manure); [Serpentine soil](wiki:Serpentine_soil); [Permaculture](wiki:Permaculture)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE)
- [Your Seed Bank](guide:SEED-BANK-GUIDE) — "Growing it here", the planting calendar, "Filling the calorie gap", fruit trees
- [Sanitation](guide:SANITATION-GUIDE) — "Composting food, yard waste and manure"; humanure
- [Food When It's Scarce](guide:FOOD-SECURITY-GUIDE), [Root Cellars](guide:ROOT-CELLAR-GUIDE) and [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — how much to grow, keeping it, acorn flour
- [Bees](guide:BEES-GUIDE) — pollination and planting for bees
- [Chickens](guide:CHICKENS-GUIDE), [Pigs](guide:PIGS-GUIDE), [Rabbits](guide:RABBITS-GUIDE), [Ducks](guide:DUCKS-GUIDE), [Goats](guide:GOATS-GUIDE) — animals that till, weed and fertilize
- [Practical Math](guide:PRACTICAL-MATH-GUIDE) — a level line; [Offline maps](guide:HOW-TO-VIEW-MAPS) — frost pockets and slopes
- [Wildfire](guide:WILDFIRE-GUIDE) — the zones around the house; burning only in the wet season
- [Water Wells](guide:WATER-WELLS-GUIDE) — cisterns and rainwater
- [Vehicles, Tractors & Heavy Equipment](guide:VEHICLES-EQUIPMENT-GUIDE) — the tractor and implements behind bigger ground work
- [Making Medicines With No Pharmacy](guide:MAKING-MEDICINES-GUIDE) — the medicinal plants worth a place in the garden
- [Skills of the Valley's First Peoples](guide:NATIVE-SKILLS-GUIDE) — acorns, camas, and tending the land with fire
