# 🌿 Making Medicines With No Pharmacy: What Works and What Doesn't

For a household, or a village health worker, when no new medicines are being made and the old ones are
running out: what you can make or use yourself, rated honestly. Most of what saves lives is plain: a drink of
salt and sugar, lots of boiled water on a wound, sugar and honey, diluted bleach, soap and a pressure canner.
Plant medicines help less than people hope, and a few kill. The books are in `Medical\Medicinal-Plants` (the
WHO monographs on medicinal plants, Vols 1–4: the evidence, plant by plant), `Medical\Where There Is No Doctor`
(WTND), `Medical\Field-Care` (the Joint Trauma System wound guidelines, JTS, and Dakin and Dunham's 1917
*Handbook of Antiseptics*), `Medical\Medicines` (MSF *Essential Drugs*) and `Medical\Manuals-PDF`; the old
recipe books are in `Southern-Oregon\Homestead-Skills`. A line that no book backs says *(rule of thumb)*.
How medicines were first discovered and made in factories, for a community that wants to make them again one
day: [How antibiotics came to be](guide:MEDICINE-HISTORY-GUIDE).

**Ratings:** ✅ works (good evidence) · ⚠️ weak or uncertain · ⛔ dangerous.

> ### The short version
> - ✅ **Diarrhea kills by drying people out, and the cure is a drink:** 1 liter of clean water, ½ level
>   teaspoon of salt and 8 level teaspoons of sugar, in sips every 5 minutes
>   ([WTND, p. 152](lib:where-there-is-no-doctor-13-some-very-common#page=2)).
> - ✅ **Wounds: wash them out with lots of boiled water and leave dirty ones open.** A wound that oozes gets
>   sugar or honey under a dry dressing, changed every day
>   ([JTS, p. 16](lib:acute-traumatic-wound-management#page=16)).
> - ✅ **Weak bleach (Dakin's solution) washes infected wounds; strong bleach harms them.** The recipe and
>   strengths are below.
> - ✅ **A pressure canner is a sterilizer:** tools on a rack above the water, 60 minutes
>   ([JTS, p. 18](lib:acute-traumatic-wound-management#page=18)).
> - ✅ **Alcohol only on unbroken skin, and only at 60–80%** ([MSF, p. 654](lib:msf-essential-drugs#page=654)).
>   Never into a wound ([WTND, p. 84](lib:where-there-is-no-doctor-10-first-aid#page=10)).
> - ⚠️ **Willow bark works, but weakly.** A full day's dose puts about as much aspirin-like medicine in the
>   blood as 87 mg of aspirin ([WHO monographs vol 4, p. 318](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=326));
>   one aspirin dose is 300 to 600 mg ([WTND, p. 380](lib:where-there-is-no-doctor-24-green-pages#page=42)).
> - ⚠️ **Most plant medicines have no clinical proof, and their strength changes from plant to plant.** The few
>   with proof are in the table below.
> - ⛔ **Never:** mould "penicillin" by mouth or injection, foxglove, ergot, comfrey or arnica by mouth, poppy
>   or opium, and never inject anything that was not made sterile.

> ### ⚠️ Before you give any dose
> - The doses here are **the doses printed in the library's books**, for when no doctor or pharmacist can be
>   reached. They are not a prescription. Where two books differ, both are shown; where no book gives a dose,
>   this guide says so.
> - **Be sure of the plant.** Foxglove leaves have been mistaken for comfrey, with deaths
>   ([Medical guide](guide:Medical-READ-ME-FIRST#medicinal-plants-go-carefully)). Photograph it with the
>   [plant identifier](guide:PLANT-ID) under Tools, then check every feature in a book.
> - **A plant's strength is not fixed.** Willow bark holds 0.5% to 10% of its active part, depending on the
>   kind of willow ([WHO vol 4, p. 312](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=320)). Start
>   at the low end of a dose and watch.
> - **Most plant doses are for adults.** Many are not for pregnancy, breastfeeding or young children: read the
>   last column of each table.
> - **Plants mix with medicines.** St John's wort lowers the blood level of warfarin, digoxin, HIV medicines
>   and others ([WHO vol 2, pp. 163–164](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=169)).
> - **Anything made at home goes by mouth or on the skin, never by injection:** "It is more dangerous to
>   inject medicine than to take it by mouth" ([WTND, p. 65](lib:where-there-is-no-doctor-09-instructions#page=1)).
> - **Real medicines first for serious infections.** For pneumonia, tetanus, typhoid, TB and fever after birth,
>   "do not lose time trying to treat them first with home remedies only"
>   ([WTND, p. 1](lib:where-there-is-no-doctor-01-home-cures#page=1)).
> - **Write down what you gave, how much, when, and what happened.**

---

## 🏅 Everything in this guide, rated

Listed from what saves the most lives.

| What | For | Rating | More |
|---|---|---|---|
| **Rehydration drink** (salt, sugar, water) | Diarrhea, cholera, big burns | ✅ | [Rehydration drink](#rehydration-drink-the-cheapest-life-saver) |
| **Lots of boiled water** to wash a wound | Stopping wound infection | ✅ | [Wound care](#wound-care-that-prevents-infection) |
| **Soap and water** | Hands, skin, dirty wounds | ✅ | [Wound care](#wound-care-that-prevents-infection) |
| **Boiled salt water** | Washing and covering wounds | ✅ | [Wound care](#wound-care-that-prevents-infection) |
| **Sugar or honey dressing** | Oozing or infected wounds; honey on burns | ✅ | [Wound care](#wound-care-that-prevents-infection) |
| **Dakin's solution** (weak bleach and baking soda) | Dirty and infected wounds | ✅ | [Wound care](#wound-care-that-prevents-infection) |
| **Hot compresses** | Infected wounds, boils | ✅ | [Wound care](#wound-care-that-prevents-infection) |
| **Pressure canner or oven** | Sterilizing tools and dressings | ✅ | [Sterilizing](#antiseptics-alcohol-and-sterilizing) |
| **Alcohol, 60–80%** | Skin before a needle; hands | ✅ on skin, ⛔ in a wound | [Alcohol](#antiseptics-alcohol-and-sterilizing) |
| **Iodine** | Skin; a single wash of a small wound | ✅ on skin, ⚠️ in a wound | [Wound care](#wound-care-that-prevents-infection) |
| **Boiling** | Tools | ⚠️ cleans, does not sterilize | [Sterilizing](#antiseptics-alcohol-and-sterilizing) |
| **Maggots** | Dead flesh in a wound, when nothing else is left | ⚠️ | [Wound care](#wound-care-that-prevents-infection) |
| **Willow bark** | Pain, fever | ⚠️ weak | [Pain and fever](#pain-and-fever) |
| **Plants proven for one use** (valerian, chamomile, garlic, ginger, St John's wort, cranberry, feverfew, echinacea) | That one use | ✅ | [Plants](#medicinal-plants-with-real-evidence) |
| **Plants with tradition only** (thyme, peppermint, elder flower, calendula, yarrow and others) | Mild complaints | ⚠️ | [Plants](#medicinal-plants-with-real-evidence) |
| **Home-made penicillin**, foxglove, ergot, comfrey or arnica by mouth, poppy | | ⛔ | [Dangerous to try](#dangerous-to-try) |
| **Anything injected** that was not made sterile | | ⛔ | [Dangerous to try](#dangerous-to-try) |

## 🧫 Why most home-made antibiotics fail

[Penicillin](wiki:Penicillin) was first found in a mould, so people try to grow their own on bread or fruit. It does not work, for four
reasons:
- **Wild moulds make very little,** and a broth or a mouldy crust holds an amount no one can measure *(rule of
  thumb)*. One adult course of penicillin is 250 to 500 mg four times a day for 10 days
  ([WTND, p. 351](lib:where-there-is-no-doctor-24-green-pages#page=13)): 10 to 20 grams of the pure drug.
- **No dose, so no cure.** Too little medicine fails, and the person is left to the infection *(rule of thumb)*.
- **Other moulds on the same food make poisons.** Aflatoxins from moulds "can cause serious illness in animals
  and humans" ([FDA *Bad Bug Book*, p. 231](lib:fda-bad-bug-book#page=231)), and penicillin itself can cause
  allergic shock ([WTND, p. 70](lib:where-there-is-no-doctor-09-instructions#page=6)).
- **Never inject it.** Germs that go in with a needle cause abscesses
  ([WTND, p. 68](lib:where-there-is-no-doctor-09-instructions#page=4)), and nothing made in a kitchen is sterile
  enough to inject *(rule of thumb)*.

Real antibiotics need a laboratory, a known strain and a way to measure and purify the drug. How that was done,
and what a community would need to do it again: [How antibiotics came to be](guide:MEDICINE-HISTORY-GUIDE).
Until then, the wound care below, and the antibiotics you have, stored well and used only when needed
([Medical guide](guide:Medical-READ-ME-FIRST#using-found-or-expired-medicines)), are what you have.

## 💧 Rehydration drink: the cheapest life-saver

"Giving lots of liquids to a child with diarrhea is more important than any medicine"
([WTND, p. 46](lib:where-there-is-no-doctor-05-healing#page=2)). The signs of drying out and how to give it are
in the [Medical guide](guide:Medical-READ-ME-FIRST#diarrhea-and-dehydration-the-homemade-drink).

| Recipe | In 1 liter of clean water | Book |
|---|---|---|
| **Sugar drink** ✅ | ½ level teaspoon of salt and **8** level teaspoons of sugar. Taste it before the sugar: "less salty than tears" | [WTND, p. 152](lib:where-there-is-no-doctor-13-some-very-common#page=2) |
| **WHO home recipe** ✅ | 0.5 level teaspoon of salt and **6** level teaspoons of sugar | [JTS burns, p. 7](lib:burn-wound-management#page=7) |
| **Cereal drink** ✅ | ½ teaspoon of salt and 8 heaping teaspoons (2 handfuls) of powdered rice or other cereal, boiled 5 to 7 minutes. It spoils in a few hours in hot weather | [WTND, p. 152](lib:where-there-is-no-doctor-13-some-very-common#page=2) |

- **The books differ on sugar: 8 or 6 level teaspoons.** Both use the same ½ teaspoon of salt.
- **How much:** sips every 5 minutes, day and night, until they pass urine as usual. "A large person needs 3 or
  more liters a day. A small child usually needs at least 1 liter a day." Keep giving it even if they vomit
  ([WTND, p. 152](lib:where-there-is-no-doctor-13-some-very-common#page=2)).
- A teaspoon is 5 ml ([WTND, p. 61](lib:where-there-is-no-doctor-08-how-to-measure#page=3)). Keep salt, sugar and
  a set of level measuring spoons with the medicines *(rule of thumb)*.
- Burns over a fifth of the body need the same drink by the clock:
  [Field Care](guide:FIELD-CARE-GUIDE#burns).

## 🩹 Wound care that prevents infection

How to stop bleeding, when to close a wound and when to leave it open, and bites:
[Field Care](guide:FIELD-CARE-GUIDE#wounds-and-infection-when-there-s-no-hospital). This section is what you
can make yourself to keep a wound clean.

### Water, soap and salt water

- ✅ **Lots of water does most of the work.** Boil it 3 minutes and cool it to body heat; 1 to 3 liters for a
  small wound, 4 to 8 for a dirty one, 9 or more for a large dirty one
  ([JTS, p. 4](lib:acute-traumatic-wound-management#page=4)).
- ✅ **Soap:** wash the skin around the wound with soap and boiled water; put soap in the wound only if it is
  very dirty: "Soap helps clean but can damage the flesh"
  ([WTND, p. 84](lib:where-there-is-no-doctor-10-first-aid#page=10)). Making soap:
  [Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#soap-from-fat-and-ashes).
- ✅ **Boiled salt water (saline):** "add 1 teaspoon of salt to 2 cups of boiled water. Only use for 24 hours"; soak
  gauze in it to cover an infected wound
  ([WWHND, p. 307](lib:where-women-have-no-doctor-17-hiv#page=26)). MSF uses only sterile salt water, not
  antiseptics, on a clean wound ([MSF, p. 656](lib:msf-essential-drugs#page=656)).
- ✅ **Hot compresses** on an infected wound, "20 minutes 4 times a day", with the part raised
  ([WTND, p. 88](lib:where-there-is-no-doctor-10-first-aid#page=14)).
- ✅ **Sterile dressings from cloth:** "Wrap it in thick paper, seal it with tape, and bake it for 20 minutes in
  an oven", with a pan of water below so it doesn't char
  ([WTND, p. 87](lib:where-there-is-no-doctor-10-first-aid#page=13)). A dirty or wet bandage is worse than none
  (same page).

### Honey and sugar dressings

✅ For a wound that oozes a lot or is infected. Honey and sugar draw water out of germs: honey's "high osmotic
potential" and the peroxide it makes when diluted stop bacteria growing
([FAO *Bees*, p. 119](lib:bees-and-their-role-in-forest-livelihoods#page=121)).
1. **Rinse** the wound with boiled salt water or the cleanest water you have.
2. **Fill** it with sugar, or spread honey over it.
3. **Cover** with a dry dressing.
4. **Repeat** every 24 hours ([JTS, pp. 11](lib:acute-traumatic-wound-management#page=11),
   [16](lib:acute-traumatic-wound-management#page=16)).

- **How often, books differ:** JTS changes it every 24 hours; WWHND cleans and redoes it "at least 2 more times
  each day", because sugar or honey that fills with liquid from the sore "will feed germs rather than kill them"
  ([WWHND, p. 306](lib:where-women-have-no-doctor-17-hiv#page=25)). Change it as soon as it turns runny.
- If it works, carry on or go back to a plain dry dressing; if not, an antiseptic wash or more cutting away of
  dead flesh ([JTS, p. 16](lib:acute-traumatic-wound-management#page=16)).
- **Burns:** "Equal parts of honey and either ghee (clarified butter), or oil" poured over gauze; the honey keeps
  germs down and the oil keeps the gauze from sticking
  ([ICRC *War Surgery*, p. 288](lib:war-surgery-working-with-limited-resources#page=291)). WTND puts a thin layer
  of honey on a burn ([p. 96](lib:where-there-is-no-doctor-10-first-aid#page=22)).
- **Never feed honey to a baby under 1 year** (infant botulism)
  ([FDA *Bad Bug Book*, p. 108](lib:fda-bad-bug-book#page=108)). Keeping bees for it:
  [Bees](guide:BEES-GUIDE#harvesting-honey-crush-strain-store).

![Four steps of a sugar or honey dressing: rinse the wound with boiled salt water from a squeeze bottle, fill it with sugar or spread honey, cover it with a dry gauze pad and bandage, and redo it every 24 hours or sooner if it turns runny](img:MAKING-MEDICINES-GUIDE/honey-sugar-dressing.svg)
*A sugar or honey dressing for a wound that oozes ([JTS, p. 16](lib:acute-traumatic-wound-management#page=16); [WWHND, p. 306](lib:where-women-have-no-doctor-17-hiv#page=25); a drawing made for this guide).*

### Dakin's solution: weak bleach for dirty wounds

✅ Weak bleach, buffered with baking soda, washes "large, very dirty, or infected wounds" and helps against
fungal infection ([JTS, p. 4](lib:acute-traumatic-wound-management#page=4)). It also helps dissolve dead
tissue ([Dakin, p. 27](lib:a-handbook-of-antiseptics#page=41)).

**The JTS recipe** ([p. 4](lib:acute-traumatic-wound-management#page=4)):
1. 1 liter of water, sterile or boiled (and cooled).
2. 5 ml (1 teaspoon) of household bleach, 5.25%, unscented.
3. ½ teaspoon of baking soda (it can be left out if you have none).
4. Mix. "Once mixed, Dakin's solution can be stored."

**Two strengths, and a muddle in the book:**
- JTS washes wounds with **0.025%** Dakin's, a strength that kills germs without harming the flesh
  ([p. 4](lib:acute-traumatic-wound-management#page=4)). Its recipe above already makes about that: 5 ml of 5.25%
  bleach in a liter is 0.026% *(arithmetic)*, though the book calls it "half-strength". The same page then says to
  dilute it 1 to 10 again, which would
  make it ten times weaker. Use the recipe as it stands for washing wounds *(rule of thumb)*.
- Dakin's own solution (1917) was **0.45 to 0.5%**: not stronger than 0.5% "or irritation of the skin may be
  frequent", not weaker than 0.4% or it works less well, and "not kept longer than one week"
  ([Dakin, p. 25](lib:a-handbook-of-antiseptics#page=39)). It works fast and is used up fast, so it was renewed
  often on a wound ([p. 27](lib:a-handbook-of-antiseptics#page=41)).

**Bleach today is stronger, and it weakens on the shelf.** Read the label. Plain bleach "can lose up to half its
strength after 6 months" ([USU *Food Storage*, p. 16](lib:food-storage-for-emergencies#page=16)). The amounts
below are the dilution rule (parts of water = bleach % ÷ % wanted − 1,
[MSF *Cholera*, p. 226](lib:management-of-a-cholera#page=226)) worked out per liter:

| Bleach strength on the label | **0.025%** (JTS: washing wounds) | **0.5%** (Dakin 1917) |
|---|---|---|
| 5.25% | 5 ml (1 teaspoon) in 1 liter | 95 ml in a liter of mix |
| 6% | 4 ml (a scant teaspoon) | 80 ml |
| 8.25% | 3 ml (a little over ½ teaspoon) | 60 ml |

- **Mix it fresh.** MSF throws away any diluted antiseptic after 24 hours
  ([MSF, p. 656](lib:msf-essential-drugs#page=656)); Dakin kept his a week at most; JTS gives no limit. Label the
  bottle with the strength and the date.
- **Don't heat it above body heat (37 °C), and never mix it with alcohol or other antiseptics**
  ([Dakin, p. 27](lib:a-handbook-of-antiseptics#page=41)), and never with ammonia or vinegar
  ([Sanitation](guide:SANITATION-GUIDE#chlorine-strengths-from-household-bleach)).
- **Never inject it:** hypochlorite breaks up blood cells and "should not be injected intravenously"
  ([Dakin, p. 27](lib:a-handbook-of-antiseptics#page=41)).
- It eats metal: not for sterilizing instruments ([Dakin, p. 22](lib:a-handbook-of-antiseptics#page=36)).
- Stronger bleach mixes for floors, laundry and the sickroom:
  [Sanitation](guide:SANITATION-GUIDE#chlorine-strengths-from-household-bleach).

![Making Dakin's solution: a liter jug of boiled, cooled water, a teaspoon of plain unscented bleach and half a teaspoon of baking soda, poured into a labelled bottle with the date; below, a table of how much bleach of each strength makes the 0.025 percent wash and the 0.5 percent solution](img:MAKING-MEDICINES-GUIDE/dakins-solution.svg)
*The JTS recipe for washing wounds, and the amounts for other bleach strengths ([JTS, p. 4](lib:acute-traumatic-wound-management#page=4); [Dakin, p. 25](lib:a-handbook-of-antiseptics#page=39); a drawing made for this guide).*

### Iodine and maggots

- **Iodine** ✅ on skin, ⚠️ in a wound. A 2.5% solution in 70% alcohol is enough for skin
  ([Dakin, p. 70](lib:a-handbook-of-antiseptics#page=84)); MSF uses 10% povidone-iodine on skin and broken skin
  ([MSF, p. 655](lib:msf-essential-drugs#page=655)). On a wound it is best as one quick application: repeated, it
  was "much too irritating" ([Dakin, p. 70](lib:a-handbook-of-antiseptics#page=84)). WTND: "NEVER put alcohol,
  tincture of iodine, or Merthiolate directly into a wound"
  ([p. 84](lib:where-there-is-no-doctor-10-first-aid#page=10)).
- **Maggots** ⚠️, when a wound is badly infected, does not heal, there are no antibiotics and the dead flesh
  can't be cut away: the Army manual's steps are to expose the wound to flies for one day, cover it, check daily,
  and flush every maggot out with sterile water "when they have cleaned out all dead tissue and before they start
  on healthy tissue". "Increased pain and bright red blood in the wound" mean they have reached healthy flesh
  ([FM 21-76, pp. 40–41](lib:fm-21-76-army-survival-manual#page=40)). The Special Forces handbook keeps only
  50 to 100 in the wound and keeps flies off the wound itself, letting them lay only on the skin at its edge
  ([ST 31-91B, p. 177](lib:special-forces-medical-handbook-st-31-91b-1982#page=177)). Flies carry germs: it is a
  last resort ([p. 177](lib:special-forces-medical-handbook-st-31-91b-1982#page=177)). Hospitals use maggots
  bred clean for the purpose *(rule of thumb)*; [Maggot therapy](wiki:Maggot_therapy).

## 🧴 Antiseptics, alcohol and sterilizing

### Alcohol: the strength that works

- ✅ **60 to 80% alcohol** kills germs best; it is for unbroken skin, "not ... on mucous membranes or broken
  skin" ([MSF, p. 654](lib:msf-essential-drugs#page=654)). Let it dry before the needle goes in
  ([p. 656](lib:msf-essential-drugs#page=656)). Hand rub needs at least 60%
  ([Make-Do](guide:MAKE-DO-HOUSEHOLD-GUIDE#cleaning-and-disinfecting)).
- In 1917 most germs died "fairly readily" in 50% alcohol, much weaker or stronger worked less well, "while most
  spores are unaffected by alcohol of any strength" ([Dakin, p. 72](lib:a-handbook-of-antiseptics#page=86)).
- **Proof is twice the percent:** 190 proof still holds at least 5% water
  ([USDA *Fuel Alcohol*, p. 23](lib:usda-small-scale-fuel-alcohol#page=23)). So 80-proof whiskey or vodka is 40%,
  too weak; 150 to 160 proof is right *(arithmetic)*.
- **Making it:** in the US you need a federal permit before you distill any alcohol, whether to drink, to sell or
  for fuel; the book names experimental and commercial permits for fuel alcohol
  ([USDA *Fuel Alcohol*, p. IV-2](lib:usda-small-scale-fuel-alcohol#page=90)). Today the permits come from the
  TTB, which still issues one for fuel alcohol *(rule of thumb)*.
  Fuel alcohol is denatured "to render it unfit for human consumption"
  ([DOE *E85 Handbook*, p. 9](lib:handbook-for-handling-storing-and-dispensing-e85#page=9)): never drink it or
  give it as medicine. How a still works: [Fuel](guide:FUEL-GUIDE#when-the-stored-fuel-runs-out).

### Soap, boiling and an oven

- ✅ **Soap and scrubbing come first:** tools are scrubbed with soap and water before any sterilizing
  ([JTS, p. 17](lib:acute-traumatic-wound-management#page=17)).
- ⚠️ **Boiling cleans but does not sterilize:** boiling water does "not sterilize instruments"
  ([WHO *Decontamination*, p. 114](lib:decontamination-and-reprocessing#page=115)). WTND boils a needle and
  thread 20 minutes to stitch a cut ([p. 86](lib:where-there-is-no-doctor-10-first-aid#page=12)): better than
  nothing.
- ✅ **Dry heat in an oven:** 180 °C (356 °F) for 30 minutes, 170 °C (338 °F) 1 hour, 160 °C (320 °F) 2 hours;
  wrap tools in foil and let them cool in the oven
  ([JTS, p. 18](lib:acute-traumatic-wound-management#page=18)).

### A pressure canner as a sterilizer

✅ Steam under pressure is "the preferred sterilization technique"
([JTS, p. 17](lib:acute-traumatic-wound-management#page=17)). Steam sterilizes at 121 °C (250 °F) in 30 minutes;
in a pressure cooker of unknown temperature, JTS gives **60 minutes**, with the tools on a wire rack so "only
steam" touches them ([pp. 17–18](lib:acute-traumatic-wound-management#page=17)).
1. **Scrub** the tools with soap and water. Wrap them, or the dressings, in cloth or paper *(rule of thumb)*.
2. **Water below the rack:** JTS's field sterilizer uses ¾ to 1 inch of water
   ([p. 17](lib:acute-traumatic-wound-management#page=17)). For a full hour put in more, and raise the rack so
   nothing sits in the water *(rule of thumb)*.
3. **Vent** steam for 10 minutes before closing the vent: trapped air lowers the heat
   ([USDA canning guide, p. 1-20](lib:usda-complete-guide-to-home-canning-2015-guide-1#page=20)).
4. **Put the weight on and keep the pressure 60 minutes.** JTS starts the hour when steam first vents; counting
   from full pressure is the safer reading *(rule of thumb)*. A canner at 10.5 pounds is at 240 °F at sea level
   ([USDA, p. 1-19](lib:usda-complete-guide-to-home-canning-2015-guide-1#page=19)); use the 15-pound weight to reach
   about 250 °F *(rule of thumb)*. Here, at about 1,300 feet, a canner already runs a little cooler than at sea level
   ([PNW 421, p. 12](lib:using-and-caring-for-your-pressure-canner#page=12)): use the 15-pound weight, never less,
   for the full 60 minutes *(rule of thumb)*.
5. **Cool** it off the heat, open it, and keep the packs wrapped until used *(rule of thumb)*.

A canner kept for this, and dressings sterilized ahead in sealed packs, are worth having now
([Field Care](guide:FIELD-CARE-GUIDE#wounds-and-infection-when-there-s-no-hospital)).

![A pressure canner cut open to show about an inch of water in the bottom, a raised rack above it, and cloth-wrapped tools and dressings sitting on the rack in steam; the weight on the vent shows 15 pounds; beside it the steps: scrub, wrap, vent 10 minutes, weight on, hold 60 minutes, cool](img:MAKING-MEDICINES-GUIDE/pressure-canner-sterilizer.svg)
*Tools on a rack in steam, not in the water ([JTS, pp. 17–18](lib:acute-traumatic-wound-management#page=17); [USDA, p. 1-20](lib:usda-complete-guide-to-home-canning-2015-guide-1#page=20); a drawing made for this guide).*

## 🌡️ Pain and fever

**Without medicine first:** for a high fever take off the covers and clothing
([WTND, p. 8](lib:where-there-is-no-doctor-01-home-cures#page=8)) and soak the body with water; for a sprain,
cold water the first day and hot soaks after; hot compresses for stiff, sore muscles and joints
([WTND, pp. 47–48](lib:where-there-is-no-doctor-05-healing#page=3)). Drink plenty, and rest.

### Willow bark ⚠️

"Is it true that tea made from willow bark will help bring fever down and stop pain? True. It helps"
([WTND, p. 8](lib:where-there-is-no-doctor-01-home-cures#page=8)). The WHO monograph lists clinical evidence for
"fever and pain, and ... mild rheumatic conditions"
([vol 4, p. 312](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=320)).

| | What the books give |
|---|---|
| **Dose (adult)** | "6–12 g of powdered drug material as a decoction (corresponding to 120–240 mg of total salicin) in two divided doses" a day ([WHO vol 4, p. 320](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=328)). The Air Force handbook boils "eight to ten six-inch stalks in two cups of water until water turns into tea" ([AFH 10-644, p. 51](lib:afh-10-644#page=59)), with no weight |
| **Strength** | Salicin, the aspirin-like part, runs from 0.5–1% in white willow to 2–10% in crack willow ([WHO vol 4, p. 312](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=320)). No book gives it for the willows growing near you |
| **How strong** | 240 mg of salicin gave the blood about as much salicylate as 87 mg of aspirin ([WHO vol 4, p. 318](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=326)). In one trial in rheumatoid arthritis it did no better than a dummy pill (same page) |
| **Don't use if** | Allergic to aspirin, or asthma from it; pregnant or breastfeeding; bleeding problems; under 12, because of Reye's syndrome ([WHO vol 4, pp. 318–319](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=326)); on blood thinners ([p. 319](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=327)) |

So willow takes the edge off a fever or an aching joint; it does not replace a stored bottle of aspirin,
paracetamol or ibuprofen (doses: [Chronic illness](guide:CHRONIC-ILLNESS-GUIDE#comfort-and-pain-medicines)).
The monograph's bark is from young branches ([WHO vol 4, p. 309](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=317)).

### Other pain helpers

| What | Rating | What the books say |
|---|---|---|
| **Feverfew** to prevent migraine | ✅ | Clinical evidence for "Prevention of migraine" ([WHO vol 2, p. 320](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=326)). The dose is given only as 0.2–0.6 mg of parthenolide a day ([p. 325](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=331)), which can't be measured at home: no book gives a number of leaves. Not in pregnancy ([p. 324](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=330)); mouth ulcers mean stop ([p. 325](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=331)) |
| **Peppermint oil** rubbed on for a headache | ✅ | Clinical evidence "Externally for treatment of myalgia and headache", as 5–20% oil in a cream or oil ([WHO vol 2, pp. 190](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=196), [195](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=201)). Never on a baby's or small child's face ([p. 194](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=200)) |
| **Oil of cloves** for tooth pain | ⚠️ | Dentists soak a bit of cotton in it, "damp but not wet", for a painful socket ([*Where There Is No Dentist*, p. 117](lib:where-there-is-no-dentist#page=127)). WHO lists toothache under tradition, not trials ([vol 2, p. 48](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=54)) |
| **Arnica** on bruises and sprains | ⚠️ outside, ⛔ by mouth | Outside only, never on broken skin; "A fatal case of poisoning following the ingestion of 70.0 g of a tincture" ([WHO vol 3, p. 83](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=91)) |

### Opioids: no ⛔

Poppy and opium preparations are illegal to make in the US, and no one can know their strength at home *(rule of
thumb)*. With all of them, from opium to morphine, "Respiratory depression is the most dangerous and can be
fatal" ([Ship's Medicine Chest, p. 113](lib:ships-medicine-chest#page=113)). This guide gives no way to make
them. Morphine from a pharmacy, and its doses: [Chronic illness](guide:CHRONIC-ILLNESS-GUIDE#comfort-and-pain-medicines).

## 🌿 Medicinal plants with real evidence
<!-- fold: The few plants proven for one use, the many with tradition only, their doses and who must not take them -->

The WHO monographs sort each plant's uses three ways: "supported by clinical data" (trials in people),
"described in pharmacopoeias" (official books of medicines) and "folk medicine, not supported by experimental
or clinical data" ([vol 1, pp. 89–90](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=96)). Here ✅ means
trials in people; ⚠️ means only pharmacopoeias or tradition. These plants grow, or can be grown, in a temperate
climate like the Illinois Valley's; ginger is from the pantry. Doses are for adults unless a column says otherwise; how to
make the teas: [below](#teas-tinctures-salves-and-poultices).

**Proven for one use (✅ for that use only)**

| Plant (part) | Proven for | Dose the WHO monograph gives | Don't use if |
|---|---|---|---|
| **Valerian** (root) | Sleep and nervous unrest: "a mild sedative and sleep-promoting agent" ([vol 1, p. 272](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=279)) | "2–3 g drug per cup by oral infusion, 1–5 times per day, up to a total of 10 g" ([p. 275](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=282)) | Pregnant or breastfeeding ([p. 273](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=280)). Long use: headaches, unease, poor sleep ([p. 274](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=281)) |
| **Chamomile** (flowers) | Upset stomach, bloating, gas; restlessness and mild sleeplessness; outside, sore skin, mouth and gums ([vol 1, p. 89](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=96)) | Adult: "average daily dose 2–8 g, 3 times a day"; child: "2 g, 3 times daily"; gargles and compresses a 3–10% infusion ([p. 92](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=99)) | Children under 3 (same page); allergy to ragweed, asters or chrysanthemums ([p. 91](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=98)) |
| **Garlic** (bulb) | High cholesterol, with diet; maybe mild high blood pressure ([vol 1, p. 20](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=27)). Infections only in pharmacopoeias (⚠️). WTND for pinworms: 4 crushed cloves in a glass of water, juice or milk, daily for 3 weeks ([p. 12](lib:where-there-is-no-doctor-01-home-cures#page=12)) | Fresh garlic 2–5 g a day, with food ([p. 26](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=33)) | Large amounts raise bleeding after surgery ([p. 25](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=32)) |
| **Ginger** (root, from the pantry) | Preventing nausea and vomiting: travel sickness, after surgery, in pregnancy ([vol 1, p. 281](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=288)) | Travel sickness, adults and children over 6: "0.5 g, 2–4 times daily"; indigestion 2–4 g a day ([p. 285](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=292)) | None listed ([p. 283](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=290)) |
| **St John's wort** (flowering tops) | "mild and moderate depressive episodes" ([vol 2, p. 153](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=159)) | "2–4 g crude drug" a day ([p. 165](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=171)). It takes 2–4 weeks to work; no better after 6 weeks, stop and seek help ([p. 163](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=169)) | **With other medicines:** it lowers the level of warfarin, digoxin, theophylline, cyclosporin and HIV medicines, and with antidepressants such as fluoxetine causes serotonin excess ([pp. 163–164](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=169)); it may make the birth-control pill fail *(rule of thumb)*. Stay out of strong sun ([p. 163](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=169)) |
| **Cranberry** (fruit, juice) | Preventing bladder infections in adults; trials in children were negative ([vol 4, p. 153](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=161)) | Prevention: "30–300 ml of a 30% pure juice product" a day; treatment 360–960 ml ([p. 163](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=171)) | Children; kidney stones or weak kidneys only with advice ([p. 162](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=170)) |
| **Feverfew** (leaves) | Preventing migraine ([vol 2, p. 320](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=326)) | Given only as parthenolide (see [Other pain helpers](#pain-and-fever)) | Pregnancy; allergy to the daisy family ([p. 324](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=330)) |
| **Echinacea** (root, or the flowering plant of *E. purpurea*) | "supportive therapy for colds and infections of the respiratory and urinary tract" ([vol 1, p. 131](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=138)): a help, not a cure | Root: about 1 g (½ teaspoon) powdered, 150 ml hot water poured over, steeped 10 minutes, three times a day ([p. 133](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=140)). *E. purpurea* juice: 6–9 ml a day for no longer than 8 weeks ([p. 142](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=149)) | TB, HIV, autoimmune illness; allergy to the daisy family ([p. 132](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=139)) |
| **Cascara** (aged bark) | "Short-term treatment of occasional constipation" ([vol 2, p. 262](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=268)) | "0.3–1.0 g crude drug in a single dose", at bedtime ([p. 266](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=272)). **Books differ:** WTND calls cascara one of the "irritating purges that often do more harm than good" ([p. 16](lib:where-there-is-no-doctor-01-home-cures#page=16)); try water and fiber first | Fresh bark "may cause severe vomiting" ([p. 266](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=272)). Not under 10, in pregnancy or breastfeeding, with belly pain or vomiting, or for over 2 weeks ([pp. 263–264](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=269)) |

**Tradition and pharmacopoeias only (⚠️: may help, no trials)**

| Plant (part) | Used for | Dose the WHO monograph gives | Don't use if |
|---|---|---|---|
| **Thyme** (leaves and flowers) | Coughs, bronchitis; gargle for sore throat ([vol 1, p. 262](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=269)) | "1–2 g of the dried herb ... as an oral infusion several times a day", adults and children from 1 year; under 1 year 0.5–1 g; gargle: a 5% infusion ([p. 264](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=271)) | Pregnant or breastfeeding ([p. 263](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=270)) |
| **Peppermint** (leaves) | Indigestion, gas, colic ([vol 2, p. 202](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=208)) | "pour 150 ml hot water over 1.5–3.0 g (one tablespoon) dried leaves, steep for 10 minutes", three times a day between meals ([p. 204](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=210)) | Gallstones; pregnancy, breastfeeding or children, unless with medical advice ([p. 203](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=209)) |
| **Lemon balm** (leaves) | Sleep and stomach (tradition); a cream of it is proven for cold sores ([vol 2, p. 183](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=189)) | "1.5–4.5 g crude drug per cup several times daily" ([p. 186](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=192)) | By mouth: pregnancy, breastfeeding or children, unless with medical advice ([p. 185](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=191)) |
| **Elder** (flowers) | Fever and chills, colds ([vol 2, p. 272](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=278)) | "3–5 g as an infusion (preferably taken hot) three times daily" ([p. 274](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=280)) | Pregnancy, breastfeeding or children, unless with medical advice ([p. 273](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=279)) |
| **Calendula, pot marigold** (flowers), outside | Small cuts, sore skin and mouth, leg ulcers ([vol 2, p. 39](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=45)) | Compress: "1–2 g/150 ml" infusion; ointment 2–5% ([p. 42](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=48)) | Allergy to the daisy family ([p. 41](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=47)) |
| **Yarrow** (flowering tops) | Poor appetite, colds, upset stomach, fever; outside, skin ([vol 4, p. 183](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=191)). The Army manual uses its leaves on a cut to stop bleeding ([FM 21-76, p. 128](lib:fm-21-76-army-survival-manual#page=128)) | "1–2 g in 150 ml boiled water for 10–15 minutes, three times daily between meals" ([p. 188](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=196)) | Pregnancy, stomach ulcers, gallbladder disease, daisy-family allergy ([p. 187](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=195)) |
| **Bearberry, uva-ursi** (leaves) | A mild bladder antiseptic ([vol 2, p. 345](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=351)) | "3 g crude drug in 150 ml water as an infusion or cold macerate, up to three or four times daily"; drink plenty ([p. 349](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=355)) | Pregnancy, breastfeeding, under 12, kidney disease; not for long ([p. 347](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=353)) |
| **Hops** (cones) | Nervous tension, sleeplessness ([vol 3, p. 240](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=248)) | "0.5 g in 150 ml of water" a dose ([p. 243](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=251)) | Allergy to it; makes you drowsy ([p. 242](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=250)) |
| **Lavender** (flowers) | Restlessness, sleeplessness, nervous stomach ([vol 3, p. 232](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=240)) | "1–2 teaspoonfuls per cup, three times per day" ([p. 234](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=242)) | Pregnancy ([p. 233](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=241)) |
| **Dandelion** (whole plant) | Passing water, appetite, indigestion; no clinical information ([vol 3, p. 331](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=339)) | "boil 3–4 g of whole plant in 150 ml of water", three times a day ([p. 335](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=343)) | Blocked bile duct or bowel, gallbladder attack ([p. 334](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=342)) |
| **Aloe** (gel from inside the leaf), outside | Minor burns and wounds ([vol 1, p. 45](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=52); [WTND, p. 13](lib:where-there-is-no-doctor-01-home-cures#page=13)); a houseplant in cold country | "Fresh gel" ([p. 48](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=55)) | Allergy to the lily family ([p. 47](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=54)) |

**Wild plants of this region with medicinal uses.** The USFS guide covers the Pacific Northwest; the county's soil
survey finds willows and Oregon grape in Josephine County itself:

| Plant | Where it grows here | Notes |
|---|---|---|
| **Willows** | Wet ground: drainageways and alluvial fans, with sedges and grasses ([Josephine soil survey, p. 66](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=66)) | No book gives the strength of the local kinds; the WHO figures are for European willows |
| **St John's wort, "Klamath weed"** | Sunny roadsides, pastures and old fields ([USFS *Special Forest Products*, p. 81](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=81)); "an aggressive weed" of dry, gravelly soils ([AIB 415, p. 101](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=101)) | Pick the top of the flowering stems, June to early August (USFS, p. 81). It poisons stock (AIB 415, p. 100) |
| **Yarrow** | Open forest, dry meadows and roadsides ([USFS, p. 27](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=27)) | "May cause dermatitis; not recommended for use during pregnancy" (same page) |
| **Cascara** | Lower mountain slopes and forest edges ([USFS, p. 73](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=73)) | The bark is taken mid-April to the end of August; the stump resprouts (same page). Fresh bark makes people vomit ([WHO vol 2, p. 266](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=272)): let it age before use *(rule of thumb)* |
| **Bearberry, kinnikinnick** | Dry, rocky slopes, after fire ([USFS, p. 37](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=37)) | Slow to grow back: take a little from the edge of a patch (same page) |
| **Blue elderberry** | Open hillsides, roadsides and fence rows ([USFS, p. 111](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=111)) | The flowers make the WHO's tea. The berries only cooked: "All varieties of raw elderberries should be cooked before consuming" ([OSU EM 9446, p. 4](lib:osu-play-it-safe-when-preserving-elderberries#page=4)) |
| **Tall Oregon grape** | Douglas-fir and madrone forest on granite soils ([Josephine soil survey, p. 100](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=100)) | Its roots are sold for medicine ([USFS, p. 45](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=45)). Its cousin barberry has no trials in people ([WHO vol 4, p. 33](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=41)) ⚠️ |
| **Wild valerians** | Moist mountain meadows and streambanks ([USFS, p. 129](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=129)) | The WHO evidence is for garden valerian, not these; grow that instead |
| **Arnica** | Shaded high meadows and conifer forest ([USFS, p. 39](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=39)) | Outside only |

Grow the proven ones (valerian, chamomile, feverfew, garlic) from seed in a garden bed, where you are sure what
they are *(rule of thumb)*.

📚 **Go deeper:** [WHO monographs Vol 1](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=4) — and Vols [2](lib:who-monographs-on-selected-medicinal-plants-vol-2), [3](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=5) and [4](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=5): every plant's evidence, doses and warnings, with an index of all four in Vol 4 ([p. 395](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=403)); [WTND, pp. 12–13](lib:where-there-is-no-doctor-01-home-cures#page=12) — useful plants and how to judge a home remedy.

## 🫖 Teas, tinctures, salves and poultices
<!-- fold: How to make each, why the dose changes from plant to plant, and keeping dried herbs -->

**The kinds** ([FM 21-76, p. 127](lib:fm-21-76-army-survival-manual#page=127)):
- **Tea (infusion):** hot water poured over the herb, left to steep, covered or not. Most of the WHO doses
  above are teas: so many grams in a cup of 150 ml.
- **Decoction:** the herb boiled or simmered, for roots and bark. "The average ratio is about 28 to 56 grams (1
  to 2 ounces) of herb to 0.5 liter of water" (same page). Where the tables give a dose, use that instead: the WHO
  dose of willow bark is 6–12 g a day *(rule of thumb)*.
- **Poultice:** crushed leaves or other parts, perhaps heated, laid on a wound or sore, directly or in cloth.
- **Expressed juice:** squeezed from the fresh plant.
- **Tincture:** the herb soaked in alcohol. A WHO "1:5, 70% ethanol" tincture is 1 part herb to 5 parts of 70%
  alcohol ([vol 1, p. 275](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=282)). The old method:
  "macerate for 7 days, press and filter" ([Lee's, p. 46](lib:lees-priceless-recipes#page=46)). The WHO
  monographs give each plant's tincture dose in ml.
- **Salve:** melt clean beeswax with oil, "One cup of beeswax should be mixed with three cups of the oil"; more
  oil makes it softer ([FAO *Bees*, p. 128](lib:bees-and-their-role-in-forest-livelihoods#page=129)). The Army
  manual mixes plant juice into animal fat or vegetable oil
  ([FM 21-76, p. 128](lib:fm-21-76-army-survival-manual#page=128)). Calendula ointment is 2–5% of the plant
  ([WHO vol 2, p. 42](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=48)).

**Weigh it.** The WHO doses are in grams. A small kitchen or postal scale is worth more than any guess by the
spoonful *(rule of thumb)*.

**Why the dose changes from plant to plant:**
- **The kind:** white willow bark has 0.5–1% salicin, crack willow 2–10%
  ([WHO vol 4, p. 312](lib:who-monographs-on-selected-medicinal-plants-vol-4#page=320)).
- **The handling:** fresh garlic held 0.25–1.15% of its active part, carefully dried garlic 0.7–1.7%
  ([WHO vol 1, p. 20](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=27)).
- **Fresh or aged:** fresh cascara bark makes people vomit
  ([WHO vol 2, p. 266](lib:who-monographs-on-selected-medicinal-plants-vol-2#page=272)).
- So a herb's strength is never certain, which is why "it is often safer to use modern medicine, since the dosage
  is easier to control" ([WTND, p. 12](lib:where-there-is-no-doctor-01-home-cures#page=12)).

**Drying and keeping herbs:** valerian root is "carefully dried at a temperature below 40 °C"
([WHO vol 1, p. 267](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=274)). Store dried herbs like
ginger: "in well-closed containers (not plastic) which prevent access of moisture", "protected from light in a
cool, dry place" ([p. 281](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=288)). Label each jar with
the plant, the part and the date, and pick again each year *(rule of thumb)*.

## ⛔ Dangerous to try

| Don't | Why |
|---|---|
| **Mould "penicillin"**, by mouth or injected | No dose, other moulds' poisons, allergic shock ([above](#why-most-home-made-antibiotics-fail)) |
| **Foxglove** (digitalis) for the heart | Its heart poisons stay "active in the fresh, dried, or even boiled plant" ([WSU *Poisonous Plants*, p. 28](lib:wsu-selected-poisonous-plants#page=28)). Its medicine, digoxin, is kept at 0.8–2 micrograms per liter of blood, checked by a laboratory, and poisoning becomes likely from 1.5 to 3 ([WHO *Formulary for Children*, p. 336](lib:who-model-formulary-for-children#page=336)): a margin no leaf can be measured to |
| **Ergot** (the dark fungus on rye and grasses) | Ergot in hay poisons animals: a cow loses the skin and flesh in a ring round the lower leg, down to the bone ([USDA *Diseases of Cattle*, p. 50](lib:usda-special-report-on-diseases-of-cattle#page=64)). The medicine made from it, ergometrine, "Used the wrong way before the baby is born, they can cause the death of the mother or the child in her womb" ([WTND, p. 266](lib:where-there-is-no-doctor-19-information-for-mothers#page=22)). Never eat grain with ergot in it |
| **Comfrey** by mouth (tea, syrup, leaves) | It harms the liver; death "may ensue from 2 weeks to more than 2 years after poisoning", and in 2001 the FDA told makers to take comfrey products meant to be swallowed off the market ([FDA *Bad Bug Book*, p. 243](lib:fda-bad-bug-book#page=243)) |
| **Arnica** by mouth | A death from 70 g of tincture ([WHO vol 3, p. 83](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=91)) |
| **Angel's trumpet, jimsonweed** and other poisonous nightshades | WTND gives drops of angel's trumpet for cramps but warns it "is very poisonous if you take more than the recommended dose" ([p. 12](lib:where-there-is-no-doctor-01-home-cures#page=12)); of jimsonweed "all parts of the plant are toxic" ([WSU, p. 30](lib:wsu-selected-poisonous-plants#page=30)). A home soak's strength can't be known *(rule of thumb)* |
| **Poppy and opium** | Illegal, and no way to know the dose; overdose stops the breathing ([Ship's, p. 113](lib:ships-medicine-chest#page=113)) |
| **Anything injected that was not made sterile** | Abscess, fever, allergic shock ([WTND, pp. 68–70](lib:where-there-is-no-doctor-09-instructions#page=4)); bleach in a vein destroys blood ([Dakin, p. 27](lib:a-handbook-of-antiseptics#page=41)) |
| **Alcohol, iodine tincture or strong bleach poured into a wound** | Alcohol and tincture of iodine "damage the flesh and make healing slower" ([WTND, p. 84](lib:where-there-is-no-doctor-10-first-aid#page=10)); Dakin kept his bleach at 0.5% or weaker, because stronger irritates ([p. 25](lib:a-handbook-of-antiseptics#page=39)) |

**The deadly ones here:**
- **Foxglove** is "a common garden flower and sometimes a wild escapee"
  ([WSU, p. 28](lib:wsu-selected-poisonous-plants#page=28)); its leaves have been mistaken for comfrey
  ([Medical guide](guide:Medical-READ-ME-FIRST#medicinal-plants-go-carefully)).
- **Western waterhemlock** grows "in wet places along streams, irrigation ditches, and sloughs", the same places as
  willows; it "is the most poisonous plant in North America"
  ([PNW 109, p. 1](lib:pnw-western-waterhemlock#page=1)). Never use a wild carrot-family plant (angelica, lovage,
  wild parsnip) as medicine *(rule of thumb)*.
- **Pacific yew** grows in moist old forest and canyon bottoms; its bark is harvested for medicine
  ([USFS, p. 115](lib:usfs-special-forest-products-species-guide-for-the-pacific-northwest-pnw-gtr-513#page=115)),
  but yew poisoning can kill so fast "that signs of poisoning may not have time to develop", and "Survival is
  rare" ([AIB 415, p. 113](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=113)).
  Never make a tea of any yew *(rule of thumb)*.
- **Tansy ragwort** "infests woodlands, pastures, and hayfields of the coastal northwest" and carries the same
  kind of liver poison as comfrey (pyrrolizidine alkaloids); animals die months after eating it
  ([AIB 415, pp. 105–106](lib:usda-ars-plants-poisonous-to-livestock-in-the-western-states-aib-415#page=105)). Never
  use it as a medicine *(rule of thumb)*.

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Rinse a wound with "fresh urine if water is not available" ([FM 21-76, p. 40](lib:fm-21-76-army-survival-manual#page=40)); urine "may well be the most nearly sterile of all fluids" ([AFH 10-644, p. 51](lib:afh-10-644#page=59)) | The cleanest water you have, boiled 3 minutes and cooled ([JTS, p. 4](lib:acute-traumatic-wound-management#page=4)) |
| For worms: "Kerosene. Drink 2 tablespoons", or "Eat 1 to 1 1/2 cigarettes" ([ST 31-91B, p. 177](lib:special-forces-medical-handbook-st-31-91b-1982#page=177)) | Never drink fuel or eat tobacco *(rule of thumb)*. Worm medicines and their doses: [WTND, p. 375](lib:where-there-is-no-doctor-24-green-pages#page=37); for pinworms, garlic may help ([WTND, p. 12](lib:where-there-is-no-doctor-01-home-cures#page=12)) |
| For diarrhea, eat "white clay or campfire ashes" ([FM 21-76, p. 128](lib:fm-21-76-army-survival-manual#page=128)), or powdered chalk, charcoal or dried bones ([ST 31-91B, p. 176](lib:special-forces-medical-handbook-st-31-91b-1982#page=176)) | The rehydration drink: "if enough liquid is given, no medicine is usually needed" ([WTND, p. 46](lib:where-there-is-no-doctor-05-healing#page=2)) |
| "Fuller's Cough Syrup": comfrey root and plantain juice boiled with sugar, "1 to 2 tablespoonsful 3 or 4 times per day" ([Lee's, p. 44](lib:lees-priceless-recipes#page=44)) | No comfrey by mouth ([FDA *Bad Bug Book*, p. 243](lib:fda-bad-bug-book#page=243)). For a cough, a thyme tea ([WHO vol 1, p. 264](lib:who-monographs-on-selected-medicinal-plants-vol-1#page=271)) |
| Arnica tincture by mouth, "10 to 30 drops", "in diarrhoea, dysentery, gout" ([Lee's, p. 46](lib:lees-priceless-recipes#page=46)) | "Internal use of Flos Arnicae ... is not recommended. For external use only" ([WHO vol 3, p. 83](lib:who-monographs-on-selected-medicinal-plants-vol-3#page=91)) |
| For toothache, a paste of opium, henbane and belladonna, or carbolic acid in the tooth ([*Household Discoveries*, p. 503](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=503)) | Oil of cloves on cotton ([*Where There Is No Dentist*, p. 117](lib:where-there-is-no-dentist#page=127)), and aspirin or paracetamol |
| Ointments of mercury, lead plaster or "red precipitate" (a mercury salt) for skin trouble ([Henley's, p. 488](lib:henleys-twentieth-century#page=488); [Lee's, p. 55](lib:lees-priceless-recipes#page=55)) | Soap and water; keep the skin clean, dry and in the sun ([FM 21-76, p. 41](lib:fm-21-76-army-survival-manual#page=41)) |
| "Honey can be regarded as a good food for both infants and adults" ([USDA AH 335 (1980), p. 88](lib:beekeeping-in-the-united-states#page=94)) | "Children under 1 year old should never be fed honey" ([FDA *Bad Bug Book*, p. 108](lib:fda-bad-bug-book#page=108)) |
| Dakin's solution "can be stored", diluted once more 1 to 10 ([JTS, p. 4](lib:acute-traumatic-wound-management#page=4)) | Make it fresh, at the strength in the table above ([Dakin's solution](#wound-care-that-prevents-infection)) |

## 📦 Making a supply last and storing medicines
<!-- fold: Stretching the real medicines you have, old and found medicines, and what to stock now -->

- **Stretching a supply, stepping down and the tablets never to split:**
  [Chronic illness](guide:CHRONIC-ILLNESS-GUIDE#making-a-supply-last).
- **Found and expired medicines, and keeping them cool and dry:**
  [Medical guide](guide:Medical-READ-ME-FIRST#using-found-or-expired-medicines).
- **Save antibiotics for what needs them.** Colds and flu get better by themselves
  ([WTND, p. 45](lib:where-there-is-no-doctor-05-healing#page=1)), and most diarrhea needs only the drink
  ([p. 46](lib:where-there-is-no-doctor-05-healing#page=2)); the illnesses that need real medicine are listed in
  [WTND, p. 1](lib:where-there-is-no-doctor-01-home-cures#page=1).
- **Stock the things this guide is made from** *(rule of thumb)*: salt, sugar and baking soda; plain unscented
  bleach, bought fresh and rotated ([USU, p. 16](lib:food-storage-for-emergencies#page=16)); honey; soap;
  strong alcohol for skin; gauze and cloth; a pressure canner kept for sterilizing; a kitchen scale; seeds of the
  proven plants; and the medicines themselves while they can be bought
  ([WTND kit list](lib:where-there-is-no-doctor-23-the-medicine-kit#page=2)).
- **Grow the proven plants** in a bed by the house, where you are sure what they are *(rule of thumb)*.

## 🖼️ Pictures & diagrams

🖼️ = drawings in the books on this drive; the plain links open photos in the offline Wikipedia.

- **Rehydration drink:** mixing it — [🖼️ WTND, p. 152](lib:where-there-is-no-doctor-13-some-very-common#page=2); [Oral rehydration therapy](wiki:Oral_rehydration_therapy)
- **Wounds:** cleaning a cut and bandages — [🖼️ WTND, pp. 84–87](lib:where-there-is-no-doctor-10-first-aid#page=10); hot compress and soaking an infected wound — [🖼️ WWHND, p. 307](lib:where-women-have-no-doctor-17-hiv#page=26); washing out a dirty wound — [🖼️ ICRC *War Surgery*, p. 215](lib:war-surgery-working-with-limited-resources#page=218); [Maggot therapy](wiki:Maggot_therapy); [Honey](wiki:Honey)
- **Sterilizing:** the field sterilizer and a pressure cooker, step by step — [JTS, pp. 17–18](lib:acute-traumatic-wound-management#page=17); a pressure canner's parts — [🖼️ PNW 421](lib:using-and-caring-for-your-pressure-canner#page=4); [Autoclave](wiki:Autoclave); [Pressure cooker](wiki:Pressure_cooker)
- **Proven plants:** [Valerian](wiki:Valerian_(herb)); [Chamomile](wiki:Matricaria_chamomilla); [Feverfew](wiki:Tanacetum_parthenium); [St John's wort](wiki:Hypericum_perforatum); [Cascara](wiki:Frangula_purshiana); [Echinacea](wiki:Echinacea_purpurea); [Willow bark](wiki:Willow); [White willow](wiki:Salix_alba)
- **Tradition plants:** [Thyme](wiki:Thymus_vulgaris); [Peppermint](wiki:Peppermint); [Lemon balm](wiki:Lemon_balm); [Elder](wiki:Sambucus); [Calendula](wiki:Calendula_officinalis); [Yarrow](wiki:Achillea_millefolium); [Bearberry](wiki:Arctostaphylos_uva-ursi); [Hops](wiki:Hops); [Lavender](wiki:Lavandula_angustifolia)
- **Dangerous plants:** foxglove — [🖼️ WSU, p. 28](lib:wsu-selected-poisonous-plants#page=28), [Foxglove](wiki:Digitalis_purpurea); jimsonweed — [🖼️ WSU, p. 30](lib:wsu-selected-poisonous-plants#page=30), [Jimsonweed](wiki:Datura_stramonium); ergot — [🖼️ USDA *Diseases of Cattle*, p. 50](lib:usda-special-report-on-diseases-of-cattle#page=64), [Ergot](wiki:Ergot); [Comfrey](wiki:Symphytum_officinale); [Arnica](wiki:Arnica_montana); [Brugmansia](wiki:Brugmansia)

## 🔗 Related guides

- [Medical books & found medicines](guide:Medical-READ-ME-FIRST) — the rehydration drink, found and expired medicines, medicinal plants to go carefully with
- [How antibiotics came to be](guide:MEDICINE-HISTORY-GUIDE) — how antibiotics, insulin and other medicines were discovered and made, for a community that wants to make them again
- [Chronic illness when the pharmacy is empty](guide:CHRONIC-ILLNESS-GUIDE) — "Making a supply last", pain medicines and their doses, daily medicines that must not stop suddenly
- [Field Care](guide:FIELD-CARE-GUIDE) — "Wounds and infection when there's no hospital", "Burns", "The kit to build now"
- [Sanitation](guide:SANITATION-GUIDE) — "Chlorine strengths from household bleach", "Handwashing and water for hygiene"
- [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — "Soap from fat and ashes", "Cleaning and disinfecting"
- [Bees](guide:BEES-GUIDE) — honey and beeswax for dressings and salves
- [Plant identifier](guide:PLANT-ID) — check a plant before you pick it
