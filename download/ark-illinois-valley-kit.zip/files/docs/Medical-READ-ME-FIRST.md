# Medical — Offline Health, First Aid & Medicines

Offline medical reference for when doctors, pharmacies and hospitals can't be reached.
**PDFs** open in Edge or any web browser; **`.zim` archives** open in **Kiwix**
(`Kiwix-Reader\`). On a laptop, the **Library Assistant**
(`AI-Offline\Library-Assistant\START-LIBRARY-ASSISTANT.bat`) searches all of it at once.

---

## What's here

| Folder | Contents |
|---|---|
| `Where There Is No Doctor\` | **Start here.** Hesperian's classic village health care handbook (2025 printing), chapter by chapter — including the **Green Pages** on medicines: uses, doses and warnings |
| `Where Women Have No Doctor\` | Women's health: pregnancy, birth, family planning, common problems |
| `A Book for Midwives\` | Pregnancy, labor, birth and newborn care, step by step |
| `Manuals-PDF\` | *Ship's Medicine Chest and Medical Aid at Sea* (care with no doctor aboard), MSF *Clinical Guidelines* (diagnosis and treatment with doses), *Emergency War Surgery* (trauma, wounds, burns), *Special Forces Medical Handbook*, *Where There Is No Dentist* |
| `Medicines\` | **Drug references:** WHO Model Formulary (adults) and for Children, MSF *Essential Drugs*, WHO essential-medicines lists, FDA notes on expired medicines and disposal |
| `Medicinal-Plants\` | WHO evidence monographs on medicinal plants, native plant uses of northern California (Chesnut 1902), USDA poisonous-plant guide |
| `Pill-Identifier\` | **`PILL-IDENTIFIER.html`** — identify a loose pill by the code printed on it (about 32,000 US pills) |
| `WikiMed\` (Kiwix) | Offline medical Wikipedia with images — an article for almost every disease, drug and procedure |
| `zimgit-medicine\` (Kiwix) | Curated offline first-aid and medical guide |

Also: the **Army first-aid and survival manuals** in `Manuals\ArmyFieldManuals\`, and the
**animal** health books in `Southern-Oregon\Animals\`.

**Which book for which problem** (WTND = *Where There Is No Doctor*):

| Problem | Open |
|---|---|
| Bleeding, wounds, burns, broken bones, heat stroke | [Injuries & Illness guide](guide:FIELD-CARE-GUIDE); [WTND — First aid](lib:where-there-is-no-doctor-10-first-aid) |
| Rattlesnake bite | [Snakebite CPG 81 (2026)](lib:snakebite-envenomation-cpg-81) — **no** band, cutting, suction or ice; [Northern Pacific rattlesnake](wiki:Crotalus_oreganus) |
| Diarrhea, dehydration, common illness | [WTND ch. 13](lib:where-there-is-no-doctor-13-some-very-common-sicknesses) |
| Fever, infection — which treatment | [MSF Clinical Guidelines](lib:msf-clinical-guidelines-diagnosis-and-treatment-manual) |
| Gunshot, crush injury, major trauma | [Emergency War Surgery](lib:emergency-war-surgery-5th-us-revision-2018) |
| Toothache, abscess | [Where There Is No Dentist, p. 103](lib:where-there-is-no-dentist#page=103) |
| Pregnancy and birth | [A Book for Midwives — labor](lib:a-book-for-midwives-11-opening-stage-1-of-labor) |
| Fear, grief, depression | [Where Women Have No Doctor ch. 27](lib:where-women-have-no-doctor-27-mental-health) |

📚 **Go deeper:** [WTND index](lib:where-there-is-no-doctor-28-index) — find any illness by name (printed page numbers); [Ship's Medicine Chest](lib:ships-medicine-chest-and-medical-aid-at-sea) — caring for a patient for days with no doctor.

---

## 🚑 The first few minutes

When someone is hurt, check in this order and act on the first problem you find
([FM 4-25.11, p. 18–19](lib:fm-4-25-11-first-aid#page=18); the newer Army order is
[MARCH — ATP 4-02.11, p. 53](lib:atp-4-02-11#page=53)):

1. **Protect yourself** — gloves or a clean plastic bag on your hands if there's blood.
2. **Responsive?** Tap and ask "Are you OK?"
3. **Breathing?** If not, open the airway and give rescue breaths
   ([🖼️ head-tilt, ATP p. 77](lib:atp-4-02-11#page=77); [🖼️ mouth-to-mouth, WTND p. 80](lib:where-there-is-no-doctor-10-first-aid#page=6)).
4. **Bleeding?** For **heavy, life-threatening bleeding from an arm or leg, put a
   [tourniquet](wiki:Tourniquet) on first** — 2–3 inches above the wound, on bare skin, tight
   until the bleeding stops (it will hurt; that means it's tight enough), and write the time on
   the person ([ATP 4-02.11 (2026), p. 62](lib:atp-4-02-11#page=62)). For other bleeding, press
   hard on the wound with a thick, clean cloth ([🖼️ WHO-ICRC, p. 169](lib:who-icrc-basic-emergency-care#page=169)), or pack the wound tightly where a tourniquet can't
   go (groin, armpit, neck — [🖼️ ATP, p. 69](lib:atp-4-02-11#page=69)). *The library's older FM 4-25.11 calls the tourniquet a "last resort" —
   that advice is out of date.* Full steps: [Injuries & Illness guide](guide:FIELD-CARE-GUIDE).
5. **[Shock](wiki:Shock_(circulatory))?** Weak, fast pulse, pale cold sweat, confusion. Lay them down with feet a
   little raised ([🖼️ ATP, p. 99](lib:atp-4-02-11#page=99)), keep warm; unconscious = on the side
   ([🖼️ ATP, p. 79](lib:atp-4-02-11#page=79); [Recovery position](wiki:Recovery_position)) and nothing by mouth;
   awake and able to swallow = sips of rehydration drink, not plain water
   ([WTND — shock](lib:where-there-is-no-doctor-10-first-aid#page=3); [Injuries & Illness guide](guide:FIELD-CARE-GUIDE)).
6. **Neck or back injury?** Don't move them unless their life is in immediate danger
   ([🖼️ how to lift without bending, WTND p. 100](lib:where-there-is-no-doctor-10-first-aid#page=26)).

*There is no 24-hour ER in the Illinois Valley* — see Local contacts in the
[Illinois Valley guide](guide:ILLINOIS-VALLEY-START-HERE).

📚 **Go deeper:** [FM 4-25.11 First Aid](lib:fm-4-25-11-first-aid#page=18) — the full casualty check; [WTND — bleeding](lib:where-there-is-no-doctor-10-first-aid#page=8) — pressure points, closing cuts.

---

## 💊 Using found or expired medicines

**1. Identify it.** US pills must carry an **imprint code**. Open
`Pill-Identifier\PILL-IDENTIFIER.html`, type the code, then check that the **color, shape
and size** also match — the same code can be two different drugs (e.g. "I2" is ibuprofen
200 mg *or* amitriptyline 25 mg depending on size; "N 4" is nitroglycerin *or* a diet pill).
No code at all = a supplement, a foreign or compounded product, or an illegal pill.

**2. Never trust street pills.** Pills that didn't come from a pharmacy can be
**[counterfeits](wiki:Counterfeit_medication) pressed with fentanyl** — fake blue "M30" oxycodone, Xanax and Adderall are
common, and many contain a deadly dose.

**3. Look it up before giving it.** In the **WHO Model Formulary** or **MSF Essential
Drugs** (`Medicines\`), read what it treats, the **dose**, who **must not** take it, and
interactions. For children, use the **WHO Formulary for Children** — children's doses go by
weight. Give the right dose, no more and no less; **finish every antibiotic course**;
antibiotics do nothing for colds
([WTND, p. 56](lib:where-there-is-no-doctor-07-antibiotics-what-they-are-and-how-to-use-them#page=2)).

**4. Expired medicines.** Most tablets and capsules kept **sealed, cool and dry** lose
potency slowly — military testing extended most stockpiled lots by years (88% of 3,005 lots,
on average by 66 months), and some drugs kept 90% strength decades past their date
([Zilker 2019, p. 54–55](lib:stability-of-medicines-beyond-expiry-dates-zilker-2019#page=55)).
That was warehouse storage, and inhalers and epinephrine often failed. But:
- **Don't rely on expired or badly stored:** **insulin** (lasts only ~28 days unrefrigerated;
  never use if it froze), **[nitroglycerin](wiki:Nitroglycerin_(medication))** tablets (lose strength once opened — keep in the
  original glass bottle; WHO: discard 8 weeks after opening,
  [p. 276](lib:who-model-formulary-2008#page=276)), **epinephrine** pens ([photo](wiki:Epinephrine_autoinjector); weaker when expired —
  but an expired pen with clear liquid is better than none in anaphylaxis), and **mixed liquid
  antibiotics** (amoxicillin suspension: 14 days in the fridge).
- **Throw out** anything discolored, crumbling, sticky or smelling odd — especially
  **tetracycline-family** antibiotics, which can damage the kidneys when degraded. Also
  caked, brownish rehydration salts, and melted creams or suppositories
  ([MSF, p. 648](lib:msf-essential-drugs-practical-guidelines#page=648)).
- **Don't raise the dose** to make up for age — MSF warns of overdose. Heart and seizure
  medicines need exact doses, so respect their dates ([p. 649](lib:msf-essential-drugs-practical-guidelines#page=649)).
- Store medicines cool and dry (not the bathroom, kitchen or a car — a vehicle can reach
  50–60 °C, [MSF, p. 647](lib:msf-essential-drugs-practical-guidelines#page=647)), in their
  original containers, out of children's reach.

**5. The biggest dangers**
- **Allergy** — face or throat swelling, trouble breathing or widespread [hives](wiki:Hives) after a
  medicine is [anaphylaxis](wiki:Anaphylaxis): give epinephrine if you have it. After *any* reaction, never use
  that medicine again ([WTND, p. 70](lib:where-there-is-no-doctor-09-instructions-and-precautions-for-injections#page=6)).
- **Acetaminophen (Tylenol)** — no more than **4,000 mg a day** for adults, *counting every
  product*; it's hidden in Norco, Vicodin, Percocet and many cold medicines. Too much causes
  liver failure ([MSF, p. 244](lib:msf-essential-drugs-practical-guidelines#page=244)) — and
  an overdose needs urgent care even if the person feels fine
  ([WHO, p. 68](lib:who-model-formulary-2008#page=68)).
- **Opioids** — a dose that's normal for someone used to them can **stop the breathing** of
  someone who isn't, or of a child. Never combine with benzodiazepines (Xanax, Valium,
  Klonopin), alcohol or other sedatives. **[Naloxone](wiki:Naloxone) (Narcan)** reverses opioid overdose —
  keep some.
- **Children** — no cough/cold medicines under age 4 (US labels; never under 2), no **aspirin** for children or teens
  (Reye syndrome — [WHO, p. 226](lib:who-model-formulary-2008#page=226)).
- **Interactions** — check the formulary when someone already takes blood thinners, heart
  medicines or antidepressants.
- **Poisoning: Oregon Poison Center 1-800-222-1222** (24/7, while phones work).

**6. Measure it right** ([WTND ch. 8](lib:where-there-is-no-doctor-08-how-to-measure-and-give-medicine#page=1)):
1 g = 1,000 mg · 1 mg = 1,000 mcg · 1 grain = 65 mg · **1 teaspoon = 5 ml** · 1 tablespoon =
15 ml. Kitchen spoons vary — mark one at 5 ml measured with a syringe
([🖼️ WTND p. 61](lib:where-there-is-no-doctor-08-how-to-measure-and-give-medicine#page=3); cutting tablets:
[🖼️ p. 60](lib:where-there-is-no-doctor-08-how-to-measure-and-give-medicine#page=2)). Check the mg on the
label: strengths differ. Never give medicine by mouth to someone asleep, unconscious or
having a seizure ([p. 62](lib:where-there-is-no-doctor-08-how-to-measure-and-give-medicine#page=4)).

**7. Getting rid of medicines** — mix with coffee grounds or cat litter and seal; flush
only what the FDA lists, like **fentanyl patches** — deadly to children even after use
([FDA](lib:fda-how-to-dispose-of-unused-medicines-2013#page=2);
[🖼️ FDA decision flowchart](lib:fda-drug-disposal-options-flowchart#page=1)).

**Stock up now:** ask your doctor about extra supplies of the medicines your household
depends on, and keep an emergency kit (wound care, pain/fever medicine, antihistamines,
oral rehydration salts, naloxone).

📚 **Go deeper:** [WTND Green Pages](lib:where-there-is-no-doctor-24-green-pages-uses-dosage-and-precautions-for-medicines) — uses, doses and warnings for each medicine; [MSF Essential Drugs, p. 646](lib:msf-essential-drugs-practical-guidelines#page=646) — storage, spoilage and expiry; [Zilker 2019](lib:stability-of-medicines-beyond-expiry-dates-zilker-2019) — what testing shows about old medicines.

---

## 💧 Diarrhea and dehydration: the homemade drink

Most children who die of diarrhea die of **[dehydration](wiki:Dehydration)**. Signs: thirst, little or dark
urine, dry mouth, sunken tearless eyes, skin that stays up when pinched
([🖼️ the pinch test, WTND p. 151](lib:where-there-is-no-doctor-13-some-very-common-sicknesses#page=1)). Start the drink at
the first watery stools ([WTND, p. 151–152](lib:where-there-is-no-doctor-13-some-very-common-sicknesses#page=1)).

**Rehydration Drink** ([🖼️ drawn step by step, Hesperian Ch 5, p. 53](lib:unsafe-water#page=10);
[Oral rehydration](wiki:Oral_rehydration_therapy)): in **1 liter of clean water**, stir **½ level teaspoon of salt** and
**8 level teaspoons of sugar**. Taste before adding the sugar: it must be *less salty than
tears*.

- Give **sips every 5 minutes** until they urinate normally — 3 liters or more a day for a
  large person, at least 1 liter for a small child.
- **Keep giving it even if they vomit.** Keep feeding, and keep breastfeeding babies.
- No repeat doses of medicines that can build up until they urinate normally
  ([WTND, p. 54](lib:where-there-is-no-doctor-06-right-and-wrong-uses-of-modern-medicines#page=6)).
- Getting worse, or other danger signs? Get medical help.

📚 **Go deeper:** [WTND, p. 152](lib:where-there-is-no-doctor-13-some-very-common-sicknesses#page=2) — the sugar and cereal recipes, with pictures; [MSF Clinical Guidelines](lib:msf-clinical-guidelines-diagnosis-and-treatment-manual) — severe diarrhea and cholera.

---

## 🌿 Medicinal plants — go carefully

> 📷 **Not sure what it is?** Photograph it with the [plant and mushroom identifier](guide:PLANT-ID) (under **Tools**). It suggests names and flags poisonous groups, but it's often wrong: confirm every feature here before you eat or use anything.

Signs a home remedy probably doesn't work: many different "cures" for one illness,
disgusting remedies, and anything using **animal or human waste** — that causes infections
([WTND, p. 10–11](lib:where-there-is-no-doctor-01-home-cures-and-popular-beliefs#page=10)).

**Deadly look-alike:** [foxglove](wiki:Digitalis_purpurea) leaves have been mistaken for
[comfrey](wiki:Symphytum_officinale) ([🖼️ foxglove photos, WSU p. 28](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=28)), with fatal "comfrey tea" poisonings — and comfrey itself
can harm the liver ([FDA Bad Bug Book, p. 243](lib:fda-bad-bug-book-2nd-edition-foodborne-pathogens-and-natural-toxins-incl-mushroom-toxins-2012#page=243)).
If in doubt, don't — and call the Poison Center.

📚 **Go deeper:** [WHO Monographs Vol 1](lib:who-monographs-on-selected-medicinal-plants-vol-1) — evidence plant by plant (Vols 1–4); [WSU Poisonous Plants of the PNW, p. 28](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=28) — foxglove and other local poisons.

---

## 🔧 If this goes wrong

| What you see | What to do |
|---|---|
| Rash, itching, swelling or wheezing after a medicine | Stop it for good; epinephrine if severe ([Green Pages](lib:where-there-is-no-doctor-24-green-pages-uses-dosage-and-precautions-for-medicines#page=49)); treat for shock |
| Antibiotic not helping after a day or two | Wrong illness, dose or medicine? Recheck ([WTND, p. 57](lib:where-there-is-no-doctor-07-antibiotics-what-they-are-and-how-to-use-them#page=3)) |
| A child got into medicines | Poison Center 1-800-222-1222 ([Poison control center](wiki:Poison_control_center)) |

📚 **Go deeper:** [WTND — poisoning](lib:where-there-is-no-doctor-10-first-aid#page=29) — common poisons and what to do; [WTND — allergic reactions, p. 166](lib:where-there-is-no-doctor-13-some-very-common-sicknesses#page=16) — mild to severe; [WHO Model Formulary](lib:who-model-formulary-2008) — side effects and interactions, drug by drug.

---

## Ask an AI about the PDFs

On a laptop, use the **Library Assistant** (searches everything, answers with sources), or
**GPT4All** (`AI-Offline\DocReader-GPT4All\`) with the medical folders added as a collection.
Read the page it cites before acting.

📚 **Go deeper:** [How to run the offline AI](guide:HOW-TO-RUN-OFFLINE-AI) — setup; [WTND vocabulary](lib:where-there-is-no-doctor-26-vocabulary) — medical words explained.

---

## ⚠️ Important

This is **reference information, not a substitute for a doctor.** Books and offline AIs
can be wrong or out of date. Get professional help whenever it's possible; use this when it
isn't, and double-check anything critical against more than one source.

*Hesperian and MSF books are free for personal use; ask the publishers before giving copies
to others.*

📚 **Go deeper:** [WTND — serious illnesses](lib:where-there-is-no-doctor-14-serious-illnesses-that-need-special-medical-attention) — signs that need more than home care; [WTND — signs of dangerous illness, p. 42](lib:where-there-is-no-doctor-04-how-to-take-care-of-a-sick-person#page=4) — when to look for medical help.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.
Many more first-aid pictures are in the [Injuries & Illness guide](guide:FIELD-CARE-GUIDE).

**The first few minutes**
- Opening the airway; mouth-to-mouth — [🖼️ ATP, p. 77](lib:atp-4-02-11#page=77); [🖼️ WTND, p. 80](lib:where-there-is-no-doctor-10-first-aid#page=6)
- Windlass and ratchet tourniquets — [🖼️ ATP, p. 62](lib:atp-4-02-11#page=62); [Tourniquet](wiki:Tourniquet)
- Pressing on a wound; where a tourniquet can't go — [🖼️ WHO-ICRC, p. 169](lib:who-icrc-basic-emergency-care#page=169); [🖼️ ATP, p. 69](lib:atp-4-02-11#page=69)
- Shock position and recovery position — [🖼️ ATP, p. 99](lib:atp-4-02-11#page=99); [🖼️ ATP, p. 79](lib:atp-4-02-11#page=79); [Recovery position](wiki:Recovery_position)
- Moving someone with a neck or back injury — [🖼️ WTND, p. 100](lib:where-there-is-no-doctor-10-first-aid#page=26)

**Medicines**
- Cutting tablets and checking a spoon holds 5 ml — [🖼️ WTND, pp. 60–61](lib:where-there-is-no-doctor-08-how-to-measure-and-give-medicine#page=2)
- Making a syrup; child doses by weight — [🖼️ WTND, p. 62](lib:where-there-is-no-doctor-08-how-to-measure-and-give-medicine#page=4)
- Epinephrine pen and naloxone — [Epinephrine autoinjector](wiki:Epinephrine_autoinjector); [Naloxone](wiki:Naloxone)
- Signs of a bad reaction — [Hives](wiki:Hives); [Anaphylaxis](wiki:Anaphylaxis)
- Getting rid of medicines — [🖼️ FDA flowchart](lib:fda-drug-disposal-options-flowchart#page=1)

**Dehydration and plants**
- Signs of dehydration, the pinch test — [🖼️ WTND, p. 151](lib:where-there-is-no-doctor-13-some-very-common-sicknesses#page=1); [Dehydration](wiki:Dehydration)
- Mixing the rehydration drink — [🖼️ WTND, p. 152](lib:where-there-is-no-doctor-13-some-very-common-sicknesses#page=2); [🖼️ Hesperian Ch 5, p. 53](lib:unsafe-water#page=10); [Oral rehydration](wiki:Oral_rehydration_therapy)
- Foxglove, the deadly comfrey look-alike — [🖼️ WSU, p. 28](lib:wsu-selected-poisonous-plants-of-the-pacific-northwest#page=28); [Foxglove](wiki:Digitalis_purpurea); [Comfrey](wiki:Symphytum_officinale)

---

## 🔗 Related guides

- [Injuries & Illness When No Help Is Coming](guide:FIELD-CARE-GUIDE) — bleeding, wounds, burns, fractures, bites, long-term nursing
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local hospitals, clinics, poison center, safe water
- [Mushroom Guide](guide:MUSHROOM-GUIDE) — mushroom poisoning and what to do after a bad meal
- [Nuclear Fallout Guide](guide:NUCLEAR-FALLOUT-GUIDE) — potassium iodide and decontamination
- [Radio Guide](guide:RADIO-GUIDE) — calling for help when phones are down
- [Make-Do Household Guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — soap, cleaners, reusable pads and diapers
- [Chronic Illness With No Pharmacy](guide:CHRONIC-ILLNESS-GUIDE) — diabetes, blood pressure, asthma, seizures and other daily medicines when the pharmacy is gone
- [Making Medicines With No Pharmacy](guide:MAKING-MEDICINES-GUIDE) — what you can make or use yourself, rated: works, weak or dangerous
- [How Antibiotics Came To Be](guide:MEDICINE-HISTORY-GUIDE) — how antibiotics were found and made, and why they stop working
