# 📱💻 Start the Library on Any Device

The library works on almost any computer, tablet or phone, with no internet. (No library drive
yet? See [Get the whole library](guide:GET-THE-LIBRARY).)

**The best way:** start the **Library Assistant**. It's one search box for everything on the drive,
plus an **offline AI** that answers your question and links to the exact page.

**No program will run?** Open **`START-HERE.html`** or **`OPEN-IN-BROWSER.html`** in any web
browser instead.

> ### ⚠️ Remember
> - The AI can be wrong. **Check the pages it links to**, especially for medicine, electricity
>   or food.
> - Leave the black window (or Termux) open while you use it. Closing it stops the library.

---

## 🚀 Pick your device

Open the drive, then the **OfflineLibrary** folder if you see one.

| Your device | What to do |
|---|---|
| **Windows** | Double-click **START-Windows** |
| **Mac** | Double-click **START-Mac** |
| **Linux**, **Raspberry Pi** or **Chromebook** | Run **START-Linux.sh** |
| **Android** tablet or phone | Set up the free **Termux** app once (below) |
| **iPhone / iPad** | Use a library **shared over Wi-Fi** from another device |
| A computer that won't run programs, or a very old one (Windows 7) | Open **OPEN-IN-BROWSER.html** |

---

## 🪟 Windows

1. Double-click **START-Windows**.
2. If a blue box says **Windows protected your PC**, click **More info**, then **Run anyway**.
3. Your web browser opens. Type a question and click **Ask**.
4. When you're done, close the black window.

## 🍎 Mac

1. Double-click **START-Mac**. Your web browser opens.
2. **The first time,** the Mac may say it **can't open** it. Click **Done**, then go to **Apple
   menu → System Settings → Privacy & Security**, scroll down and click **Open Anyway**.

## 🐧 Linux, Raspberry Pi, Chromebook

1. Right-click **START-Linux.sh** → **Run as a Program**. Your web browser opens.
2. If it only opens as text: right-click an empty spot in the folder → **Open in Terminal**, type
   `bash START-Linux.sh` and press Enter.

- **Raspberry Pi:** needs the 64-bit system; a Pi 5 works best. To run one with no screen, see the
  [ARK Vault](guide:AMMO-CAN-COMPUTER-GUIDE).
- **Chromebook:** first turn on Linux (**Settings**, search for **Linux**). In the **Files** app,
  right-click the drive → **Share with Linux**. Open the **Terminal** app, click **penguin**, and type:

  ```
  bash /mnt/chromeos/removable/*/OfflineLibrary/START-Linux.sh
  ```

## 🤖 Android tablet or phone

About 10 minutes, **once**. You'll use **Termux**, a free app where you type short commands.

**First,** copy the whole **OfflineLibrary** folder onto the tablet or its SD card.

1. **Install Termux:** in the **Files** app, open **OfflineLibrary → Phone-Apps → Android-Termux**
   and tap the **Termux** file. Allow it if asked, then tap **Install**.
2. **Copy `START-Android.sh`** (next to `START-HERE.html`) into the tablet's **Download** folder.
3. **Open Termux**, type `termux-setup-storage`, press Enter, and tap **Allow**.
4. Type this and press Enter. It takes a minute, then the library opens in your browser.

   ```
   bash /sdcard/Download/START-Android.sh
   ```

5. **From then on,** just open Termux and type `library`.

Keep Termux open while you use it.

## 🍏 iPhone and iPad

iPhones can't run the Library Assistant, but you can:

1. **Use a library shared over Wi-Fi** from a laptop, tablet or ARK Vault. Everything works,
   including the AI. See [below](#share-one-library-with-every-phone-nearby).
2. **Load the iPhone itself, now, while you have internet:** install the free **Kiwix**
   (encyclopedias) and **OsmAnd** (maps) apps, then copy files from the drive onto the iPhone.
   See [Use the library on a phone](guide:USE-ON-PHONE).
3. **Save the library website:** open it in Safari, tap **More → Offline & downloads**, then **Save** beside **Guides and tools**,
   then **Share → Add to Home Screen**.

---

## 🌐 No program? Use the library in your web browser

**`OPEN-IN-BROWSER.html`** works on almost any computer with nothing to install: a work computer,
a Chromebook, or one you're borrowing.

1. Double-click **`OPEN-IN-BROWSER.html`** on the drive.
2. Click **📂 Open the library folder** and pick the folder it's in. (The browser asks first. If it
   says "upload", don't worry: nothing leaves the computer.)
3. Search, read the e-books, or open Wikipedia by an article's title.

It can't run the **AI** or the **maps**.

---

## 📡 Share one library with every phone nearby

One device runs the library, and **every phone nearby uses it in its web browser**, iPhones
included. No internet needed.

**On the device running the library:**

1. Click **More → Share with nearby devices → Start local sharing**. If asked to allow network access, click **Allow**.
2. Write down the address it shows (like `http://192.168.43.1:8096`).

**On each phone:**

1. Join the **same Wi-Fi**.
2. Type the address into the browser. On an iPhone, use **Safari**.
3. For an icon, tap **Share → Add to Home Screen** (iPhone) or **⋮ → Add to Home screen** (Android).

**No Wi-Fi?** Turn on an Android phone's **hotspot** (no phone plan needed) or use a small travel
router. Put a password on it. A Raspberry Pi can make its own Wi-Fi; see the
[ARK Vault](guide:AMMO-CAN-COMPUTER-GUIDE).

---

## 🗄️ Put old devices to work — set them up now

An old laptop or tablet in a drawer makes a great emergency computer:

| Old device | What it can do |
|---|---|
| Windows laptop (Windows 10 or 11) | Runs the library, or shares it with the household |
| Mac (about 2017 or newer) | Runs the library |
| Android tablet or phone (Android 7 or newer), most Amazon Fire tablets | Runs the library with Termux |
| Raspberry Pi 4 or 5 | Shares the library over its own Wi-Fi; see the [ARK Vault](guide:AMMO-CAN-COMPUTER-GUIDE) |
| iPhone, iPad, any phone | Uses a library shared over Wi-Fi |

Charge it, copy the library on, and **try it once** with the Wi-Fi off. Store spares in a metal
can (see the [EMP guide](guide:EMP-GUIDE)), about half charged.

---

## 🧠 Which AI will I get?

You don't need to choose. It picks the best AI the device can handle, and you can change it in
**More → Offline AI settings**:

| Setting | Good for | Answers |
|---|---|---|
| **Automatic** (recommended) | Any device | Picks for you |
| **Off** | Very old devices | Search only, instant |
| **Quick** | Phones, tablets, older laptops | Short answers, about 30–60 seconds |
| **Standard** | Most laptops | Good answers, about a minute |
| **Smart** | Computers with lots of memory (16 GB) | Better answers, slower |
| **Graphics card** | Gaming computers | Fast, good answers |

Search is always instant, even with the AI off.

---

## 🔧 If something goes wrong

| Problem | Fix |
|---|---|
| Windows: **Windows protected your PC** | Click **More info**, then **Run anyway** |
| Mac: **can't be opened** | **System Settings → Privacy & Security → Open Anyway** |
| The browser didn't open | Type the address shown in the black window into your browser |
| The AI is very slow or stopped | In **More → Offline AI settings**, pick **Quick** or **Off** |
| Raspberry Pi: **⚠️ Power too weak** | Without enough power the Pi can slow right down. Use the official Raspberry Pi power supply and its own cable (a phone charger usually isn't enough). In the ammo can, see the [ARK Vault guide](guide:AMMO-CAN-COMPUTER-GUIDE) |
| Android: **Couldn't find the library** | Copy the *whole* library folder to the tablet, then try again |
| Android: the page stops working | Keep Termux open; don't swipe it away |
| **OPEN-IN-BROWSER** asks you to open the folder | Click **📂 Open the library folder** and pick the folder with `START-HERE.html` in it |
| A Mac or tablet won't open the drive | The drive needs to be **exFAT**. See [Get the whole library](guide:GET-THE-LIBRARY) |

---

## 🤝 Sharing it with your community

- **Copy it:** copy the whole **OfflineLibrary** folder onto another USB drive. The copy works just
  like the original.
- **Or make a fresh one:** run the installer ([Get the whole library](guide:GET-THE-LIBRARY)). Even a
  **16 GB** stick holds all the guides, the Illinois Valley books, a small AI and maps of Oregon.
- **Hold a "library night":** bring a laptop and blank USB sticks and help neighbors set it up.
- **Please don't sell it or post the books online.** It's free to share with family and neighbors.

---

## 🔗 Related guides

- [Get the whole library](guide:GET-THE-LIBRARY) — putting it on a USB drive
- [Start Here (Illinois Valley)](guide:ILLINOIS-VALLEY-START-HERE) — the one-page local quick reference
- [Use the Library on a Phone](guide:USE-ON-PHONE) — Kiwix and OsmAnd on phones and iPads
- [How to Run the Offline AI](guide:HOW-TO-RUN-OFFLINE-AI) — more about the AI
- [EMP Guide](guide:EMP-GUIDE) — protecting a spare device
