# 🏞️ Dams, Weirs, Ditches & Ponds

How water is held back, raised, measured and led across the land, and how to build the small versions: what
a dam's parts do and how dams fail; a farm pond whose spillway never lets it overtop; weirs that raise a creek
or turn a ruler reading into gallons a minute; headgates, ditches, siphons and furrows; water wheels; fish
passage; and how to live safely near all of it. Most of the books are in `Off-Grid-Power\Micro-Hydro` (the
Bureau of Reclamation's *Water Measurement Manual*, the ESHA *Layman's Guidebook*, the DOE *Microhydropower
Handbook*), with the VITA *Village Technology Handbook* in `Homestead-Skills\Household-Make-Do`. Turbines are in
the [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE), springs and ram pumps in
[Water Wells](guide:WATER-WELLS-GUIDE), culverts in [Masonry & Roads](guide:MASONRY-ROADS-GUIDE), a town's
pipes in [How Town Water and Sewer Work](guide:TOWN-WATER-SEWER-GUIDE).

> ### The short version
> - **Stay away from low dams and weirs, above and below.** The roller at the foot of one can hold a person in
>   a life jacket under again and again ([Air Force AFH 10-644, p. 491](lib:afh-10-644#page=491)).
> - **A dam breaking is a flash flood** ([FEMA, p. 51](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=51)):
>   below one, know your way to high ground on foot.
> - **Dams fail from water going over or through them.** New wet spots, muddy seeps or boils below a dam are
>   the warning: tell everyone downstream first.
> - **A small earth bank holds** when its clay core is keyed into firm ground and it is built in damp layers
>   about 8 in thick, each rammed hard ([WHO *Vector Control*, p. 137](lib:vector-control-methods#page=137);
>   [ESHA, p. 52](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=52)).
> - **Size the spillway for the worst storm** ([NCAT, p. 3](lib:ncat-attra-micro-hydro#page=3)), in natural ground
>   beside the bank, never over the fill.
> - **Measure a creek with a weir:** a notch, a post upstream level with the notch bottom, a ruler and the
>   tables below ([DOE, pp. 94–97](lib:doe-microhydropower-handbook-vol-1-part-1#page=94)).
> - **Ditches want a gentle fall,** 1–5 cm per 10 m (1–6 in per 100 ft)
>   ([WHO *Vector Control*, p. 127](lib:vector-control-methods#page=127)). Leave water in the creek for the fish.
> - **Who may take water is a law question,** even after a collapse; in the West the oldest right is served
>   first ([DOE Vol 1 Pt 2, p. 173](lib:doe-microhydropower-handbook-vol-1-part-2#page=173)).

---

## 🏞️ How dams work
<!-- fold: The kinds of dam, their parts, how they fail, warning signs, and living below one -->

A dam stores water or raises its level so it can run somewhere by gravity
([ESHA, p. 52](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=52)). It must stand up to the
water's push, stop water getting through or under it, and pass floods without going over the top.

### Kinds of dams

| Kind | Notes |
|---|---|
| **Earth embankment** ([photos](wiki:Embankment_dam)) | Held by its weight; a watertight **core** of compacted clay reaches down into watertight ground. Better than rigid concrete where earthquakes happen ([ESHA, p. 52](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=52)). The usual pond dam |
| **Rock-fill** | Piled rock leaks unless the upstream face is sealed, as with gabions lined with a sheet ([ESHA, p. 56](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=56)); small ones make simple weirs ([GTZ, p. 29](lib:gtz-micro-hydro#page=29)) |
| **Concrete or stone gravity** ([photos](wiki:Gravity_dam)) | Upright face upstream, sloping face downstream; its weight keeps it from tipping or sliding ([ESHA, p. 53](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=53)). A small weir's base should be 3 times its height ([GTZ, p. 28](lib:gtz-micro-hydro#page=28)) |
| **Arch** ([photos](wiki:Arch_dam)) | A thin curved wall pushing into canyon rock: engineers' work *(rule of thumb)* |
| **Timber crib** | Green logs stacked crosswise 2–3 ft apart, spiked, filled with rock and gravel, the upstream side sealed with clay ([DOE, p. 95](lib:doe-microhydropower-handbook-vol-1-part-1#page=95)) |
| **Beaver dam** ([photos](wiki:Beaver_dam)) | Sticks and mud where water runs slowly ([AFWA *Beaver BMPs*, p. 2](lib:trapping-bmps-beaver#page=2)); floods fields and roads, but the ponds make habitat ([*Trapping Furbearers*, p. 11](lib:trapping-furbearers-student-manual#page=11)) |

### The parts of a dam

- **Cutoff and core:** a clay-filled trench or wall under the dam reaches watertight ground, and the watertight
  middle (core) rises from it ([ESHA, pp. 52–53](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=52)).
- **Faces:** the upstream (wet) face is armoured with rock, **riprap**, against waves; the downstream face is kept
  grassed and dry *(rule of thumb)*.
- **Crest and freeboard:** the top, and its height above the water: **12–20 in** on small pond banks
  ([WHO *Vector Control*, p. 137](lib:vector-control-methods#page=137)).
- **Spillways:** the **principal** spillway (a pipe or notch) carries normal flow; the **emergency** spillway, a wide
  channel round one end, carries floods. Fast spillway water digs, so it ends in a **stilling basin** or rock apron
  ([ESHA, pp. 54–56](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=54)).
- **Outlet works:** a low pipe with a valve or gate to release water or empty the pond for repairs
  ([ESHA, p. 56](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=56)).

### How dams fail

- **Overtopping:** a flood the spillway can't carry runs over the crest and washes the bank away. "Unless properly
  engineered, a dam can easily wash out" ([DOE, p. 181](lib:doe-microhydropower-handbook-vol-1-part-1#page=181)).
  It happens most when the pond is already full in a long storm ([county hazard plan, p. 289](lib:josephine-county-multi-jurisdictional-natural-hazard-mitigation-plan-josephine-county-2022#page=289)).
- **Piping:** water finds a path through or under the dam, carries soil out, and the path grows. At one weir built
  on loose ground with no cutoff, the only sign was "minor leakage at the downstream toe"; a channel already ran
  right under it ([ESHA, p. 50](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=50)).
- **Slides:** at the same book's La Marea scheme, a sand-and-clay reservoir bank leaked, the soaked hillside slid,
  and the bank broke (same page).
- **Burrows and roots:** muskrats "can be extremely destructive to the banks and dikes of man-made ponds"
  ([*Trapping Furbearers*, p. 11](lib:trapping-furbearers-student-manual#page=11)); on small dams, plants and
  burrowing animals are a common cause of failure ([county hazard plan, p. 290](lib:josephine-county-multi-jurisdictional-natural-hazard-mitigation-plan-josephine-county-2022#page=290)).
- **Earthquakes:** a bank can settle until a full pond goes over the top ([county hazard plan, p. 290](lib:josephine-county-multi-jurisdictional-natural-hazard-mitigation-plan-josephine-county-2022#page=290)).
  Most of Oregon's big dams were built before modern earthquake design; well-built dams have stood up in other
  subduction quakes, but a damaged spillway gate could let water out without warning
  ([Oregon Resilience Plan, p. 134](lib:oregon-resilience-plan-full-report-osspac-2013#page=134)).

### Warning signs at a dam

Walk the dam after big storms, and in the dry season, when new seepage is easiest to spot
([Practical Action, p. 12](lib:operation-and-maintenance-of-community-micro#page=12)). Look for *(rule of thumb,
unless cited)*:

| Sign | What it may mean |
|---|---|
| New wet ground or springs on the dry face, at the toe or below | Seepage ([ESHA, p. 50](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=50)) |
| **Muddy** seepage, or a "boil" bubbling up sand | Piping has started. **Danger** |
| A whirlpool in the pond | Water draining through a hole. **Danger**: it pulls things in |
| Cracks, slumps, bulges or sinkholes | The bank is moving or hollowing |
| Water near the crest; spillway blocked or eroding | Overtopping coming |

**If a dam looks like failing:** warn everyone downstream first, then open the outlet only if you can do it without
standing on the dam or in the water. Never try to plug a hole from the pond side *(rule of thumb)*.

### Living downstream of a dam

- A dam break acts like a flash flood, with "a dangerous wall of roaring water that carries rocks, mud, and other
  debris" ([FEMA, p. 51](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=51)): "seek higher
  ground on foot immediately" ([p. 52](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=52)).
- Know which dams are above you, where their water would go, and your path uphill. Flood steps: "The first hour of a
  flood" in the [Floods guide](guide:FLOODS-STORMS-HEAT-GUIDE).
- Dam safety is each state's job, and bigger dams need permits
  ([DOE Vol 1 Pt 2, pp. 174–175](lib:doe-microhydropower-handbook-vol-1-part-2#page=174)). With no inspectors,
  the neighbours below should walk the dam together *(rule of thumb)*.

**Dams above us.** The county's hazard plan lists two high-hazard dams, Strong Reservoir (Sour Dough Gulch, near
Glendale) and **McMullen Creek Dam, which holds Lake Selmac** near Selma, and one significant-hazard dam, Sowell Dam
southeast of Cave Junction ([county hazard plan, p. 290](lib:josephine-county-multi-jurisdictional-natural-hazard-mitigation-plan-josephine-county-2022#page=290)).
"High hazard" means people live in the flood path, not that the dam is unsafe
([p. 288](lib:josephine-county-multi-jurisdictional-natural-hazard-mitigation-plan-josephine-county-2022#page=288)).
The county owns Lake Selmac's dam; OWRD estimated that its failure could flood **39 buildings** and endanger **up to
69 people** ([p. 47](lib:josephine-county-multi-jurisdictional-natural-hazard-mitigation-plan-josephine-county-2022#page=47)),
and the county plans to seek money to repair it
([p. 82](lib:josephine-county-multi-jurisdictional-natural-hazard-mitigation-plan-josephine-county-2022#page=82)).
If you live below the lake, walk your route to high ground now, and watch the dam in long winter storms.

## 🪣 Small dams and farm ponds
<!-- fold: Choosing a site, soils that hold water, building the bank, the spillway, pipes, and what ponds are for -->

A dam holding "more than a few acre-feet" does "a great deal of damage" if it breaks: choose the site carefully and
"consult an expert before starting to build" ([VITA, p. 121](lib:village-technology-handbook-vita#page=121)). An
**acre-foot** is a foot of water over an acre, about 326,000 gallons (same page; *arithmetic*). In Oregon, a reservoir or pond of **any size** that stores water needs a water right permit. A dam **10 ft or
higher that stores 9.2 acre-feet (3 million gallons) or more** must be designed and built under a registered
engineer, with plans approved by OWRD; smaller ponds get a quicker review with the watermaster and ODFW
([OWRD *Water Rights in Oregon*, pp. 24–25](lib:oregon-owrd-water-rights-in-oregon#page=24); [p. 50](lib:oregon-owrd-water-rights-in-oregon#page=50)).

### Choosing the site and the watershed

- **Where:** "where a broad valley narrows with steep sides and a firm base"; not on big boulders, cracked bedrock,
  sand or porous rock. Best is solid rock near the surface or deep silty or sandy clay
  ([VITA, pp. 121–122](lib:village-technology-handbook-vita#page=121)).
- **Water in:** the watershed (all the land draining to the pond) yields about **5 acre-feet a year per inch of
  yearly rain per square mile**, about a tenth of the rain ([VITA, p. 121](lib:village-technology-handbook-vita#page=121)):
  100 acres with 30 in of rain gives about **23 acre-feet a year** *(arithmetic)*.
- **Water out:** taking 9 gallons a minute around the clock drops a half-acre pond **an inch a day**
  ([Clemson, p. 13](lib:clemson-extension-homemade#page=13)). Add summer evaporation and plan for the driest month
  *(rule of thumb)*.
- **Off the main creek:** a dam across a flowing stream must pass every flood and blocks fish; use a side draw or
  fill the pond from a ditch *(rule of thumb)*.

### Soils that hold water, and keying in

- The best soil has **clay with some silt or sand**, enough nearby for the whole bank
  ([VITA, p. 122](lib:village-technology-handbook-vita#page=122)). Test it with the ribbon test in "Earth building" in
  the [Shelter guide](guide:SHELTER-BUILDING-GUIDE). It is damp enough to pack when a squeezed golf ball of it breaks
  into a few even pieces ([FM 5-34, p. 267](lib:fm-5-34-engineer#page=267)).
- **Strip** topsoil, roots, stumps and brush from under the bank: buried plants rot into leaks *(rule of thumb)*.
- **Key it in:** dig a cutoff trench along the centre line down into clay or rock and fill it with rammed clay joined
  to the core ([ESHA, p. 52](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=52)). Missing it
  undermined the weir in "How dams fail". On a timber dam, boards driven 2–3 ft into the bed ("priming planks") do
  the same ([DOE, p. 94](lib:doe-microhydropower-handbook-vol-1-part-1#page=94)).
- **Soils here:** Table 13 of the county Soil Survey rates every soil for **pond reservoir areas** (best: little
  seepage in the top 60 in) and **embankment fill** (it must resist seepage and piping; poor if there is less than
  5 ft of it, or it is stony or full of plant matter)
  ([Soil Survey, pp. 121–122](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=121)). Some
  soils here suit small fish ponds ([p. 117](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=117)).

### Building the bank by hand or with animals

- **Thin, damp, rammed layers:** "about 20 cm" (8 in), each "dampened and rammed down before a new layer is added";
  grass the bank against erosion ([WHO *Vector Control*, p. 137](lib:vector-control-methods#page=137)).
- **Moving dirt:** a **fresno scraper** behind 2 oxen or 2–4 horses moves large amounts; plough first, and keep clear
  of the handle, which can fly up ([VITA, p. 190](lib:village-technology-handbook-vita#page=190)). A **V-drag** cuts
  ditches and builds low banks ([p. 207](lib:village-technology-handbook-vita#page=207)).
- **Shape** *(rule of thumb)*: sides no steeper than **3 across to 1 up** on the water side and **2 to 1** on the dry
  side; a top 8–12 ft wide; build a tenth higher than planned, for settling.
- **Rock** for the spillway ([VITA, p. 122](lib:village-technology-handbook-vita#page=122)), and where waves hit the bank
  *(rule of thumb)*.

### Sizing the spillway

"It is vital to know the maximum streamflow in order to adequately size spillways"
([NCAT, p. 3](lib:ncat-attra-micro-hydro#page=3)).

1. **The flood:** for under 100 acres, **Q = 2 × A × R × C**: Q in cubic feet a second (cfs), A the acres draining in,
   R the heaviest rain in inches an hour, C the share that runs off (the book's Table 8-3)
   ([FM 5-34, p. 268](lib:fm-5-34-engineer#page=268)). The wettest day on record at Cave Junction brought **8.12 in** of rain
   ([Soil Survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)).
2. **The width:** a spillway passes **Q = C × L × H^1.5**, L its width and H the depth flowing over it; for a broad
   flat spillway C is 1.66 in metres ([ESHA, p. 55](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=55)),
   **about 3.0 in feet** *(arithmetic)*.
3. **Example:** 20 acres, 2 in of rain an hour, half running off (C = 0.5, assumed): Q = 2 × 20 × 2 × 0.5 = **40 cfs**.
   At 1 ft deep that needs 40 ÷ 3.0 = **13 ft of width**, and the dam's top at least 2 ft above the spillway floor
   *(arithmetic; the extra foot is rule of thumb)*. Wider is safer.
4. **Where:** in undisturbed ground round one end, grassed or rocked, back to the creek well below the toe *(rule of
   thumb)*. "Protect the downstream face of the dam from erosion" ([DOE, p. 95](lib:doe-microhydropower-handbook-vol-1-part-1#page=95)).

### Pipes, trees and burrowing animals

- **Water creeps along the outside of a pipe** through a bank. A collar round the pipe (an anti-seep collar), such as
  a "puddle flange of rubber or mild steel", stops it ([GTZ, p. 44](lib:gtz-micro-hydro#page=44)); bed the pipe in rammed clay, never gravel
  *(rule of thumb)*.
- **Better, no pipe through the bank:** a siphon over the top takes water "without breaching the dam"
  ([Clemson, p. 13](lib:clemson-extension-homemade#page=13)). Over 10 ft of lift, get an engineer; insulate the bend
  against freezing ([DOE, p. 223](lib:doe-microhydropower-handbook-vol-1-part-1#page=223)).
- **Keep trees and brush off the bank.** Muskrat burrows are 4–8 in across
  ([*Trapping Furbearers*, p. 48](lib:trapping-furbearers-student-manual#page=48)): trap them and pack the holes with
  clay; clear beaver sticks from spillways before storms *(rule of thumb)*. Trapping:
  [Hunting, Trapping & Fishing guide](guide:HUNTING-TRAPPING-FISHING-GUIDE).

### Ponds for stock, fire, fish and watering

- **Stock:** fence the pond and pipe water to a trough, so hooves don't break the bank *(rule of thumb)*. A ram pump
  can run from a pond if its spring keeps up, with the waste water led away from the bank
  ([Clemson, p. 13](lib:clemson-extension-homemade#page=13)).
- **Fire:** keep a road to the edge *(rule of thumb)*; pumps: "Water with no power" in the [Wildfire guide](guide:WILDFIRE-GUIDE).
- **Fish and mosquitoes:** about 6 small mosquito-eating fish keep a 5–10 m² pool clear of larvae
  ([WHO *Vector Control*, p. 138](lib:vector-control-methods#page=138)). Ask ODFW before moving any
  fish, and never let pond fish into a creek *(rule of thumb)*.
- **Crops:** 1 cfs gives about **1 acre-inch an hour**, **2 acre-feet a day**
  ([USBR, p. 275](lib:usbr-water-measurement-manual#page=275)).
- **Children:** fence ponds near houses (see "Working in and near water").

## 📏 Weirs: raising water and measuring a creek
<!-- fold: Low walls that raise a creek for an intake, and measuring weirs with their flow tables -->

A **weir** is a low wall that water flows over. It raises a creek so some can enter an intake, or, cut to an exact
shape, measures the flow.

### Diversion weirs

- Small water schemes use "a low diversion structure" that lifts the water into the intake and lets the rest
  overflow; the simplest is "a few boulders placed across the stream", or gabions (wire baskets of stone)
  ([ESHA, p. 52](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=52)).
- Build on rock where you can, with a gate to flush out sand ([GTZ, p. 28](lib:gtz-micro-hydro#page=28)); stake and
  other makeshift weirs "have to be repaired or rebuilt after floods" ([p. 30](lib:gtz-micro-hydro#page=30)).
- **Wing weirs instead of a dam:** a rock weir across a third of the creek, 50–100 ft above the intake and angled
  downstream, steers debris away; another across half the creek below the intake helps divert water. Floods run over
  both ([DOE, pp. 181–183](lib:doe-microhydropower-handbook-vol-1-part-1#page=181)).
- **Flashboards** (planks on pins along the crest) raise it more, but pulling them in a flood "is very difficult"
  ([ESHA, p. 53](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=53)).

### How a measuring weir works

A weir of set shape has only one pool depth for each flow, so a depth reading and a table give the flow
([USBR, p. 87](lib:usbr-water-measurement-manual#page=87)). For the tables to be true
([pp. 91–92](lib:usbr-water-measurement-manual#page=91)):

- Measure the **head** (water depth above the notch's bottom edge, the **crest**) upstream, **at least 4 times the
  biggest head** away: the surface dips as it nears the notch ([p. 89](lib:usbr-water-measurement-manual#page=89)).
- Keep the notch edge **sharp on the upstream side**, with air under the falling water, and the water below the weir
  **at least 2½ in (0.2 ft) under** the crest.
- Keep the pool quiet: water approaching slower than **0.5 ft a second** ([p. 60](lib:usbr-water-measurement-manual#page=60)),
  with no sand bars or weeds ([p. 59](lib:usbr-water-measurement-manual#page=59)).

### Building a measuring weir

From the DOE handbook ([pp. 90–96](lib:doe-microhydropower-handbook-vol-1-part-1#page=90)):

1. **Notch:** at least as deep as the stream and **3 times as wide as it is deep**.
2. **Board or plate:** tongue-and-groove lumber or metal, the notch bevelled **45°** on the downstream side, its bottom
   level and sides square; leave a **⅛-in flat lip** on wood's upstream face so it doesn't chip.
3. **Setting:** trench across the stream, level the bottom board on clay, brace it to a post driven firm, and seal the
   upstream face with plastic and earth or sandbags, away from the notch. Check often that water isn't cutting round it
   ([NCAT, p. 5](lib:ncat-attra-micro-hydro#page=5)).
4. **Gauge post:** at least **5 ft upstream**, reachable from the bank, its top level with the notch bottom (use a
   carpenter's level). Read the depth on a ruler to the nearest ⅛ in.
5. Leave at least **1 ft of drop** below the weir ([🖼️ p. 92](lib:doe-microhydropower-handbook-vol-1-part-1#page=92)).

### Reading a rectangular notch

Multiply by the **notch width in inches** ([DOE, p. 97](lib:doe-microhydropower-handbook-vol-1-part-1#page=97);
[Peace Corps *Hydrams*, p. 50](lib:hydrams-design-construction#page=50)):

| Water over the notch bottom | Gallons a minute per inch of width | Cubic ft a second per inch |
|---|---|---|
| 1 in | 3.0 | 0.0067 |
| 2 in | 8.5 | 0.019 |
| 3 in | 15.6 | 0.035 |
| 4 in | 24 | 0.054 |
| 5 in | 34 | 0.075 |
| 6 in | 44 | 0.099 |
| 8 in | 68 | 0.152 |
| 10 in | 95 | 0.212 |
| 12 in | 125 | 0.279 |

**Example:** a 12-in notch reading 3 in: 12 × 15.6 = **187 gallons a minute**. In feet: Q = 3.33 × L × h^1.5 (cfs)
([USBR, p. 100](lib:usbr-water-measurement-manual#page=100)). Readings under 2½ in are rough
([p. 92](lib:usbr-water-measurement-manual#page=92)): use a narrower notch or a V.

### Reading a V-notch

A **90° V-notch** (a right-angled V, point down) is "particularly suited for small flows"
([USBR, p. 100](lib:usbr-water-measurement-manual#page=100)): Q = 2.49 × h^2.48 (cfs, head in feet)
([p. 101](lib:usbr-water-measurement-manual#page=101); the book's Table A7-4,
[p. 285](lib:usbr-water-measurement-manual#page=285)):

| Water above the point of the V | Cubic ft a second | Gallons a minute |
|---|---|---|
| 2½ in | 0.051 | 23 |
| 3 in | 0.080 | 36 |
| 4 in | 0.163 | 73 |
| 5 in | 0.284 | 127 |
| 6 in | 0.446 | 200 |
| 8 in | 0.91 | 409 |
| 10 in | 1.58 | 711 |
| 12 in | 2.49 | 1,118 |
| 15 in | 4.33 | 1,944 |

Use it from 2½ to 15 in of head ([p. 97](lib:usbr-water-measurement-manual#page=97)), with its point and edges at
least 2 heads from the banks and bottom ([p. 101](lib:usbr-water-measurement-manual#page=101)). Gallons a minute ×
feet of drop ÷ 10 is rough watts ([Off-Grid guide](guide:OFF-GRID-POWER-GUIDE)).

### Flumes

A **measuring flume** narrows or lifts the channel so the water speeds up and its depth gives the flow. It loses under
a quarter of the drop a weir needs, passes sand and trash, and is hard to alter "to obtain an unfair share of water"
([USBR, p. 117](lib:usbr-water-measurement-manual#page=117)). The **Parshall flume** has tables from 1 inch wide up
([pp. 118, 291](lib:usbr-water-measurement-manual#page=118)); a raised sill (broad-crested weir) can be fitted to
almost any ditch (pp. 117–118), and suits a farm ditch with little drop and many weeds
([p. 57](lib:usbr-water-measurement-manual#page=57)). A **flume** is also a wooden trough carrying a ditch over a gully.

## 🌊 Diversions and ditches
<!-- fold: Taking part of a creek, headgates and checks, grade, upkeep, siphons, irrigation, old ditches, and water rights -->

### Taking part of a creek

- **Angle:** an intake at **90°** to the stream "attracts the least amount of debris" and stands up to floods
  ([DOE, p. 181](lib:doe-microhydropower-handbook-vol-1-part-1#page=181)). Use a straight stretch: the inside of a
  bend fills with sand, the outside takes the floods ([ESHA, p. 62](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=62)).
- **Depth:** the ditch bottom at or below the creek bottom, so it still draws at low flow
  ([DOE, pp. 185–186](lib:doe-microhydropower-handbook-vol-1-part-1#page=185)).
- **Armour:** rock 8 in or bigger, 5 ft each way from the intake and a foot above high-water marks
  ([DOE, p. 184](lib:doe-microhydropower-handbook-vol-1-part-1#page=184)).
- **Sand:** on ditches half a mile or longer, a settling basin **4 times the ditch's width, 2–3 ft deeper and 90 ft
  long**, flushed through a cleanout ([DOE, p. 190](lib:doe-microhydropower-handbook-vol-1-part-1#page=190)).
- **Leave water in the creek, and screen the intake:** see "Salmon, steelhead and fish passage".

### Headgates and checks

- A **headgate** sets how much water enters: a board or plate sliding in grooves, raised by a screw or wheel
  ([ESHA, pp. 63–64](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=63)). Stop leaks with rubber
  strip or plastic in the slot; grease the screw; paint the wood
  ([Practical Action, p. 13](lib:operation-and-maintenance-of-community-micro#page=13)).
- **Stoplogs**, timbers stacked in grooves, only stop flow; for a full shutoff use two sets 6 in apart with clay
  packed between ([ESHA, p. 63](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=63)).
- A **check** across the ditch holds the level steady for the turnouts above it; lowering a hinged gate 6 in lowers
  the water about 6 in ([USBR, p. 108](lib:usbr-water-measurement-manual#page=108)). Keep stoplogs stacked in it ready to
  drop by pulling a pin; a canvas or plastic sheet laid upstream seals them
  ([DOE, p. 218](lib:doe-microhydropower-handbook-vol-1-part-1#page=218)).

### Ditch grade and shape

- **Fall:** **1–5 cm per 10 m** (1–6 in per 100 ft); steeper erodes
  ([WHO *Vector Control*, p. 127](lib:vector-control-methods#page=127)). Set it with a level, never by eye
  ([DOE, p. 189](lib:doe-microhydropower-handbook-vol-1-part-1#page=189)): see "Slope, grade, pitch and stairs" in
  the [Practical Math guide](guide:PRACTICAL-MATH-GUIDE).
- **Size:** water should move about **2 ft a second**, so square feet of flow = cfs ÷ 2
  ([DOE, p. 184](lib:doe-microhydropower-handbook-vol-1-part-1#page=184)); 1 cfs needs half a square foot *(arithmetic)*.
- **Sides:** clay stands at 1 up to ¾ across under water, sandy soil at 1 up to 2 across; **freeboard** a third of the
  water depth, at least 6 in ([ESHA Pt 2, pp. 2–3](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=2)).
- **Digging:** start at the outlet and work up; side ditches join at about 30°
  ([WHO *Vector Control*, p. 127](lib:vector-control-methods#page=127)). On a hillside, bench along the contour, build
  the outer bank in compacted layers and grass it ([GTZ, p. 36](lib:gtz-micro-hydro#page=36)); with animals, plough
  and V-drag ([VITA, pp. 207–209](lib:village-technology-handbook-vita#page=207)).
- **Overflows:** spillways every **100–200 m** (330–660 ft) on a long ditch ([GTZ, p. 42](lib:gtz-micro-hydro#page=42)),
  so storm water can't overflow it ([DOE, p. 189](lib:doe-microhydropower-handbook-vol-1-part-1#page=189)).

### Keeping a ditch working

- Walk it before turning water in and after storms: erosion, loose rocks, logs, slips, blocked crossings. "A delay in
  a small repair can lead to bigger and more serious problems within days"
  ([Practical Action, pp. 12–13](lib:operation-and-maintenance-of-community-micro#page=12)).
- Leaks, blockages and leftover puddles breed mosquitoes ([WHO *Vector Control*, p. 126](lib:vector-control-methods#page=126));
  varying the level or turning the water off for a while also keeps snails down
  ([VITA, p. 183](lib:village-technology-handbook-vita#page=183)).
- Pack gopher and muskrat holes with damp clay before water finds them *(rule of thumb)*.

### Crossings: siphons, culverts and flumes

- **Siphon tube:** takes water over the bank "without cutting a hole in the ditch bank", which "soon becomes a large
  hole". Fill it in the ditch, cap one end with your hand, and set that end outside, lower than the ditch water
  ([VITA, p. 213](lib:village-technology-handbook-vita#page=213)). At low flow tubes air-lock: prime again
  ([USBR, p. 260](lib:usbr-water-measurement-manual#page=260)). Lift limit: "Water flow and pressure" in the
  [Practical Math guide](guide:PRACTICAL-MATH-GUIDE).
- **Under a road:** "Culverts and water bars" in [Masonry & Roads](guide:MASONRY-ROADS-GUIDE).
- **Over a gully:** a wooden flume on trestles, or a pipe that dips under and rises (an inverted siphon) with its
  outlet lower than its inlet *(rule of thumb)*.

### Furrow and flood irrigation

- **Level the field:** drag a float at least 16 ft long over it each season, the last pass the way the water will run
  ([VITA, p. 202](lib:village-technology-handbook-vita#page=202)).
- **Furrows:** small channels between rows, fed by siphon tubes or short pipes through the bank
  ([USBR, pp. 259–260](lib:usbr-water-measurement-manual#page=259)).
- **Border (flood) irrigation:** plough and V-drag low banks down the field, smooth between them
  ([VITA, p. 209](lib:village-technology-handbook-vita#page=209)), and run a sheet of water down each strip
  ([photos](wiki:Surface_irrigation)).
- **Gardens:** concrete tile laid level 12 in deep, lines 4 ft apart, filled by hose once or twice a week; it drains
  the beds in winter ([VITA, pp. 214–216](lib:village-technology-handbook-vita#page=214)).
- **Here:** sprinklers, furrows, borders, wild flooding and drip are all used, but few soils suit furrow or border
  flooding, which needs nearly level, even ground
  ([Soil Survey, p. 112](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=112)). Only about
  15% of the year's rain falls April to September ([p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)).

### Old mining ditches and millraces

Old ditches cut along hillsides carried water to mines and mills with a gentle, even fall. Cleaned out, one may run
again, but its banks are old fill and it may carry someone's water right *(rule of thumb)*. Old records give flow in
**miner's inches**: 1 cfs is 40 or 50, by state ([USBR, p. 275](lib:usbr-water-measurement-manual#page=275)). A
**millrace** is a small wood or concrete-lined canal from a millpond to a wheel
([DOE, p. 218](lib:doe-microhydropower-handbook-vol-1-part-1#page=218)). Gold was found in the Illinois Valley in 1851, Oregon's first mining area
([Soil Survey, p. 4](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=4)), so many old hillside
ditches here began as mining ditches *(rule of thumb)*; farm ditches came later (the Grants Pass Irrigation District
dates from 1916, same page). In Oregon, **40 miner's inches make 1 cfs**
([USBR, p. 275](lib:usbr-water-measurement-manual#page=275)).

### Water rights and neighbours

- **Two systems** ([DOE Vol 1 Pt 2, pp. 172–173](lib:doe-microhydropower-handbook-vol-1-part-2#page=172)): in the East,
  **riparian rights**: whoever owns the banks may use the water reasonably without injuring others. In the West,
  **prior appropriation**: "the first person to appropriate water and apply it to a beneficial use has first right",
  and later users take what is left. States also keep a minimum flow in the stream
  ([DOE, p. 185](lib:doe-microhydropower-handbook-vol-1-part-1#page=185)).
- **After a collapse,** the old rights still say whose turn it is; ignoring them starts feuds. Keep the papers, agree
  a schedule, measure with a weir, and name one person to run the ditch *(rule of thumb;
  [Community & Barter guide](guide:COMMUNITY-BARTER-GUIDE))*.

**Oregon's rules, while they are enforced** ([OWRD *Water Rights in Oregon*](lib:oregon-owrd-water-rights-in-oregon#page=7)):

- Under Oregon law "all water belongs to the public". With some exceptions, using water from any source needs a permit from OWRD,
  even water flowing past your land ([p. 7](lib:oregon-owrd-water-rights-in-oregon#page=7)).
- Oregon has used prior appropriation since 1909: the oldest right is the last shut off. A right not used for five
  years in a row can be cancelled ([pp. 7–8](lib:oregon-owrd-water-rights-in-oregon#page=8)).
- **No permit is needed** for a spring that never leaves your property, stock water piped from a permitted pond to a
  trough, fish screens and fishways, emergency fire fighting, and rain off a roof
  ([p. 10](lib:oregon-owrd-water-rights-in-oregon#page=10)).
- Each summer the **watermaster** shuts off junior users so senior ones get their water; on some streams by late
  summer only rights from the 1800s get any ([p. 42](lib:oregon-owrd-water-rights-in-oregon#page=42)).

## ⚙️ Water power from a dam or weir
<!-- fold: Millponds and races, kinds of water wheel, and where generators come in -->

- **Layout:** a weir raises the water; a headrace (ditch) carries it along the hillside, gaining height over the creek;
  a pipe or chute drops it to the wheel; a tailrace returns it
  ([NRCan, pp. 19–20](lib:nrcan-micro-hydropower-systems-a-buyers#page=19)). A dam built only for power rarely pays
  ([DOE, p. 56](lib:doe-microhydropower-handbook-vol-1-part-1#page=56)).
- **Water wheels** turn **6–20 times a minute** with great force, run on dirty water and cope with changing flow: good
  for grinding, sawing and pumping ([DOE, p. 39](lib:doe-microhydropower-handbook-vol-1-part-1#page=39)). Consider them
  under 5 kW and 10 ft of drop; ice can wreck them ([NRCan, p. 23](lib:nrcan-micro-hydropower-systems-a-buyers#page=23)).

| Wheel ([GTZ, p. 79](lib:gtz-micro-hydro#page=79); [photos](wiki:Water_wheel)) | How the water drives it | Suits |
|---|---|---|
| **Overshot** | Fills buckets at the top, which "retain water until... below the level of the axle" ([*Shifts and Expedients*, p. 490](lib:shifts-and-expedients#page=490)) | A drop about the wheel's height |
| **Breastshot** | Enters at about axle height | A middling drop |
| **Undershot** | Pushes flat paddles at the bottom | Little drop, plenty of current |

- **Pumping by wire:** a small undershot wheel's crank rocks a frame that pulls a wire back and forth every 3–5
  seconds, working a well pump up to half a mile away ([VITA, pp. 123–125](lib:village-technology-handbook-vita#page=123)).
- **Electricity** needs 720–3,600 turns a minute ([DOE, p. 39](lib:doe-microhydropower-handbook-vol-1-part-1#page=39)),
  so a wheel needs big gearing: "Matching it to a water wheel or wind rotor" in the
  [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE). Most Illinois Valley creeks are closed to hydropower by state rule (see [Start Here](guide:ILLINOIS-VALLEY-START-HERE)).

## 🐟 Salmon, steelhead and fish passage
<!-- fold: Why dams and diversions hurt salmon, fish ladders, screens, and leaving water in the creek -->

- **Salmon and steelhead** spawn in fresh water and live most of their lives in the ocean, so they need a way past every
  dam and weir ([ESHA Pt 2, p. 45](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=45)).
- **A diversion hurts the stretch it dries:** less water there "may affect spawning, incubation, rearing, and the
  passage" of these fish, and "frequent changes from semi-dry to wet" can "ruin aquatic life"
  ([p. 44](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=44)). Leave a steady flow; shade trees,
  gravel and bank shrubs help ([p. 45](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=45)).
- **Fish ladders** ([photos](wiki:Fish_ladder)): most are a stair of pools, each spilling over a low wall
  ([p. 46](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=46)), **10–16 in** of drop between pools;
  salmon jump the walls ([p. 47](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=47)). Put the
  entrance beside the weir, since salmon search round the obstacle; keep the top exit away from the spillway; guard it
  from poachers ([p. 48](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=48)).
- **On a small weir** *(rule of thumb)*: leave a low notch or a sloping rock ramp at one side that always has water,
  and a pool below deep enough to jump from.
- **Screens:** a turbine kills a few percent to over 40% of the fish that pass through. The simplest screen is punched
  steel with 4 mm holes, sloped so fish slide into a trough back to the creek
  ([ESHA Pt 2, p. 49](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=49); [Fish screen](wiki:Fish_screen)).
  Fish led down a ditch are stranded when it shuts *(rule of thumb)*.

**Fish here.** The Rogue and its tributaries carry coho, Chinook and steelhead, more than any Oregon river but the
Columbia ([Soil Survey, p. 117](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=117)). All
Illinois River tributaries, the East and West Forks included, are closed to all angling
([ODFW 2026 regulations, p. 36](lib:odfw-2026-oregon-sport-fishing-regulations#page=36)).

- **Screens:** ODFW gives free help. A screen cleaned by hand must pass water no faster than 0.2 ft a second (so at
  least 5 sq ft of wet screen for each cfs), with round holes no wider than 3/32 in, on diversions under 3 cfs
  ([ODFW *Fish Screening Criteria*, p. 1](lib:oregon-odfw-fish-screening-criteria-for-water-diversions#page=1)).
- **Beavers:** their dams once held back runoff at the heads of Oregon's streams and reared young fish; where beavers
  moved into one dry draw, it became 2 acres of wet meadow with springs below
  ([*Mammals of Oregon*, pp. 273–274](lib:the-mammals-and-life-zones-of-oregon-north-american-fauna-55-bailey-usda-1936#page=273)).
- The salmon weirs of the people who lived here first are in the [Native Skills guide](guide:NATIVE-SKILLS-GUIDE).

## 🛑 Dangers: low dams, failing dams and working in water

### The drowning machine below a low dam

Water pouring over a smooth wall that spans the stream dives to the bottom, and on the surface below, part of it flows
**back upstream** into the falls. Anything caught is rolled under, carried a little way and pulled back
([Weir](wiki:Weir); [Hydraulic jump](wiki:Hydraulic_jump)).

- It can "pull an IP wearing a LPU" (a person in a life jacket) "beneath the surface"; they are "returned to the
  suction hole by the upriver flow, to be pushed under once again", and floating things stay trapped
  ([Air Force AFH 10-644, p. 491](lib:afh-10-644#page=491)).
- **It hides:** "there is no frothing, no obvious curling water, and little noise" (same page); from upstream a low
  dam is just a line on the water. Foam below falls "takes away the buoyancy" ([p. 493](lib:afh-10-644#page=493)).
- **Rules** *(rule of thumb)*: no swimming, wading or boating near a low dam, above or below, least of all in high
  water; carry boats round; never walk the crest. To help someone caught, throw a rope or float from the bank; don't
  go in.
- **If caught:** dive deep and go downstream with the current along the bottom, or swim sideways out the end of the
  roller ([AFH 10-644, p. 491](lib:afh-10-644#page=491)). Swept along, face downstream with your feet out in front to
  fend off rocks, and steer clear of churning water ([Army TC 3-97.61, p. 350](lib:tc-3-97-61#page=350)). Oregon's boating handbook warns that low-head dams "are difficult to see and can trap paddlers and swimmers": know
  where they are and always carry your boat around
  ([OSMB, pp. 13–14](lib:osmb-experience-oregon-boating-2026-handbook#page=13)).

### When a dam may fail

See "Warning signs at a dam" above. In a flood below any dam, go to high ground **on foot, right away**
([FEMA, p. 52](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=52)), not along the creek
road *(rule of thumb)*; more in the [Floods guide](guide:FLOODS-STORMS-HEAT-GUIDE).

### Working in and near water

- **Current:** its force "is most often underestimated" ([Army TC 3-97.61, p. 343](lib:tc-3-97-61#page=343)). Over 5 ft
  a second is swift; wade only knee-deep or less ([p. 345](lib:tc-3-97-61#page=345)). Post a lookout upstream for logs
  and a helper downstream with a rope ([p. 351](lib:tc-3-97-61#page=351)); wear a life jacket and never work alone
  *(rule of thumb)*.
- **Intakes:** whirlpools at an intake draw trash in
  ([ESHA, p. 59](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=59)) and can pin a hand or a child
  to a pipe mouth or grate: close the headgate before reaching in *(rule of thumb)*. Watch for snakes in the leaves
  ([Practical Action, p. 13](lib:operation-and-maintenance-of-community-micro#page=13)).
- **Undercut banks:** water runs deep and strong on the outside of bends ([TC 3-97.61, p. 344](lib:tc-3-97-61#page=344)),
  hollowing the bank until it drops. Stay back from the lip, and never dig into the foot of a bank or dam *(rule of thumb)*.
- **Children:** in one Australian study, 78% of drownings of farm children under 5 were in "farm dams and irrigation
  channels" ([WHO *Child Injury*, p. 85](lib:world-report-on-child-injury#page=85)). Fences or banks by ponds, and
  covers on wells, work ([p. 86](lib:world-report-on-child-injury#page=86)).

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Falls: "not too dangerous on a two- or three-foot drop" ([AFH 10-644, p. 493](lib:afh-10-644#page=493)) | A smooth low dam across a stream makes a roller that holds people in life jackets ([p. 491](lib:afh-10-644#page=491)). Keep clear of every low dam |
| Pond dam: "The bottom is made tight with brush and clay" ([*Handy Farm Devices*, p. 172](lib:handy-farm-devices#page=172)) | Brush rots into leak paths *(rule of thumb)*. Clean clay in damp, rammed 8-in layers ([WHO *Vector Control*, p. 137](lib:vector-control-methods#page=137)), keyed into firm ground ([ESHA, p. 52](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=52)) |
| Kerosene on ponds against mosquitoes, "one ounce... for 15 square feet" ([*Household Discoveries*, p. 314](lib:household-discoveries#page=314)) | Not on water stock or people drink *(rule of thumb)*. Drain puddles, keep ditches flowing, let small fish eat the larvae ([WHO *Vector Control*, pp. 126, 137](lib:vector-control-methods#page=126)) |
| Copper salts at 15–30 parts per million in ditches to kill snails ([VITA, p. 183](lib:village-technology-handbook-vita#page=183)) | It poisons the water downstream *(rule of thumb)*, and the same page found it worked poorly beyond small pools. Vary the level or dry the ditch instead (same page) |
| Kerosene or fuel oil in a weir's stilling well against ice ([USBR, p. 86](lib:usbr-water-measurement-manual#page=86)) | The same page: "only nontoxic, environmentally safe oils" |

## 🖼️ Pictures & diagrams

Look before you build. 🖼️ = drawings in the books on this drive; the other links are photos in the offline Wikipedia.

- **Dams:** boulder and gabion weirs, an earth dam's core, a gravity dam's forces — [🖼️ ESHA, pp. 52–53](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=52); spillways, [🖼️ p. 55](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-1#page=55); a good site, [🖼️ VITA, p. 122](lib:village-technology-handbook-vita#page=122); [Spillway](wiki:Spillway); [Internal erosion](wiki:Internal_erosion)
- **Timber dams:** tongue-and-groove and log crib dams, priming planks — [🖼️ DOE, pp. 92–95](lib:doe-microhydropower-handbook-vol-1-part-1#page=92); a 1912 plank pond dam, [🖼️ *Handy Farm Devices*, p. 171](lib:handy-farm-devices#page=171) (but see the table above)
- **Earthmoving:** the fresno scraper — [🖼️ VITA, pp. 190–194](lib:village-technology-handbook-vita#page=190); [Riprap](wiki:Riprap)
- **Measuring weirs:** kinds and proportions — [🖼️ USBR, pp. 89–90](lib:usbr-water-measurement-manual#page=89), [🖼️ p. 60](lib:usbr-water-measurement-manual#page=60); details and the measuring post, [🖼️ DOE, pp. 91, 96](lib:doe-microhydropower-handbook-vol-1-part-1#page=91); [🖼️ NCAT, p. 5](lib:ncat-attra-micro-hydro#page=5)
- **Diversion weirs:** rock fill to Tyrolean, a stake weir — [🖼️ GTZ, pp. 29–31](lib:gtz-micro-hydro#page=29); wing weirs and a gabion weir, [🖼️ DOE, pp. 182–183](lib:doe-microhydropower-handbook-vol-1-part-1#page=182); [Gabion](wiki:Gabion)
- **Flumes:** long-throated and Parshall — [🖼️ USBR, pp. 118–119](lib:usbr-water-measurement-manual#page=118); [Parshall flume](wiki:Parshall_flume)
- **Ditches:** draining pools right and wrong — [🖼️ WHO *Vector Control*, p. 127](lib:vector-control-methods#page=127); a hillside channel and its spillways, [🖼️ GTZ, pp. 36, 43](lib:gtz-micro-hydro#page=36); stoplog checks and a skimmer, [🖼️ DOE, pp. 219–220](lib:doe-microhydropower-handbook-vol-1-part-1#page=219); [Sluice](wiki:Sluice)
- **Irrigation:** siphon tubes and ditch-to-furrow pipes — [🖼️ VITA, p. 213](lib:village-technology-handbook-vita#page=213); [🖼️ USBR, p. 259](lib:usbr-water-measurement-manual#page=259); [Surface irrigation](wiki:Surface_irrigation)
- **Water power:** an old mill site and a siphon over a dam — [🖼️ DOE, pp. 57–58](lib:doe-microhydropower-handbook-vol-1-part-1#page=57); kinds of wheel, [🖼️ GTZ, pp. 79–81](lib:gtz-micro-hydro#page=79); [🖼️ *Shifts and Expedients*, p. 490](lib:shifts-and-expedients#page=490); a wheel pumping by wire, [🖼️ VITA, pp. 124–126](lib:village-technology-handbook-vita#page=124); [Mill race](wiki:Mill_race)
- **Fish:** fish ladders — [🖼️ ESHA Pt 2, pp. 46–48](lib:esha-laymans-guidebook-develop-a-small-hydro-site-part-2#page=46); [Steelhead](wiki:Steelhead); [Coho salmon](wiki:Coho_salmon)
- **Danger:** the suction hole below a drop, and falls — [🖼️ AFH 10-644, pp. 492–493](lib:afh-10-644#page=492); [Hydraulic jump](wiki:Hydraulic_jump)
- **Local:** dams in Josephine and Jackson counties and their hazard — [🖼️ county hazard plan, p. 289](lib:josephine-county-multi-jurisdictional-natural-hazard-mitigation-plan-josephine-county-2022#page=289)

---

## 🔗 Related guides

- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) — creek hydro: head, pipes, turbines
- [Water Wells, Pumps, Springs & Cisterns](guide:WATER-WELLS-GUIDE) — springs, cisterns, ram pumps
- [Masonry & Roads](guide:MASONRY-ROADS-GUIDE) — concrete, road ditches, culverts
- [Practical Math](guide:PRACTICAL-MATH-GUIDE) — water flow and pressure, laying out a slope
- [Floods, Ice Storms & Heat Waves](guide:FLOODS-STORMS-HEAT-GUIDE) — when the water comes
- [How Town Water and Sewer Work](guide:TOWN-WATER-SEWER-GUIDE) — a town's water and sewer systems
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — generators for a wheel or turbine
- [Wildfire](guide:WILDFIRE-GUIDE) — pond water for fire fighting
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — beaver, muskrat and fish
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local creeks, water and fish
- [Building Soil](guide:GROWING-SOIL-GUIDE) — swales, keyline and keeping water in the soil
