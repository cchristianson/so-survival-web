# 🕯️ Light Without the Grid: Candles, Lamps & Lamp Oil

How to make your own light when the power is off for good and the kerosene runs out: tallow and beeswax candles,
wicks, rushlights, which oils and fats burn in a lamp, lamps made from a jar or a can, kerosene lamps while the
kerosene lasts, more light from a small flame, and staying safe from fire, fumes and poisoning. It goes deeper than
"Fire and light without stores" in the [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE). The books are in
`Homestead-Skills\Soap-Candles` (Practical Action's *Candlemaking*, Gilbert White's rushlight letter),
`Homestead-Skills\Household-Make-Do` (*Household Discoveries*, *Shifts and Expedients*, Seton, *Rural Lighting*) and
`Nuclear-Radiation\Shelter-and-Protection` (Kearny's tested jar lamps). *Household Discoveries* ("HD" below) is
cited by the PDF's page number; the number printed on the page is 10 higher.

> ### The short version
> - **Cooking oil or fat in a jar is the safest light you can make.** A cotton wick **slightly less than ⅛ in**
>   thick, the flame **just above the oil**, burns about **1 oz of fat in 8 hours** ([Kearny, p. 104](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=104)).
>   **Never kerosene, diesel or gasoline in an open lamp** ([ORNL-4941, p. 309](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=309)).
> - **Never water on burning wax, fat or oil:** heat off, then a metal lid, damp cloth, wool rug, sand or earth.
>   **Melt wax in a pot standing in water, never dry over a flame**; above about **150 °C (300 °F)** it can catch
>   fire by itself ([Practical Action, p. 3](lib:practical-action-candlemaking-technical-brief#page=3)).
> - **Dip candles at about 70 °C (158 °F): 3–4 seconds in, 1–4 minutes to cool.** A wick too thick drips; too
>   thin drowns ([Practical Action, pp. 2–5](lib:practical-action-candlemaking-technical-brief#page=2)).
> - **Rushlights stretch fat furthest:** about **6 lb of grease dips 1 lb of rushes** (over **1,600** lights), and
>   **1½ lb of rushes** lit a working family for a year ([White, pp. 206–207](lib:white-the-natural-history-of-selborne-1789#page=206)).
> - **Kerosene kills small children.** Dark, marked, closed cans out of reach, **never a drink bottle**; if
>   swallowed, **don't make them vomit** ([*Where There Is No Doctor*, p. 29](lib:where-there-is-no-doctor-10-first-aid#page=29)).
> - **Every flame makes carbon monoxide and soot.** Let air through; put lamps out before sleep
>   ([FM 21-76, p. 182](lib:fm-21-76-army-survival-manual#page=182)). **No flame in a damaged house until you know
>   there is no gas leak** ([FEMA, p. 183](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=183)).
> - **Hang lamps from an overhead wire, clear of walls, curtains and beds** *(rule of thumb)*.

---

## 🧭 Which light for which job

Flames "produce more heat than light" ([*Rural Lighting*, p. 2](lib:practical-action-rural-lighting-technical-brief#page=2));
a candle gives about 1 lumen (table in the Make-Do guide). **Use LEDs first, while batteries and panels last**
([Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE)): a modern 1-watt LED matches **80 or more candles**
*(arithmetic)*. Then kerosene for close work while it lasts, fat jar lamps for all-night light, candles to carry and
read by, rushlights for everyday *(rule of thumb)*, and **daylight**: White's working families burned no candles in
summer "because they rise and go to bed by daylight" ([White, p. 207](lib:white-the-natural-history-of-selborne-1789#page=207)).
**Per pound of fat**, a tiny jar lamp runs about **128 hours** and White's rushlights about **130 hours** (1,600
rushes at half an hour each from 6 lb of grease) *(arithmetic)*; a small store candle in a drafty room lasted "not
much more than two hours" (White, p. 207).

## 🐖 Fat and wax: where it comes from and how much

**Lard:** **9–13%** of a meat-type hog's live weight, **14–18%** of a fat hog's; one meat-type hog "produces as
much pork and lard as a family of two consumes in a year" ([USDA FB 2138, p. 6](lib:pork-slaughtering-cutting-preserving-on-the-farm-usda-fb2138#page=6)).
A 250-lb meat-type hog gives about **22–32 lb** *(arithmetic)*. Lard is soft: burn it in lamps, or harden it.

**Tallow** (beef, mutton, deer, elk): "the hard fat and tallow of any animal that may be killed should be
preserved" for candles, if it can be spared from greasing axles ([*Shifts*, p. 93](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=93)).
Deer and elk fat is "highly saturated" (it sets hard) and usually trimmed off the meat ([NDSU, p. 5](lib:ndsu-wild-side-of-the-menu-1-care-and-cookery#page=5)):
save it. The library has no figure for tallow per steer or sheep. **Render it first** (chill, render within a week,
slow heat, no copper, strain into jars): "Salt, sweeteners and fat" in the [Food From Scratch guide](guide:FOOD-FROM-SCRATCH-GUIDE).

**Beeswax** (rendering: "Beeswax: rendering and uses" in the [Bees guide](guide:BEES-GUIDE#beeswax-rendering-and-uses)):
bees eat about **8 kg of honey to make 1 kg of wax** ([FAO, p. 106](lib:bees-and-their-role-in-forest-livelihoods-top-bar-hives-honey-and-wax-fao-nwfp-19-2009#page=106)).
Frame hives give about **75 parts honey to 1 of wax**, top-bar hives about **10 to 1** ([p. 107](lib:bees-and-their-role-in-forest-livelihoods-top-bar-hives-honey-and-wax-fao-nwfp-19-2009#page=107)).
Unmanaged colonies seldom give over **25–30 lb** of surplus honey, well-managed ones over **100 lb**
([USDA AH 335, p. 70](lib:beekeeping-in-the-united-states-usda-ag-handbook-335-1980#page=70)). **Estimate
*(arithmetic)*:** a top-bar hive giving 30–100 lb of honey yields about **3–10 lb of wax a year**; a frame hive
giving 100 lb, only about **1⅓ lb**. Pure beeswax chewed "does not stick to the teeth", and it keeps for years
([FAO, p. 108](lib:bees-and-their-role-in-forest-livelihoods-top-bar-hives-honey-and-wax-fao-nwfp-19-2009#page=108)).
Wax may earn more as salve ([p. 129](lib:bees-and-their-role-in-forest-livelihoods-top-bar-hives-honey-and-wax-fao-nwfp-19-2009#page=129)): burn tallow and rushes every day *(rule of thumb)*.

**Bayberry wax:** boil the autumn berries in water and skim off the wax that floats; it sets into "a cloudy green
mass" for candles, "either pure or mixed with some common tallow" ([Saunders, p. 276](lib:useful-wild-plants-of-the-united-states-and-canada-saunders-1920#page=276)).
Those are eastern shrubs; our coast's Pacific wax myrtle ([Myrica californica](wiki:Myrica_californica)) isn't in
the library, so try a small batch the same way *(rule of thumb)*. **A year's needs *(arithmetic)*:** one jar lamp
**4 hours a night** burns about **11 lb of fat a year**; White's family's rushes took about **9 lb of grease**.

## 🧈 Cleaning and hardening tallow

Candle tallow "must be clear-grained fat" ([HD p. 97](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=97)).
**Simple cleaning** ([HD p. 179](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=179)):
render beef suet, mutton tallow or pork scraps, strain through coarse linen, and boil the fat in water with a
little **salt or alum**. Cool it, lift off the cake of clean fat, scrape off the soft, dirty underside (p. 97), and
**dry the cake well**, "or it will not keep sweet". Salty bacon-pot skimmings: set them "in a warm oven" so the salt
sinks ([White, p. 206](lib:white-the-natural-history-of-selborne-1789#page=206)).

**Stronger cleaning** (HD p. 97): boil **2–3 hours** in weak potash or soda lye (wood-ash lye: "Soap from fat and
ashes" in the Make-Do guide), skimming; next day scrape the soft part off the cake; repeat **two or three days**,
the last day in water with **1 lb alum and 1 lb saltpeter per 30 lb of tallow**. **Lye burns:** gloves, goggles.

**Hardening.** Even 3 parts mutton to 1 part beef tallow is "likely to be soft and often turn yellow, especially in
summer time" (HD p. 97). So:
- Stir **1 lb of alum**, dissolved in hot water, into each **5 lb of tallow** as it melts (p. 97); or melt **1¼ lb
  mutton tallow, 8 oz beeswax and 4 oz alum** together, "as hard and durable as wax" (p. 97; leave out the camphor
  the book adds, see the old-advice table).
- **2 parts beeswax to 1 part tallow** looks like a wax candle ([HD p. 99](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=99)).
- **Lard candles:** 10 lb lard with 1 lb saltpeter and 1 lb alum dissolved in about half a pint of boiling water;
  boil until the water is gone, and skim ([HD pp. 97–98](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=97)).
- **Salvaged paraffin:** about **10% stearine** hardens it and frees it from moulds; **5% beeswax** makes it burn
  longer ([Practical Action, pp. 1–2](lib:practical-action-candlemaking-technical-brief#page=1)).

**Pots and heat** ([Practical Action, pp. 3–4](lib:practical-action-candlemaking-technical-brief#page=3)):
aluminium or stainless steel; iron except for beeswax; **no copper or brass**; a jam or sugar thermometer; a
**double boiler** whose water must not "boil away". Use an open fire only when nothing else will do; lid within reach.

![A double boiler: the pot of wax stands inside a larger pot of water, with the heat under the water](img:LIGHTING-GUIDE/double-boiler.png)
*Melt wax in a pot standing in hot water, never dry over a flame ([Practical Action, p. 3](lib:practical-action-candlemaking-technical-brief#page=3)).*

## 🧵 Wicks: making, pickling and sizing

**Cotton only:** braided cotton strands, "not cotton thread", and no **lead-core** wicks ([Practical Action, p. 2](lib:practical-action-candlemaking-technical-brief#page=2)).
Cotton string or cloth strips work, but "**Nylon cannot be used**" ([FAO, p. 130](lib:bees-and-their-role-in-forest-livelihoods-top-bar-hives-honey-and-wax-fao-nwfp-19-2009#page=130)).
Use "as many strands ... as the size of the candle requires" ([HD p. 97](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=97));
unravelled cotton yarn and old cotton knits are the usual source *(rule of thumb)*.
- **Twisted:** strands twice the length you need, twisted slightly and doubled so the halves twist together
  ([*Shifts*, p. 93](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=93)). **Braided:** three
  even bundles, braided firmly *(rule of thumb)*.
- **Self-trimming:** braid in **one strand a little shorter** than the rest, pulled tight, so the wick bends out and
  burns off its own tip (HD p. 97), curling "into the hottest (outer) part of the flame" (Practical Action, p. 2).

**Pickling (soaking) wicks** makes them burn cleaner (HD p. 97). The safe recipes from that page:
- **Lime and saltpeter:** **½ lb lime and 2 oz saltpeter in 1 gallon of water.** Soak **15–20 minutes**, then hang
  in the sun until thoroughly dry. Lime burns skin: wear gloves.
- **Turpentine:** soak, dry thoroughly (outdoors, away from flame *(rule of thumb)*), and use a wick "smaller than
  ordinary".
- **Or skip it:** plain cotton primed in hot wax (Dipping, step 3) works *(rule of thumb)*. Don't use the book's
  third recipe: chloride of lime (bleach) with an ammonia salt gives off poison gas (Make-Do guide).

**Matching the wick to the candle** (Practical Action, p. 2): "the larger diameter the candle, the thicker the
wick". **Too thick:** the flame melts wax too fast and it **drips**. **Too thin:** it will "'drown' in its own wax
pool". **Beeswax needs a thicker wick than tallow.** "Some trial and error testing is usually necessary": burn a
test candle an hour out of drafts. You want a steady flame, the tip curling and glowing, and a pool that nearly
reaches the rim without spilling. Spills: fewer strands. Shrinking flame: more. Write down what works *(rule of thumb)*.

![Three candles: the right wick gives a steady flame with the tip curling over and a pool nearly to the rim; a wick too thick gives a big flame and wax dripping down the sides; a wick too thin gives a small flame drowning in its pool](img:LIGHTING-GUIDE/wick-right-too-thick-too-thin.svg)
*Burn a test candle: fewer strands if it drips, more if the flame drowns (a diagram drawn for this guide).*

## 🫕 Dipping candles step by step

**You need:** a pot of wax or tallow **deeper than the candles are long**, standing in a pot of hot water; a
thermometer; a rod; cotton wicks; a smooth board; a cool place to hang them.
1. **Hang the wicks.** Cut each twice the candle length plus a few inches and hang it over the rod to make a **pair**
   ([Practical Action, p. 6](lib:practical-action-candlemaking-technical-brief#page=6)), half a dozen to a rod
   (*Shifts*, p. 93), "a little more than twice the thickness of a candle" apart ([HD p. 98](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=98)).
2. **Heat to about 70 °C (158 °F),** "a good starting point" ([Practical Action, p. 4](lib:practical-action-candlemaking-technical-brief#page=4)),
   "over a slow fire, but do not let it burn" (HD p. 98).
3. **Prime.** First dip only: leave the wicks in **about 2 minutes** to drive out air and moisture. Draw each
   through your fingers to strip lumps, pull straight, and let harden (Practical Action, p. 4; HD p. 98).
4. **Dip for 3–4 seconds** and lift out smoothly ([Practical Action, p. 5](lib:practical-action-candlemaking-technical-brief#page=5)).
   **Touch the bottoms gently on a smooth board** to take off the drip (HD p. 98).
5. **Cool 1–4 minutes**, depending on the room (Practical Action, p. 5), in cool moving air if you can (HD p. 98).
6. **Repeat** until thick enough. With several rods, dip "in rotation" so each cools in turn (*Shifts*, p. 93).
7. **Watch the wax.** Too hot "will melt off more wax from the candles than it adds"; too cool, "a fine skin will
   form" and they go lumpy (Practical Action, p. 5).
8. **Finish:** hang overnight, cut the pairs apart, trim the bases with a **warmed knife** ([*Shifts*, p. 94](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=94)).

![Hand dipping in four steps: priming the wicks in the wax, dipping again and again to build thickness, the final dip, and hanging the pair of candles to cool](img:LIGHTING-GUIDE/hand-dipping-steps.png)
*Prime the wicks, dip to build the candles up, give a final dip, hang them to cool ([Practical Action, p. 5](lib:practical-action-candlemaking-technical-brief#page=5)).*

**Short of fat?** Throw it into **a bucket of hot water**, where it "will soon melt and float upon the surface",
and dip through that layer (*Shifts*, p. 93). It takes far less fat than a deep pot *(rule of thumb)*.

## 🫙 Moulds, pouring and rolled beeswax candles

**Tin moulds** came "in frames of 6 or 13 tubes" ([HD p. 96](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=96)).
Candles are moulded **upside down**: the tip forms at the bottom, where a small hole takes the wick.
1. **Prime the wick** ([Practical Action, p. 7](lib:practical-action-candlemaking-technical-brief#page=7)). Loop one end
   over a stick across the top; thread the other down through the hole with a large darning needle (HD p. 98).
2. Knot it under the hole (HD p. 98), or seal the hole with clay and tie the top to a pencil so the wick is tight
   and centred (Practical Action, p. 7).
3. **Pour at about 90 °C (194 °F)** into the centre, and **tap the mould** to free air bubbles (p. 7).
4. Fill the hollow that forms round the wick as it cools, but "Do not fill beyond the original wax level"
   ([p. 8](lib:practical-action-candlemaking-technical-brief#page=8)).
5. When quite cold, pull them out by the wick loops (HD p. 98). If one sticks, cool the mould in cold water (p. 8).

![Moulding a candle in five steps: thread the wick up through the mould, tie it to a stick and seal the hole, pour the wax, fill the hollow that forms, then remove the sealant and pull the candle out](img:LIGHTING-GUIDE/moulding-steps.png)
*Thread and tie the wick, seal the hole, pour, fill the hollow, then pull the candle out ([Practical Action, p. 8](lib:practical-action-candlemaking-technical-brief#page=8)).*

**Pipe mould:** *Shifts* used an 8–10 in piece of gun barrel; any straight, smooth metal pipe works. A stick
through the wick loop across the top, the wick centred through a cork disc at the bottom, the end stopped; pour,
and when cool "warm the mould slightly and the candle will draw out" (*Shifts*, p. 93). **Split-tube mould:**
bamboo or a plant stem split lengthwise and tied shut, the wick centred by "small sticks"; open it when the wax is
solid ([FAO, p. 130](lib:bees-and-their-role-in-forest-livelihoods-top-bar-hives-honey-and-wax-fao-nwfp-19-2009#page=130)).

**Beeswax** is "soft and sticky ... difficult to mould in rigid moulds" (Practical Action, p. 2). Instead:
- **Pour:** ladle wax at about **70 °C** down each hanging wick, turning it slowly; drips fall back into the pot
  (Practical Action, p. 6). Roll smooth between "two paddles of hard wood previously soaked in water" (HD p. 98).
- **Roll** (FAO, p. 130): pour hot beeswax over a **metal plate smeared with soapy water**; it sets at once into a
  thin sheet that lifts off. Roll it tight round a primed wick. Beeswax is pliable at **35–40 °C (95–104 °F)** and
  brittle below **18 °C (64 °F)** ([FAO, p. 108](lib:bees-and-their-role-in-forest-livelihoods-top-bar-hives-honey-and-wax-fao-nwfp-19-2009#page=108)):
  roll it warm, by the stove in winter *(rule of thumb)*.
- **Containers:** tins and pottery are ideal, glass may crack, and "beeswax is perfect" ([Practical Action, p. 9](lib:practical-action-candlemaking-technical-brief#page=9)).

📚 **Go deeper:** [Practical Action *Candlemaking*, pp. 4–9](lib:practical-action-candlemaking-technical-brief#page=4) — dipping, pouring, moulding and container candles, with step drawings; [HD pp. 96–99](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=96) — wicks, frames, moulds and tallow recipes.

## 🛠️ Why candles drip, smoke or drown

The flame melts a pool of wax, the wick soaks it up, and the heat turns it to vapour; a well-made candle burns down
evenly "and dripping will not occur" ([Practical Action, p. 1](lib:practical-action-candlemaking-technical-brief#page=1)).

| Trouble | Likely cause | Fix |
|---|---|---|
| Drips, runs down one side | Wick too thick ([Practical Action, p. 2](lib:practical-action-candlemaking-technical-brief#page=2)); a draft; soft fat | Thinner wick; screen it, since candles "waste rapidly unless screened from the wind" ([*Shifts*, p. 94](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=94)); harden the tallow |
| Drips and sputters | Warm, soft candle | Chill on ice **2–3 hours** (wick off the ice); rub **a pinch of salt** into the wick ([HD p. 99](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=99)) |
| Flame shrinks and drowns | Wick too thin | More strands; pour off the pool and relight *(rule of thumb)* |
| Smoke and soot | Long, charred wick; dirty fat | Trim the wick; clean the tallow; beeswax candles "do not smoke as most other candles do" ([FAO, p. 130](lib:bees-and-their-role-in-forest-livelihoods-top-bar-hives-honey-and-wax-fao-nwfp-19-2009#page=130)) |
| Wick smoulders when put out | Blown out downward | Hold it above your mouth and blow **upward** (HD p. 99) |
| Hard to light | Match held to the top | Light the **side** of the wick (HD p. 99) |
| Holes or a sunken top | Air bubbles, shrinking | Tap the mould; fill the hollow ([Practical Action, p. 7](lib:practical-action-candlemaking-technical-brief#page=7)) |

**Storing:** beeswax changes little over time (FAO, p. 108). Tallow softens and yellows in summer (HD p. 97): keep
candles cool and dark, in the root cellar through our hot, dry summers *(rule of thumb)*; bleach yellowed ones in
"dew, air, and sunshine" (HD p. 99). Keep tallow, candles and fat in **lidded tins**: mice eat them and grease
draws bears *(rule of thumb)*. Keep wicks and matches dry in a closed jar ([Kearny, p. 104](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=104)).

## 🌾 Rushlights: Gilbert White's measured method

A rushlight is the white pith of a rush, held up by one strip of its skin, dipped in fat and burned like a thin
candle ([Rushlight](wiki:Rushlight)). Gilbert White weighed, counted and timed them in Letter 26 of *The Natural
History of Selborne* (1775). He used "the common soft rush", found "in most moist pastures, by the sides of streams,
and under hedges", best "in the height of summer", and "the largest and longest are best"
([White, p. 205](lib:white-the-natural-history-of-selborne-1789#page=205)). Soft rush ([Juncus effusus](wiki:Juncus_effusus))
grows in wet pastures and ditches around the valley *(rule of thumb)*.

**Making them** ([White, p. 206](lib:white-the-natural-history-of-selborne-1789#page=206)):
1. **Cut the longest rushes and put them in water at once**, "for otherwise they will dry and shrink, and the peel
   will not run".
2. **Peel off the green skin**, leaving "one regular, narrow, even rib from top to bottom" to hold up the pith.
3. **Bleach and dry:** lay them on the grass to "take the dew for some nights", then dry them in the sun.
4. **Dip them in "scalding" fat** (a knack learned by practice): bacon-pot skimmings, salt settled out in a warm
   oven. "A little wax" makes them cleaner and burn longer; "mutton-suet would have the same effect".

**White's numbers:** "about six pounds of grease will dip a pound of rushes" (p. 206). A pound of dry rushes held
"upwards of one thousand six hundred" ([p. 207](lib:white-the-natural-history-of-selborne-1789#page=207)). A rush
**2 ft 4½ in** long burned "three minutes short of an hour", a longer one an hour and a quarter (p. 206), with "a
good clear light" (p. 207). "One pound and a-half of rushes completely supplies his family the year round", since
working people went to bed by daylight in summer (p. 207). *(Arithmetic:)* that is about **2,400 rushlights** and
**9 lb of grease** a year; at White's cautious half hour each, **1,200 hours**, over 3 hours a night on average.

**Burning them** *(rule of thumb)*: hold the rush slanting in a clip or split stick on a heavy base, over a tin or a
dish of sand to catch drips; move it up as it burns; never leave one alight in an empty room. Leave **two** ribs of
skin on and it burns slower and dimmer, like the old "watch-lights" (White, p. 207): a night light.

![Making a rushlight: cut long soft rushes and keep them in water; peel off the green skin leaving one narrow rib holding up the white pith; dip in hot fat; burn slanting in a holder on a heavy base over a dish of sand](img:LIGHTING-GUIDE/making-a-rushlight.svg)
*Leave one rib of skin to hold up the pith, and burn the rush slanting over sand (a diagram drawn for this guide).*

## 🫒 Lamp oils: what burns and what doesn't

**Good:** kitchen fats, "lard, bacon grease, vegetable shortening, or vegetable oil" ([ORNL-4941, p. 44](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=44)),
and **non-drying oils** like olive oil, which "become rancid and thicken ... but do not dry up"
([HD p. 366](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=366)). HD names lard
oil, neat's-foot oil (boiled from cattle feet), olive, colza and rape-seed oil together ([p. 367](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=367)).
Animal and fish oils are "very similar to the nondrying vegetable oils", though fish oil can smell "very offensive"
(pp. 366–367); Northwest peoples burned the [eulachon](wiki:Eulachon), or candlefish, for light (*Shifts*, p. 94).
Hard fats like tallow need a soft-fat lamp whose flame warms the dish (below).

**Not good:** **drying oils** like linseed (flax) "oxidize ... into a hard, resinous varnish" (HD p. 366): expect a
gummed, crusted wick. The book doesn't test this in a lamp; it follows from the varnish *(rule of thumb)*.

**The catch with vegetable oil:** it is safe, "but their disadvantage is that they do not rise in the wick-carrier"
([WHO, p. 106](lib:world-report-on-child-injury-prevention-drowning-burns-falls-poisoning-who-unicef-2008#page=106)).
So keep the wick **short**, the flame **just above the oil** (ORNL-4941, p. 309), or float it. As the oil drops, top
it up or lower the wick holder *(rule of thumb)*.

**Clarifying and storing:** let oil **settle** a few days and pour off the top; to **dry** it, boil gently, stand,
filter through cloth and heat briefly to **100 °C (212 °F)** ([*Oil Extraction*, pp. 5–6](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=5)).
Wet oil sputters *(rule of thumb)*. For rancid or smelly animal oil, filter it through a burlap bag lined with flannel
with charcoal quilted between, or stir clean charcoal lumps into it over a slow fire and strain (HD p. 367). Store it
"in lightproof, airtight and moisture-proof containers in a cool place", never copper ([*Oil Extraction*, p. 6](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=6)),
and don't leave lamps filled for months (Kearny, p. 104). Burn the old oil, eat the fresh *(rule of thumb)*.

**Pressing oil:** rape seed is **40–45%** oil, mustard **25–45%**, sunflower and sesame **25–50%**, safflower **30%**
([*Oil Extraction*, p. 1](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=1)). **Dry and clean** the seed,
throw out mouldy ones, dehull sunflower (p. 1); soft seeds and nuts can be hand-pressed, hard ones need a ram press
([p. 2](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=2)). A **cage press** (a perforated metal cage under
a plunger) can be driven by a screw or a car jack: raise the pressure **slowly**, and beware a leaking hydraulic jack's
"poisonous hydraulic fluid" ([p. 3](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=3)). Nut meats: boil,
add salt, skim (p. 2). Every pint burned is a pint not eaten: press for food first *(rule of thumb)*.

### Never gasoline or mixed fuels in an open lamp
- The jar lamps are safe only with kitchen fats: "DO NOT USE KEROSENE, DIESEL FUEL, OR GASOLINE — USE ONLY FATS OR
  OILS OF THE KINDS FOUND IN THE KITCHEN" (ORNL-4941, p. 309). Knocked onto dry paper, the flame goes out by itself
  when the fuel is "a cooking oil or fat" and the wick is small (Kearny, p. 104).
- Good kerosene gives off no burnable vapour below **110 °F** ([HD p. 91](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=91)).
  Gasoline does even in freezing weather, so a little of it makes kerosene far more dangerous, and fuel mixed into
  cooking oil spills and burns like fuel *(rule of thumb)*. Never use a can that ever held gasoline (WHO, p. 106).
- **Test doubtful kerosene** outdoors ([HD p. 92](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=92)):
  a tablespoon of it on a cup of water heated to **110 °F**, and a lit match. "If the oil takes fire it is unsafe."

## 🪔 Lamps you can make

**Fuel use:** with the smallest practical wick, about **1 oz of oil or fat in 8 hours** ([Kearny, p. 104](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=104)),
or "about 3 ounces ... in 24 hr" ([ORNL-4941, p. 308](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=308)).
**1 lb of fat** lasts about **128 hours**, five days and nights *(arithmetic)*. **Wicks:** cotton string, cloth or rag;
in the bush, plant fibres, beaten bark or peeled rush ([*Shifts*, p. 91](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=91)).
Flat kerosene wicks: "Save old felt hats", or hem a strip of cotton stocking or flannel **about three times the
burner's width** ([HD pp. 139–140](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=139)).

### Wire-stiffened jar lamp
From Oak Ridge's tested drawing ([🖼️ ORNL-4941, p. 309](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=309)):
1. **Base:** two bent nails, about **½ in shorter than the jar is wide**, tied one across the other so it won't rock.
2. **Wick:** cotton string "slightly less than ⅛-in. in diameter". Tie a fine wire (window-screen wire) round the
   nails at its middle, and wind its ends in opposite directions up the string so it stands stiff.
3. **Oil:** fill the jar **no more than half full** of cooking oil or fat, with the "flame from end of wick ... just
   above oil surface".
4. **Reflector:** foil **⅔ of the way around** the jar and under its bottom. **Hang** it on light wire by a loop
   "large enough for finger".
5. **Light** it with a match tied to a stick. **To put it out, drip oil on the wick.** Keep spare wire and string.

![Oak Ridge's wire-stiffened-wick lamp: a glass jar no more than half full of cooking oil, a cotton wick stiffened with fine wire standing on two crossed bent nails, the flame just above the oil, and a wire loop to hang it by](img:LIGHTING-GUIDE/wire-stiffened-jar-lamp.png)
*Oak Ridge's tested lamp: kitchen fat only, the jar no more than half full, the flame just above the oil ([ORNL-4941, p. 309](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=309)).*

### Floating-wick lamp
From the drawing ([🖼️ ORNL-4941, p. 310](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=310)):
1. A block of **soft pine ½ in narrower than the inside of the jar** (2½ in for a 3-in jar), about **¾ in** high.
2. A V-notch across the top: **5 even saw cuts**, then whittle it out, leaving about 3/16 in under it. Bore a snug
   wick hole through the bottom of the notch with a knife point, from both sides.
3. A wick **1/16–3/32 in** thick (thin cotton string or twisted threads). Float it on oil in a half-full jar with the
   same reflector. **When not in use for days, take the wood out of the oil.**

![Oak Ridge's floating-wick lamp: a notched soft-pine block with a thin cotton wick through it floats on cooking oil in a half-full glass jar hung from light wire](img:LIGHTING-GUIDE/floating-wick-lamp.png)
*A notched pine block floats the wick; take the wood out of the oil when the lamp sits unused for days ([ORNL-4941, p. 310](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=310)).*

*Shifts* floats a wick on "bottle wire and three bits of cork": "half an inch of wick is enough to last all night"; but
rats can upset a lamp and carry off the burning wick (p. 93).

### Hunter's lamp and soft-fat lamps
- **Hunter's lamp** (slut lamp; Seton's names are "slot-lamp, grease-jet, hunter's lamp"): cotton cloth or twisted
  rag in a clam shell of oil or melted grease. Better, push the wick through a hole in **a thin, flat stone** in the
  grease to hold it up; better still, use **a tin** for "a steadier lamp, as well as a much larger light"
  ([Seton, p. 239](lib:seton-the-book-of-woodcraft-1913#page=239)).
- **Soft fat** (too stiff to climb a wick, too soft to mould): lay the wick so it rests on and overhangs the edge of
  the dish; "the flame soon heats the side sufficiently to melt a portion of the fat" (*Shifts*, p. 91).
- Open flames: stand them in a tin tray on something that can't burn, away from drafts and children *(rule of thumb)*.

### Can lanterns and candle holders
- **Tomato-can lantern:** a big hole in the bottom for the candle, the sides punched full of small holes from inside;
  it "will not go out in the wind" (Seton, p. 239). A candle pushed up through a hole in the side of a can makes "a
  boxed light, shining ahead like a searchlight" ([Seton, p. 240](lib:seton-the-book-of-woodcraft-1913#page=240)).
- **Jar lantern:** "a candle, a glass jar, and light wire to hang the lantern" ([FEMA H-4, p. 76](lib:preparedness-planning-for-a-nuclear-crisis-citizens-guide-fema-hs-4-1987#page=76)).
  To carry a candle, stick a short one in a tumbler with its own drips (HD p. 99). A tin candlestick's socket seam
  must be folded, not just soldered, or it will "melt apart" ([Thatcher, p. 117](lib:making-tin-can-toys-thatcher-1919#page=117)).

![Seton's camp lights: a hunter's lamp made from a shell of grease with the wick held up by a flat stone, a can with a candle pushed up through a hole in its side, a bottle lantern, and a tomato can punched full of holes with a candle inside](img:LIGHTING-GUIDE/hunters-lamp-and-can-lanterns.png)
*A hunter's lamp with its flat stone, a can lit through a side hole, and a punched tomato-can lantern ([Seton, p. 240](lib:seton-the-book-of-woodcraft-1913#page=240)).*

## 🛢️ Kerosene lamps while the kerosene lasts

Storage and heaters: "Kerosene and propane" in the [Fuel guide](guide:FUEL-GUIDE). Keep it in a metal can marked
**KEROSENE**, not red, never an old gasoline can, outside the house away from where children play ([MSU E-1669, p. 4](lib:some-considerations-about-portable-kerosene-heaters-msu-extension-e-1669-1982#page=4)).
Good kerosene is "clear and nearly colorless, like water" ([HD p. 92](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=92)).
1. **Each morning, by daylight: clean, fill, trim** ([HD p. 138](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=138)).
   **Never fill a lamp while it is burning** ([p. 93](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=93))
   or hot. Fill to **within about ½ in of the top**, since "the oil expands with heat and runs over"; wipe it dry
   ([p. 139](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=139); p. 92).
2. **Trim by rubbing the char off** with a finger or burnt match: "Don't cut it; you can't cut it even" (p. 92). The
   wick must reach the bottom (p. 138); renew it "every month or two, no matter how fresh it looks" (p. 92).
3. Keep the burner's air holes clear; once a month, boil the burner in washing soda or lye water (p. 92).
4. **Light it low and turn it up slowly;** if steam fogs a cold chimney, keep it low till that clears (p. 139). Too
   high or too low, it smokes; set the screw back a touch so the wick won't creep up ([p. 94](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=94)).
5. **Turn it low before blowing it out and when carrying it.** Use lamps with "a broad, solid base", and don't light
   one that has stood part-empty a long time (p. 93).

**Chimneys and spares:** the right chimney gives "perhaps twice as much" light; a cold draft or the flame touching a
hot chimney cracks it (p. 93). Toughen new ones by boiling **10–15 minutes** in strong salt water, wrapped in
cheesecloth, and cooling them in the water (p. 139). Keep "two or three extra chimneys and burners, and a yard or two
of wicking", with lamps all alike so parts swap (p. 138). For a **night light**, don't turn a lamp low (it throws off
unburned carbon); use a small lamp turned up (p. 94). **Kerosene-soaked rags** in a heap can catch fire on their own
(p. 138). **Pressure lanterns** are brighter but "noisy", "hot" and "troublesome to start" ([*Rural Lighting*, pp. 3–4](lib:practical-action-rural-lighting-technical-brief#page=3)),
and burn about **5 litres a week** at six hours a night ([pp. 6–7](lib:practical-action-rural-lighting-technical-brief#page=6)).
No kerosene lamps in a small closed room: "They produce gases that can cause headaches or even death" (Kearny, p. 104).

## 🔆 Getting more light from a little flame

- **Reflect it:** "Use reflective material such as aluminum foil, mirrors, or white boards to concentrate a weak
  light where it is needed" ([Kearny, p. 104](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=104)).
  With foil on three sides and the bottom of a jar lamp hung between you and your book, a flame "smaller than that
  of a birthday candle" is enough to read by (same page).
- **A reflector stand:** a tin sheet nearly **2 ft** tall bent into a half cylinder **6–8 in** across, with a shelf for
  the lamp and two small mirrors angled behind, let *Shifts*' author "write or sketch with facility during many hours
  of the weary night" ([pp. 92–93](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=92)). A
  mirror also throws light "down a well or other deep, dark recess" ([HD p. 96](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=96)).
- **Light, clean walls:** "dirt absorbs and masks light", and washing gets back 5–10% more light than dry wiping
  ([TM 5-683, p. 131](lib:tm-5-683-electrical-interior-facilities-army-navy-air-force-1995#page=131)). Ceilings should be
  the lightest, off-white, not shiny; dirt can halve the light in a year ([Navy CE, p. 181](lib:us-navy-construction-electrician-basic-navedtra-14026#page=181)).
  Wash lamp soot off walls, chimneys and reflectors *(rule of thumb)*; a clean, right-sized chimney can double a
  kerosene lamp's light (HD p. 93).
- **Task lighting:** one small light close to the work and everyone at one table, not a lit room *(rule of thumb)*.
  For light to work by, build the fire up on a base **18 in to 2 ft** high (*Shifts*, p. 92).
- **Pine knots and fatwood:** "a roll of birch bark, a pine knot, or some pine-root slivers, in a split stick of green
  wood" ([Seton, p. 239](lib:seton-the-book-of-woodcraft-1913#page=239)); resinous splints burn in a rest, nearly upright
  if very resinous (*Shifts*, pp. 93–94). Finding fatwood: "Fire and light without stores" in the
  [Make-Do guide](guide:MAKE-DO-HOUSEHOLD-GUIDE). It's smoky: fireplace or outdoors only, and **no torches outdoors
  in fire season (June–October)** *(rule of thumb)*.

## 🧯 Fire, fumes, burns and children

**Putting out a fire:**
- **Burning wax or fat in the pot:** heat off, then a metal lid or damp cloth. "On no account try to extinguish burning
  wax with water as it will intensify the fire" ([Practical Action, p. 3](lib:practical-action-candlemaking-technical-brief#page=3)).
- **A burning lamp:** wrap it tightly in "a heavy woolen rug" to smother it. **Burning oil on the floor:** sand or
  earth, never water, "as it will only spread it". **Clothes on fire:** don't let the person run; wrap them in wool
  ([HD p. 95](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=95)).
- **Don't throw a burning lamp out of the window**, though that page says to: you'd carry an open fire across the
  room, spill burning oil on yourself and the floor, and the window may be shut. Smother it where it stands *(rule of thumb)*.
- Keep **a bucket of sand or earth** by the lamps and the candle pot ([FEMA H-4, p. 76](lib:preparedness-planning-for-a-nuclear-crisis-citizens-guide-fema-hs-4-1987#page=76)).

**Where lamps go:** a safe lamp is "short and heavy", with "two flat sides" so it won't roll, a screw-on metal lid
and thick glass, and never at a table's edge; light bottle lamps "could easily topple, igniting the clothes of a
child" ([WHO, p. 106](lib:world-report-on-child-injury-prevention-drowning-burns-falls-poisoning-who-unicef-2008#page=106)).
"Keep lamps and matches out of reach of children" ([*Where There Is No Doctor*, p. 22](lib:where-there-is-no-doctor-10-first-aid#page=22)).

**Hanging lamps: the books disagree.** FEMA says hanging helps "prevent lamps from being knocked over" (H-4, p. 76);
WHO says "not to hang the lamps on walls" (p. 106), where a lamp on a nail sits by a sleeping child; a barn lantern
on a pulley stays above the hay forks ([*Handy Farm Devices*, p. 115](lib:handy-farm-devices-and-how-to-make-them-1912#page=115)).
**Our rule: hang lamps from an overhead wire, away from walls, curtains, shelves and beds, above head height, with
nothing that burns above them or within their swing; an earthquake will set them swinging** *(rule of thumb)*.

**Children and kerosene:** fuel and lamp oils are the commonest child poisons in poorer countries, kerosene alone
up to **16%** of cases, mostly children **1 to 3 years** old ([WHO, p. 145](lib:world-report-on-child-injury-prevention-drowning-burns-falls-poisoning-who-unicef-2008#page=145)).
**Child-resistant caps** are "the only proven intervention"; use dark containers, as kerosene "may be easily mistaken
for water" ([p. 152](lib:world-report-on-child-injury-prevention-drowning-burns-falls-poisoning-who-unicef-2008#page=152)),
and dyeing it blue cut poisonings in Australia ([p. 153](lib:world-report-on-child-injury-prevention-drowning-burns-falls-poisoning-who-unicef-2008#page=153)).
"**Never keep kerosene, gasoline, or other poisons in cola or soft drink bottles**" ([*Where There Is No Doctor*, p. 29](lib:where-there-is-no-doctor-10-first-aid#page=29)).
**If swallowed:** do **not** make them vomit (same page), and no activated charcoal ([*Book for Midwives*, p. 12](lib:a-book-for-midwives-26-medicines-green-pages#page=12));
see the [Field Care guide](guide:FIELD-CARE-GUIDE).

**Carbon monoxide and soot:**
- "Any time you have an open flame, it may generate carbon monoxide"; it has no colour or smell, usually no
  symptoms, and "unconsciousness and death can occur without warning". **Never fall asleep with a lamp burning**
  ([FM 21-76, p. 182](lib:fm-21-76-army-survival-manual#page=182); [Carbon monoxide poisoning](wiki:Carbon_monoxide_poisoning)).
- **Signs:** headache, dizziness, confusion, yawning, weariness, nausea, ringing ears, sudden collapse. **Get the
  person into open air; keep them still and warm** ([TC 21-3, p. 40](lib:tc-21-3-soldiers-handbook-for-individual-operations-and-survival-in-cold-weather-areas-us-army-1986#page=40)).
- Put flames **near where air leaves the room**, and put them all out if it must be shut up (Kearny, p. 104).
- **Soot:** a lamp turned too high or too low smokes, and soot in the lungs is "exceedingly harmful" (HD p. 94); all
  lamps and candles "contribute to indoor air pollution" ([*Rural Lighting*, p. 4](lib:practical-action-rural-lighting-technical-brief#page=4)).

**Burns from hot wax and fat:** keep children away from the candle pot and turn pot handles in. Put a burn in clean,
cool water (not ice) right away, for no longer than **20 minutes**; "Never put ice, grease, fat ... on a burn"
([*Where There Is No Doctor*, p. 22](lib:where-there-is-no-doctor-10-first-aid#page=22)). Leave cooled wax stuck to
the skin; it comes off as the burn heals *(rule of thumb)*. Big or deep burns: "Burns" in the [Field Care guide](guide:FIELD-CARE-GUIDE).

**After a quake, storm or fire:** "Do not smoke or use oil, gas lanterns, candles, or torches for lighting inside a
damaged home until you are sure there is no leaking gas or other flammable materials present"
([FEMA *Are You Ready?*, p. 183](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full-edition#page=183)).
Check with a flashlight; if you smell gas, see "If you smell gas" in the Fuel guide.

📚 **Go deeper:** [Kearny, ch. 11 "Light"](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=103) — shelter lights and tested lamps; [HD pp. 90–100](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=90) — kerosene lamps and candles in 1909.

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| A burning lamp: "seize it and throw it out of the window" ([HD p. 95](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=95)) | Smother it where it stands with a heavy wool rug (the same page's second choice); sand or earth on spilled oil. |
| Throw "milk or any dry, heavy substance, as flour, corn meal" on burning oil (HD p. 95) | **Sand or earth.** Milk is mostly water; flour thrown as a cloud can flare *(rule of thumb)*. |
| Wick solution with **chloride of lime** and **chloride of ammonia** ([HD p. 97](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=97)) | Chloride of lime is bleach; with an ammonia salt it gives off poison gas. Use the lime-and-saltpeter or turpentine soak, or plain primed cotton. |
| Hard tallow candles with **camphor** (HD p. 97) | Leave the camphor out; it is poisonous if a child eats it *(rule of thumb)*. Alum or beeswax does the hardening. |
| Make stearin with **sulphuric acid**; harden lard and beeswax with **nitric acid** ([HD p. 98](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=98)) | No acids. Harden with alum or beeswax (HD pp. 97, 99). |
| Run fish oil into a **lead-lined** vat "acidulated with blue vitriol" ([HD p. 367](lib:household-discoveries-encyclopaedia-of-practical-recipes-and-processes-1909#page=367)) | Lead and blue vitriol (copper sulphate) are poisons. Use the charcoal filter bag from the same page. |
| Old or salvaged candles with **lead-core** wicks | Don't burn them indoors; cotton wicks only ([Practical Action, p. 2](lib:practical-action-candlemaking-technical-brief#page=2)). |

## 🖼️ Pictures & diagrams

- Wick sizes: right, too thick, too thin — [🖼️ Practical Action, p. 2](lib:practical-action-candlemaking-technical-brief#page=2); [Candle wick](wiki:Candle_wick); melting wax in a double boiler, [🖼️ p. 3](lib:practical-action-candlemaking-technical-brief#page=3)
- Hand dipping in four steps, and a dipping wheel — [🖼️ Practical Action, p. 5](lib:practical-action-candlemaking-technical-brief#page=5); hand pouring in four steps, [🖼️ p. 6](lib:practical-action-candlemaking-technical-brief#page=6); bicycle-wheel pouring rig, [🖼️ p. 7](lib:practical-action-candlemaking-technical-brief#page=7)
- Moulding a candle: thread, seal with clay, pour, top up, take out — [🖼️ Practical Action, p. 8](lib:practical-action-candlemaking-technical-brief#page=8); container candle, [🖼️ p. 9](lib:practical-action-candlemaking-technical-brief#page=9)
- Wire-stiffened-wick jar lamp, with every measurement — [🖼️ ORNL-4941, p. 309](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=309); floating-wick lamp on a notched pine block, [🖼️ p. 310](lib:expedient-shelter-handbook-ornl-4941-1974-incl-kearny-air-pump#page=310); both in Kearny's book, [🖼️ p. 105](lib:nuclear-war-survival-skills-1979-original-ornl-5037-kearny#page=105)
- "Make-shift lamps": a wick over the edge of a dish of soft fat — [🖼️ *Shifts*, p. 91](lib:shifts-and-expedients-of-camp-life-travel-and-exploration-1871#page=91)
- Hunter's lamp, side-hole and punched-tin can lanterns, bottle lantern — [🖼️ Seton, p. 240](lib:seton-the-book-of-woodcraft-1913#page=240)
- Tin-can candlestick with drip tray: socket pattern and section — [🖼️ Thatcher, p. 117](lib:making-tin-can-toys-thatcher-1919#page=117), [🖼️ p. 118](lib:making-tin-can-toys-thatcher-1919#page=118)
- Pulley-hung barn lantern — [🖼️ *Handy Farm Devices*, p. 115](lib:handy-farm-devices-and-how-to-make-them-1912#page=115)
- Candleberry (bayberry) plant — [🖼️ Saunders, p. 277](lib:useful-wild-plants-of-the-united-states-and-canada-saunders-1920#page=277); [Myrica cerifera](wiki:Myrica_cerifera)
- Oil presses: a cage press driven by a car jack, and a ram press — [🖼️ *Oil Extraction*, p. 3](lib:oil-extraction-from-seeds-and-nuts-practical-action#page=3)
- Photos — [Rushlight](wiki:Rushlight); [Juncus effusus](wiki:Juncus_effusus) (soft rush); [Betty lamp](wiki:Betty_lamp); [Oil lamp](wiki:Oil_lamp); [Kerosene lamp](wiki:Kerosene_lamp); [Candle](wiki:Candle); [Tallow](wiki:Tallow); [Beeswax](wiki:Beeswax); [Fatwood](wiki:Fatwood); [Drying oil](wiki:Drying_oil)

## 🔗 Related guides

- [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — the short version of this guide, the lumens table, fatwood, fire without matches, soap and salves
- [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — rendering lard and tallow, nut oil
- [Bees](guide:BEES-GUIDE) — keeping bees and rendering beeswax
- [Fuel](guide:FUEL-GUIDE) — storing kerosene, kerosene heaters, propane and gas leaks
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) — LED lighting, solar and batteries: far more light for the effort while they last
- [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — doing the work while there is daylight and power
- [Field Care](guide:FIELD-CARE-GUIDE) — burns, and what to do when someone swallows fuel
