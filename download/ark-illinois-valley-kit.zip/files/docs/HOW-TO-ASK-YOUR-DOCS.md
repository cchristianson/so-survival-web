# 📄 Ask Your Documents with GPT4All

**GPT4All** is an optional extra app. You point it at folders of PDFs and text files, ask a
question, and it answers from what's *in them*, showing which file it used. It runs **offline on an
ordinary computer**: no internet and no graphics card needed.

Example: ask *"According to the Army survival manual, how do I purify water?"* and it answers
from that manual.

**Most people don't need it.** The Library Assistant (the START file, see
[Start on Any Device](guide:START-ON-ANY-DEVICE)) already searches every book on the drive.
GPT4All is handy if you also want to ask about **your own** PDFs and notes.

> ### ⚠️ Set it up now, while you have internet
> GPT4All needs the internet **once**, to download a small "reading" model (the *embedding model*,
> which lets it search your documents). After that it works offline for good.

---

## 💾 Install it (one time, about 2 minutes)

1. On the drive, open **OfflineLibrary → AI-Offline → DocReader-GPT4All**.
2. Double-click the installer, **gpt4all-installer-win64-….exe** (the version number varies).
3. If a blue box says **Windows protected your PC**, click **More info**, then **Run anyway**.
4. Click through the installer (the normal choices are fine), then open **GPT4All**.

That's all. GPT4All brings its own AI engine (no Python or other add-ons) and runs on any 64-bit
Windows 10 or 11 computer.

*Mac or Linux:* the folder holds the installer for the kind of computer that made the drive
(`.dmg` for a Mac, `.run` for Linux). If there's no installer, GPT4All wasn't ticked when the
drive was made.

---

## ⚙️ First-time setup (while you have internet)

**A. Use the AI models already on the drive:**

1. In GPT4All, click **Settings** (the gear) → **Application**.
2. Find **Model Folder** (or **Download path**) and set it to the drive's **OfflineLibrary →
   AI-Offline → models** folder (on Windows, something like `E:\OfflineLibrary\AI-Offline\models`).
3. Go to **Chats** and open the model list at the top. Pick **Llama 3.2 3B Instruct** (fast) or,
   if your drive has it, **Meta Llama 3.1 8B Instruct** (smarter; needs about 8 GB of memory).

*No models listed?* Use **Add Model** (or **Download Models**) to download one small model, such as
Llama 3.2 3B. This needs internet, once.

**B. Turn on the document reader (LocalDocs):**

1. Click **LocalDocs** (left side).
2. Click **+ Add Collection**.
3. The first time, GPT4All downloads the small reading model by itself (tens of MB). Let it finish.

After A and B, **everything works offline.**

---

## 📂 Point it at your books

A *collection* is just a folder of documents for GPT4All to read.

1. Click **LocalDocs → + Add Collection**.
2. Type a name (for example `Army Manuals`) and choose a folder on the drive, such as
   **OfflineLibrary → Manuals → ArmyFieldManuals**.
3. Click **Create** (or **Add**). A progress bar shows it reading the files; big folders take a
   few minutes the first time only.
4. Repeat for other folders: **Medical → Manuals-PDF**, **Manuals → Radio-Communications**, the
   **Southern-Oregon** local pack, or your own folders of notes.

It reads PDF, plain text (`.txt`), Markdown (`.md`), Word (`.docx`) and several other office and
code files. It does **not** read `.zim` files (Wikipedia, WikiMed, iFixit, Appropedia, zimgit).
Open those in **Kiwix** instead ([How to Use Kiwix](guide:HOW-TO-USE-KIWIX)), which has its own
fast search.

---

## 💬 Ask a question

1. Go to **Chats** and start a new chat.
2. Check that a **model is picked** (at the top) and your **LocalDocs** collections are **turned
   on** for this chat (use the LocalDocs button in the chat).
3. Type one clear question, such as:
   - *"How do I treat a deep cut and stop bleeding?"*
   - *"How do I purify water if I have no filter?"*
   - *"What knots should I know, and how do I tie a bowline?"*
4. It answers **from your documents** and lists its **sources**. The AI can make mistakes, so open
   the cited PDF and check anything about health or safety.

**Every time after that:** open GPT4All, pick a model (**3B** is fast, **8B** smarter but slower),
turn on the collections you want, and ask.

---

## 🔧 If something goes wrong

| What happens | What to do |
|---|---|
| No models listed | Set **Model Folder** to the drive's `AI-Offline\models` (**Settings → Application**), or download one small model while online |
| LocalDocs won't read the files, or an *embedding model* error | It needs the one-time reading-model download: do step **B** while online |
| Slow answers | Use the **3B** model and close other programs. Older computers are slower but still work |
| The answer ignores my documents | Check the collection is **turned on** in the chat and has finished reading |
