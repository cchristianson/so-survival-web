# 📄 Ask Your Documents with GPT4All

**GPT4All** is an optional extra app. Point it at a folder of PDFs or notes, ask a question, and it
answers from what's in them. It runs offline on an ordinary computer.

**Most people don't need it.** The Library Assistant (see
[Start on Any Device](guide:START-ON-ANY-DEVICE)) already searches every book on the drive. GPT4All
is handy for asking about **your own** files.

> ### ⚠️ Set it up now, while you have internet
> It needs the internet **once**, to download a small add-on. After that it works offline.

---

## 💾 Install it (Windows, about 2 minutes)

1. On the drive, open **OfflineLibrary → AI-Offline → DocReader-GPT4All**.
2. Double-click the **gpt4all-installer** file.
3. If a blue box says **Windows protected your PC**, click **More info**, then **Run anyway**.
4. Click through the installer, then open **GPT4All**.

(Mac or Linux: the folder has the installer for the kind of computer that made the drive.)

---

## ⚙️ First-time setup (while you have internet)

1. **Use the AI already on the drive:** **Settings** (gear) → **Application** → set **Model
   Folder** to the drive's **OfflineLibrary → AI-Offline → models** folder. Then pick **Llama 3.2 3B
   Instruct** in the model list at the top of **Chats**.
2. **Turn on the document reader:** click **LocalDocs** → **+ Add Collection**. The first time, it
   downloads a small add-on. Let it finish.

After that, **everything works offline.**

---

## 📂 Point it at your books

1. Click **LocalDocs → + Add Collection**.
2. Give it a name (like `Army Manuals`) and pick a folder, such as **Manuals → ArmyFieldManuals**,
   **Medical → Manuals-PDF**, the **Southern-Oregon** folder, or your own notes.
3. Click **Create**. It reads the files (a few minutes the first time).

It reads PDFs, Word files and text files. It can't read the `.zim` encyclopedias; use
[Kiwix](guide:HOW-TO-USE-KIWIX) for those.

---

## 💬 Ask a question

1. Go to **Chats** and start a new chat.
2. Check a **model** is picked and your **LocalDocs** collections are **turned on**.
3. Ask one clear question, like *"How do I purify water if I have no filter?"*
4. It answers and shows which files it used. Check anything about health or safety in the file
   itself.

---

## 🔧 If something goes wrong

| Problem | Fix |
|---|---|
| No models listed | Set **Model Folder** to the drive's `AI-Offline\models` (see setup step 1) |
| LocalDocs won't read the files | It needs its one-time download: do setup step 2 while online |
| Slow answers | Use the **3B** model and close other programs |
| The answer ignores my documents | Check the collection is turned on in the chat and has finished reading |
