# 🚜 Vehicles, Tractors & Heavy Equipment

How to keep cars, pickups, diesel trucks, tractors and other machines working when there is no parts store, no
dealer and no tow truck, and how to do it without getting hurt: the 12-volt battery, starting, cooling, brakes,
tires, parking a vehicle for months, towing, diesels in the cold, tractors and their hitches, hydraulics, air brakes,
and electric cars and hybrids. The books are in `Southern-Oregon\Engines-Motors\Vehicles-Tractors` (the Navy's
equipment courses, NIOSH's tractor and PTO papers, the NTSB's report on electric-car battery fires) and
`Southern-Oregon\Engines-Motors\Hydraulics` (the Army's FM 5-499). The Army's *Principles of Automotive Vehicles*
(TM 9-8000) is in `Manuals\ArmyFieldManuals`, and the Navy's *Construction Mechanic 3 & 2* in
`Southern-Oregon\Engines-Motors\Small-Engines`. Small engines, diesel basics and generators are in the
[Engines guide](guide:ENGINES-AND-MOTORS-GUIDE); fuel itself is in the [Fuel guide](guide:FUEL-GUIDE). For any one
machine, its own manual comes first: keep it in the machine.

> ### The short version
> - **Tractors roll over, and that kills.** The tractor is "the machine most often involved in farm-related
>   fatalities," and overturns are 50–60% of tractor deaths ([NIOSH TRAC-SAFE, p. 18](lib:trac-safe#page=18)). With a
>   roll bar (ROPS), under 1% of overturns killed anyone; **wear the seat belt only if there is a ROPS**
>   ([p. 19](lib:trac-safe#page=19)).
> - **A rear overturn is over in about 1½ seconds**: you can't jump clear ([p. 69](lib:trac-safe#page=69)). Hitch
>   only to the drawbar, and back up steep slopes ([p. 48](lib:trac-safe#page=48)).
> - **PTO: shut it off and stop the engine before you leave the seat** ([NIOSH Alert 94-105, p. 7](lib:preventing-scalping#page=7)).
>   Spinning shafts catch hair, clothes and limbs, and kill and maim farm workers every year ([p. 3](lib:preventing-scalping#page=3)).
> - **No riders.** "Never permit anyone to ride on the equipment"
>   ([Navy *Equipment Operator*, p. 235](lib:navy-equipment-operator-basic#page=235)).
> - **Never get under anything held up by a jack or by hydraulics.** Lower it, or block it
>   ([*Equipment Operator*, pp. 76, 225](lib:navy-equipment-operator-basic#page=225)).
> - **Never feel for a hydraulic leak with your hand.** The oil is at up to 3,000 psi and can be over 200 °F
>   ([*Equipment Operator*, p. 103](lib:navy-equipment-operator-basic#page=103)); a jet through the skin is a
>   surgical emergency even when it looks like a pinprick ([below](#hydraulic-dangers-injected-oil-and-falling-loads)).
> - **Batteries give off hydrogen and oxygen, "a highly explosive mixture"**
>   ([TM 9-8000, p. 293](lib:tm-9-8000#page=293)). No sparks or flame near one.
> - **Never open a hot radiator** ([*Equipment Operator*, p. 48](lib:navy-equipment-operator-basic#page=48)).
> - **Engine exhaust holds carbon monoxide, "colorless, odorless, tasteless, deadly"**
>   ([TM 9-8000, p. 741](lib:tm-9-8000#page=741)). Never run an engine in a closed shed or garage.
> - **Electric cars run at 300–400 volts or more**, far above the 50–60 volts DC counted safe
>   ([NTSB SR-20/01, pp. 15, 17](lib:safety-risks-from-lithium-ion#page=17)). Leave the orange cables alone. A damaged
>   pack can catch fire again days later ([p. 28](lib:safety-risks-from-lithium-ion#page=28)).
> - **Stock the spares now:** filters, belts, hoses, fuses, bulbs, brake fluid, hydraulic oil, antifreeze, tire
>   patches and a tire gauge *(rule of thumb)*.

---

## 🚗 Cars and pickups with no shop
<!-- fold: Battery and charging, starting, cooling, brakes, tires, fuel, fuses, storage, power and towing -->

A car or pickup needs the same few things checked over and over. The Navy's walk-around before a truck moves is a
good habit for any vehicle: tires, lights, leaks under it, fluid levels, then the brakes and gauges once it runs
([*Equipment Operator*, pp. 163–164](lib:navy-equipment-operator-basic#page=163)).

### The 12-volt battery and charging

- **Reading the charge with a hydrometer** (wet batteries with caps): below **1.240** at 80 °F, charge it; never
  let it go below 1.225 except in hot climates. For every 10 °F below 80 °F, subtract 0.004 from the reading
  ([Navy *Construction Mechanic 3 & 2*, p. 166](lib:navy-construction-mechanic-3-and-2#page=166)).
- **A flat battery freezes.** At 1.100 the acid freezes at 18 °F; at 1.220, at −31 °F; fully charged
  (1.285), not until about −95 °F. Check and charge batteries that sit, above all in cold weather
  ([p. 168](lib:navy-construction-mechanic-3-and-2#page=168)).
- **Cold steals cranking power:** at 0 °F a battery has about **40%** of the cranking power it has at 80 °F
  ([TM 9-8000, p. 289](lib:tm-9-8000#page=289)).
- **Is it charging?** With the engine running, a 12-volt system should read **13.2 to 14.5 volts**
  ([TM 9-8000, p. 383](lib:tm-9-8000#page=383)). Lower: check the belt, the wires and the alternator *(rule of thumb)*.
- **Clean the terminals** with baking soda and water, and keep it out of the cells
  ([*Construction Mechanic*, p. 167](lib:navy-construction-mechanic-3-and-2#page=167)).
- **Alternator rules:** connect a charger or a booster battery **+ to +** and **− to −**; never run the alternator
  with the battery disconnected ("open circuit"); never short its terminals
  ([*Alternator and Regulator Servicing*, pp. 15–16](lib:alternator-and-regulator-servicing#page=15)).
- **Jump-starting** *(rule of thumb)*: + to + first, then − of the good battery to bare metal on the dead car's
  engine, away from its battery, so the last spark is not beside the hydrogen. Remove them in the reverse order.
  **Never jump a 12-volt system from a 24-volt one** (many big trucks and machines): it can wreck the battery and
  starter "or even" cause "an explosion" ([*Equipment Operator*, p. 95](lib:navy-equipment-operator-basic#page=95)).
- Charging and caring for lead-acid batteries, and acid in the eyes:
  [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#keeping-lead-acid-alive) and its
  [battery safety](guide:OFF-GRID-POWER-GUIDE#battery-safety).

### When it won't start

- **Barely turns over, or a row of loud clicks:** "you can be fairly sure there is a problem with the battery."
  Starters seldom fail unless overused: **never crank more than 30 seconds** without letting the starter cool
  ([*Construction Mechanic*, p. 197](lib:navy-construction-mechanic-3-and-2#page=197)).
- **Turns over well but won't fire:** it needs fuel, spark and compression, the same as a small engine
  ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#small-gas-engines-why-it-won-t-start)). Old gasoline is the usual
  culprit ([Fuel guide](guide:FUEL-GUIDE#how-long-fuel-keeps)).
- **Diesels:** [below](#diesel-trucks-and-tractors).

### Cooling: radiator, hoses and belts

- **The pressure cap:** systems run at **4 to 17 psi**, and each pound raises the boiling point about **3 °F**.
  Replace a cap only with one of the same rating ([*Equipment Operator*, p. 46](lib:navy-equipment-operator-basic#page=46)).
  **Never take it off unless the engine is cold**: "it will spray you with hot steam and coolant"
  ([p. 48](lib:navy-equipment-operator-basic#page=48)).
- **Antifreeze:** a mix of **60% ethylene glycol and 40% water** gives the most protection; more glycol gives
  *less*, and pure glycol freezes not much below water. If you run plain water, add a rust inhibitor. **Glycerin**
  is the stand-in: it protects like alcohol and doesn't boil away ([TM 9-8000, p. 238](lib:tm-9-8000#page=238)).
- **Antifreeze poisons:** its sweet taste draws animals and children
  ([*Equipment Operator*, p. 46](lib:navy-equipment-operator-basic#page=46)). Keep it capped and locked up.
- **Watch the gauge.** If the temperature starts to rise, stop and find out why; don't wait for the red
  ([*Equipment Operator*, p. 98](lib:navy-equipment-operator-basic#page=98)). Clean bugs and chaff out of the
  radiator by blowing through it backward ([p. 45](lib:navy-equipment-operator-basic#page=45)).
- **Hoses:** squeeze them. Replace any that are cracked or "mushy"; a soft **lower** hose can suck flat and boil the
  engine over ([*Construction Mechanic*, p. 147](lib:navy-construction-mechanic-3-and-2#page=147)).
- **Belts:** the Navy's rule of thumb is **no more than ½ inch** of give when pressed midway between pulleys
  ([*Equipment Operator*, p. 47](lib:navy-equipment-operator-basic#page=47)). Too tight wears out the alternator
  bearings ([*Construction Mechanic*, p. 148](lib:navy-construction-mechanic-3-and-2#page=148)).

### Brakes

- **Test before you move:** pump the pedal three times, then hold it firmly for 5 seconds. **The pedal should not
  sink**; if it does, there is a leak ([*Equipment Operator*, p. 164](lib:navy-equipment-operator-basic#page=164)).
- **Having to keep topping up the fluid means a leak.** A **soft, spongy pedal means air** in the lines
  ([*Construction Mechanic*, p. 277](lib:navy-construction-mechanic-3-and-2#page=277)).
- **The right fluid only.** Use brake fluid marked DOT-3 (or what the cap says)
  ([p. 267](lib:navy-construction-mechanic-3-and-2#page=267)). Fluid with **mineral oil** in it (engine oil, ATF,
  hydraulic oil) ruins the rubber seals, and then the whole system must be rebuilt and flushed
  ([p. 378](lib:navy-construction-mechanic-3-and-2#page=378)). Silicone brake fluid "will not absorb or retain
  moisture" and keeps through long storage, but it does not mix with the ordinary (glycol) kind
  ([*Construction Mechanic Advanced*, p. 150](lib:navy-construction-mechanic-advanced#page=150)). Ordinary fluid draws
  water from the air, so keep the can sealed *(rule of thumb)*.
- **Bleeding the air out** with a helper ([*Construction Mechanic*, pp. 277–278](lib:navy-construction-mechanic-3-and-2#page=277);
  [🖼️ drawing](lib:navy-construction-mechanic-3-and-2#page=277)):
  1. Fill the master cylinder. Push a clear hose onto the bleeder screw of the wheel **farthest** from it, with
     the hose end in a jar of clean brake fluid.
  2. Open the bleeder; the helper pushes the pedal down **slowly** as far as it goes. It may take six or seven
     strokes before the fluid comes without air. Close the bleeder before the pedal comes back up, so it can't
     suck air in *(rule of thumb)*.
  3. Refill the master cylinder every three or four strokes, or it pumps air back in.
  4. When no more bubbles come, close the bleeder tightly. Do the next-farthest wheel, and so on.
- **Brake dust from old shoes may be asbestos, "a substance that can cause cancer."** Wear a filter mask
  ([TM 9-8000, p. 655](lib:tm-9-8000#page=655)); never blow it out with air *(rule of thumb)*.

### Tires, flats and jacking

- **Pressure matters both ways.** Low tires flex, heat up and blow out; hard ones break cords and wear the center
  ([*Equipment Operator*, p. 72](lib:navy-equipment-operator-basic#page=72)). Don't mix radial and bias-ply tires on
  one axle ([p. 73](lib:navy-equipment-operator-basic#page=73)).
- **Jacking** ([*Equipment Operator*, p. 76](lib:navy-equipment-operator-basic#page=76)): park in gear with the brake
  on, block the wheels on the **other** axle, loosen the nuts before lifting, and put a plank under the jack on soft
  ground. **"Do not leave the vehicle suspended on the jack":** to work under it, set stands or solid blocks under
  the axle.
- **Patching:** feel inside a tire with a rag, not a bare hand: there may be a nail
  ([*Equipment Operator*, p. 80](lib:navy-equipment-operator-basic#page=80)). On a radial tire, patch only the middle of
  the tread, not the sidewall ([p. 81](lib:navy-equipment-operator-basic#page=81); [🖼️ repairing a puncture](lib:navy-equipment-operator-basic#page=81)).
  Bicycle-style tube patching: [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE#flat-tyres-patching-tubes-and-booting-tyres).
- **Split rims and lock rings kill.** On many truck, tractor and implement wheels, a ring holds the tire on. A ring
  that isn't seated "may blow off, causing serious injury." Inflate to 5–10 psi, tap the ring home, and **never stand
  in front of or over it**: inflate inside a safety cage, or through a clip-on chuck from the side
  ([*Equipment Operator*, p. 80](lib:navy-equipment-operator-basic#page=80);
  [🖼️ lock-ring rim](lib:navy-equipment-operator-basic#page=79); [🖼️ safety cage](lib:navy-equipment-operator-basic#page=78)).
  With no cage, chain the wheel to something heavy and stand well aside *(rule of thumb)*.

### Fuel, filters, lights and fuses

- **Drain the fuel filter's bowl:** water and grit settle there. The Navy drains about a quarter pint from the filter
  before each day's work ([*Equipment Operator*, pp. 28–29](lib:navy-equipment-operator-basic#page=29)).
- **Never wash an air filter in gasoline**: static or friction can set it alight
  ([*Construction Mechanic*, p. 87](lib:navy-construction-mechanic-3-and-2#page=87)).
- **A rusted muffler leaks carbon monoxide into the cab**, "sometimes fatally"
  ([*Construction Mechanic*, p. 91](lib:navy-construction-mechanic-3-and-2#page=91)).
- **Fuses:** replace with **the same rating**, and find the fault first. A blackened fuse means a short; a clear one,
  too much load ([*Equipment Operator*, p. 98](lib:navy-equipment-operator-basic#page=98)). Never use foil or wire in
  place of a fuse *(rule of thumb)*.
- Getting fuel out of tanks and testing it: [Fuel guide](guide:FUEL-GUIDE#drums-and-vehicles).

### Parking a vehicle for months

- **The battery:** check and charge it regularly, or it freezes when cold
  ([*Construction Mechanic*, p. 168](lib:navy-construction-mechanic-3-and-2#page=168)). Taking the negative cable off
  stops slow drains from clocks and computers *(rule of thumb)*.
- **Fuel:** old gas gums up; stabilize it or drain it ([Fuel guide](guide:FUEL-GUIDE#how-long-fuel-keeps)). Water
  "forms by condensation in a partially empty tank" ([*Construction Mechanic*, p. 130](lib:navy-construction-mechanic-3-and-2#page=130)),
  so park a diesel with its tank full ([Fuel guide](guide:FUEL-GUIDE#diesel-care)).
- **Shiny hydraulic rams:** grease them before storage and wipe them before use
  ([*Equipment Operator*, p. 102](lib:navy-equipment-operator-basic#page=102)).
- **Don't just idle it now and then.** Long idling keeps plugs too cool to burn clean
  ([*Construction Mechanic*, p. 208](lib:navy-construction-mechanic-3-and-2#page=208)); if you start it, drive it
  until it is fully warm *(rule of thumb)*.
- *(Rule of thumb)*: park on boards or blocks off wet ground, pump the tires up, close the vents and keep mice out of
  the air box and wiring (they nest and chew).

### A vehicle as a power source

A running car is a 12-volt generator. An inverter on the battery runs small loads; how to wire it, and why idling for
hours to charge a house bank wastes fuel: [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#generators-cars-and-backfeed).
**Never run it in a garage or near a window** ([TM 9-8000, p. 741](lib:tm-9-8000#page=741)), and never feed a house
through an outlet ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#generators)).

### Towing and getting unstuck

- **Use a tow bar, not a chain or rope,** for towing ([*Equipment Operator*, p. 114](lib:navy-equipment-operator-basic#page=114)).
  A rigid bar keeps the towed vehicle from running into the one pulling it *(rule of thumb)*.
- **Stand clear of any loaded cable, chain or strap.** Wire rope "whips with great force" when it breaks; everyone
  should stay clear of its whole length ([*Equipment Operator*, p. 278](lib:navy-equipment-operator-basic#page=278)).
- **Winching:** don't wrap the cable round a bumper; it bends
  ([*Equipment Operator*, p. 112](lib:navy-equipment-operator-basic#page=112)). A snatch block on a solid anchor adds
  pulling power ([p. 115](lib:navy-equipment-operator-basic#page=115); [🖼️ winching drawings](lib:navy-equipment-operator-basic#page=113);
  [🖼️ self-winching](lib:navy-equipment-operator-basic#page=115)). Blocks and tackle, and safe rope work:
  [Knots & Rope](guide:KNOTS-ROPE-GUIDE#lifting-and-hauling-block-and-tackle).
- *(Rule of thumb)*: drape a heavy coat or a sack over the middle of a winch line to soak up a snap; pull slowly;
  never "snatch" with a chain.

📚 **Go deeper:** [TM 9-8000 *Principles of Automotive Vehicles*](lib:tm-9-8000) — how every part of a vehicle works; [Navy *Construction Mechanic 3 & 2*](lib:navy-construction-mechanic-3-and-2#page=166) — batteries, cooling, brakes and tune-ups; [Navy *Equipment Operator*](lib:navy-equipment-operator-basic#page=163) — daily checks, tires, towing and winching. Pictures: [🖼️ a cooling system's pressure cap, TM 9-8000 p. 245](lib:tm-9-8000#page=245), [Automotive battery](wiki:Automotive_battery), [Hydraulic brake](wiki:Hydraulic_brake), [Jump start (vehicle)](wiki:Jump_start_(vehicle)).

## 🛢️ Diesel trucks and tractors
<!-- fold: Glow plugs and cold starts, running dry, water in the fuel -->

How a diesel works, bleeding air out of the fuel system, cleaning injectors and reading the smoke are in the
[Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#diesel-engines); gelling, water, fuel bugs and stand-in fuels are in
the [Fuel guide](guide:FUEL-GUIDE#diesel-care). What they leave out:

- **Glow plugs.** Cold diesel fuel is hard to light, so many diesels have glow plugs (or an intake heater) that warm
  the air before and while you crank ([*Construction Mechanic*, p. 129](lib:navy-construction-mechanic-3-and-2#page=129)).
  Turn the key to "on" and **wait for the glow light**, often 15 to 30 seconds, before you crank
  ([*Equipment Operator*, p. 34](lib:navy-equipment-operator-basic#page=34); [🖼️ a glow plug](lib:navy-equipment-operator-basic#page=34)).
  Hard starting only when cold often means a dead glow plug *(rule of thumb)*.
- **Cold starts.** Diesels are "very difficult to start in cold weather" because the fuel doesn't evaporate; the
  Army's helpers are a flame heater in the intake and an ether shot ([TM 9-8000, p. 200](lib:tm-9-8000#page=200)).
  Keep the battery charged: at 0 °F it has only 40% of its cranking power ([p. 289](lib:tm-9-8000#page=289)).
  **Never spray starting fluid into an engine while its glow plugs or intake heater are on**: it can fire early and
  break the engine *(rule of thumb)*.
- **Ran out of fuel?** Air got in. "Air lock in fuel line" is one of the first things to suspect
  ([Practical Action *Diesel Engine Repair*, p. 12](lib:diesel-engine-repair-and-maintenance#page=12)). Fill up, then
  bleed it from the tank toward the injectors as the [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#diesel-engines) shows.
- **Water in the fuel** "will rust an engine" and causes hard starting and misfiring
  ([*Construction Mechanic*, p. 93](lib:navy-construction-mechanic-3-and-2#page=93)); it can rust the injection system
  until it fails ([*Equipment Operator*, p. 26](lib:navy-equipment-operator-basic#page=26)). Drain the filter bowl
  every day you run ([p. 29](lib:navy-equipment-operator-basic#page=29)).
- **Keep your hands off injectors and their lines while the engine turns.** The Navy warns that injector spray that
  gets through the skin "will cause blood poisoning"
  ([*Construction Mechanic Advanced*, p. 132](lib:navy-construction-mechanic-advanced#page=132)).

📚 **Go deeper:** [Navy *Construction Mechanic Advanced*](lib:navy-construction-mechanic-advanced#page=132) — diesel fuel-system overhaul; [TM 9-8000, p. 200](lib:tm-9-8000#page=200) — cold-weather starting aids. Pictures: [Glow plug](wiki:Glow_plug), [Diesel engine](wiki:Diesel_engine).

## 🚜 Tractors: daily checks, the hitch and the PTO
<!-- fold: The checks before you start, the three-point hitch, the PTO and implements -->

**Before you start** ([TRAC-SAFE, p. 29](lib:trac-safe#page=29); [checklist, p. 72](lib:trac-safe#page=72)):
tire pressure, clean windows and mirrors, the seat set for you, the **ROPS and seat belt**, brakes, steering, lights,
the slow-moving-vehicle sign, and the **PTO shields** in place. Oil, coolant, fuel filter bowl and hydraulic fluid as
on any diesel ([above](#diesel-trucks-and-tractors)).

**The hitch.** Pull loads **only from the drawbar**. "Many accidents occur when loads are hitched to axle housing or
other parts of the tractor"; on the three-point hitch use only implements made for it. "Attaching implements to
something higher than a drawbar can cause the tractor to roll over" ([TRAC-SAFE, p. 48](lib:trac-safe#page=48)).
Front-end weights help keep the front down ([p. 29](lib:trac-safe#page=29)).

**The PTO** (power take-off) is the spinning shaft at the back that drives mowers, balers and pumps
([NIOSH Alert 94-105, p. 3](lib:preventing-scalping#page=3)). Keep every shield and guard on it, and replace a
guard that is open underneath ([p. 7](lib:preventing-scalping#page=7)). The rules for using it are in the safety
section just below.

**Implements:** lower them to the ground before you service anything or leave the seat
([*Equipment Operator*, p. 235](lib:navy-equipment-operator-basic#page=235)). **Front-end loader:** carry the bucket as
low as you can on any slope (same page). Hauling a raised load is a known cause of overturns
([TRAC-SAFE, p. 18](lib:trac-safe#page=18)).

**On the road:** lock the two brake pedals together, so a hard stop can't brake one wheel alone and swing the tractor
round *(rule of thumb)*.

📚 **Go deeper:** [NIOSH TRAC-SAFE](lib:trac-safe#page=18) — causes of overturns and a tractor safety checklist; [Navy *Equipment Operator*](lib:navy-equipment-operator-basic#page=235) — loaders, backhoes and their safety rules. Pictures: [🖼️ tractor safety checklist, TRAC-SAFE p. 72](lib:trac-safe#page=72), [Three-point hitch](wiki:Three-point_hitch), [Power take-off](wiki:Power_take-off).

## ☠️ Tractor safety: rollovers, PTO, runovers and riders

**Rollovers** are the "most common and most often fatal" kind of tractor accident
([TRAC-SAFE, p. 18](lib:trac-safe#page=18)):
- **85 of every 100 overturns are to the side**, 15 to the rear (same page).
- **Side:** too fast on a turn, crossing steep slopes, ditches and holes, hitting a stump, a raised loader
  ([p. 29](lib:trac-safe#page=29)). A wheel drops off a road shoulder and the driver steers back uphill: that turn is
  what tips it ([p. 18](lib:trac-safe#page=18)). Slow down, and keep away from ditch banks.
- **Rear:** hitching high, no front weight, "popping" the clutch, rear wheels frozen or stuck, driving forward up a
  steep slope ([p. 26](lib:trac-safe#page=26)). **Back up steep slopes and drive forward down them**
  ([p. 48](lib:trac-safe#page=48)). A rear overturn reaches "the point of no return" in **0.75 seconds** and is over in
  about **1½**; your reaction time is about half a second ([p. 69](lib:trac-safe#page=69)).
- **A ROPS (roll bar or approved cab) plus the seat belt** is the answer: with a ROPS, fewer than 1% of overturns were
  fatal; the belt keeps you inside its protection. **Never buckle up on a tractor without one**: then being thrown
  clear is your only, remote, chance ([p. 19](lib:trac-safe#page=19)). A homemade bar is not a ROPS ([p. 71](lib:trac-safe#page=71)).
- **Use the tractor with a ROPS for the risky jobs**: slopes, ditches, mowing banks and road travel
  ([p. 19](lib:trac-safe#page=19)). Older tractors are the ones that kill: 63% of fatal overturns, where the age was
  known, were tractors over 10 years old ([p. 18](lib:trac-safe#page=18)).

![Three panels. One: a tractor with a chain hitched higher than the drawbar, the chain crossed out in red and a red arrow curving back over the tractor, with a green arrow pointing to the drawbar. Two: a tractor on a steep slope facing downhill with a green arrow pointing up the slope, marked back up a steep slope and drive forward down it. Three: a tractor seen from behind, lying over on its side with an orange roll bar holding the ground off the belted driver](img:VEHICLES-EQUIPMENT-GUIDE/tractor-rollover.svg)
*The three that matter: the hitch, the slope, and the roll bar with the belt ([TRAC-SAFE, pp. 18–19, 26, 29, 48, 69](lib:trac-safe#page=18); a diagram drawn for this guide).*

**PTO entanglement.** At least **112 farm workers died in PTO drivelines** in the 1980s, and nearly 10,000 more were
hurt in entanglements on farms in five years, 864 of them losing a body part
([NIOSH Alert 94-105, pp. 3–4](lib:preventing-scalping#page=3)). The rules ([p. 7](lib:preventing-scalping#page=7)):
- **Disengage the PTO and switch the engine off before you leave the seat** or go near the shaft.
- Wait until the shaft and the machine have **completely stopped** before any adjustment.
- **No loose clothes or jewelry; tie back hair**, but know that even short or tied hair can be caught.
- **Children never near a running PTO**, and never let them work one.
- Never step over a turning shaft ([TRAC-SAFE, p. 26](lib:trac-safe#page=26)).

![A shaft running from the back of a tractor to an implement. Over the tractor's stub is the master shield; over most of the shaft is its own guard, which must turn freely. Where the guard is missing, a sleeve is shown wound round the bare shaft in tight coils, running up to an arm, with the note that a sleeve, a trouser leg, a bootlace or long hair is wound on in an instant. A red cross over the shaft reads never step over a turning shaft, and a cross-section shows a guard worn open underneath, marked is no guard: replace it](img:VEHICLES-EQUIPMENT-GUIDE/pto-shaft-and-guard.svg)
*The guards that must be there, and what a bare shaft catches ([NIOSH Alert 94-105, pp. 3–4, 7](lib:preventing-scalping#page=3); [TRAC-SAFE, p. 26](lib:trac-safe#page=26); a diagram drawn for this guide).*

**Runovers and riders.** An extra rider has "no safe place to sit or anything to hang on to," falls off on a bump,
and is run over by the tractor or what it pulls ([TRAC-SAFE, p. 29](lib:trac-safe#page=29)). **One seat, one person.**
Never start or drive a tractor from anywhere but the seat
([*Equipment Operator*, p. 235](lib:navy-equipment-operator-basic#page=235)): one started from the ground in gear runs
over its driver *(rule of thumb)*. Climb on and off with the steps and handholds ([TRAC-SAFE, p. 26](lib:trac-safe#page=26)).

📚 **Go deeper:** [NIOSH TRAC-SAFE](lib:trac-safe#page=18) — overturns, ROPS, riders; [NIOSH Alert 94-105](lib:preventing-scalping#page=3) — PTO cases and guards. Pictures: [🖼️ a baler's PTO driveline and its open-bottomed guard, NIOSH p. 4](lib:preventing-scalping#page=4), [Rollover protection structure](wiki:Rollover_protection_structure).

## 💧 Hydraulics: how it works and keeping it healthy
<!-- fold: Pump, valve and cylinder; leaks, hoses and fittings; clean fluid and the right fluid; air in it -->

### How it works

A **pump** pushes oil from a **tank** (reservoir) through a **valve** you work with a lever, into a **cylinder** whose
rod pushes out or pulls in; the oil goes back to the tank through a **filter**. A **relief valve** lets oil back to
the tank when the pressure gets too high ([*Equipment Operator*, pp. 100–101](lib:navy-equipment-operator-basic#page=100);
[🖼️ a basic system](lib:navy-equipment-operator-basic#page=100)). A small push on a small piston makes a big push on a
big one: 100 pounds on a 1-square-inch piston pushes 500 pounds on a 5-square-inch one, but the big piston moves only a
fifth as far ([FM 5-499, pp. 19–20](lib:fm-5-499#page=19)). That is how a bottle jack lifts a truck
([🖼️ the jack](lib:fm-5-499#page=26)).
The tank lets air bubbles out and the oil cool, so **keep it filled to the mark**: low oil overheats, or lets air
into the pump. Work the levers smoothly; jerking wears the machine ([*Equipment Operator*, p. 101](lib:navy-equipment-operator-basic#page=101)).

### Leaks, hoses and fittings

- **Look, don't feel.** Check hoses before and after work for cracks, splits, **pinhole leaks**, rubbing, heat and
  twisting ([*Equipment Operator*, p. 103](lib:navy-equipment-operator-basic#page=103)). Hunt for a leak with a piece
  of cardboard or wood held near the hose, never your hand *(rule of thumb)*.
- **Fitting a hose** ([FM 5-499, pp. 44–45](lib:fm-5-499#page=44)): don't twist it (the stripe along it should run
  straight); leave some slack, because a hose gets shorter under pressure; wrap it with tape where it rubs; clamp
  lines often, but never weld them to their supports.
- **New hose ends:** many hoses take couplings you can fit in the field; cut the hose square with a fine hacksaw
  (24 or 32 teeth per inch) ([FM 5-499, p. 49](lib:fm-5-499#page=49); [🖼️ field couplings](lib:fm-5-499#page=49)).
- **Pipe-thread compound:** keep it off the first two threads so none gets inside
  ([FM 5-499, p. 47](lib:fm-5-499#page=47)).
- **Quick couplers:** put the dust plugs in when you unhook an implement, or tie a plastic bag over the ends
  ([*Equipment Operator*, p. 103](lib:navy-equipment-operator-basic#page=103); [🖼️ quick couplers](lib:navy-equipment-operator-basic#page=103)).
- **Finding an air leak on the pump's suction side:** pour oil over each joint and listen; the noise changes at the
  leak ([FM 5-499, p. 137](lib:fm-5-499#page=137)).

### Clean fluid, the right fluid

- **Dirt is the main enemy.** Contamination causes "more hydraulic system failures than any other single source"
  ([*Construction Mechanic Advanced*, p. 252](lib:navy-construction-mechanic-advanced#page=252)). Clean round the filler
  before you open it ([*Equipment Operator*, p. 101](lib:navy-equipment-operator-basic#page=101)); cap open hoses and
  ports; **never wipe parts with rags**, whose lint clogs valves ([FM 5-499, pp. 45, 113](lib:fm-5-499#page=113)).
- **Water** gets in by condensation and turns to sludge; oil cooked **above 250 °F** breaks down and turns brown
  ([*Construction Mechanic Advanced*, p. 253](lib:navy-construction-mechanic-advanced#page=253)).
- **Use the fluid the manual names.** Hydraulic fluids are water-based, petroleum-based or synthetic, and the wrong one
  means draining, flushing and refilling ([*Equipment Operator*, p. 43](lib:navy-equipment-operator-basic#page=43)).
  "Do not mix hydraulic fluids or reuse old fluid," and filter what you pour in
  ([*Construction Mechanic Advanced*, p. 250](lib:navy-construction-mechanic-advanced#page=250)).
- **In a pinch:** no book in the library names a stand-in. *(Rule of thumb)*: for a system that takes petroleum oil
  (most tractors and loaders), top up with clean petroleum hydraulic or tractor fluid of about the same thickness,
  then drain and refill with the right one when you can. **Never brake fluid in a hydraulic system, and never
  hydraulic oil in brakes** ([*Construction Mechanic*, p. 378](lib:navy-construction-mechanic-3-and-2#page=378)).
- **Clean parts in clean solvent**, not carbon tetrachloride, which ruins rubber seals
  ([FM 5-499, p. 113](lib:fm-5-499#page=113)).

### Air in the system

Slower movement than normal can mean air in the system ([FM 5-499, p. 138](lib:fm-5-499#page=138)); air drawn into
the pump makes it noisy and makes the system chatter ([p. 137](lib:fm-5-499#page=137)). It escapes in the tank, where
the oil can foam and give it up ([*Equipment Operator*, p. 100](lib:navy-equipment-operator-basic#page=100)). Top up
the tank first. *(Rule of thumb)*: with the engine at idle, run each cylinder slowly all the way out and in several
times, so the air goes back to the tank and bubbles out there.

**Troubleshooting:** FM 5-499 has tables for a pump that won't deliver, no pressure, noise, creeping, slow action and
overheating, each with its causes and fixes ([pp. 136–139](lib:fm-5-499#page=136)).

📚 **Go deeper:** [FM 5-499 *Hydraulics*](lib:fm-5-499#page=136) — every part, and the troubleshooting tables; [Navy *Construction Mechanic Advanced*](lib:navy-construction-mechanic-advanced#page=250) — keeping equipment hydraulics clean. Pictures: [🖼️ a reservoir's design, FM 5-499 p. 34](lib:fm-5-499#page=34), [🖼️ single- and double-acting cylinders, *Equipment Operator* p. 102](lib:navy-equipment-operator-basic#page=102), [Hydraulic cylinder](wiki:Hydraulic_cylinder), [Hydraulic fluid](wiki:Hydraulic_fluid).

## 💉 Hydraulic dangers: injected oil and falling loads

- **A pinhole leak is a needle.** Equipment hydraulics run at **up to 3,000 psi**, with oil above 200 °F
  ([*Equipment Operator*, p. 103](lib:navy-equipment-operator-basic#page=103)); piston pumps reach 5,000 psi
  ([FM 5-499, p. 70](lib:fm-5-499#page=70)). The Navy warns that fuel spray through the skin "will cause blood
  poisoning" ([*Construction Mechanic Advanced*, p. 132](lib:navy-construction-mechanic-advanced#page=132)), and that
  high-pressure air "can cut through the skin, destroy tissue, cause air embolism, and death"
  ([p. 195](lib:navy-construction-mechanic-advanced#page=195)). Hydraulic oil from a pinhole does the same *(rule of
  thumb)*.
- **Never feel for a leak with your hand, and don't trust gloves.** Use cardboard or wood *(rule of thumb)*.
- **If oil gets under the skin, it is a surgical emergency, even when it looks like nothing.** The wound may be a dot
  that hardly hurts at first; the oil spreads and kills tissue over hours, and fingers and hands are lost. Get to
  whoever can operate, fast, and say it was injected oil. Don't wait to see *(rule of thumb: no book in the library
  covers the treatment)*. First aid until then: [Field Care](guide:FIELD-CARE-GUIDE).

![Two panels over a hydraulic hose. On the left, marked yes, a hand holds a piece of cardboard well away from the body and a fine jet from a pinhole in the hose marks a dark spot on it. On the right, marked no, a bare hand reaching for the same leak is crossed out in red. Below, a red-bordered box: if oil gets under the skin it is a surgical emergency, with a drawing of a fingertip marked by a single dot](img:VEHICLES-EQUIPMENT-GUIDE/hydraulic-pinhole-leak.svg)
*Hunt for a leak with cardboard or wood, never a hand ([*Equipment Operator*, p. 103](lib:navy-equipment-operator-basic#page=103); [FM 5-499, p. 70](lib:fm-5-499#page=70); a diagram drawn for this guide).*

- **Before you loosen anything:** lower every bucket, blade and implement to the ground, stop the engine, and work the
  levers back and forth to let the pressure out *(rule of thumb)*. Some systems store pressure in an
  **accumulator**: relieve it before you take it off ([FM 5-499, p. 39](lib:fm-5-499#page=39);
  [*Construction Mechanic Advanced*, p. 252](lib:navy-construction-mechanic-advanced#page=252)).
- **Never work under a raised load that is held only by hydraulics.** "Always lower the lift arms or boom to the
  ground or block them securely before performing any service"; no greasing or adjusting with the bucket raised and
  unblocked ([*Equipment Operator*, p. 235](lib:navy-equipment-operator-basic#page=235)). A loader's arms can drop
  "by accident": use the support strut ([p. 225](lib:navy-equipment-operator-basic#page=225);
  [🖼️ the strut](lib:navy-equipment-operator-basic#page=223)). "Never allow anyone to work under a raised blade or
  other attachment" ([p. 256](lib:navy-equipment-operator-basic#page=256)). A cylinder can creep down by itself through
  a worn seal ([FM 5-499, p. 138](lib:fm-5-499#page=138)).

📚 **Go deeper:** [Navy *Equipment Operator*, p. 235](lib:navy-equipment-operator-basic#page=235) — the loader and backhoe safety rules. Pictures: [High-pressure injection injury](wiki:High_pressure_injection_injury).

## 🚛 Air brakes
<!-- fold: How truck air brakes work, the pressures to watch, draining the tanks, spring brakes -->

Big trucks, some tractors' trailers and many machines stop with air: an engine-driven **compressor** fills **tanks**,
and the pedal sends air to a **chamber** at each wheel ([*Equipment Operator*, p. 88](lib:navy-equipment-operator-basic#page=88);
[🖼️ a typical system](lib:navy-equipment-operator-basic#page=88)).
- **Pressures:** the governor stops the compressor at about **125 psi** and starts it again at about **100**
  ([*Equipment Operator*, p. 89](lib:navy-equipment-operator-basic#page=89)). Keep **100 to 120 psi**; a warning must
  come on **below 60 psi**. A sudden loss means something burst ([p. 99](lib:navy-equipment-operator-basic#page=99)).
- **Drain every air tank at the end of each day**: water and oil collect, and "ice inside a brake system can make the
  brakes stop working" ([p. 89](lib:navy-equipment-operator-basic#page=89)).
- **Spring brakes** are the parking and emergency brakes: strong springs held off by air. Lose the air and they come
  on, at **20 to 45 psi**; don't wait for that, stop safely when the low-air warning comes
  ([p. 166](lib:navy-equipment-operator-basic#page=166)). Never take a spring-brake chamber apart: the spring inside
  can kill *(rule of thumb)*.
- **Compressed air itself is dangerous**: it can cut through skin and cause a fatal air embolism
  ([*Construction Mechanic Advanced*, p. 195](lib:navy-construction-mechanic-advanced#page=195)). Bleed an air line
  before you uncouple it ([*Equipment Operator*, p. 395](lib:navy-equipment-operator-basic#page=395)).

📚 **Go deeper:** [TM 9-8000](lib:tm-9-8000#page=680) — air, air-over-hydraulic and vacuum brakes; [Navy *Construction Mechanic Advanced*](lib:navy-construction-mechanic-advanced#page=150) — troubleshooting hydraulic and air brakes. Pictures: [🖼️ a typical air brake system, TM 9-8000 p. 680](lib:tm-9-8000#page=680), [🖼️ a brake chamber, p. 684](lib:tm-9-8000#page=684), [Air brake (road vehicle)](wiki:Air_brake_(road_vehicle)).

## 🔌 Electric cars and hybrids

- **Two batteries.** The big pack is **300 to 400 volts or more**, with 800-volt cars on the road; the safe limits for
  people are 50–60 volts DC and 30 volts AC ([NTSB SR-20/01, pp. 15, 17](lib:safety-risks-from-lithium-ion#page=15)).
  Beside it is an ordinary **12-volt battery** ([p. 16](lib:safety-risks-from-lithium-ion#page=16)), which powers the
  computer that runs the big pack: cutting its cable "will depower the battery management system"
  ([p. 19](lib:safety-risks-from-lithium-ion#page=19)). So **a flat 12-volt battery means a dead car**, however full the
  pack. Keep it charged and jump it like any car's *(rule of thumb; follow the owner's manual)*.
- **Orange cables carry the high voltage** ([🖼️ a wrecked SUV's orange cables, p. 30](lib:safety-risks-from-lithium-ion#page=30)).
  Never cut, open or probe them or the pack. Cutting the "cut loops" rescuers use isolates the pack but "will not
  remove energy from the high-voltage battery"; draining one takes the maker's tools and a specialist
  ([p. 19](lib:safety-risks-from-lithium-ion#page=19)). Hybrids carry a high-voltage pack too, smaller: the Volt's
  held 16 kWh ([p. 15](lib:safety-risks-from-lithium-ion#page=15)).
- **Keeping the pack healthy in storage:** lithium keeps best part-charged and cool. Lithium cells are best stored at
  **20–40% charge** near room temperature, and not charged below freezing
  ([Lighting Global, pp. 7–8](lib:lighting-global#page=7)). *(Rule of thumb)*: leave a parked EV at about half charge,
  12-volt battery disconnected or kept up.
- **How big is the pack?** A 2011 Chevrolet Volt held **16 kWh**; a 2019 Tesla Model S, **60 to 100 kWh**
  ([NTSB, p. 15](lib:safety-risks-from-lithium-ion#page=15)).
- **Charging from home solar** *(arithmetic)*: each panel watt gives about 0.85 Wh for each hour of full sun
  ([Practical Action, p. 4](lib:practical-action-solar-photovoltaic#page=4)). So 1,000 W of panels with 4 sun hours
  makes about **3.4 kWh a day**: about 6% of a 60 kWh pack. In a dark winter month, half that or less
  ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#a-worked-example) has the sun hours). An EV is a summer vehicle on a
  small solar system.
- **Charging from a generator** *(arithmetic)*: a 120-volt outlet on a 15-amp circuit can give at most 1,800 W, and a
  car's plug-in cord usually draws less, about 1,400 W *(rule of thumb)*. Ten hours then add about 14 kWh, a quarter
  of a 60 kWh pack. Run the generator outdoors only ([Engines guide](guide:ENGINES-AND-MOTORS-GUIDE#generators)).
- **A dead EV's pack** holds many times the energy of a house battery bank: a 60 kWh pack is about eleven banks of
  four golf-cart batteries ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#a-worked-example), *arithmetic*). But it is
  hundreds of volts until it is taken apart into modules, which is work for someone trained. Reusing lithium packs:
  [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#lithium-lifepo4-and-salvaged-packs); what never to cut or open:
  [Salvage](guide:SALVAGE-GUIDE#never-cut-burn-or-open-these).
- **Fire.** A damaged pack can go into "thermal runaway," venting toxic and flammable gas and throwing out pieces
  ([NTSB, pp. 17–18](lib:safety-risks-from-lithium-ion#page=17)). One crashed SUV took **more than 20,000 gallons of
  water** over two hours ([p. 22](lib:safety-risks-from-lithium-ion#page=22)); another pack caught fire again **5 days
  after the crash** ([p. 28](lib:safety-risks-from-lithium-ion#page=28)). Fires can flare again "within several hours
  to a day or more," with a whoosh or popping and white smoke first. **Keep a damaged EV 50 feet from any building or
  other vehicle**, and keep cooling a burning pack with water even after the flames are gone
  ([p. 56](lib:safety-risks-from-lithium-ion#page=56)). The gas is toxic ([p. 18](lib:safety-risks-from-lithium-ion#page=18)):
  stay upwind *(rule of thumb)*.

📚 **Go deeper:** [NTSB SR-20/01](lib:safety-risks-from-lithium-ion#page=15) — how EV packs fail and burn; [Lighting Global](lib:lighting-global#page=7) — lithium care and storage. Pictures: [Electric vehicle battery](wiki:Electric_vehicle_battery), [Hybrid electric vehicle](wiki:Hybrid_electric_vehicle), [Thermal runaway](wiki:Thermal_runaway).

## 🆘 If this goes wrong

| What happened | What to do |
|---|---|
| Oil or fuel squirted into the skin | Surgery, fast, even if it looks small ([above](#hydraulic-dangers-injected-oil-and-falling-loads)) |
| Someone pinned under a tractor or a dropped load | Lift with a jack or a lever and blocks, never by bare strength; then [bleeding, shock and broken bones](guide:FIELD-CARE-GUIDE#stopping-life-threatening-bleeding-then-shock) *(rule of thumb)* |
| Battery acid in the eyes or on skin | Flush with water at least 15 minutes ([Off-Grid Power](guide:OFF-GRID-POWER-GUIDE#battery-safety)) |
| Steam or coolant burn | [Burns](guide:FIELD-CARE-GUIDE#burns) |
| Brake pedal sinks or goes soft on the road | Pump it, downshift, use the parking brake gently; then find the leak and bleed the brakes ([Brakes](#brakes)) *(rule of thumb)* |
| Temperature gauge climbing | Stop; let it cool before opening anything; check the belt, hoses and coolant ([Cooling](#cooling-radiator-hoses-and-belts)) |
| Air pressure warning on a truck | Stop safely now, before the spring brakes lock ([Air brakes](#air-brakes)) |
| Smoke, popping or hissing from an electric car | Get everyone out and 50 feet away; water from a distance ([Electric cars](#electric-cars-and-hybrids)) |
| Hair or clothes caught in a PTO | Disengage the PTO and stop the engine before anyone reaches in ([NIOSH, p. 7](lib:preventing-scalping#page=7)); then [bleeding and shock](guide:FIELD-CARE-GUIDE#stopping-life-threatening-bleeding-then-shock) |

## ⚠️ Old advice in the library to ignore

| Old book | What it says | Do this instead |
|---|---|---|
| [Henley's *Formulas* (1916), p. 365](lib:henleys-twentieth-century#page=365) | For a car's radiator, "a saturated solution of common salt is one of the best things to use. It does not affect the metal of the engine" | Salt eats radiators and water jackets *(rule of thumb)*. Use ethylene glycol, or glycerin, and add a rust inhibitor to plain water ([TM 9-8000, p. 238](lib:tm-9-8000#page=238)) |
| [Navy *Construction Mechanic* (1978), p. 378](lib:navy-construction-mechanic-3-and-2#page=378) | Clean brake dust off "with a dry brush or compressed air" | Old linings can hold asbestos, which "can cause cancer": wear a filter mask ([TM 9-8000, p. 655](lib:tm-9-8000#page=655)) and wipe the dust up wet *(rule of thumb)* |
| [Navy *Construction Mechanic* (1978), p. 183](lib:navy-construction-mechanic-3-and-2#page=183) | "Polarize" a generator by touching a jumper wire across the regulator | That was for old DC generators. **"Do not attempt to polarize the alternator"** that nearly every vehicle has now ([*Alternator and Regulator Servicing*, p. 16](lib:alternator-and-regulator-servicing#page=16)) |

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; the other links are photos in the offline Wikipedia.

**Cars and pickups**
- Inside a battery — [🖼️ TM 9-8000, p. 284](lib:tm-9-8000#page=284); [🖼️ *Equipment Operator*, p. 93](lib:navy-equipment-operator-basic#page=93); [Automotive battery](wiki:Automotive_battery)
- Cooling system and pressure cap — [🖼️ TM 9-8000, p. 237](lib:tm-9-8000#page=237); [🖼️ p. 245](lib:tm-9-8000#page=245); [🖼️ *Equipment Operator*, p. 45](lib:navy-equipment-operator-basic#page=45); [Antifreeze](wiki:Antifreeze)
- Adjusting a drive belt — [🖼️ *Equipment Operator*, p. 47](lib:navy-equipment-operator-basic#page=47)
- Hydraulic brakes, master cylinder and wheel cylinders — [🖼️ TM 9-8000, p. 671](lib:tm-9-8000#page=671); [🖼️ p. 672](lib:tm-9-8000#page=672); [🖼️ p. 673](lib:tm-9-8000#page=673); [Hydraulic brake](wiki:Hydraulic_brake)
- Drum and disc brakes — [🖼️ *Equipment Operator*, p. 86](lib:navy-equipment-operator-basic#page=86); [Drum brake](wiki:Drum_brake), [Disc brake](wiki:Disc_brake)
- Bleeding brakes — [🖼️ *Construction Mechanic*, p. 277](lib:navy-construction-mechanic-3-and-2#page=277); [Brake bleeding](wiki:Brake_bleeding)
- Rims, lock rings and the safety cage — [🖼️ TM 9-8000, pp. 612–613](lib:tm-9-8000#page=612); [🖼️ *Equipment Operator*, p. 78](lib:navy-equipment-operator-basic#page=78); [🖼️ p. 79](lib:navy-equipment-operator-basic#page=79)
- Patching a tire — [🖼️ *Equipment Operator*, p. 81](lib:navy-equipment-operator-basic#page=81); [Tire](wiki:Tire)
- Winching, snatch blocks and self-recovery — [🖼️ *Equipment Operator*, p. 112](lib:navy-equipment-operator-basic#page=112); [🖼️ p. 113](lib:navy-equipment-operator-basic#page=113); [🖼️ p. 115](lib:navy-equipment-operator-basic#page=115); [Winch](wiki:Winch)

**Diesels**
- A glow plug — [🖼️ *Equipment Operator*, p. 34](lib:navy-equipment-operator-basic#page=34); [Glow plug](wiki:Glow_plug)
- Flame heater and ether starting aids — [🖼️ TM 9-8000, p. 201](lib:tm-9-8000#page=201)

**Tractors**
- A baler's PTO driveline with an open-bottomed guard — [🖼️ NIOSH Alert, p. 4](lib:preventing-scalping#page=4); [Power take-off](wiki:Power_take-off)
- Tractor safety checklist — [🖼️ TRAC-SAFE, p. 72](lib:trac-safe#page=72); [Rollover protection structure](wiki:Rollover_protection_structure), [Three-point hitch](wiki:Three-point_hitch)
- A loader's support strut — [🖼️ *Equipment Operator*, p. 223](lib:navy-equipment-operator-basic#page=223); [Loader (equipment)](wiki:Loader_(equipment))

**Hydraulics**
- A basic system: tank, pump, valve, cylinder — [🖼️ *Equipment Operator*, p. 100](lib:navy-equipment-operator-basic#page=100); [🖼️ FM 5-499, p. 16](lib:fm-5-499#page=16)
- The hydraulic jack — [🖼️ FM 5-499, p. 26](lib:fm-5-499#page=26); [Jack](wiki:Jack_(device))
- A reservoir — [🖼️ FM 5-499, p. 34](lib:fm-5-499#page=34)
- Hoses, twisting and field couplings — [🖼️ *Equipment Operator*, p. 103](lib:navy-equipment-operator-basic#page=103); [🖼️ FM 5-499, p. 44](lib:fm-5-499#page=44); [🖼️ p. 49](lib:fm-5-499#page=49); [Hydraulic machinery](wiki:Hydraulic_machinery)
- Single- and double-acting cylinders — [🖼️ *Equipment Operator*, p. 102](lib:navy-equipment-operator-basic#page=102); [Hydraulic cylinder](wiki:Hydraulic_cylinder)

**Air brakes**
- A typical system, the compressor's governor and a brake chamber — [🖼️ *Equipment Operator*, p. 88](lib:navy-equipment-operator-basic#page=88); [🖼️ TM 9-8000, p. 680](lib:tm-9-8000#page=680); [🖼️ p. 683](lib:tm-9-8000#page=683); [🖼️ p. 684](lib:tm-9-8000#page=684); [Air brake (road vehicle)](wiki:Air_brake_(road_vehicle))

**Electric cars**
- Orange high-voltage cables on a wrecked SUV — [🖼️ NTSB, p. 30](lib:safety-risks-from-lithium-ion#page=30); [Electric vehicle battery](wiki:Electric_vehicle_battery)

---

## 🔗 Related guides

- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — small gas engines, diesel bleeding and injectors, generators
- [Fuel](guide:FUEL-GUIDE) — storing and testing gasoline and diesel, gelling, water, getting fuel out of tanks
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) — lead-acid and lithium batteries, inverters, charging from a car
- [Salvage: Useful Things From Broken Things](guide:SALVAGE-GUIDE) — what to take from a dead car or truck
- [Knots, Rope & Cordage](guide:KNOTS-ROPE-GUIDE) — safe rope work, blocks and tackle for pulling a vehicle out
- [Bicycles & Carts](guide:BICYCLES-CARTS-GUIDE) — when the fuel is gone: bikes, trailers, carts and tube patching
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — harness and draft work instead of a tractor
- [Field Care](guide:FIELD-CARE-GUIDE) — bleeding, shock, broken bones and burns
- [Blacksmithing and Hand Tools](guide:BLACKSMITHING-GUIDE) — making and repairing parts and tools
- [EMP and solar storms](guide:EMP-GUIDE) — what an EMP would really do to vehicles
- [Masonry & Roads](guide:MASONRY-ROADS-GUIDE) — keeping gravel roads and culverts passable
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — the local picture and where everything is on the drive
- [Batteries: Keeping Them, Charging Them, Reviving Them](guide:BATTERIES-GUIDE) — a vehicle battery that sits unused, winter storage, and reviving a sulfated one

---

*Old manuals are fine for how things work; for your own vehicle or machine, its manual and the numbers on it come
first.*
