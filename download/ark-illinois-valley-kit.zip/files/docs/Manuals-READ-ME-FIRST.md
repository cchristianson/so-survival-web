# Manuals — Focused Core Survival & Repair Kit

Practical manuals for survival, repair and self-reliance. The easiest way to search them all is the
**Library Assistant** (the **START** file for your device; see
[Start on any device](guide:START-ON-ANY-DEVICE)). Or open them directly:

- **PDF books** open in any web browser.
- **Encyclopedias** (`.zim` files) open in the Kiwix app. See [Wikipedia and Kiwix](guide:HOW-TO-USE-KIWIX).

---

## What's here

| Folder | What's inside |
|---|---|
| `ArmyFieldManuals\` | US Army manuals: survival, first aid, hand tools, carpentry, **auto mechanics**, rigging, field cooking |
| `Repair-iFixit\` | iFixit repair guides: **cars, appliances, electronics, phones, tools** |
| `DIY-Appropedia\` | Appropedia: **plumbing, electrical, building, energy, water, food, farming** |
| `Survival-Water-Food\` | Survival, water purification, food, knots |
| `Radio-Communications\` | How ham, CB and shortwave radio work, and emergency radio |

---

## Why there are no "code books"

Modern code books (electrical and plumbing codes) and brand car manuals (Haynes, Chilton) are
copyrighted, so they aren't included. The free iFixit and Appropedia encyclopedias and the Army
manuals cover the same repairs. Buy the official code books from their publishers if you need them.
