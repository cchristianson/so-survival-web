# ♨️ Heat into Work and Power

Can a fire do more than keep you warm? Yes: it can pump water, turn a saw, charge a phone and even make
ice. This guide gives the honest numbers first, then covers stove-top thermoelectric generators, small
steam engines and **boiler safety**, hot-air (Stirling) engines, refrigerators that run on a flame, and
other ways to put heat to work. The books added for this guide are in
`Southern-Oregon\Off-Grid-Power\Heat-Engines` (download list: local/library-files.txt). Wood gas, the
best way to run a generator on wood, is in the [Fuel guide](guide:FUEL-GUIDE) and the
[Engines guide](guide:ENGINES-AND-MOTORS-GUIDE); storing heat in water and stone is in the
[Storing Energy guide](guide:STORING-ENERGY-GUIDE). Where this guide works a number out, it says
*(arithmetic)*; check it with the [Practical Math guide](guide:PRACTICAL-MATH-GUIDE) or the
[Calculator](guide:CALCULATOR).

> ### The short version
> - **Use heat as heat first.** A stove gets about **half** of the wood's heat into the room, the pot or
>   the water tank; the heat engines in this guide turn only **1 to 10%** of it into work or electricity
>   ([Aprovecho, p. 18](lib:aprovecho-capturing-heat-three#page=18); table below).
> - **For real electricity from wood, run an engine on wood gas.** About **3 lb of wood per kWh** at
>   best, against **10–25 lb** for a small steam plant *(arithmetic, below)*.
> - **A stove-top thermoelectric generator is worth having** for phones, LED lights and radios while
>   you heat or cook anyway. Real stoves in a DOE contest made **14 to 268 watts**
>   ([DOE stove report, p. 17](lib:wood-stove-design-challenge-2018#page=17)).
> - **Boilers explode.** Never make one from a tank, a pipe, a water heater or a gas cylinder
>   *(rule of thumb)*. Test a
>   boiler with **water** at 1½ times its working pressure, never with steam or air, and try the safety
>   valve **every morning** ([*Maxims*, p. 29](lib:maxims-and-instructions-for-the-boiler-room#page=29),
>   [p. 121](lib:maxims-and-instructions-for-the-boiler-room#page=121),
>   [p. 285](lib:maxims-and-instructions-for-the-boiler-room#page=285)).
> - **If the water drops out of sight in the glass, kill the fire and never pump in water**
>   ([Navy *Boilerman*, p. 324](lib:boilerman-3-and-2#page=324)).
> - **Hot-air (Stirling) engines are safe but weak:** an antique one made about **50 watts**
>   ([NASA *Stirling Manual*, p. 8](lib:stirling-engine-design-manual#page=8)). Use one to pump water slowly.
> - **A gas or kerosene absorption refrigerator is the best heat-driven machine you can own.** Keep it
>   level: one stopped cooling when tipped just **1 to 2 degrees**
>   ([NBS report, p. 33](lib:propane-fired-absorption-refrigerator#page=33)).
> - **Every flame makes carbon monoxide**
>   ([MSU *Portable Kerosene Heaters*, p. 3](lib:some-considerations-about-portable-kerosene-heaters#page=3)).
>   Vent burners outdoors and keep a CO alarm with batteries *(rule of thumb)*.

---

## 🧮 The honest numbers: what a pound of wood can do

A pound of dry wood holds about **8,600 BTU** of heat, and a stove gets roughly **50%** of it into the
house ([Aprovecho *Capturing Heat Three*, p. 18](lib:aprovecho-capturing-heat-three#page=18)). That is
about **2.5 kWh** of heat in the wood and 1.25 kWh delivered (1 kWh = 3,412 BTU) *(arithmetic)*. One
horsepower is 746 watts ([DOE *Wind Power for Farms*, p. 27](lib:wind-power-for-farms-homes-and-small-industry-us-doe-1978#page=27)),
so one horsepower for an hour is 2,545 BTU of work *(arithmetic)*.

| Way of using the heat | Share of the wood's heat you get back | From 1 lb of dry wood | Worth building? |
|---|---|---|---|
| **Heat used as heat** (house, cooking, hot water, drying) | About **50%** as useful heat | About 1.25 kWh of heat | **Yes, always first** |
| **Wood gas in an engine generator** | About **12%** as electricity, at a good steady load | About 0.3 kWh (3 lb per kWh) | **Yes**, if you can build and tend a gasifier |
| **Hot-air (Stirling) engine** | **7–10%** for the best small factory engines; homemade ones far less | 25–200 Wh | For **slow pumping**; homemade ones are teaching models |
| **Small steam engine** (no condenser) | About **2–4%** as shaft work | 50–100 Wh of work; 10–25 lb of wood per kWh | Only for heavy mechanical work, with a real boiler and a trained operator |
| **Thermoelectric module on a stove** | About **3%** of the heat that passes through it; well under 1% of the stove's whole fire | A few watt-hours, but the heat still warms the room | **Yes**, as a free extra while you heat or cook |

Where these come from *(arithmetic, from the pages named)*:
- **Wood gas:** "about 20 lb of wood have the energy equivalence of one gallon of gasoline"
  ([FEMA *Wood Gas Generator*, p. 70](lib:fema-construction-of-a-simplified-wood-gas#page=70)). A
  gallon of gasoline is about 125,000 BTU (18,800 BTU a pound, 7½ gallons weigh 50 lb), and an average
  engine is "approximately 20 to 25 percent thermally efficient"
  ([TM 9-8000, p. 74](lib:tm-9-8000-principles-of-automotive-vehicles#page=74)). At 20–25%, less about a
  fifth lost in the generator *(rule of thumb)*, 20 lb of wood makes about 6–7 kWh. A generator
  running a light load wastes much more fuel per kWh *(rule of thumb)*.
- **Steam:** "5 pounds is a common consumption of coal" per horsepower-hour in stationary engines
  ([Hawkins *New Catechism*, p. 19](lib:new-catechism-of-the-steam-engine#page=19)), and coal holds about
  11,000–12,700 BTU a pound ([Univ. of Minnesota EB 436, p. 16](lib:univ-of-minnesota-heating-the-home-with-wood#page=16)):
  about **4%**. A farm engine boiler is sized to boil off **7½ gallons of water an hour per horsepower**
  ([Maggard *Rough and Tumble*, p. 53](lib:rough-and-tumble-engineering#page=53)); at about 1,146 BTU in
  each pound of steam ([*Maxims*, p. 202](lib:maxims-and-instructions-for-the-boiler-room#page=202)) that
  is 3.6% of the heat in the steam. If the boiler gets about half the fire's heat into the water
  (Aprovecho's 50% rule of thumb, p. 18), that is about **2%** of the wood's heat.
- **Stirling:** a small Philips air engine made at most about **0.48 kW** at **7.75%**, and about
  **10%** at its best setting ([NASA *Stirling Manual*, p. 57](lib:stirling-engine-design-manual#page=57)).
- **Thermoelectric:** a 25-watt Stirling generator, about 10% efficient, "uses only 27 percent of the
  fuel required by a 25 w (e) thermo-electric generator"
  ([NASA, p. 405](lib:stirling-engine-design-manual#page=405)), which puts that thermoelectric generator
  near **3%**. On a wood stove most of the fire's heat never passes through the modules. The best stove
  in the DOE contest made 276 Wh in 2½ hours
  ([DOE stove report, p. 17](lib:wood-stove-design-challenge-2018#page=17)); if it burned about 6 lb
  of wood an hour, like Aprovecho's example house stove (p. 18), that is under 1% of the fire.

**What it means:** a stove that heats the house and also charges the phones is a good deal. A fire built
only to make electricity is not: a steam plant burns 10 to 25 lb of wood for each kWh, about what a
fridge uses in a day *(rule of thumb)*. If you need real power, see wood gas in the
[Fuel guide](guide:FUEL-GUIDE), and solar and creek hydro in the [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE).

📚 **Go deeper:** [NASA *Stirling Engine Design Manual*, pp. 7–8](lib:stirling-engine-design-manual#page=7) — why heat engines all need a hot side and a cold side; [Aprovecho, pp. 16–18](lib:aprovecho-capturing-heat-three#page=16) — how much heat a house really needs.

## 🔋 Stove-top thermoelectric power

### How a thermoelectric generator works

Heat one end of a joint between two different metals and a small voltage appears across it: the
**Seebeck effect** ([Kuphaldt *Lessons in Electric Circuits* vol. 1, p. 320](lib:lessons-in-electric-circuits-vol-1-dc-kuphaldt#page=320)).
Many junctions in series make a **thermopile**: heat goes into one set and the other set is "bonded to
a heat sink of some sort (air- or water-cooled)"
([p. 323](lib:lessons-in-electric-circuits-vol-1-dc-kuphaldt#page=323)). A modern module (TEG,
thermoelectric generator) is a flat square tile packed with such junctions. Power comes from the
**difference** in temperature between its two faces, so a hot stove with a warm cold side makes almost
nothing *(rule of thumb)*. You can see the effect with a copper wire, an iron wire, a candle and a
voltmeter ([Kuphaldt vol. 6, p. 117](lib:lessons-in-electric-circuits-vol-6-experiments-kuphaldt#page=117)).

### What to expect in watts

- **Measured on real wood stoves:** in a 2½-hour DOE-funded contest, five stoves fitted with
  thermoelectric generators peaked at **268, 139, 85, 32 and 14 watts** and made **276, 235, 118, 47
  and 28 watt-hours** ([DOE stove report, p. 17](lib:wood-stove-design-challenge-2018#page=17)).
  The two that reached the market "were larger units closer to boilers"
  ([p. 4](lib:wood-stove-design-challenge-2018#page=4)).
- **What that runs:** such stoves "can generate enough power to charge cell phones and light a home"
  in an outage ([p. 2](lib:wood-stove-design-challenge-2018#page=2)). A phone charge is roughly
  10–15 Wh and an LED bulb 3–5 W *(rule of thumb)*, so 28 Wh is two phone charges, and 276 Wh is a
  lit house for an evening plus every phone.
- **A single small module** on a stove top makes a few watts; Wikipedia notes they are "put on top of a
  wood or coal burning stove" and "generate enough electricity to power an LED light or charge a mobile
  device" ([Thermoelectric generator](wiki:Thermoelectric_generator)).
- **Stove fans** (the little fans that sit on a stove and spin by themselves) run on the same modules
  (same article). They push warm air into the room with no wiring at all.

### Choosing modules: TEG or salvaged Peltier

- **Modules sold as TEGs** (generator modules) are built to take a hot side. **Peltier modules** from
  12-volt camping coolers, wine coolers and computer coolers are built for cooling, but they also
  generate when heated on one face, usually less than a true TEG *(rule of thumb)*.
- **Heat limits:** most modules are bismuth telluride, which Wikipedia lists among the low-temperature
  materials, "up to around 450 K" (about 350 °F, 177 °C)
  ([Thermoelectric generator](wiki:Thermoelectric_generator)). Cooling modules are often soldered for
  less. Never set a module straight on a stove top running at full heat; put a **steel or aluminum
  plate** between them, check it with a stove thermometer, and stay under the seller's rating, or
  about **250 °F (120 °C)** for a salvaged Peltier you know nothing about *(rule of thumb)*.
- **Testing a salvaged module:** hold one face on a cup of hot water and the other in the air, and read
  the voltage on a meter; no voltage means a broken module *(rule of thumb)*.

### Keeping the cold side cold

The cold side is half the machine. Wikipedia: "The cold side must be cooled by air or water"
([Thermoelectric generator](wiki:Thermoelectric_generator)).
1. Clamp the module firmly between the hot plate and a **heat sink** (a finned block from an old
   computer or amplifier) with a thin smear of heat-sink paste on both faces *(rule of thumb)*.
2. **Water cooling works best:** a flat-bottomed pot or a closed metal box of water on top of the
   module. The water warms, so top it up or swap it; never let it boil dry *(rule of thumb)*.
3. **Air cooling:** a big finned heat sink, ideally with a small fan run from the module's own output
   *(rule of thumb)*.
4. A module whose two faces reach the same temperature makes **nothing**; if the output sags after an
   hour, the cold side has warmed up *(rule of thumb)*.

### Getting usable 5 V and 12 V out of it

A single module gives a few volts that rise and fall with the fire, so it needs a regulator between it
and anything you care about *(rule of thumb)*:
- **Phones and USB lights:** wire two to four modules in **series** (plus of one to minus of the next)
  and feed a small **DC-DC converter** with a USB socket: a **buck** converter steps a higher voltage
  down to 5 V, a **boost** converter steps a lower voltage up
  ([Buck converter](wiki:Buck_converter); [Boost converter](wiki:Boost_converter)). Never plug a phone
  straight into a module *(rule of thumb)*.
- **A 12-volt battery:** use a converter set to about 14 V, or a small charge controller, plus a
  **blocking diode** so the battery can't push current back through the modules at night
  *(rule of thumb)*. Charging limits and controllers are in "Charge controllers and inverters" in the
  [Off-Grid Power guide](guide:OFF-GRID-POWER-GUIDE); diodes are in "Motors as generators" in the
  [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE).
- **Good loads:** phones, LED lights, a radio receiver (see the [Radio guide](guide:RADIO-GUIDE)), a
  fan. **Bad loads:** anything that heats (kettles, heaters, hair dryers); use the stove for heat.

📚 **Go deeper:** [DOE *Wood Stove Design Challenge* report](lib:wood-stove-design-challenge-2018#page=17) — the measured stoves and how they were tested ([p. 21](lib:wood-stove-design-challenge-2018#page=21)); [Kuphaldt vol. 1, pp. 320–324](lib:lessons-in-electric-circuits-vol-1-dc-kuphaldt#page=320) — thermocouples, thermopiles and the Peltier effect.

## 🚂 Steam: what a small engine can do

**What steam is good at:** steady, heavy mechanical work from any fuel that burns. Farm steam engines
were belted to threshing machines, and a steam engine copes with a load that changes a lot:
Maggard's farm engine might "do eight horse work one day and sixteen horse work the next day"
([Maggard *Rough and Tumble*, p. 11](lib:rough-and-tumble-engineering#page=11)).

**What a small one needs:**
- **Water:** about **7½ gallons an hour for each horsepower**
  ([Maggard, p. 53](lib:rough-and-tumble-engineering#page=53)). A 1-hp engine running an 8-hour day
  boils off 60 gallons unless you condense it *(arithmetic)*.
- **Wood:** at 2–4%, one horsepower-hour (746 watt-hours of work) takes about **7–15 lb of dry wood**
  *(arithmetic, from the table above)*. Someone has to cut, split and feed it.
- **A real boiler:** a factory boiler for a ½-horsepower engine was "tested at 160 pounds cold water
  pressure" and rated "safe to run it at a steam pressure of 75 to 100 pounds"
  ([Collins *Boys' Book of Engine-Building*, p. 267](lib:boys-book-of-engine-building#page=267)).
  Watson's book gives dimensioned drawings for engines and boilers "from five horse power down to model
  sizes" ([Watson *Small Engines and Boilers*, p. 13](lib:small-engines-and-boilers-watson#page=13)),
  but a pressure boiler is skilled shop work in seamless or brazed tube
  ([p. 118](lib:small-engines-and-boilers-watson#page=118)); a soldered tin boiler "is merely a
  makeshift" ([p. 115](lib:small-engines-and-boilers-watson#page=115)).
- **A trained operator** who stays with it the whole time it is under pressure. Hawkins: "Don't let
  any one talk to you when firing"
  ([*Maxims*, p. 48](lib:maxims-and-instructions-for-the-boiler-room#page=48)).

### Turning a pump, saw or generator

- **Belts** carry the power from the engine's flywheel to the machine; a belt "ought to sag slightly
  as it hugs the pulley closer, and will last much longer"
  ([Maggard, p. 138](lib:rough-and-tumble-engineering#page=138)).
- **A pump or a saw** suits steam best: both take steady power, and a saw can wait while the pressure
  comes back up *(rule of thumb)*.
- **A generator:** belt the flywheel up to a car alternator or a permanent-magnet DC motor and charge
  batteries; the speeds and wiring are in "Motors as generators" in the
  [Engines guide](guide:ENGINES-AND-MOTORS-GUIDE). Steam engines slow down under load, so a
  **governor** or a charge controller is needed to keep the voltage steady *(rule of thumb)*.

### Condensing and reusing the water

- **Exhaust steam still holds most of its heat.** At 212 °F each pound of exhaust steam "contains 1,146
  heat units" (BTU) ([*Maxims*, p. 202](lib:maxims-and-instructions-for-the-boiler-room#page=202)).
  Pass it through a **feed-water heater** to warm the water going into the boiler: "All the heat
  imparted to the feed water, before it enters the boiler, is so much saved"
  ([p. 201](lib:maxims-and-instructions-for-the-boiler-room#page=201)).
- **Heat buildings with it:** in most works "the exhaust steam produced will very nearly, if not quite
  supply sufficient exhaust steam to furnish all the heat required for" warming
  ([p. 271](lib:maxims-and-instructions-for-the-boiler-room#page=271)).
- **Condensing it** turns the steam back into water: the Navy's condensers "recover feed water by
  condensing exhaust steam" ([Navy *Boilerman*, p. 245](lib:boilerman-3-and-2#page=245)). Condensed
  steam is soft water and lays down little scale *(rule of thumb)*. It takes a lot of cooling water:
  about **seventy gallons** an hour for each horsepower
  ([Hawkins *New Catechism*, p. 361](lib:new-catechism-of-the-steam-engine#page=361)). A coil in a creek
  or a big tank is the homestead version *(rule of thumb)*.
- **Use soft water.** Hawkins wants "soft or rain water" even in a gas engine's water jacket, because
  hard water fills it with lime ([*New Catechism*, p. 296](lib:new-catechism-of-the-steam-engine#page=296));
  a boiler needs it more *(rule of thumb)*. Scale on boiler plates is
  "a more or less perfect non-conductor of heat"
  ([*Maxims*, p. 154](lib:maxims-and-instructions-for-the-boiler-room#page=154)), and the plate under it
  can be "heated to redness" ([p. 152](lib:maxims-and-instructions-for-the-boiler-room#page=152)).

## 💥 Boiler safety: read this before you light a fire under anything closed

### Why boilers explode

"The one great cause of boiler explosion is the inability of the boiler to withstand the pressure to
which it is subjected at the time"
([Hawkins *Maxims*, p. 284](lib:maxims-and-instructions-for-the-boiler-room#page=284)). Hawkins lists
the reasons (pp. 284–285):
1. **Bad design** (not enough stays and braces).
2. **Bad workmanship.**
3. **Bad material:** blisters and flaws in the plate.
4. **Too much pressure:** a reckless operator, a wrong gauge or a stuck safety valve.
5. **Overheated plates from low water.**
6. **Scale and mud** that keep the water off the iron.

The farm engineer's version: "A properly constructed boiler never explodes, except from low water or
high pressure" ([Maggard, p. 20](lib:rough-and-tumble-engineering#page=20)). The damage comes from the
hot water flashing into steam all at once when the shell lets go
([*Maxims*, p. 284](lib:maxims-and-instructions-for-the-boiler-room#page=284);
[Boiler explosion](wiki:Boiler_explosion)).

### What never to use as a boiler

*(Rule of thumb, from the failures in the books)*
- **No propane or air tanks, fire extinguishers, pipe with caps on, kegs, milk cans or old water
  heaters** as a steam boiler. They were never built or tested for fire on one side
  and steam on the other, and you can't see the corrosion inside.
- **No soft-soldered or tin boilers:** a soldered tin boiler is good for about **10 pounds** and "is
  merely a makeshift" ([Watson, p. 115](lib:small-engines-and-boilers-watson#page=115)).
- **Even water heaters go bang:** Aprovecho's "most carefully built wood fired showers … occasionally
  leaked or even exploded!" ([Aprovecho, p. 9](lib:aprovecho-capturing-heat-three#page=9)). Any closed
  tank over a fire needs a working relief valve (see "Hot water" in the
  [Storing Energy guide](guide:STORING-ENERGY-GUIDE)).
- **Never repair pressure parts yourself:** no welding, brazing, patching or plugging of a cracked,
  bulged, thinned or leaking shell, tube or firebox. Retire it from pressure use.

### The safety valve

- **Try it every morning before lighting the fire,** by lifting the lever or rod by hand
  ([*Maxims*, p. 29](lib:maxims-and-instructions-for-the-boiler-room#page=29)). A valve that sticks
  can stick "even though tried every day", if it is only lifted and dropped back
  ([p. 198](lib:maxims-and-instructions-for-the-boiler-room#page=198)).
- **Nothing between the valve and the boiler:** any shut-off valve there "should be taken out at once"
  ([p. 131](lib:maxims-and-instructions-for-the-boiler-room#page=131)).
- **Never add weight, wedge it or screw it down** to hold more steam. Maggard warns that a weak gauge
  tempts you to screw the valve down, when you may already have **110 pounds** or more on a boiler set
  for 100 ([Maggard, p. 79](lib:rough-and-tumble-engineering#page=79)).
- **Test the gauge against a known-good gauge** before you set the safety valve by it (same page).
- **If the pressure is already far too high,** don't suddenly lift the valve wide open: the rush can
  hit the shell like a water hammer ([*Maxims*, p. 198](lib:maxims-and-instructions-for-the-boiler-room#page=198)).
  Pull or smother the fire and let it cool *(rule of thumb)*.
- How a lever safety valve is built: [🖼️ sectional view](lib:maxims-and-instructions-for-the-boiler-room#page=191);
  [Safety valve](wiki:Safety_valve).

### Water level: the gauge glass and the try-cocks

- **Keep the water in the glass, at the same height all day**
  ([*Maxims*, p. 48](lib:maxims-and-instructions-for-the-boiler-room#page=48)). Above the top of the
  glass, water carried into a hard-working engine can "knock out a cylinder head"; below the lower
  gauge "you may get your own head knocked off"
  ([Maggard, p. 19](lib:rough-and-tumble-engineering#page=19)).
- **Don't trust the glass alone.** Open the **try-cocks** (gauge cocks): the lower one should give
  water and the upper one steam. Use them every day or they lime up and become useless
  ([Maggard, p. 20](lib:rough-and-tumble-engineering#page=20)).
- **An empty glass looks like a full one.** "The glass looks much the same when empty as it does when
  full" ([Navy *Boilerman*, p. 323](lib:boilerman-3-and-2#page=323)). Blow the glass through to be sure
  ([p. 324](lib:boilerman-3-and-2#page=324); [🖼️ water gage column](lib:boilerman-3-and-2#page=72)).
- **Blow down** (open the blow-off cock to flush out mud) once or twice a day, more with dirty water,
  and close it again "when the water in the boiler has sunk to one and a half inches"
  ([*Maxims*, p. 48](lib:maxims-and-instructions-for-the-boiler-room#page=48)): watch the glass the
  whole time *(rule of thumb)*.
- **Check the water before lighting up** each morning: "very many boilers have been ruined by
  neglecting this first simple precaution"
  ([p. 29](lib:maxims-and-instructions-for-the-boiler-room#page=29)).

### The fusible plug

A brass plug filled with soft metal sits in the crown sheet over the fire. If the water drops below
it, the metal melts and steam blows into the fire to put it out
([Maggard, p. 81](lib:rough-and-tumble-engineering#page=81);
[🖼️ fusible plugs](lib:maxims-and-instructions-for-the-boiler-room#page=175);
[Fusible plug](wiki:Fusible_plug)). Some states required one by law
([*Maxims*, p. 175](lib:maxims-and-instructions-for-the-boiler-room#page=175)); Maggard thought it made
operators careless (p. 81). **Keep the plug, but never count on it:** it is a last warning, not a
water gauge *(rule of thumb)*.

### If the water is low

The Navy's rule, for when the water goes below the bottom of the glass **or you don't know whether
it is high or low** ([*Boilerman*, p. 324](lib:boilerman-3-and-2#page=324)):
1. **Stop the fire.** On a wood fire, smother it with dirt or ashes
   ([Maggard, p. 162](lib:rough-and-tumble-engineering#page=162)); **never throw water into the
   firebox**, which can crack the sheets (same page).
2. **Shut the feed.** "You must never feed water to a boiler in an attempt to restore the water level
   after a low-water casualty!" ([*Boilerman*, p. 324](lib:boilerman-3-and-2#page=324)). Hawkins
   agrees: "Don't pump cold water into a hot boiler"
   ([*Maxims*, p. 48](lib:maxims-and-instructions-for-the-boiler-room#page=48)).
3. **Shut off the steam to the engine** and get people away from the boiler *(rule of thumb)*.
4. **Let it cool slowly**, then look inside for bulged or scorched plates before you use it again
   *(rule of thumb)*.

### Testing with water, never with steam or air

- "Testing new boilers under steam pressure is both dangerous and unwise"; a water test does the same
  job safely ([*Maxims*, p. 285](lib:maxims-and-instructions-for-the-boiler-room#page=285)). Water
  barely compresses, so a leak just drips; air or steam stores energy and a failure flies apart
  *(rule of thumb)*.
- **Test pressure:** 150 pounds of water pressure for every 100 pounds of working pressure (1½ times)
  ([p. 121](lib:maxims-and-instructions-for-the-boiler-room#page=121)).
- **How:** fill the boiler "with water to safety-valve"
  ([*Maxims*, p. 134](lib:maxims-and-instructions-for-the-boiler-room#page=134)), pump it up with a
  hand force pump, and look for leaks, weeping seams and bulges
  ([Maggard, p. 87](lib:rough-and-tumble-engineering#page=87);
  [Collins, p. 123](lib:boys-book-of-engine-building#page=123)).
- Even water tests hurt people: a blown rivet in one test scalded five men
  ([*Maxims*, p. 285](lib:maxims-and-instructions-for-the-boiler-room#page=285)). Stand to the side.

### Low-pressure and no-pressure choices

- **Don't need shaft power? Don't make steam.** Hot water and space heat need no pressure at all; an
  **open, vented** tank can't build pressure *(rule of thumb)*.
- **A hot-air engine** uses the fire's heat directly with no boiler, and is "by all odds the safest to
  use" ([Collins, p. 215](lib:boys-book-of-engine-building#page=215)). See the next section.
- **A thermoelectric module** has no moving parts and no pressure (above).
- **Model engines:** a copper boiler 4 inches across and 12 inches long will run an engine with a
  1-inch cylinder "all day long at 1,000 revolutions per minute" at 50 pounds
  ([Watson, pp. 115–117](lib:small-engines-and-boilers-watson#page=117)); even a model needs a safety
  valve, a water gauge and a water test *(rule of thumb)*.

📚 **Go deeper:** [Hawkins *Maxims and Instructions for the Boiler Room*](lib:maxims-and-instructions-for-the-boiler-room#page=29) — firing, the morning checks, explosions (pp. 284–285); [Maggard *Rough and Tumble Engineering*](lib:rough-and-tumble-engineering#page=19) — running a farm engine and boiler, with questions and answers (pp. 140–162); [Navy *Boilerman 3 & 2*](lib:boilerman-3-and-2#page=323) — water-level emergencies, gauge glasses and safety valves.

## 🌀 Stirling and hot-air engines

### How they work

A hot-air engine (today called a **Stirling engine**) keeps the same air shut inside. One end is
heated by a fire and the other is kept cool. A loose piston called the **displacer** (or transfer
piston) shuffles the air between the hot end, where it expands and pushes the power piston, and the
cold end, where it shrinks again; a heavy flywheel carries it round
([Collins, pp. 215–216](lib:boys-book-of-engine-building#page=215);
[🖼️ how it works](lib:boys-book-of-engine-building#page=227);
[Stirling engine](wiki:Stirling_engine)). Better engines add a **regenerator**, a mesh or plates
between the hot and cold ends that soaks up heat from the air going one way and gives it back on the
way back ([Hawkins *New Catechism*, p. 324](lib:new-catechism-of-the-steam-engine#page=324)).

**Why bother:** they can "use any source of heat", run quietly and last a long time
([NASA *Stirling Manual*, p. 7](lib:stirling-engine-design-manual#page=7)); there is **no boiler** to
burst. **Why they lost out:** the old air engines had "high reliability and safety, but low specific
power" (same page): big and heavy for the work they do.

### What they really deliver

- **Antique hot-air engines:** about **50 watts** for an old machine; a modern air engine of the
  same kind made 850 W ([NASA, p. 8](lib:stirling-engine-design-manual#page=8)).
- **The best small factory engines:** a Philips air engine in a generator set built for **200 watts**
  ([p. 55](lib:stirling-engine-design-manual#page=55)) made at most about 0.48 kW, at 7.75 to 10%
  efficiency ([p. 57](lib:stirling-engine-design-manual#page=57)). Factory Stirling
  generators of the early 1980s made **25 to 70 watts**, and one cost $5,000
  ([p. 405](lib:stirling-engine-design-manual#page=405)).
- **Homemade engines** from cans and pipe fittings are teaching models: they spin themselves and
  little more *(rule of thumb)*. Getting the fire's heat into the hot end and out of the cold end is the
  hard part, and the books' factory numbers came from engineers with test rigs.

### Best uses: pumping water and slow work

- "The old hot air engines were used almost entirely for pumping water"
  ([NASA, p. 406](lib:stirling-engine-design-manual#page=406)). A modern fluid-piston engine pumped
  water **10 feet** high at **7%** efficiency on propane (same page).
- **The pumped water cools the engine.** In the Ericsson hot-air pumping engine "all the water passes"
  through a jacket around the cool end on its way from the well to the tank, while the bottom sits in
  the fire ([*New Catechism*, p. 319](lib:new-catechism-of-the-steam-engine#page=319);
  [🖼️ the pumping engine](lib:new-catechism-of-the-steam-engine#page=319);
  [🖼️ in section](lib:new-catechism-of-the-steam-engine#page=320)). Heat the bottom "a very few
  minutes", then start it with a turn or two of the flywheel by hand
  ([p. 321](lib:new-catechism-of-the-steam-engine#page=321)).
- **Other slow jobs:** turning a grindstone, a churn or a fan, where a few dozen watts all day is
  enough *(rule of thumb)*. For electricity, a thermoelectric module is simpler for the same few watts.

### A simple build from pipe fittings

Collins's model hot-air engine is made from plumbing parts
([*Boys' Book of Engine-Building*, pp. 215–226](lib:boys-book-of-engine-building#page=215);
[🖼️ cross-section](lib:boys-book-of-engine-building#page=217);
[🖼️ the finished engine](lib:boys-book-of-engine-building#page=225)):
1. **Hot cylinder:** a 4-inch length of iron pipe a little over 2 inches across, a threaded cap on each
   end, the top cap drilled for the displacer rod
   ([p. 216](lib:boys-book-of-engine-building#page=216)). (The old scan blurs the fractions; check the
   drawing.)
2. **Displacer:** a smaller capped pipe with a hardwood plug, deliberately loose so air can pass around
   it, on a rod through the top cap ([pp. 217–218](lib:boys-book-of-engine-building#page=217)).
3. **Power cylinder:** "half as large as the expansion cylinder", with a piston of the same metal that
   fits "pretty accurately, as it is not packed"
   ([pp. 219–220](lib:boys-book-of-engine-building#page=219)).
4. **Connecting pipe** from the top of the hot cylinder to the power cylinder, and a crankshaft with
   two cranks, one for each piston ([pp. 221–223](lib:boys-book-of-engine-building#page=221)).
5. **A heavy 5- or 6-inch flywheel** and a firebox with air holes at top and bottom
   ([pp. 224–226](lib:boys-book-of-engine-building#page=224)).
6. **To run it:** a flame centered under the bottom of the hot cylinder, then "Give the flywheel a
   couple of turns" ([p. 226](lib:boys-book-of-engine-building#page=226)).

The same layout scaled up, with a water-cooled top and a regenerator, is the old pumping engine
*(rule of thumb)*.

📚 **Go deeper:** [Hawkins *New Catechism*, pp. 319–324](lib:new-catechism-of-the-steam-engine#page=319) — the Ericsson and Rider pumping engines, with sectional drawings; [NASA *Stirling Engine Design Manual*](lib:stirling-engine-design-manual#page=7) — the engineering, for anyone designing a serious engine.

## ❄️ Heat into cold: absorption refrigerators and ice makers

### How a flame makes cold

Gas and kerosene refrigerators use the **absorption** system: a small flame drives ammonia out of
water under pressure until it condenses to a liquid, and the liquid boils off again in the cold box,
soaking up heat. There are **no moving parts**; "The Servel is used in RV's now. Modern kerosene and
propane refrigerators use this system"
([Aprovecho, p. 37](lib:aprovecho-capturing-heat-three#page=37);
[Absorption refrigerator](wiki:Absorption_refrigerator)). The sealed system is under real pressure:
the tested unit held 1.52 lb of ammonia and was pressure-tested to **717 psi**
([NBS report, p. 9](lib:propane-fired-absorption-refrigerator#page=9)). **Never drill, cut, bend or
heat its tubing** *(rule of thumb)*.

### Keeping an absorption refrigerator running

From the National Bureau of Standards tests, for the Army, of a propane-fired household-type absorption
refrigerator:
- **Level it carefully.** It failed when tipped just **1 degree** forward or to the left, and **2
  degrees** backward or to the right
  ([NBS report, p. 33](lib:propane-fired-absorption-refrigerator#page=33)). One degree is under ½ inch
  across a 2-foot-wide fridge *(arithmetic)*; use a spirit level on the freezer floor, and re-level
  after moving it *(rule of thumb)*.
- **Keep it out of the heat.** It worked at about **103 °F**, slipped at 110 °F, and failed at 118 °F
  ([p. 23](lib:propane-fired-absorption-refrigerator#page=23)). Once it failed it did **not** recover
  until the room was cooled well below that
  ([p. 24](lib:propane-fired-absorption-refrigerator#page=24)). Its limit was about **105 °F**
  ([p. 33](lib:propane-fired-absorption-refrigerator#page=33)). In summer give it the coolest, shadiest
  spot and free air around the back *(rule of thumb)*; the testers set it about 6 inches from the wall
  ([p. 15](lib:propane-fired-absorption-refrigerator#page=15);
  [🖼️ the back, with condenser and heater box](lib:propane-fired-absorption-refrigerator#page=12)).
- **Right gas pressure:** it ran best at **11 inches of water column**, the maker's figure
  ([p. 23](lib:propane-fired-absorption-refrigerator#page=23),
  [p. 33](lib:propane-fired-absorption-refrigerator#page=33)). That needs a proper low-pressure
  propane regulator, never a hose straight from the tank *(rule of thumb)*.
- **Reset the thermostat with the seasons:** no single setting was right for both a 70 °F and a 90 °F
  room ([p. 33](lib:propane-fired-absorption-refrigerator#page=33)).
- **Choosing one:** a freezer compartment "will use much more fuel"; top-opening boxes are more
  efficient; units that run on both gas and electricity are "of especial value"
  ([WHO field manual, pp. 271–272](lib:communicable-disease-control-in-emergencies#page=271)).

### Fuel: how long a tank lasts

The tested fridge was rated for **1,300–1,600 BTU an hour**
([NBS report, p. 9](lib:propane-fired-absorption-refrigerator#page=9)). With the burner on all day that
is 31,000–38,000 BTU, or about **⅓ to ⅖ of a gallon of propane a day** at 91,000 BTU a gallon
([Univ. of Minnesota EB 436, p. 16](lib:univ-of-minnesota-heating-the-home-with-wood#page=16))
*(arithmetic)*. The thermostat turns the flame down much of the time, so real use is less. A kerosene
model burning the same heat would use about **¼ gallon a day** (kerosene: 135,000 BTU a gallon, same
page) *(arithmetic)*.

### Burner care and carbon monoxide

*(Rule of thumb unless cited)*
- **Clean flame:** a steady blue gas flame, or a kerosene flame with no smoke. Soot in the flue or a
  yellow, smoky flame means a dirty burner, a wrong wick height or a blocked flue: fix it before you
  use the fridge again.
- **Clean the flue** (the tube above the burner, with a baffle hanging inside) with a long brush, and
  keep spiders and wasps out of the burner's air holes.
- **Kerosene models:** only clean **1-K kerosene**, never gasoline
  ([CPSC *Kerosene Heater Safety*, p. 1](lib:kerosene-heater-safety-cpsc#page=1)). Trim and clean the
  wick like a lamp wick (see "Kerosene lamps while the kerosene lasts" in the
  [Lighting guide](guide:LIGHTING-GUIDE)), and don't let the tank run dry.
- **Carbon monoxide:** "Any heating system that burns fuel, and does not have a chimney, will give off
  some gases into the room" ([MSU *Portable Kerosene Heaters*, p. 3](lib:some-considerations-about-portable-kerosene-heaters#page=3)).
  Vent the fridge's flue **outdoors** as RV fridges are, and keep a CO alarm in the room.

### Solar and fire-driven ice makers

- **How they work:** a heated vessel drives ammonia over to a condenser by day; at night one valve is
  turned and the liquid boils off in coils in an insulated box, making ice. The DOE-funded ISAAC ice
  maker had a solar collector, two pressure vessels, a condenser and piping, with "no moving parts or
  electrical components" ([ISAAC report, pp. 3–4](lib:isaac-solar-ice-maker#page=3)). On cloudy days a
  "burner coil, fueled by kerosene, propane or biomass" heats it instead
  ([p. 5](lib:isaac-solar-ice-maker#page=5)).
- **Hard to build well:** the first two prototypes fell short, and the third worked well but
  "reliability was marginal and it was too expensive" (same page).
- **The Icy Ball** was a 1930s fire-charged version; more than 100,000 were sold
  ([Aprovecho, p. 37](lib:aprovecho-capturing-heat-three#page=37); [Icyball](wiki:Icyball)). Aprovecho
  rebuilt one from small propane cylinders, then stopped because of "the potential for explosion" when
  its soldered safety plug proved unreliable (same page). **Don't build one:** use an absorption
  fridge you can buy or salvage, or store winter ice (see "Cold: storing winter for summer" in the
  [Storing Energy guide](guide:STORING-ENERGY-GUIDE)).

### What a 12-volt "thermoelectric cooler" can do

The plug-in camping coolers use Peltier modules run backwards. They cool only **about 20 °C (36 °F)
below the room** and are much less efficient than a compressor fridge
([Thermoelectric heat pump](wiki:Thermoelectric_heat_pump)). Fine for a drive, poor for living off a
battery *(rule of thumb)*. Their modules are worth saving for stove-top power (above).

## 🔧 Other ways to put heat to work

- **Engine waste heat:** only about **25%** of an engine's fuel turns into work; "What happens to the
  remaining 75 percent of the heat? It is largely absorbed by the engine parts or passes out with the
  exhaust gases." An ordinary six-cylinder engine "generates sufficient heat to warm a six-room house in
  freezing weather" ([Navy *Construction Mechanic*, p. 133](lib:navy-construction-mechanic-3-and-2-1978#page=133)).
  When a liquid-cooled engine runs (a tractor, a truck, a wood-gas generator), its hot coolant can warm
  a tank of wash water through a coil; never bring the **exhaust** indoors *(rule of thumb)*.
- **Exhaust steam for heating and hot water** (above, "Condensing and reusing the water").
- **Stove fans** that run on a thermoelectric module (above).
- **Hot water by thermosiphon** with no pump, and heat stored in water and stone: see the
  [Storing Energy guide](guide:STORING-ENERGY-GUIDE).
- **Charcoal and wood gas** for engines: see the [Fuel guide](guide:FUEL-GUIDE).

## 🧯 Safety: burns, steam, carbon monoxide and fire

- **Scalds:** water at 140 °F (60 °C) takes about **5 seconds** to cause a severe burn, at 158 °F
  (70 °C) about **1 second** ([Ciochetti & Metcalf, p. 5](lib:pasteurization-of-naturally-contaminated-water#page=5)).
  Steam and boiler water are far hotter.
- **Steam leaks:** a hissing joint on a boiler means shut down and let it cool; never tighten a
  fitting under pressure *(rule of thumb)*. A blown rivet during one water test "struck a man in the
  face, and … parboiled him from head to foot"
  ([*Maxims*, p. 285](lib:maxims-and-instructions-for-the-boiler-room#page=285)).
- **Carbon monoxide** from every burner, firebox and engine: "you cannot see or smell CO", and a
  generator in a closed space can make dangerous levels "within minutes"
  ([CPSC *Portable Generator Hazards*, p. 1](lib:cpsc-portable-generator-hazards#page=1)). It takes 10
  to 24 hours to clear it from the blood
  ([MSU *Portable Kerosene Heaters*, p. 3](lib:some-considerations-about-portable-kerosene-heaters#page=3);
  [Carbon monoxide poisoning](wiki:Carbon_monoxide_poisoning)).
- **Boiler explosions:** stay out of line with the ends and the firebox door of a boiler under
  pressure, and keep children and visitors away entirely *(rule of thumb)*.
- **Fire:** an unshielded single-wall stovepipe needs **18 inches** of clearance to anything that
  burns ([CMHC, p. 15](lib:cmhc-a-guide-to-residential-wood-heating#page=15)). Boilers, engines and
  fridge burners are hot too: kerosene heater surfaces run 320 °F to more than 500 °F
  ([MSU, p. 3](lib:some-considerations-about-portable-kerosene-heaters#page=3)).
- **Gasoline burners** under a boiler: Watson calls gasoline "treacherous stuff"
  ([Watson, p. 115](lib:small-engines-and-boilers-watson#page=115)); use wood, charcoal or a proper
  kerosene or alcohol burner *(rule of thumb)*.
- **Ammonia** from a cracked refrigerator: it smells strongly and burns the eyes and lungs; get out,
  air the room, and take the unit outside *(rule of thumb)*.

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| On low water out on the road, run the engine's front end onto high ground "so that the water would raise over the crown sheet and thus make it safe to pump up the water" ([Maggard, p. 162](lib:rough-and-tumble-engineering#page=162)). | Never feed water after a low-water scare: kill the fire, shut the feed, let it cool, then inspect ([Navy *Boilerman*, p. 324](lib:boilerman-3-and-2#page=324)). |
| A cork in the filling hole of a toy boiler "will act as a safety valve, for it will blow out before the boiler blows up" ([Collins, p. 74](lib:boys-book-of-engine-building#page=74)). | A cork can swell, stick or be pushed in too hard. Any boiler, even a toy, gets a real weighted or spring safety valve *(rule of thumb)*. |
| Pump the boiler up with a bicycle pump and run the engine on compressed air "without steam and, naturally, without fire" ([Collins, p. 125](lib:boys-book-of-engine-building#page=125)). | Never put air pressure in a boiler: compressed air stores energy and bursts violently. Test with water only *(rule of thumb)*. |
| "If you find a thin plate, what would you do? Put a patch on" ([*Maxims*, pp. 131–132](lib:maxims-and-instructions-for-the-boiler-room#page=131)). | That was a licensed boilermaker's job. A thinned, cracked or patched boiler is retired from pressure use *(rule of thumb)*. |
| Calk stack leaks "with a mixture of asbestos wicking and red lead" ([*Boilerman*, p. 359](lib:boilerman-3-and-2#page=359)). | No asbestos and no red lead: use high-temperature stove cement or furnace sealant *(rule of thumb)*. |
| Refill a melted fusible plug with babbitt by pouring it in ([Maggard, p. 83](lib:rough-and-tumble-engineering#page=83)). | Fit a proper replacement plug of the right melting point, and find out why the water got low *(rule of thumb)*. |
| A homemade Icy Ball from propane cylinders ([Aprovecho, p. 37](lib:aprovecho-capturing-heat-three#page=37)). | Aprovecho itself stopped over "the potential for explosion" (same page). Use a factory absorption fridge. |

## 🖼️ Pictures & diagrams

- Stirling and hot-air engines: how a hot-air engine works, [🖼️ Collins, p. 227](lib:boys-book-of-engine-building#page=227); a pipe-fitting model in section, [🖼️ p. 217](lib:boys-book-of-engine-building#page=217), and finished, [🖼️ p. 225](lib:boys-book-of-engine-building#page=225); [Stirling engine](wiki:Stirling_engine); [Hot air engine](wiki:Hot_air_engine)
- Hot-air pumping engines: Ericsson, [🖼️ Hawkins *New Catechism*, p. 319](lib:new-catechism-of-the-steam-engine#page=319) and in section, [🖼️ p. 320](lib:new-catechism-of-the-steam-engine#page=320); Rider, [🖼️ p. 322](lib:new-catechism-of-the-steam-engine#page=322) and [🖼️ p. 323](lib:new-catechism-of-the-steam-engine#page=323)
- The four steps of every heat engine — [🖼️ NASA *Stirling Manual*, p. 8](lib:stirling-engine-design-manual#page=8); a Philips air-engine generator set, [🖼️ p. 56](lib:stirling-engine-design-manual#page=56)
- A five-horsepower vertical steam engine — [🖼️ Watson, p. 12](lib:small-engines-and-boilers-watson#page=12); a small boiler, [🖼️ p. 116](lib:small-engines-and-boilers-watson#page=116)
- Boiler fittings: safety valve, [🖼️ Hawkins *Maxims*, p. 191](lib:maxims-and-instructions-for-the-boiler-room#page=191); fusible plugs, [🖼️ p. 175](lib:maxims-and-instructions-for-the-boiler-room#page=175) and [🖼️ p. 176](lib:maxims-and-instructions-for-the-boiler-room#page=176); a boiler with a low-water safety valve, [🖼️ p. 63](lib:maxims-and-instructions-for-the-boiler-room#page=63); water gage column, [🖼️ Navy *Boilerman*, p. 72](lib:boilerman-3-and-2#page=72); [Boiler explosion](wiki:Boiler_explosion); [Fusible plug](wiki:Fusible_plug)
- Propane absorption refrigerator: the back, with condenser and heater box, [🖼️ NBS report, p. 12](lib:propane-fired-absorption-refrigerator#page=12); burner and thermostat, [🖼️ p. 14](lib:propane-fired-absorption-refrigerator#page=14); [Absorption refrigerator](wiki:Absorption_refrigerator); [Icyball](wiki:Icyball)
- Thermocouples and thermopiles — [🖼️ Kuphaldt vol. 1, p. 320](lib:lessons-in-electric-circuits-vol-1-dc-kuphaldt#page=320); a wire thermocouple to build, [🖼️ Kuphaldt vol. 6, p. 117](lib:lessons-in-electric-circuits-vol-6-experiments-kuphaldt#page=117); [Thermoelectric generator](wiki:Thermoelectric_generator)

## 🔗 Related guides

- [Fuel](guide:FUEL-GUIDE) — wood gas, kerosene and propane
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) — motors as generators, and running a generator on wood gas
- [Storing Energy Without Batteries](guide:STORING-ENERGY-GUIDE) — heat stored in water and stone, ice, and safe hot-water tanks
- [Off-Grid Power](guide:OFF-GRID-POWER-GUIDE) — batteries, charge controllers, solar and creek hydro
- [Firewood](guide:FIREWOOD-GUIDE) — the fuel for all of it, and safe stoves and chimneys
- [Water Wells, Pumps, Springs & Cisterns](guide:WATER-WELLS-GUIDE) — pumps and tanks for a hot-air pumping engine
- [Root Cellars & Food Storage](guide:ROOT-CELLAR-GUIDE) — keeping food cool with no machine at all
- [Lighting](guide:LIGHTING-GUIDE) — kerosene wicks and safe flames
- [Blacksmithing](guide:BLACKSMITHING-GUIDE) — metalwork for engine parts (never for boiler repairs)
- [Practical Math](guide:PRACTICAL-MATH-GUIDE) and [Calculator](guide:CALCULATOR) — check the arithmetic
