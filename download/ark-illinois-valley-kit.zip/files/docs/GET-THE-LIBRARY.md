# 💾 Get the Whole Library on a USB Drive

The **full library** has every book, all of Wikipedia, maps that work with no signal, and an AI
that needs no internet. It's too big for a website, so you put it on a **USB drive, external hard
drive or SD card** while the internet still works. After that, it works with the power and phones
out.

No commands to type: you download a small kit, double-click one file, pick your drive, and press
**Start**.

> ### ⚠️ What you need
> - **A computer:** Windows, Mac or Linux. (Phones and tablets can *use* the drive afterwards, but
>   can't make it.)
> - **A drive:** any size works; the installer fills what fits. See [How big a drive?](#how-big-a-drive)
> - **Internet and time:** a few hours, or overnight for everything. Keep the computer plugged in
>   and awake. If it stops, run it again and press **Continue**. It picks up where it left off.
> - The installer only **adds** files. It never erases your drive.

---

## 📥 Step 1: Download the kit

**[⬇️ Download the installer kit (ark-illinois-valley-kit.zip)](https://cchristianson.github.io/so-survival-web/download/ark-illinois-valley-kit.zip)**

One zip file, about 40 MB. The same kit works on Windows, Mac and Linux.

---

## 🧰 Step 2: Unzip it and start the installer

When you open the unzipped folder you'll see **READ-ME-FIRST**, three **INSTALL** files, and a
**files** folder (you don't need to open that one).

### Windows

1. Open your **Downloads** folder.
2. **Right-click `ark-illinois-valley-kit`** → **Extract All…** → **Extract**. A new folder opens.
3. **Double-click `INSTALL-Windows`.**
4. If a blue box says *Windows protected your PC*, click **More info**, then **Run anyway**. If it
   asks *Do you want to run this file?*, click **Run**.
5. A black window opens. **Leave it open** (you can minimize it). The installer page opens in your
   web browser.

### Mac

1. Open your **Downloads** folder. Safari usually unzips the kit for you. If you see
   `ark-illinois-valley-kit.zip` instead, double-click it.
2. Open the **ark-illinois-valley-kit** folder and **double-click `INSTALL-Mac`.**
3. The first time, your Mac will say it can't open or verify it. Click **Done**, then:
   1. Open the **Apple menu → System Settings → Privacy & Security**.
   2. Scroll down to the note about `INSTALL-Mac` and click **Open Anyway**. Type your Mac password
      if it asks.

   On older Macs: **right-click `INSTALL-Mac` → Open → Open** instead.
4. A Terminal window opens. **Leave it open.** The installer page opens in your web browser.

### Linux and Raspberry Pi

1. Unzip the kit (right-click → **Extract Here**).
2. Open a terminal in the unzipped folder, type this and press Enter:
   ```
   bash INSTALL-Linux.sh
   ```
3. The installer page opens in your web browser.

---

## ✅ Step 3: Pick the drive and press Start

1. **Plug in your drive.** Each drive is listed with its free space. Click yours. (Not listed?
   Click **I plugged in a drive - look again**.)
2. **Check what goes on it.** It has already ticked a set that **fits your drive**. You can change
   any tick; the bar at the bottom shows if it still fits. Not sure? Keep what it picked.
3. **Press Start the download.** A bar shows how much is done and about how long is left.
4. When it says **The library is on your drive**, click **Open the library** to try it.
5. **Eject the drive** before you unplug it. Windows: the USB icon by the clock. Mac: click ⏏ next
   to the drive in Finder.

---

## 📏 How big a drive?

| Drive size | What fits |
|---|---|
| **16 GB** | All the guides and local books, the Library Assistant with a small AI, medical encyclopedias, maps of Oregon |
| **32 GB** | Adds a short Wikipedia (the opening of every article) and maps of Oregon and California |
| **64 GB** | Adds the repair encyclopedias, the bigger AI and maps of the whole USA |
| **128 GB** | Adds all of Wikipedia's text (no pictures) |
| **256 GB or more** | Everything, including Wikipedia with pictures |

USB 3 flash drives and small external SSDs both work. An SSD is faster and tougher.

**About the map viewer for computers:** if you tick it, the installer leaves part of the drive
**empty on purpose** (about 30 GB for maps of the whole USA). The viewer fills that space the first
time you open it. Phones don't need it.

---

## 🔌 Make the drive work on every device

For a drive you'll plug into different computers and tablets:

1. **Keep "Works on every kind of device" ticked.** The installer ticks it for you on USB and
   external drives.
2. **Use a drive formatted exFAT.** The installer shows each drive's format and warns you if it
   isn't exFAT. Most new drives over 32 GB already are.

| Format | Opens on |
|---|---|
| **exFAT** ✅ | Windows, Mac, Linux, Raspberry Pi, most Android tablets |
| **FAT32** ⚠️ | Everything, but no file over 4 GB, so no Wikipedia and no large AI |
| **NTFS** ⚠️ | Windows and Linux. Macs can only read it; most Android tablets can't open it |
| **Mac formats** (APFS, Mac OS Extended) ❌ | Macs only |

**To switch a drive to exFAT.** This **erases everything on the drive**, so copy off anything you
want to keep first.

- **Windows:** File Explorer → **This PC** → right-click the drive → **Format…** → File system:
  **exFAT** → **Start**.
- **Mac:** open **Disk Utility** → **View → Show All Devices** → click the drive (the top line for
  it) → **Erase** → Format: **ExFAT**, Scheme: **Master Boot Record** → **Erase**.

---

## 🔁 Using, copying and updating it

- **Use it:** plug in the drive and open **`START-HERE.html`**. For the search box and offline AI,
  double-click **`START-Windows`** or **`START-Mac`**. Every kind of device is covered in
  [Start on any device](guide:START-ON-ANY-DEVICE).
- **Copy it for a neighbor:** copy the whole **`OfflineLibrary`** folder to their drive. No
  internet needed.
- **Update it:** run the installer again and pick the same drive. It only downloads what's new or
  missing. When there's a newer edition of Wikipedia or another big reference file, it swaps it in
  only if the drive has room for both while it downloads, then deletes the old one. If there isn't
  room, it keeps the one you have.

---

## ❓ If something goes wrong

| What happens | What to do |
|---|---|
| The browser warns about the download | Choose **Keep** (in Edge or Chrome: click **⋯** → **Keep**) |
| Nothing happens, or "files are missing" | You opened it inside the zip. Unzip first (Step 2), then use the unzipped folder |
| Mac won't open `INSTALL-Mac` | **System Settings → Privacy & Security → Open Anyway** (Step 2) |
| The browser page doesn't open | The black (or Terminal) window shows a web address. Type it into your browser. If that fails, the installer asks its questions in that window instead |
| My drive isn't listed | Wait a few seconds and click **look again**. Or open **Use a different folder instead** and type the drive, like `E:\` |
| It stopped partway | Run the installer again, pick the same drive, press **Continue** |
| It says some items are **missing** | A few websites didn't answer. Everything else works. Press **Try the missing ones again**, or run the installer again later. Click **Show what's missing** to see the list |
| It says **too big** | Untick something (Wikipedia with pictures and US maps are the biggest), or click **Fill it automatically again** |
| Lots of space still **free when it's done** | That's the map viewer's space (see [How big a drive?](#how-big-a-drive)) |
| A drive won't open on a Mac or tablet | Check its format: exFAT opens everywhere (see above) |

Still stuck? Take a photo of the text window and show it to whoever is helping you.
