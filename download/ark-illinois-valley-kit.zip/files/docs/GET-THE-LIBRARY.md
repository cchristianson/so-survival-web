# 💾 Get the Whole Library on a USB Drive

The full library (every book, Wikipedia, offline maps and an offline AI) is too big for a website.
You copy it onto a **USB drive** while you still have internet. After that it works with no
internet at all.

> ### ⚠️ What you need
> - **A Windows, Mac or Linux computer.** (Phones can use the drive later, but can't make it.)
> - **A USB drive.** Any size works; see [How big a drive?](#how-big-a-drive)
> - **Internet and a few hours.** Overnight for everything. Keep the computer plugged in.
>
> You can stop any time and carry on later. Nothing is lost, and nothing on your drive is erased.

---

## 📥 Step 1: Download the kit

**[⬇️ Download the installer kit (ark-illinois-valley-kit.zip)](https://theofflineark.com/download/ark-illinois-valley-kit.zip)**

One zip file, about 40 MB. It works on Windows, Mac and Linux.

🧰 Building the **ARK Vault**? Use this same kit. See the [ARK Vault guide](guide:AMMO-CAN-COMPUTER-GUIDE).

---

## 🧰 Step 2: Unzip it and start the installer

### Windows

1. In your **Downloads** folder, **right-click `ark-illinois-valley-kit`** → **Extract All** → **Extract**.
2. In the folder that opens, **double-click `INSTALL-Windows`**.
3. If a blue box says *Windows protected your PC*, click **More info**, then **Run anyway**.
4. A black window opens (leave it open), then a page in your web browser.

### Mac

1. In your **Downloads** folder, open the **ark-illinois-valley-kit** folder (double-click the zip first if
   needed).
2. **Double-click `INSTALL-Mac`.**
3. If the Mac says it can't open it: click **Done**, go to **Apple menu → System Settings →
   Privacy & Security**, scroll down and click **Open Anyway**.
4. A Terminal window opens (leave it open), then a page in your web browser.

### Linux

Unzip the kit, open a terminal in that folder, type `bash INSTALL-Linux.sh` and press Enter.

---

## ✅ Step 3: Pick your drive and press Start

1. **Plug in your drive** and click it in the list.
2. It has already picked what **fits**. Leave it, or change the ticks.
3. Press **Start the download** and leave the computer on.
4. When it says **The library is on your drive**, you're done. **Eject the drive** before
   unplugging it.

---

## 📏 How big a drive?

| Drive size | What fits |
|---|---|
| **16 GB** | All the guides and local books, a small AI, the medical encyclopedia, maps of Oregon |
| **32 GB** | Adds a short Wikipedia (the opening of every article) and maps of Oregon and California |
| **64 GB** | Adds the repair encyclopedias, a bigger AI and maps of the whole USA |
| **128 GB** | Adds all of Wikipedia (words only) |
| **256 GB or more** | Everything, including Wikipedia with pictures |

A small external SSD is faster and tougher than a flash drive, but both work.

If you tick the **map viewer for computers**, the installer leaves some space empty on purpose
(about 30 GB for the whole USA). The viewer uses it the first time you open it.

---

## 🔌 Make the drive work everywhere

Use a drive formatted **exFAT**. It opens on Windows, Mac, Linux and most tablets. Most new drives
already are; the installer warns you if yours isn't.

**To change a drive to exFAT** (this **erases** it, so copy off anything you want first):

- **Windows:** **This PC** → right-click the drive → **Format** → File system **exFAT** → **Start**.
- **Mac:** **Disk Utility** → **View → Show All Devices** → click the drive → **Erase** → Format
  **ExFAT**, Scheme **Master Boot Record** → **Erase**.

---

## 🔁 Using, copying and updating it

- **Use it:** open **`START-HERE.html`** on the drive, or double-click **`START-Windows`** /
  **`START-Mac`** for search and the AI. See [Start on any device](guide:START-ON-ANY-DEVICE).
- **Copy it for someone:** copy the whole **`OfflineLibrary`** folder to their drive.
- **Update it:** run the installer again and pick the same drive. It only adds what's new.

---

## ❓ If something goes wrong

| Problem | Fix |
|---|---|
| The browser warns about the download | Choose **Keep** |
| Nothing happens, or "files are missing" | You opened it inside the zip. Unzip it first (Step 2) |
| The browser page doesn't open | Type the web address shown in the black (or Terminal) window into your browser |
| My drive isn't listed | Wait a few seconds and click **look again** |
| It stopped partway | Run it again, pick the same drive, press **Continue** |
| Some items are **missing** | A few websites didn't answer. Press **Try the missing ones again**, or run it again later |
| It says **too big** | Untick something (Wikipedia with pictures and US maps are the biggest) |
| Lots of space still free when it's done | That's the map viewer's space (see above) |
| A Mac or tablet won't open the drive | The drive needs to be exFAT (see above) |

Still stuck? Take a photo of the black window and show it to someone helping you.
