# 🐖 Pigs: Meat, Lard and Leftovers

How to keep pigs with no feed store, no vet and no fridge: choosing lard, bacon and pasture breeds, fences that hold pigs when the charger is dead, rooting,
feeding on Pacific Northwest pasture and on grain the pigs harvest themselves, acorns and kitchen scraps, what never to feed, shade and water in our hot
summers, breeding, farrowing and piglets, health with no vet, butchering day in cold weather, rendering lard, keeping trichinosis and tapeworm out of the
family, and why a pig must never get loose. Curing and smoking are in the [Preserving Food guide](guide:PRESERVING-FOOD-GUIDE). The pig books are in
`Animals\Cattle-Horses-Pigs` (USDA *Pasture and Grain Crops for Hogs in the Pacific Northwest*, *Swine Production* and *Pork Slaughtering*, OSU
*Care of New Feeder Pigs*, *Slaughter and Preservation of Meat*), with *Pork on the Farm* in `Homestead-Skills\Food-Crafts-Tools`, lard in
`Food-From-Scratch\Wild-and-Local-Staples`, smokehouse and hoist plans in `Food-Storage\Curing-Smoking`, no-vet medicine and the diseases people catch from pigs
in `Animals\Veterinary`, and poisonous plants in `Wild-Plants`. The main CVM book, [*Raising Healthy Pigs*](lib:raising-healthy-pigs-cvm), has photos but no
text the search tool can read, so this guide does not quote it.

> ### The short version
> - **Pigs die of heat.** Shade and clean water all day: **½–1½ gallons per 100 lb of pig a day**, more for nursing sows.
>   Salty slop with too little water kills ([*No Animal Doctor*, p. 47](lib:where-there-is-no-animal-doctor#page=47);
>   [Peace Corps Vol 4, p. 210](lib:peace-corps-livestock-training#page=210); [p. 332](lib:where-there-is-no-animal-doctor#page=332)).
> - **Boil every scrap that has touched meat, and boil milk and whey,** before pigs get them: raw meat scraps give pigs
>   trichinosis, raw milk and garbage spread TB ([USDA FB 1437, p. 5](lib:swine-production-usda#page=5);
>   [*Zoonoses*, p. 27](lib:zoonoses-diseases-animals#page=27)).
> - **Cook pork until it is gray all through** (about **170 °F**). Never taste raw sausage; curing and smoking don't make
>   pork safe ([*Zoonoses*, p. 121](lib:zoonoses-diseases-animals#page=121); [USDA FB 1186, p. 41](lib:farmers-bulletin-1186#page=41)).
> - **Sows crush piglets.** Farrow in a pen about **7 × 7 ft** with a guard rail **10 in** off the floor and **4–6 in** from
>   the wall; over half of newborn deaths come in the **first 24 hours** ([FB 1437, pp. 24, 26](lib:swine-production-usda#page=24)).
> - **Piglets on a floor need iron:** put fresh sod or clean soil in the pen ([FB 1437, p. 32](lib:swine-production-usda#page=32)).
> - **Butcher in cold weather:** carcass down to **34–40 °F within 24 hours**; fresh pork eaten or preserved within
>   **3–5 days** ([FB 1186, p. 3](lib:farmers-bulletin-1186#page=3); [USDA FB 2138, p. 24](lib:pork-slaughtering-cutting#page=24)).
> - **Never let a pig loose**, and never let pigs reach a latrine (pork tapeworm) ([*Zoonoses*, p. 112](lib:zoonoses-diseases-animals#page=112)).
>   Escaped pigs go wild *(rule of thumb)*.
> - **One 200-lb hog ≈ the pork and lard two people eat in a year** ([FB 2138, p. 6](lib:pork-slaughtering-cutting#page=6));
>   a family of four needs two or more (see "How many pigs feed a family").

---

## 🐖 Choosing pigs: lard, bacon and pasture breeds

The hog is "the most valuable farm animal in utilizing farm wastes" ([FB 1437, p. 4](lib:swine-production-usda#page=4)): scraps, whey, gleanings, acorns and
culls become meat and fat. With no store oil, **lard is the household's cooking fat**, so choose for fat as well as meat.

| Type | Built like | Best fed on | Breeds named in the books |
|---|---|---|---|
| **Lard** | Short-legged, thick, compact; small litters | Corn and other fattening grain | [Poland China](wiki:Poland_China): black with six white points, 600–1,000 lb grown, fast-gaining, good survival ([Peace Corps, pp. 280–281](lib:peace-corps-livestock-training#page=280); [p. 284](lib:peace-corps-livestock-training#page=284)) |
| **Bacon** | Long, lean, muscled | **Peas, wheat, barley, oats, rye, dairy by-products and roots**: what our valley grows | [Landrace](wiki:Landrace_pig): long, prolific, efficient. [Yorkshire](wiki:American_Yorkshire): good mothers, large litters, forage well, but do poorly with little care ([pp. 281, 284](lib:peace-corps-livestock-training#page=281)) |
| **Meat** (in between) | Large, fast-growing, hungry | Grain plus protein | [Duroc](wiki:Duroc_pig): red, litters survive well, sows "fierce in the defense of their young." [Hampshire](wiki:Hampshire_pig): white belt, sows raise a high share of their pigs; smaller, slower ([p. 284](lib:peace-corps-livestock-training#page=284)) |

**Pasture pigs:** a breed "selected genetically for production" needs "high quality feed, a disease-free environment, good housing"
([Peace Corps, p. 280](lib:peace-corps-livestock-training#page=280)). On pasture and leftovers pick hardy crossbreds or old grazing breeds that mother well,
such as [Berkshire](wiki:Berkshire_pig), [Tamworth](wiki:Tamworth_pig), [Large Black](wiki:Large_Black) or the small [Kunekune](wiki:Kunekune), over modern
indoor lines *(rule of thumb)*. Crosses give bigger litters, more pigs living and faster growth ([p. 282](lib:peace-corps-livestock-training#page=282)). Sunburn
is a trait to select against ([p. 281](lib:peace-corps-livestock-training#page=281)): under our July sun, dark-skinned pigs fare better *(rule of thumb)*.

**Buying:** "start with only a few sows," of one breed and herd, ideally already bred. A good sow lets you into her pen any time, has legs long enough to keep
her udder off the ground and **at least six teats in each row**; keep no pigs from a cross or nervous sow
([FB 1437, pp. 5–7](lib:swine-production-usda#page=5)). Buy only from herds you know are healthy. **Feeder pigs** (weaned pigs raised for meat) need a clean,
dry, draft-free pen ready; ask what they ate and change feed slowly ([OSU EM 9271, pp. 1, 3](lib:care-of-new-feeder-pigs#page=1)).

## 🏠 Pens, fences and rooting

**Room per pig** under cover: sows, gilts and boars **15–20 sq ft**; sow and litter **50–65**; weaners to 75 lb **5–6**; 75–125 lb **6–7**; 125–200 lb **8–10**;
build near the house and the feed, proof against predators ([Peace Corps, p. 288](lib:peace-corps-livestock-training#page=288)). A 50-lb pig is comfortable at
**70–82 °F**, a 215-lb one at **50–75 °F**, and Oregon nights chill young pigs "through the month of May": bed deep with straw
([OSU EM 9271, pp. 1–2](lib:care-of-new-feeder-pigs#page=1)) and never let pigs sleep on damp bedding ([FB 1437, p. 34](lib:swine-production-usda#page=34)). A
roof on posts with **straw-bale walls** is a winter house; take the bales out and it is a summer shade ([🖼️ FB 1437, p. 38](lib:swine-production-usda#page=38)).
Feed in a V-shaped trough with slats across the top, **1–2 ft per pig** (pigs fed on the ground get more worms), and water in a heavy concrete bowl they can't
tip ([Peace Corps, pp. 290–291](lib:peace-corps-livestock-training#page=290)). Dig or plow pig lots twice a year and sow them to pasture
([FB 1437, p. 37](lib:swine-production-usda#page=37)): worm eggs live years in damp soil but die in weeks of sun
([*No Animal Doctor*, p. 347](lib:where-there-is-no-animal-doctor#page=347)).

### Fences that hold pigs
Fence "hog tight" with **woven wire**: about **26 in** high on a big field with **one barbed strand at the bottom, just above the ground**, and **32–36 in**
around a small pen, where pigs push harder. "Probably 90 percent" of a woven-wire fence's strength is in **well-braced corner posts**
([FB 1437, p. 21](lib:swine-production-usda#page=21)). Pigs root under woven wire, so run "one or two electric fence wires near the bottom"
([OSU EM 9271, p. 5](lib:care-of-new-feeder-pigs#page=5)) on the pig side, where a snout meets them first: about **6–8 in and 12–16 in** up *(rule of thumb)*.

![End view of a hog fence: woven wire on the pig side of the post, 32–36 inches high, with a barbed strand at the ground or two hot wires on offsets about 6–8 and 12–16 inches up, and a pig nosing the lower wire](img:PIGS-GUIDE/hog-fence-hot-wire.svg)
*Woven wire with low hot wires on the pig side; in a dry summer the lower wire becomes the ground wire ([FB 1437, p. 21](lib:swine-production-usda#page=21); [OSU EM 9271, p. 5](lib:care-of-new-feeder-pigs#page=5)) (a diagram drawn for this guide).*

### Electric wire with no power from the grid
- **Sun and a battery:** "Electric fences can be run off of solar charged batteries"
  ([*Raising Healthy Sheep*, p. 131](lib:raising-healthy-sheep-cvm#page=131)). Face the panel south
  ([UF bear fences, p. 5](lib:building-bear-fences-for-your-apiary#page=5)); buy a solar charger and a spare battery **now** *(rule of thumb)*.
- **Dry summer soil** can't carry the shock back to the ground rod: make the bottom wire a **ground wire** and keep the upper one hot
  ([OSU EM 9271, p. 5](lib:care-of-new-feeder-pigs#page=5)). A pig touching both gets the shock.
- **Train pigs to the wire** in a small pen with a solid fence behind it while you still have a charger. Pigs that have been shocked often respect a dead wire
  for a while, but they test fences: **never trust a cold wire alone**; with no charger, the woven wire, barbed strand, hog panels, boards or stone are the
  fence *(rule of thumb)*.
- **Against bears**, an electric pen needs at least **3 strands** (5–6 better), the lowest **7–9 in** up, the top **36–42 in**, wires **8–10 in** apart, and at
  least **6,000 volts and 0.5 joule** ([ODFW bear-country chickens, p. 2](lib:raising-chickens-in-bear-country#page=2)).

### Rooting: the problem and the plow
Pigs root hardest in wet ground ([FB 599, p. 3](lib:pasture-and-grain-crops-for-hogs#page=3)), and west of the Cascades winter tramping "puddles" (packs and
ruins) wet soil: take them off pasture in heavy rain, except on sandy soil or tight sod ([p. 12](lib:pasture-and-grain-crops-for-hogs#page=12)). **English
ryegrass** sod "stands tramping well" ([p. 15](lib:pasture-and-grain-crops-for-hogs#page=15)), and straw spread first protects heavy soil
([p. 17](lib:pasture-and-grain-crops-for-hogs#page=17)). Keep the winter lot on your best-drained, gravelly ground *(rule of thumb)*. **Ringed** hogs (rings in
the top of the snout) can't dig tubers (same page); buy rings and a ringer now *(rule of thumb)*. Rooting is also free plowing: hogs work stalks into the soil
and spread their droppings evenly ([p. 7](lib:pasture-and-grain-crops-for-hogs#page=7)). Turn pigs onto a finished garden in early fall, then move them before
the mud *(rule of thumb)*.

### Predators, and pigs as a danger
"Store livestock food in a secure place" ([ODFW, p. 2](lib:living-with-black-bears-odfw#page=2)), and shelter animals at night against [cougars](wiki:Cougar)
([ODFW, p. 2](lib:oregon-is-cougar-country-odfw#page=2)): a **night pen** near the house and carrying off carcasses are rated effective against lions, bears and
coyotes ([UC ANR 8598, p. 5](lib:livestock-protection-tools#page=5)). Bears raid pig pens and take piglets *(rule of thumb)*. Sows with piglets and boars "may
attack and bite" ([*No Animal Doctor*, p. 47](lib:where-there-is-no-animal-doctor#page=47)): carry a board to hold between you, never turn your back on a boar,
keep children out of the pen, and keep pigs from chickens, which they kill *(rule of thumb)*.

## 🌾 Feeding with no feed store

**Pasture alone is not enough for growing pigs:** they get "big bellied, and thin in flesh or stunted," though dry sows can hold condition on good pasture
([FB 599, p. 4](lib:pasture-and-grain-crops-for-hogs#page=4)). On pasture feed grain at about **2–3% of live weight a day**, or **1%** for a light ration, then
fatten on all they clean up three times a day ([p. 5](lib:pasture-and-grain-crops-for-hogs#page=5)); a growing pig on abundant pasture gets **1–2 lb of grain a
day** ([FB 1437, p. 15](lib:swine-production-usda#page=15)). **Change feed slowly**, a quarter at a time over at least a week
([p. 10](lib:swine-production-usda#page=10)).

### Pasture and crops for hogs in the Pacific Northwest
USDA Farmers' Bulletin 599 was written for Washington, Oregon and Idaho; in western Oregon it finds hog pasture "throughout the entire year"
([FB 599, pp. 2, 12–15](lib:pasture-and-grain-crops-for-hogs#page=2)):

| Crop | Sow | Graze | Hogs per acre |
|---|---|---|---|
| Red clover (drained soil), alsike (wet) | A year ahead | April–November; best April–June, fades in drought | 8–16 |
| [Alfalfa](wiki:Alfalfa) | A year ahead | April–November; "highly successful in the Umpqua and Rogue River Valleys on irrigated and subirrigated land" | 8–16 |
| [Rape](wiki:Rapeseed) in hoed rows | April 1, 15 and 30 | June–November; green all summer if cultivated | 8–14 |
| [Vetch](wiki:Vicia_sativa) with wheat or oats | In corn in July, or on stubble in early fall | October/November–April | 5–8 |
| [English ryegrass](wiki:Lolium_perenne), 10–15 lb seed per acre | Spring or fall, with grain | Early fall to the next July | 5–14 |
| Winter wheat | September–October | February–April | 8–16 |

Split pasture in two or more and move hogs every **7–10 days**, turning them in when clover or alfalfa is **3–4 in** high and rape, kale or vetch **8–10 in**
([p. 3](lib:pasture-and-grain-crops-for-hogs#page=3)); legume pasture means less grain ([p. 6](lib:pasture-and-grain-crops-for-hogs#page=6)). Never plan "just
enough": an acre carries **5–15 hogs of 100 lb** ([FB 1437, p. 19](lib:swine-production-usda#page=19)). Here grass and clover quit in July unless watered, so
plan summer around grain to hog off *(rule of thumb)*; serpentine ground grows poor, low-calcium pasture
([NRCS, p. 49](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=49)).

### Hogging down grain, peas and corn
"Hogging off" means turning hogs into a ripe field to harvest it themselves: no threshing or hauling, and the hogs need only "water, shade, and salt"
([FB 599, pp. 6–7](lib:pasture-and-grain-crops-for-hogs#page=6)). In western Oregon: **beardless barley** July 1–20, **soft club winter wheat** July 10–August
10, **field peas** July 25–October 1, **corn** (planted April 20–May 10) from mid-September, earlier in the Rogue Valley
([pp. 15–16](lib:pasture-and-grain-crops-for-hogs#page=15)). Bearded barley and hard wheat hurt pigs' mouths
([pp. 8–9](lib:pasture-and-grain-crops-for-hogs#page=8)). Fence off only what the herd cleans up in **15–20 days**, or rain sprouts the peas and molds the corn;
to size it, count how many days a fenced trial acre lasts ([pp. 9, 11](lib:pasture-and-grain-crops-for-hogs#page=9)).

### Winter feed: kale, roots, squash and artichokes
Thousand-headed **[kale](wiki:Kale)** (sown March–April, transplanted in June) stands in the field and feeds **October–April**, best from a rack;
**[squash](wiki:Winter_squash)** planted about May 25 and stored dark under straw feeds November–January
([FB 599, p. 16](lib:pasture-and-grain-crops-for-hogs#page=16)), and squash and pumpkins are "favorite foods"
([OSU EM 9271, p. 5](lib:care-of-new-feeder-pigs#page=5)). **[Mangels](wiki:Mangelwurzel)**, beets, carrots and rutabagas go whole from the field
([FB 599, pp. 17, 22](lib:pasture-and-grain-crops-for-hogs#page=17)), though good alfalfa does more ([FB 1437, p. 10](lib:swine-production-usda#page=10)). Pigs
dig **[Jerusalem artichokes](wiki:Jerusalem_artichoke)** on sandy creek land all winter ([FB 599, p. 17](lib:pasture-and-grain-crops-for-hogs#page=17)).
**Cooked potatoes:** 4½ lb equal 1 lb of corn, no more than 4 lb of potato to 1 of grain ([FB 1437, p. 9](lib:swine-production-usda#page=9)). Chopped, soaked
alfalfa hay can be **half the ration** of pigs you aren't hurrying ([FB 599, p. 22](lib:pasture-and-grain-crops-for-hogs#page=22)), and unthreshed bundle grain
carries dry sows through winter ([p. 24](lib:pasture-and-grain-crops-for-hogs#page=24)).

### Acorns and other mast
"Mast" is the nuts that fall in autumn. An English feeder reckoned a peck of acorns a day with a little bran put on **about a pound a day for two months**;
California hogs ate raw acorns "with impunity," though in England they were "occasionally condemned as fatal"
([Chesnut 1902, p. 353](lib:chesnut-1902#page=353)). OSU replaced **15–30%** of a finishing ration with ground cull **hazelnuts** for the last 42 days, as Spain
and Italy finish ham pigs on acorns ([OSU EM 9271, p. 7](lib:care-of-new-feeder-pigs#page=7)). The oak poison is in **young leaves, buds and green acorns**
([WSU, p. 27](lib:wsu-selected-poisonous#page=27)). Gather the ripe brown acorns of [Oregon white oak](wiki:Quercus_garryana),
[black oak](wiki:Quercus_kelloggii) and [tanoak](wiki:Notholithocarpus) in September–November, feed them **with** other feed, never alone, and dry some for
winter *(rule of thumb)*. Bears work the same groves, so bring the acorns to the pigs, never the pigs to the woods *(rule of thumb)*. Windfall fruit feeds pigs
too, and picking it up keeps bears away ([ODFW, p. 2](lib:living-with-black-bears-odfw#page=2)).

### Garbage, skim milk and whey: cook it first
- **Kitchen garbage** "containing raw meat scraps or bones" spreads trichinae ([FB 1437, p. 5](lib:swine-production-usda#page=5)), and cooking garbage stops TB,
  in many areas "almost as frequent" in pigs as in cattle ([*Zoonoses*, p. 27](lib:zoonoses-diseases-animals#page=27)). **Boil all garbage that has touched
  meat** at least **30 minutes**, longer with bones ([p. 113](lib:zoonoses-diseases-animals#page=113)); see "Garbage when no truck comes" in the
  [Sanitation guide](guide:SANITATION-GUIDE).
- **Skim milk** is "a valuable protein supplement for grain," not a whole ration: about **4–5 lb per lb of grain** for weaned pigs, **2–3 lb** at 50–100 lb,
  **1–2 lb** for big hogs. **Whey** is worth half as much, best with barley and peas ([FB 1437, pp. 10–11](lib:swine-production-usda#page=10)). **Boil milk and
  whey** unless the animals are tested free of TB ([p. 11](lib:swine-production-usda#page=11)): with no testing, always. See "Whey and buttermilk" in the
  [Milk, Butter & Cheese guide](guide:DAIRY-GUIDE).
- **Meat scraps and offal** from healthy animals are good protein, as the old packing-house "tankage" was ([FB 1437, p. 10](lib:swine-production-usda#page=10)),
  but **only boiled** ([*Slaughter and Preservation of Meat*, p. 68](lib:slaughter-and-preservation-of-meat#page=68)), and not pork *(rule of thumb)*.

### Grain, protein and minerals
- **Grains** against corn: wheat about 5% better, barley 90–95%, rye 95–100% but less liked, oats 60–70% (good for sows and growing pigs); grind them coarsely
  ([FB 1437, pp. 8–9](lib:swine-production-usda#page=8)), and don't cook grain: it is "more harmful than beneficial"
  ([p. 13](lib:swine-production-usda#page=13)).
- **Protein:** **24%** of the diet at 10–20 lb, falling to **13%** over 150 lb ([OSU EM 9271, p. 3](lib:care-of-new-feeder-pigs#page=3)); **15%** for a pregnant
  sow ([FB 1437, p. 14](lib:swine-production-usda#page=14)). Without bought meal: milk, whey, peas, clover, alfalfa and cooked scraps *(rule of thumb)*.
- **Home mineral mix:** equal weights of steamed bone meal, ground limestone (or air-slaked lime) and salt, plus wood ashes up to a third of it, iodized salt
  where goiter occurs, kept dry in a covered box ([FB 1437, pp. 11–12](lib:swine-production-usda#page=11)). Even **1 part salt to 4 parts wood ash** beats none;
  sows on grain alone run short of calcium and **"dog sit"** ([*No Animal Doctor*, p. 327](lib:where-there-is-no-animal-doctor#page=327)).
- **Selenium:** Oregon is short of it and swine suffer for it, but it is also a poison ([OSU EM 9094, p. 1](lib:selenium-supplementation-strategies#page=1)).
  Stock a swine trace-mineral salt with selenium now and never give more than the label says *(rule of thumb)*.

### What not to feed

| Never feed | Why | Source |
|---|---|---|
| Raw meat, bones or garbage that touched meat; any carcass; dead rats; raw bear or other wild meat | Trichinosis, TB and more; wild trichinella survives freezing and smoking | [FB 1437, pp. 5, 38](lib:swine-production-usda#page=5); [*Zoonoses*, p. 120](lib:zoonoses-diseases-animals#page=120); "Disease and safety" in the [Hunting guide](guide:HUNTING-TRAPPING-FISHING-GUIDE) |
| Raw poultry offal; raw milk or whey from untested animals | Bird TB; cattle TB | [FB 1437, p. 11](lib:swine-production-usda#page=11) |
| Human waste: pigs must never reach a latrine | Pork tapeworm, which can cause seizures in people | [*Zoonoses*, pp. 110, 112](lib:zoonoses-diseases-animals#page=110) |
| Green or sprouted potatoes, potato and tomato vines, nightshade | Solanine | [WSU, p. 21](lib:wsu-selected-poisonous#page=21) |
| [Poison hemlock](wiki:Conium_maculatum) (pigs like it); water hemlock roots (pigs dig them) | Death within hours; poison hemlock on days **30–60** of pregnancy deforms piglets | [AIB 415, p. 81](lib:plants-poisonous-to-livestock-in-the-western#page=81); [WSU, pp. 12–13](lib:wsu-selected-poisonous#page=12) |
| Cocklebur seedlings; early-spring death camas; hedge trimmings (yew, oleander, rhododendron); lots of green acorns | Poisoning; yew kills before signs show | [AIB 415, pp. 113, 115](lib:plants-poisonous-to-livestock-in-the-western#page=113); [PNW 104, p. 2](lib:meadow-deathcamas#page=2); [WSU, pp. 15, 27](lib:wsu-selected-poisonous#page=15) |
| Salty slop, brine or cured-meat trimmings without plenty of water | Salt poisoning: blind, deaf, convulsions, death | [*No Animal Doctor*, p. 332](lib:where-there-is-no-animal-doctor#page=332) |

Keep sheep out of the pig feed: it can hold enough copper to poison them ([*No Animal Doctor*, p. 74](lib:where-there-is-no-animal-doctor#page=74)).

📚 **Go deeper:** [USDA FB 599](lib:pasture-and-grain-crops-for-hogs#page=2) — PNW hog crops, dates and grazing systems; [FB 1437, pp. 8–15](lib:swine-production-usda#page=8) — grains, protein, minerals and sow rations; [🖼️ hay racks, FB 599, pp. 22–23](lib:pasture-and-grain-crops-for-hogs#page=22).

## 💧 Water, shade and heat: pigs die of heat

"Pigs of all ages can overheat if they struggle, and can even die from heat stress. If boars overheat, they can be sterile for several months. Sows easily
overheat when giving birth." Handle pigs only in the cool of early morning or evening
([*No Animal Doctor*, p. 47](lib:where-there-is-no-animal-doctor#page=47)). "Hogs suffer greatly from heat and must have shade"
([FB 1437, p. 37](lib:swine-production-usda#page=37)), and sunburn is the other summer hazard ([OSU EM 9271, p. 5](lib:care-of-new-feeder-pigs#page=5)).

1. **Water all day:** **½–1½ gallons per 100 lb of pig**, the high end for young pigs and nursing sows, more in heat
   ([Peace Corps, p. 210](lib:peace-corps-livestock-training#page=210)): about **4½ gallons** for a 300-lb nursing sow *(arithmetic)*. Clean water whenever they
   want it, not twice a day in a foul trough ([FB 1437, p. 12](lib:swine-production-usda#page=12)). Don't share a water source with pigs
   ([Peace Corps, p. 210](lib:peace-corps-livestock-training#page=210)).
2. **Shade that breathes:** trees in a clump, or a frame **about 4 ft high** roofed with hay, straw or weeds **at least 2 ft deep**, wetted on hot days so it
   drips, cooling the air and laying the dust. **Low farrowing houses and A-frame huts are not shade:** pigs crowd into them "even though they suffocate"; shut
   them in hot weather ([FB 1437, p. 37](lib:swine-production-usda#page=37)).
3. **A wallow:** FB 1437 wants **4–6 in** of water in a shaded concrete wallow, changed often, and calls a mud wallow "a nuisance" because pigs drink the foul
   water ([p. 37](lib:swine-production-usda#page=37)); the Peace Corps manual counts a mud wallow as heat protection
   ([p. 286](lib:peace-corps-livestock-training#page=286)). In a valley August any wallow beats none: keep it shaded and refill it with clean water
   *(rule of thumb)*.
4. **No work in the heat:** no moving, weaning or hauling in the hot of the day; breeding above **86 °F (30 °C)** "greatly" cuts fertility, so breed morning or
   evening ([Peace Corps, p. 230](lib:peace-corps-livestock-training#page=230)).
5. **Smoke days:** clean water, extra shade or sprinkling, and put off weaning, regrouping and hauling until the air clears
   ([PNW783, p. 10](lib:wildfires-smoke-and-livestock#page=10)).

![Two side views: on the left an open shade about 4 feet high roofed with 2 feet of straw, wetted so it drips, with pigs lying under it; on the right a low A-frame hut crossed out, labeled as a heat trap to shut in hot weather](img:PIGS-GUIDE/shade-not-a-low-hut.svg)
*Open straw shade, wetted on hot days; low huts trap heat and must be shut in summer ([FB 1437, p. 37](lib:swine-production-usda#page=37)) (a diagram drawn for this guide).*

**A pig down in the heat** (panting, open mouth, wobbling, lying flat): stop, get it into shade, pour cool water over it, **especially the head**, let it rest,
then offer water; an overheated animal may not drink until it cools ([*No Animal Doctor*, p. 124](lib:where-there-is-no-animal-doctor#page=124)). A pig that
went without water and acts blind or convulses has salt poisoning: **small drinks often**, not all it wants at once
([p. 332](lib:where-there-is-no-animal-doctor#page=332)).

## 🍼 Breeding, farrowing and piglets

| | What to know |
|---|---|
| Heat | First at about **5 months** if well fed (separate young boars and gilts by then); every **21 days**, lasting **1–3 days**: swollen red vulva, restless grunting; in **standing heat** she stands stock-still when you press on her back ([Peace Corps, p. 228](lib:peace-corps-livestock-training#page=228)) |
| First breeding | Not before **8 months**, on her third heat, to farrow at about a year (same page; [FB 1437, p. 22](lib:swine-production-usda#page=22)); don't rebreed a first-litter gilt for fall (same page) |
| Mating | **Twice, about 12 hours apart** ([Peace Corps, p. 230](lib:peace-corps-livestock-training#page=230)); a young boar serves one sow a day ([FB 1437, p. 22](lib:swine-production-usda#page=22)). Write the date down |
| Gestation | **114 days**, "3 months, 3 weeks, and 3 days" ([Peace Corps, p. 231](lib:peace-corps-livestock-training#page=231)); **112–115** in FB 1437 ([p. 22](lib:swine-production-usda#page=22)). Bred December 15 = due about April 8 *(arithmetic)* |
| The boar | Not used before **8 months**; never one with a single testicle or from a ruptured litter ([FB 1437, pp. 7–8](lib:swine-production-usda#page=7)). One serves **10–15 sows** for **5–6 years** ([Peace Corps, p. 230](lib:peace-corps-livestock-training#page=230)); a borrowed boar can bring brucellosis ([p. 282](lib:peace-corps-livestock-training#page=282)) |
| The pregnant sow | In good flesh, not fat; about **1½ lb of feed per 100 lb** of sow a day (**2 lb** for a gilt), with grain scattered in the field to make her walk ([FB 1437, p. 13](lib:swine-production-usda#page=13)). A sow that eats her pigs was usually fed or kept badly ([p. 15](lib:swine-production-usda#page=15)) |

### Getting ready to farrow
**Farrow in spring when the nights have warmed:** newborn pigs want about **95 °F** for three days, then 85 °F over three weeks, and "demand the most heat of
any young domestic livestock" ([OSU EM 9271, p. 8](lib:care-of-new-feeder-pigs#page=8)); with no heat lamps you have timing, straw and the sow's own heat *(rule
of thumb)*. Not in August either: sows overheat giving birth ([*No Animal Doctor*, p. 47](lib:where-there-is-no-animal-doctor#page=47)).
1. **Pen her 3 days before** she is due, in a dry, airy pen about **7 × 7 ft** with a **guard rail** of 2-by-4s (or pipe, which can't be chewed) around the
   inside, **about 10 in off the floor and 4–6 in from the walls** ([FB 1437, p. 24](lib:swine-production-usda#page=24)), so a piglet lies safe in the gap when
   she lies down against the wall ([Peace Corps, p. 288](lib:peace-corps-livestock-training#page=288)).
2. **Clean it** with scalding water and lye, rinse and dry ([FB 1437, p. 25](lib:swine-production-usda#page=25)), and if you can leave it **empty in the sun for
   a few weeks** ([*No Animal Doctor*, p. 347](lib:where-there-is-no-animal-doctor#page=347)). **Bed it** with dry **wheat or rye straw** or chopped hay, **not
   oat straw**, which stays wet; wash the mud off her sides and udder before she goes in ([FB 1437, p. 25](lib:swine-production-usda#page=25)).
3. **Feed her outside** in a yard **6–8 ft** long off the pen: a sow fed among her piglets cripples or kills them ([p. 26](lib:swine-production-usda#page=26)).
4. **A warm corner** she can't enter: a boxed-in "hover" holds the piglets' own heat and stops drafts ([OSU EM 9271, p. 8](lib:care-of-new-feeder-pigs#page=8)).
   A farrowing crate (**4½–5 ft by 8 ft**, the sow unable to turn) stays **20–25 °F warmer** than the barn from her heat alone
   ([FB 1437, p. 29](lib:swine-production-usda#page=29); [Peace Corps, p. 288](lib:peace-corps-livestock-training#page=288)).

![A farrowing pen from above: about 7 by 7 feet with a guard rail all round, the sow lying in the middle, piglets along the walls, a warm corner only piglets can enter, and a door to an outside feeding pen 6–8 feet long; beside it a cut-through view of the wall showing a 2-by-4 rail about 10 inches up and 4–6 inches out, with a piglet lying safe under it](img:PIGS-GUIDE/farrowing-pen-guard-rail.svg)
*The guard rail keeps the sow from pinning a piglet against the wall ([FB 1437, pp. 24–26](lib:swine-production-usda#page=24)) (a diagram drawn for this guide).*

**Signs she is close:** the udder fills **7–10 days** ahead; colostrum (first milk) can be squeezed out **within 24 hours**; she grows restless, makes a nest,
and may turn aggressive ([Peace Corps, p. 231](lib:peace-corps-livestock-training#page=231)). Halve her feed the day before; none for 24 hours after, but plenty
of lukewarm water ([FB 1437, p. 15](lib:swine-production-usda#page=15)).

### Farrowing night
Someone should be there, checking every hour with a light ready ([FB 1437, p. 25](lib:swine-production-usda#page=25);
[Peace Corps, p. 231](lib:peace-corps-livestock-training#page=231)).
1. **Each piglet:** clear the membranes off the nose; if it isn't breathing, a few gentle slaps on the side or a brisk rub. Dry it, tie the cord with thread
   **1–2 in** from the belly, cut beyond the knot, dip in **iodine**. Keep the litter in a box lined with sacks around **warm bricks or a jug of hot water
   wrapped in cloth**, and let them nurse if farrowing drags past 2–3 hours ([FB 1437, p. 25](lib:swine-production-usda#page=25);
   [Peace Corps, p. 233](lib:peace-corps-livestock-training#page=233)).
2. **How long:** **3–4 hours**, about **15 minutes** between pigs. Wait up to **4 hours**, or a stillborn pig, before reaching in or giving oxytocin, both "last
   resort measures" for the experienced ([Peace Corps, p. 233](lib:peace-corps-livestock-training#page=233)).
3. **The afterbirth** ends it; a retained piece infects her, and a cloudy, smelly one may mean brucellosis (same page). Wear gloves *(rule of thumb)*.
4. **Colostrum the first day** or the piglet dies. A sow raises only as many as she has working teats: foster extras onto another sow, masking everyone's smell.
   A piglet under **1 lb** has "no chance" ([pp. 229, 233](lib:peace-corps-livestock-training#page=229)). **A sow with no milk:** undiluted cow's milk every **2
   hours**, ½ in deep in a clean shallow pan ([FB 1437, p. 14](lib:swine-production-usda#page=14)).

### Piglets: crushing, cold, teeth and iron
- "Over 50 percent of the losses of newborn pigs during the first 10 days of life happen in the first 24 hours"; they chill easily
  ([FB 1437, p. 26](lib:swine-production-usda#page=26)), and crushing is worst the first week ([p. 29](lib:swine-production-usda#page=29)).
- **Needle teeth:** snip the top third off all **8** with sharp side-cutting pliers so they don't tear the teats and each other; **don't break or pull them**
  ([FB 1437, p. 26](lib:swine-production-usda#page=26); [Peace Corps, p. 234](lib:peace-corps-livestock-training#page=234)). Tails need no docking where pigs
  have room.
- **Iron:** sow's milk lacks it, so piglets kept off soil turn pale, sluggish and rough-coated, then weak, with scours or "thumps" (gasping)
  ([FB 1437, p. 32](lib:swine-production-usda#page=32)). **Put clean, fresh soil or a sod in the pen** (same page), dug where no pigs have been, since soil
  carries worm eggs *(rule of thumb; [Peace Corps, p. 234](lib:peace-corps-livestock-training#page=234))*. Injectable iron goes in the ham in the first three
  days (same page); follow its label ([Medical guide](guide:Medical-READ-ME-FIRST)).
- **Creep feed** at **3 weeks** (a corner with grain only piglets can reach), protein at **5–6 weeks** ([FB 1437, p. 32](lib:swine-production-usda#page=32)).

### Castration
Castrate boar pigs you won't breed: no stray litters or inbreeding, calmer pigs, and no **[boar taint](wiki:Boar_taint)** (the foul smell of mature boar meat)
([*No Animal Doctor*, p. 192](lib:where-there-is-no-animal-doctor#page=192); [OSU EM 9271, p. 6](lib:care-of-new-feeder-pigs#page=6)). Do it **at about 2 weeks,
while they suckle**, so they heal before weaning ([FB 1437, p. 32](lib:swine-production-usda#page=32);
[Peace Corps, p. 235](lib:peace-corps-livestock-training#page=235)).
1. A helper holds the pig by the hind legs, or on its back in the lap, rump up. **Feel for a hernia** (gut in the scrotum): if there is one, don't castrate
   ([*No Animal Doctor*, p. 192](lib:where-there-is-no-animal-doctor#page=192)).
2. Wash scrotum and hands. Press a testicle against the skin and cut **low**, ½–1 in long, so it drains; press it out and pull gently until the cord tears off
   near the body, which bleeds less than cutting; repeat on the other side ([Peace Corps, pp. 235–236](lib:peace-corps-livestock-training#page=235)).
3. Wash off the blood (it draws flies), dab on iodine, keep the pig on **clean, dry bedding** for 24 hours, and check it daily for 3 days
   ([Peace Corps, p. 236](lib:peace-corps-livestock-training#page=236)). Grown boars bleed more and need a skilled hand
   ([*No Animal Doctor*, p. 193](lib:where-there-is-no-animal-doctor#page=193)).

### Weaning and the next litter
Wean at **8 weeks or later**: a good sow milks to 10–12 weeks, and a pig stunted by early weaning never catches up. Cut the sow's feed 4–5 days before, then
take **her** away and leave the pigs in their pen ([FB 1437, pp. 32–33](lib:swine-production-usda#page=32)). She comes back in heat **3–5 days** later
([Peace Corps, p. 229](lib:peace-corps-livestock-training#page=229)). **Three litters in two years** is a good average; fall pigs need extra care, and none
should come after **October 15** ([FB 1437, pp. 33–34](lib:swine-production-usda#page=33)).

📚 **Go deeper:** [🖼️ FB 1437, pp. 25–30](lib:swine-production-usda#page=25) — bedded pen, cutting teeth, hover, crate; [🖼️ Peace Corps, p. 289](lib:peace-corps-livestock-training#page=289) — farrowing stalls; [🖼️ *No Animal Doctor*, p. 192](lib:where-there-is-no-animal-doctor#page=192) — castration.

## 🩺 Pig health with no vet

**Know normal:** about **102.2 °F** for a grown pig, **103.6 °F** for a young one ([*No Animal Doctor*, p. 66](lib:where-there-is-no-animal-doctor#page=66));
OSU uses **102.5 °F ± 1** ([EM 9271, p. 4](lib:care-of-new-feeder-pigs#page=4)). Pulse and breathing are in
[Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE). Watch daily for coughing, fever, going off feed, dullness and hard or fast breathing, and act
at the first sign. Give shots in the **neck just behind and below the ear**, never the ham or loin, and wait out every withdrawal time before slaughter
([EM 9271, p. 4](lib:care-of-new-feeder-pigs#page=4)). **To hold a big pig**, slip the loop of a finger-thick rope at least 10 ft long into its mouth **behind
the big canine teeth** and tie it low to a post ([🖼️ *No Animal Doctor*, p. 47](lib:where-there-is-no-animal-doctor#page=47)). Medicines in general: the
[Medical guide](guide:Medical-READ-ME-FIRST); this guide gives no doses.

**Prevention does most of the work.** The old USDA sanitation system controls most worms: a clean farrowing pen, the sow washed before farrowing, a clean trip
to clean pasture, and clean pasture for the pigs until **4 months** old ([FB 1437, p. 41](lib:swine-production-usda#page=41)). Disinfect with soap and water,
then chlorine or iodine, then **48 hours of sun** ([Peace Corps, p. 288](lib:peace-corps-livestock-training#page=288)). Change bedding before it is wet and foul
([FB 1437, p. 37](lib:swine-production-usda#page=37)). Keep new pigs apart **30–60 days** *(rule of thumb; FB 1437 holds new breeding stock through two blood
tests 60 days apart, [p. 40](lib:swine-production-usda#page=40))*.

| Trouble | Signs | What to do |
|---|---|---|
| **Large roundworm** ([Ascaris](wiki:Ascaris_suum)) | Poor growth; **white spots on the liver** at butchering | Clean pens, sun, fresh ground; worm sows the month before farrowing if you have a wormer ([*No Animal Doctor*, pp. 346–347](lib:where-there-is-no-animal-doctor#page=346)) |
| **Swine flu** | Off feed, violent cough, vomiting, fever | Warm dry quarters, rest, fresh water ([FB 1437, p. 38](lib:swine-production-usda#page=38)) |
| **[Erysipelas](wiki:Erysipelothrix_rhusiopathiae)** | High fever, hot swollen joints, purple ears and belly, **raised diamond-shaped red patches**; later lameness | Penicillin if you have it ([*No Animal Doctor*, p. 294](lib:where-there-is-no-animal-doctor#page=294)). **People catch it handling infected meat**: gloves ([FB 1437, p. 39](lib:swine-production-usda#page=39)) |
| **[Brucellosis](wiki:Brucellosis)** | Abortions, weak or stillborn pigs, sterility, hind-end weakness, swollen testicles | Buy from clean herds, isolate newcomers, cull. **It infects people**: gloves at farrowings ([FB 1437, pp. 39–40](lib:swine-production-usda#page=39)) |
| **Tuberculosis** | Found at slaughter | From TB birds and cattle and raw milk: cook offal, boil milk ([FB 1437, p. 40](lib:swine-production-usda#page=40)) |
| **Atrophic rhinitis** | Sneezing young pigs, later a twisted snout | No cure once bent; clean, airy pens ([*No Animal Doctor*, p. 293](lib:where-there-is-no-animal-doctor#page=293)) |
| **Lice and mange** | Scratching, scabby skin, poor growth | Worst in thin pigs ([Peace Corps, p. 274](lib:peace-corps-livestock-training#page=274)); clean bedding ([*No Animal Doctor*, pp. 131–133](lib:where-there-is-no-animal-doctor#page=131)); not the old dips |
| **Scours** in new feeder pigs | Diarrhea | **20% ground whole oats** or **10%** alfalfa in the feed for some weeks; warmth; sanitation ([OSU EM 9271, pp. 3–4](lib:care-of-new-feeder-pigs#page=3)) |

**Dead pigs:** never let pigs eat one; burn it, or bury it **4 ft** deep under quicklime ([FB 1437, pp. 38–39](lib:swine-production-usda#page=38)); see "Dead
animals and gut piles" in the [Sanitation guide](guide:SANITATION-GUIDE).

📚 **Go deeper:** [Peace Corps Vol 4, pp. 244–278](lib:peace-corps-livestock-training#page=244) — swine diseases and parasites (skip its chemical tables).

## 🔪 Butchering day

### Planning a hog-killing day
- **Wait for cold:** the carcass must reach **34–40 °F within 24 hours**, 48 at most ([FB 1186, p. 3](lib:farmers-bulletin-1186#page=3)): here, **late November
  to February**, in a dry spell with nights near freezing *(rule of thumb)*; in a hard freeze, hang it in a shed or wrap it in a sheet
  ([p. 16](lib:farmers-bulletin-1186#page=16)). Kill a healthy hog of about **200–225 lb** ([FB 2138, pp. 5–6](lib:pork-slaughtering-cutting#page=5)), never one
  found dead, feverish or down ([*Slaughter and Preservation of Meat*, pp. 27–28](lib:slaughter-and-preservation-of-meat#page=27)).
- **Tools:** a curved 6-inch skinning knife (it sticks too), a narrow boning knife, steel and oilstone, a 24–28-inch meat saw, bell scrapers, a hook, a
  thermometer to 212 °F, tubs for edible and inedible insides, plenty of hot and cold water, and a **50-gallon barrel** with **25–30 gallons** of water, which
  scalds a hog up to **250 lb**, tilted at the end of a scraping table **4½ ft wide, 2½ ft high, 4–8 ft long**
  ([FB 2138, pp. 4–5, 9](lib:pork-slaughtering-cutting#page=4)). Hang the carcass from a singletree gambrel on a beam, a limb or a "hobbyhorse" hoist
  ([AWI-68, p. 7](lib:smokehouses-and-hog#page=7)).
- **People:** two to scrape, one at each end of the table ([FB 2138, p. 5](lib:pork-slaughtering-cutting#page=5)), and a third for the fire and water
  *(rule of thumb)*. Shut the dogs away: raw pork scraps give them trichinosis ([*Zoonoses*, p. 113](lib:zoonoses-diseases-animals#page=113)).
- **The day before:** pen the hog alone, **24 hours** without feed but with water, and never chase or wrestle it: a heated hog bleeds poorly and its "fiery"
  meat spoils ([FB 2138, p. 6](lib:pork-slaughtering-cutting#page=6)).

![A neighborhood scalding setup: a hog hanging from a gambrel on a 7-foot pole frame, a scraping platform 8 feet long with removable slats, and a scalding tank set in a brick firebox with a stovepipe](img:PIGS-GUIDE/scalding-vat-and-hanging-rail.png)
*Neighbors who kill several hogs a year can share a scalding vat over a firebox, a scraping platform and a hanging rail ([AWI-68, p. 7](lib:smokehouses-and-hog#page=7)).*

### Killing and sticking
Shoot or stun first, and make the **first** shot count ([FB 2138, p. 7](lib:pork-slaughtering-cutting#page=7)). The brain is small and behind thick sinuses: aim
**on the center line of the forehead, slightly above a line between the eyes, not between the eyes** ([UF VM114, p. 9](lib:humane-euthanasia-of-sick#page=9)),
toward the spinal canal ([AVMA, p. 119](lib:avma-guidelines#page=119)). A **.22 long rifle** does for young animals, but hollow points may not get through an
adult skull: use a heavier bullet on old sows and boars. Hold the muzzle **a few inches** off the head ([VM114, p. 5](lib:humane-euthanasia-of-sick#page=5));
bullets "glance from a hog's skull," so keep people and stock out of line ([FB 2138, p. 7](lib:pork-slaughtering-cutting#page=7)).

![A pig's head from the front, with the aim point on the center line just above a dashed line between the eyes and a red X between the eyes; beside it a side view with an arrow entering the forehead and pointing back toward the spine](img:PIGS-GUIDE/where-to-shoot-a-pig.svg)
*Aim slightly above the eye line, on the center line, toward the tail ([UF VM114, p. 9](lib:humane-euthanasia-of-sick#page=9); [AVMA, p. 119](lib:avma-guidelines#page=119)) (a diagram drawn for this guide).*

**Stick at once**, with the hog hoisted by a hind leg or on its back, a helper astride holding the front feet
([FB 2138, pp. 7–8](lib:pork-slaughtering-cutting#page=7)): open the skin about **3 in** in front of the breastbone; push the knife in **edge down, straight
toward the breastbone**; follow the bone down until the knife slips under it and push about **1 in** more; cut toward the backbone, then thrust **forward toward
the head** to cut the artery. Stay on the center line or you stick a shoulder; **don't stick the heart**; let it bleed out. Keep the hole no wider than the
blade, so scald water can't get in ([*Slaughter and Preservation of Meat*, p. 62](lib:slaughter-and-preservation-of-meat#page=62)).

![Cut-away drawing of a hog's neck and chest on its back: the knife shown in three positions, entering in front of the breastbone, sliding under it, and turned forward to cut the artery and vein, with the heart behind](img:PIGS-GUIDE/sticking-a-hog.png)
*The knife (a) into the fat, (b) above the artery, (c) after the cut; the heart is not the target ([USDA FB 2138, p. 8](lib:pork-slaughtering-cutting#page=8)).*

### Scalding or skinning
**Scalding** keeps the skin for cracklings, salt pork and hams that store well, but takes much hot water and fuel. The books differ, and all work: **143 °F ± 2
for 4–4½ minutes** ([*Slaughter and Preservation of Meat*, p. 63](lib:slaughter-and-preservation-of-meat#page=63)); **140–145 °F** in a barrel, as hotter water
may "set" the bristles ([AWI-68, p. 7](lib:smokehouses-and-hog#page=7)); or on a farm **155–165 °F** to start, the hog kept moving and pulled out often
([FB 2138, p. 9](lib:pork-slaughtering-cutting#page=9)). **Test, don't guess:** when the hair on ham, flank, belly and head slips out, take the hog out
([*Slaughter and Preservation of Meat*, p. 63](lib:slaughter-and-preservation-of-meat#page=63)). **Scrape fast**, before the skin sets: twist the hair off the
legs, pull dewclaws and toes with the hook while hot, scrape with the bell scraper on edge, put sacks and hot water on stubborn patches, then rinse, singe and
shave ([FB 2138, pp. 9–11](lib:pork-slaughtering-cutting#page=9)). **Skinning** suits hogs over about **250 lb**: prop it on its back with bricks and skin it
like a beef, slowly, since the skin is thin ([*Slaughter and Preservation of Meat*, pp. 62–63](lib:slaughter-and-preservation-of-meat#page=62)); it needs no
barrel or fire, but you lose the rind *(rule of thumb)*.

### Gutting, chilling and cutting
1. Slip the gambrel under **both** big hind-leg tendons and hoist ([FB 2138, p. 11](lib:pork-slaughtering-cutting#page=11)). Split the breastbone; cut down
   between the hams, missing the bladder; open the belly with the knife handle inside and the point out ([pp. 11–13](lib:pork-slaughtering-cutting#page=11)).
2. Tie off the bung (rear gut) ([*Slaughter and Preservation of Meat*, p. 65](lib:slaughter-and-preservation-of-meat#page=65)), free the liver, cut the
   diaphragm, and lift out guts, heart and lungs **without rupturing the guts**. Save liver (gall bladder off), heart, tongue, and caul and ruffle fat for lard
   ([FB 2138, pp. 13–15](lib:pork-slaughtering-cutting#page=13)).
3. **Look before you eat:** white spots on the liver mean roundworm ([*No Animal Doctor*, p. 346](lib:where-there-is-no-animal-doctor#page=346)); **small shiny
   bladders, ½–1 cm, under the tongue** or in jaw, heart, diaphragm or shoulder muscle are pork tapeworm cysts
   ([*Zoonoses*, p. 111](lib:zoonoses-diseases-animals#page=111)). Boil such offal and bury it under lime
   ([*Slaughter and Preservation of Meat*, p. 67](lib:slaughter-and-preservation-of-meat#page=67)); bury a carcass full of cysts *(rule of thumb)*.
4. Wash out the cavity, saw down the backbone, **pull the leaf fat while warm**, and hang the halves apart, or hams and bellies spoil overnight
   ([FB 2138, pp. 14, 16](lib:pork-slaughtering-cutting#page=14)): dress in the afternoon, cut next morning
   ([FB 1186, p. 16](lib:farmers-bulletin-1186#page=16)). If it turns warm, cut up the sides and hang the pieces to air, but nothing is as safe as cold
   ([FB 2138, p. 19](lib:pork-slaughtering-cutting#page=19)).
5. **Cut the cold carcass** ([pp. 18–23](lib:pork-slaughtering-cutting#page=18); [🖼️ cuts, p. 19](lib:pork-slaughtering-cutting#page=19)): head off behind the
   ears; shoulder off between the 2nd and 3rd ribs, split into **picnic** (cure it with the hams), **butt** and fat **plate** (lard or salt pork); **ham**
   behind the rise of the pelvic bone; **loin** sawn off the **bacon**; **spareribs** lifted off the bacon; **jowls** cured like bacon.

**Eat, cure or can fresh pork within 3–5 days**: it spoils faster than other meat ([FB 2138, p. 24](lib:pork-slaughtering-cutting#page=24)), and can it only in
a **pressure canner** ([pp. 39–40](lib:pork-slaughtering-cutting#page=39)). Curing, smoking and storing hams and bacon: "Curing pork and venison" in the
[Preserving Food guide](guide:PRESERVING-FOOD-GUIDE); smoke with hardwood, never pine, at **100–120 °F**, in a smokehouse at least **50 ft** from other
buildings ([FB 2138, pp. 32–34](lib:pork-slaughtering-cutting#page=32)).
- **Fresh sausage:** **⅓ fat, ⅔ lean**; test batch **4 lb** trimmings, **5 tsp salt, 4 tsp sage, 2 tsp pepper, 1 tsp sugar**
  ([FB 2138, p. 45](lib:pork-slaughtering-cutting#page=45)). **Fry a patty to check the seasoning; never taste it raw**
  ([FB 1186, p. 41](lib:farmers-bulletin-1186#page=41)).
- **[Headcheese](wiki:Head_cheese):** simmer head (eyes, eardrums, teeth and nasal passages out), tongue, heart and clean skin until the meat slips off the
  bone; chop, add broth, boil again, season and chill in pans. **[Scrapple](wiki:Scrapple):** **4 parts** ground cooked meat, **3** broth, **1** cereal (7
  cornmeal to 3 flour) ([FB 2138, pp. 46–48](lib:pork-slaughtering-cutting#page=46)).

📚 **Go deeper:** [USDA FB 2138](lib:pork-slaughtering-cutting#page=4) — the whole job in photos; [AWI-68](lib:smokehouses-and-hog#page=7) — hoists, scald vats, smokehouses; [Oregon custom-exempt FAQ, p. 2](lib:custom-exempt-slaughter#page=2) — in normal times custom-killed meat "cannot be sold, traded, bartered or given away," so trade live pigs or shares of a live pig.

## 🫙 Rendering lard and cracklings

Lard is **9–13% of the live weight** of a meat-type hog and **14–18%** of a fat one ([FB 2138, p. 6](lib:pork-slaughtering-cutting#page=6)); a 225-lb hog gave
**27 lb** of fat for the kettle ([p. 22](lib:pork-slaughtering-cutting#page=22)).
1. **Sort it.** **Leaf fat** (from around the kidneys) makes the best lard; render it apart for baking. Back fat and trimmings make the rest; caul and ruffle
   fat from the guts give darker lard, so render them separately ([FB 2138, p. 40](lib:pork-slaughtering-cutting#page=40)); strong intestinal fat is for
   **soap** ([Minnesota, p. 2](lib:making-lard-at-home#page=2)).
2. **Keep it cold and render soon:** at **32–35 °F** no more than **5–7 days** (same page).
3. **Cut it small**; take off the skin for whiter lard and pick out every bit of lean, which browns and darkens it (same page;
   [FB 2138, p. 23](lib:pork-slaughtering-cutting#page=23)).
4. **Kettle:** iron, steel or aluminum, **never copper**. A little water in the bottom, a small batch on a low fire, the rest added as it melts; don't fill it,
   or it boils over ([Minnesota, p. 3](lib:making-lard-at-home#page=3); [FB 2138, p. 40](lib:pork-slaughtering-cutting#page=40)).
5. **Heat:** it sits near **212 °F** while the water cooks off, then climbs; hold **235–245 °F** ([Minnesota, p. 3](lib:making-lard-at-home#page=3)), **never
   above 255 °F** ([FB 2138, p. 42](lib:pork-slaughtering-cutting#page=42)). Stir often so nothing scorches.
6. **Done** when the bubbling stops and the [cracklings](wiki:Cracklings) float, chestnut-brown and easily crushed; fully rendered they sink. Full rendering
   drives out the water so the lard keeps (same pages).
7. **Strain** through two or three layers of cheesecloth, press the cracklings, and pour into clean, scalded, dry crocks or tins of **5–10 lb**, **filled to the
   top**; cool fast and store **dark and cool, below 50 °F** ([FB 2138, p. 42](lib:pork-slaughtering-cutting#page=42);
   [Minnesota, pp. 3–4](lib:making-lard-at-home#page=3)).

**Yields:** leaf fat **90–93%** lard; mixed leaf, back and cutting fat **80–85%**; gut fat **55–65%**; pressed cracklings **4–6%** of the fat
([FB 2138, p. 42](lib:pork-slaughtering-cutting#page=42)): the 27 lb of fat makes roughly **22 lb of lard** *(arithmetic)*. Air, light, water left in, and warm
storage make lard rancid; 10% beef fat firms soft lard; slightly rancid lard is rescued by heating it with sliced potatoes until they brown, then straining
([Minnesota, p. 4](lib:making-lard-at-home#page=4)). ⚠️ **Hot fat burns badly:** keep children back, keep a lid at hand to smother a fire, and **never put water
on burning fat** *(rule of thumb)*. Eat the cracklings as they are or in cornbread *(rule of thumb)*. More in "Salt, sweeteners and fat" in
[Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE); soap in "Soap from fat and ashes" in the [Make-Do Household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE).

## 🦠 Keeping pigs and people safe

**[Trichinosis](wiki:Trichinosis)** is a worm in the muscle of pigs, rats, bears and other meat-eaters, caught from raw or undercooked meat, most often pork.
**8–15 days** later come sudden muscle pain and **swollen upper eyelids**, then eye pain, sweats and fever to 104 °F; heart and nerve damage can kill in weeks
3–8 ([*Zoonoses*, pp. 120–121](lib:zoonoses-diseases-animals#page=120)). If that follows a meal of pork or bear, see the
[Medical guide](guide:Medical-READ-ME-FIRST).
- **Keep it out of the pigs:** boil garbage with meat in it, feed no raw meat or carcasses ([FB 1437, p. 5](lib:swine-production-usda#page=5);
  [*Zoonoses*, p. 113](lib:zoonoses-diseases-animals#page=113)), and keep rats out of feed and pens *(rule of thumb)*.
- **Cook pork until it changes from pink to gray all through**, at least **170 °F (77 °C)** inside
  ([*Zoonoses*, p. 121](lib:zoonoses-diseases-animals#page=121); [FB 2138, p. 46](lib:pork-slaughtering-cutting#page=46)). FB 2138 says heating it **through to
  137 °F** kills the worms (same page); cook well past that, since thick cuts fool you *(rule of thumb)*.
- **Freezing** works only in a deep freezer: **5 °F for 20–30 days** or −10 °F for 10–20 days ([FB 2138, p. 46](lib:pork-slaughtering-cutting#page=46)). Wild
  trichinella in bear meat survives freezing ([Hunting guide](guide:HUNTING-TRAPPING-FISHING-GUIDE)). With no freezer, **cook it**.
- **Home-cured and smoked pork is raw.** People caught trichinosis from "imperfectly cooked fresh pork, and sausage, smoked hams, bacon, and shoulders," and
  from **tasting sausage** while seasoning it ([FB 1186, p. 41](lib:farmers-bulletin-1186#page=41)). Cook country ham and bacon.

**Pork tapeworm ([Taenia solium](wiki:Taenia_solium)):** pigs get the cysts by eating human feces; people get the tapeworm from undercooked pork, and its eggs
can grow cysts in another person's **brain**, "the major cause of seizures" in many poor countries
([*Zoonoses*, pp. 109–110](lib:zoonoses-diseases-animals#page=109)). **Pigs must never reach a latrine, outhouse pit or human waste**, raw sewage must not
fertilize their ground, and all pork must be cooked well ([pp. 112–113](lib:zoonoses-diseases-animals#page=112)); **salting and pickling don't kill the cysts**
([p. 113](lib:zoonoses-diseases-animals#page=113)). Latrines are in the [Sanitation guide](guide:SANITATION-GUIDE).

**Also from pigs:** erysipelas from handling infected meat, brucellosis, and TB through raw milk and garbage
([FB 1437, pp. 39–40](lib:swine-production-usda#page=39)). Wear gloves to butcher and to help a farrowing, cover cuts, wash well, and keep **pregnant women**
away from abortions and afterbirths *(rule of thumb)*. Bites, kicks and knife cuts: [Field Care guide](guide:FIELD-CARE-GUIDE).

## 🚫 Never let pigs go feral

A pig that gets loose for good does not stay a farm pig *(rule of thumb)*. Free-ranging pigs spread diseases and parasites to people, lose more to predators,
and breed with no control ([Peace Corps, p. 285](lib:peace-corps-livestock-training#page=285)); free-range village pigs are "not-too-distant offspring" of wild
ones ([p. 283](lib:peace-corps-livestock-training#page=283)). A gilt can come in heat at about **5 months** and farrow **114 days** later
([pp. 228, 231](lib:peace-corps-livestock-training#page=228)), and a good sow raises **8** or more ([FB 1437, p. 7](lib:swine-production-usda#page=7)): one
loose pair can be dozens within two years *(arithmetic)*. [Feral pigs](wiki:Feral_pig) root up meadows, camas beds and creek banks, raid gardens and grain,
carry brucellosis and trichinella, and a wild sow is dangerous *(rule of thumb)*.
- **Never release pigs**: not to "fend for themselves," not when feed runs short, not to fatten on acorns in the woods. Sell, trade or butcher them. Releasing
  pigs is against the law in Oregon in normal times; the drive has no copy of the rule *(rule of thumb)*.
- **Count the pigs every day**, walk the fence weekly, fix holes at once, chain the gates, and castrate every boar you won't breed *(rule of thumb;
  [*No Animal Doctor*, p. 192](lib:where-there-is-no-animal-doctor#page=192))*.
- **A pig gets out:** go after it the same day with a feed bucket while it still comes to you. If it can't be caught in a few days, shoot it, use the meat
  (cooked well), and tell your neighbors. Never let anyone "seed" pigs in the hills for hunting *(rule of thumb)*.

## 📅 A pig year in the Illinois Valley

| When | Pigs | Work |
|---|---|---|
| Dec–Jan | Sows bred; fat hogs ready; mud | **Kill, cut, render and cure** on cold dry days; breed sows (bred Dec 15 = farrow about Apr 8 *(arithmetic)*); pigs on the drained winter lot or ryegrass sod; kale, roots, squash, artichokes and bundle grain |
| Feb–Mar | Pregnant sows | Winter wheat and vetch pasture; sow peas, beardless barley and spring grain to hog off; dig and seed old pig lots; clean farrowing pens and leave them in the sun |
| Apr–May | **Farrowing** | Pens ready 3 days early; snip teeth; sods for iron; castrate at 2 weeks; creep at 3 weeks; plant rape (Apr 1, 15, 30), corn (Apr 20–May 10), squash (May 25) |
| Jun–Jul | Weaned at 8–10 weeks; heat begins | Wean onto clean pasture; shade, wallow and water daily; transplant kale; hog off barley (Jul 1–20) and wheat (Jul 10–Aug 10); no open burning in fire season ([Wildfire guide](guide:WILDFIRE-GUIDE)) |
| Aug–Sep | Growing pigs; heat and smoke | Peas hogged off to Oct 1; no hauling or breeding in the heat of the day; rebreed a grown sow early in the morning for a fall litter |
| Oct–Nov | Acorns fall; rains start | Corn hogged down; acorns, hazelnuts and windfalls; sow vetch, ryegrass and winter wheat; pigs off soggy pasture; no fall litter after Oct 15 ([FB 1437, p. 33](lib:swine-production-usda#page=33)); plan the kill |

Crop dates are the book's for western Oregon ([FB 599, pp. 12–16](lib:pasture-and-grain-crops-for-hogs#page=12)); the fit to our valley is a *rule of thumb*.
April pigs are **7–8 months** old by December, when FB 599's well-fed pasture hogs reach 170–225 lb ([p. 5](lib:pasture-and-grain-crops-for-hogs#page=5)); OSU
says feeder pigs can be ready at **six months** ([EM 9271, p. 5](lib:care-of-new-feeder-pigs#page=5)).

## 👪 How many pigs feed a family

| Goal | What it takes | Source |
|---|---|---|
| Pork and lard | One **200-lb** meat-type hog ≈ a year's pork and lard for **two**. A family of four: **2 hogs**; **3–4** if pork and lard are your main meat and only fat | [FB 2138, p. 6](lib:pork-slaughtering-cutting#page=6) *(arithmetic; rule of thumb)* |
| One hog gives | **225 lb** live → **176 lb** carcass → **113 lb** hams, picnics, bacon, loin and butt, **34 lb** ribs, sausage, feet and head, **27 lb** fat (≈ **22 lb** lard) | [FB 2138, p. 22](lib:pork-slaughtering-cutting#page=22) *(lard: arithmetic)* |
| Grain | **300–350 lb** of grain plus **25–35 lb** of protein feed per **100 lb** of gain on full feed: about **600–700 lb** of grain to raise a weaned pig. Less with pasture, milk and scraps, but slower | [FB 1437, p. 17](lib:swine-production-usda#page=17) *(arithmetic)* |
| Grain land | At 30 bushels (1,800 lb) of wheat an acre, about **⅓–⅖ acre** of grain per hog | [FB 599, p. 11](lib:pasture-and-grain-crops-for-hogs#page=11) *(arithmetic)* |
| Pasture | **8–16** hogs an acre on clover or alfalfa: about **¼ acre** for two feeders, in two paddocks | [FB 599, p. 12](lib:pasture-and-grain-crops-for-hogs#page=12) *(arithmetic)* |
| Water | Two 200-lb hogs and a nursing sow: about **10 gallons** a day in summer | [Peace Corps, p. 210](lib:peace-corps-livestock-training#page=210) *(arithmetic)* |
| Breeding stock | **1–2 sows** and a share in a boar. One sow raising **8** pigs, three litters in two years, gives about **12 pigs a year**: enough for 3–4 families, or for trade | [FB 1437, pp. 7, 33](lib:swine-production-usda#page=7) *(arithmetic)* |
| Or buy feeders | **2** weaned pigs in spring, killed in winter: no sow or boar to feed all year, but only while someone nearby keeps sows | *(rule of thumb)* |

## 🧬 Keeping the line going

- **Records:** breeding date, boar, farrowing date, pigs born and weaned, sicknesses; a big calendar will do
  ([Peace Corps, p. 237](lib:peace-corps-livestock-training#page=237)).
- **Keep gilts** from big litters that grew well and from calm sows that milked to 10–12 weeks; choose at **5–6 months**, when faults show, and grow them on
  pasture with only ¼–⅓ of their feed as corn ([FB 1437, pp. 6–7, 34–35](lib:swine-production-usda#page=6)).
- **Keep a good sow 6–8 years** ([p. 22](lib:swine-production-usda#page=22)); cull cross sows, pig-eaters, poor milkers and any that won't settle
  ([pp. 6, 32](lib:swine-production-usda#page=6)).
- **Boars:** "the boar is half the herd"; pick one to correct the sows' faults, and when his daughters join the herd **trade him** for an unrelated boar as good
  ([FB 1437, p. 7](lib:swine-production-usda#page=7)). A neighborhood should keep **at least two unrelated boars** and swap them every few years
  *(rule of thumb)*. There is no artificial insemination without liquid nitrogen to store semen
  ([*No Animal Doctor*, p. 193](lib:where-there-is-no-animal-doctor#page=193)).
- **Crossbreed** for vigor: a crossbred sow to a boar of a third breed, then to a fourth ([Peace Corps, p. 282](lib:peace-corps-livestock-training#page=282)),
  so keep several breeds in the valley *(rule of thumb)*. **Save seed** of rape, kale, mangels, peas, barley and squash: they are the feed
  ([Seed Bank guide](guide:SEED-BANK-GUIDE)).

**Ear notches** last for life where tags tear out. Notch soon after farrowing, while wounds heal fast, with small sharp side-cutting pliers, deep enough to take
some cartilage ([FB 1437, pp. 35–36](lib:swine-production-usda#page=35)). Each notch place has the value printed beside it in the drawing; add up a pig's
notches to read its number, and write it down with its mother's *(how to read the drawing)*.

![A pig's face from the front with notch places on both ears: on the pig's right ear 3000, 9000 and 1000 along the top edge, 30 at the tip, 90 and 10 along the lower edge; on the left ear 300, 900 and 100 along the top, 3 at the tip, 9 and 1 along the lower edge](img:PIGS-GUIDE/ear-notching-pigs.png)
*The ear-notch numbering system; "right" and "left" are the pig's own ears ([USDA FB 1437, p. 36](lib:swine-production-usda#page=36)).*

## 🧯 If this goes wrong

| Problem | Likely cause and fix |
|---|---|
| Piglets found flat and dead the first days | Crushed: guard rail, warm corner, someone at the farrowing ([FB 1437, pp. 24, 26, 29](lib:swine-production-usda#page=24)) |
| Piglets shivering in a heap | Cold and drafts: dry straw, a closed-in warm corner, a box with warm bricks ([OSU EM 9271, p. 8](lib:care-of-new-feeder-pigs#page=8); [FB 1437, p. 25](lib:swine-production-usda#page=25)) |
| Piglets pale, rough-coated, gasping at 2–3 weeks | Iron: fresh sod or clean soil ([FB 1437, p. 32](lib:swine-production-usda#page=32)) |
| Sow eating her pigs | Poor feed and care in pregnancy; cull if it happens again ([FB 1437, p. 15](lib:swine-production-usda#page=15)) |
| Sow has no milk | Cow's milk every 2 hours in a shallow pan, or foster ([FB 1437, p. 14](lib:swine-production-usda#page=14); [Peace Corps, p. 229](lib:peace-corps-livestock-training#page=229)) |
| Pig down, panting, on a hot day | Shade, cool water on the head, rest, then water ([*No Animal Doctor*, p. 124](lib:where-there-is-no-animal-doctor#page=124)) |
| Pigs digging out; fence weak in August | Hot wire near the bottom; in dry soil make the low wire a ground wire ([OSU EM 9271, p. 5](lib:care-of-new-feeder-pigs#page=5)) |
| Sow won't settle | Breed twice, 12 hours apart, in standing heat, in the cool of the day ([Peace Corps, pp. 228, 230](lib:peace-corps-livestock-training#page=228)) |
| Hair won't scrape off | Water too hot (hair "set") or too cool; sacks and hot water on stubborn patches ([FB 2138, p. 9](lib:pork-slaughtering-cutting#page=9)) |
| Meat bloody and spoiling | Hog chased or hot when killed, or bled poorly ([FB 2138, p. 6](lib:pork-slaughtering-cutting#page=6)) |
| Ham smells sour at the bone | Run a sharpened wire along the bone; if it smells rotten, destroy the piece ([FB 2138, p. 35](lib:pork-slaughtering-cutting#page=35)) |
| Lard went rancid | Water left in, light, air or storage over 50 °F ([Minnesota, p. 4](lib:making-lard-at-home#page=4)) |
| Sore muscles and puffy eyelids a week after eating pork | Trichinosis: get medical help ([*Zoonoses*, p. 121](lib:zoonoses-diseases-animals#page=121)) |

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Worm pigs with **sodium fluoride**; spray lice and mange with **BHC, lindane, chlordane, toxaphene, TDE, methoxychlor**, or dip in crude petroleum — [FB 1437, p. 41](lib:swine-production-usda#page=41); more in the Peace Corps lice table — [p. 279](lib:peace-corps-livestock-training#page=279) | Poisons, now banned. Clean pens, sun, fresh ground and the sanitation system ([FB 1437, p. 41](lib:swine-production-usda#page=41)) |
| **Crude oil** on the wallow water for lice — [FB 1437, p. 37](lib:swine-production-usda#page=37) | Clean water, changed often |
| **Formalin** drops on a scouring piglet's tongue — [FB 1437, p. 15](lib:swine-production-usda#page=15) | A poison. Warmth, dry clean bedding, a clean sow |
| Disinfect with **compound cresol** — [FB 1437, p. 37](lib:swine-production-usda#page=37) | Soap and water, chlorine or iodine, 48 hours of sun ([Peace Corps, p. 288](lib:peace-corps-livestock-training#page=288)) |
| Cook only the meat scraps; let hogs pick the raw garbage — [FB 1437, p. 5](lib:swine-production-usda#page=5) | Boil all garbage that touched meat ([*Zoonoses*, pp. 27, 113](lib:zoonoses-diseases-animals#page=27)) |
| Sticking **without stunning** drains the blood better — [FB 1186, p. 7](lib:farmers-bulletin-1186#page=7) | Shoot or stun first, then stick at once ([FB 2138, p. 7](lib:pork-slaughtering-cutting#page=7)) |
| Spray **insecticide** before slaughter — [FB 2138, p. 3](lib:pork-slaughtering-cutting#page=3) | Skip it: butcher in cold weather when flies are few, and screen the cooling room |
| Paint meat bags with **barium sulfate** — [FB 2138, p. 36](lib:pork-slaughtering-cutting#page=36) | The same book's lime, clay or flour wash ([p. 37](lib:pork-slaughtering-cutting#page=37)) |
| **Lorexane** (lindane) or another pesticide on castration wounds — [*No Animal Doctor*, p. 192](lib:where-there-is-no-animal-doctor#page=192) | Wash off the blood, iodine, clean dry bedding ([Peace Corps, p. 236](lib:peace-corps-livestock-training#page=236)) |
| Burn the pea vines after rain — [FB 599, p. 9](lib:pasture-and-grain-crops-for-hogs#page=9) | Never in fire season; a movable fence does the job (same page) |
| Raw sour milk for the pigs (*Keeping One Cow*, 1888) | Boil milk and whey unless the animals are tested free of TB ([FB 1437, p. 11](lib:swine-production-usda#page=11); [*Zoonoses*, p. 27](lib:zoonoses-diseases-animals#page=27)) |

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings and photos in the books on this drive; the other links open the offline Wikipedia.

- Hog types and breeds — [🖼️ Peace Corps, p. 281](lib:peace-corps-livestock-training#page=281); [🖼️ FB 1437, p. 6 (sow)](lib:swine-production-usda#page=6); [🖼️ p. 8 (boar)](lib:swine-production-usda#page=8); [Pig](wiki:Pig); [Mangalica (a lard breed)](wiki:Mangalica)
- Pigs on pasture, gleaning barley, hogging down corn, hay racks, artichokes — [🖼️ FB 599, p. 4](lib:pasture-and-grain-crops-for-hogs#page=4); [🖼️ p. 10](lib:pasture-and-grain-crops-for-hogs#page=10); [🖼️ p. 18](lib:pasture-and-grain-crops-for-hogs#page=18); [🖼️ pp. 22–23](lib:pasture-and-grain-crops-for-hogs#page=22); [🖼️ FB 1437, p. 17](lib:swine-production-usda#page=17); [Pannage (acorn feeding)](wiki:Pannage)
- Straw-bale shelter and shade; feeders, creep and a concrete waterer — [🖼️ FB 1437, p. 38](lib:swine-production-usda#page=38); [🖼️ p. 31](lib:swine-production-usda#page=31); [🖼️ Peace Corps, pp. 290–291](lib:peace-corps-livestock-training#page=290)
- Heat chart; farrowing pen, washing the sow, cutting teeth, hover, crate, stalls — [🖼️ Peace Corps, p. 228](lib:peace-corps-livestock-training#page=228); [🖼️ FB 1437, pp. 25–30](lib:swine-production-usda#page=25); [🖼️ Peace Corps, p. 289](lib:peace-corps-livestock-training#page=289)
- Holding a pig, castrating a piglet; erysipelas, salt poisoning, a dog-sitting sow — [🖼️ *No Animal Doctor*, p. 47](lib:where-there-is-no-animal-doctor#page=47); [🖼️ p. 192](lib:where-there-is-no-animal-doctor#page=192); [🖼️ p. 294](lib:where-there-is-no-animal-doctor#page=294); [🖼️ p. 124](lib:where-there-is-no-animal-doctor#page=124); [🖼️ p. 327](lib:where-there-is-no-animal-doctor#page=327)
- Poison and water hemlock — [🖼️ WSU, p. 13](lib:wsu-selected-poisonous#page=13); [🖼️ AIB 415, p. 81](lib:plants-poisonous-to-livestock-in-the-western#page=81)
- Where to shoot — [🖼️ UF VM114, p. 9](lib:humane-euthanasia-of-sick#page=9); [🖼️ AVMA, p. 119](lib:avma-guidelines#page=119)
- Equipment, holding for sticking, scalding, scraping, gutting, leaf fat, cuts — [🖼️ FB 2138, p. 5](lib:pork-slaughtering-cutting#page=5); [🖼️ p. 7](lib:pork-slaughtering-cutting#page=7); [🖼️ p. 10](lib:pork-slaughtering-cutting#page=10); [🖼️ pp. 11–18](lib:pork-slaughtering-cutting#page=11); [🖼️ p. 19](lib:pork-slaughtering-cutting#page=19); [🖼️ FB 1186, p. 17](lib:farmers-bulletin-1186#page=17); [Pig slaughter](wiki:Pig_slaughter)
- Hoists, scalding barrel, smokehouses — [🖼️ AWI-68, p. 7](lib:smokehouses-and-hog#page=7); [🖼️ p. 8](lib:smokehouses-and-hog#page=8); [🖼️ barrel smoker, FB 2138, p. 43](lib:pork-slaughtering-cutting#page=43)
- Lard and pork dishes — [Lard](wiki:Lard); [Cracklings](wiki:Cracklings); [Scrapple](wiki:Scrapple); [Head cheese](wiki:Head_cheese)
- Life cycles of pork tapeworm and trichinella — [🖼️ *Zoonoses*, p. 114](lib:zoonoses-diseases-animals#page=114); [🖼️ p. 122](lib:zoonoses-diseases-animals#page=122); [Cysticercosis](wiki:Cysticercosis)
- Feral pigs — [Feral pig](wiki:Feral_pig); [Wild boar](wiki:Wild_boar)

## 🔗 Related guides

- [Preserving Food](guide:PRESERVING-FOOD-GUIDE) and [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — curing, smoking and canning pork; lard; acorn flour
- [Milk, Butter & Cheese](guide:DAIRY-GUIDE) — the whey and skim milk the pigs drink (boiled)
- [Goats](guide:GOATS-GUIDE) and [Chickens](guide:CHICKENS-GUIDE) — the other homestead animals; the [Sheep](guide:SHEEP-GUIDE), [Cattle](guide:CATTLE-GUIDE), [Ducks](guide:DUCKS-GUIDE), [Geese](guide:GEESE-GUIDE), [Turkeys](guide:TURKEYS-GUIDE) and [Dogs](guide:DOGS-GUIDE) guides cover the rest
- [Sanitation](guide:SANITATION-GUIDE) and [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — cooking garbage, manure, latrines pigs can't reach, dead animals; soap from waste fat
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) — trichinella in bear and other wild meat
- [Wildfire](guide:WILDFIRE-GUIDE) and [Home Defense](guide:HOME-DEFENSE-GUIDE) — burning rules and smoke; guarding livestock
- [Seed Bank](guide:SEED-BANK-GUIDE) and [Food Security](guide:FOOD-SECURITY-GUIDE) — seed for the feed crops; how much meat and fat a family needs
- [Medical](guide:Medical-READ-ME-FIRST), [Field Care](guide:FIELD-CARE-GUIDE) and [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — medicines, trichinosis, bites; livestock vital signs
- [Building Soil](guide:GROWING-SOIL-GUIDE) — animals that till and fertilize; tree crops they harvest themselves
