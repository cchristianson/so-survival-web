# 🚰 How Town Water and Sewer Work

How a small town gets water from a river or well to every tap, and its sewage from every drain back to the river; how
a town could keep a small system going with no grid; what to do when the water or sewer fails; and the dangers that
kill people who work on them. The books are in `Homestead-Skills\Sanitation-Water` (WHO's emergency notes),
`Water-Purification\Filters-Sand-Charcoal-Ceramic` (slow sand filters for a village), `Sanitation-Hygiene\Latrines-Toilets`
(sewers, lagoons and treatment), `Homestead-Skills\Household-Make-Do` (the *Village Technology Handbook*) and
`EMP-Solar-Storms\Effects-and-Threat` (water when the grid goes); Josephine County's hazard plan, which describes Cave Junction's own water and sewer, is in `Disaster-Scenarios\Local-Hazards`,
and the Oregon Resilience Plan, with its earthquake estimates, in `Disaster-Scenarios\Cascadia-Earthquake`. Water for one house is in the
[Water Wells](guide:WATER-WELLS-GUIDE) and [Water Purification](guide:WATER-PURIFICATION-GUIDE) guides; toilets,
septic tanks and disease are in the [Sanitation guide](guide:SANITATION-GUIDE).

> ### The short version
> - **Town water runs on electricity.** Pumps fill tanks on high ground, and the tanks give the pressure. With no power
>   they drain in hours to a day or two ([county plan, p. 286](lib:josephine-county-multi-jurisdictional#page=286)). When Montreal's two plants stopped in an ice storm, the
>   city had **4 to 8 hours** of water left ([EMP Commission, p. 160](lib:emp-commission-critical-national-infrastructures#page=160)).
>   **Fill every clean container the moment the power goes** *(rule of thumb)*.
> - **When pressure drops, dirty water gets into the pipes** through every leak. Treat tap water as unsafe until it is
>   tested: boil or disinfect it ([WHO/WEDC, p. 46](lib:who-wedc-technical-notes#page=46)).
> - **If mains break, shut your house valve** to keep the clean water in your pipes and water heater
>   ([Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23)).
> - **Never climb into a manhole, wet well, tank or vault, not even to save someone.** Sewer gas drops people fast,
>   and "the rescuer rushes in and becomes the second victim" ([Hospital Corpsman, p. 128](lib:hospital-corpsman#page=128)).
> - **When the sewer stops, stop flushing:** the pipes under the street may be broken
>   ([OSU *Sanitation*, p. 5](lib:osu-extension-survival-basics-sanitation#page=5)). Plug the drains and use bucket
>   toilets or latrines ([Sanitation guide](guide:SANITATION-GUIDE)).
> - **A small town can make safe water with no grid:** gravity, settling, two slow sand beds, chlorine dosed by hand,
>   and a test at the farthest tap.
> - **Ask the water operator now for the system map and the valve list.** Repair crews start with them
>   ([WHO/WEDC, p. 15](lib:who-wedc-technical-notes#page=15)).

---

## 🗺️ The whole system in one picture
<!-- fold: The path water takes from the river to your tap and back to the river, in one table -->

Water and sewage are one loop: untreated sewage spoils the water of everyone downstream
([Hesperian Ch 7, p. 15](lib:building-toilets#page=15)).

| Stop on the way | What happens there |
|---|---|
| **Source and intake** | A river, lake, well or spring ([EMP Commission, p. 157](lib:emp-commission-critical-national-infrastructures#page=157)); a screen keeps out debris and a pond lets mud settle ([WHO/WEDC, p. 25](lib:who-wedc-technical-notes#page=25)) |
| **Treatment plant** | Settling, filtering and chlorine make it safe to drink |
| **Pumps and tanks on high ground** | Pumps fill the tanks; the tanks give the pressure and keep water for fires |
| **Mains, valves and hydrants** | Pipes under the street, with valves to shut off a stretch for repair |
| **Service line** | Your own pipe, with a valve in a box at the curb and one in the house |
| **Drains and sewers** | Each drain has a water-filled bend (a trap) that keeps sewer gas out *(rule of thumb)*; sewers slope downhill all the way |
| **Lift stations** | Pumps that lift sewage where the ground is too flat or rises |
| **Sewage plant or lagoons** | Screens, settling, bacteria and chlorine clean it before it goes back to the river |

Each person uses about **100 gallons a day** at home, all treated to drinking standard, though very little is drunk
([EMP Commission, p. 156](lib:emp-commission-critical-national-infrastructures#page=156)).

## 💧 Where a town's water comes from
<!-- fold: Rivers, wells, springs and infiltration galleries, and what each needs -->

Cities usually take water from rivers, lakes and reservoirs; country towns often use wells
([EMP Commission, p. 157](lib:emp-commission-critical-national-infrastructures#page=157); [water supply network](wiki:Water_supply_network)).

| Source | Good | Trouble |
|---|---|---|
| **River or creek intake** | Plenty of water, quick to set up | Needs the most treatment ([Sphere, p. 131](lib:sphere-handbook-2018#page=131)); towns, farms and erosion upstream foul it ([WHO/WEDC, p. 24](lib:who-wedc-technical-notes#page=24)) |
| **Wells** | Groundwater needs less treatment ([Sphere, p. 131](lib:sphere-handbook-2018#page=131)) | Need pumps, so power ([EMP Commission, p. 161](lib:emp-commission-critical-national-infrastructures#page=161)) |
| **Springs above town** | Gravity carries it: **no pump at all** ([Sphere, p. 131](lib:sphere-handbook-2018#page=131)) | Rarely big enough for a whole town *(rule of thumb)*; protect it ([Water Wells guide](guide:WATER-WELLS-GUIDE)) |
| **[Infiltration gallery](wiki:Infiltration_gallery)** | Perforated pipe buried in gravel beside or under a river, so the riverbed filters the water *(rule of thumb)* | Silts up in time *(rule of thumb)* |

**Let the riverbed filter it.** Water drawn through a river's own sand into a collecting well went from over 400
turbidity units (very muddy) to under 5 in one Indian village
([IRC *Slow Sand Filtration*, p. 21](lib:slow-sand-filtration-for-community#page=21)). Dams, weirs and ditches are in
the [Dams, Weirs, Ditches & Ponds guide](guide:DAMS-DITCHES-GUIDE).

**Cave Junction's water** comes from the **Illinois River**, through a raw-water intake on Highway 199, and from the
**Daisy Hill Well**. It goes through **one treatment plant** that can treat up to **2 million gallons a day**; the city
uses only about a third of its water rights ([county plan, pp. 108, 124, 129](lib:josephine-county-multi-jurisdictional#page=108)).
The town is **one pressure zone**, fed by **four gravity tanks holding 2.8 million gallons** and one booster pump
station in Kerby, through about **18 miles of pipe** up to 18 inches wide ([p. 128](lib:josephine-county-multi-jurisdictional#page=128);
[🖼️ map of the system, same page](lib:josephine-county-multi-jurisdictional#page=128)). The tanks are the clearwell at the
plant (0.5 million gallons), two on Laurel Road (0.5 and 1.5) and one on South Old Stage Road (0.3)
([p. 124](lib:josephine-county-multi-jurisdictional#page=124)). Homes outside the city's pipes depend on their own wells
and septic tanks *(rule of thumb)*: see the [Water Wells](guide:WATER-WELLS-GUIDE) and [Sanitation](guide:SANITATION-GUIDE) guides.

## 🏭 Treatment, step by step
<!-- fold: Screening, coagulation, settling, rapid and slow sand filters, chlorine, contact time and residual -->

Most plants do the same steps in the same order ([WHO/WEDC, p. 24](lib:who-wedc-technical-notes#page=24);
[🖼️ the whole plant drawn, p. 25](lib:who-wedc-technical-notes#page=25); [water treatment](wiki:Water_treatment)):

| Step | What it does |
|---|---|
| **Screening** | Bar and fine screens catch sticks, leaves and trash ([EMP Commission, p. 157](lib:emp-commission-critical-national-infrastructures#page=157)) |
| **Coagulation** | A chemical, usually **alum** (aluminum sulfate), cancels the charge that keeps mud particles apart, so they stick together ([CAWST, p. 11](lib:household-water-treatment-and-safe-storage-fact-sheets#page=11)) |
| **[Flocculation](wiki:Flocculation)** | Slow, gentle mixing grows them into fluffy clumps called **floc** ([EMP Commission, p. 157](lib:emp-commission-critical-national-infrastructures#page=157)) |
| **[Settling](wiki:Sedimentation_(water_treatment))** | In big, slow tanks the floc sinks as sludge (same page). Done well, these three steps remove 90–99% of germs; done badly, much less. Getting the dose right is a job for trained people ([WHO *Managing Water in the Home*, p. 49](lib:managing-water-in-the-home#page=49)) |
| **Filtering** | A [rapid sand filter](wiki:Rapid_sand_filter) strains out what is left and must be **backwashed** regularly ([EMP Commission, p. 157](lib:emp-commission-critical-national-infrastructures#page=157)); a [slow sand filter](wiki:Slow_sand_filter) is a living filter that also cuts germs ([WHO/WEDC, p. 25](lib:who-wedc-technical-notes#page=25)) |
| **Disinfection** | Chlorine kills what got through, and a little stays in the water to protect it in the pipes ([WHO/WEDC, p. 44](lib:who-wedc-technical-notes#page=44)) |

### Chlorine: contact time and residual
<!-- fold: How long chlorine needs, how much should be left at the tap, and why clear water comes first -->

- **Contact time:** at least **30 minutes** at 64 °F (18 °C) or warmer, **longer in cold water**, so chlorine goes in
  as water enters a tank or a long pipe ([WHO/WEDC, p. 43](lib:who-wedc-technical-notes#page=43); [water chlorination](wiki:Water_chlorination)).
- **Residual** is the chlorine left over; it shows the germs are dead and guards the pipes. Aim for **0.2–0.5 mg/L at
  the tap**, higher near the plant, lower at the far ends ([WHO/WEDC, p. 46](lib:who-wedc-technical-notes#page=46);
  [Sphere, p. 135](lib:sphere-handbook-2018#page=135)). Many people complain at 0.6–1.0
  ([CAWST *Testing*, p. 214](lib:introduction-to-drinking-water-quality-testing#page=214)) and go back to better-tasting,
  unsafe sources ([Sphere, p. 136](lib:sphere-handbook-2018#page=136)).
- **Clear water first:** chlorine misses germs hidden in silt and is weak against *Cryptosporidium*
  ([WHO/WEDC, p. 43](lib:who-wedc-technical-notes#page=43)). Get cloudiness below 5 turbidity units first
  ([Sphere, p. 136](lib:sphere-handbook-2018#page=136)).

## 🗼 Tanks on the hill, pumps and pressure
<!-- fold: Why height gives pressure, what pumps do, pressure zones, and how much a tank holds -->

**Height is pressure:** water gains **1 psi for every 2.31 feet** it falls, so 40 psi at a house needs a tank **more
than 90 feet** above it ([Texas *Rainwater Harvesting*, pp. 21–22](lib:texas-manual-on-rainwater#page=21);
[water tower](wiki:Water_tower)). Town mains run at **40–80 psi**. **Low-lift pumps** bring raw water into the plant,
**high-lift pumps** push treated water out to the tanks, and **booster pumps** serve districts higher up
([EMP Commission, pp. 157–158](lib:emp-commission-critical-national-infrastructures#page=157)). Each tank serves a
**pressure zone**: the houses far enough below it for good pressure *(rule of thumb)*.

The tank covers the gap between steady pumping and use that rises and falls through the day, and holds water for fires
and short breakdowns ([WHO/WEDC, p. 25](lib:who-wedc-technical-notes#page=25)). Most hold only a day or two of normal
use, because water that sits too long goes stale ([county plan, p. 286](lib:josephine-county-multi-jurisdictional#page=286)).

**Cave Junction's margin:** the city uses between 0.337 and 1.18 million gallons a day
([county plan, p. 128](lib:josephine-county-multi-jurisdictional#page=128)), so its 2.8 million gallons of tanks last
about **2½ days at the highest use and 8 days at the lowest**, if every pipe is sound *(arithmetic)*. A big main break or a
large fire empties them much faster. The county warns that where water has to be pumped up to tanks, power outages of
more than a day or two may cut off drinking water, and suggests generators, or quick connections for portable ones, at
the key pumps ([p. 286](lib:josephine-county-multi-jurisdictional#page=286)).

## 🚿 Mains, valves, hydrants and the pipe to your house
<!-- fold: The parts under the street, the valve at the curb and in your house, water hammer, backflow -->

| Part | What it is |
|---|---|
| **Mains** | Big pipes from the tanks, smaller ones along each street ([🖼️ a town's network drawn with its valves, WHO/WEDC p. 16](lib:who-wedc-technical-notes#page=16)) |
| **Stop valves** ([gate valve](wiki:Gate_valve)) | Closing the ones on each side cuts off one stretch for repair (same page) |
| **Washouts** | Valves at low points to drain and flush a main (same page) |
| **[Fire hydrants](wiki:Fire_hydrant)** | For fire engines; crews also use them to fill, flush and test mains ([WHO/WEDC, p. 17](lib:who-wedc-technical-notes#page=17)) |
| **Curb valve and meter** | In a concrete box at the curb; "extremely difficult to turn" and needs a special tool ([Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23)) |
| **House valve** | Where the pipe comes in: garage, basement or by the water heater. **Everyone at home should know how to shut it** (same page) |

**Close valves slowly:** stopping fast water all at once sends a hammer blow down the pipe
([UNL, p. 3](lib:pumps-and-pressure-tanks#page=3); [water hammer](wiki:Hydraulic_shock)).

### Backflow and boil-water notices
<!-- fold: Why lost pressure lets dirt in, cross-connections, and what to do at home -->

**All pipes leak.** When the pressure drops, dirty water enters through the breaks, more than any chlorine people will
drink can deal with, so **a supply that keeps going off must be treated as contaminated** and disinfected where it is
used ([WHO/WEDC, p. 46](lib:who-wedc-technical-notes#page=46); [backflow](wiki:Backflow)). That is why towns put out a
[boil-water notice](wiki:Boil-water_advisory) after a main break or a long power cut.

**Cross-connections:** water can siphon backwards through a hose ([OSU *Twelve Simple Things*, p. 4](lib:twelve-simple-things#page=4)),
so a hose lying in a bucket or stock tank can be sucked into the pipes when pressure drops. Fit backflow preventers
([Texas, p. 48](lib:texas-manual-on-rainwater#page=48); [backflow preventer](wiki:Backflow_prevention_device)) and keep an
air gap between a hose and what it fills ([OSU EM9273, p. 2](lib:open-air-poultry-slaughter#page=2)). Mixed drinking
and sewage plumbing has caused outbreaks ([*Ship's Medicine Chest*, p. 95](lib:ships-medicine-chest#page=95)).

**At home, when mains break or the water is declared unsafe:**
1. **Shut the house valve**, or cracked lines may pollute your supply and gravity drain the water heater and toilet
   tanks ([Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23); [OSU *Water*, p. 3](lib:osu-survival-basics-water#page=3)).
2. **Use the water in the house:** open the highest tap to let air in and draw from the lowest; drain the water heater
   with its power or gas off ([FEMA, p. 40](lib:fema-are-you-ready-citizen-preparedness-guide-2004-full#page=40)).
3. **Treat tap water** until it is declared safe ([Water Purification guide](guide:WATER-PURIFICATION-GUIDE)).

## ⏳ How long the water lasts after the power fails
<!-- fold: What happens in the first hours and days, with real examples, and what to do -->

**The plant stops first:** pumps, mixers, screens and filters all run on the grid. A big plant uses so much power that a
backup generator is impractical; some systems have generators for a reduced supply for a short time
([EMP Commission, pp. 155, 159](lib:emp-commission-critical-national-infrastructures#page=159)). Plants are run by
computer ([SCADA](wiki:SCADA)) with few staff: many valves can be worked by hand, but there may not be enough trained
people to run a plant by hand for long (pp. 158–159).

**Then the tanks drain**, in hours to a day or two ([county plan, p. 286](lib:josephine-county-multi-jurisdictional#page=286)), faster with leaks, fire hoses and everyone
filling bathtubs; houses on the highest ground go dry first *(rule of thumb)*. A blackout over a wide area could stop the
water for "weeks or even months" ([EMP Commission, p. 156](lib:emp-commission-critical-national-infrastructures#page=156));
why is in "Why restarting takes days, weeks or months" in the [Power Grid guide](guide:POWER-GRID-GUIDE).

| What happened ([EMP Commission, pp. 160–161](lib:emp-commission-critical-national-infrastructures#page=160)) |
|---|
| **Montreal, ice storm:** both plants for 1.5 million people failed, leaving **4 to 8 hours** of water. Officials kept it quiet; people hoarded anyway |
| **Fresno, heat-wave blackout:** a city on electric wells; **only 2 of 16 fire stations had water**, and most hydrants were dry |
| **Baltimore, hurricane:** a sewage plant's three pumps stopped and it **spilled 24 million gallons** into the harbor |

**When the power goes for more than a few hours** *(rule of thumb)*: fill every clean container and the bathtub, don't
count on hydrants for fires, and plan for no tap water until the plant has power.

**After a Cascadia earthquake** the Oregon Resilience Plan expects drinking water and sewer to take **1 month to 1
year** to restore in its Valley zone and **1 to 3 years** in its Coastal zone
([Resilience Plan, p. 22](lib:oregon-resilience-plan-full-report#page=22)). Most of Josephine County is in the Valley zone,
parts in the Coastal zone ([county plan, p. 39](lib:josephine-county-multi-jurisdictional#page=39)). Old cast-iron
pipes snap and newer pipes pull apart at the joints, leaving whole towns with no pressure
([Resilience Plan, p. 230](lib:oregon-resilience-plan-full-report#page=230)), and the leaks drain the tanks and take
away fire protection ([p. 229](lib:oregon-resilience-plan-full-report#page=229)).

## 🛠️ Keeping a small system going with no grid
<!-- fold: Gravity, a town-sized slow sand filter, chlorinating by hand, fixing leaks, protecting the source, telling people -->

In an emergency **enough water matters more than perfect water**: get the quantity first, then improve the quality
([WHO/WEDC, p. 24](lib:who-wedc-technical-notes#page=24); [Sphere, p. 136](lib:sphere-handbook-2018#page=136)).

### Let gravity do the work
<!-- fold: Springs above town, generators only to fill tanks, standpipes when the pipes can't hold pressure -->

- **Water from above town needs no pump;** springs and gravity supplies come first ([Sphere, p. 131](lib:sphere-handbook-2018#page=131)).
- **Water from below town is pumped up once:** bring generators to the pumps ([WHO/WEDC, p. 24](lib:who-wedc-technical-notes#page=24)),
  run them a few hours to fill the tanks, and let gravity deliver ("Pump into storage" and ram pumps in the
  [Water Wells guide](guide:WATER-WELLS-GUIDE)).
- **If the pipes can't hold pressure,** run one sound main to **standpipes**: one tap per **250 people**, no home
  farther than **500 m (550 yd)**, no queue over 30 minutes ([Sphere, p. 131](lib:sphere-handbook-2018#page=131)).

### A slow sand filter for a whole town
<!-- fold: How it works, how big, how to run and clean it, and what it can't take -->

A [slow sand filter](wiki:Slow_sand_filter) is the best single treatment a village can build and run: local materials,
no chemicals, a caretaker trained for a short time ([IRC, pp. 19–20](lib:slow-sand-filtration-for-community#page=19)).
Water trickles through fine sand at **0.1–0.3 m (4–12 in) an hour**; a slimy living skin, the
**[schmutzdecke](wiki:Schmutzdecke)**, grows on top and eats germs (p. 19). A mature filter removes **95–100% of fecal
bacteria and nearly all viruses and cysts** ([p. 38](lib:slow-sand-filtration-for-community#page=38)).

- **The box** ([IRC, pp. 31–34](lib:slow-sand-filtration-for-community#page=31); [🖼️ drawn with every valve, p. 32](lib:slow-sand-filtration-for-community#page=32)):
  watertight concrete, ferrocement, stone or brick, 2.5–3 m (8–10 ft) tall; 1–1.5 m of raw water over **0.8–0.9 m of
  fine sand** (grains 0.15–0.30 mm, no clay or soil; never let it get below 0.5 m), over 0.3–0.5 m of graded gravel
  and perforated drains. An outlet weir just above the sand keeps it under water.
- **Size:** **0.02–0.08 m² (¼ to 1 sq ft) of sand per person** ([p. 20](lib:slow-sand-filtration-for-community#page=20)),
  so 20–80 m² (200–900 sq ft) for 1,000 people *(arithmetic)*; a person with one tap uses about 50 litres (13 gallons)
  a day ([p. 46](lib:slow-sand-filtration-for-community#page=46)). **Build two or more beds,** run at **0.1–0.2 m an
  hour**; one may go to 0.3 for a day or two while its partner is cleaned ([p. 40](lib:slow-sand-filtration-for-community#page=40)).
- **Not for muddy water:** over 50 turbidity units for weeks, or 100 for days, clogs it. Settle the water first in a
  pond or gravel roughing filter, or draw it through the riverbed ([p. 19](lib:slow-sand-filtration-for-community#page=19)).

**Running and cleaning it** ([EPA *Slow Sand Filtration*, pp. 9–12](lib:optimization-of-slow-sand-filtration#page=9)):
- **Run it steadily, day and night;** change the flow by no more than half in a day and never switch it on and off,
  or the living layer starves of oxygen. Keep water above the sand. Below 41 °F (5 °C) filter more slowly, and don't
  clean it in winter.
- **Clean** when the water reaches the overflow or the flow falls too low: drain to a few inches below the sand, scrape
  off **half an inch or less** with flat shovels, and keep off the uncleaned parts (pp. 10–11). Re-sand before the bed
  is under **24 inches** (p. 11), usually in the second or third year ([IRC, p. 34](lib:slow-sand-filtration-for-community#page=34)).
- **Refill from the bottom,** then run it to waste **at least a day** (an hour for each hour it was off) until tests are
  good ([EPA, p. 12](lib:optimization-of-slow-sand-filtration#page=12)). A new bed takes **weeks to months** to ripen
  ([p. 7](lib:optimization-of-slow-sand-filtration#page=7)).
- **Never chlorinate before the filter:** it kills the living layer. Chlorinate what comes out
  ([WHO/WEDC, p. 46](lib:who-wedc-technical-notes#page=46)).

A homestead-sized filter is in the [Water Purification guide](guide:WATER-PURIFICATION-GUIDE).

### Chlorinating by hand
<!-- fold: Where to add it, how to make it up, a drip feeder from barrels, and testing the residual -->

Drops per gallon and the pool-shock stock solution are in "Step 3 — Kill the germs" in the
[Water Purification guide](guide:WATER-PURIFICATION-GUIDE). For a town tank:
- **Dose where the water has 30 minutes before the first tap,** as it enters the clear-water tank or a long main
  ([WHO/WEDC, p. 43](lib:who-wedc-technical-notes#page=43)).
- **Use bleach or calcium hypochlorite** (pool shock), not chlorine gas: pure chlorine is "difficult and dangerous to
  use" ([VITA, p. 133](lib:village-technology-handbook#page=133)). Make powder into a paste before adding it
  ([WHO/WEDC, p. 46](lib:who-wedc-technical-notes#page=46)). VITA's table gives amounts per 1,000 gallons: very clear
  water starts at 5 parts per million, slightly hazy water at 10 ([VITA, p. 134](lib:village-technology-handbook#page=134)).
- **A drip feeder with no power:** barrels on a shelf feed weak bleach and raw water side by side at the same steady
  pressure into the town's tank. Start with ½ pint of bleach in 50 gallons of water for each 500 gallons treated, and
  adjust until the tank water has a noticeable chlorine taste ([VITA, pp. 137–139](lib:village-technology-handbook#page=137);
  [🖼️ the barrels, p. 138](lib:village-technology-handbook#page=138)).

**Testing the residual** ([WHO/WEDC, pp. 44–45](lib:who-wedc-technical-notes#page=44); [🖼️ the steps drawn, p. 45](lib:who-wedc-technical-notes#page=45)):
a **DPD** tablet turns a sample red, and you match it against a color chart (stock tablets now *(rule of thumb)*).
Test where the chlorine goes in, at the nearest house and at the far ends of town; **daily** for a new or repaired
system, then **at least weekly**. With no kit, a faint chlorine smell after 30 minutes means enough was added
([Water Purification guide](guide:WATER-PURIFICATION-GUIDE)). **If the supply keeps going off, chlorinating the pipes is
pointless:** have people disinfect at home ([WHO/WEDC, p. 46](lib:who-wedc-technical-notes#page=46)), and keep scarce
chemicals for places like the hospital and schools ([p. 26](lib:who-wedc-technical-notes#page=26)).

### Finding and fixing leaks
<!-- fold: The six steps for a broken main: map, warn, other water, isolate, repair, test and disinfect -->

WHO's steps for a small town's broken pipes ([WHO/WEDC, pp. 15–18](lib:who-wedc-technical-notes#page=15)):
1. **Map the damage** with the staff who know the system and its drawings; walk the network and mark every break.
2. **Tell people** what is off, what you're doing and when, and how to stay safe.
3. **Give them other water** if repairs will take more than a few hours: tankers, and advice on local springs and wells for washing.
4. **Isolate the break** with the valves, so the rest of town keeps water. If the valves can't be found, fit new ones.
5. **Repair from the source outward,** 500–1,000 m (⅓–⅔ mile) between valves at a time, with repair clamps or a new pipe
   laid on the ground for now. Shore the trench, keep traffic away, and find other buried lines first
   ([🖼️ shoring, a clamp and backfill, p. 17](lib:who-wedc-technical-notes#page=17)).
6. **Test, flush and disinfect:** hold **1½ times normal pressure for 4 hours** and watch the joints; flush until clean;
   fill with water dosed at **80 g of calcium hypochlorite per 1,000 litres** (about 11 oz per 1,000 gallons
   *(arithmetic)*) for **24 hours**; flush until the strong chlorine smell is gone (pp. 17–18).

**Hidden leaks** *(rule of thumb)*: a wet or green strip in dry weather, water in a valve box, a hiss heard through a
steel rod on a valve at night, a tank that drops at night when nobody uses water. People help find leaks if you ask
([WHO/WEDC, p. 26](lib:who-wedc-technical-notes#page=26)).

### Protecting the source
<!-- fold: Keeping sewage, garbage, farms and people away from the water before it reaches the plant -->

Keeping the water clean is the cheapest treatment: manage excreta, garbage and storm runoff, control erosion and farm
runoff, and keep people out of the source; getting the town's sewage under control may matter more than repairing the
water plant ([WHO/WEDC, p. 24](lib:who-wedc-technical-notes#page=24); [🖼️ what to keep away, same page](lib:who-wedc-technical-notes#page=24)).
Walk the source regularly and check drainage, fences, latrines and garbage, and test any new source for arsenic and
fluoride as well as germs ([Sphere, pp. 135–136](lib:sphere-handbook-2018#page=135)). Latrines and graves stay 100 ft
from water ([Sanitation guide](guide:SANITATION-GUIDE)); fence the intake, filters and tanks and lock the hatches
*(rule of thumb)*.

### What to tell everyone
<!-- fold: Honest, regular news: what is off, what you are doing, when, and what people should do -->

Tell people **what is affected, what you are doing and when, and what they should do**, and keep the updates coming
([WHO/WEDC, p. 15](lib:who-wedc-technical-notes#page=15)); news eases worry, cuts waste and gets leaks reported
([p. 26](lib:who-wedc-technical-notes#page=26)). **Secrecy fails:** Montreal's silence didn't stop hoarding, and
boil-water warnings meant nothing to people with no way to boil
([EMP Commission, pp. 160–161](lib:emp-commission-critical-national-infrastructures#page=160)). A notice that works
*(rule of thumb)*: is the water **safe, boil, or off**; where the nearest safe water is; **don't flush** if the sewer is
down; when the next notice comes. Post it in the same places daily and send it by runner ("Runners, relays and written
messages" in the [Signals & Morse guide](guide:SIGNALS-MORSE-GUIDE)).

## 🚽 Sewers: from drain to river
<!-- fold: Gravity sewers and manholes, lift stations, the treatment plant, sludge, storm drains and combined sewers -->

### Gravity sewers, slope and manholes
<!-- fold: Why sewers slope, how deep they run, what manholes are for, and why they need water -->

A [sanitary sewer](wiki:Sanitary_sewer) is a branching network of pipes running downhill to the plant
([Compendium, pp. 92–93](lib:compendium-of-sanitation#page=92); [🖼️ drawn, p. 92](lib:compendium-of-sanitation#page=92)):
- **It slopes all the way,** fast enough to scour itself: about **2 ft (0.6–0.7 m) a second**. Where the slope can't be
  kept, a pumping station lifts the sewage. Main sewers lie **5–10 ft (1.5–3 m)** under the roads.
- **[Manholes](wiki:Manhole)** sit at set distances and at every junction and bend, for inspection and cleaning.
- **Sewers need water:** keeping that speed takes over **100 litres (26 gallons) a person a day**. With water rationed,
  solids settle and pipes block *(rule of thumb)*.
- **Grease, rags and grit block them;** crews rod, flush, jet and bail them. Sewers "can be dangerous because of toxic
  gases" and are work for trained crews (p. 93).

### Lift stations: when the pumps stop
<!-- fold: What a lift station is, and the backups and overflows when its power fails -->

A **lift station** ([pumping station](wiki:Pumping_station)) is a deep pit, the **wet well**, where sewage collects until
pumps lift it to a higher sewer ([Compendium, p. 92](lib:compendium-of-sanitation#page=92)). When its power fails, the
wet well and the sewers behind it fill, sewage comes up the **lowest drains first** (basement floor drains, low toilets
and showers), and then out of manholes into streets and creeks *(rule of thumb)*
([sewer overflow](wiki:Sanitary_sewer_overflow)). A generator or engine pump at each key lift station keeps the sewer
working *(rule of thumb)*. **Nobody goes down into the wet well** ("Deadly dangers", below).

### The treatment plant
<!-- fold: Screens, grit, settling, bacteria, lagoons, chlorine, and which need power -->

A plant cleans sewage in stages ([EMP Commission, p. 158](lib:emp-commission-critical-national-infrastructures#page=158);
[sewage treatment](wiki:Sewage_treatment)):

| Stage | What it does |
|---|---|
| **Screens and grit chambers** | Catch rags, sticks and sand that wreck pumps; automatic screens need power ([Compendium, pp. 100–101](lib:compendium-of-sanitation#page=100)) |
| **Primary settling** | Most solids sink as raw sludge, which goes to a digester |
| **Biological treatment** | Bacteria eat what is dissolved. **[Activated sludge](wiki:Activated_sludge)** blows air through tanks and needs **constant electricity and skilled staff**; its bacteria take weeks to grow back ([Compendium, pp. 126–127](lib:compendium-of-sanitation#page=126)). A **[trickling filter](wiki:Trickling_filter)** sprays settled sewage over stones coated in slime that eats it ([p. 114](lib:compendium-of-sanitation#page=114)) |
| **Final settling and disinfection** | The bacteria settle out; then chlorine, ultraviolet lamps, or sunlight in shallow ponds ([Compendium, pp. 128–129](lib:compendium-of-sanitation#page=128)) |

**Lagoons** ([waste stabilization ponds](wiki:Waste_stabilization_pond)) need **no electricity**: three or more ponds in a
row, a deep **anaerobic** pond (2–5 m, 1–7 days) that settles and digests the solids, a **facultative** pond (1–2.5 m,
5–30 days), and shallow **maturation** ponds (0.5–1.5 m) where sunlight kills germs. They cost little to run and take
sudden loads, but need a lot of land. Fence them, skim the scum, pull water plants that breed mosquitoes, and dig out
the first pond every 2–5 years, when it is a third full of sludge ([Compendium, pp. 110–111](lib:compendium-of-sanitation#page=110)).

**Cave Junction's sewage plant** treats and disinfects the town's wastewater to the limits in its discharge permit
([county plan, p. 108](lib:josephine-county-multi-jurisdictional#page=108)). It was on the county's list of places to
study for a solar-and-battery microgrid ([p. 288](lib:josephine-county-multi-jurisdictional#page=288)). The county
warns that sewage plants and lift stations stop when the power fails, with overflows, and that treatment plants often
sit low in floodplains ([p. 286](lib:josephine-county-multi-jurisdictional#page=286)); the city rates its chance of a
river flood as high ([p. 133](lib:josephine-county-multi-jurisdictional#page=133)).

### Sludge
<!-- fold: What sludge is, drying beds, and why it is never quite safe -->

**Sludge** is the solids a plant collects; raw sludge goes to a **digester**, where bacteria break it down without air
([EMP Commission, p. 158](lib:emp-commission-critical-national-infrastructures#page=158); [anaerobic digestion](wiki:Anaerobic_digestion)).
On **drying beds** of sand and gravel over drains, 50–80% of the liquid drains or dries off and the cake can be shoveled
out after 10–15 days; roof them in a wet climate. Dried sludge **is not safe yet**, and the water draining off needs
treating too ([Compendium, pp. 118–119](lib:compendium-of-sanitation#page=118)). "Even after treatment, sludge is rarely
pathogen-free": wear boots, gloves and a mask, and follow the rules on which crops may get it
([p. 139](lib:compendium-of-sanitation#page=139)); keep it off anything eaten raw *(rule of thumb)*.

### Storm drains and combined sewers
<!-- fold: The grates in the street go straight to the creek; old sewers that carry both overflow in rain -->

**[Storm drains](wiki:Storm_drain)** carry rain from the streets **straight to a river or lake**. No toilet may be
connected to one; clear them of trash before the rainy season ([Compendium, pp. 94–95](lib:compendium-of-sanitation#page=94)).
**[Combined sewers](wiki:Combined_sewer)** carry rain and sewage in one pipe and overflow on purpose in storms so the
plant isn't swamped; they are no longer thought good practice ([p. 93](lib:compendium-of-sanitation#page=93)). Rain gets into
separate sewers too, through manholes and cracked pipes (pp. 92–93), so a sewer near its limit backs up in heavy rain
*(rule of thumb)*.

## 🪠 When the town's sewer fails
<!-- fold: Stop flushing, keep sewage out of the house, and the move to bucket toilets and latrines -->

1. **Stop flushing,** even if your pipes look fine: the street's may be broken. A septic tank can keep working if
   nothing leaks or backs up ([OSU *Sanitation*, p. 5](lib:osu-extension-survival-basics-sanitation#page=5)).
2. **Keep sewage out of the house.** Plug the tub and sink drains ([OSU *Water*, p. 3](lib:osu-survival-basics-water#page=3)).
   Sewer pipes let water into a building unless they have backflow devices
   ([FEMA P-1019, p. 110](lib:emergency-power-systems-for-critical-facilities#page=110)). Plug basement floor drains with a
   rubber test plug, or a towel under a bag of sand; keep the cleanout capped; a **backwater valve** (a flap that lets
   sewage out but not back) is the lasting fix *(rule of thumb)*.
3. **Keep the traps wet** in drains still used for wash water, or sewer gas comes in *(rule of thumb)*.
4. **Switch to bucket toilets and latrines** at once, with handwashing by each; wash water to a soak pit
   ([Sanitation guide](guide:SANITATION-GUIDE)). **Never tip buckets into manholes or storm drains** *(rule of thumb)*.
5. **Treat sewage on the ground as an outbreak waiting to happen:** fence it off, cover it, keep children and animals
   away ("How germs spread, and stopping an outbreak" in the [Sanitation guide](guide:SANITATION-GUIDE)).

**After a Cascadia earthquake** the Oregon Resilience Plan expects that in many places it would take **a year** before
the sewers work again and **three years** for the main lines and plants. Meanwhile the rivers fill with raw sewage, the
water plants downstream struggle, and people turn to chemical toilets and latrines
([Resilience Plan, p. 238](lib:oregon-resilience-plan-full-report#page=238)).

## ☠️ Deadly dangers

### Manholes, wet wells, vaults and tanks: never go in

Sewers, wet wells, valve vaults, septic tanks and closed tanks can hold air that kills ([confined space](wiki:Confined_space);
[sewer gas](wiki:Sewer_gas)):
- **[Hydrogen sulfide](wiki:Hydrogen_sulfide)** smells of rotten eggs at low levels, but **the sense of smell quickly
  fails** at higher ones, and it causes "rapid incapacitation" ([NWCG *IRPG*, p. 42](lib:nwcg-incident-response-pocket-guide#page=42)).
  It paralyzes breathing: "Victims become unconscious and never regain consciousness." **Never use your nose to judge
  it** ([FM 10-67-1, p. 241](lib:fm-10-67-1#page=241)).
- **No oxygen:** rust in a long-closed tank uses it up (same page). Safe entry needs a meter reading of
  **19.5–23.5% oxygen** and no flammable gas ([UFM 3-460-03, p. 408](lib:ufm-3-460-03#page=408)).
- **Explosive gas:** a flame can set it off ([Hospital Corpsman, p. 128](lib:hospital-corpsman#page=128)); test before
  opening a manhole and use only gas-proof lights ([FM 5-424, p. 169](lib:us-army-fm-5-424#page=169)).

**People die going in to rescue someone:** "In a large number of accidents, the rescuer rushes in and becomes the
second victim." A wet cloth gives "no protection against poisonous gases or lack of oxygen," and a gas mask makes no
oxygen ([Hospital Corpsman, pp. 128, 130](lib:hospital-corpsman#page=128)).
- **Never enter.** Not for a minute, not for a tool, not for a person or a dog.
- **If someone collapses inside,** call for help and lower a rope, or a hose blowing fresh air *(rule of thumb)*. Only
  crews with gas meters, their own air, a harness and a lifeline tended from outside go in, and they follow the lifeline
  rather than drag the victim ([Hospital Corpsman, pp. 127–130](lib:hospital-corpsman#page=127)).
- **Keep lids on;** guard an open manhole with a flag by day and a barricade by night
  ([FM 5-424, pp. 169–170](lib:us-army-fm-5-424#page=169)). Septic tanks, pits and wells: the same rule.

### Chlorine

- **Breathing chlorine fumes must be avoided** ([WHO/WEDC, p. 43](lib:who-wedc-technical-notes#page=43)). Big plants
  use chlorine **gas** ([p. 25](lib:who-wedc-technical-notes#page=25)), which is hard to handle and store safely
  ([Compendium, p. 129](lib:compendium-of-sanitation#page=129); [chlorine gas poisoning](wiki:Chlorine_gas_poisoning)).
  If a chlorine room smells sharp or you see yellow-green gas, **get out uphill and upwind and stay out** *(rule of thumb)*.
- **Never mix bleach with ammonia, acids or urine:** it releases toxic chlorine gas, "especially in a confined space"
  ([WHO-PAHO, p. 76](lib:decontamination-and-reprocessing-of-medical-devices#page=76)).
- **Store pool shock** cool, dry and sealed, away from fuel, oil and anything that burns *(rule of thumb)*.

### Sewage, trenches and traffic

- **Sewage** spreads hepatitis, cholera and typhoid ([Hesperian Ch 7, p. 15](lib:building-toilets#page=15)); disposing of
  it properly is one of the most important ways to stop them ([Hospital Corpsman, p. 335](lib:hospital-corpsman#page=335)).
  Wear boots, gloves and protective clothing ([Compendium, pp. 101, 119](lib:compendium-of-sanitation#page=101)), cover
  cuts, and wash before eating *(rule of thumb)*.
- **Trench walls fall without warning** *(rule of thumb)*. Shore loose ground ([WHO/WEDC, p. 17](lib:who-wedc-technical-notes#page=17);
  [trench shoring](wiki:Trench_shoring)), cut the sides of any trench **deeper than 5 ft back at about 45°**
  ([DOE *Microhydropower Handbook*, p. 107](lib:doe-microhydropower-handbook-vol-1-part-2#page=107)), pile the dirt well
  back from the edge ([Peace Corps *Wells*, p. 53](lib:wells-construction-hand-dug#page=53)), find other buried lines
  first ([WHO/WEDC, p. 17](lib:who-wedc-technical-notes#page=17)), and never dig alone *(rule of thumb)*.
- **Traffic:** route it away from the work ([WHO/WEDC, p. 17](lib:who-wedc-technical-notes#page=17)), put out cones and
  wear an orange vest ([EPA *Sumps*, p. 5](lib:inspecting-and-maintaining-sumps#page=5)), and post a flagger
  ([FM 5-424, p. 169](lib:us-army-fm-5-424#page=169)).

## 📋 Who runs it, and the records to get now
<!-- fold: The operators' know-how, the maps and valve lists, and why a neighborhood should ask for them now -->

**The people matter as much as the pipes.** Repairs start with the local staff who know the system and its drawings
([WHO/WEDC, p. 15](lib:who-wedc-technical-notes#page=15)). Operators may not fully understand the treatment process, so find
the engineers too, and pay them if their pay has stopped ([p. 23](lib:who-wedc-technical-notes#page=23)). Computer control has cut
staff below what long running by hand would take ([EMP Commission, p. 159](lib:emp-commission-critical-national-infrastructures#page=159)).

**Records to ask for now, on paper** *(rule of thumb)*:
- **System map:** mains and sizes, tanks, pumps, pressure zones, hydrants and washouts.
- **Valve list:** where each valve is, its size, turns to close, which way it turns, and what it shuts off. It turns
  hours of searching into minutes.
- **Sewer map:** manholes, depths and lift stations, to know where sewage will back up.
- **Power needs** of each pump and plant, and the generator hookups.
- **Chemicals:** stock and suppliers of alum, chlorine and test tablets, which run out first.
- **The plant's operating steps,** so someone else can run it.

**Why ask now:** in a disaster the staff may be busy, hurt or gone, and the maps on a computer with no power *(rule of
thumb)*. If the utility keeps full maps private for security, ask for the valves on your own streets, or for an operator
to walk them with you *(rule of thumb)*. Know your house valve and curb box ([Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23))
and put the valves on the neighborhood map ("Skills, tools and the neighborhood map" in the [Community guide](guide:COMMUNITY-BARTER-GUIDE)).

**Who to ask here:** the City of Cave Junction runs both the water plant and the sewage plant
([county plan, p. 108](lib:josephine-county-multi-jurisdictional#page=108)). Its *Water Master Plan* (2013) and *Water
Distribution Master Plan* hold the maps and the maintenance plans, and the master plan includes steps for conserving
and rationing water ([pp. 128–129](lib:josephine-county-multi-jurisdictional#page=128)). Ask City Hall for copies, and
for the valves on your street.

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| "To determine the presence of harmful gases, a lighted candle or small bird should be lowered into the well" ([USDA FB 1448, p. 20](lib:farmstead-water-supply#page=20)); test a tank "by burning a candle on the bottom" ([*Bluejackets' Manual*, p. 215](lib:bluejackets-manual#page=215)) | A flame says nothing about hydrogen sulfide, which kills at levels far too low to put a candle out *(rule of thumb)*, and it can set off gas ([Hospital Corpsman, p. 128](lib:hospital-corpsman#page=128)). Use a gas meter, or don't go in |
| "To rescue an unconscious person in a place filled with gas, move quickly and carry him out without breathing yourself"; "less gas will be found near the floor" ([*Boy Scouts Handbook* 1911, p. 288](lib:boy-scouts-handbook-for-boys#page=288)) | That is how rescuers die ([Hospital Corpsman, p. 128](lib:hospital-corpsman#page=128)); deadly gases are "just as likely" near the floor ([p. 129](lib:hospital-corpsman#page=129)). Call for help and work from outside |
| Oxygen: "A concentration of less than 7 percent is dangerous" ([FM 10-67-1, p. 241](lib:fm-10-67-1#page=241)) | Under **19.5%** is unsafe to enter without your own air ([UFM 3-460-03, p. 408](lib:ufm-3-460-03#page=408); [*Ship's Medicine Chest*, p. 197](lib:ships-medicine-chest#page=197)) |
| Carry the drainpipes "to any running stream where the water is not afterwards used" ([*Household Discoveries*, p. 103](lib:household-discoveries#page=103)) | Someone downstream always uses it ([Hesperian Ch 7, p. 15](lib:building-toilets#page=15)). Treat sewage, or use latrines 100 ft from water ([Sanitation guide](guide:SANITATION-GUIDE)) |
| Test chlorine with "orthotolidine" ([VITA, p. 135](lib:village-technology-handbook#page=135)) | Use DPD tablets and a comparator ([WHO/WEDC, p. 44](lib:who-wedc-technical-notes#page=44)) |

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; the other links are photos in the offline Wikipedia.

**Town water**
- A whole plant, intake to storage, and rebuilding one in stages — [🖼️ WHO/WEDC, pp. 25–26](lib:who-wedc-technical-notes#page=25); what to keep away from the source — [🖼️ p. 24](lib:who-wedc-technical-notes#page=24); [Water treatment](wiki:Water_treatment); [Clarifier](wiki:Clarifier)
- Drawing water through a riverbed, and a filter fed that way — [🖼️ IRC, p. 21](lib:slow-sand-filtration-for-community#page=21); [🖼️ p. 42](lib:slow-sand-filtration-for-community#page=42); [Infiltration gallery](wiki:Infiltration_gallery)
- Slow sand filters with all their valves, and village plants with plans — [🖼️ IRC, pp. 32–33](lib:slow-sand-filtration-for-community#page=32); [🖼️ pp. 93–100](lib:slow-sand-filtration-for-community#page=93); [Slow sand filter](wiki:Slow_sand_filter); [Schmutzdecke](wiki:Schmutzdecke)
- A barrel drip chlorinator, and a settling basin with a sand filter — [🖼️ VITA, p. 138](lib:village-technology-handbook#page=138); [🖼️ p. 141](lib:village-technology-handbook#page=141); testing chlorine with a comparator — [🖼️ WHO/WEDC, p. 45](lib:who-wedc-technical-notes#page=45); [Water chlorination](wiki:Water_chlorination)
- A town's mains with valves, washouts and hydrants, the damage marked — [🖼️ WHO/WEDC, p. 16](lib:who-wedc-technical-notes#page=16); shoring, a pipe clamp, backfill — [🖼️ p. 17](lib:who-wedc-technical-notes#page=17); the house water valve — [🖼️ Map Your Neighborhood, p. 23](lib:map-your-neighborhood-discussion-guide#page=23); [Water tower](wiki:Water_tower); [Fire hydrant](wiki:Fire_hydrant); [Backflow prevention device](wiki:Backflow_prevention_device)

**Sewers and treatment**
- A gravity sewer and manhole, a shallow "simplified" sewer, storm drains — [🖼️ Compendium, p. 92](lib:compendium-of-sanitation#page=92); [🖼️ p. 90](lib:compendium-of-sanitation#page=90); [🖼️ p. 94](lib:compendium-of-sanitation#page=94); [Sanitary sewer](wiki:Sanitary_sewer); [Manhole](wiki:Manhole); [Combined sewer](wiki:Combined_sewer)
- Screens and grit removal; lagoons in series — [🖼️ Compendium, p. 100](lib:compendium-of-sanitation#page=100); [🖼️ p. 110](lib:compendium-of-sanitation#page=110); [Waste stabilization pond](wiki:Waste_stabilization_pond)
- A trickling filter, activated sludge, a chlorine contact tank, drying beds — [🖼️ Compendium, pp. 114, 126, 128, 118](lib:compendium-of-sanitation#page=114); [Activated sludge](wiki:Activated_sludge); [Sewage treatment](wiki:Sewage_treatment)

**Safety**
- A rescue lifeline — [🖼️ Hospital Corpsman, p. 128](lib:hospital-corpsman#page=128); guarding an open manhole at night — [🖼️ FM 5-424, p. 170](lib:us-army-fm-5-424#page=170); [Confined space](wiki:Confined_space); [Hydrogen sulfide](wiki:Hydrogen_sulfide)
- Tanks, pipes and plants broken by other great earthquakes — [🖼️ Resilience Plan, pp. 230–238](lib:oregon-resilience-plan-full-report#page=230); Cave Junction's water service area and pipes — [🖼️ county plan, p. 128](lib:josephine-county-multi-jurisdictional#page=128)

---

## 🔗 Related guides

- [Water Wells](guide:WATER-WELLS-GUIDE) and [Water Purification](guide:WATER-PURIFICATION-GUIDE) — one household's water, pumping into storage, boiling and bleach
- [Sanitation](guide:SANITATION-GUIDE) — septic tanks with no power, latrines, bucket toilets, stopping an outbreak
- [Dams, Weirs, Ditches & Ponds](guide:DAMS-DITCHES-GUIDE) — holding and leading water
- [How the Power Grid Works](guide:POWER-GRID-GUIDE) — why the power, and so the pumps, can be out for weeks
- [Engines, Motors and Generators](guide:ENGINES-AND-MOTORS-GUIDE) and [Fuel](guide:FUEL-GUIDE) — running pumps on a generator
- [Floods, Ice Storms & Heat Waves](guide:FLOODS-STORMS-HEAT-GUIDE) — flooded wells and septic tanks, frozen pipes
- [Community & Barter](guide:COMMUNITY-BARTER-GUIDE) — a neighborhood group and its map
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — local contacts and maps
