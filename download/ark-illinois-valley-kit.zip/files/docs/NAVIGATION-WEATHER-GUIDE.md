# 🧭 Navigation & Weather Without GPS or Forecasts

How to find your way in the hills around the Illinois Valley with a paper map and compass — or
with neither — and how to read the weather coming when there is no forecast: map reading,
declination, pace count, terrain association, finding yourself when lost, the sun and stars,
clouds and wind, our local weather from valley fog to east-wind fire days, lightning, and a home
weather log. The books are in `Navigation-Weather\Land-Navigation` and `Navigation-Weather\Weather`;
the local topo maps are in `Maps\Topo-USGS` and `Maps\Forest-Service` (see the Maps section of the
[Illinois Valley guide](guide:ILLINOIS-VALLEY-START-HERE)).

> ### ⚠️ Rules that prevent the worst outcomes
> - **Set your compass to 14° East.** Older maps print bigger numbers; always use the newest.
>   Ignoring declination puts you about a quarter mile off for every mile you walk.
> - **Leave a written trip plan** with someone who stays home. With no search and rescue, nobody
>   comes unless someone knows your route and your return time
>   ([NPS Trip Plan](lib:nps-sample-trip-plan#page=1)).
> - **When you hear thunder, move:** off peaks and ridges, away from taller trees, and **out of rock
>   overhangs and cave mouths**. Wait 30 minutes after the last thunder
>   ([Backcountry Lightning, pp. 1–2](lib:backcountry-lightning#page=1)).
> - **Never cross fast water.** Six inches can knock you off your feet; two feet carries away most
>   vehicles ([Spotter Guide, p. 12](lib:weather-spotters-field-guide#page=12)).
> - **A dry east wind after a front in late summer or fall is extreme fire weather** — the pattern
>   behind the September 2020 fires. Be ready to leave.
> - **Sun, watch, moon and moss methods are rough.** Check any no-compass direction with a second
>   method before you commit to a long walk.

---

## 🗺️ Reading a topo map

**Scale.** The library's local quads (US Topo and FSTopo) are **1:24,000: 1 inch = 2,000 ft**
([🖼️ using the bar scale](lib:fm-3-25-26-map-reading#page=46); [Topographic map](wiki:Topographic_map)). On the
1:100,000 Forest Service sheet, 1 inch is about 1.6 miles. Map distance is "as the crow flies";
walking a steep slope is farther ([USGS FS 035-01, p. 1](lib:finding-your-way-with-map-and-compass#page=1);
[PMS 475, p. 133](lib:basic-land-navigation-pms-475#page=133)).

**Contour lines** ([FS 035-01, p. 1](lib:finding-your-way-with-map-and-compass#page=1);
[PMS 475, pp. 41–42](lib:basic-land-navigation-pms-475#page=41); [Contour line](wiki:Contour_line);
[🖼️ a contour map beside the land it shows](lib:basic-land-navigation-pms-475#page=40); [🖼️ FM 3-25.26, p. 107](lib:fm-3-25-26-map-reading#page=107)):
- Brown lines join points of **equal height**; the heavier, labeled ones are index contours.
- **Close together = steep. Far apart = gentle.** Circles inside circles = a hilltop.
- **V-shaped bends point uphill and upstream** — creeks and draws.
- **U-shaped bends point down a ridge** — spurs and ridge ends.

![A drawing of hills, a cliff and a bay seen from the side, and below it the same land drawn as a contour map](img:NAVIGATION-WEATHER-GUIDE/contour-map-and-the-land.png)
*The same land as a picture (top) and as contour lines (bottom): the lines almost touch at the cliffs and spread far apart on level ground ([PMS 475, p. 40](lib:basic-land-navigation-pms-475#page=40)).*

**Name the land.** Learn to spot these on the map and on the ground — it is the heart of navigating
without GPS ([FM 3-25.26, pp. 115–118](lib:fm-3-25-26-map-reading#page=115)):

| Feature | On the map | On the ground |
|---|---|---|
| **Hill** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=116)) | Closed rings | Ground falls away on all sides |
| **[Saddle](wiki:Saddle_(landform))** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=116)) | Hourglass between two hills | Low dip between two high points |
| **[Valley](wiki:Valley)** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=117)) | V or U contours with a stream | Low ground between ridges |
| **[Ridge](wiki:Ridge)** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=117)) | Long line of high ground | Ground falls away on three sides |
| **Depression** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=117)) | Ring with tick marks inside | A hollow |
| **Draw** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=118)) | Small V pointing uphill | Small gully |
| **[Spur](wiki:Spur_(topography))** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=118)) | Small U pointing downhill | Finger of high ground off a ridge |
| **[Cliff](wiki:Cliff)** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=119)) | Contours touching or merged | Near-vertical drop |

**Symbols:** [US Topo Map Symbols (2023)](lib:us-topo-map-symbols-usgs-2023) matches the library's
GeoPDF maps; the older [USGS symbol booklet](lib:topographic-map-symbols-usgs-2005) matches older
quads and FSTopo.

**Grid position.** The valley is in **UTM Zone 10** ("10T" on the quads). Grid lines are every
1,000 m. Read **right first (easting), then up (northing)**
([USGS FS 077-01, pp. 1–2](lib:the-universal-transverse-mercator#page=1); [🖼️ grid lines](lib:fm-3-25-26-map-reading#page=33); [🖼️ reading a UTM coordinate](lib:basic-land-navigation-pms-475#page=71);
[UTM](wiki:Universal_Transverse_Mercator_coordinate_system)).

📚 **Go deeper:** [FM 3-25.26](lib:fm-3-25-26-map-reading#page=115) — the Army's full map-reading course; [PMS 475](lib:basic-land-navigation-pms-475#page=41) — firefighter workbook with exercises; [FSTopo Cave Junction](lib:fstopo-cave-junction-or-2025) — practice on your home sheet.

## 🧭 Compass and declination

**Use 14° East for the Illinois Valley.** NOAA's model gives 13.9° E for Cave Junction in November
2026, shrinking about 0.1° a year. The [FSTopo Cave Junction sheet](lib:fstopo-cave-junction-or-2025#page=1)
prints 14°8′ (2024) and the [US Topo sheet](lib:usgs-topo-cave-junction-or-2023#page=1) 14°18′
(2023). Older maps print larger numbers — **use the newest value**. See
[Magnetic declination](wiki:Magnetic_declination).

**Which way to correct** ([FS 035-01, p. 2](lib:finding-your-way-with-map-and-compass#page=2);
[PMS 475, p. 86](lib:basic-land-navigation-pms-475#page=86)):
- Here the magnetic north (MN) arrow sits to the **right** (east) of true north ([🖼️ north arrow on a quad](lib:basic-land-navigation-pms-475#page=35);
  [🖼️ declination diagrams](lib:fm-3-25-26-map-reading#page=62)).
- **Map → compass: subtract 14°.** A map bearing of 90° becomes 76° on an unadjusted compass.
- **Compass → map: add 14°.**
- Memory aid: "declination east, compass least."
- **Easiest:** set the compass's declination screw to 14° E once and forget it.

![Diagram: true north points straight up and magnetic north 14 degrees to its right; map to compass subtract 14, compass to map add 14](img:NAVIGATION-WEATHER-GUIDE/declination-14-east.svg)
*Here the compass needle points 14° east of true north: subtract 14° going from map to compass, add 14° going back (a diagram drawn for this guide).*

**Why it matters:** 1° of error puts you about **920 ft off in 10 miles**
([PMS 475, p. 86](lib:basic-land-navigation-pms-475#page=86)). Ignoring all 14° puts you about
**1,300 ft off for every mile** *(general practice: worked out from the angle)*.

**Grid north** on the Cave Junction quad is only about half a degree from true north — ignore it on
foot. That's why the margin shows three norths
([FM 3-25.26, p. 62](lib:fm-3-25-26-map-reading#page=62); [🖼️ three norths](lib:fm-3-25-26-map-reading#page=57)).

**The way back (back azimuth):** add 180° if the bearing is 180° or less; subtract 180° if more. A
slip here can be disastrous — **check it twice** ([FM 3-25.26, p. 58](lib:fm-3-25-26-map-reading#page=58); [🖼️ direct and back bearing](lib:basic-land-navigation-pms-475#page=90)).

**[Compass](wiki:Compass) habits** ([PMS 475, p. 84](lib:basic-land-navigation-pms-475#page=84);
[FM 3-25.26, p. 97](lib:fm-3-25-26-map-reading#page=97); [🖼️ parts of a compass](lib:basic-land-navigation-pms-475#page=83)):
- Hold it **level at waist height** ([🖼️ centerhold](lib:fm-3-25-26-map-reading#page=98)), take every bearing **twice**, and walk where the
  direction-of-travel arrow points, not where your hunch says ([🖼️ following a bearing](lib:basic-land-navigation-pms-475#page=92)).
- **Keep away from metal:** 55 m (180 ft) from high-voltage lines, 18 m (60 ft) from a truck, 10 m
  (33 ft) from barbed wire or phone lines, half a meter from a rifle. Belt buckles and clipboards
  throw it off too.

📚 **Go deeper:** [USGS *Finding Your Way*](lib:finding-your-way-with-map-and-compass#page=2) — taking a bearing off a topo map; [PMS 475, pp. 82–86](lib:basic-land-navigation-pms-475#page=82) — parts of a compass and setting declination.

## 👣 Pace count: measuring distance on foot

([FM 3-25.26, pp. 52–53](lib:fm-3-25-26-map-reading#page=52); [PMS 475, pp. 133–134](lib:basic-land-navigation-pms-475#page=133))
1. **Measure a 100 m (328 ft) course** on ground like where you'll travel — a road shoulder with a
   tape or a measured fence line works *(rule of thumb)*.
2. **Walk it naturally and count your steps.** The Army's example is about 120 steps per 100 m.
   Walk it several times and average.
3. **Expect more steps** ([🖼️ why the ground is longer than the map](lib:basic-land-navigation-pms-475#page=133)) uphill, into a headwind, in mud, sand, snow or brush, in rain, and in fog or
   darkness.
4. **Keep a separate, shorter night count** ([p. 141](lib:fm-3-25-26-map-reading#page=141)).
5. **Don't try to remember the count.** Move a pebble from one pocket to the other, or tie a knot,
   every 100 m ([pace count beads](wiki:Pace_count_beads)).

⚠️ The Forest Service (NWCG) counts a "pace" as **two** steps — every time the same foot lands. The
Army counts every step. **Pick one and never mix them.**

📚 **Go deeper:** [PMS 475, p. 133](lib:basic-land-navigation-pms-475#page=133) — pacing worksheet; [FM 3-25.26, p. 52](lib:fm-3-25-26-map-reading#page=52) — pace count and other ways to measure distance.

## 🏞️ Terrain association: handrails, catching features, aiming off

**Match the map to the ground as you go** ([🖼️ drawing](lib:fm-3-25-26-map-reading#page=130)). It is far more forgiving than walking a compass line,
because you keep comparing what you expected to see with what you do see. Pure compass walking piles
up errors with every detour ([FM 3-25.26, pp. 131, 139](lib:fm-3-25-26-map-reading#page=131)).
Keep the map turned so its north matches the land ([p. 140](lib:fm-3-25-26-map-reading#page=140); [🖼️ by the land](lib:basic-land-navigation-pms-475#page=112);
[🖼️ by compass](lib:basic-land-navigation-pms-475#page=113)).

**Plan a route this way** ([FM 3-25.26, p. 140](lib:fm-3-25-26-map-reading#page=140)):
- **Handrail:** a line you follow without careful compass work — a road, stream, ridge or power line.
  Ours include **Hwy 199**, the **Illinois River** and its **East and West Forks**, the **Caves
  Highway (OR 46)**, and numbered Forest Service roads on the FSTopo sheets *(local: rule of thumb)*.
- **Catching feature:** something across your path that tells you you've gone too far.
- **Attack point:** a sure landmark no more than about 500 m from the goal. From there, walk an exact
  bearing and pace count.

**Aim off on purpose** ([FM 3-25.26, p. 100](lib:fm-3-25-26-map-reading#page=100); [🖼️ deliberate offset](lib:fm-3-25-26-map-reading#page=101)). Heading for a
spot on a road or creek, aim about **10° to one side**. When you hit the road, you know which way to
turn. Each degree moves you about 18 m sideways per 1,000 m walked, so 10° is about 180 m.

![Diagram seen from above: instead of walking straight at a spot on a road, walk a bearing about 10 degrees to one side, then turn along the road toward the goal](img:NAVIGATION-WEATHER-GUIDE/aiming-off.svg)
*Aim to one side of the spot on purpose; when you reach the road you know which way to turn (a diagram drawn for this guide).*

📚 **Go deeper:** [FM 3-25.26, ch. 11](lib:fm-3-25-26-map-reading#page=126) — terrain association in depth; [MVUM Wild Rivers](lib:usfs-mvum-wild-rivers-ranger-district-2019) — which forest roads are real roads.

## 📍 Finding yourself on the map (resection)

**Resection** ([FM 3-25.26, p. 68](lib:fm-3-25-26-map-reading#page=68);
[Position resection](wiki:Position_resection_and_intersection); [🖼️ drawing](lib:fm-3-25-26-map-reading#page=69); [🖼️ PMS 475, p. 131](lib:basic-land-navigation-pms-475#page=131)):
1. Orient the map.
2. Take compass bearings to **two or three landmarks** you can name on the map.
3. Turn each into a map bearing (**add 14°**, unless your compass is already set), then into its
   **back azimuth** (±180°).
4. Draw each line back from its landmark. **Where they cross is you.** Three lines make a small
   triangle — you are inside it.

![Map diagram: lines drawn back from three named peaks cross in a small triangle where you are standing](img:NAVIGATION-WEATHER-GUIDE/resection.svg)
*Resection: back bearings drawn from two or three peaks you can name cross where you stand (a diagram drawn for this guide).*

Local candidates are peaks on the FSTopo sheets such as **Grayback Mountain, Kerby Peak and Eight
Dollar Mountain** — check on the sheet which you can really see from where you stand *(rule of
thumb)*.

**Modified resection** ([p. 70](lib:fm-3-25-26-map-reading#page=70); [🖼️ drawing](lib:fm-3-25-26-map-reading#page=71)): if you know you're on a road,
river or ridgeline, **one** bearing to one landmark is enough. You are where that line crosses your
road or ridge.

📚 **Go deeper:** [FM 3-25.26, pp. 68–70](lib:fm-3-25-26-map-reading#page=68) — intersection, resection and modified resection with drawings; [PMS 475, p. 131](lib:basic-land-navigation-pms-475#page=131) — finding your own position by triangulation; [AFH 10-644, p. 406](lib:afh-10-644#page=406) — azimuth, biangulation and triangulation.

## ☀️ Direction without a compass — and how wrong each can be

| Method | How | How far off |
|---|---|---|
| **Shadow stick** | Push a 3-ft stick into level ground and mark the shadow tip. Wait 10–15 min and mark it again. The line runs **west → east; the first mark is always west**. First mark on your left = you face north. Works by bright moonlight too. | Gives an *approximate* east–west line ([FM 21-76, pp. 231–232](lib:fm-21-76-army-survival-manual#page=231); [FM 3-25.26, pp. 102, 141](lib:fm-3-25-26-map-reading#page=102); [🖼️ drawing](lib:fm-3-25-26-map-reading#page=101)) |
| **Watch** | Point the hour hand at the sun. **South is halfway between the hour hand and 12** (halfway to **1** on daylight time). | The Army warns it can be in error and **cause circling** — recheck with a shadow stick after an hour ([FM 3-25.26, pp. 102–103](lib:fm-3-25-26-map-reading#page=102); [🖼️ drawing](lib:fm-3-05-70-survival-2002#page=311)). Here the sun is due south about **12:15 PST / 1:15 PDT**, give or take up to 16 minutes by season *(computed)* |
| **Sunrise / sunset** | The sun rises **due east only in March and September** ([🖼️ drawing](lib:afh-10-644#page=410)). | At our latitude, sunrise is about **32° north of east in late June** and **32° south of east in late December** *(computed)* |
| **North Star** ([Polaris](wiki:Polaris)) | Follow the two "pointer" stars at the end of the [Big Dipper](wiki:Big_Dipper)'s cup about **five times their spacing** ([🖼️ Big Dipper and Cassiopeia](lib:fm-3-05-70-survival-2002#page=313); [🖼️ northern constellations](lib:fm-3-25-26-map-reading#page=104); [Cassiopeia](wiki:Cassiopeia_(constellation))). | Within **1°** of true north — the best no-compass method. Here it sits about 42° up, a bit under halfway up the northern sky ([FM 3-25.26, p. 103](lib:fm-3-25-26-map-reading#page=103); [FM 21-76, p. 234](lib:fm-21-76-army-survival-manual#page=234)) |
| **Moon** ([phases](wiki:Lunar_phase)) | Rises before sunset: lit side faces **west**. Rises after midnight: lit side faces **east**. | Rough east–west only ([FM 21-76, p. 233](lib:fm-21-76-army-survival-manual#page=233)) |
| **Moss** | — | **Not a compass** — moss can grow all the way around a tree ([FM 21-76, p. 235](lib:fm-21-76-army-survival-manual#page=235)) |

![Three drawings of the shadow-stick method: mark the tip of a stick's shadow, mark it again later and draw a line through both marks, then stand with the first mark on your left to face north](img:NAVIGATION-WEATHER-GUIDE/shadow-tip-method.png)
*Shadow stick: mark the tip, wait 10–15 minutes, mark it again; with the first mark on your left and the second on your right, you face north ([FM 3-05.70, p. 310](lib:fm-3-05-70-survival-2002#page=310)).*

![Night sky drawing: lines from the Big Dipper and from Cassiopeia both lead to Polaris, the North Star; an arrow from Polaris down to the horizon marks north](img:NAVIGATION-WEATHER-GUIDE/north-star-from-big-dipper-and-cassiopeia.png)
*Polaris lies off the end of the Big Dipper's cup, on the far side from Cassiopeia's "W"; straight below it is true north ([FM 3-05.70, p. 313](lib:fm-3-05-70-survival-2002#page=313)).*

**Use Polaris to check your compass** on a clear night: it should read about 346° on an unadjusted
compass, or 0° once declination is set *(worked from 14° E)*. The noon sun stands about 71° high in
June but only about 24° in December, so winter shadows are long *(computed for 42° N)*.

📚 **Go deeper:** [FM 21-76, pp. 231–235](lib:fm-21-76-army-survival-manual#page=231) — sun, moon and stars with drawings; [FM 3-25.26, pp. 102–103](lib:fm-3-25-26-map-reading#page=102) — field-expedient direction finding.

## 🆘 Getting un-lost

**STOP: Stop, Think, Observe, Plan** ([*Today's Hunter*, p. 80](lib:todays-hunter-in-new-york#page=80)):
1. **Stop.** Admit you're turned around. Sit down.
2. **Think.** Retrace your route in your head: the last place you were *sure* of, and what you've
   passed since.
3. **Observe.** Look for the five terrain features, a peak you can name, the sound of a road or the
   river. Try a resection.
4. **Plan.** Pick the nearest big handrail on the map (a road or river) and walk a bearing to it,
   **aiming off** so you know which way to turn when you reach it.

- **If you can't get back before dark,** stop early and spend the effort on shelter, warmth and a
  signal ([p. 80](lib:todays-hunter-in-new-york#page=80); [Signals guide](guide:SIGNALS-MORSE-GUIDE)).
- **Staying put only works if someone will come.** That page assumes searchers in "a few days." Now
  it works only if someone at home has your trip plan.
- **Never shelter under a rock overhang in a thunderstorm** — lightning arcs across the gap.

**Trip plan before every trip into the hills** ([NPS Trip Plan, pp. 1–2](lib:nps-sample-trip-plan#page=1)):
who is going, the route, start and return times, a backup plan, the vehicle and the
gear. Leave it with someone who isn't going, **check in when you're back**, and agree that they act
at the deadline.

📚 **Go deeper:** [NPS Trip Plan form](lib:nps-sample-trip-plan#page=1) — print a stack; [*Today's Hunter*, pp. 80–84](lib:todays-hunter-in-new-york#page=80) — shelter, fire, signals, cold and heat.

## ☁️ Reading the sky: clouds, wind and barometer

**Clouds that warn** ([AH 360, pp. 163–164](lib:fire-weather-agriculture-handbook-360#page=163);
[Cloudwise poster](lib:cloudwise-ten-basic-clouds-poster-nws-2019#page=1);
[Sky Watcher chart](lib:sky-watcher-cloud-chart#page=1); [List of cloud types](wiki:List_of_cloud_types)):

| You see | It often means |
|---|---|
| High, thin wisps ([cirrus](wiki:Cirrus_cloud), [🖼️ photo](lib:aviation-weather-ac-00-6b#page=125)) thickening to a milky veil ([cirrostratus](wiki:Cirrostratus_cloud), [🖼️ photo](lib:aviation-weather-ac-00-6b#page=127)) | A warm front and rain coming; from the southwest in spring/summer, often 24–48 hours ahead at Roseburg ([Garriott, p. 137](lib:weather-folk-lore#page=137)) |
| Rows of small, high puffs ([cirrocumulus](wiki:Cirrocumulus_cloud), [🖼️ photo](lib:aviation-weather-ac-00-6b#page=126)) from the south or southwest in fall/winter | Rain in 12–24 hours (same page) |
| Turreted, castle-top clouds (castellanus) in the morning | Thunderstorms that afternoon |
| Smooth, lens-shaped clouds over the ridges ([lenticular](wiki:Lenticular_cloud), [🖼️ photo](lib:aviation-weather-ac-00-6b#page=129)) | Strong winds aloft |
| Towering cumulus growing into an anvil ([cumulonimbus](wiki:Cumulonimbus_cloud), [🖼️ photo](lib:aviation-weather-ac-00-6b#page=138)) | Thunderstorm, lightning, a gusty "[gust front](wiki:Outflow_boundary)" that can arrive before the rain ([AC 00-6B, pp. 167–168](lib:aviation-weather-ac-00-6b#page=167)) |
| Low gray layer with steady rain ([nimbostratus](wiki:Nimbostratus_cloud), [🖼️ photo](lib:aviation-weather-ac-00-6b#page=131)) | Steady rain or snow |

Rain falls mainly from cumulus, cumulonimbus and nimbostratus. A thunderstorm cell lives about 30
minutes ([🖼️ life cycle](lib:aviation-weather-ac-00-6b#page=168)), but its gust front can set off new ones ([AC 00-6B, pp. 167–168](lib:aviation-weather-ac-00-6b#page=167)).

**Wind signs:**
- **Roseburg (nearest station in the 1903 Weather Bureau study):** in spring and summer, rain follows
  **southwest winds and a falling barometer by 12–24 hours**; in winter, southerly winds by about 12
  hours ([Garriott, p. 137](lib:weather-folk-lore#page=137)).
- **Portland, Oregon:** wind turning from northwest through northeast to southeast means rain; a
  shift to **northwest means clearing** ([p. 131](lib:weather-folk-lore#page=131)).
- **[Cold front](wiki:Cold_front)** ([🖼️ cold and warm fronts](lib:aviation-weather-ac-00-6b#page=100)): wind from the south or southwest before it, then an **abrupt shift to west,
  northwest or north** ([AH 360, p. 101](lib:fire-weather-agriculture-handbook-360#page=101)).
- **Back to the wind, low pressure is on your left and a little ahead**
  ([AH 360, p. 84](lib:fire-weather-agriculture-handbook-360#page=84)).
- ⚠️ Valley winds are bent by the hills. Judge by **cloud movement or ridgetop wind**.

**[Barometer](wiki:Barometer):** watch the **trend**, not the number. A drop of more than about 0.06 inch in 3 hours
means change is coming; about 0.18 inch or more in 3 hours means a strong storm *(general
practice)*. The old Roseburg rule "rain after the barometer falls to 29.90" uses sea-level readings;
at our ~1,300 ft an unadjusted barometer reads about 1.3–1.4 inches lower *(general practice)*.

**Sayings that hold up (somewhat):** "Evening red and morning gray…" ([Red sky at morning](wiki:Red_sky_at_morning); [🖼️ photo](lib:afh-10-644#page=104)) has a basis, because weather
mostly moves west to east ([Garriott, p. 18](lib:weather-folk-lore#page=18)). Hard, greasy, ragged
clouds mean wind ([*Shifts and Expedients*, p. 183](lib:shifts-and-expedients#page=183)). Forecasts
weeks ahead from the moon, almanacs or animals "can not stand the test of verification"
([Garriott, p. 35](lib:weather-folk-lore#page=35)).

📚 **Go deeper:** [Garriott 1903](lib:weather-folk-lore#page=137) — station-by-station signs for Roseburg, Portland and Eureka; [Sky Watcher chart](lib:sky-watcher-cloud-chart#page=1) — photos of 27 cloud types; [AH 360](lib:fire-weather-agriculture-handbook-360#page=163) — clouds, fronts and mountain winds.

## 🌦️ Illinois Valley weather through the year

**The baseline** ([NRCS soil survey, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)):
winter averages 40°F at Cave Junction (record low −6°F, December 1972), with about 24 inches of
snow a season in that older record (NOAA's 1991–2020 normal is only about 7 inches); summer
averages 67°F, and Grants Pass has hit 108°F. Only about 15% of the rain falls
April to September, and summer afternoon humidity runs 25–30%. It cools 3–5°F for every 1,000 ft you
climb, and above about 4,500 ft it can freeze in any month. Most winters bring one or two damaging
windstorms; every few years a continental air mass from the east brings days well below freezing in
winter, or a sweltering week in summer.

**Valley fog and inversions** ([AH 360, p. 35](lib:fire-weather-agriculture-handbook-360#page=35);
[AC 00-6B, p. 146](lib:aviation-weather-ac-00-6b#page=146);
[EPA Smoke Guide, p. 26](lib:epa-wildfire-smoke-guide-2026#page=26); [Inversion](wiki:Inversion_(meteorology))):
- On clear, calm nights cold air drains off the slopes ([🖼️ drawing](lib:aviation-weather-ac-00-6b#page=95)) and pools on the valley floor, deepening until
  about midnight. [Fog](wiki:Fog) forms if the air is moist ([🖼️ radiation fog](lib:aviation-weather-ac-00-6b#page=145)).
- Fog is common the morning after rain then clearing, and usually burns off by noon unless cloud
  moves in above it.
- In winter an inversion can trap fog and **woodstove smoke** for days ([🖼️ smoke under an inversion](lib:afh-10-644#page=105)). Burn hot and dry
  ([Firewood guide](guide:FIREWOOD-GUIDE)).

**[Frost](wiki:Frost)** ([Garriott, p. 137](lib:weather-folk-lore#page=137); [AH 360, p. 35](lib:fire-weather-agriculture-handbook-360#page=35)):
heavy frost follows a **high or rising barometer, evening temperature at 40°F or below, clearing sky
and light wind**. Frost hits low spots first. The **mid-slope "thermal belt" stays warmest at night**
— the best spot for tender crops, and also where wildfires stay active all night.

**Winter storms off the Pacific** ([NRCS, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5);
[Spotter Guide, p. 12](lib:weather-spotters-field-guide#page=12)): warm storms carrying a long plume of
subtropical moisture (an [atmospheric river](wiki:Atmospheric_river)) bring several inches of rain a
day, high snow levels and fast-rising rivers *(general practice)*. Cave Junction got **8.12 inches in
one day** on 22 December 1964. Stay off low crossings and out of creeks when they rise.

**Summer thunderstorms** are most frequent over the mountains
([NRCS, p. 5](lib:nrcs-soil-survey-of-josephine-county-oregon-1983-text-edition#page=5)). In fire
season, watch the ridges for smoke for a day or two after lightning *(rule of thumb)*.

**Heat:** in a hot spell, take regular breaks in shade and drink often; do heavy work in the cool
morning *(rule of thumb)*. [Heat exhaustion](wiki:Heat_exhaustion) — heavy sweat, pale clammy skin, dizziness, nausea —
means shade, rest, water and cool wet cloths.
**Confusion or collapse is [heat stroke](wiki:Heat_stroke), a life-threatening emergency** — cool them fast
([ATP 4-02.11, pp. 188–189](lib:atp-4-02-11#page=188); [Field care guide](guide:FIELD-CARE-GUIDE)).

**East wind = fire weather** ([AH 360, p. 211](lib:fire-weather-agriculture-handbook-360#page=211);
[NWS Medford, pp. 14–15](lib:southern-oregon-climate-summary#page=14); [Foehn wind](wiki:Foehn_wind)):
in late summer and fall, after a cold front, high pressure inland can send **strong, dry north-to-east
winds** downslope, warming and drying as they come. On 7–9 September 2020, Medford's humidity fell to
about 7% and Slater Butte (4,600 ft, near where the [Slater Fire](wiki:Slater_fire) started south of Takilma and O'Brien)
recorded gusts of 55–60 mph. **Warning signs:** very clear air, warm dry nights, and east wind on the
ridges after a front. Pack the car and watch for smoke. Another nearby east-wind fire: the
[Chetco Bar Fire](wiki:Chetco_Bar_Fire).

**Smoke:** inversions hold smoke in the valley at night. With no air-quality reports, judge smoke by
**how far you can see** ([EPA Smoke Guide, pp. 95–96](lib:epa-wildfire-smoke-guide-2026#page=95)) —
in daylight, not at sunrise or sunset, only when humidity is under 65%, looking at dark landmarks at
known distances:

| Farthest dark landmark you can see | Healthy adults | Children, elders, pregnant, heart or lung disease |
|---|---|---|
| **More than 10 miles** | Watch for changes | Watch; shorten activity if you feel it |
| **5–10 miles** | Shorten and ease outdoor work | Minimize or avoid outdoor activity |
| **Under 5 miles** | Minimize or avoid outdoor activity | Stay indoors in cleaner air |

📚 **Go deeper:** [AH 360](lib:fire-weather-agriculture-handbook-360#page=35) — inversions, slope winds, east winds; [NWS Medford Sept 2020](lib:southern-oregon-climate-summary#page=14) — the Labor Day east wind, hour by hour; [EPA Smoke Guide, p. 61](lib:epa-wildfire-smoke-guide-2026#page=61) — a cleaner-air room.

## ⚡ Lightning safety

([Backcountry Lightning, pp. 1–2](lib:backcountry-lightning#page=1);
[NWS Lightning brochure, p. 2](lib:lightning-safety-for-you#page=2);
[Spotter Guide, p. 13](lib:weather-spotters-field-guide#page=13))
- **If you can hear thunder, [lightning](wiki:Lightning) is within about 10 miles.** Start moving to shelter then.
- **Flash to bang:** count the seconds and divide by 5 for miles. Don't stake your life on it.
- **Stay sheltered 30 minutes after the last thunder.** People are struck going out too soon.
- **Ground current is the big danger, not a direct strike:** about half of casualties come from
  current spreading through the ground; direct strikes cause only 3–5% of deaths.
- **Caught outside:** get off peaks and ridges, away from taller trees, out of overhangs and cave
  mouths ([🖼️ safer and riskier terrain](lib:backcountry-lightning#page=2)). **Spread a group 20 ft apart**, so one strike can't hurt everyone. Crouch with **feet
  together** ([🖼️ the lightning position](lib:backcountry-lightning#page=2)).
- **A struck person carries no charge.** Start CPR or rescue breathing right away
  ([Field care guide](guide:FIELD-CARE-GUIDE)).
- The US averages about 300 people struck and about 30 killed a year.
- At home: unplug radios and ground antennas ([Radio guide](guide:RADIO-GUIDE)).

📚 **Go deeper:** [Backcountry Lightning](lib:backcountry-lightning#page=1) — picking terrain, group spacing, the lightning position; [NWS brochure](lib:lightning-safety-for-you#page=2) — family rules and first aid.

## 📓 A simple home weather log

With no forecasts, your own notes teach you the local signs. Read the same things at the **same
times every day**, say 7 am and 5 pm *(rule of thumb)*:

| Date | Time | Temp °F | Barometer (3-hr change) | Wind from (clouds / ridgetop) | Clouds | Rain (in) | Farthest landmark seen | Notes: fog, frost, thunder, smoke |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

- **[Rain gauge](wiki:Rain_gauge):** a straight-sided can on a post in the open; measure the depth with a ruler and empty
  it *(rule of thumb)*.
- **Visibility landmarks:** pick three dark ridges or peaks and measure their distance on the topo
  map — one near 5 miles, one near 10, one farther — for the smoke table above *(rule of thumb)*.
- **Frost dates:** record the first and last frost each year for the garden
  ([Seed bank guide](guide:SEED-BANK-GUIDE)).
- **After a year,** compare your notes with Garriott's Roseburg signs and write down the ones that
  work at your place.

📚 **Go deeper:** [Garriott 1903](lib:weather-folk-lore#page=18) — which sayings hold up and why; [Cloudwise poster](lib:cloudwise-ten-basic-clouds-poster-nws-2019#page=1) — print and post next to the log.

## ⚠️ Old advice in the library to ignore

| Book and page | What it says | Do this instead |
|---|---|---|
| [ODFW *Today's Hunter* instructor guide, p. 37](lib:odfw-todays-hunter-in-oregon-instructor-guide-2007#page=37) | Magnetic north is "in the Hudson Bay area" | Long out of date — it is now near the geographic pole, on the Siberian side *(general practice)*. Use the declination printed on the newest map: **14° E**. |
| Any older local map | Larger declination numbers | Use 14° E (2024–2026 value). |
| [FM 21-76, p. 235](lib:fm-21-76-army-survival-manual#page=235) | Tree rings are wider on the south side | Don't rely on it — ring width depends mostly on slope, lean and crowding *(general practice)*. |
| [*Today's Hunter* (NY), p. 80](lib:todays-hunter-in-new-york#page=80) | Shelter under a rock overhang; you'll be "found in a few days" | Never use an overhang in a thunderstorm. No one is coming unless someone has your trip plan. |
| [FEMA *Are You Ready?* 2004, p. 75](lib:fema-are-you-ready-citizen-preparedness-guide-2004#page=75) | 80 lightning deaths a year | Out of date: about 30 a year now ([NWS, p. 2](lib:lightning-safety-for-you#page=2)). |
| [Garriott 1903, p. 27](lib:weather-folk-lore#page=27) | "Three foggy mornings indicate rain (Oregon)" | Often fails here in winter, when valley fog sits under high pressure for days with no rain. |
| [Garriott 1903, p. 137](lib:weather-folk-lore#page=137) | Rain when the barometer reaches 29.90 | Sea-level readings. Watch the 3-hour trend on your own barometer. |
| [AH 360 (1970)](lib:fire-weather-agriculture-handbook-360) | Fire-control procedures | Predates satellites and modern fire-danger ratings. Weather science sound; fire tactics are history. |
| [FM 3-25.26, p. 102](lib:fm-3-25-26-map-reading#page=102) / [FM 21-76, p. 233](lib:fm-21-76-army-survival-manual#page=233) | Watch method for direction | Rough; can make you walk in circles. Check with a shadow stick or the North Star. |

📚 **Go deeper:** [FM 3-25.26, ch. 6](lib:fm-3-25-26-map-reading#page=56) — current Army methods for direction and declination; [NWS lightning brochure](lib:lightning-safety-for-you#page=2) — up-to-date lightning facts.

---

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Reading the map**
- Contour lines beside the land they show — [🖼️ PMS 475, p. 40](lib:basic-land-navigation-pms-475#page=40); [🖼️ FM 3-25.26, p. 107](lib:fm-3-25-26-map-reading#page=107); [Contour line](wiki:Contour_line)
- Hill, saddle, valley, ridge, depression, draw, spur, cliff — [🖼️ FM 3-25.26, pp. 116–119](lib:fm-3-25-26-map-reading#page=116); [🖼️ all together, p. 120](lib:fm-3-25-26-map-reading#page=120); [🖼️ AFH 10-644, pp. 393–396](lib:afh-10-644#page=393)
- Bar scale and measuring distance on the map — [🖼️ FM 3-25.26, p. 46](lib:fm-3-25-26-map-reading#page=46); [🖼️ p. 47](lib:fm-3-25-26-map-reading#page=47)
- UTM grid lines and coordinates — [🖼️ FM 3-25.26, p. 33](lib:fm-3-25-26-map-reading#page=33); [🖼️ PMS 475, pp. 70–71](lib:basic-land-navigation-pms-475#page=70); [UTM](wiki:Universal_Transverse_Mercator_coordinate_system)
- What a topo map looks like — [🖼️ PMS 475, p. 14](lib:basic-land-navigation-pms-475#page=14); [Topographic map](wiki:Topographic_map)

**Compass and declination**
- Parts of a compass — [🖼️ PMS 475, p. 83](lib:basic-land-navigation-pms-475#page=83); [🖼️ lensatic compass, FM 3-25.26 p. 96](lib:fm-3-25-26-map-reading#page=96); [Compass](wiki:Compass)
- Three norths and the declination diagram — [🖼️ FM 3-25.26, p. 57](lib:fm-3-25-26-map-reading#page=57); [🖼️ p. 62](lib:fm-3-25-26-map-reading#page=62); [🖼️ PMS 475, p. 35](lib:basic-land-navigation-pms-475#page=35); [Magnetic declination](wiki:Magnetic_declination)
- Taking, following and reversing a bearing — [🖼️ PMS 475, p. 89](lib:basic-land-navigation-pms-475#page=89); [🖼️ p. 90](lib:basic-land-navigation-pms-475#page=90); [🖼️ p. 92](lib:basic-land-navigation-pms-475#page=92); [🖼️ back azimuth, FM 3-25.26 p. 58](lib:fm-3-25-26-map-reading#page=58)
- Holding the compass — [🖼️ FM 3-25.26, p. 98](lib:fm-3-25-26-map-reading#page=98); [🖼️ AFH 10-644, p. 421](lib:afh-10-644#page=421)
- Orienting the map — [🖼️ PMS 475, p. 112](lib:basic-land-navigation-pms-475#page=112); [🖼️ p. 113](lib:basic-land-navigation-pms-475#page=113)

**Finding your way and finding yourself**
- Why the ground is longer than the map — [🖼️ PMS 475, p. 133](lib:basic-land-navigation-pms-475#page=133); [Pace count beads](wiki:Pace_count_beads)
- Terrain association — [🖼️ FM 3-25.26, p. 130](lib:fm-3-25-26-map-reading#page=130); [🖼️ p. 139](lib:fm-3-25-26-map-reading#page=139)
- Aiming off and going around obstacles — [🖼️ FM 3-25.26, p. 101](lib:fm-3-25-26-map-reading#page=101); [🖼️ p. 100](lib:fm-3-25-26-map-reading#page=100); [Orienteering](wiki:Orienteering)
- Intersection, resection and modified resection — [🖼️ FM 3-25.26, p. 67](lib:fm-3-25-26-map-reading#page=67); [🖼️ p. 69](lib:fm-3-25-26-map-reading#page=69); [🖼️ p. 71](lib:fm-3-25-26-map-reading#page=71); [🖼️ PMS 475, p. 131](lib:basic-land-navigation-pms-475#page=131)

**Direction without a compass**
- Shadow-tip method — [🖼️ FM 3-25.26, p. 101](lib:fm-3-25-26-map-reading#page=101); [🖼️ FM 3-05.70, p. 310](lib:fm-3-05-70-survival-2002#page=310); [🖼️ AFH 10-644, p. 403](lib:afh-10-644#page=403)
- Watch method (rough) — [🖼️ FM 3-25.26, p. 102](lib:fm-3-25-26-map-reading#page=102); [🖼️ FM 3-05.70, p. 311](lib:fm-3-05-70-survival-2002#page=311)
- The North Star from the Big Dipper and Cassiopeia — [🖼️ FM 3-05.70, p. 313](lib:fm-3-05-70-survival-2002#page=313); [🖼️ FM 3-25.26, p. 103](lib:fm-3-25-26-map-reading#page=103); [🖼️ TC 21-3, p. 55](lib:tc-21-3-soldiers-handbook#page=55); [Polaris](wiki:Polaris); [Big Dipper](wiki:Big_Dipper)
- Northern constellations — [🖼️ FM 3-25.26, p. 104](lib:fm-3-25-26-map-reading#page=104); [Cassiopeia](wiki:Cassiopeia_(constellation))
- Rising and setting sun — [🖼️ AFH 10-644, p. 410](lib:afh-10-644#page=410)
- Moon phases — [Lunar phase](wiki:Lunar_phase)

**Clouds, fronts and wind**
- The ten basic clouds — [🖼️ Cloudwise poster](lib:cloudwise-ten-basic-clouds-poster-nws-2019#page=1); [🖼️ Sky Watcher chart](lib:sky-watcher-cloud-chart#page=1); [🖼️ FM 3-05.70, pp. 651–654](lib:fm-3-05-70-survival-2002#page=651); [List of cloud types](wiki:List_of_cloud_types)
- Cirrus, cirrocumulus and cirrostratus — [🖼️ AC 00-6B, pp. 125–127](lib:aviation-weather-ac-00-6b#page=125); [Cirrus cloud](wiki:Cirrus_cloud)
- Lenticular clouds and mountain waves — [🖼️ AC 00-6B, p. 129](lib:aviation-weather-ac-00-6b#page=129); [🖼️ p. 158](lib:aviation-weather-ac-00-6b#page=158); [Lenticular cloud](wiki:Lenticular_cloud)
- Towering cumulus and cumulonimbus — [🖼️ AC 00-6B, p. 133](lib:aviation-weather-ac-00-6b#page=133); [🖼️ p. 138](lib:aviation-weather-ac-00-6b#page=138); [🖼️ AFH 10-644, p. 102](lib:afh-10-644#page=102); [Cumulonimbus cloud](wiki:Cumulonimbus_cloud)
- Cold and warm fronts — [🖼️ AC 00-6B, p. 100](lib:aviation-weather-ac-00-6b#page=100); [Weather front](wiki:Weather_front)
- Red sky — [🖼️ AFH 10-644, p. 104](lib:afh-10-644#page=104); [Red sky at morning](wiki:Red_sky_at_morning)

**Local weather and lightning**
- Cold air sliding downhill at night; radiation fog — [🖼️ AC 00-6B, p. 95](lib:aviation-weather-ac-00-6b#page=95); [🖼️ p. 145](lib:aviation-weather-ac-00-6b#page=145); [Fog](wiki:Fog)
- Smoke trapped under an inversion — [🖼️ AFH 10-644, p. 105](lib:afh-10-644#page=105); [Inversion](wiki:Inversion_(meteorology))
- East wind and fire — [Foehn wind](wiki:Foehn_wind); [Slater Fire](wiki:Slater_fire); [Chetco Bar Fire](wiki:Chetco_Bar_Fire)
- Atmospheric river storms — [Atmospheric river](wiki:Atmospheric_river)
- Thunderstorm life cycle — [🖼️ AC 00-6B, p. 168](lib:aviation-weather-ac-00-6b#page=168); [🖼️ AFH 10-644, p. 98](lib:afh-10-644#page=98); [Thunderstorm](wiki:Thunderstorm)
- The lightning position and safer terrain — [🖼️ Backcountry Lightning, p. 2](lib:backcountry-lightning#page=2); [Lightning](wiki:Lightning)

## 🔗 Related guides

- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — which topo map covers what, evacuation levels, walking routes out
- [Signals, Morse & Messages](guide:SIGNALS-MORSE-GUIDE) — signaling when lost, ground-to-air symbols, signal-fire danger
- [Radio guide](guide:RADIO-GUIDE) — NOAA weather radio frequencies and the SAME code
- [Shelter building](guide:SHELTER-BUILDING-GUIDE) — a night out when you can't get home
- [Field care guide](guide:FIELD-CARE-GUIDE) — lightning strikes, heat illness, cold and injuries far from help
- [Bicycles and carts](guide:BICYCLES-CARTS-GUIDE) — traveling the roads and handrails in this guide
- [Seed bank guide](guide:SEED-BANK-GUIDE) — frost dates and the thermal belt for planting
- [On Foot: backpacking and travel](guide:ON-FOOT-GUIDE) — how much to carry, packs, feet and blisters, water and food on the move, camps, river crossings and safety on the road.
