# 🎒 On Foot: Backpacking and Travel When the Roads Are Empty

With no fuel and no car, walking is how a household reaches Grants Pass, the coast, family or a trade. This guide
covers planning, loads and packs, feet, water and food on the move, camp, wildlife, cold rivers, snowy passes and
staying safe on the road. Miles, travel days and route files are in other guides, and this one links to them. Its new
books are in `Southern-Oregon\Travel-On-Foot`: the Army's *Military Mountaineering* (TC 3-97.61, 2025) and *Foot
Marches* (ATP 3-21.18, 2017), Horace Kephart's *Camping and Woodcraft* (1916, two volumes), ODF's fire-season rules,
OSU's poison-oak bulletin and a National Park Service trip planner. The older *Foot Marches* (FM 21-18) and Knapik's
*Load Carriage* are in `Southern-Oregon\Bicycles-Carts\Trailers-Carts`; the Air Force survival handbook (AFH 10-644,
the whole book despite "Signaling" in its file name) is in `Southern-Oregon\Comms-Signals\Visual-Sound-Signals`.

> ### The short version
> - **Cold rivers kill.** Wade alone only where it is **knee-deep or less** and the current mild
>   ([TC 3-97.61, p. 345](lib:tc-3-97-61#page=345)). **Unbuckle hip and chest straps** first
>   ([p. 344](lib:tc-3-97-61#page=344)), **never tie yourself to a rope**, and "if in doubt, turn back or wait for help"
>   ([NPS North Cascades, p. 1](lib:nps-north-cascades#page=1)). Oregon rivers stay "dangerously cold" in warm weather
>   ([OSMB, p. 17](lib:osmb-experience-oregon-boating#page=17)).
> - **Feet first.** Cover a hot spot the minute you feel it ([Knapik, p. 49](lib:load-carriage-in-military-operations#page=49));
>   change socks at noon and never "walk them dry" ([Kephart Vol. 2, pp. 144–145](lib:kephart-camping-and-woodcraft-vol-2#page=144)).
> - **Carry less:** plan family loads on **10–20 kg (22–44 lb)** ([World Bank, p. 65](lib:improving-rural-mobility#page=65)).
> - **Plan by time, not miles:** about **15 miles a day** on roads (what the walking-routes tool assumes), plus
>   **an hour per 1,000 ft of climb** ([FM 3-97.6, p. 72](lib:fm-3-97-6-mountain-operations#page=72)). Late December has only about **9 hours** of
>   daylight *(arithmetic)*.
> - **Water:** **2–4 quarts** a day when cool, **4–8** in the mountains, never over **1¼ quarts an hour**
>   ([NY hunter manual, p. 81](lib:todays-hunter-in-new-york#page=81); [FM 3-97.6, p. 17](lib:fm-3-97-6-mountain-operations#page=17);
>   [FM 21-10, p. 56](lib:us-army-fm-21-10#page=56)). Treat every drop.
> - **No fires in fire season.** ODF's 2026 rules ban "campfires, cooking fires and warming fires" from **May 15**
>   ([ODF closure, p. 1](lib:odf-southwest-oregon#page=1)). Eat cold, or use a stove in a cleared spot.
> - **Leave a written plan; turn back early.** Leaving "a safe shelter to travel in adverse weather conditions is
>   foolhardy" ([AFH, p. 427](lib:afh-10-644#page=427)). And "Travelling alone is dangerous" ([p. 426](lib:afh-10-644#page=426)).

---

## 🗺️ Planning a trip

### Distance, hills and daylight

- **Miles and days from Cave Junction** are in "Travel times from Cave Junction" in the
  [Bicycles & Carts guide](guide:BICYCLES-CARTS-GUIDE) and "Walking out" in the [Start Here guide](guide:ILLINOIS-VALLEY-START-HERE);
  print directions and maps from `Walking-Routes\WALKING-ROUTES.html`. All assume **15 miles a day** with a pack.
- **Hills:** the Bicycles guide has the Army rule (a third more distance, an hour per 1,000 ft up). Checks: 800 ft of
  climb an hour "is good work", and "If you cannot talk without catching your breath ... you are going too fast"
  ([Kephart Vol. 2, p. 146](lib:kephart-camping-and-woodcraft-vol-2#page=146)); distances are "reduced by half over average
  gradients of 10 percent" ([🖼️ FM 21-18, p. 66](lib:fm-21-18-foot-marches#page=66)).
- **The first days are hardest:** stiff legs on day two; poor sleep, constipation and sore feet by day three
  ([Kephart Vol. 2, pp. 142–143](lib:kephart-camping-and-woodcraft-vol-2#page=142)).
  Make the first days 8–10 miles *(rule of thumb)*.
- **Daylight at Cave Junction** *(arithmetic, 42° N)*: about **9 hours** on December 21, 10 in mid-November and late
  January, 12 at the equinoxes, 15¼ on June 21. A 15-mile day takes 7½–8 hours with rests, so plan **10–12 miles** in
  midwinter. Start looking for camp "at least two hours before sunset" ([Kephart Vol. 1, p. 212](lib:kephart-camping-and-woodcraft-vol-1#page=212)).
- **Season:** snow can fall in any month above 5,000 ft, and flash floods run "many miles downstream" of the rain
  ([FM 3-97.6, p. 15](lib:fm-3-97-6-mountain-operations#page=15)). Late spring and early fall are usually easiest *(rule
  of thumb)*; check "Reading fire danger with no forecast" in the [Wildfire guide](guide:WILDFIRE-GUIDE).

### Choosing a route

Where there are no bridges, "keep away from streams and follow the ridges between them"
([Kephart Vol. 2, pp. 49–50](lib:kephart-camping-and-woodcraft-vol-2#page=49)), and "Travel on trails rather than taking
shortcuts through the brush" ([AFH, p. 446](lib:afh-10-644#page=446)). The library's back-road routes climb high Forest
Service roads, such as Grayback Road (FR 4611) toward Grants Pass and Medford and Sanger Peak Road (FR 4803) toward
Crescent City; US-199 stays lower. The route files give no heights, so read each climb off a topo map *(rule of thumb)*
("Reading a topo map" in the [Navigation guide](guide:NAVIGATION-WEATHER-GUIDE)). No book on the drive gives camping
limits on public land; the Forest Service has long allowed about 14 days in one spot *(rule of thumb)*.

### The plan you leave behind, and when to turn back

Leave a note "stating departure time, destination, route of travel, personal condition, and available supplies", and
carry "sufficient water to reach the next probable water source" ([AFH, p. 427](lib:afh-10-644#page=427)). The NPS
trip-plan form is in "Getting un-lost" in the Navigation guide. **Turn-around rules** to write on the plan *(rule of thumb)*:
1. A **turn-around time**: if you aren't at the pass, ford or planned camp by then, go back.
2. A river above the knee, or rising: "Not every river or stream can be crossed safely" ([TC 3-97.61, p. 351](lib:tc-3-97-61#page=351)).
3. Snow above the knee on a pass and no snowshoes; smoke or a fire column ahead; a hot east wind in fire season.
4. Water down to half with no sure source ahead; someone hurt, sick or limping; a checkpoint that says no.

### Caches

"Bears will demolish any such pile [of stones] that one man could build." Hang the bundle from a peeled pole between two
trees **15–20 ft** up, trees "too slender for a bear to climb, yet too stout for him to shake"
([Kephart Vol. 2, p. 233](lib:kephart-camping-and-woodcraft-vol-2#page=233)). Hide damp-proof things under an old,
half-buried log, away from camp so one raid or fire doesn't take both ([p. 236](lib:kephart-camping-and-woodcraft-vol-2#page=236)).
Dried food needs a "completely waterproof" container ([AFH, p. 369](lib:afh-10-644#page=369)).

## ⚖️ How much to carry

| Who and where | Load | Source |
|---|---|---|
| Everyday carrying | **10–20 kg (22–44 lb)**; 50 kg only "for short distances" | [World Bank, p. 65](lib:improving-rural-mobility#page=65) |
| Middle-aged, soft from office work | about **20 lb** | [Kephart Vol. 2, p. 102](lib:kephart-camping-and-woodcraft-vol-2#page=102) |
| Younger or active adult | **30 lb**, more once in training | same page |
| Strong and fit, trackless mountains | **50 lb** "without over-exertion" | same page |
| Kephart's summer kit with 2 days' food | **23 lb 2 oz** | [p. 108](lib:kephart-camping-and-woodcraft-vol-2#page=108) |
| A week alone in the fall | **40–50 lb** at the start | [p. 147](lib:kephart-camping-and-woodcraft-vol-2#page=147) |
| Soldier, British rule of 1920 | 18–20 kg or **⅓ of body weight** | [Knapik, p. 17](lib:load-carriage-in-military-operations#page=17) |
| Fit soldiers, 8-hour march (a ceiling) | **45% of body weight** | [FM 21-18, p. 79](lib:fm-21-18-foot-marches#page=79) |
| Steep ground above 5,000 ft | cut by **nearly 50%** | [FM 3-97.6, p. 102](lib:fm-3-97-6-mountain-operations#page=102) |

**This guide follows the World Bank and Kephart figures,** which fit ordinary people; the Army numbers are ceilings for
fit young soldiers. Each 10 lb over 40 lb cuts about **2 km** off six hours' march ([🖼️ FM 21-18, p. 66](lib:fm-21-18-foot-marches#page=66)).
"Find out what is light and easy for you, and then GO LIGHT" ([Kephart Vol. 2, p. 102](lib:kephart-camping-and-woodcraft-vol-2#page=102)).
Water weighs **2.2 lb a liter** *(arithmetic)*. To get fit, add load or distance, "but not at the same time"
([FM 21-18, p. 80](lib:fm-21-18-foot-marches#page=80)).

**Children, elders and the injured:**
- **The slowest walker sets the pace** ([AFH, p. 428](lib:afh-10-644#page=428)). For children, "avoid long distances" and
  keep "a good easy pace, say two or three miles an hour" ([Boy Scouts 1911, p. 173](lib:boy-scouts-handbook-for-boys#page=173)).
- No book on the drive gives loads for children or older people. Start a child at about a tenth of body weight and a
  frail adult at 10–15 lb, and adjust by day two *(rule of thumb)*. Past frostbite or trench foot makes it likelier
  again ([FM 21-18, p. 106](lib:fm-21-18-foot-marches#page=106)).
- **Carrying someone:** two poles through a blanket, jackets or sacks; with no poles, roll a blanket in from both sides
  and grip the rolls ([FM 4-25.11, pp. 211–212](lib:fm-4-25-11-first-aid#page=211)). Use four carriers who swap often
  *(rule of thumb)*. To fetch help, "Send two people if possible" ([AFH, p. 426](lib:afh-10-644#page=426)).
- **Animals, carts, sleds:** "Travel and packing" in the [Horse guide](guide:HORSE-GUIDE); donkeys of 100–110 kg "regularly
  carry loads of 25-50 kg over distances of up to 20 km" ([Starkey, p. 82](lib:harnessing-and-implements-for-animal-traction#page=82)).
  Handcarts and travois are in the Bicycles guide. "Sleds should be used when heavy loads must be carried over
  snow-covered terrain" ([TC 3-97.61, p. 156](lib:tc-3-97-61#page=156)).

## 🚶 Pace, rests and walking technique

**The day's rhythm.** On roads this guide follows FM 21-18; on steep trails and in cold, the newer books' shorter stops.
1. Start in fewer layers, a little chilly ([AFH, p. 428](lib:afh-10-644#page=428)); stop to fix laces, straps and layers
   in the first half hour ([ATP 3-21.18, p. 25](lib:atp-3-21-18#page=25)).
2. **On roads:** rest 15 minutes after the first 45, then 10 in every hour, feet up ([FM 21-18, p. 48](lib:fm-21-18-foot-marches#page=48)).
3. **On steep trails and in cold:** "shorter breaks taken more often are better ... especially in colder weather"
   ([TC 3-97.61, p. 109](lib:tc-3-97-61#page=109)); "Long halts eat up daylight; they stiffen the muscles; and they cause
   chills" ([Kephart Vol. 2, p. 142](lib:kephart-camping-and-woodcraft-vol-2#page=142)). Lean the pack on a tree or bank.
4. **At any long stop, put on a layer:** "It is much easier to keep a warm body warm" ([ATP, p. 25](lib:atp-3-21-18#page=25)).
5. **Halfway:** a 15-minute stop in which everyone changes socks ([FM 21-18, p. 91](lib:fm-21-18-foot-marches#page=91)).

- **Uphill:** slow and steady, zigzagging rather than charging straight up ([TC 3-97.61, p. 107](lib:tc-3-97-61#page=107)).
  The **rest step**: pause on the straight rear leg, "so the bone, not muscle, supports the weight"
  ([ATP, p. 25](lib:atp-3-21-18#page=25); [🖼️ TC 3-97.61, p. 108](lib:tc-3-97-61#page=108)).
- **Downhill:** bend the knees; "Even one pole can be very helpful". Go straight down scree in short shuffling steps,
  heels dug in; never walk below someone on a loose slope ([TC 3-97.61, p. 109](lib:tc-3-97-61#page=109)).
- **Heat:** don't march "at the hottest time of day" ([FM 21-18, p. 61](lib:fm-21-18-foot-marches#page=61)); 3½ mph with 40 lb
  or more is "hard work" ([FM 21-10, p. 57](lib:us-army-fm-21-10#page=57)). Heat illness: "Heat and cold in the Valley" in
  the [Field Care guide](guide:FIELD-CARE-GUIDE). Drop no wrappers; they tell others who passed ([FM 21-18, p. 84](lib:fm-21-18-foot-marches#page=84)).

![Six drawings of a walker doing the rest step uphill: step up, pause with the rear leg straight and locked, then step again; the lower row with an ice axe as a stick](img:ON-FOOT-GUIDE/rest-step.png)
*The rest step: after each step, pause on the straight rear leg so bone, not muscle, holds the weight; lower row, the same with a stick or ice axe ([TC 3-97.61, p. 108](lib:tc-3-97-61#page=108)).*

## 🎒 Packs: fitting, loading, making and mending

### Fitting and loading a pack

- **The hips carry the load:** "A waistband will support 80 to 90 percent of the weight" cinched "around the pelvic
  girdle" ([AFH, p. 454](lib:afh-10-644#page=454)); in one test a frame and wide hip belt cut shoulder pressure from 203
  to 15 mm Hg ([Knapik, p. 31](lib:load-carriage-in-military-operations#page=31)).
- **Heavy things close to your back,** balanced side to side; **high on easy ground, lower on rough ground** ("low or
  midway"); rain gear and first aid on top ([AFH, p. 453](lib:afh-10-644#page=453); [TC 3-97.61, p. 156](lib:tc-3-97-61#page=156)).
- **Nothing dangling:** "flip-flops" and "stick-outs" snag in brush and can throw you off a log bridge; the best pack is
  one roomy sack holding everything ([Kephart Vol. 2, p. 126](lib:kephart-camping-and-woodcraft-vol-2#page=126)).
- **Adjust at every rest** ([AFH, p. 450](lib:afh-10-644#page=450)). Numb, tingling arms ("rucksack palsy"): move the straps
  or use a frame and hip belt ([Knapik, p. 47](lib:load-carriage-in-military-operations#page=47)). Lift a heavy packboard by
  sitting against it and rolling to your knees; never drop it ([Packboard, p. 1](lib:use-of-the-packboard#page=1)).

### Packs you can make

| Pack | How | Good and bad | Source |
|---|---|---|---|
| **Blanket roll** | Tarp under, blanket on top, gear in two even piles at the ends; roll, tie, join the ends; over one shoulder | "no help from the hips"; "suitable only for a day's hike and a one-night camp" | [Kephart Vol. 2, pp. 122–123](lib:kephart-camping-and-woodcraft-vol-2#page=122) |
| **Horseshoe pack** | Gear along one edge of a 5 × 5-ft square, hard things padded; roll, tie, join the ends | Quick on and off; switch shoulders | [AFH, pp. 451–452](lib:afh-10-644#page=451) |
| **Square pack** | 5 × 5-ft tarp, sleeping bag S-folded in the middle, hard things near the top; trucker's and jam hitches | Rides on the back, stays dry | [AFH, pp. 450–451](lib:afh-10-644#page=450) |
| **Simple rucksack** | Square bag with a drawstring; straps from the neck loop to wooden balls sewn in the bottom corners | Light, quick to sew | [Shifts, pp. 730–731](lib:shifts-and-expedients#page=730) |
| **Tumpline** | A broad band over the forehead, tied to the pack | Rests the shoulders; on a ford or log, drop the shoulder straps so the load "can be cast off instantly by throwing back the head" | [Kephart Vol. 2, p. 125](lib:kephart-camping-and-woodcraft-vol-2#page=125) |
| **Pack frame** | Two wooden uprights and cross-bars with canvas stretched tight; or a square of lashed limbs | Cool back; legs hold the load when you sit; best for heavy or sharp loads | [Kephart Vol. 2, p. 137](lib:kephart-camping-and-woodcraft-vol-2#page=137); [FM 3-05.70, p. 203](lib:fm-3-05-70-survival-2002#page=203) |
| **Alaskan packstrap** | Strap of hide, canvas or webbing with a quick-release knot | One pull drops the pack; take the safety off near water | [AFH, p. 452](lib:afh-10-644#page=452) |

**Mending:** duct tape, patches, safety pins, heavy thread or dental floss, a sewing kit, cord or wire
([TC 3-97.61, p. 74](lib:tc-3-97-61#page=74)), a sail needle and waxed thread ([Kephart Vol. 2, p. 110](lib:kephart-camping-and-woodcraft-vol-2#page=110)).
Patch a torn-out strap with salvaged canvas ([🖼️ Fabric repair, p. 101](lib:general-fabric-repair#page=101); "Mending and
hand sewing" in the [Clothing guide](guide:CLOTHING-LEATHER-GUIDE)).

## 🦶 Feet: boots, socks and blisters

### Boots and socks

- **Fit:** a thumb's width past the big toe, and a finger under the unlaced tongue ([🖼️ FM 21-18, pp. 107–108](lib:fm-21-18-foot-marches#page=108)).
  Pressure means too small, rubbing too big. Carry spare laces ([p. 109](lib:fm-21-18-foot-marches#page=109)).
- **Break boots in before the trip,** alternating with an old pair and taping known hot spots ([ATP 3-21.18, p. 110](lib:atp-3-21-18#page=110)).
  Dry them slowly with a warm cloth inside; on freezing nights keep them in the sleeping bag
  ([FM 21-18, p. 107](lib:fm-21-18-foot-marches#page=107)). Resoling: "Boots, shoes and moccasins" in the Clothing guide.
- **Socks:** "The wool cushion-sole sock is best"; dry damp ones inside your shirt ([FM 21-18, p. 109](lib:fm-21-18-foot-marches#page=109)).
  A thin nylon or polyester liner under the wool cuts blisters ([Knapik, p. 48](lib:load-carriage-in-military-operations#page=48)).
- **Wet feet:** stop "and wring out the hose; do not 'walk them dry'" ([Kephart Vol. 2, p. 144](lib:kephart-camping-and-woodcraft-vol-2#page=144)).
  No dry socks left: grass insoles an inch thick, made fresh daily ([AFH, p. 191](lib:afh-10-644#page=191)).

### Blisters

**Prevention:** two socks, good insoles, a lighter load, distance built up slowly, and "Cover skin when hot spots
appear" ([Knapik, p. 47](lib:load-carriage-in-military-operations#page=47)). A hot spot is "a localized warm or burning
sensation"; cover it with moleskin or tape at once ([p. 49](lib:load-carriage-in-military-operations#page=49)).

**Draining: the books disagree.** TC 3-97.61 says "Never drain blisters unless" infected ([p. 49](lib:tc-3-97-61#page=49));
FM 21-18 drains all of them ([p. 102](lib:fm-21-18-foot-marches#page=102)); Knapik leaves small ones and drains big ones
on weight-bearing spots ([p. 50](lib:load-carriage-in-military-operations#page=50)). **This guide follows Knapik:**
1. **Small (under 5 mm, about 3/16 in) and not painful:** leave it whole, inside a doughnut of moleskin
   ([Knapik, p. 52](lib:load-carriage-in-military-operations#page=52)).
2. **Big and tight on the sole or heel:** wash around it, flame a needle, prick it at the edge, press the fluid out and
   **leave the skin on**; cover past the edges ([🖼️ FM 21-18, p. 102](lib:fm-21-18-foot-marches#page=102)).
3. **Torn open:** take off the loose roof and treat it as a wound ([Knapik, p. 51](lib:load-carriage-in-military-operations#page=51));
   see "Wounds and infection when there's no hospital" in Field Care.
4. **Spreading redness or pus:** infection, which can become cellulitis or blood poisoning
   ([Knapik, p. 48](lib:load-carriage-in-military-operations#page=48)). Rest the foot.

![Four drawings of treating a foot blister: clean it, sterilize the needle in a flame, pierce the blister at its edge, cover it with a bandage](img:ON-FOOT-GUIDE/treating-a-foot-blister.png)
*For a big, tight blister on the sole or heel (step 2): clean it, flame the needle, prick it at the edge, and cover it with the skin left on ([FM 21-18, p. 102](lib:fm-21-18-foot-marches#page=102)).*

### Trench foot and frostbite

- **Trench foot** comes from days in wet, cold boots at **32–50 °F**, sitting or standing still, laced tight
  ([FM 21-18, p. 106](lib:fm-21-18-foot-marches#page=106)): an ordinary valley winter. Early on, feet are pale, numb and
  **not painful**, so check each other. Prevent it with dry socks and boots daily; in wet boots, wiggle the toes. Treat
  gently: feet "should not be rubbed or massaged"; clean, dry, raise, and carry the person (same page). Mild cases heal
  with about 24 hours of drying ([TC 3-97.61, p. 54](lib:tc-3-97-61#page=54)).
- **Frostbite** (high passes in winter): warm small spots with body heat, hands in armpits, bare feet on a companion's
  chest; no massage, fire or snow ([FM 21-18, p. 105](lib:fm-21-18-foot-marches#page=105)). Don't thaw deep frostbite on
  the trail: "it is safer to walk on frozen feet" ([p. 106](lib:fm-21-18-foot-marches#page=106)).

### A daily foot routine

| When | What | Source |
|---|---|---|
| Before the trip | Toenails "short and square, and straight across"; boots broken in | [🖼️ FM 21-18, p. 100](lib:fm-21-18-foot-marches#page=100) |
| Each morning | Clean, dry, powdered feet; tape known hot spots | [p. 101](lib:fm-21-18-foot-marches#page=101) |
| At halts | **One boot off at a time**; rub, powder, dry socks; loosen laces over the arch | [ATP, p. 110](lib:atp-3-21-18#page=110) |
| Evening | Wash feet and dry them well; dry socks and boots; look for red, swollen spots | [Kephart Vol. 2, p. 144](lib:kephart-camping-and-woodcraft-vol-2#page=144); [ATP, p. 110](lib:atp-3-21-18#page=110) |

Rub healthy feet only. A stress fracture needs **two or three weeks** of rest ([FM 21-18, p. 107](lib:fm-21-18-foot-marches#page=107)).

## 🧥 Clothing, cold and heat

What to wear is in "Dressing for our cold-wet winters" in the Clothing guide. On the trail:
- **Three layers:** one next to the skin that moves sweat, an insulating one, and a wind-and-rain shell. Wool "provides
  warmth when wet"; soaked clothing loses heat "several hundred times faster" than dry; cotton is a poor choice
  ([NY hunter manual, p. 77](lib:todays-hunter-in-new-york#page=77)).
- **Start cool;** "Do not sit around when overheated and damp ... But do not muffle up on the march"
  ([Kephart Vol. 2, p. 145](lib:kephart-camping-and-woodcraft-vol-2#page=145)). Dry underwear and socks at night "are as
  warm as an extra blanket" ([p. 104](lib:kephart-camping-and-woodcraft-vol-2#page=104)). Carry spare socks, hat and
  gloves, and a poncho or "extra-large plastic trash bag" ([TC 3-97.61, p. 73](lib:tc-3-97-61#page=73)).
- **Hypothermia** creeps up from wet brush, wind and "Resting against cold surfaces"; chocolate, peanuts or raisins help
  ([NY hunter manual, p. 82](lib:todays-hunter-in-new-york#page=82)). **Heat:** a hat and light clothing that covers the
  skin ([p. 77](lib:todays-hunter-in-new-york#page=77)). Treatment of both: Field Care. Smoke: the Wildfire guide.

## 💧 Water on the move

### How much to drink

| Conditions | Per person, per day | Source |
|---|---|---|
| Bare minimum, cool weather | 2 qt | [AFH, p. 279](lib:afh-10-644#page=279) |
| Cool weather, walking | 2–4 qt | [NY hunter manual, p. 81](lib:todays-hunter-in-new-york#page=81) |
| Cold or mountains, hard work | 3–6 L (3–6 qt) | [TC 3-97.61, p. 46](lib:tc-3-97-61#page=46) |
| Low mountains | 4–8 qt | [FM 3-97.6, p. 17](lib:fm-3-97-6-mountain-operations#page=17) |
| Short of food | 6–8 L | [FM 3-05.70, p. 33](lib:fm-3-05-70-survival-2002#page=33) |
| Hot, sweaty marching | 6–12 oz every 15–20 min; up to 10 L in extreme dry heat | [ATP 3-21.18, p. 107](lib:atp-3-21-18#page=107) |
| Never more than | 1¼ qt an hour, 12 L a day | [FM 21-10, p. 56](lib:us-army-fm-21-10#page=56) |

**Settled:** plan about **4 quarts** for a cool walking day and **6–8** for a hot one, never more than about a quart
an hour *(rule of thumb, from the ranges above)*.
- Drink at every halt, "even when not thirsty", and refill "at every opportunity" ([FM 21-18, p. 17](lib:fm-21-18-foot-marches#page=17)).
  Urine should be pale yellow. **In heat,** "Do not restrict salt": about 1 gram of sodium an hour on long, sweaty days
  ([ATP, p. 107](lib:atp-3-21-18#page=107)); too much plain water dilutes the blood's salt (Field Care).
- Don't eat snow: it "will contribute to loss of body heat" ([TC 3-97.61, p. 46](lib:tc-3-97-61#page=46)). **Running
  short?** "physical activity must be reduced" ([p. 75](lib:tc-3-97-61#page=75)); walk in the cool hours *(rule of thumb)*.

### Finding, carrying and treating water

- **Finding:** streams, springs, rain; a short tube fills a bottle from a trickle off rock; "Water is scarce above the
  timberline" ([TC 3-97.61, p. 75](lib:tc-3-97-61#page=75)). By a muddy pond, dig a hole "about 18 inches across and down
  about 6 inches below water-level, a few paces from the pond", bail it three times, then take the clearer water
  ([Seton, p. 292](lib:seton-the-book-of-woodcraft-1913#page=292)). Still treat it.
  Summer ridges are dry: plan refills at creeks and springs on the topo map *(rule of thumb)*.
- **Skip** water below farms or mine tailings ([TC 3-97.61, p. 75](lib:tc-3-97-61#page=75)). "Never drink from the well of
  an abandoned farm" ([Kephart Vol. 1, p. 214](lib:kephart-camping-and-woodcraft-vol-1#page=214)); "It is not true that
  running water purifies itself" ([p. 213](lib:kephart-camping-and-woodcraft-vol-1#page=213)).
- **Carrying:** wide-mouth bottles; bladders "can break and have freezing issues" ([TC 3-97.61, p. 73](lib:tc-3-97-61#page=73)).
  Sleep with your water on freezing nights ([p. 75](lib:tc-3-97-61#page=75)).
- **Treating:** "Virtually all surface waters are microbiologically contaminated", and Giardia and Cryptosporidium
  "thrive in domestic and wild animals" ([TC 3-97.61, p. 75](lib:tc-3-97-61#page=75)). A **1-minute** boil kills them;
  tablets miss Crypto and work slower in cold water; many filters don't stop viruses ([p. 76](lib:tc-3-97-61#page=76)).
  Methods: "Step 3 — Kill the germs" and "After a wildfire" in the [Water Purification guide](guide:WATER-PURIFICATION-GUIDE).

## 🍞 Food on the move

- **How much:** a loaded march burns over **300 calories an hour** ([FM 21-18, p. 65](lib:fm-21-18-foot-marches#page=65));
  Kephart lists 3,400 a day for moderate work, 4,150 hard, 5,500 very hard ([Kephart Vol. 1, p. 185](lib:kephart-camping-and-woodcraft-vol-1#page=185)),
  against everyday adult needs of 1,600–3,000 ([Dietary Guidelines, p. 152](lib:dietary-guidelines-for-americans#page=152)).
  **Plan 3,000–4,000 calories, about 2 lb of dry food, per person per walking day** *(arithmetic)*.
- **Calories per pound:** fat about 4,080 and butter 3,410 ([Kephart Vol. 1, p. 185](lib:kephart-camping-and-woodcraft-vol-1#page=185));
  parched corn 1,915, cornmeal 1,655, bread 1,205 ([Kephart Vol. 2, p. 159](lib:kephart-camping-and-woodcraft-vol-2#page=159)).
  Fresh food would be "five or six pounds a day" ([Kephart Vol. 1, p. 182](lib:kephart-camping-and-woodcraft-vol-1#page=182)).
- Carry **one extra day's food** ([TC 3-97.61, p. 74](lib:tc-3-97-61#page=74)). Eat little and often: 25–75 g of
  carbohydrate an hour in four bits ([ATP, p. 106](lib:atp-3-21-18#page=106)).

**Parched corn (pinole),** the lightest trail food in the library:
1. Parch dry corn "in clean hot ashes until it bursts", sift it, and pound it to meal ([Parker, p. 118](lib:iroquois-uses-of-maize#page=118)).
2. Stir it into water, "one tablespoonful to a pint" (same page). Two heaping tablespoons with raisins or chocolate made
   Kephart "a square meal" ([Kephart Vol. 2, p. 158](lib:kephart-camping-and-woodcraft-vol-2#page=158)).
3. **Go easy:** it swells. A handful (2 or 3 oz) was "even considered dangerous unless cooked" ([Parker, p. 119](lib:iroquois-uses-of-maize#page=119)).

**Make at home before you leave:** jerky and pemmican ("Jerky and pemmican" in [Preserving Food](guide:PRESERVING-FOOD-GUIDE)),
hardtack ("Staples" in [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE)) and dried fruit. A fist-size piece of pemmican
"would make a meal for two men" ([Kephart Vol. 2, p. 160](lib:kephart-camping-and-woodcraft-vol-2#page=160)). Eat lean
jerky with fat and grain, not alone *(rule of thumb)*.

**Little fuel:** in fire season, plan no-fire meals or a legal stove *(rule of thumb)*. A broad, shallow pot "boils water
much sooner"; skip foods that need long boiling ([Kephart Vol. 2, pp. 106–107](lib:kephart-camping-and-woodcraft-vol-2#page=106)).
Use a lid: only 10–40% of a fire's heat reaches the pot ([Aprovecho, p. 7](lib:aprovecho-pcia-design-principles#page=7)).
In the wet season, burn "dry, dead hardwood no larger than a pencil" for "less smoke" ([AFH, p. 563](lib:afh-10-644#page=563)).

## ⛺ Camp and sleep

### Choosing a campsite

A good site has water; wood if fires are allowed; a level spot "well above any chance overflow" ("Observe the previous
flood marks"); "Security against the spread of fire"; morning sun; shelter from winter wind; and privacy
([Kephart Vol. 1, p. 213](lib:kephart-camping-and-woodcraft-vol-1#page=213)). **Move on if the site is:**
- in a creek bottom, dry streambed or drainage (flash floods), under dead trees or dead limbs, in poison oak, or in a
  slide path, which shows as a strip of young growth down the slope ([AFH, p. 195](lib:afh-10-644#page=195));
- on the valley floor, where cold air pools ([AFH, p. 194](lib:afh-10-644#page=194)); camp "up the hillside above the
  valley floor", clear of rockfall ([TC 3-97.61, p. 77](lib:tc-3-97-61#page=77));
- beside brush, tall grass or boulders where snakes live ([FM 3-05.70, p. 530](lib:fm-3-05-70-survival-2002#page=530)), or
  on an animal trail ([ODFW bears, p. 2](lib:living-with-black-bears#page=2)).

### Tarp and debris shelters

- **Tarp or poncho lean-to:** back to the wind, a stick or line under the middle so rain can't pool
  ([FM 3-05.70, pp. 69–70](lib:fm-3-05-70-survival-2002#page=69)). Kephart tied one long side of a 7 × 9-ft cloth to a pole
  4 ft up and staked the other out at 45° ([Kephart Vol. 2, pp. 104–105](lib:kephart-camping-and-woodcraft-vol-2#page=104)).
  More in "Emergency tarp and plastic shelters" in the [Shelter guide](guide:SHELTER-BUILDING-GUIDE).
- **Debris hut,** warm with no fire ([FM 3-05.70, pp. 82–83](lib:fm-3-05-70-survival-2002#page=82)):
  1. Rest one end of a long ridgepole on a stump, rock or two short stakes, about waist high.
  2. Lean sticks along both sides as ribs, wide enough for your body and steep enough to shed rain; lay brush across.
  3. Pile dry leaves, needles and grass **at least 3 ft thick**, "the thicker the better", with branches on top.
  4. Put a **1-ft layer** inside to lie on, and pull a heap of debris into the doorway behind you.
- **Off the cold ground:** "Don't bed down on the cold, hard earth" ([Kephart Vol. 2, p. 105](lib:kephart-camping-and-woodcraft-vol-2#page=105)).
  Fir boughs are best, spruce prickly, pine thin ([AFH, p. 222](lib:afh-10-644#page=222)). Kephart's 1-lb "bed tick" is a
  cloth bag stuffed with dry leaves: "A 3-pound blanket on top of such a mattress is warmer than a 5-pound one without it"
  ([p. 106](lib:kephart-camping-and-woodcraft-vol-2#page=106)). On snow, use a foam pad ([TC 3-97.61, p. 73](lib:tc-3-97-61#page=73)).

![Two drawings of a debris hut: first a ridgepole resting on a stump with sticks leaned along both sides, then the frame buried under a thick pile of leaves and branches with a small doorway](img:ON-FOOT-GUIDE/debris-hut.png)
*Debris hut: (1) the ridgepole on a stump with ribs along both sides; (2) piled at least 3 ft thick with leaves and brush ([FM 3-05.70, p. 83](lib:fm-3-05-70-survival-2002#page=83)).*

### Fire and fire season

**The law in 2026** ([ODF closure, pp. 1–2](lib:odf-southwest-oregon#page=1)), on forest land protected by ODF's
Southwest Oregon District:
- "Open fires are prohibited, including campfires, cooking fires and warming fires", except on private land with the
  owner's permission at low (GREEN) danger and at designated campgrounds. "Smoking is prohibited while traveling."
- Camp stoves on bottled fuel are allowed in areas cleared "for 50 feet in all directions". While traveling, except on
  state highways, county roads and driveways, carry "one shovel and one gallon of water or one 2½ pound or larger fire
  extinguisher" ([p. 2](lib:odf-southwest-oregon#page=2)): on foot, a small shovel and a gallon among your bottles
  *(rule of thumb)*.
- The 2026 closure began **May 15**; ODF reissues it yearly. Treat **June through October as no-fire months** whether or
  not anyone says so *(rule of thumb)*. Illegal outdoor burning can cost **$12,000 a day** ([DEQ, p. 1](lib:oregon-deq-southern-oregon-outdoor-burning#page=1)).

**Where a fire is allowed** (wet season or a legal fire ring): keep it small and off slopes; drown it, stir, and feel the
ashes until "all steaming and sizzling stops"; "Never just bury a fire" ([ODFW hunter manual, p. 34](lib:odfw-todays-hunter-in-oregon#page=34)).
**Never burn poison oak:** the smoke can put people in "intensive care" ([OSU PNW 108, p. 4](lib:osu-pnw-108#page=4)).

### A quiet, hidden camp

Kephart's "masked camp" is "invisible from trails, and from opposite ridges", screened by evergreens so smoke and
firelight don't show, near a trail but not on it, with dead wood about so there's no noise of chopping, and with the
way in and out hidden ([Kephart Vol. 2, pp. 237–238](lib:kephart-camping-and-woodcraft-vol-2#page=237)). Also **BLISS**:
"Blend in", "Low silhouette", "Irregular shape", "Small", "Secluded location" ([FM 3-05.70, p. 68](lib:fm-3-05-70-survival-2002#page=68)).
**Toilet:** a "cat hole" 6–8 inches deep, at least 200 ft from camp and water ([NPS North Cascades, p. 1](lib:nps-north-cascades#page=1));
more in the [Sanitation guide](guide:SANITATION-GUIDE).

## 🐻 Bears, cougars, poison oak, ticks and snakes

### Food storage in bear country

- **Hang it:** ODFW says "at least 10 feet high and 6 to 10 feet from a tree trunk" ([ODFW bears, p. 2](lib:living-with-black-bears#page=2));
  BLM on the Rogue says twelve feet "between two trees and six feet from tree trunks" ([BLM, p. 16](lib:blm-rogue-river-boaters#page=16)).
  **Use 10–12 ft up and 6 ft out, on a line between two trees,** with food, pots, garbage and anything scented. Carry
  at least 50 ft of cord ([NPS North Cascades, p. 1](lib:nps-north-cascades#page=1)).
- "Sleep at least 100 yards from cooking and eating areas"; no food, soap or lotion in the tent; "Do not bury
  garbage—bears will dig it up"; "Avoid berry patches"; "Don't hike after dark" ([ODFW bears, p. 2](lib:living-with-black-bears#page=2)).

![Side-view diagram of a food bag hung from a line tied between two trees, 10 to 12 feet off the ground and at least 6 feet from each trunk](img:ON-FOOT-GUIDE/hanging-food-from-bears.svg)
*Hang food, pots, garbage and anything scented 10–12 ft up and at least 6 ft from the trunks, on a line between two trees (a diagram drawn for this guide).*

### Meeting a bear or a cougar

| | Black bear | Cougar |
|---|---|---|
| **Usually** | It avoids you. Give it a way out, step off the trail and walk away; leave cubs alone | It leaves if it can. Most active at dawn and dusk |
| **If it stays** | **Don't run. Avoid eye contact.** Back away slowly, facing it | **Don't run. Keep eye contact.** Stand your ground, then back away slowly |
| **Make noise** | Raise your voice, yell, clap | Yell, clap, **raise your arms**; **pick up children** without bending down or turning away |
| **If it attacks** | Fight back; bear spray | Fight back; bear spray works on cougars too |
| **Source** | [ODFW bears, p. 1](lib:living-with-black-bears#page=1) | [ODFW cougar, pp. 1–2](lib:oregon-is-cougar-country#page=1) |

A bear standing up is usually catching a scent, not attacking ([ODFW bears, p. 1](lib:living-with-black-bears#page=1)).
In cougar country be "alert when sitting quietly or stopping to rest", and keep away from animal kills
([ODFW cougar, p. 2](lib:oregon-is-cougar-country#page=2)).

### Poison oak, ticks and rattlesnakes

> 📷 **Is that poison oak?** Photograph it with the [plant identifier](guide:PLANT-ID) (under **Tools**). Leaves of three, let them be, whatever it says.

- **Poison oak** is common in western Oregon in brush, woods, clearcuts, stream banks and canyons, as a shrub or vine,
  usually with three leaflets, red in fall ([OSU PNW 108, pp. 1–2](lib:osu-pnw-108#page=1); [🖼️ photos, p. 3](lib:osu-pnw-108#page=3)).
  The oil is in every part but the pollen, **all year**, bare winter stems too. It rides on clothes, packs, firewood and
  dogs: "Wash your skin with soap and water as soon as possible", wash clothes separately, wash the dog
  ([p. 4](lib:osu-pnw-108#page=4)). No water: wipe with dirt or sand, but not over blisters ([FM 21-76, p. 132](lib:fm-21-76-army-survival-manual#page=132)).
- **Ticks:** check your whole body often ([AFH, p. 70](lib:afh-10-644#page=70)); pull a tick straight out with fine-tipped
  tweezers close to the skin, with no nail polish, petroleum jelly or heat ([🖼️ CDC, p. 50](lib:tickborne-diseases-of-the-united-states#page=50)).
  More in "Disease and safety" in the [Hunting guide](guide:HUNTING-TRAPPING-FISHING-GUIDE).
- **Rattlesnakes:** no hands into crevices, heavy brush or hollow logs; "Don't step over a fallen tree. Step on the log
  and look" ([FM 3-05.70, p. 531](lib:fm-3-05-70-survival-2002#page=531)). Bites: "Rattlesnakes, spiders and stings" in Field
  Care (no cutting, sucking, ice or tourniquet).

## 🌊 River and creek crossings

"The force of flowing water may be extremely great and is most often underestimated." Treat every stream as a danger
and avoid it if you can ([TC 3-97.61, p. 343](lib:tc-3-97-61#page=343)).

### When not to cross

- **Knee-deep is the limit** for one person, in "mild to moderate" current only. Swift water runs over 5 ft a second,
  about walking speed *(arithmetic)* ([TC 3-97.61, p. 345](lib:tc-3-97-61#page=345)). "Six inches of fast-moving water
  can knock you off" your feet ([Spotter guide, p. 12](lib:weather-spotters-field-guide#page=12)).
- **Our rivers are cold all year.** A fall in brings "involuntary gasping", and cold water "drains body heat 25 times
  faster than cold air" ([OSMB, p. 17](lib:osmb-experience-oregon-boating#page=17)). In very cold water, "Wade across if you
  can get only your feet wet"; otherwise find another way ([FM 3-05.70, p. 296](lib:fm-3-05-70-survival-2002#page=296)).
- **Never cross above** rapids, falls or a logjam. Logjams and fallen trees ("strainers", "sweepers") let water through
  but trap people ([OSMB, p. 14](lib:osmb-experience-oregon-boating#page=14); [AFH, p. 496](lib:afh-10-644#page=496)).
- **Wait for the water to drop.** Snow-fed streams run lowest in early morning ([TC 3-97.61, p. 343](lib:tc-3-97-61#page=343)).
  After heavy winter rain, wait a day or more; a bridge is worth a long detour *(rule of thumb)*. "Not every river or
  stream can be crossed safely. If it is possible, cross at a different time or place, use a different technique, or
  choose another route" ([p. 351](lib:tc-3-97-61#page=351)).

### Picking the spot and getting ready

Look from high ground first. Cross where the river widens, usually shallower; avoid bends (the outside is deep and fast)
and narrows; choose low banks ([TC 3-97.61, pp. 343–344](lib:tc-3-97-61#page=344)). Below the crossing you want a shallow
bar to wash up on, not rapids ([FM 3-05.70, p. 295](lib:fm-3-05-70-survival-2002#page=295)). Riffles in a line mean rocks;
a hump and drop behind a rock is a "hole" that sucks at your feet ([TC 3-97.61, p. 351](lib:tc-3-97-61#page=351)).
Then ([TC 3-97.61, p. 344](lib:tc-3-97-61#page=344) unless noted):
1. Sleeping bag, dry clothes and food in waterproof bags (trash bags work), dry clothes on top.
2. Socks and insoles off and stowed; **boots back on** for grip.
3. Pack high and snug, then **unbuckle the waist and chest straps** so you can get out of it if swept off your feet.
   "Unbuckle your pack straps ... Never tie yourself in while you cross" ([NPS North Cascades, p. 1](lib:nps-north-cascades#page=1)).
4. The Army normally keeps clothes on, with dry ones packed. In our cold water, keep them on and change on the far bank
   *(rule of thumb)*.
5. A stout pole about 3 in thick and 7–8 ft long ([FM 3-05.70, p. 297](lib:fm-3-05-70-survival-2002#page=297)).
6. A lookout 50–100 m upstream for floating logs, and someone downstream with a pole or rope to throw
   ([TC 3-97.61, p. 351](lib:tc-3-97-61#page=351)).

### Crossing alone

([TC 3-97.61, p. 345](lib:tc-3-97-61#page=345); 🖼️ Fig. 13-1 on the same page.)
1. Face slightly across the current; in strong current, turn more side-on and lean upstream.
2. Plant the pole **upstream** of you as a third leg, and probe with it.
3. Aim slightly downstream; going straight across fights the current.
4. Lead with the downstream foot in small steps; never move one foot until the other is set, and never cross your legs.
5. Step on the upstream side of rocks; the downstream side is scoured and the rock may roll.
6. On the far bank, drain your boots and put on dry socks ([p. 344](lib:tc-3-97-61#page=344)).

![Side view and top view of one person wading a stream: facing slightly across the current, leaning on a long pole planted upstream, shuffling sideways](img:ON-FOOT-GUIDE/fording-alone-pole-upstream.png)
*Crossing alone: the pole is planted upstream as a third leg; from above (right), the walker side-shuffles across with the current coming from the side ([TC 3-97.61, p. 345](lib:tc-3-97-61#page=345)).*

### Crossing as a group

- Know who can't swim before you start ([TC 3-97.61, p. 351](lib:tc-3-97-61#page=351)).
- **Chain:** side by side facing the far bank, arms linked, the **biggest person upstream** leaning into the current.
  **Conga line:** all face upstream, each holding the clothes or pack behind the shoulders of the person upstream.
  **Wedge:** the biggest at the upstream point, small people and the injured in the middle
  ([pp. 346–347](lib:tc-3-97-61#page=346)). One person calls each step. If someone loses control, don't cling so hard
  that the whole line goes down ([p. 346](lib:tc-3-97-61#page=346)).
- **Rope handline:** stretched across at **30–45° downstream**; cross on its downstream side, one at a time
  ([p. 348](lib:tc-3-97-61#page=348); [🖼️ pp. 349–350](lib:tc-3-97-61#page=349)). Taking the rope over first is the most
  dangerous job: the strongest swimmer, belayed, in a life jacket if you have one ([pp. 347–348](lib:tc-3-97-61#page=347)).
  **Never tie directly into a rope** in moving water; you must be able to let go ([p. 348](lib:tc-3-97-61#page=348)).
- **If you're swept away:** shed the pack; face downstream, feet up in front to fend off rocks, and "work with the flow
  of water" toward the nearest bar; keep away from eddies. Get out and get warm fast: "Hypothermia will set in quickly in
  colder waters" ([pp. 350–351](lib:tc-3-97-61#page=350)).

![Side view and top view of three people crossing a stream side by side with arms linked, facing the far bank](img:ON-FOOT-GUIDE/chain-crossing.png)
*The chain: side by side, arms locked, facing the far bank, the biggest person on the upstream end ([TC 3-97.61, p. 346](lib:tc-3-97-61#page=346)).*

## ❄️ Snow and the passes

- **Stay off the passes in storms and deep snow:** snow can fall any month above 5,000 ft ([FM 3-97.6, p. 15](lib:fm-3-97-6-mountain-operations#page=15)),
  and the back-road routes climb into country that holds snow into spring ("high passes can get snow", Start Here). In
  winter take the lower highway route or wait for a clear spell *(rule of thumb)*.
- **Walking on snow:** best is snow that holds you, next best calf-deep; avoid thigh-deep. Go early after a cold night,
  while the crust holds ([AFH, p. 467](lib:afh-10-644#page=467)).
- **Snowshoes:** bend a sapling about 1 in thick and 5 ft long into a loop about 12 in wide and lace it with cord; in a
  pinch, lash pine boughs together at the cut ends and tie them on ([AFH, pp. 255–256](lib:afh-10-644#page=255);
  [🖼️ TC 21-3, p. 52](lib:tc-21-3-soldiers-handbook#page=52)). Take them off when the snow holds you ([AFH, p. 468](lib:afh-10-644#page=468)).
- **Sunglasses** against snow blindness ([TC 3-97.61, p. 73](lib:tc-3-97-61#page=73)). In fog or with snow over the trail,
  use the compass and pace count in the Navigation guide.

**Avalanche signs.** Our danger is mostly on steep, open slopes and gullies high up after big storms *(rule of thumb)*.
- Most slides start on slopes of **30–45°**; slab avalanches cause about 90% of deaths ([AFH, p. 431](lib:afh-10-644#page=431)).
  Watch winds of 15 mph or more, and the time during and just after storms ([p. 433](lib:afh-10-644#page=433)).
- **Slide paths:** "Steep, open gullies and slopes, pushed over small trees, trees with limbs broken off, and tumbled
  rocks" ([AFH, p. 434](lib:afh-10-644#page=434)); "broken tree stumps at different heights" ([TC 21-3, p. 46](lib:tc-21-3-soldiers-handbook#page=46)).
- **Danger now:** "If the snow echoes or sounds hollow, conditions are dangerous. If the snow cracks and the cracks
  persist or run, the danger of a slab avalanche is imminent" ([AFH, p. 434](lib:afh-10-644#page=434)).
- **Crossing:** one at a time, never tied together, each trailing a line about 100 ft long. **If caught:** drop the
  pack, "use swimming motions" toward the side, get an arm up, make a breathing space. Buried people have about a 50%
  chance after 30 minutes, so dig fast ([p. 435](lib:afh-10-644#page=435)).

## 🛡️ Safety on the road

This is about avoiding trouble, calming it, and turning back. Fighting and patrolling are outside these guides.
- **Together, by day:** "Don't travel or hunt alone" ([NY hunter manual, p. 80](lib:todays-hunter-in-new-york#page=80));
  "Don't hike after dark" ([ODFW bears, p. 2](lib:living-with-black-bears#page=2)).
- **Low profile:** a pack with "nothing exposed to advertise your mission" ([Kephart Vol. 2, p. 108](lib:kephart-camping-and-woodcraft-vol-2#page=108));
  earth tones that "blend into your surroundings" ([NPS North Cascades, p. 1](lib:nps-north-cascades#page=1)). Don't show
  food, tools or weapons; spread valuables among the packs *(rule of thumb)*.
- **Most people are like you:** in American disasters looting has been "very rare", though massive in some catastrophes
  abroad ([Quarantelli, p. 12](lib:conventional-beliefs-and-counterintuitive#page=12)).
- **Meeting strangers** ([AFH, pp. 168–169](lib:afh-10-644#page=168)): if you can, "wait until only one person is near and,
  if possible, let that person make the initial approach". "Displaying fear, displaying weapons, and making sudden or
  threatening movements" can "prompt a hostile response". Smile; "Approach them slowly and don't rush matters." Keep any
  promise; don't enter a house uninvited. What to say: "Don't be a target" in [Home & Property Protection](guide:HOME-DEFENSE-GUIDE).

### Checkpoints and roadblocks

No book on the drive covers these from the traveler's side; these steps are *(rule of thumb)*:
1. Stop well short, in daylight and plain view. Never approach at night or try to slip around.
2. One person walks forward slowly, hands empty and visible; the rest wait.
3. Say who you are, where you're going and why, and ask to pass. Offer road news.
4. Keep your voice low and give them space ("Someone at the gate, strangers, or a break-in" in Home & Property
   Protection; [De-escalation, p. 15](lib:using-verbal-de-escalation#page=15)).
5. Don't argue or force it. If refused, thank them and turn back or go another way. Pass towns by day; camp well away.

**Share freely** *(rule of thumb)*: bridges out, safe fords, fire and smoke, water, sickness on the road, weather.
**Keep to yourself:** how many live at home, what you carry, where your cache is, when you'll be back, and whether you
are armed. Oregon law on force is in Home & Property Protection.

## 📋 Packing lists

From [NY hunter manual, p. 78](lib:todays-hunter-in-new-york#page=78), [TC 3-97.61, pp. 72–74](lib:tc-3-97-61#page=72),
[NPS North Cascades, p. 1](lib:nps-north-cascades#page=1) and [Kephart Vol. 2, pp. 108–110](lib:kephart-camping-and-woodcraft-vol-2#page=108).

| Day trip (each person) | Add for overnight or longer |
|---|---|
| Map, compass, whistle, signal mirror | Tarp or shelter cloth about 7 × 9 ft, cord, stakes |
| Water, 2–4 qt, and a way to treat it | Blanket or sleeping bag; foam pad or a bed tick to stuff with leaves |
| Food, plus one extra day's | About 2 lb of dry food per person per day |
| Rain layer, warm layer, hat, gloves | Small pot with lid, cup, spoon; stove and fuel in fire season |
| Spare dry socks | Change of underwear and socks |
| Knife; flashlight or headlamp, spare batteries | 50 ft of cord and a bag for hanging food |
| First-aid and foot kit (below) | Repair kit ("Mending" under Packs) |
| Poncho or big garbage bag | Trowel, soap, toilet paper |
| Spare glasses; two days' extra medicine | Camp shoes |
| Fire starter in a waterproof case (wet season) | Notebook and pencil for trail notes |
| Fire season: small shovel and a gallon of water (ODF) | Copies of route directions and map |

**First-aid and foot kit:** "The kit to build now" in Field Care, plus foot powder, gauze and adhesive tape
([FM 21-18, p. 55](lib:fm-21-18-foot-marches#page=55)), moleskin, a needle, and splint material
([TC 3-97.61, p. 73](lib:tc-3-97-61#page=73)). Leave the trip plan at home, and leave out the signal flares and lighter
fluid some old lists include. For a wildfire evacuation, see "Go-kit" in the Start Here guide.

## 📡 Staying in touch and trail signs

- **Radios:** section 5, "FRS / GMRS / MURS", of the [Radio guide](guide:RADIO-GUIDE). No radio: the
  [Signals guide](guide:SIGNALS-MORSE-GUIDE) covers whistles, mirrors and "Runners, relays and written messages"; no signal
  fires June–October. Agree on whistle signals before you leave (stop, come here, help), as the Army settles its sound
  signals in advance ([FM 21-18, p. 47](lib:fm-21-18-foot-marches#page=47)).
- **Signs for people behind you:** one stone set on another, a twig broken and left hanging, or a tuft of grass tied in a
  knot all mean "this is the trail" ([Seton, p. 267](lib:seton-the-book-of-woodcraft-1913#page=267);
  [🖼️ chart, p. 268](lib:seton-the-book-of-woodcraft-1913#page=268)). "All trails should be marked" ([AFH, p. 429](lib:afh-10-644#page=429)).
- **Notes at forks and camps:** a dated note in a jar under a small cairn: names, date, which way, all well or not
  *(rule of thumb)*. Write nothing you wouldn't want a stranger to read.

## 🆘 Getting lost

Follow "Getting un-lost" in the Navigation guide: Stop, Think, Observe, Plan. Before leaving each place, "study their
backtrail carefully" ([AFH, p. 429](lib:afh-10-644#page=429)). "If you get lost, the best thing you can do is stay put and
wait", using a whistle, bright clothing or a mirror ([NPS North Cascades, p. 1](lib:nps-north-cascades#page=1)), but that
works only if someone has your trip plan and will come. If no one will, walk a bearing to a big handrail such as US-199
or the Illinois River ("Terrain association" in the Navigation guide).

## ⚠️ Old advice in the library to ignore

| Book says | Do this instead |
|---|---|
| Cross with people "tied together" on a rope ([FM 3-05.70, pp. 298–299](lib:fm-3-05-70-survival-2002#page=298); [FM 21-76, p. 223](lib:fm-21-76-army-survival-manual#page=223)) | Never tie into a rope in moving water ([TC 3-97.61, p. 348](lib:tc-3-97-61#page=348)) |
| The pack's weight "will help" you ford ([FM 3-05.70, p. 298](lib:fm-3-05-70-survival-2002#page=298); [Kephart Vol. 2, p. 49](lib:kephart-camping-and-woodcraft-vol-2#page=49)) | Unbuckle hip and chest straps ([TC 3-97.61, p. 344](lib:tc-3-97-61#page=344)) |
| "deep water sometimes runs more slowly and is therefore safer" ([FM 3-05.70, p. 296](lib:fm-3-05-70-survival-2002#page=296)) | Alone, wade no deeper than the knee ([TC 3-97.61, p. 345](lib:tc-3-97-61#page=345)) |
| Pole planted downstream; heaviest person downstream; "The inside of a sharp bend is deep" ([Kephart Vol. 2, p. 49](lib:kephart-camping-and-woodcraft-vol-2#page=49); [FM 3-05.70, p. 298](lib:fm-3-05-70-survival-2002#page=298)) | Pole upstream, biggest person upstream; the outside of a bend is deep ([TC 3-97.61, pp. 344–346](lib:tc-3-97-61#page=344)) |
| Take off trousers to ford in cold weather ([Kephart Vol. 2, p. 49](lib:kephart-camping-and-woodcraft-vol-2#page=49); [FM 3-05.70, p. 297](lib:fm-3-05-70-survival-2002#page=297)) | Keep clothes on in our cold water; change after *(rule of thumb)* |
| Drink "14 to 30 liters of water per day" ([FM 21-76, p. 21](lib:fm-21-76-army-survival-manual#page=21)); "prevent the boys from excessive water drinking" ([Boy Scouts, p. 173](lib:boy-scouts-handbook-for-boys#page=173)) | No more than 1¼ qt an hour or 12 L a day ([FM 21-10, p. 56](lib:us-army-fm-21-10#page=56)); never ration a child's water in heat *(rule of thumb)* |
| Seep-hole water "is as safe as a spring" ([Seton, p. 292](lib:seton-the-book-of-woodcraft-1913#page=292)); a rock spring "is worthy of confidence" ([Kephart Vol. 1, p. 214](lib:kephart-camping-and-woodcraft-vol-1#page=214)) | Wild animals carry Giardia; treat all water ([TC 3-97.61, p. 75](lib:tc-3-97-61#page=75)) |
| Neutralize alkali water with hydrochloric acid ([Kephart Vol. 1, p. 214](lib:kephart-camping-and-woodcraft-vol-1#page=214)) | Never; find other water |
| Paint feet with formalin; inject benzoin into blisters ([FM 21-18, p. 103](lib:fm-21-18-foot-marches#page=103)); harden feet in alcohol, tannic acid or alum ([Kephart Vol. 2, p. 143](lib:kephart-camping-and-woodcraft-vol-2#page=143)) | Wash, dry, powder, change socks ([ATP 3-21.18, p. 110](lib:atp-3-21-18#page=110)); build up distance slowly ([FM 21-18, p. 100](lib:fm-21-18-foot-marches#page=100)) |
| Remove ticks with "heat, irritants, or petroleum jelly" ([AFH, p. 70](lib:afh-10-644#page=70)) | Fine tweezers, straight out ([CDC, p. 50](lib:tickborne-diseases-of-the-united-states#page=50)) |
| "Snake doctor" kit: a lancet and permanganate for the cut ([Kephart Vol. 2, p. 107](lib:kephart-camping-and-woodcraft-vol-2#page=107)) | No cuts, suction or chemicals ("Rattlesnakes, spiders and stings" in Field Care) |
| Treat poison oak with tannic acid or jewelweed ([FM 21-76, p. 132](lib:fm-21-76-army-survival-manual#page=132)) | Soap and water fast; home remedies "may worsen the problem" ([OSU PNW 108, p. 4](lib:osu-pnw-108#page=4)) |
| Signal flares and lighter fluid in the day pack ([NY hunter manual, p. 78](lib:todays-hunter-in-new-york#page=78)); a Dakota fire hole as an everyday fire ([AFH, p. 563](lib:afh-10-644#page=563)) | Mirror and whistle; no fires in fire season ([ODF, p. 1](lib:odf-southwest-oregon#page=1)), and fire holes can smolder into roots *(rule of thumb)* |
| A quarter pound of parched meal is "sufficient for a day's subsistence" ([Parker, p. 118](lib:iroquois-uses-of-maize#page=118)) | That is about 480 calories *(arithmetic)*; plan about 2 lb of dry food a day |
| Blaze trails with an axe on living trees ([Seton, p. 267](lib:seton-the-book-of-woodcraft-1913#page=267)) | Stacked stones, a broken twig, a knotted tuft of grass |

## 🖼️ Pictures & diagrams

- Load and march-speed charts — [🖼️ FM 21-18, p. 66](lib:fm-21-18-foot-marches#page=66); high and low loads, [🖼️ Knapik, p. 33](lib:load-carriage-in-military-operations#page=33); [Backpacking (hiking)](wiki:Backpacking_(hiking)); [Backpack](wiki:Backpack)
- Improvised packs — [🖼️ AFH, pp. 451–454](lib:afh-10-644#page=451); [🖼️ FM 3-05.70, pp. 202–203](lib:fm-3-05-70-survival-2002#page=202); rucksack, [🖼️ Shifts, p. 730](lib:shifts-and-expedients#page=730); pack harness with head strap and pack frame, [🖼️ Kephart Vol. 2, p. 123](lib:kephart-camping-and-woodcraft-vol-2#page=123), [🖼️ p. 136](lib:kephart-camping-and-woodcraft-vol-2#page=136); [Tumpline](wiki:Tumpline)
- Routes along divides; a masked camp — [🖼️ Kephart Vol. 2, p. 50](lib:kephart-camping-and-woodcraft-vol-2#page=50); [🖼️ p. 237](lib:kephart-camping-and-woodcraft-vol-2#page=237)
- Foot placement and the rest step — [🖼️ TC 3-97.61, p. 106](lib:tc-3-97-61#page=106); [🖼️ p. 108](lib:tc-3-97-61#page=108); slopes, scree and talus, [🖼️ AFH, pp. 447–450](lib:afh-10-644#page=447)
- Blister care, boot fit, sock sizes, toenails — [🖼️ FM 21-18, p. 102](lib:fm-21-18-foot-marches#page=102); [🖼️ p. 108](lib:fm-21-18-foot-marches#page=108); [🖼️ p. 110](lib:fm-21-18-foot-marches#page=110); [🖼️ p. 100](lib:fm-21-18-foot-marches#page=100); doughnut pad, [🖼️ Knapik, p. 52](lib:load-carriage-in-military-operations#page=52); [Blister](wiki:Blister); [Trench foot](wiki:Trench_foot)
- Poncho lean-to, poncho tent, debris hut, fir-bough bed — [🖼️ FM 3-05.70, p. 69](lib:fm-3-05-70-survival-2002#page=69); [🖼️ p. 71](lib:fm-3-05-70-survival-2002#page=71); [🖼️ p. 83](lib:fm-3-05-70-survival-2002#page=83); [🖼️ AFH, p. 222](lib:afh-10-644#page=222); [Lean-to](wiki:Lean-to)
- Trail signs — [🖼️ AFH, p. 430](lib:afh-10-644#page=430); [🖼️ Seton, p. 268](lib:seton-the-book-of-woodcraft-1913#page=268); [Cairn](wiki:Cairn)
- Fording alone and in groups; handline — [🖼️ TC 3-97.61, pp. 345–347](lib:tc-3-97-61#page=345); [🖼️ pp. 349–350](lib:tc-3-97-61#page=349); [Ford (crossing)](wiki:Ford_(crossing)); [Cold shock response](wiki:Cold_shock_response)
- Avalanche signs; improvised snowshoes — [🖼️ AFH, pp. 431–434](lib:afh-10-644#page=431); [🖼️ pp. 255–256](lib:afh-10-644#page=255); [🖼️ TC 21-3, p. 52](lib:tc-21-3-soldiers-handbook#page=52); [Avalanche](wiki:Avalanche); [Snowshoe](wiki:Snowshoe)
- Cougar tracks; poison oak in every season; tick removal — [🖼️ ODFW, p. 2](lib:oregon-is-cougar-country#page=2); [🖼️ OSU PNW 108, pp. 1–3](lib:osu-pnw-108#page=1); [🖼️ OSU EM 9184, p. 24](lib:osu-em-9184#page=24); [🖼️ CDC, p. 50](lib:tickborne-diseases-of-the-united-states#page=50); [Cougar](wiki:Cougar); [American black bear](wiki:American_black_bear); [Toxicodendron diversilobum](wiki:Toxicodendron_diversilobum)
- Improvised litters; donkey pack saddles — [🖼️ FM 4-25.11, pp. 211–212](lib:fm-4-25-11-first-aid#page=211); [🖼️ Starkey, p. 82](lib:harnessing-and-implements-for-animal-traction#page=82); [Stretcher](wiki:Stretcher); [Pack animal](wiki:Pack_animal)
- Trail foods — [Pemmican](wiki:Pemmican); [Hardtack](wiki:Hardtack); [Jerky](wiki:Jerky); [Pinole](wiki:Pinole)

## 🔗 Related guides

- [Bicycles, Carts & Hauling](guide:BICYCLES-CARTS-GUIDE) — travel times from Cave Junction; handcarts, travois, trailers
- [Illinois Valley — Start Here](guide:ILLINOIS-VALLEY-START-HERE) — "Walking out" routes, wildfire go-kit, burn line
- [Navigation & Weather](guide:NAVIGATION-WEATHER-GUIDE) — maps, compass, getting un-lost, trip plans, valley weather
- [Field Care](guide:FIELD-CARE-GUIDE) — heat and cold, wounds, rattlesnake bites, the first-aid kit
- [Water Purification](guide:WATER-PURIFICATION-GUIDE) — boiling, bleach and filters; water after a wildfire
- [Clothing, Textiles, Leather & Shoes](guide:CLOTHING-LEATHER-GUIDE) and [Make-Do Household](guide:MAKE-DO-HOUSEHOLD-GUIDE) — wet-weather clothes, mending, boots, tire sandals
- [Horses, Mules and Draft Animals](guide:HORSE-GUIDE) — packing stock for travel
- [Preserving Food](guide:PRESERVING-FOOD-GUIDE) and [Food From Scratch](guide:FOOD-FROM-SCRATCH-GUIDE) — jerky, pemmican, hardtack
- [Shelter, Building & Repair](guide:SHELTER-BUILDING-GUIDE) — tarp and plastic shelters
- [Wildfire](guide:WILDFIRE-GUIDE) — fire danger, smoke, and being caught outside by a fire
- [Signals, Morse Code & Messages](guide:SIGNALS-MORSE-GUIDE) and [Radio](guide:RADIO-GUIDE) — staying in touch on the road
- [Home & Property Protection](guide:HOME-DEFENSE-GUIDE) — strangers, de-escalation, Oregon law on force
- [Hunting, Trapping & Fishing](guide:HUNTING-TRAPPING-FISHING-GUIDE) and [Sanitation](guide:SANITATION-GUIDE) — ticks, licences, toilets, garbage and bears
- [Vehicles, Tractors & Heavy Equipment](guide:VEHICLES-EQUIPMENT-GUIDE) — when a vehicle stops being the way to travel
