# ⚒️ Blacksmithing and Hand Tools

How to set up a simple forge, pick the right scrap steel, forge and heat-treat it, and make or
repair basic hand tools — chisels, punches, tongs, knives, axes — plus how to sharpen and
re-handle the tools you already have. The full books are in `Blacksmithing-Tools\`
(`Blacksmithing`, `Heat-Treating-Steel`, `Hand-Tools`); axe and crosscut-saw manuals are in
`Engines-Motors\Chainsaws-and-Saws`. Farm blacksmithing (plow shares) and a short Practical
Action brief are in `Homestead-Skills\Food-Crafts-Tools`.

> ### ⚠️ Rules that prevent the worst injuries
> - **Hot steel looks exactly like cold steel.** Assume everything near the forge is hot; pick
>   things up with tongs, and set hot pieces down where no one will grab them.
> - **Eye protection** at the anvil, grinder and when quenching. Never use a cracked grinding
>   wheel, never wear gloves at the wheel, stand aside when you switch it on.
>   ([Navy *Steelworker*, p. 22](lib:steelworker-vol-1#page=22))
> - **Never heat galvanized (zinc-coated) metal indoors** — the fumes cause "metal fume fever."
>   Strip the zinc first *(rule of thumb: soak overnight in vinegar)* and work outdoors.
>   Drinking milk does not help, despite old advice
>   ([TM 10-440, p. 60](lib:us-army-tm-10-440#page=60) still recommends it — ignore that).
> - **Quench oil can catch fire.** Use a metal container with a close-fitting metal lid next to
>   it, enough oil to fully cover the piece, and plunge it in quickly and completely. **Never put
>   water on an oil fire** — smother it with the lid. *(Rule of thumb)* Oil fires usually start
>   when there's too little oil for the piece.
>   ([Practical Action *Blacksmithing*, p. 3](lib:practical-action-blacksmithing#page=3))
> - **A coal or charcoal forge makes carbon monoxide** — work outdoors or under an open-sided
>   roof.
> - **Fire season:** Illinois Valley summers are dry. Keep a full water bucket or trough by the
>   forge for embers as well as quenching
>   ([Practical Action, pp. 1–2](lib:practical-action-blacksmithing#page=2)), clear dry grass
>   and leaves well back from the forge, and never leave a fire unattended. *(Rule of thumb)*
> - **Oily rags can catch fire by themselves.** Throw them out or keep them in a bucket of water.
>   ([USFS *An Ax to Grind*, p. 34](lib:usfs-an-ax-to-grind#page=34))

---

## 🔥 A simple forge and anvil

*Rule-of-thumb setups; the books have full plans.*

- **Forge:** anything that holds a fist-sized pile of burning fuel with air blown up into the
  middle — a brake drum or steel tub lined with clay, or a brick or stone hearth with a pipe
  coming in at the bottom (the "tuyere"). The ICS *Shop Equipment* book and the Peace Corps
  manual show how to build forges and **bellows**.
  ([ICS, p. 21](lib:ics-blacksmith-shop-equipment#page=21); drawings:
  [🖼️ brick forge](lib:ics-blacksmith-shop-equipment#page=12),
  [🖼️ tuyere](lib:us-army-tm-10-440#page=8),
  [🖼️ village forges](lib:peace-corps-basic-techniques#page=27),
  [🖼️ how a bellows works](lib:ics-blacksmith-shop-equipment#page=21); [Forge](wiki:Forge))
- **Air:** a hand-crank blower, homemade bellows, a hair dryer or a small fan with a valve or
  gate to control it. Too much air wastes fuel and burns steel.
  ([🖼️ hand-built fan and pump designs](lib:peace-corps-basic-techniques#page=63);
  [🖼️ a blower](lib:practical-action-blacksmithing#page=2))
- **Fuel:** **charcoal** (easy to make — see `Homestead-Skills\Fuels`), or coal turned to coke in
  the fire. Keep the fire clean: rake out clinker (glassy lumps), and work in the hot center.
  Screen coke to get rid of dust before you use it.
  ([Practical Action, p. 2](lib:practical-action-blacksmithing#page=2);
  [Charcoal](wiki:Charcoal), [Coke](wiki:Coke_(fuel)), [Clinker](wiki:Clinker_(waste)))
- **Anvil:** a real anvil is best, but a chunk of **railroad rail**, a big block of steel, or a
  sledgehammer head set in a stump works. Set the face at about **knuckle height** when you
  stand with your arm hanging. Practical Action also shows a stone with an iron insert and an
  old casting used as anvils. ([Practical Action, p. 3](lib:practical-action-blacksmithing#page=3);
  [🖼️ improvised anvils](lib:practical-action-blacksmithing#page=3);
  [🖼️ parts of an anvil](lib:selvidge-and-allton#page=129))
- **First tools:** a 2–3 lb cross-peen hammer, a pair of tongs (or make them — they're a
  classic first project), a bucket of water, a file, and a magnet.
  ([🖼️ hammer types](lib:us-army-tm-10-440#page=13); [🖼️ common tongs](lib:us-army-tm-10-440#page=14);
  [🖼️ holding work in tongs](lib:selvidge-and-allton#page=18); [Tongs](wiki:Tongs))
- **Water trough:** big enough to sink the whole piece — at least about **25 litres (6½ US gallons)**.
  ([Practical Action, p. 2](lib:practical-action-blacksmithing#page=2))

**Running the fire** ([TM 10-440, pp. 26–27](lib:us-army-tm-10-440#page=27);
cross-sections of [🖼️ open and side-banked fires](lib:us-army-tm-10-440#page=27) and
[🖼️ a hollow fire](lib:us-army-tm-10-440#page=28);
[🖼️ building the fire](lib:selvidge-and-allton#page=16)):
- The **hottest spot is about 5–7 inches above the tuyere.** Keep the fire just big enough to
  surround the piece with glowing coals.
- A **thin fire** lets unburned air reach the steel and covers it in scale (an "oxidizing"
  fire). A **deep fire** uses up the air first — slower, but it doesn't scale the steel.
- Pack **wet, unburned fuel around the edges** to keep the fire from spreading; it cokes there
  and feeds the center as you need it.

![A forge fire drawn whole and in cross-section: a cone of coke burning over the tuyere in the center, with green coal packed around the edges](img:BLACKSMITHING-GUIDE/forge-fire-cross-section.png)
*Coke burns in the center right over the tuyere; green (unburned) coal packed round the edges cokes slowly and feeds it ([TM 10-440, p. 27](lib:us-army-tm-10-440#page=27)).*

| Fire problem | Likely cause | Fix |
|---|---|---|
| Steel comes out heavily scaled | Fire too thin, too much air | Build the fire deeper; less blast |
| Fire won't get hot | Clinker choking the tuyere; wet or dusty fuel | Rake out clinker; screen fuel |
| Fire spreads and wastes fuel | Too much loose fuel, no banking | Pack damp fuel around the edges |

[Anvil](wiki:Anvil), [Tuyere](wiki:Tuyere), [Bellows](wiki:Bellows), [Swage block](wiki:Swage_block),
[Hardy tool](wiki:Hardy_tool).

📚 **Go deeper:** [ICS *Blacksmith Shop Equipment*](lib:ics-blacksmith-shop-equipment#page=15) — forges, blowers, bellows and anvil tools; [Peace Corps *Basic Techniques of Blacksmithing*](lib:peace-corps-basic-techniques#page=20) — building a forge and tools from scrap; [TM 10-440](lib:us-army-tm-10-440#page=26) — fuel and fire management; [Peace Corps *Charcoal Making*](lib:peace-corps-small-scale-charcoal) — making forge charcoal.

## 🌡️ Heat colors (in shade, not sunlight)

| Color | About °F | What it's for |
|---|---|---|
| Dull red | 1,050–1,175 | **Stop hammering** — steel worked colder than this cracks. |
| Cherry red | 1,250–1,375 | Hardening temperature for most carbon steel; bending. |
| Orange to yellow | 1,725–1,975 | Normal **forging** heat — hammer here. |
| Bright yellow-white, "flowing" surface | about 2,000 and up | **Forge welding** (mild steel and wrought iron). A few sparks are normal at welding heat. |
| White, throwing a shower of sparks | hotter still | **Burned.** The steel is ruined — cut that part off. |

(°F from [TM 10-440's color table, p. 25](lib:us-army-tm-10-440#page=25); colors look different in
different light and to different eyes, so learn them on your own forge.)

High-carbon steel burns at a lower heat than mild steel, so forge tool steel no hotter than
orange-yellow. **Burned steel can't be fixed by any later heat treatment.** Keep hammering until
the steel cools to a low red — forging refines the grain and makes it tougher.
([TM 10-440, p. 24](lib:us-army-tm-10-440#page=24))

**Basic moves:** *drawing out* (hammering thinner and longer), *upsetting* (hammering the hot
end to make it thicker), *bending* over the anvil horn or edge, *punching* holes hot, *cutting*
on a hardy (a chisel set in the anvil), *twisting*, and *forge welding*. Ilgen's *Forge Work*
and the Selvidge *Shop Manual* walk through each one step by step. Drawings:
[🖼️ drawing out](lib:selvidge-and-allton#page=24), [🖼️ upsetting](lib:selvidge-and-allton#page=31),
[🖼️ bending](lib:us-army-tm-10-440#page=30), [🖼️ hardy and chisels](lib:us-army-tm-10-440#page=18),
[🖼️ top and bottom fullers](lib:us-army-tm-10-440#page=15); [Blacksmith](wiki:Blacksmith).

**Punching a hole** ([TM 10-440, p. 33](lib:us-army-tm-10-440#page=33);
[🖼️ drawing](lib:selvidge-and-allton#page=36)): center-punch the spot,
heat to a good working heat, drive the punch **two-thirds of the way through**, flip the piece,
and punch out from the other side over the anvil's round (pritchel) hole. Cool the punch often
so it doesn't soften, and drop a little dry coal in a deep hole to stop the punch sticking.

![A hand punch and three cross-sections of the hole: punched two-thirds through, turned over and punched through, and the finished hole](img:BLACKSMITHING-GUIDE/punching-a-hole.png)
*Punch A: drive it about two-thirds through (B), turn the piece over and drive it through on the mark (C), then finish over the pritchel hole (D) ([Selvidge, pp. 36–37](lib:selvidge-and-allton#page=36)).*

**Forge welding, step by step** ([Selvidge, pp. 45–47](lib:selvidge-and-allton#page=45);
[TM 10-440, pp. 30–31](lib:us-army-tm-10-440#page=30)):
1. **Prepare:** upset each end to about 1½ times its thickness, then hammer a **scarf** (a
   bevel) on each, slightly **rounded, not hollow**, so scale squeezes out from the middle.
   ([🖼️ good and bad scarfs](lib:bacon-forge-practice#page=42);
   [🖼️ shaping the scarf](lib:bacon-forge-practice#page=41))
2. **Clean fire, clean anvil:** rake out clinker, have plenty of coke ready, brush scale off the
   anvil face, and set your hammer where you can grab it.
3. **Heat slowly** under a covering of live coals, turning the pieces so both heat evenly.
   ([🖼️ both pieces in the fire, scarf up](lib:selvidge-and-allton#page=47))
4. At **bright red**, sprinkle **flux — borax or clean sand** — on the scarfs; it keeps air off
   and melts the scale so it can squeeze out.
5. Keep heating until the surface looks **wet and flowing**. Pull both pieces, knock off loose
   scale, lap the scarfs and strike **light blows first, then heavier**.
   ([🖼️ laying the pieces together](lib:drew-farm-blacksmithing#page=41);
   [🖼️ lap-weld drawings](lib:selvidge-and-allton#page=46))
6. **Don't keep hammering once it drops below welding heat.** If it doesn't stick, cut off the
   tips, re-scarf and try again. Use as few heats as possible.

![Side view of two scarfed bar ends laid together: slightly rounded faces touching in the middle with scale squeezing out at the sides, and hollow faces touching only at the edges with scale trapped in a pocket](img:BLACKSMITHING-GUIDE/scarfs-rounded-not-hollow.svg)
*Rounded scarfs meet in the middle and squeeze the scale out; hollow ones meet at the edges and trap it (a diagram drawn for this guide).*

| Forging problem | Likely cause | Fix |
|---|---|---|
| Cracks while hammering | Worked below dull red | Reheat sooner; stop at dull red |
| Sparks and a crumbly end | Burned | Cut back to sound metal |
| Weld won't stick | Not hot enough, dirty fire, no flux, scale between faces | Clean fire, flux at bright red, reach full welding heat |
| Weld lets go later | Hammered after it cooled; hollow scarfs trapped scale | Round the scarfs; weld in fewer, hotter heats |
| Thin tip burns before the thick part is hot | Fast heating | Heat slowly and keep the thin end back from the hot spot ([Drew, p. 63](lib:drew-farm-blacksmithing#page=63)) |

[Forge welding](wiki:Forge_welding).

📚 **Go deeper:** [Selvidge *Blacksmithing Shop Manual*](lib:selvidge-and-allton#page=45) — every basic operation as a one-page job sheet; [Ilgen *Forge Work*](lib:ilgen-forge-work) — drawing, upsetting, bending and welding explained; [TM 10-440](lib:us-army-tm-10-440#page=24) — heat colors, forging and welding in brief.

## 🔩 Which scrap steel to use

([Peace Corps *Basic Techniques of Blacksmithing*, p. 31](lib:peace-corps-basic-techniques#page=31))

| Steel | Found in | Good for |
|---|---|---|
| **Low carbon** — won't harden | Car body panels, most **rebar** ([Rebar](wiki:Rebar)), nails, bolts, rail spikes ([Railroad spike](wiki:Rail_fastening_system)), pipe, drums | Hooks, hinges, brackets, tongs, anything that bends instead of cuts. Forge-welds easily. |
| **Medium carbon** — hardens | **Leaf and coil springs** ([Coil spring](wiki:Coil_spring)), axles, torsion bars, shock-absorber rods | Chisels, punches, hammers, axes, hoes, pry bars, springs. **The best all-round tool stock.** |
| **High carbon** — hardens hard | **Old files**, saw blades, drill bits, dies, bulldozer blades | Knives, scrapers, wood chisels, plane irons — tools that must hold a keen edge. |

**Sources disagree on springs.** The Peace Corps puts car springs, axles and torsion bars in the
medium-carbon group; Practical Action calls coil springs, leaf springs and torsion bars **high
carbon**. Test each piece and treat springs as hardening steel either way. Practical Action also
warns that **rebar often has a bit more carbon than true mild steel.**
([Practical Action, p. 5](lib:practical-action-blacksmithing#page=5))

- **Quick test:** heat the tip to light cherry red and quench it in water. If a file **skates
  over it like glass**, it will harden. If the file bites, it's low-carbon.
  ([Peace Corps, p. 32](lib:peace-corps-basic-techniques#page=32))
- **Spark test** on a grinder: low-carbon steel throws long streams with few forks;
  **high-carbon throws shorter, bushier streams full of bright bursts**; cast iron throws short
  dull red sparks. Practice on known pieces first. In the Navy *Steelworker*'s pictures
  the low-carbon stream runs about **70 inches**, high-carbon about **55 inches** with more
  volume, and gray cast iron only about **25 inches**, red near the wheel and straw-colored at
  the end. Watch a spot about a third of the way back from the tip of the stream.
  ([Steelworker, pp. 22–24](lib:steelworker-vol-1#page=22);
  [🖼️ the parts of a spark stream](lib:steelworker-vol-1#page=21);
  [🖼️ spark patterns of common metals](lib:steelworker-vol-1#page=23))
- **Other clues** ([Peace Corps, p. 32](lib:peace-corps-basic-techniques#page=32)): drop it on
  concrete and compare the ring with known pieces; see whether a cold chisel nicks it easily;
  and **think about its old job** — anything that had to be springy, tough or wear-resistant is
  probably medium or high carbon.

![Spark streams from a grinding wheel: long plain streams from low-carbon steel, bushy streams full of bursts from high-carbon steel, and short broken streams from gray cast iron](img:BLACKSMITHING-GUIDE/spark-test-patterns.png)
*At the grinder (wheel on the right): low-carbon steel throws long, plain streams; high-carbon, bushy streams full of bursts; gray cast iron, short streams ([Navy *Steelworker*, p. 23](lib:steelworker-vol-1#page=23)).*

[Spark testing](wiki:Spark_testing), [Leaf spring](wiki:Leaf_spring). More pictures:
[Carbon steel](wiki:Carbon_steel).

📚 **Go deeper:** [Peace Corps manual, scrap identification](lib:peace-corps-basic-techniques#page=31) — what's in scrap and how to test it; [Navy *Steelworker* Vol 1](lib:steelworker-vol-1#page=21) — spark and chip tests with pictures; [Practical Action *Blacksmithing* brief](lib:practical-action-blacksmithing#page=5) — mild, medium and high carbon steel from old vehicles.

## 🧪 Hardening and tempering

1. **Anneal (soften) old steel before reshaping it cold or filing it:** heat slowly to red, then
   bury it in **dry wood ashes**, lime or powdered charcoal and leave it until cold.
   ([Selvidge, p. 56](lib:selvidge-and-allton#page=56); [Annealing](wiki:Annealing_(materials_science)))
2. **Harden:** heat evenly to **cherry red** — *rule of thumb: just past the point where a magnet
   stops sticking to it* — and quench.
   - **Plain carbon steel** (springs, files, most scrap): water or **brine** (about ¾ lb salt per
     gallon) cools fastest and most evenly. Thin or very high-carbon pieces (files, knives) can
     crack in water — **warm oil** (80–150 °F; vegetable oil works) is gentler.
     ([Steelworker, pp. 35–36](lib:steelworker-vol-1#page=35))
   - **Alloy steels:** oil only.
   - **Keep the piece moving** in the quench. Steam and gas bubbles otherwise cling to it and
     leave **soft spots**, which can later crack or warp.
     ([Selvidge, p. 57](lib:selvidge-and-allton#page=57); Steelworker, p. 35;
     [🖼️ a quench tank](lib:steelworker-vol-1#page=35); [Quenching](wiki:Quenching))
   - The steel is now **glass-hard and brittle** — temper it right away, before it's fully cold.
     The Navy *Steelworker* manual takes parts out of the quench at about **200 °F** — still too
     hot to touch — rather than letting them cool through the "cracking range" below that.
     ([Steelworker, p. 31](lib:steelworker-vol-1#page=31))
3. **Temper:** polish a spot bright with sandpaper or a stone, then reheat gently (over the fire,
   on a hot plate, or in an oven) and watch the colors run. Quench when the edge reaches the
   color you want:

| Color | About | Use |
|---|---|---|
| Pale yellow | 430 °F | Engraving and lathe tools, scrapers |
| Straw | 460 °F | Taps, punches, dies, knives for a very hard edge |
| Brown-yellow (deep straw) | 500 °F | Wood chisels, drills, plane irons, hammer faces |
| Purple | 530–540 °F | Light cold chisels, shears, axes |
| Blue tinged with purple | 550 °F | Ordinary cold chisels |
| Blue | 570–600 °F | Springs, picks |

The further toward blue, the softer and tougher. **Books disagree a little** — one old table
puts most chisels and knives at light blue — so test your tool and adjust.
([Bacon, p. 263](lib:bacon-forge-practice#page=263);
[Selvidge, p. 59](lib:selvidge-and-allton#page=59); [TM 10-440, p. 26](lib:us-army-tm-10-440#page=26))

**One-heat method for chisels and punches:** heat the working end to cherry red, quench only
the tip inch or so (bob it up and down), pull it out, quickly polish the tip, and watch the
heat from the shank run colors toward the edge. When the right color reaches the edge, quench
the whole tool. ([Steelworker, p. 34](lib:steelworker-vol-1#page=34);
[Selvidge, p. 58](lib:selvidge-and-allton#page=58))

![Three steps: a chisel's working end heated cherry red, only its tip dipped and bobbed in water, then color bands of blue, purple, brown and straw creeping toward the polished edge](img:BLACKSMITHING-GUIDE/one-heat-tempering.svg)
*One heat for a cold chisel: the colors creep from the hot shank to the edge, and you quench it all when purple arrives; real colors vary with the light (a diagram drawn for this guide).*

**Many pieces at once:** temper them in a pot of oil over the fire with a thermometer instead of
by color — steadier and more even. ([Bacon, pp. 263–264](lib:bacon-forge-practice#page=264);
[🖼️ tempering kettle with its lid](lib:bacon-forge-practice#page=264))

**If the tool doesn't work right:**

| Problem | Likely cause | Fix |
|---|---|---|
| Edge **chips or breaks** in use | Too hard | Reheat gently to the next softer color and quench ([Selvidge, p. 59](lib:selvidge-and-allton#page=59)) |
| Edge **bends or dulls fast** | Too soft — tempered too far, or never got hard | Re-harden and temper less *(rule of thumb)* |
| File still bites after quenching | Low-carbon steel, or not hot enough | Test the steel; heat to full cherry red |
| **Soft spots** | Steam pockets in the quench | Move the piece in the quench; use brine |
| **Cracked** in the quench | Too hot, quench too harsh, thick-and-thin shape, sharp inside corners | Harden at cherry, not hotter; use oil for thin or high-carbon pieces |
| **Warped** | Uneven heat or uneven entry into the quench | Heat evenly; plunge straight in, thick end first ([Drew, p. 64](lib:drew-farm-blacksmithing#page=64); [🖼️ an axe going in thick part first](lib:bacon-forge-practice#page=257)) |

[Tempering colors](wiki:Tempering_(metallurgy)). More pictures:
[Hardening](wiki:Hardening_(metallurgy)), [Heat treating](wiki:Heat_treating).

📚 **Go deeper:** [Bacon *Forge Practice and Heat Treatment of Steel*](lib:bacon-forge-practice#page=263) — temper colors and oil-bath tempering; [Woodworth *Hardening, Tempering, Annealing*](lib:woodworth-hardening-tempering) — deep detail on heat-treating tools; [Navy *Steelworker* Vol 1](lib:steelworker-vol-1#page=28) — annealing, hardening, quench media; [Selvidge](lib:selvidge-and-allton#page=56) — annealing, hardening and tempering job sheets.

## 🛠️ Making basic tools

- **Cold chisel** (first real project): a 6–8 inch piece of **coil spring or axle**. Straighten
  it, draw one end to a wedge, grind or file the edge to about 60°, harden and temper to purple at
  the edge (one-heat method). Leave the striking end soft.
  ([TM 10-440, pp. 33–34](lib:us-army-tm-10-440#page=33);
  [🖼️ forging a chisel](lib:drew-farm-blacksmithing#page=53); [Chisel](wiki:Chisel))
- **Hot chisel vs cold chisel:** a **hot chisel** is left soft and used **only on hot steel**; a
  **cold chisel** is hardened and tempered and used **only on cold steel.** Don't swap them. ([Practical Action, p. 4](lib:practical-action-blacksmithing#page=4);
  [🖼️ hot and cold chisels side by side](lib:us-army-tm-10-440#page=18);
  [🖼️ hot and cold cutters](lib:selvidge-and-allton#page=136))
- **Center punch / drift:** same steel, drawn to a round taper; temper the point straw to brown.
- **Tongs:** two matching pieces of mild steel, forged with jaws and a boss, punched and riveted
  together. Richardson Vol 2 and Selvidge have patterns.
  (Step drawings: [🖼️ Drew](lib:drew-farm-blacksmithing#page=43), [🖼️ ICS](lib:ics-blacksmith-shop-equipment#page=120))
- **Knife:** from an **old file** or saw blade. Anneal first, forge or grind to shape (on a
  grinder, dip often — blue on the edge means you've ruined the temper), harden in oil, temper
  straw to brown.
- **Axe, hoe, hammer:** the Peace Corps manual covers forging each from scrap, including
  punching the eye with a drift. ([🖼️ axe step by step](lib:peace-corps-basic-techniques#page=68);
  [🖼️ field hoe](lib:peace-corps-basic-techniques#page=73);
  [🖼️ cross-peen hammer](lib:peace-corps-basic-techniques#page=80))
- **Fullers** (grooving tools) and other top and bottom tools can be made of plain mild steel.
  ([Practical Action, p. 4](lib:practical-action-blacksmithing#page=4);
  [🖼️ the tools a smith needs](lib:practical-action-blacksmithing#page=4);
  [🖼️ top fuller](lib:us-army-tm-10-440#page=15), [🖼️ bottom fuller](lib:us-army-tm-10-440#page=16))
- **Repairing tools ("dressing"):** reforge mushroomed chisel heads, re-point picks, and redraw
  worn hoes and drill bits — ICS *Shop Equipment, Hand Forging and Tool Dressing*.

**Sharpening a plow share** — gardens and fields here depend on it
([Drew *Farm Blacksmithing*, pp. 62–64](lib:drew-farm-blacksmithing#page=62);
[🖼️ drawing out a share's edge](lib:selvidge-and-allton#page=109);
[Ploughshare](wiki:Plowshare)):
1. Use a **round-faced 2½–3 lb hammer.** Draw the edge out by hammering the **top** side while
   the bottom lies flat on the anvil.
2. **Don't burn the edge** while heating — it's thin and heats fast.
3. If the point bends over, rest the edge on a **hardwood block**, not the anvil, while you drive
   it back.
4. Harden a good-steel share at full red, plunging it **thick side first** into water or brine.
   For stony ground, leave it less hard so it doesn't chip.
5. A worn-out point can be replaced by welding on a piece of old plow steel (not a rasp — too
   high in carbon to weld easily), using borax as flux. Practice on scrap first. Skip the old
   book's chemical hardening powder.

📚 **Go deeper:** [Peace Corps manual](lib:peace-corps-basic-techniques#page=65) — axe, hoe, tongs and hammer projects; [ICS *Tool Dressing*](lib:ics-blacksmith-shop-equipment#page=137) — reforging and re-tempering worn tools; [Drew *Farm Blacksmithing*](lib:drew-farm-blacksmithing#page=51) — farm repairs, chisels and plow work; [Richardson *Practical Blacksmithing* Vol 2](lib:richardson-practical-blacksmithing-vol-2) — tongs and shop-made tools.

## 🪓 Keeping hand tools working

**Hanging an axe handle** ([USFS *An Ax to Grind*](lib:usfs-an-ax-to-grind#page=24)):
- First check whether you need a new handle at all — often just a new wedge will do.
  ([*An Ax to Grind*, p. 28](lib:usfs-an-ax-to-grind#page=28))
- Line the edge up with the center of the handle. Laid flat, the blade should touch the table one
  third of the way from the heel. ([p. 24](lib:usfs-an-ax-to-grind#page=24);
  [🖼️ a correctly hung ax](lib:usfs-an-ax-to-grind#page=24))
- Saw the wedge slot about two-thirds of the depth of the eye. Drive the head on by **striking the
  end of the handle** on a block, not the head. ([pp. 30–31](lib:usfs-an-ax-to-grind#page=30), photographed
  step by step: [🖼️ p. 30](lib:usfs-an-ax-to-grind#page=30), [🖼️ p. 31](lib:usfs-an-ax-to-grind#page=31))
- Drive a **hardwood wedge** in until it stops, leaving ¼–½ inch, then trim. **No metal wedges,
  screws or epoxy.** Soaking a loose head in water only works for a day.
  ([pp. 32–33](lib:usfs-an-ax-to-grind#page=32); [🖼️ wedging, pictured](lib:usfs-an-ax-to-grind#page=32))
  Soaking the head in **linseed oil** is a better temporary fix. (p. 33)
- Good handle woods: straight-grained ash (Oregon ash grows here), hickory, oak. *(Rule of thumb)*
  The grain should run straight along the handle and in line with the wedge slot.
  ([p. 26](lib:usfs-an-ax-to-grind#page=26); [🖼️ good and bad grain](lib:usfs-an-ax-to-grind#page=26);
  [Oregon ash](wiki:Fraxinus_latifolia), [Hickory](wiki:Hickory))

![The hang of an ax: heads set too open and too closed, and a properly hung ax laid flat touching the table one third of the way from the heel](img:BLACKSMITHING-GUIDE/hang-of-an-ax.png)
*Laid flat, a well-hung ax touches the table a third of the way from the heel ([*An Ax to Grind*, p. 24](lib:usfs-an-ax-to-grind#page=24)).*

**Sharpening:**
- **Never sharpen an axe on a fast dry bench grinder** — it draws the temper (the edge turns
  blue). Use a **file** (cuts on the push stroke only; lift on the return, wear gloves and use a
  knuckle guard), a slow wet grindstone, then a whetstone. File until a burr forms, then switch
  sides. Aim for about **25°**, slightly convex.
  ([*An Ax to Grind*, pp. 34–36](lib:usfs-an-ax-to-grind#page=34);
  [*Handtools for Trail Work*, p. 22](lib:usfs-mtdc-handtools-for-trail-work#page=22);
  [🖼️ filing with a guard](lib:usfs-an-ax-to-grind#page=35);
  [🖼️ edge-shape gauge to copy](lib:usfs-an-ax-to-grind#page=36);
  [🖼️ field sharpening](lib:usfs-mtdc-handtools-for-trail-work#page=22))
- If you do blue an edge, the temper is gone for at least **3/16 inch** back — grind or file
  past it. On a pedal grindstone, keep it wet and turn it **toward you, into the edge.** File
  in a **fan shape** 2–3 inches back from the middle of the edge, and hone every morning you use
  the axe. ([*An Ax to Grind*, pp. 34–36](lib:usfs-an-ax-to-grind#page=35))
- **Chisels and plane irons:** grind at about 25°, then hone on an oilstone or water stone until
  a fine burr forms, flip and flatten the back, and strop.
  The grindstone shapes; **only the stone sharpens** — hone at a hair steeper angle than you
  ground. ([Griffith *Essentials of Woodworking*, pp. 68–69](lib:griffith-essentials-of-woodworking#page=68);
  [🖼️ holding the chisel on the stone](lib:griffith-essentials-of-woodworking#page=69))
- **Hand saws** ([Disston](lib:disston-saw-tool-and-file#page=34)): clamp with the gullets just above the jaws. **Joint** the teeth level
  with a flat file, **set** them (never deeper than half the tooth), then file. **Crosscut:** every
  other tooth with the file angled about 45° toward the handle, then turn the saw around for the
  rest. **Rip:** straight across at 90°.
  ([Disston, pp. 35–38](lib:disston-saw-tool-and-file#page=35);
  [🖼️ teeth and set, seen from the side and back](lib:disston-saw-tool-and-file#page=34);
  [🖼️ the two filing positions](lib:disston-saw-tool-and-file#page=38); [Hand saw](wiki:Hand_saw))
- **Files:** keep them dry and separate (files dull each other), clean them with a file card or a
  nail, and use chalk on the teeth for soft metals.
  ([Nicholson *Treatise on Files and Rasps*, pp. 101–102](lib:nicholson-treatise-on-files#page=101);
  [*An Ax to Grind*, p. 35](lib:usfs-an-ax-to-grind#page=35))

**Edge angles for digging and trail tools** ([USFS *Handtools for Trail Work*](lib:usfs-mtdc-handtools-for-trail-work#page=25)):

| Tool | Bevel |
|---|---|
| Axe | About 25°, slightly convex, fan-shaped 2–3 in back |
| Pulaski | Axe blade like an axe; adze (grub) blade with about a ⅜-inch bevel ([p. 25](lib:usfs-mtdc-handtools-for-trail-work#page=25); [🖼️ drawing](lib:usfs-mtdc-handtools-for-trail-work#page=25)) |
| McLeod and draw hoes | 45° on the outside edge; no need to hone ([pp. 26, 28](lib:usfs-mtdc-handtools-for-trail-work#page=26); [🖼️ hoe drawings](lib:usfs-mtdc-handtools-for-trail-work#page=28); [McLeod](wiki:McLeod_(tool))) |
| Mattock grubbing blade | 35° on the underside ([p. 27](lib:usfs-mtdc-handtools-for-trail-work#page=27); [🖼️ drawing](lib:usfs-mtdc-handtools-for-trail-work#page=27)) |
| Shovel | About 45° on the top (inside) face, filed from below the foot rest to the point ([p. 29](lib:usfs-mtdc-handtools-for-trail-work#page=29); [🖼️ blade shapes](lib:usfs-mtdc-handtools-for-trail-work#page=29)) |
| Carpenter's adze | 30° on the underside, then whetstone ([p. 46](lib:usfs-mtdc-handtools-for-trail-work#page=46); [Adze](wiki:Adze)) |
| Digging bar | Keep the factory bevel ([p. 30](lib:usfs-mtdc-handtools-for-trail-work#page=30)) |

**Hammers and grinders** (Army *TM 9-243 Use and Care of Hand Tools*):
- Replace a hammer with a **chipped or cracked face** — chips fly off.
  ([TM 9-243, p. 122](lib:tm-9-243#page=122))
- Replace cracked handles. To get a stuck one out, saw it off close to the head and **drive the
  stub out through the large end of the eye** with a drift. Rub linseed oil into wooden handles
  now and then. ([TM 9-243, pp. 126–128](lib:tm-9-243#page=126);
  [🖼️ handle-replacing tools and wedges](lib:tm-9-243#page=127))
- **Before mounting a grinding wheel, tap it lightly** with a mallet: a clear **ring** means
  sound, a **dull thud** means it may be cracked — don't use it.
  ([TM 9-243, p. 185](lib:tm-9-243#page=185); [🖼️ sharpening stones and the bench grinder](lib:tm-9-243#page=185);
  [🖼️ dressing a grinding wheel](lib:steelworker-vol-1#page=22); [Bench grinder](wiki:Bench_grinder))
- Never grind brass, copper or aluminum on a steel-grinding wheel — it clogs and can unbalance
  the wheel until it flies apart. ([Steelworker, p. 22](lib:steelworker-vol-1#page=22))

[Axe](wiki:Axe), [Pulaski](wiki:Pulaski_(tool)), [Mattock](wiki:Mattock), [File](wiki:File_(tool)),
[Whetstone](wiki:Whetstone).

📚 **Go deeper:** [USFS *An Ax to Grind*](lib:usfs-an-ax-to-grind#page=28) — hanging and sharpening axes step by step; [USFS *Handtools for Trail Work*](lib:usfs-mtdc-handtools-for-trail-work#page=25) — using and sharpening digging and cutting tools; [Disston *Saw, Tool and File Book*](lib:disston-saw-tool-and-file#page=34) — jointing, setting and filing hand saws; [TM 9-243](lib:tm-9-243#page=122) — Army care and repair of every common hand tool.

## 🖼️ Pictures & diagrams

Look before you try it. 🖼️ = drawings in the books on this drive; 📷 = photos in the offline Wikipedia.

**Forge, fire and anvil**
- Brick forge and tuyere — [🖼️ ICS, p. 12](lib:ics-blacksmith-shop-equipment#page=12); [🖼️ TM 10-440, p. 8](lib:us-army-tm-10-440#page=8); [Forge](wiki:Forge); [Tuyere](wiki:Tuyere)
- Village and hand-powered forges — [🖼️ Peace Corps, p. 27](lib:peace-corps-basic-techniques#page=27); [🖼️ p. 28](lib:peace-corps-basic-techniques#page=28)
- Bellows, fans and forge pumps — [🖼️ ICS, p. 21](lib:ics-blacksmith-shop-equipment#page=21); [🖼️ Peace Corps, p. 63](lib:peace-corps-basic-techniques#page=63); [🖼️ Practical Action, p. 2](lib:practical-action-blacksmithing#page=2); [Bellows](wiki:Bellows)
- The fire in cross-section — [🖼️ TM 10-440, p. 27](lib:us-army-tm-10-440#page=27); [🖼️ p. 28](lib:us-army-tm-10-440#page=28)
- Anvil parts and improvised anvils — [🖼️ Selvidge, p. 129](lib:selvidge-and-allton#page=129); [🖼️ ICS, p. 37](lib:ics-blacksmith-shop-equipment#page=37); [🖼️ Practical Action, p. 3](lib:practical-action-blacksmithing#page=3); [Anvil](wiki:Anvil)
- Hammers, tongs and holding the work — [🖼️ TM 10-440, p. 13](lib:us-army-tm-10-440#page=13); [🖼️ p. 14](lib:us-army-tm-10-440#page=14); [🖼️ Selvidge, p. 18](lib:selvidge-and-allton#page=18); [Tongs](wiki:Tongs)
- Hardy, fullers, swages and swage block — [🖼️ TM 10-440, p. 15](lib:us-army-tm-10-440#page=15); [🖼️ p. 16](lib:us-army-tm-10-440#page=16); [🖼️ p. 18](lib:us-army-tm-10-440#page=18); [🖼️ p. 19](lib:us-army-tm-10-440#page=19); [Hardy tool](wiki:Hardy_tool); [Swage block](wiki:Swage_block)

**Forging operations**
- Drawing out — [🖼️ Selvidge, p. 24](lib:selvidge-and-allton#page=24); [🖼️ TM 10-440, p. 28](lib:us-army-tm-10-440#page=28)
- Upsetting — [🖼️ Selvidge, p. 31](lib:selvidge-and-allton#page=31)
- Bending — [🖼️ TM 10-440, p. 30](lib:us-army-tm-10-440#page=30); [🖼️ Selvidge, p. 26](lib:selvidge-and-allton#page=26)
- Punching a hole — [🖼️ Selvidge, p. 36](lib:selvidge-and-allton#page=36)
- Scarfs for welding: rounded, not hollow — [🖼️ Bacon, p. 41](lib:bacon-forge-practice#page=41); [🖼️ p. 42](lib:bacon-forge-practice#page=42)
- Taking the welding heat and making the weld — [🖼️ Selvidge, p. 46](lib:selvidge-and-allton#page=46); [🖼️ p. 47](lib:selvidge-and-allton#page=47); [🖼️ Drew, p. 41](lib:drew-farm-blacksmithing#page=41); [Forge welding](wiki:Forge_welding)

**Steel and heat treatment**
- Spark testing — [🖼️ Navy *Steelworker*, p. 21](lib:steelworker-vol-1#page=21); [🖼️ p. 23](lib:steelworker-vol-1#page=23); [Spark testing](wiki:Spark_testing)
- Quench tank; dipping the thick part first — [🖼️ Navy *Steelworker*, p. 35](lib:steelworker-vol-1#page=35); [🖼️ Bacon, p. 257](lib:bacon-forge-practice#page=257); [Quenching](wiki:Quenching)
- Oil-bath tempering kettle — [🖼️ Bacon, p. 264](lib:bacon-forge-practice#page=264); [Tempering colors](wiki:Tempering_(metallurgy))

**Making tools**
- Hot and cold chisels; hot and cold cutters — [🖼️ TM 10-440, p. 18](lib:us-army-tm-10-440#page=18); [🖼️ Selvidge, p. 136](lib:selvidge-and-allton#page=136); [Chisel](wiki:Chisel)
- Forging a cold chisel — [🖼️ Drew, p. 53](lib:drew-farm-blacksmithing#page=53)
- Making tongs — [🖼️ Drew, p. 43](lib:drew-farm-blacksmithing#page=43); [🖼️ ICS, p. 120](lib:ics-blacksmith-shop-equipment#page=120)
- Axe, field hoe and cross-peen hammer from scrap — [🖼️ Peace Corps, p. 68](lib:peace-corps-basic-techniques#page=68); [🖼️ p. 73](lib:peace-corps-basic-techniques#page=73); [🖼️ p. 80](lib:peace-corps-basic-techniques#page=80)
- A smith's basic tools at a glance — [🖼️ Practical Action, p. 4](lib:practical-action-blacksmithing#page=4)
- Sharpening a plow share — [🖼️ Selvidge, p. 109](lib:selvidge-and-allton#page=109); [Ploughshare](wiki:Plowshare)

**Axes and hand tools**
- Parts of an ax; a correctly hung ax — [🖼️ *An Ax to Grind*, p. 9](lib:usfs-an-ax-to-grind#page=9); [🖼️ p. 24](lib:usfs-an-ax-to-grind#page=24); [Axe](wiki:Axe)
- Hanging a new handle, step by step — [🖼️ p. 30](lib:usfs-an-ax-to-grind#page=30); [🖼️ p. 31](lib:usfs-an-ax-to-grind#page=31); [🖼️ p. 32](lib:usfs-an-ax-to-grind#page=32)
- Filing an ax; the edge gauge — [🖼️ p. 35](lib:usfs-an-ax-to-grind#page=35); [🖼️ p. 36](lib:usfs-an-ax-to-grind#page=36); [File](wiki:File_(tool))
- Trail tools: Pulaski, mattock, hoes, shovel — [🖼️ USFS, p. 25](lib:usfs-mtdc-handtools-for-trail-work#page=25); [🖼️ p. 27](lib:usfs-mtdc-handtools-for-trail-work#page=27); [🖼️ p. 28](lib:usfs-mtdc-handtools-for-trail-work#page=28); [🖼️ p. 29](lib:usfs-mtdc-handtools-for-trail-work#page=29); [Pulaski](wiki:Pulaski_(tool)); [Mattock](wiki:Mattock)
- Honing a chisel — [🖼️ Griffith, p. 69](lib:griffith-essentials-of-woodworking#page=69); [Whetstone](wiki:Whetstone)
- Saw teeth, set and filing positions — [🖼️ Disston, p. 34](lib:disston-saw-tool-and-file#page=34); [🖼️ p. 38](lib:disston-saw-tool-and-file#page=38); [Hand saw](wiki:Hand_saw)
- Grinder, grinding wheel and stones — [🖼️ TM 9-243, p. 185](lib:tm-9-243#page=185); [🖼️ Navy *Steelworker*, p. 22](lib:steelworker-vol-1#page=22); [Bench grinder](wiki:Bench_grinder)

## 🔗 Related guides

- [Engines, motors and generators](guide:ENGINES-AND-MOTORS-GUIDE) — chainsaws, crosscut saws,
  and motor repair.
- [Fuel guide](guide:FUEL-GUIDE) — charcoal, wood gas and keeping fuel safe near a forge.
- [Make-do household guide](guide:MAKE-DO-HOUSEHOLD-GUIDE) — mending and making what you need at
  home.
- [Horse guide](guide:HORSE-GUIDE) — working animals that need shoes, harness hardware and tools.
- [Illinois Valley start here](guide:ILLINOIS-VALLEY-START-HERE) — the local picture and where
  everything is on the drive.

---

*The old books use coal forges and some chemicals now known to be dangerous (cyanide for
case-hardening, asbestos). Use their methods, not their chemicals.*
